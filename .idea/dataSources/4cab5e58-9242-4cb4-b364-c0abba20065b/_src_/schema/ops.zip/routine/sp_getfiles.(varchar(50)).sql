CREATE PROCEDURE ops.sp_getfiles(IN parentid VARCHAR(50))
  BEGIN
	select t1.*
from `files_view` t1
where t1.file_lastupdated = (select t2.file_lastupdated from `files_view` t2
							where lower(t1.file_name) = lower(t2.file_name) and t2.file_parent_id = parentid
                            order by t2.file_lastupdated desc
                            limit 1)
                            and t1.file_parent_id = parentid
                            order by t1.file_name;
END;
