CREATE VIEW auth.check_photo_admin AS
  SELECT
    `ug`.`group_id` AS `group_id`,
    `u`.`user_id`   AS `user_id`
  FROM ((`auth`.`user_group` `ug`
    JOIN `auth`.`group` `g` ON ((`ug`.`group_id` = `g`.`group_id`))) JOIN `auth`.`user` `u`
      ON ((`u`.`user_id` = `ug`.`user_id`)))
  WHERE (`g`.`group_name` = 'PhotoAdmin');
