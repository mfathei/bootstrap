CREATE VIEW auth.user_groups AS
  SELECT
    `g`.`group_id`   AS `group_id`,
    `g`.`group_name` AS `group_name`,
    `g`.`is_primary` AS `is_primary`,
    `au`.`user_id`   AS `user_id`
  FROM ((`auth`.`group` `g`
    JOIN `auth`.`user_group` `ug` ON ((`g`.`group_id` = `ug`.`group_id`))) JOIN `auth`.`user` `au`
      ON ((`ug`.`user_id` = `au`.`user_id`)));
