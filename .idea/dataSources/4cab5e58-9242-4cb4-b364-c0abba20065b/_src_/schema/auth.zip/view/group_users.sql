CREATE VIEW auth.group_users AS
  SELECT
    `g`.`group_id`      AS `group_id`,
    `g`.`group_name`    AS `group_name`,
    `u`.`user_id`       AS `user_id`,
    `u`.`first_name`    AS `first_name`,
    `u`.`last_name`     AS `last_name`,
    `g`.`is_primary`    AS `is_primary`,
    `u`.`is_locked_out` AS `is_locked_out`
  FROM ((`auth`.`group` `g`
    JOIN `auth`.`user_group` `ug` ON ((`g`.`group_id` = `ug`.`group_id`))) JOIN `auth`.`user` `u`
      ON ((`u`.`user_id` = `ug`.`user_id`)))
  ORDER BY `g`.`group_name`;
