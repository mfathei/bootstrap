CREATE VIEW auth.get_photo_users AS
  SELECT
    `u`.`user_id`                                  AS `node_id`,
    concat(`u`.`first_name`, ' ', `u`.`last_name`) AS `node_name`
  FROM ((`auth`.`user` `u`
    JOIN `auth`.`user_group` `ug` ON ((`ug`.`user_id` = `u`.`user_id`))) JOIN `auth`.`group` `g`
      ON ((`g`.`group_id` = `ug`.`group_id`)))
  WHERE (`g`.`group_name` = 'PhotoUser')
  ORDER BY `u`.`first_name`;
