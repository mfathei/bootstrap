CREATE VIEW auth.sales_territory_users AS
  SELECT
    `u`.`user_id`      AS `user_id`,
    `u`.`first_name`   AS `first_name`,
    `u`.`last_name`    AS `last_name`,
    `g`.`group_name`   AS `group_name`,
    `t`.`territory_id` AS `territory_id`
  FROM (((`auth`.`user` `u`
    JOIN `auth`.`user_group` `ug` ON ((`u`.`user_id` = `ug`.`user_id`))) JOIN `auth`.`group` `g`
      ON ((`g`.`group_id` = `ug`.`group_id`))) JOIN `common`.`territory` `t`
      ON ((`t`.`territory_name` = `g`.`group_name`)))
  WHERE (`g`.`is_primary` = 1)
  ORDER BY `u`.`first_name`, `u`.`last_name`;
