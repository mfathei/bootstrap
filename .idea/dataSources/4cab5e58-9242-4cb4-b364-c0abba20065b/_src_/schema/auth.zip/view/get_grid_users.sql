CREATE VIEW auth.get_grid_users AS
  SELECT
    `u`.`user_id`                                                        AS `user_id`,
    `u`.`first_name`                                                     AS `first_name`,
    `u`.`last_name`                                                      AS `last_name`,
    `u`.`user_name`                                                      AS `user_name`,
    `u`.`user_password`                                                  AS `user_password`,
    `u`.`user_email`                                                     AS `user_email`,
    `u`.`email_password`                                                 AS `email_password`,
    `u`.`phone`                                                          AS `phone`,
    `u`.`phone_ext`                                                      AS `phone_ext`,
    `u`.`question`                                                       AS `question`,
    `u`.`answer`                                                         AS `answer`,
    `u`.`is_locked_out`                                                  AS `is_locked_out`,
    `u`.`failed_login`                                                   AS `failed_login`,
    `u`.`last_login`                                                     AS `last_login`,
    `u`.`machine_name`                                                   AS `machine_name`,
    `u`.`machine_ip`                                                     AS `machine_ip`,
    `u`.`title`                                                          AS `title`,
    (SELECT `g`.`group_name`
     FROM ((`auth`.`group` `g`
       JOIN `auth`.`user_group` `ug` ON ((`g`.`group_id` = `ug`.`group_id`))) JOIN `auth`.`user` `s`
         ON ((`ug`.`user_id` = `s`.`user_id`)))
     WHERE ((`s`.`user_id` = `u`.`user_id`) AND (`g`.`is_primary` = 1))) AS `primary_group`
  FROM `auth`.`user` `u`;
