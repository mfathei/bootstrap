CREATE VIEW auth.users_for_groups AS
  SELECT
    `auth`.`user`.`user_id`    AS `user_id`,
    `auth`.`user`.`first_name` AS `first_name`,
    `auth`.`user`.`last_name`  AS `last_name`
  FROM `auth`.`user`
  ORDER BY `auth`.`user`.`first_name`, `auth`.`user`.`last_name`;
