CREATE VIEW auth.pl_auth AS
  SELECT
    `u`.`user_id`    AS `user_id`,
    `u`.`first_name` AS `first_name`,
    `u`.`last_name`  AS `last_name`,
    `u`.`user_email` AS `user_email`
  FROM ((`auth`.`user` `u`
    JOIN `auth`.`user_group` `ug` ON ((`u`.`user_id` = `ug`.`user_id`))) JOIN `auth`.`group` `g`
      ON ((`ug`.`group_id` = `g`.`group_id`)))
  WHERE ((lower(`g`.`group_name`) = 'photouser') OR (lower(`g`.`group_name`) = 'photoadmin'));
