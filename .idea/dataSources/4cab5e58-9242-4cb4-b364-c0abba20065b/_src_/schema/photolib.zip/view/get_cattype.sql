CREATE VIEW photolib.get_cattype AS
  SELECT
    `ct`.`cattype_name` AS `cattype_name`,
    `s`.`subcat_id`     AS `subcat_id`
  FROM ((`photolib`.`cat_type` `ct`
    JOIN `photolib`.`cat` `c` ON ((`ct`.`cattype_id` = `c`.`cattype_id`))) JOIN `photolib`.`sub_cat` `s`
      ON ((`c`.`cat_id` = `s`.`cat_id`)));
