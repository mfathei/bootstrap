CREATE VIEW photolib.subcat_pics AS
  SELECT
    `p`.`pic_id`                      AS `pic_id`,
    `p`.`pic_realname`                AS `pic_realname`,
    round((`p`.`pic_size` / 1024), 0) AS `pic_size`,
    `s`.`subcat_id`                   AS `subcat_id`
  FROM ((`photolib`.`pic` `p`
    JOIN `photolib`.`pic_subcat` `ps` ON ((`p`.`pic_id` = `ps`.`picsubcat_picid`))) JOIN `photolib`.`sub_cat` `s`
      ON ((`ps`.`picsubcat_subcatid` = `s`.`subcat_id`)))
  ORDER BY `p`.`pic_realname`;
