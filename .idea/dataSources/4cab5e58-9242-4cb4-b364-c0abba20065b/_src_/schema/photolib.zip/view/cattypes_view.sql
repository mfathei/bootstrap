CREATE VIEW photolib.cattypes_view AS
  SELECT
    `cy`.`cattype_id`                AS `cat_id`,
    `cy`.`cattype_name`              AS `name`,
    `ci`.`cat_userid`                AS `user_id`,
    (CASE WHEN (`cy`.`cattype_name` = 'Global')
      THEN 'true'
     WHEN (`cy`.`cattype_name` = 'Private')
       THEN if((SELECT count(`c`.`cat_id`)
                FROM (`photolib`.`cat` `c`
                  JOIN `photolib`.`cat_type` `ct` ON ((`ct`.`cattype_id` = `c`.`cattype_id`)))
                WHERE ((`c`.`cattype_id` = `cy`.`cattype_id`) AND ((`c`.`cat_userid` = `ci`.`cat_userid`) > 0))),
               'true', 'false') END) AS `hasChildren`
  FROM (`photolib`.`cat_type` `cy`
    JOIN `photolib`.`cat` `ci` ON ((`cy`.`cattype_id` = `ci`.`cattype_id`)))
  ORDER BY `cy`.`cattype_name`;
