CREATE VIEW photolib.company_cats AS
  SELECT
    `c`.`cat_id`   AS `cat_id`,
    `c`.`cat_name` AS `cat_name`
  FROM (`photolib`.`cat` `c`
    JOIN `photolib`.`cat_type` `t` ON ((`c`.`cattype_id` = `t`.`cattype_id`)))
  WHERE (lower(`t`.`cattype_name`) = 'company')
  ORDER BY `c`.`cat_name`;
