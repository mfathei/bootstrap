CREATE VIEW photolib.personal_cats AS
  SELECT
    `c`.`cat_id`     AS `cat_id`,
    `c`.`cat_name`   AS `cat_name`,
    `c`.`cat_userid` AS `cat_userid`
  FROM (`photolib`.`cat` `c`
    JOIN `photolib`.`cat_type` `t` ON ((`c`.`cattype_id` = `t`.`cattype_id`)))
  WHERE (lower(`t`.`cattype_name`) = 'personal')
  ORDER BY `c`.`cat_name`;
