CREATE VIEW photolib.staging_view AS
  SELECT
    `s`.`pic_id`      AS `pic_id`,
    `s`.`pic_name`    AS `pic_realname`,
    `s`.`user_id`     AS `user_id`,
    `u`.`first_name`  AS `first_name`,
    `u`.`last_name`   AS `last_name`,
    `s`.`subcat_id`   AS `subcat_id`,
    `t`.`subcat_name` AS `subcat_name`,
    `c`.`cat_id`      AS `cat_id`,
    `c`.`cat_name`    AS `cat_name`,
    `s`.`pic_size`    AS `pic_size`
  FROM (((`photolib`.`staging` `s`
    JOIN `auth`.`user` `u` ON ((`s`.`user_id` = `u`.`user_id`))) JOIN `photolib`.`sub_cat` `t`
      ON ((`s`.`subcat_id` = `t`.`subcat_id`))) JOIN `photolib`.`cat` `c` ON ((`t`.`cat_id` = `c`.`cat_id`)));
