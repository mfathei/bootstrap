CREATE PROCEDURE photolib.delete_from_cat(IN picid VARCHAR(50), IN subcatid VARCHAR(50))
  BEGIN
	declare cnt int;
	select count(picsubcat_id) into cnt from pic_subcat where picsubcat_picid = picid;
	if cnt > 1 then
			delete from pic_subcat where picsubcat_picid = picid and picsubcat_subcatid = subcatid;
	end if;
	select cnt;
END;
