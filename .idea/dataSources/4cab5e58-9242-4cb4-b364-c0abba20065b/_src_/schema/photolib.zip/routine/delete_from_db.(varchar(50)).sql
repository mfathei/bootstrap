CREATE PROCEDURE photolib.delete_from_db(IN picid VARCHAR(50))
  BEGIN
	declare cnt int;
	delete from pic_subcat where picsubcat_picid = picid;
	delete from pic where pic_id = picid;
	set cnt = 1;
	select cnt;
END;
