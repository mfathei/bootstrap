CREATE PROCEDURE photolib.search_cats(IN subcatid VARCHAR(50), IN letters VARCHAR(5))
  begin
select cat_id,cat_name from cat 
where cattype_id = (select t.cattype_id from cat_type t 
inner join cat c on t.cattype_id = c.cattype_id
inner join sub_cat s on c.cat_id = s.cat_id
where s.subcat_id = subcatid) and
cat_name like concat(letters,'%');
end;
