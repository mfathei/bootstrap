CREATE PROCEDURE photolib.save_image_to_subcat(IN picid VARCHAR(50), IN subcatid VARCHAR(50))
  BEGIN
	declare cnt int;
	select count(picsubcat_id) into cnt from pic_subcat where picsubcat_picid = picid and picsubcat_subcatid = subcatid;
	if cnt > 0 then
		set cnt = 0;
        else
			begin
				insert into pic_subcat values (myuuid(),picid,subcatid);
                set cnt = ROW_COUNT();
            end;
	end if;
	select cnt;
END;
