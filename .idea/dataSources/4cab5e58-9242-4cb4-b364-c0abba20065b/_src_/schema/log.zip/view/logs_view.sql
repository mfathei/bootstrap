CREATE VIEW log.logs_view AS
  SELECT
    concat(`u`.`first_name`, ' ', `u`.`last_name`)    AS `user`,
    `z`.`module`                                      AS `module`,
    `z`.`zip_file`                                    AS `zip_file`,
    `l`.`emaillog_id`                                 AS `emaillog_id`,
    `l`.`email_date`                                  AS `log_date`,
    group_concat(`r`.`recipient_email` SEPARATOR ',') AS `recipients`
  FROM (((`log`.`email_log` `l`
    JOIN `auth`.`user` `u`) JOIN `log`.`zip` `z`) JOIN `log`.`email_recipient` `r`)
  WHERE ((`l`.`emaillog_id` = `r`.`email_id`) AND (`l`.`user_id` = `u`.`user_id`) AND (`l`.`zip_id` = `z`.`zip_id`))
  GROUP BY `l`.`emaillog_id`
  ORDER BY `l`.`email_date` DESC;
