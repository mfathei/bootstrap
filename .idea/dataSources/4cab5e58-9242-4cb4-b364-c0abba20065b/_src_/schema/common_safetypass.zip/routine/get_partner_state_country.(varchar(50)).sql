CREATE PROCEDURE common_safetypass.get_partner_state_country(IN cty VARCHAR(50))
  begin
	select `s`.`StateId`,`t`.`CountryId` from `State` `s` inner join `City` `c` on `s`.`StateId` = `c`.`StateId` inner join `Country` `t` on `t`.`CountryId` = `s`.`CountryId`
    where `c`.`CityId` = cty;
end;
