CREATE PROCEDURE manual.sp_deleteversions(IN fileid VARCHAR(50), IN filename VARCHAR(255), IN parentid VARCHAR(50))
  BEGIN
	delete from `file` where file_filename = filename and file_parentid = parentid and file_id != fileid;
END;
