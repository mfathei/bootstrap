CREATE VIEW manual.files_view AS
  SELECT
    `t1`.`file_id`                                                     AS `file_id`,
    `t1`.`file_parentid`                                               AS `file_parent_id`,
    `t1`.`file_filename`                                               AS `file_name`,
    `t1`.`file_extension`                                              AS `file_extension`,
    `t1`.`file_createdate`                                             AS `file_lastupdated`,
    (SELECT concat(`auth`.`user`.`first_name`, ' ', `auth`.`user`.`last_name`)
     FROM `auth`.`user`
     WHERE (`auth`.`user`.`user_id` = `t1`.`file_uploadby`))           AS `file_uploadby`,
    (SELECT count(0)
     FROM `manual`.`file`
     WHERE ((lower(`manual`.`file`.`file_filename`) = lower(`t1`.`file_filename`)) AND
            (`manual`.`file`.`file_parentid` = `t1`.`file_parentid`))) AS `file_version`
  FROM `manual`.`file` `t1`
  WHERE (`t1`.`file_type` = 'file');
