CREATE TRIGGER ABCanTrackV2.hist_spill_release_BINS
BEFORE INSERT ON ABCanTrackV2.hist_spill_release
FOR EACH ROW
  BEGIN
SET NEW.HistSpillReleaseId = MyUUID();
END;
