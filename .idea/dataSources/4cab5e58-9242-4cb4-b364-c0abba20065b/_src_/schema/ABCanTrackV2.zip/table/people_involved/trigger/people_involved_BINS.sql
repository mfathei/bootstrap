CREATE TRIGGER ABCanTrackV2.people_involved_BINS
BEFORE INSERT ON ABCanTrackV2.people_involved
FOR EACH ROW
  BEGIN
	SET NEW.PeopleInvolvedId = MyUUID();
	UPDATE last_uuid
	SET LastId	= NEW.PeopleInvolvedId
	WHERE TableName = 'people_involved';
END;
