CREATE TRIGGER ABCanTrackV2.restricted_work_BINS
BEFORE INSERT ON ABCanTrackV2.restricted_work
FOR EACH ROW
  BEGIN
SET NEW.RestrictedWorkId = MyUUID();
END;
