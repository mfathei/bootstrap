CREATE TRIGGER ABCanTrackV2.env_cond_parameter_BINS
BEFORE INSERT ON ABCanTrackV2.env_cond_parameter
FOR EACH ROW
  BEGIN
SET NEW.EnvCondParameterId = MyUUID();
END;
