CREATE TRIGGER ABCanTrackV2.hist_people_involved_BINS
BEFORE INSERT ON ABCanTrackV2.hist_people_involved
FOR EACH ROW
  BEGIN
SET NEW.HistPeopleInvolvedId = MyUUID();
END;
