CREATE TRIGGER ABCanTrackV2.hist_traffic_violation_BINS
BEFORE INSERT ON ABCanTrackV2.hist_traffic_violation
FOR EACH ROW
  BEGIN
SET NEW.HistTrafficViolationId = MyUUID();
END;
