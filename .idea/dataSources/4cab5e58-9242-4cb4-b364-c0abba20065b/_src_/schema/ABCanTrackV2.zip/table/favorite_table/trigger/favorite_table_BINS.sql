CREATE TRIGGER ABCanTrackV2.favorite_table_BINS
BEFORE INSERT ON ABCanTrackV2.favorite_table
FOR EACH ROW
  BEGIN
	SET NEW.FavoriteTableId = MyUUID();
	UPDATE last_uuid
	SET LastId	= NEW.FavoriteTableId
	WHERE TableName = 'favorite_table';
END;
