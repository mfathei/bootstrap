CREATE TRIGGER ABCanTrackV2.temp_template_BEFORE_INSERT
BEFORE INSERT ON ABCanTrackV2.temp_template
FOR EACH ROW
  BEGIN
SET NEW.TemplateId = MyUUID();
	UPDATE last_uuid
	SET LastId	= NEW.TemplateId
	WHERE TableName = 'temp_template';    
END;
