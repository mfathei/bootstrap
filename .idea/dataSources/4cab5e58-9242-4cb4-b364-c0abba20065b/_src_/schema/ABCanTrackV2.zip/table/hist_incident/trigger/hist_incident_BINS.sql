CREATE TRIGGER ABCanTrackV2.hist_incident_BINS
BEFORE INSERT ON ABCanTrackV2.hist_incident
FOR EACH ROW
  BEGIN
	SET NEW.HistIncidentId = MyUUID();
	UPDATE last_uuid
	SET LastId	= NEW.HistIncidentId
	WHERE TableName = 'hist_incident';
END;
