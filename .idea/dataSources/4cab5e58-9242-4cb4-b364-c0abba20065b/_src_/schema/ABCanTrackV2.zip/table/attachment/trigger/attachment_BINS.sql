CREATE TRIGGER ABCanTrackV2.attachment_BINS
BEFORE INSERT ON ABCanTrackV2.attachment
FOR EACH ROW
  BEGIN
SET new.AttachmentId = MyUUID();
END;
