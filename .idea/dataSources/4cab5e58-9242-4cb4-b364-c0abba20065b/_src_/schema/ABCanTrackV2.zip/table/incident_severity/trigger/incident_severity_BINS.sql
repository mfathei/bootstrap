CREATE TRIGGER ABCanTrackV2.incident_severity_BINS
BEFORE INSERT ON ABCanTrackV2.incident_severity
FOR EACH ROW
  BEGIN
SET NEW.IncidentSeverityId = MyUUID();
END;
