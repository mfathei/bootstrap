CREATE TRIGGER ABCanTrackV2.email_log_BINS
BEFORE INSERT ON ABCanTrackV2.email_log
FOR EACH ROW
  BEGIN
	SET new.EmailLogId = MyUUID();  
     set new.SentDate=CURRENT_TIMESTAMP;
	Update last_uuid
	SET LastId	= new.EmailLogId
	WHERE TableName = 'email_log';
    set @lst_uuid = new.EmailLogId;
END;
