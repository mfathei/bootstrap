CREATE TRIGGER ABCanTrackV2.contact_agency_BINS
BEFORE INSERT ON ABCanTrackV2.contact_agency
FOR EACH ROW
  BEGIN
SET NEW.ContactAgencyId = MyUUID();
END;
