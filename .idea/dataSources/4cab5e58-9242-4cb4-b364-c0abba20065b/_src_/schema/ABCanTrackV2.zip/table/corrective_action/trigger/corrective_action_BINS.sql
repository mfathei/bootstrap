CREATE TRIGGER ABCanTrackV2.corrective_action_BINS
BEFORE INSERT ON ABCanTrackV2.corrective_action
FOR EACH ROW
  BEGIN
	SET @session_corr_id =  MyUUID();
    SET NEW.CorrectiveActionId = @session_corr_id;
	UPDATE last_uuid    
	SET LastId	= NEW.CorrectiveActionId    
	WHERE TableName = 'corrective_action';
END;
