CREATE TRIGGER ABCanTrackV2.history_operation_BINS
BEFORE INSERT ON ABCanTrackV2.history_operation
FOR EACH ROW
  BEGIN
  SET NEW.HistoryOperationId = MyUUID();
END;
