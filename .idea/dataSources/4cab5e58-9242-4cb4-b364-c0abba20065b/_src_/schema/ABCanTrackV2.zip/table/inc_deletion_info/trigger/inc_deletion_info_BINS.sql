CREATE TRIGGER ABCanTrackV2.inc_deletion_info_BINS
BEFORE INSERT ON ABCanTrackV2.inc_deletion_info
FOR EACH ROW
  BEGIN
SET NEW.IncDeletionInfoId = MyUUID();
END;
