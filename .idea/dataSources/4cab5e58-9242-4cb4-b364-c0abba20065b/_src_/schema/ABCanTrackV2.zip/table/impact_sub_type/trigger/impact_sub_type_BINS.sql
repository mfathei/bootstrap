CREATE TRIGGER ABCanTrackV2.impact_sub_type_BINS
BEFORE INSERT ON ABCanTrackV2.impact_sub_type
FOR EACH ROW
  BEGIN
SET NEW.ImpactSubTypeId = MyUUID();
END;
