CREATE TRIGGER ABCanTrackV2.duration_unit_BINS
BEFORE INSERT ON ABCanTrackV2.duration_unit
FOR EACH ROW
  BEGIN
SET NEW.DurationUnitId = MyUUID();
END;
