CREATE TRIGGER ABCanTrackV2.hist_corrective_action_BINS
BEFORE INSERT ON ABCanTrackV2.hist_corrective_action
FOR EACH ROW
  BEGIN
SET NEW.HistCorrectiveActionId = MyUUID();
END;
