CREATE TRIGGER ABCanTrackV2.injury_recordable_BINS
BEFORE INSERT ON ABCanTrackV2.injury_recordable
FOR EACH ROW
  BEGIN
SET NEW.RecordableId = MyUUID();
END;
