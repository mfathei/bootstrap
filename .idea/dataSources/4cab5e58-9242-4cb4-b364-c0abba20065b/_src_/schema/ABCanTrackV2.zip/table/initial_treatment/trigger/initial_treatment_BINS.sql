CREATE TRIGGER ABCanTrackV2.initial_treatment_BINS
BEFORE INSERT ON ABCanTrackV2.initial_treatment
FOR EACH ROW
  BEGIN
SET NEW.InitialTreatmentId = MyUUID();
END;
