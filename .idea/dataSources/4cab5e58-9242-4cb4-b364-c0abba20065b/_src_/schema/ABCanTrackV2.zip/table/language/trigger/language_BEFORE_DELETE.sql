CREATE TRIGGER ABCanTrackV2.language_BEFORE_DELETE
BEFORE DELETE ON ABCanTrackV2.language
FOR EACH ROW
  BEGIN
	IF LOWER(OLD.LanguageCode) = 'en' THEN
		SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Error: You can't delete English Language(it is the default)!';
    END IF;
END
;
