CREATE TRIGGER ABCanTrackV2.spill_release_BINS
BEFORE INSERT ON ABCanTrackV2.spill_release
FOR EACH ROW
  BEGIN
	SET NEW.SpillReleaseId = MyUUID();
	UPDATE last_uuid
	SET LastId	= NEW.SpillReleaseId
	WHERE TableName = 'spill_release';
END;
