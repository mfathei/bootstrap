CREATE TRIGGER ABCanTrackV2.vehicle_damage_BINS
BEFORE INSERT ON ABCanTrackV2.vehicle_damage
FOR EACH ROW
  BEGIN
	SET NEW.VehicleDamageId = MyUUID();
	UPDATE last_uuid
	SET LastId	= NEW.VehicleDamageId
	WHERE TableName = 'vehicle_damage';
END;
