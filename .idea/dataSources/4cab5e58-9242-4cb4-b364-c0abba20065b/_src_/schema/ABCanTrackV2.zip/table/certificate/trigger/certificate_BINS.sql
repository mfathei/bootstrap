CREATE TRIGGER ABCanTrackV2.certificate_BINS
BEFORE INSERT ON ABCanTrackV2.certificate
FOR EACH ROW
  BEGIN
SET new.CertificateId = MyUUID();
END;
