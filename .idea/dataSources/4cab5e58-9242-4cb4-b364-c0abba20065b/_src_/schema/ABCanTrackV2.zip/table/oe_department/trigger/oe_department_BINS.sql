CREATE TRIGGER ABCanTrackV2.oe_department_BINS
BEFORE INSERT ON ABCanTrackV2.oe_department
FOR EACH ROW
  BEGIN
SET NEW.OEDepartmentId = MyUUID();
END;
