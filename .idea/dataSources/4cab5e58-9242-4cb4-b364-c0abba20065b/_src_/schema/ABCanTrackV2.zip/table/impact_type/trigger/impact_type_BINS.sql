CREATE TRIGGER ABCanTrackV2.impact_type_BINS
BEFORE INSERT ON ABCanTrackV2.impact_type
FOR EACH ROW
  BEGIN
SET NEW.ImpactTypeId = MyUUID();
UPDATE last_uuid
SET LastId	= NEW.ImpactTypeId
WHERE TableName = 'impact_type';
END;
