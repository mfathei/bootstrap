CREATE TRIGGER ABCanTrackV2.spill_release_source_BINS
BEFORE INSERT ON ABCanTrackV2.spill_release_source
FOR EACH ROW
  BEGIN
SET NEW.SourceId = MyUUID();
END;
