CREATE TRIGGER ABCanTrackV2.traffic_violation_BINS
BEFORE INSERT ON ABCanTrackV2.traffic_violation
FOR EACH ROW
  BEGIN
	SET NEW.TrafficViolationId = MyUUID();
	UPDATE last_uuid
	SET LastId	= NEW.TrafficViolationId
	WHERE TableName = 'traffic_violation';
END;
