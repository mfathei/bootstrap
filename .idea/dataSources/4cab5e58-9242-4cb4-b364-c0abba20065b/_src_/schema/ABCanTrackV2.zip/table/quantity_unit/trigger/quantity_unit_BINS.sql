CREATE TRIGGER ABCanTrackV2.quantity_unit_BINS
BEFORE INSERT ON ABCanTrackV2.quantity_unit
FOR EACH ROW
  BEGIN
SET NEW.QuantityUnitId = MyUUID();
END;
