CREATE TRIGGER ABCanTrackV2.impacts_ext_agency_BINS
BEFORE INSERT ON ABCanTrackV2.impacts_ext_agency
FOR EACH ROW
  BEGIN
SET NEW.ImpactsExtAgencyId = MyUUID();
END;
