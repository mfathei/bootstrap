CREATE TRIGGER ABCanTrackV2.email_template_BINS
BEFORE INSERT ON ABCanTrackV2.email_template
FOR EACH ROW
  BEGIN
SET new.TemplateId = MyUUID();
END;
