CREATE TRIGGER ABCanTrackV2.env_condition_BINS
BEFORE INSERT ON ABCanTrackV2.env_condition
FOR EACH ROW
  BEGIN
SET NEW.EnvConditionId = MyUUID();
UPDATE last_uuid
SET LastId	= NEW.EnvConditionId
WHERE TableName = 'env_condition';
END;
