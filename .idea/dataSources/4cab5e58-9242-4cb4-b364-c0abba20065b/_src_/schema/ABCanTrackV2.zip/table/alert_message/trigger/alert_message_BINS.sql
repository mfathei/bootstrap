CREATE TRIGGER ABCanTrackV2.alert_message_BINS
BEFORE INSERT ON ABCanTrackV2.alert_message
FOR EACH ROW
  BEGIN
SET new.AlertMessageId = MyUUID();
END;
