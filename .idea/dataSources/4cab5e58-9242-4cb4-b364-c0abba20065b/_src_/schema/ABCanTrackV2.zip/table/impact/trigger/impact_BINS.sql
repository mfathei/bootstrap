CREATE TRIGGER ABCanTrackV2.impact_BINS
BEFORE INSERT ON ABCanTrackV2.impact
FOR EACH ROW
  BEGIN
	SET NEW.ImpactId = MyUUID();
	UPDATE last_uuid
	SET LastId	= NEW.ImpactId
	WHERE TableName = 'impact';
END;
