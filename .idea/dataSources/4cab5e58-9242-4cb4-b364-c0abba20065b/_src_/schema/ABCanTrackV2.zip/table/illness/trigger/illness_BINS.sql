CREATE TRIGGER ABCanTrackV2.illness_BINS
BEFORE INSERT ON ABCanTrackV2.illness
FOR EACH ROW
  BEGIN
	SET NEW.IllnessId = MyUUID();
	UPDATE last_uuid
	SET LastId	= NEW.IllnessId
	WHERE TableName = 'illness';
END;
