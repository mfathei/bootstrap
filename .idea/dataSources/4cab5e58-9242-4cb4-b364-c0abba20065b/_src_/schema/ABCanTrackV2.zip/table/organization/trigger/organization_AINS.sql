CREATE TRIGGER ABCanTrackV2.organization_AINS
AFTER INSERT ON ABCanTrackV2.organization
FOR EACH ROW
  BEGIN
/*
this trigger inserts into following tables
-- 1. `ABCanTrackV2`.`org_alert_message`
2. `ABCanTrackV2`.`body_area`
3. `ABCanTrackV2`.`body_part`
4. `ABCanTrackV2`.`certificate`
5. `ABCanTrackV2`.`contact`
6. `ABCanTrackV2`.`contact_agency`
7. `ABCanTrackV2`.`contact_code`
8. `ABCanTrackV2`.`corr_act_status`
9. `ABCanTrackV2`.`duration_unit`
										-- loop
10.`ABCanTrackV2`.`env_condition`
11.`ABCanTrackV2`.`env_cond_parameter`
										-- end loop
12.`ABCanTrackV2`.`event_type`
13.`ABCanTrackV2`.`external_agency`
										-- loop
14.`ABCanTrackV2`.`impact_type` 
15.`ABCanTrackV2`.`impact_sub_type`
										-- end loop
16.`ABCanTrackV2`.`incident_severity`
17.`ABCanTrackV2`.`initial_treatment`
18.`ABCanTrackV2`.`injury_recordable`
19.`ABCanTrackV2`.`injury_type`
20.`ABCanTrackV2`.`inv_source`
21.`ABCanTrackV2`.`inv_status`
										-- loop
22.`ABCanTrackV2`.`observation_analysis` 
23.`ABCanTrackV2`.`observation_analysis_param`
										-- end loop
24.`ABCanTrackV2`.`oe_department`
25.`ABCanTrackV2`.`org_field`
26.`ABCanTrackV2`.`priority`
27.`ABCanTrackV2`.`quantity_unit`
28.`ABCanTrackV2`.`restricted_work`
29.`ABCanTrackV2`.`risk_of_recurrence`
										-- loop
30.`ABCanTrackV2`.`root_cause`
31.`ABCanTrackV2`.`root_cause_param`
										-- end loop
32.`ABCanTrackV2`.`spill_release_source`
33.`ABCanTrackV2`.`symptoms`
34.`ABCanTrackV2`.`vehicle_type`
35.`ABCanTrackV2`.`email_template`
*/
DECLARE $Min, $Max, $CurId VARCHAR(100);
DECLARE $Code1 VARCHAR(255);
INSERT INTO `ABCanTrackV2`.`body_area`
(
    `body_area`.`FieldCode`,
    `body_area`.`LanguageId`,
    `body_area`.`BodyAreaName`,
    `body_area`.`OrgId`,
    `body_area`.`Order`,
    `body_area`.`LastUpdateDate`,
    `body_area`.`EditingBy`,
    `body_area`.`Hide`
)
select
    `body_area`.`FieldCode`,
    `body_area`.`LanguageId`,
    `body_area`.`BodyAreaName`,
    New.`OrgId`,
    `body_area`.`Order`,
    Current_timestamp(),
    `body_area`.`EditingBy`,
    `body_area`.`Hide`
from `ABCanTrackV2`.`body_area` where OrgId is null AND LanguageId = NEW.`LanguageId`;
-- *************************************************************	
	
INSERT INTO `ABCanTrackV2`.`body_part`
(
    `body_part`.`FieldCode`,
    `body_part`.`LanguageId`,
    `body_part`.`BodyPartName`,
    `body_part`.`OrgId`,
    `body_part`.`Order`,
    `body_part`.`LastUpdateDate`,
    `body_part`.`EditingBy`,
    `body_part`.`Hide`
)
select
    `body_part`.`FieldCode`,
    `body_part`.`LanguageId`,
    `body_part`.`BodyPartName`,
    NEW.`OrgId`,
    `body_part`.`Order`,
    Current_timestamp(),
    `body_part`.`EditingBy`,
    `body_part`.`Hide`
from `ABCanTrackV2`.`body_part` where OrgId is null AND LanguageId = NEW.`LanguageId`;
-- *************************************************************
INSERT INTO `ABCanTrackV2`.`certificate`
(
    `certificate`.`FieldCode`,
    `certificate`.`LanguageId`,
    `certificate`.`CertificateName`,
    `certificate`.`OrgId`,
    `certificate`.`Order`,
    `certificate`.`LastUpdateDate`,
    `certificate`.`EditingBy`,
    `certificate`.`Hide`
)
select 
    `certificate`.`FieldCode`,
    `certificate`.`LanguageId`,
    `certificate`.`CertificateName`,
    NEW.`OrgId`,
    `certificate`.`Order`,
    Current_timestamp(),
    `certificate`.`EditingBy`,
    `certificate`.`Hide`
from `ABCanTrackV2`.`certificate` where OrgId is null AND LanguageId = NEW.`LanguageId`;
-- *************************************************************
INSERT INTO `ABCanTrackV2`.`contact`
(	
    `contact`.`FieldCode`,
    `contact`.`LanguageId`,
    `contact`.`ContactName`,
    `contact`.`OrgId`
)
SELECT
    `contact`.`FieldCode`,
    `contact`.`LanguageId`,
    `contact`.`ContactName`,
    NEW.`OrgId`
FROM `ABCanTrackV2`.`contact` where OrgId is null AND LanguageId = NEW.`LanguageId`;
-- *************************************************************
INSERT INTO `ABCanTrackV2`.`contact_agency`
(	
    `contact_agency`.`FieldCode`,
    `contact_agency`.`LanguageId`,
    `contact_agency`.`ContactAgencyName`,
    `contact_agency`.`Description`,
    `contact_agency`.`OrgId`,
    `contact_agency`.`Order`,
    `contact_agency`.`LastUpdateDate`,
    `contact_agency`.`EditingBy`,
    `contact_agency`.`Hide`
)
SELECT	
    `contact_agency`.`FieldCode`,
    `contact_agency`.`LanguageId`,
    `contact_agency`.`ContactAgencyName`,
    `contact_agency`.`Description`,
    NEW.`OrgId`,
    `contact_agency`.`Order`,
    Current_timestamp(),
    `contact_agency`.`EditingBy`,
    `contact_agency`.`Hide`
FROM `ABCanTrackV2`.`contact_agency` WHERE OrgId is null AND LanguageId = NEW.`LanguageId`;
-- *************************************************************
INSERT INTO `ABCanTrackV2`.`contact_code`
(
    `contact_code`.`FieldCode`,
    `contact_code`.`LanguageId`,
    `contact_code`.`ContactCodeName`,
    `contact_code`.`OrgId`,
    `contact_code`.`Order`,
    `contact_code`.`LastUpdateDate`,
    `contact_code`.`EditingBy`,
    `contact_code`.`Hide`
)
SELECT
    `contact_code`.`FieldCode`,
    `contact_code`.`LanguageId`,
    `contact_code`.`ContactCodeName`,
    NEW.`OrgId`,
    `contact_code`.`Order`,
    Current_timestamp(),
    `contact_code`.`EditingBy`,
    `contact_code`.`Hide`
FROM `ABCanTrackV2`.`contact_code` WHERE OrgId is null AND LanguageId = NEW.`LanguageId`;
-- *************************************************************
INSERT INTO `ABCanTrackV2`.`corr_act_status`
(
    `corr_act_status`.`FieldCode`,
    `corr_act_status`.`LanguageId`,
    `corr_act_status`.`CorrActStatusName`,
    `corr_act_status`.`CorrActStatusCode`,
    `corr_act_status`.`Description`,
    `corr_act_status`.`OrgId`,
    `corr_act_status`.`Order`,
    `corr_act_status`.`LastUpdateDate`,
    `corr_act_status`.`EditingBy`,
    `corr_act_status`.`Hide`
)
SELECT 
    `corr_act_status`.`FieldCode`,
    `corr_act_status`.`LanguageId`,
    `corr_act_status`.`CorrActStatusName`,
    `corr_act_status`.`CorrActStatusCode`,
    `corr_act_status`.`Description`,
    NEW.`OrgId`,
    `corr_act_status`.`Order`,
    Current_timestamp(),
    `corr_act_status`.`EditingBy`,
    `corr_act_status`.`Hide`
FROM `ABCanTrackV2`.`corr_act_status` WHERE OrgId is null AND LanguageId = NEW.`LanguageId`;
-- *************************************************************
INSERT INTO `ABCanTrackV2`.`duration_unit`
(
    `duration_unit`.`FieldCode`,
    `duration_unit`.`LanguageId`,
    `duration_unit`.`DurationUnitName`,
    `duration_unit`.`Order`,
    `duration_unit`.`OrgId`,
    `duration_unit`.`LastUpdateDate`,
    `duration_unit`.`EditingBy`,
    `duration_unit`.`Hide`
)
SELECT 
    `duration_unit`.`FieldCode`,
    `duration_unit`.`LanguageId`,
    `duration_unit`.`DurationUnitName`,
    `duration_unit`.`Order`,
    NEW.`OrgId`,
    Current_timestamp(),
    `duration_unit`.`EditingBy`,
    `duration_unit`.`Hide`
FROM `ABCanTrackV2`.`duration_unit` Where OrgId is null AND LanguageId = NEW.`LanguageId`;
-- *************************************************************
INSERT INTO `ABCanTrackV2`.`email_template`
(    
    `email_template`.`FieldCode`,
    `email_template`.`LanguageId`,
    `email_template`.`OrgId`,
    `email_template`.`EmailTypeId`,
    `email_template`.`Title`,
    `email_template`.`Subject`,
    `email_template`.`Body`,
    `email_template`.`UpdatedDate`,
    `email_template`.`IsActive`,
    `email_template`.`Order`
)
SELECT 
    `email_template`.`FieldCode`,
    `email_template`.`LanguageId`,
	 NEW.`OrgId`,
    `email_template`.`EmailTypeId`,
    `email_template`.`Title`,
    `email_template`.`Subject`,
    `email_template`.`Body`,
    `email_template`.`UpdatedDate`,
    `email_template`.`IsActive`,
    `email_template`.`Order`
FROM `ABCanTrackV2`.`email_template` WHERE `OrgId` IS NULL AND LanguageId = NEW.`LanguageId`;
-- *************************************************************
CALL ins_org_env_conditions(NEW.`OrgId`, NEW.`LanguageId`);
-- end env_condition and env_cond_parameter Loop --
-- *************************************************************
INSERT INTO `ABCanTrackV2`.`event_type`
(
    `event_type`.`FieldCode`,
    `event_type`.`LanguageId`,
    `event_type`.`EventTypeName`,
    `event_type`.`OrgId`,
    `event_type`.`Order`,
    `event_type`.`LastUpdateDate`,
    `event_type`.`EditingBy`,
    `event_type`.`Hide`
)
SELECT
    `event_type`.`FieldCode`,
    `event_type`.`LanguageId`,
    `event_type`.`EventTypeName`,
    NEW.`OrgId`,
    `event_type`.`Order`,
    Current_timestamp(),
    `event_type`.`EditingBy`,
    `event_type`.`Hide`
FROM `ABCanTrackV2`.`event_type` Where OrgId is null AND LanguageId = NEW.`LanguageId`;
-- *************************************************************
INSERT INTO `ABCanTrackV2`.`external_agency`
(
    `external_agency`.`FieldCode`,
    `external_agency`.`LanguageId`,
    `external_agency`.`ExtAgencyName`,
    `external_agency`.`OrgId`,
    `external_agency`.`Description`,
    `external_agency`.`Order`,
    `external_agency`.`LastUpdateDate`,
    `external_agency`.`EditingBy`,
    `external_agency`.`Hide`
)
SELECT 
    `external_agency`.`FieldCode`,
    `external_agency`.`LanguageId`,
    `external_agency`.`ExtAgencyName`,
    NEW.`OrgId`,
    `external_agency`.`Description`,
    `external_agency`.`Order`,
    Current_timestamp(),
    `external_agency`.`EditingBy`,
    `external_agency`.`Hide`
FROM `ABCanTrackV2`.`external_agency` Where OrgId is null AND LanguageId = NEW.`LanguageId`;
-- *************************************************************
-- Loop for insert into impact_type and impact_sub_type --
SET $Min = (select min(ImpactTypeId) from impact_type where OrgId is null AND LanguageId = NEW.`LanguageId`);
SET $Max = (select max(ImpactTypeId) from impact_type where OrgId is null AND LanguageId = NEW.`LanguageId`);
ImpactLoop: While $Min <= $Max
DO
INSERT INTO `ABCanTrackV2`.`impact_type` 
(
    `impact_type`.`FieldCode`,
    `impact_type`.`LanguageId`,
    `impact_type`.`ImpactTypeName`,
    `impact_type`.`ImpactTypeCode`,
    `impact_type`.`IsPotential`,
    `impact_type`.`OrgId`,
    `impact_type`.`Order`,
    `impact_type`.`LastUpdateDate`,
    `impact_type`.`EditingBy`,
    `impact_type`.`Hide`
)
SELECT
    `impact_type`.`FieldCode`,
    `impact_type`.`LanguageId`,
    `impact_type`.`ImpactTypeName`,
    `impact_type`.`ImpactTypeCode`,
    `impact_type`.`IsPotential`,
    NEW.`OrgId`,
    `impact_type`.`Order`,
    Current_timestamp(),
    `impact_type`.`EditingBy`,
    `impact_type`.`Hide`
FROM `ABCanTrackV2`.`impact_type` where ImpactTypeId = $Min AND LanguageId = NEW.`LanguageId`;
SET $CurId = (SELECT max(ImpactTypeId) from impact_type where OrgId = NEW.OrgId AND LanguageId = NEW.`LanguageId`);
INSERT INTO `ABCanTrackV2`.`impact_sub_type`
(    
    `impact_sub_type`.`FieldCode`,
    `impact_sub_type`.`LanguageId`,
	`impact_sub_type`.`ImpactSubTypeName`,
    `impact_sub_type`.`ImpactTypeId`,
    `impact_sub_type`.`Order`,
    `impact_sub_type`.`LastUpdateDate`,
    `impact_sub_type`.`EditingBy`,
    `impact_sub_type`.`Hide`
)
SELECT 
    `impact_sub_type`.`FieldCode`,
    `impact_sub_type`.`LanguageId`,
    `impact_sub_type`.`ImpactSubTypeName`,
    $CurId,
    `impact_sub_type`.`Order`,
    Current_timestamp(),
    `impact_sub_type`.`EditingBy`,
    `impact_sub_type`.`Hide`
FROM `ABCanTrackV2`.`impact_sub_type` where ImpactTypeId = $Min AND LanguageId = NEW.`LanguageId`;
IF $Min = $Max then
LEAVE ImpactLoop;
Else
SET $Min = (select min(ImpactTypeId) from impact_type where OrgId is null and ImpactTypeId > $Min AND LanguageId = NEW.`LanguageId`);
END IF;
END While;
-- end impact_type and impact_sub_type Loop --
-- *************************************************************
INSERT INTO `ABCanTrackV2`.`incident_severity`
( 
    `incident_severity`.`FieldCode`,
    `incident_severity`.`LanguageId`,
    `incident_severity`.`IncidentSeverityName`,
    `incident_severity`.`OrgId`,
    `incident_severity`.`Order`,
    `incident_severity`.`LastUpdateDate`,
    `incident_severity`.`EditingBy`,
    `incident_severity`.`Hide`
)
SELECT 
    `incident_severity`.`FieldCode`,
    `incident_severity`.`LanguageId`,
    `incident_severity`.`IncidentSeverityName`,
    NEW.`OrgId`,
    `incident_severity`.`Order`,
    Current_timestamp(),
    `incident_severity`.`EditingBy`,
    `incident_severity`.`Hide`
FROM `ABCanTrackV2`.`incident_severity` Where OrgId is null AND LanguageId = NEW.`LanguageId`;
-- *************************************************************
INSERT INTO `ABCanTrackV2`.`initial_treatment`
(
    `initial_treatment`.`FieldCode`,
    `initial_treatment`.`LanguageId`,
    `initial_treatment`.`InitialTreatmentName`,
    `initial_treatment`.`OrgId`,
    `initial_treatment`.`Order`,
    `initial_treatment`.`LastUpdateDate`,
    `initial_treatment`.`EditingBy`,
    `initial_treatment`.`Hide`
)
SELECT
    `initial_treatment`.`FieldCode`,
    `initial_treatment`.`LanguageId`,
    `initial_treatment`.`InitialTreatmentName`,
    NEW.`OrgId`,
    `initial_treatment`.`Order`,
    Current_timestamp(),
    `initial_treatment`.`EditingBy`,
    `initial_treatment`.`Hide`
FROM `ABCanTrackV2`.`initial_treatment` Where OrgId is null AND LanguageId = NEW.`LanguageId`;
-- *************************************************************
INSERT INTO `ABCanTrackV2`.`injury_recordable`
(
    `injury_recordable`.`FieldCode`,
    `injury_recordable`.`LanguageId`,
    `injury_recordable`.`RecordableName`,
    `injury_recordable`.`OrgId`,
    `injury_recordable`.`Order`,
    `injury_recordable`.`LastUpdateDate`,
    `injury_recordable`.`EditingBy`,
    `injury_recordable`.`Hide`
)
SELECT
    `injury_recordable`.`FieldCode`,
    `injury_recordable`.`LanguageId`,
    `injury_recordable`.`RecordableName`,
    NEW.`OrgId`,
    `injury_recordable`.`Order`,
    Current_timestamp(),
    `injury_recordable`.`EditingBy`,
    `injury_recordable`.`Hide`
FROM `ABCanTrackV2`.`injury_recordable` Where OrgId is null AND LanguageId = NEW.`LanguageId`;
-- *************************************************************
INSERT INTO `ABCanTrackV2`.`injury_type`
(
    `injury_type`.`FieldCode`,
    `injury_type`.`LanguageId`,
    `injury_type`.`InjuryTypeName`,
    `injury_type`.`OrgId`,
    `injury_type`.`Order`,
    `injury_type`.`LastUpdateDate`,
    `injury_type`.`EditingBy`,
    `injury_type`.`Hide`
)
SELECT 
    `injury_type`.`FieldCode`,
    `injury_type`.`LanguageId`,
    `injury_type`.`InjuryTypeName`,
    NEW.`OrgId`,
    `injury_type`.`Order`,
    Current_timestamp(),
    `injury_type`.`EditingBy`,
    `injury_type`.`Hide`
FROM `ABCanTrackV2`.`injury_type` Where OrgId is null AND LanguageId = NEW.`LanguageId`;
-- *************************************************************
INSERT INTO `ABCanTrackV2`.`inv_source`
(
    `inv_source`.`FieldCode`,
    `inv_source`.`LanguageId`,
    `inv_source`.`InvSourceName`,
    `inv_source`.`OrgId`,
    `inv_source`.`Order`,
    `inv_source`.`LastUpdateDate`,
    `inv_source`.`EditingBy`,
    `inv_source`.`Hide`
)
SELECT
    `inv_source`.`FieldCode`,
    `inv_source`.`LanguageId`,
    `inv_source`.`InvSourceName`,
    NEW.`OrgId`,
    `inv_source`.`Order`,
    Current_timestamp(),
    `inv_source`.`EditingBy`,
    `inv_source`.`Hide`
FROM `ABCanTrackV2`.`inv_source` Where OrgId is null AND LanguageId = NEW.`LanguageId`;
-- *************************************************************
INSERT INTO `ABCanTrackV2`.`inv_status`
(
    `inv_status`.`FieldCode`,
    `inv_status`.`LanguageId`,
    `inv_status`.`InvStatusName`,
    `inv_status`.`InvStatusCode`,
    `inv_status`.`Description`,
    `inv_status`.`OrgId`,
    `inv_status`.`Order`,
    `inv_status`.`LastUpdateDate`,
    `inv_status`.`EditingBy`,
    `inv_status`.`Hide`
)
SELECT
    `inv_status`.`FieldCode`,
    `inv_status`.`LanguageId`,
    `inv_status`.`InvStatusName`,
    `inv_status`.`InvStatusCode`,
    `inv_status`.`Description`,
    NEW.`OrgId`,
    `inv_status`.`Order`,
    Current_timestamp(),
    `inv_status`.`EditingBy`,
    `inv_status`.`Hide`
FROM `ABCanTrackV2`.`inv_status` Where OrgId is null AND LanguageId = NEW.`LanguageId`;
-- *************************************************************
/**
-- Loop for insert into observation_analysis and observation_analysis_param --
SET $Min = (select min(ObservationAndAnalysisId) from observation_analysis where OrgId is null AND LanguageId = NEW.`LanguageId`);
SET $Max = (select max(ObservationAndAnalysisId) from observation_analysis where OrgId is null AND LanguageId = NEW.`LanguageId`);
ObserLoop: While $Min <= $Max
DO
INSERT INTO `ABCanTrackV2`.`observation_analysis` 
(
    `observation_analysis`.`FieldCode`,
    `observation_analysis`.`LanguageId`,
    `observation_analysis`.`ObservationAndAnalysisCode`,
    `observation_analysis`.`ObservationAndAnalysisName`,
    `observation_analysis`.`ObservationAndAnalysisDetails`,
    `observation_analysis`.`OrgId`,
    `observation_analysis`.`Order`,
    `observation_analysis`.`LastUpdateDate`,
    `observation_analysis`.`EditingBy`,
    `observation_analysis`.`Hide`
)
SELECT
    `observation_analysis`.`FieldCode`,
    `observation_analysis`.`LanguageId`,
    `observation_analysis`.`ObservationAndAnalysisCode`,
    `observation_analysis`.`ObservationAndAnalysisName`,
    `observation_analysis`.`ObservationAndAnalysisDetails`,
    NEW.`OrgId`,
    `observation_analysis`.`Order`,
    Current_timestamp(),
    `observation_analysis`.`EditingBy`,
    `observation_analysis`.`Hide`
FROM `ABCanTrackV2`.`observation_analysis` Where ObservationAndAnalysisId = $Min AND LanguageId = NEW.`LanguageId`;
SET $CurId = (SELECT LastId from last_uuid where TableName = 'observation_analysis');
SET $Code1 = (select ObservationAndAnalysisCode from `ABCanTrackV2`.observation_analysis where OrgId is null AND LanguageId = NEW.`LanguageId` AND ObservationAndAnalysisId = $Min );
-- CALL `ABCanTrackV2`.`InsertOrgObserAnaParam`($Code1,NEW.`LanguageId`,$Min,NEW.`OrgId`);
CALL `InsertObserAnaParamTrigger44`($Code1,NEW.`OrgId`,NEW.`LanguageId`,$Min);
IF $Min = $Max then
LEAVE ObserLoop;
Else
SET $Min = (select min(ObservationAndAnalysisId) from observation_analysis where OrgId is null AND LanguageId = NEW.`LanguageId` and ObservationAndAnalysisId > $Min);
END IF;
END While;
-- end observation_analysis and observation_analysis_param Loop --
**/
CALL `CommonDB`.`ins_org_observations`(NEW.`OrgId`,NEW.`LanguageId`);
-- *************************************************************
INSERT INTO `ABCanTrackV2`.`oe_department`
(
    `oe_department`.`FieldCode`,
    `oe_department`.`LanguageId`,
    `oe_department`.`Province`,
    `oe_department`.`OEDepartmentName`,
    `oe_department`.`Address`,
    `oe_department`.`WebSite`,
    `oe_department`.`Phone`,
    `oe_department`.`Fax`,
    `oe_department`.`Order`,
    `oe_department`.`OrgId`,
    `oe_department`.`HelpMeName`,
    `oe_department`.`HelpMeDescription`,
    `oe_department`.`LastUpdateDate`,
    `oe_department`.`EditingBy`,
    `oe_department`.`Hide`
)
SELECT
    `oe_department`.`FieldCode`,
    `oe_department`.`LanguageId`,
    `oe_department`.`Province`,
    `oe_department`.`OEDepartmentName`,
    `oe_department`.`Address`,
    `oe_department`.`WebSite`,
    `oe_department`.`Phone`,
    `oe_department`.`Fax`,
    `oe_department`.`Order`,
    NEW.`OrgId`,
    `oe_department`.`HelpMeName`,
    `oe_department`.`HelpMeDescription`,
    Current_timestamp(),
    `oe_department`.`EditingBy`,
    `oe_department`.`Hide`
FROM `ABCanTrackV2`.`oe_department` Where OrgId is null AND LanguageId = NEW.`LanguageId`;
-- *************************************************************
INSERT INTO `ABCanTrackV2`.`org_field`
(
	`org_field`.`OrgId`,
    `org_field`.`FieldId`,
    `org_field`.`FieldLabel`,
    `org_field`.`HelpMeName`,
    `org_field`.`HelpMeDescription`,
    `org_field`.`IsMandatory`,
    `org_field`.`IsHidden`
)
SELECT
	NEW.`OrgId` AS `OrgId`,
	`field`.`FieldId` AS `FieldId`,
    `field`.`DefaultFieldLabel` AS `FieldLabel`,
    `field`.`DefaultHelpMeName` AS `HelpMeName`,
    `field`.`DefaultHelpMeDescription` AS `HelpMeDescription`,
    `field`.`IsMandatory` AS `IsMandatory`,
    `field`.`IsHidden` AS `IsHidden`
FROM `ABCanTrackV2`.`field` WHERE `OrgId` IS NULL  AND IsCustom=0  AND `LanguageId` = NEW.`LanguageId` ;
-- *************************************************************
INSERT INTO `ABCanTrackV2`.`priority`
(
    `priority`.`FieldCode`,
    `priority`.`LanguageId`,
    `priority`.`PriorityName`,
    `priority`.`OrgId`,
    `priority`.`Order`,
    `priority`.`LastUpdateDate`,
    `priority`.`EditingBy`,
    `priority`.`Hide`
)
SELECT
    `priority`.`FieldCode`,
    `priority`.`LanguageId`,
    `priority`.`PriorityName`,
    NEW.`OrgId`,
    `priority`.`Order`,
    Current_timestamp(),
    `priority`.`EditingBy`,
    `priority`.`Hide`
FROM `ABCanTrackV2`.`priority` Where OrgId is null AND LanguageId = NEW.`LanguageId`;
-- *************************************************************
INSERT INTO `ABCanTrackV2`.`quantity_unit`
(
    `quantity_unit`.`FieldCode`,
    `quantity_unit`.`LanguageId`,
    `quantity_unit`.`QuantityUnitName`,
    `quantity_unit`.`Order`,
    `quantity_unit`.`OrgId`,
    `quantity_unit`.`LastUpdateDate`,
    `quantity_unit`.`EditingBy`,
    `quantity_unit`.`Hide`
)
SELECT
    `quantity_unit`.`FieldCode`,
    `quantity_unit`.`LanguageId`,
    `quantity_unit`.`QuantityUnitName`,
    `quantity_unit`.`Order`,
    NEW.`OrgId`,
    Current_timestamp(),
    `quantity_unit`.`EditingBy`,
    `quantity_unit`.`Hide`
FROM `ABCanTrackV2`.`quantity_unit` Where OrgId is null AND LanguageId = NEW.`LanguageId`;
-- *************************************************************
INSERT INTO `ABCanTrackV2`.`restricted_work`
(
    `restricted_work`.`FieldCode`,
    `restricted_work`.`LanguageId`,
    `restricted_work`.`RestrictedWorkName`,
    `restricted_work`.`OrgId`,
    `restricted_work`.`Order`,
    `restricted_work`.`LastUpdateDate`,
    `restricted_work`.`EditingBy`,
    `restricted_work`.`Hide`
)
SELECT
    `restricted_work`.`FieldCode`,
    `restricted_work`.`LanguageId`,
    `restricted_work`.`RestrictedWorkName`,
    NEW.`OrgId`,
    `restricted_work`.`Order`,
    Current_timestamp(),
    `restricted_work`.`EditingBy`,
    `restricted_work`.`Hide`
FROM `ABCanTrackV2`.`restricted_work` Where OrgId is null AND LanguageId = NEW.`LanguageId`;
-- *************************************************************
INSERT INTO `ABCanTrackV2`.`risk_of_recurrence`
(
    `risk_of_recurrence`.`FieldCode`,
    `risk_of_recurrence`.`LanguageId`,
    `risk_of_recurrence`.`RiskOfRecurrenceName`,
    `risk_of_recurrence`.`OrgId`,
    `risk_of_recurrence`.`Order`,
    `risk_of_recurrence`.`LastUpdateDate`,
    `risk_of_recurrence`.`EditingBy`,
    `risk_of_recurrence`.`Hide`
)
SELECT 
    `risk_of_recurrence`.`FieldCode`,
    `risk_of_recurrence`.`LanguageId`,
    `risk_of_recurrence`.`RiskOfRecurrenceName`,
    NEW.`OrgId`,
    `risk_of_recurrence`.`Order`,
    Current_timestamp(),
    `risk_of_recurrence`.`EditingBy`,
    `risk_of_recurrence`.`Hide`
FROM `ABCanTrackV2`.`risk_of_recurrence` Where OrgId is null AND LanguageId = NEW.`LanguageId`;
-- *************************************************************
-- Loop for insert into root_cause and root_cause_param --
SET $Min = (select min(RootCauseId) from root_cause where OrgId is null AND LanguageId = NEW.`LanguageId`);
SET $Max = (select max(RootCauseId) from root_cause where OrgId is null AND LanguageId = NEW.`LanguageId`);
RootCauseLoop: While $Min <= $Max
DO
INSERT INTO `ABCanTrackV2`.`root_cause`
(
    `root_cause`.`FieldCode`,
    `root_cause`.`LanguageId`,
    `root_cause`.`RootCauseName`,
    `root_cause`.`OrgId`,
    `root_cause`.`Order`,
    `root_cause`.`LastUpdateDate`,
    `root_cause`.`EditingBy`,
    `root_cause`.`Hide`
)
SELECT
    `root_cause`.`FieldCode`,
    `root_cause`.`LanguageId`,
    `root_cause`.`RootCauseName`,
    NEW.`OrgId`,
    `root_cause`.`Order`,
    Current_timestamp(),
    `root_cause`.`EditingBy`,
    `root_cause`.`Hide`
FROM `ABCanTrackV2`.`root_cause` Where RootCauseId = $Min AND LanguageId = NEW.`LanguageId`; 
SET $CurId = (SELECT max(RootCauseId) from root_cause where OrgId = NEW.OrgId AND LanguageId = NEW.`LanguageId`);
 
 INSERT INTO `ABCanTrackV2`.`root_cause_param`
 (
    `root_cause_param`.`FieldCode`,
    `root_cause_param`.`LanguageId`,
    `root_cause_param`.`RootCauseParamName`,
    `root_cause_param`.`RootCauseId`,
    `root_cause_param`.`RootCauseParamDescription`,
    `root_cause_param`.`Order`,
    `root_cause_param`.`LastUpdateDate`,
    `root_cause_param`.`EditingBy`,
    `root_cause_param`.`Hide`
)
 SELECT
    `root_cause_param`.`FieldCode`,
    `root_cause_param`.`LanguageId`,
    `root_cause_param`.`RootCauseParamName`,
    $CurId,
    `root_cause_param`.`RootCauseParamDescription`,
    `root_cause_param`.`Order`,
    Current_timestamp(),
    `root_cause_param`.`EditingBy`,
    `root_cause_param`.`Hide`
FROM `ABCanTrackV2`.`root_cause_param`  where RootCauseId = $Min AND LanguageId = NEW.`LanguageId`;
IF $Min = $Max then
LEAVE RootCauseLoop;
Else
SET $Min = (select min(RootCauseId) from root_cause where OrgId is null and RootCauseId > $Min AND LanguageId = NEW.`LanguageId`);
END IF;
END While;
-- end root_cause and root_cause_param Loop --
-- *************************************************************
INSERT INTO `ABCanTrackV2`.`spill_release_source`
(
    `spill_release_source`.`FieldCode`,
    `spill_release_source`.`LanguageId`,
    `spill_release_source`.`SourceName`,
    `spill_release_source`.`Description`,
    `spill_release_source`.`OrgId`,
    `spill_release_source`.`Order`,
    `spill_release_source`.`LastUpdateDate`,
    `spill_release_source`.`EditingBy`,
    `spill_release_source`.`Hide`
)
SELECT
    `spill_release_source`.`FieldCode`,
    `spill_release_source`.`LanguageId`,
    `spill_release_source`.`SourceName`,
    `spill_release_source`.`Description`,
    NEW.`OrgId`,
    `spill_release_source`.`Order`,
     Current_timestamp(),
    `spill_release_source`.`EditingBy`,
    `spill_release_source`.`Hide`
FROM `ABCanTrackV2`.`spill_release_source` Where OrgId is null AND LanguageId = NEW.`LanguageId`;
-- *************************************************************
INSERT INTO `ABCanTrackV2`.`symptoms`
(
    `symptoms`.`FieldCode`,
    `symptoms`.`LanguageId`,
    `symptoms`.`Description`,
    `symptoms`.`AdditionalDetails`,
    `symptoms`.`OrgId`,
    `symptoms`.`Order`,
    `symptoms`.`LastUpdateDate`,
    `symptoms`.`EditingBy`,
    `symptoms`.`Hide`
)
SELECT
    `symptoms`.`FieldCode`,
    `symptoms`.`LanguageId`,
    `symptoms`.`Description`,
    `symptoms`.`AdditionalDetails`,
    NEW.`OrgId`,
    `symptoms`.`Order`,
    Current_timestamp(),
    `symptoms`.`EditingBy`,
    `symptoms`.`Hide`
FROM `ABCanTrackV2`.`symptoms` Where OrgId is null AND LanguageId = NEW.`LanguageId`;
-- *************************************************************
INSERT INTO `ABCanTrackV2`.`vehicle_type`
(
    `vehicle_type`.`FieldCode`,
    `vehicle_type`.`LanguageId`,
    `vehicle_type`.`VehicleTypeName`,
    `vehicle_type`.`AdditionalDetails`,
    `vehicle_type`.`OrgId`,
    `vehicle_type`.`Order`,
    `vehicle_type`.`LastUpdateDate`,
    `vehicle_type`.`EditingBy`,
    `vehicle_type`.`Hide`
)
SELECT
    `vehicle_type`.`FieldCode`,
    `vehicle_type`.`LanguageId`,
    `vehicle_type`.`VehicleTypeName`,
    `vehicle_type`.`AdditionalDetails`,
    NEW.`OrgId`,
    `vehicle_type`.`Order`,
    Current_timestamp(),
    `vehicle_type`.`EditingBy`,
    `vehicle_type`.`Hide`
FROM `ABCanTrackV2`.`vehicle_type` Where `OrgId` is null AND LanguageId = NEW.`LanguageId`;
-- ------------------------------------------------------------
INSERT INTO `ABCanTrackV2`.`sp_rel_agency`
(
	`sp_rel_agency`.`SpRelAgencyId`,
     `sp_rel_agency`.LanguageId
	,`sp_rel_agency`.FieldCode
	,`sp_rel_agency`.SpRelAgencyName
	,`sp_rel_agency`.OrgId
	,`sp_rel_agency`.`Order`
	,`sp_rel_agency`.LastUpdateDate
	,`sp_rel_agency`.EditingBy
	,`sp_rel_agency`.Hide
)
SELECT
	''
	,NEW.LanguageId
	,`sp_rel_agency`.FieldCode
	,`sp_rel_agency`.SpRelAgencyName
	,NEW.OrgId
	,`sp_rel_agency`.`Order`
	,CURRENT_TIMESTAMP()
	,`sp_rel_agency`.EditingBy
	,`sp_rel_agency`.Hide
FROM `ABCanTrackV2`.`sp_rel_agency` Where `OrgId` is null AND LanguageId = NEW.`LanguageId`;
-- ------------------------------------------------------------

INSERT INTO `ABCanTrackV2`.`yes_no`
(
	`Id`,
    `OrgId`,
    `LanguageId`, 
    `LabelYes`, 
    `LabelNo`
)
select MyUUID(),
    NEW.OrgId,
    NEW.LanguageId,
    `LabelYes`, 
    `LabelNo`
from `ABCanTrackV2`.`yes_no` where OrgId is null and `LanguageId` = NEW.LanguageId;

END;
