CREATE TRIGGER ABCanTrackV2.field_AUPD
AFTER UPDATE ON ABCanTrackV2.field
FOR EACH ROW
  begin
if NEW.orgid is not null then
UPDATE `org_field`
SET
`FieldLabel` = NEW.defaultfieldlabel,
`HelpMeName` = NEW.DefaultHelpMeName,
`HelpMeDescription` = NEW.DefaultHelpMeDescription
WHERE  `FieldId` = NEW.fieldid;
/*
ELSEIF NEW.orgid IS NULL
THEN 
	UPDATE `org_field`
	SET
	`HelpMeName` = NEW.DefaultHelpMeName,
	`HelpMeDescription` = NEW.DefaultHelpMeDescription
	WHERE  `FieldId` = NEW.fieldid;
	*/
end if;
END;
