CREATE TRIGGER ABCanTrackV2.field_BINS
BEFORE INSERT ON ABCanTrackV2.field
FOR EACH ROW
  BEGIN
	SET NEW.FieldId = MyUUID();
	UPDATE last_uuid
	SET LastId	= NEW.FieldId
	WHERE TableName = 'field';
END;
