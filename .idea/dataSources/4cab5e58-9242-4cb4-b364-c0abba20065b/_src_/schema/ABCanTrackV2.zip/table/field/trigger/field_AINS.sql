CREATE TRIGGER ABCanTrackV2.field_AINS
AFTER INSERT ON ABCanTrackV2.field
FOR EACH ROW
  begin
if new.orgid is not null then
INSERT INTO  `ABCanTrackV2`.`org_field`
(
	`org_field`.`OrgId`,
    `org_field`.`FieldId`,
    `org_field`.`FieldLabel`,
    `org_field`.`HelpMeName`,
    `org_field`.`HelpMeDescription`
)
Values
(
	NEW.`OrgId`,
	NEW.`FieldId`,
    NEW.`DefaultFieldLabel`,
    NEW.`DefaultHelpMeName`,
    NEW.`DefaultHelpMeDescription`
);
/**
Else IF NEW.IsCustom = 0 THEn
BEGIN
DECLARE $Min, $Max varchar(100);
SET $Min = (select min(OrgId) from organization);
SET $Max = (select max(OrgId) from organization);
OrgLoop: WHILE $Min <= $Max
DO
INSERT INTO  `ABCanTrackV2`.`org_field`
(
	`org_field`.`OrgId`,
    `org_field`.`FieldId`,
    `org_field`.`FieldLabel`,
    `org_field`.`HelpMeName`,
    `org_field`.`HelpMeDescription`
)
Values
(
	$Min,
	NEW.`FieldId`,
    NEW.`DefaultFieldLabel`,
    NEW.`DefaultHelpMeName`,
    NEW.`DefaultHelpMeDescription`
);
IF $Min = $Max
then LEAVE OrgLoop;
Else
SET $Min = (select min(OrgId) from organization where OrgId > $Min);
END IF;
END WHILE;
END;
**/
end if;
END;
