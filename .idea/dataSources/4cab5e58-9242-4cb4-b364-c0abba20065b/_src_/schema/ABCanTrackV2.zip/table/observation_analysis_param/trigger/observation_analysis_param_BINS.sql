CREATE TRIGGER ABCanTrackV2.observation_analysis_param_BINS
BEFORE INSERT ON ABCanTrackV2.observation_analysis_param
FOR EACH ROW
  BEGIN
  SET NEW.ObservationAndAnalysisParamId = MyUUID();
  UPDATE last_uuid 
  SET LastId = NEW.ObservationAndAnalysisParamId
  WHERE TableName = 'observation_analysis_param';
END;
