CREATE TRIGGER ABCanTrackV2.external_agency_BINS
BEFORE INSERT ON ABCanTrackV2.external_agency
FOR EACH ROW
  BEGIN
SET NEW.ExtAgencyId = MyUUID();
END;
