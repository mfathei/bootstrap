CREATE TRIGGER ABCanTrackV2.injury_BINS
BEFORE INSERT ON ABCanTrackV2.injury
FOR EACH ROW
  BEGIN
	SET NEW.InjuryId = MyUUID();
	UPDATE last_uuid
	SET LastId	= NEW.InjuryId
	WHERE TableName = 'injury';
END;
