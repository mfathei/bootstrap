CREATE TRIGGER ABCanTrackV2.incident_BINS
BEFORE INSERT ON ABCanTrackV2.incident
FOR EACH ROW
  BEGIN
	SET @MyIncidentId= MyUUID();
    SET NEW.IncidentId = @MyIncidentId;
	UPDATE last_uuid
	SET LastId	= NEW.IncidentId
	WHERE TableName = 'incident'; 
END;
