CREATE TRIGGER ABCanTrackV2.root_cause_param_BINS
BEFORE INSERT ON ABCanTrackV2.root_cause_param
FOR EACH ROW
  BEGIN
SET NEW.RootCauseParamId = MyUUID();
END;
