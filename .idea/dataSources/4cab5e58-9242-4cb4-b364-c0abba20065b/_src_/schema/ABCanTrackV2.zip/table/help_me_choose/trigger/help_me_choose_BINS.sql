CREATE TRIGGER ABCanTrackV2.help_me_choose_BINS
BEFORE INSERT ON ABCanTrackV2.help_me_choose
FOR EACH ROW
  BEGIN
SET NEW.HelpMeChooseId = MyUUID();
END;
