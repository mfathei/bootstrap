CREATE TRIGGER ABCanTrackV2.vehicle_type_BINS
BEFORE INSERT ON ABCanTrackV2.vehicle_type
FOR EACH ROW
  BEGIN
SET NEW.VehicletypeId = MyUUID();
END;
