CREATE TRIGGER ABCanTrackV2.corr_act_status_BINS
BEFORE INSERT ON ABCanTrackV2.corr_act_status
FOR EACH ROW
  BEGIN
SET NEW.CorrActStatusId = MyUUID();
END;
