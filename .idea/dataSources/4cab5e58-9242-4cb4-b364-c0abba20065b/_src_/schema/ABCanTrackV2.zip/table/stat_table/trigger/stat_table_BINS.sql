CREATE TRIGGER ABCanTrackV2.stat_table_BINS
BEFORE INSERT ON ABCanTrackV2.stat_table
FOR EACH ROW
  BEGIN
SET NEW.StatTableId = MyUUID();
Update last_uuid
	SET LastId	= new.StatTableId
	WHERE TableName = 'stat_table';
END;
