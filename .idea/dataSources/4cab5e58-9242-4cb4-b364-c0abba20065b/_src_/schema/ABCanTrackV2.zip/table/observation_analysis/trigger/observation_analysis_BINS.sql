CREATE TRIGGER ABCanTrackV2.observation_analysis_BINS
BEFORE INSERT ON ABCanTrackV2.observation_analysis
FOR EACH ROW
  BEGIN
SET NEW.ObservationAndAnalysisId = MyUUID();
UPDATE last_uuid
SET LastId	= NEW.ObservationAndAnalysisId
WHERE TableName = 'observation_analysis';
END;
