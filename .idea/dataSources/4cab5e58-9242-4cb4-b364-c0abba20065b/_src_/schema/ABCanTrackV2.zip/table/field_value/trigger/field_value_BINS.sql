CREATE TRIGGER ABCanTrackV2.field_value_BINS
BEFORE INSERT ON ABCanTrackV2.field_value
FOR EACH ROW
  BEGIN
	SET @NewFieldValueId = MyUUID();
	SET NEW.FieldValueId = @NewFieldValueId;
	UPDATE last_uuid
	SET LastId	= new.FieldValueId
	WHERE TableName = 'field_value';
END;
