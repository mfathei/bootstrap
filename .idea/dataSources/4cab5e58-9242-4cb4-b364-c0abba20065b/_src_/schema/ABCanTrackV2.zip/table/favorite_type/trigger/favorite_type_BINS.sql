CREATE TRIGGER ABCanTrackV2.favorite_type_BINS
BEFORE INSERT ON ABCanTrackV2.favorite_type
FOR EACH ROW
  BEGIN
SET NEW.FavoriteTypeId = MyUUID();
END;
