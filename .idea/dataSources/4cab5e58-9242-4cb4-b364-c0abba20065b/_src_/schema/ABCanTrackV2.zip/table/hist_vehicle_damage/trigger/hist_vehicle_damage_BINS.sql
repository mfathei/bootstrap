CREATE TRIGGER ABCanTrackV2.hist_vehicle_damage_BINS
BEFORE INSERT ON ABCanTrackV2.hist_vehicle_damage
FOR EACH ROW
  BEGIN
SET NEW.HistVehicleDamageId = MyUUID();
END;
