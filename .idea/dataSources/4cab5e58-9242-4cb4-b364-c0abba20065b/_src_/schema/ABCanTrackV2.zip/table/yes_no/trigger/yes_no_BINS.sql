CREATE TRIGGER ABCanTrackV2.yes_no_BINS
BEFORE INSERT ON ABCanTrackV2.yes_no
FOR EACH ROW
  BEGIN
    set @last_uuid = MyUUID();
	SET NEW.Id = @last_uuid;
END;
