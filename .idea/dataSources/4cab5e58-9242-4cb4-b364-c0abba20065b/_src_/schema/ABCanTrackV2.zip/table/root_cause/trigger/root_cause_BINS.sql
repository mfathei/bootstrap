CREATE TRIGGER ABCanTrackV2.root_cause_BINS
BEFORE INSERT ON ABCanTrackV2.root_cause
FOR EACH ROW
  BEGIN
SET NEW.RootCauseId = MyUUID();
UPDATE last_uuid
SET LastId	= NEW.RootCauseId
WHERE TableName = 'root_cause';
END;
