CREATE TRIGGER ABCanTrackV2.template_BINS
BEFORE INSERT ON ABCanTrackV2.template
FOR EACH ROW
  BEGIN
	SET NEW.TemplateId = MyUUID();
	UPDATE last_uuid
	SET LastId	= NEW.TemplateId
	WHERE TableName = 'template';
END;
