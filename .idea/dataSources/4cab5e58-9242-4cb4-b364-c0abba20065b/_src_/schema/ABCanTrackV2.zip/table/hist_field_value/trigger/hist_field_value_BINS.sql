CREATE TRIGGER ABCanTrackV2.hist_field_value_BINS
BEFORE INSERT ON ABCanTrackV2.hist_field_value
FOR EACH ROW
  BEGIN
SET NEW.HistFieldValueId = MyUUID();
END;
