CREATE TRIGGER ABCanTrackV2.risk_of_recurrence_BINS
BEFORE INSERT ON ABCanTrackV2.risk_of_recurrence
FOR EACH ROW
  BEGIN
SET NEW.RiskOfRecurrenceId = MyUUID();
END;
