CREATE FUNCTION ABCanTrackV2.GETASSIGNNOTIFICATIONSFUN(`$EmployeeId` VARCHAR(100), `$GroupId` VARCHAR(100),
                                                       `$OrgId`      VARCHAR(100))
  RETURNS TEXT
  BEGIN
-- DECLARE $Concatinated TEXT;
DECLARE $EmailToId TEXT;
 IF $GroupId is null
		then 		
			SET @Concatinated = (select
				concat_ws(', ',
							(select group_concat(Location1Name  separator ', ') from location1 where  location1id in (select TableKeyValue from email_to where OrgId = $OrgId and EmployeeId = $EmployeeId and  TableName = 'location1')),
							(select group_concat(Location2Name  separator ', ') from location2 where  location2id in (select TableKeyValue from email_to where OrgId = $OrgId and  EmployeeId = $EmployeeId and  TableName = 'location2')),
							(select group_concat(Location3Name  separator ', ') from location3 where  location3id in (select TableKeyValue from email_to where OrgId = $OrgId and  EmployeeId = $EmployeeId and  TableName = 'location3')),
							(select group_concat(Location4Name  separator ', ') from location4 where  location4id in (select TableKeyValue from email_to where OrgId = $OrgId and  EmployeeId = $EmployeeId and  TableName = 'location4')),
							(select group_concat(OperationTypeName  separator ', ') from operation_type where  OperationTypeId in (select TableKeyValue from email_to where OrgId = $OrgId and  EmployeeId = $EmployeeId and  TableName = 'operation_type')),
							(select group_concat(EventTypeName  separator ', ') from event_type where  EventTypeId in (select TableKeyValue from email_to where OrgId = $OrgId and  EmployeeId = $EmployeeId and  TableName = 'event_type')),
							(select group_concat(IncidentSeverityName  separator ', ') from incident_severity where  IncidentSeverityId in (select TableKeyValue from email_to where OrgId = $OrgId and  EmployeeId = $EmployeeId and  TableName = 'incident_severity')),
							(select group_concat(ImpactTypeName  separator ', ') from impact_type where  ImpactTypeId in (select TableKeyValue from email_to where OrgId = $OrgId and  EmployeeId = $EmployeeId and  TableName = 'impact_type'))
		) 
		as locValue);
        SET $EmailToId = (select EmailToId from email_to where OrgId = $OrgId and EmployeeId = $EmployeeId and  TableName='corrective_action' LIMIT 1);
		IF $EmailToId IS NOT NULL
		THEN
			SET @Concatinated = CONCAT_WS(',',@Concatinated,'Corrective Actions');
		
		END IF;
		End If;
		
IF $EmployeeId is null
		then 
			SET @Concatinated = (select
			  concat_ws(', ',
							(select group_concat(Location1Name  separator ', ') from location1 where  location1id in (select TableKeyValue from email_to where OrgId = $OrgId and GroupId = $GroupId and  TableName = 'location1')),
							(select group_concat(Location2Name  separator ', ') from location2 where  location2id in (select TableKeyValue from email_to where OrgId = $OrgId and  GroupId = $GroupId and  TableName = 'location2')),
							(select group_concat(Location3Name  separator ', ') from location3 where  location3id in (select TableKeyValue from email_to where OrgId = $OrgId and  GroupId = $GroupId and  TableName = 'location3')),
							(select group_concat(Location4Name  separator ', ') from location4 where  location4id in (select TableKeyValue from email_to where OrgId = $OrgId and  GroupId = $GroupId and  TableName = 'location4')),
							(select group_concat(OperationTypeName  separator ', ') from operation_type where  OperationTypeId in (select TableKeyValue from email_to where OrgId = $OrgId and  GroupId = $GroupId and  TableName = 'operation_type')),
							(select group_concat(EventTypeName  separator ', ') from event_type where  EventTypeId in (select TableKeyValue from email_to where OrgId = $OrgId and  GroupId = $GroupId and  TableName = 'event_type')),
							(select group_concat(IncidentSeverityName  separator ', ') from incident_severity where  IncidentSeverityId in (select TableKeyValue from email_to where OrgId = $OrgId and  GroupId = $GroupId and  TableName = 'incident_severity')),
							(select group_concat(ImpactTypeName  separator ', ') from impact_type where  ImpactTypeId in (select TableKeyValue from email_to where OrgId = $OrgId and  GroupId = $GroupId and  TableName = 'impact_type'))
				)
		as locValue);
        SET $EmailToId = (select EmailToId from email_to where OrgId = $OrgId and  GroupId = $GroupId and TableName='corrective_action' LIMIT 1);
		IF $EmailToId IS NOT NULL
		THEN
			SET @Concatinated = CONCAT_WS(',',@Concatinated,'Corrective Actions');
		
		END IF;
end If;
RETURN @Concatinated; 
END;
