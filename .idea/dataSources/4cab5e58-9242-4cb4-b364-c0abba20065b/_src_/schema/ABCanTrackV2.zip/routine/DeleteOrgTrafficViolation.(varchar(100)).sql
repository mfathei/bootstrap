CREATE PROCEDURE ABCanTrackV2.DeleteOrgTrafficViolation(IN `$OrgId` VARCHAR(100))
  BEGIN
	DECLARE $Count INT;
    
    
    -- Step1: impacts_ext_agency
	SET $Count = (SELECT COUNT(*) FROM impacts_ext_agency WHERE TrafficViolationId IN (SELECT TrafficViolationId FROM traffic_violation WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId)));
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgTrafficViolation',  'impacts_ext_agency', NULL, $Count, 1);
    
	-- ************
	DELETE FROM impacts_ext_agency WHERE TrafficViolationId IN (SELECT TrafficViolationId FROM traffic_violation WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId));
    -- #
    
    
    -- Step2: traffic_violation
	SET $Count = (SELECT COUNT(*) FROM traffic_violation WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId));
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgTrafficViolation',  'traffic_violation', NULL, $Count, 2);
    
	-- ************
	DELETE FROM traffic_violation WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId);
    -- #
    
    -- Step3: DONE
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgTrafficViolation', 'DONE', NULL, NULL, 3);
    -- # 
END;
