CREATE PROCEDURE ABCanTrackV2.InsertInto_hist_corrective_action(IN `$CorrectiveActionId`         VARCHAR(100),
                                                                IN `$OldCorrectiveActionId`      VARCHAR(100),
                                                                IN `$OriginalCorrectiveActionId` VARCHAR(100),
                                                                IN `$UpdatedById`                VARCHAR(100))
  BEGIN
/*
	DECLARE @IncidentId, @HistoryOperationId, @HistIncidentId varchar(100) ;
	DECLARE @StatusName, @PriorityName, @AssignedToName, @AssignedByName, @UpdatedByName varchar(255) ;
	DECLARE @AlsoNotifyName, @Description, @OldDescription, @OutComeFollowUp, @OldOutComeFollowUp, @Comments, @OldComments TEXT ;
	DECLARE @StartDate, @TargetEndDate, @ActualEndDate, @UpdatedDate DATETIME ;
	DECLARE @EstimatedCost DECIMAL(10,2) ;
	DECLARE @DesiredResults BIT;
	DECLARE @VersionNumber INT;
    */
    
	SET  @UpdatedByName = (  select concat(firstname ,' ', lastname) from employee where employeeid = $UpdatedById ) ;
	SET  $CorrectiveActionId = ( select CorrectiveActionId from corrective_action where correctiveactionid =  $CorrectiveActionId);
	SET  @IncidentId = ( select incidentid from corrective_action where  correctiveactionid =  $CorrectiveActionId);
	SET  @StatusName = ( select corractstatusName from corr_act_status where  corractstatusid = (select corractstatusid from corrective_action where CorrectiveActionId = $CorrectiveActionId));
	SET  @PriorityName = ( select priorityname from priority where priorityid = (select priorityid from corrective_action where CorrectiveActionId = $CorrectiveActionId));
	SET  @AssignedToName = ( select concat(firstname ,' ', lastname) from employee where employeeid = (select assignedtoid from corrective_action where CorrectiveActionId = $CorrectiveActionId) );
	SET  @AlsoNotifyName = ( select group_concat(concat(firstname ,' ', lastname) separator ' ;| ') from employee where employeeid in (select employeeid from corrective_action_notified where correctiveactionid = $CorrectiveActionId));
	SET  @StartDate = ( select startdate from corrective_action where CorrectiveActionId = $CorrectiveActionId );
	SET  @TargetEndDate = ( select targetenddate from corrective_action where CorrectiveActionId = $CorrectiveActionId );
	SET  @ActualEndDate = ( select ActualEndDate from corrective_action where CorrectiveActionId = $CorrectiveActionId );
	SET  @EstimatedCost = ( select EstimatedCost from corrective_action where CorrectiveActionId = $CorrectiveActionId );
	SET  @Description = ( select TaskDescription from corrective_action where CorrectiveActionId = $CorrectiveActionId );
		if($OldCorrectiveActionId is null) then
		SET  @OldDescription =( select concat(DATE_FORMAT(curdate(), '%b %d %Y'),' ', '(',@UpdatedByName,')',': ', ifnull((@Description), '') )from corrective_action where correctiveactionid = $CorrectiveActionId );
		else
		SET  @OldDescription = ( select concat(DATE_FORMAT(curdate(), '%b %d %Y'),' ', '(',@UpdatedByName,')',': ', ifnull((@Description), '') ,' <br><br> ', ifnull((OldDescription), '')) from hist_corrective_action where correctiveactionid = $OldCorrectiveActionId LIMIT 1);
		end if; 
	SET  @OutComeFollowUp = ( select OutComeFollowUp from corrective_action where CorrectiveActionId = $CorrectiveActionId );
if($OldCorrectiveActionId is null) then
		SET  @OldOutComeFollowUp =( select concat(DATE_FORMAT(curdate(), '%b %d %Y'),' ', '(',@UpdatedByName,')',': ', ifnull((@OutComeFollowUp), '') ));
set $OriginalCorrectiveActionId = $CorrectiveActionId;
else
SET  @OldOutComeFollowUp = ( select concat(DATE_FORMAT(curdate(), '%b %d %Y'),' ', '(',@UpdatedByName,')',': ', ifnull((@OutComeFollowUp), '') ,' <br><br> ', ifnull((OldOutComeFollowUp), '')) from hist_corrective_action where correctiveactionid = $OldCorrectiveActionId LIMIT 1);
	
end if;
SET  @DesiredResults = ( select DesiredResults from corrective_action where CorrectiveActionId = $CorrectiveActionId );
	SET  @Comments = ( select Comments from corrective_action where CorrectiveActionId = $CorrectiveActionId );
	
	if($OldCorrectiveActionId is null) then
		SET  @OldComments =( select concat(DATE_FORMAT(curdate(), '%b %d %Y'),' ', '(',@UpdatedByName,')',': ', ifnull((@Comments), '') ));
	else
	SET  @OldComments = ( select concat(DATE_FORMAT(curdate(), '%b %d %Y'),' ', '(',@UpdatedByName,')',': ', ifnull((@Comments), '') ,' <br><br> ', ifnull((OldComments), '')) from hist_corrective_action where correctiveactionid = $OldCorrectiveActionId LIMIT 1);	
	end if;
	SET  @AssignedByName = ( select concat(firstname ,' ', lastname) from employee where employeeid = (select AssignedById from corrective_action where CorrectiveActionId = $CorrectiveActionId) );
	SET @VersionNumber = (SELECT MAX(VersionNumber) FROM hist_incident WHERE IncidentId = @IncidentId);
	SET @HistIncidentId = (SELECT HistIncidentId FROM hist_incident WHERE IncidentId = @IncidentId AND VersionNumber = @VersionNumber);
	SET  @HistoryOperationId = (SELECT HistoryOperationId FROM hist_incident WHERE HistIncidentId = @HistIncidentId);
	
if($OriginalCorrectiveActionId is null  or $OriginalCorrectiveActionId='') then
set $OriginalCorrectiveActionId = $CorrectiveActionId ;
END IF;
	SET  @UpdatedDate = current_timestamp();
	INSERT INTO `hist_corrective_action`
	(
	`HistCorrectiveActionId`,
	`CorrectiveActionId`,
	`IncidentId`,
	`StatusName`,
	`PriorityName`,
	`AssignedToName`,
	`AlsoNotifyName`,
	`StartDate`,
	`TargetEndDate`,
	`ActualEndDate`,
	`EstimatedCost`,
	`Description`,
	`OldDescription`,
	`OutComeFollowUp`,
	`OldOutComeFollowUp`,
	`DesiredResults`,
	`Comments`,
	`OldComments`,
	`AssignedByName`,
	`HistoryOperationId`,
	`UpdatedById`,
	`UpdatedDate`,
	`HistIncidentId`,
					`OriginalCorrectiveActionId`
	)
	VALUES
	(
	MyUUID(),
	$CorrectiveActionId,
	@IncidentId,
	@StatusName,
	@PriorityName,
	@AssignedToName,
	@AlsoNotifyName,
	@StartDate,
	@TargetEndDate,
	@ActualEndDate,
	@EstimatedCost,
	@Description,
	@OldDescription,
	@OutComeFollowUp,
	@OldOutComeFollowUp,
	@DesiredResults,
	@Comments,
	@OldComments,
	@AssignedByName,
	@HistoryOperationId,
	$UpdatedById,
	@UpdatedDate,
	@HistIncidentId,
	$OriginalCorrectiveActionId
	);
	END;
