CREATE PROCEDURE ABCanTrackV2.GetOrgReportTemplates_old(IN `$OrgId` VARCHAR(100), IN `$EmployeeId` VARCHAR(100))
  BEGIN

declare  $GroupId VARCHAR(100);

set  $GroupId = (select g.GroupId from `group` g
inner join emp_group eg
on g.GroupId = eg.GroupId and g.OrgId=$OrgId  and EmployeeId = $EmployeeId);



 -- select $GroupId;

SELECT 
    temp.TemplateName,
    temp.TemplateTypeCode,
    temp.TemplateId,
    FullName,
    EmployeeId
FROM
    (SELECT 
        TemplateName,
            TemplateTypeCode,
            TemplateId,
            LastUpdatedDate,
            CONCAT(e.FirstName, ' ', e.LastName) AS FullName,
            tbl1.EmployeeId
    FROM
        template tbl1
    INNER JOIN template_type ON tbl1.TemplateTypeId = template_type.TemplateTypeId
    INNER JOIN employee e ON tbl1.EmployeeId = e.EmployeeId
    WHERE
        tbl1.OrgId = $OrgId
            AND tbl1.EmployeeId = $EmployeeId
            AND TemplateTypeCode = 'MyTemplate' UNION ALL SELECT 
        TemplateName,
            TemplateTypeCode,
            TemplateId,
            LastUpdatedDate,
            CONCAT(e.FirstName, ' ', e.LastName) AS FullName,
            tbl2.EmployeeId
    FROM
        template tbl2
    INNER JOIN template_type ON tbl2.TemplateTypeId = template_type.TemplateTypeId
    INNER JOIN `group` tbl3 ON `tbl3`.OrgId = tbl2.OrgId
    INNER JOIN emp_group tbl4 ON tbl2.EmployeeId = tbl4.EmployeeId
    INNER JOIN employee e ON tbl2.EmployeeId = e.EmployeeId
        AND tbl3.GroupId = tbl4.GroupId
    WHERE
        tbl2.OrgId = $OrgId
            AND (TemplateTypeCode = 'DefaultTemplate'
            OR TemplateTypeCode = 'SharedTemplate')
            AND tbl4.GroupId = $GroupId) temp
ORDER BY LastUpdatedDate DESC;


END;
