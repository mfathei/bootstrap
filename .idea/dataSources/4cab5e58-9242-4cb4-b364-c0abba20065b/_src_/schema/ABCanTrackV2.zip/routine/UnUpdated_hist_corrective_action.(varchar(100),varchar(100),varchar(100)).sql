CREATE PROCEDURE ABCanTrackV2.UnUpdated_hist_corrective_action(IN `$NewHistIncidentId` VARCHAR(100),
                                                               IN `$OldHistIncidentId` VARCHAR(100),
                                                               IN `$UpdatedById`       VARCHAR(100))
  BEGIN  
INSERT INTO `ABCanTrackV2`.`hist_corrective_action`
(`HistCorrectiveActionId`,
`CorrectiveActionId`,
`OriginalCorrectiveActionId`,
`IncidentId`,
`StatusName`,
`PriorityName`,
`AssignedToName`,
`AlsoNotifyName`,
`StartDate`,
`TargetEndDate`,
`ActualEndDate`,
`EstimatedCost`,
`Description`,
`OldDescription`,
`OutComeFollowUp`,
`OldOutComeFollowUp`,
`DesiredResults`,
`Comments`,
`OldComments`,
`AssignedByName`,
`HistoryOperationId`,
`UpdatedById`,
`UpdatedDate`,
`HistIncidentId`)
select 
`HistCorrectiveActionId`,
`CorrectiveActionId`,
`OriginalCorrectiveActionId`,
`IncidentId`,
`StatusName`,
`PriorityName`,
`AssignedToName`,
`AlsoNotifyName`,
`StartDate`,
`TargetEndDate`,
`ActualEndDate`,
`EstimatedCost`,
`Description`,
`OldDescription`,
`OutComeFollowUp`,
`OldOutComeFollowUp`,
`DesiredResults`,
`Comments`,
`OldComments`,
`AssignedByName`,
`HistoryOperationId`,
$UpdatedById,
current_timestamp(),
$NewHistIncidentId
from hist_corrective_action
WHERE HistIncidentId = $OldHistIncidentId; 

INSERT INTO `ABCanTrackV2`.`hist_field_value`
(`HistFieldValueId`,
`FieldValueId`,
`IncidentId`,
`FieldId`,
`OptionName`,
`HistIncidentId`,
`FieldValue`,
`TableKeyValue`,
`TableKeyId`,
`HistoryOperationId`,
`UpdatedById`)
SELECT 
`HistFieldValueId`,
`FieldValueId`,
`IncidentId`,
`FieldId`,
`OptionName`,
$NewHistIncidentId,
`FieldValue`,
`TableKeyValue`,
`TableKeyId`,
`HistoryOperationId`,
$UpdatedById
FROM  hist_field_value
WHERE HistIncidentId = $OldHistIncidentId AND TableKeyValue = 'corrective_action';
END;
