CREATE FUNCTION ABCanTrackV2.getInjuryDescription2(`$InjuryId` VARCHAR(100), `$OriginalInjuryId` VARCHAR(100))
  RETURNS TEXT
  BEGIN
if $OriginalInjuryId is null   or $OriginalInjuryId  =''   then
	set $OriginalInjuryId = $InjuryId ;
end if;
set session group_concat_max_len = 10000;
select (group_concat(DATE_FORMAT(UpdatedDate, '%b %d %Y') ,' ', '(',  concat(firstname ,' ', lastname) ,')',': <pr>', InjuryDescription separator '<br><br>' ) ) as InjuryDescription  
 into @newInjuryDescription2 
 from(
 select UpdatedDate, InjuryDescription, firstname,lastname FROM hist_injury hi 
join employee e on e.EmployeeId = hi.UpdatedbyId
 where OriginalInjuryId = $OriginalInjuryId  
order by UpdatedDate asc  ) temp ; 
return @newInjuryDescription2;
END;
