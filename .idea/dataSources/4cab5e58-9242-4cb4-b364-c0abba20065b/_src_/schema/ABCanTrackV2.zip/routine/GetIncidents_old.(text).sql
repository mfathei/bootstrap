CREATE PROCEDURE ABCanTrackV2.GetIncidents_old(IN xmlData TEXT)
  BEGIN
 
 
-- ========================================================================
-- Reviewed and altered by AbdulRahman Shamsan.
-- ========================================================================
 
SET @OrgId = extractvalue(xmlData, '//OrgId');
SET @page = extractvalue(xmlData, '//page');
SET @limit = extractvalue(xmlData, '//limit');
SET @sortOrder =  extractvalue(xmlData, '//sortOrder');
SET @index =  extractvalue(xmlData, '//index');
SET @Mine =  extractvalue(xmlData, '//Mine');
SET @CreatorId = extractvalue(xmlData, '//CreatorId');
SET @Export =  extractvalue(xmlData, '//Export');
-- ========================================================================
-- Default select statment: BEGIN
-- ========================================================================
-- =========================================
-- Default select clause
set @selectquery ='
SELECT
        `inc`.`IncidentId` AS `IncidentId`,
        `inc`.`IncidentNumber` AS `IncidentNumber`,
         date_format(`inc`.`IncidentDate`, '%m/%d/%Y') AS `IncidentDate`,
        `inc`.`IncidentHour` AS `IncidentHour`,
        `inc`.`EditingBy` AS `EditingBy`,
        `inc`.`EditingBy` AS `LockedId`,
        `inc`.`IncidentMinute` AS `IncidentMinute`,
        `inc`.`IsEmerRP` AS `IsEmerRP`,
        `inc`.`RepName` AS `RepName`,
        `inc`.`RepEmail` AS `RepEmail`,
        `inc`.`RepPosition` AS `RepPosition`,
        `inc`.`RepCompany` AS `RepCompany`,
        `inc`.`RepPrimaryPhone` AS `RepPrimaryPhone`,
        `inc`.`RepAlternatePhone` AS `RepAlternatePhone`,
        `inc`.`OtherLocation` AS `OtherLocation`,
        `inc`.`EventSequence` AS `EventSequence`,
        `inc`.`EnvConditionNote` AS `EnvConditionNote`,
        `inc`.`IncDescription` AS `IncDescription`,
        `inc`.`EnergyFormNote` AS `EnergyFormNote`,
        `inc`.`SubStandardActionNote` AS `SubStandardActionNote`,
        `inc`.`SubStandardConditionNote` AS `SubStandardConditionNote`,
        `inc`.`UnderLyingCauseNote` AS `UnderLyingCauseNote`,
         date_format(`inc`.`InvestigationDate`, '%m/%d/%Y') AS `InvestigationDate`,
        `inc`.`InvestigatorName1` AS `InvestigatorName1`,
        `inc`.`InvestigatorName2` AS `InvestigatorName2`,
        `inc`.`InvestigatorName3` AS `InvestigatorName3`,
        `inc`.`InvSummary` AS `InvSummary`,
        `inc`.`FollowUpNote` AS `FollowUpNote`,
        `inc`.`ResponseCost` AS `ResponseCost`,
        `inc`.`RepairCost` AS `RepairCost`,
        `inc`.`InsuranceCost` AS `InsuranceCost`,
        `inc`.`WCBCost` AS `WCBCost`,
        `inc`.`OtherCost` AS `OtherCost`,
        `inc`.`TotalCost` AS `TotalCost`,
        `inc`.`SourceDetails` AS `SourceDetails`,
        `inc`.`RootCauseNote` AS `RootCauseNote`,
        `inc`.`SignOffInvestigatorName` AS `SignOffInvestigatorId`,
        date_format(`inc`.`SignOffDate`, '%m/%d/%Y') AS `SignOffDate`,
        max(`hinc`.`VersionNumber`) AS `MAXVN`
';
-- =========================================
-- Default from clause
set @queryFrom = ' from incident inc INNER JOIN hist_incident hinc on inc.IncidentId = hinc.IncidentId  ';
-- =========================================
-- Group clause
SET @querygroup = ' group by hinc.IncidentId ';
-- =========================================
-- Have clause
SET @queryhave = ' having MAXVN = MAX(hinc.VersionNumber)    ';
-- =========================================
-- Default Where clause
SET @queryWhere = ' where 1= 1 ';
IF (@OrgId != '' AND @OrgId !='0') THEN
	SET @queryWhere = CONCAT(@queryWhere," and inc.OrgId = '", @Orgid,"'");
END IF;
-- ========================================================================
-- Default select statment: END
-- ========================================================================================================================================
-- ========================================================================================================================================
-- Adding joins to From clause and conditions to Where clause: Begin
-- ========================================================================
-- =========================================
-- inc.CreatorId = Current EmployeeId
IF (@Mine = 'true') THEN
	SET @queryWhere = CONCAT(@queryWhere," AND inc.CreatorId =  '",@CreatorId,"'"  );
END IF;
-- =========================================
-- Add join with event_type table
SET @queryWhere = CONCAT(@queryWhere,' AND inc.Hide =  0');
IF( ExtractValue(xmlData, 'count(//EventTypeId)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', event_type.EventTypeName as EventTypeId ');
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join event_type on inc.EventTypeId = event_type.EventTypeId  ');
END IF;
-- =========================================
-- Add join with operation_type table
IF( ExtractValue(xmlData, 'count(//OperationTypeId)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', operation_type.OperationTypeName as OperationTypeId ');
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join operation_type on inc.OperationTypeId = operation_type.OperationTypeId  ');
END IF;
-- =========================================
-- Add join with location1 table
IF( ExtractValue(xmlData, 'count(//Location1Id)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', location1.Location1Name as Location1Id ');
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join location1 on inc.Location1Id = location1.Location1Id  ');
END IF;
-- =========================================
-- Add join with location2 table
IF( ExtractValue(xmlData, 'count(//Location2Id)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', location2.Location2Name as Location2Id ');
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join location2 on inc.Location2Id = location2.Location2Id  ');
END IF;
-- =========================================
-- Add join with location3 table
IF( ExtractValue(xmlData, 'count(//Location3Id)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', location3.Location3Name as Location3Id ');
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join location3 on inc.Location3Id = location3.Location3Id  ');
END IF;
-- =========================================
-- Add join with location4 table
IF( ExtractValue(xmlData, 'count(//Location4Id)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', location4.Location4Name as Location4Id ');
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join location4 on inc.Location4Id = location4.Location4Id  ');
END IF;
-- =========================================
-- Add join with inv_status table
IF( ExtractValue(xmlData, 'count(//InvStatusId)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', inv_status.InvStatusName as InvStatusId ');
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join inv_status on inc.InvStatusId = inv_status.InvStatusId  ');
END IF;
-- =========================================
-- Add join with risk_of_recurrence table
IF( ExtractValue(xmlData, 'count(//RiskOfRecurrenceId)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', risk_of_recurrence.RiskOfRecurrenceName as RiskOfRecurrenceId ');
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join risk_of_recurrence on inc.RiskOfRecurrenceId = risk_of_recurrence.RiskOfRecurrenceId  ');
END IF;
-- =========================================
-- Add join with incident_severity table
IF( ExtractValue(xmlData, 'count(//IncidentSeverityId)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', incident_severity.IncidentSeverityName as IncidentSeverityId ');
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join incident_severity on inc.IncidentSeverityId = incident_severity.IncidentSeverityId  ');
END IF;
-- =========================================
-- Add join with employee table as empModifier 
IF( ExtractValue(xmlData, 'count(//UpdatedByName)') >0 OR ExtractValue(xmlData, 'count(//VersionNumber)') >0) THEN
		IF( ExtractValue(xmlData, 'count(//UpdatedByName)') >0)THEN		
			SET @selectquery = CONCAT(@selectquery,', ', 'CONCAT',' (','empModifier.FirstName,',"'","  '" ,',empModifier.LastName',') ',' as UpdatedByName ');
			SET @queryFrom = CONCAT(@queryFrom,'  inner join employee as empModifier on hinc.UpdatedById = empModifier.EmployeeId  ');
		END IF;
END IF;
-- =========================================
-- Add join with employee table as empCreator 
IF( ExtractValue(xmlData, 'count(//CreatorName)') >0 ) THEN
	SET @selectquery = CONCAT(@selectquery,', ', 'CONCAT',' (','empCreator.FirstName,',"'","  '" ,',empCreator.LastName',') ',' as CreatorName ');
	SET @queryFrom = CONCAT(@queryFrom,'    inner join employee as empCreator on inc.CreatorId = empCreator.EmployeeId  ');
END IF;
/*  incident_third_party */
-- =========================================
-- Add join with inc_third_party and third_party and where condition--> many-to-many
-- =========================================
IF( ExtractValue(xmlData, 'count(//CustomerId)') >0  or ExtractValue(xmlData, 'count(//CustomerJobNumber)') >0 or ExtractValue(xmlData, 'count(//CustName)') >0
or ExtractValue(xmlData, 'count(//ContractorId)') >0  or ExtractValue(xmlData, 'count(//ContractorJobNumber)') >0  or ExtractValue(xmlData, 'count(//ContName)') >0) THEN
	SET @selectquery = CONCAT(@selectquery,', `tpcust`.`ThirdPartyName` AS `CustomerId`, `tpcust`.`ContactName` AS `CustName`, `itpcust`.`JobNumber` AS `CustomerJobNumber`, `tpcont`.`ThirdPartyName` AS `ContractorId`, `tpcont`.`ContactName` AS `ContName`, `itpcont`.`JobNumber` AS `ContractorJobNumber` ' );
	SET @queryFrom = CONCAT(@queryFrom,'   
      left join (`inc_third_party` `itpcust`
        join `third_party` `tpcust` ON `itpcust`.`ThirdPartyId` = `tpcust`.`ThirdPartyId`
        join `third_party_type` `tptcust` ON `tpcust`.`ThirdPartyTypeId` = `tptcust`.`ThirdPartyTypeId`
            and `tptcust`.`ThirdPartyTypeCode` = 'Customer') ON `inc`.`IncidentId` = `itpcust`.`IncidentId`
        left join (`inc_third_party` `itpcont`
        join `third_party` `tpcont` ON `itpcont`.`ThirdPartyId` = `tpcont`.`ThirdPartyId`
        join `third_party_type` `tptcont` ON `tpcont`.`ThirdPartyTypeId` = `tptcont`.`ThirdPartyTypeId`
            and `tptcont`.`ThirdPartyTypeCode` = 'Contractor') ON `inc`.`IncidentId` = `itpcont`.`IncidentId` ');
 
-- =========================================
-- third_party Contractor part 
	SET @Col =  extractvalue(xmlData, CONCAT('//','ContractorId'));
	IF (@Col != '' AND @Col !='NULL') THEN	 
		SET @queryWhere = CONCAT(@queryWhere,'  and `tpcont`.`ThirdPartyName`' ,' like '"'%", @Col ,"%'" );
	END IF;
	SET @Col =  extractvalue(xmlData, CONCAT('//','ContName'));
	IF (@Col != '' AND @Col !='NULL') THEN	 
		SET @queryWhere = CONCAT(@queryWhere,'  and `tpcont`.`ContactName`' ,' like '"'%", @Col ,"%'" );
	END IF;
	SET @Col =  extractvalue(xmlData, CONCAT('//','ContractorJobNumber'));
	IF (@Col != '' AND @Col !='NULL') THEN	 
		SET @queryWhere = CONCAT(@queryWhere,'  and `itpcont`.`JobNumber`' ,' like '"'%", @Col ,"%'" );
	END IF;
	SET @Col =  extractvalue(xmlData, CONCAT('//','CustomerId'));
	IF (@Col != '' AND @Col !='NULL') THEN	 
		SET @queryWhere = CONCAT(@queryWhere,'  and `tpcust`.`ThirdPartyName`' ,' like '"'%", @Col ,"%'" );
	END IF;
-- =========================================
-- third_party Customer part
	SET @Col =  extractvalue(xmlData, CONCAT('//','CustName'));
	IF (@Col != '' AND @Col !='NULL') THEN	 
	SET @queryWhere = CONCAT(@queryWhere,'  and `tpcust`.`ContactName`' ,' like '"'%", @Col ,"%'" );
	END IF;
    
	SET @Col =  extractvalue(xmlData, CONCAT('//','CustomerJobNumber'));
	IF (@Col != '' AND @Col !='NULL') THEN	 
		SET @queryWhere = CONCAT(@queryWhere,'  and `itpcust`.`JobNumber`' ,' like '"'%", @Col ,"%'" );
	END IF; 
END IF;
-- *******************************************************************************************************************************************************
/*  OEDepartmentId  */
-- =========================================
-- Add join with inc_oe_department and oe_department with its where condition--> many-to-many
-- =========================================
IF( ExtractValue(xmlData, 'count(//OEDepartmentId)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,',   group_concat(`oe_department`.`OEDepartmentName`
                        separator '; ') AS OEDepartmentId');
	SET @queryFrom = CONCAT(@queryFrom,'   left join  ( inc_oe_department  join `oe_department` ON `oe_department`.`OEDepartmentId` = `inc_oe_department`.`OEDepartmentId` )  on inc.IncidentId = inc_oe_department.IncidentId   ');
    
	SET @Col =  extractvalue(xmlData, CONCAT('//','OEDepartmentId'));
	IF (@Col != '' AND @Col !='NULL') THEN	 
		SET @queryWhere = CONCAT(@queryWhere,'  and `oe_department`.`OEDepartmentName`' ,' like '"'%", @Col ,"%'" );
	END IF;
END IF;
-- *******************************************************************************************************************************************************
/*  EnvConditions  */
-- =========================================
-- Add join with inc_env_cond and env_cond_parameter with its where condition--> many-to-many
-- =========================================
IF( ExtractValue(xmlData, 'count(//EnvConditions)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,',   group_concat(`env_cond_parameter`.`EnvCondParameterName`
                        separator '; ') AS EnvConditions');
	SET @queryFrom = CONCAT(@queryFrom,'    
								left join ( `inc_env_cond` inner join `env_cond_parameter` ON `env_cond_parameter`.`EnvCondParameterId` = `inc_env_cond`.`EnvCondParameterId` ) on inc.IncidentId = inc_env_cond.IncidentId  ');
                                
    
	SET @Col =  extractvalue(xmlData, CONCAT('//','EnvConditions'));
	IF (@Col != '' AND @Col !='NULL') THEN	 
		SET @queryWhere = CONCAT(@queryWhere,'  and `env_cond_parameter`.`EnvCondParameterName`' ,' like '"'%", @Col ,"%'" );
	END IF;                     
END IF;
-- *******************************************************************************************************************************************************
/*  RootCauseParamId  */
-- =========================================
-- Add join with inc_root_cause and root_cause_param with its where condition--> many-to-many
-- =========================================
IF( ExtractValue(xmlData, 'count(//RootCauseParamId)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,',  group_concat(`root_cause_param`.`RootCauseParamName`
                        separator '; ') AS RootCauseParamId');
	SET @queryFrom = CONCAT(@queryFrom,'     LEFT JOIN (`inc_root_cause` inner  join `root_cause_param` ON `root_cause_param`.`RootCauseParamId` = `inc_root_cause`.`RootCauseParamId`      ) ON inc.IncidentId = inc_root_cause.IncidentId  ');
    
    
     SET @Col =  extractvalue(xmlData, CONCAT('//','RootCauseParamId'));
	IF (@Col != '' AND @Col !='NULL') THEN	 
		SET @queryWhere = CONCAT(@queryWhere,'  and `root_cause_param`.`RootCauseParamName`' ,' like '"'%", @Col ,"%'" );
	END IF;
END IF;
-- *******************************************************************************************************************************************************
/*  InvSourceId  */
-- =========================================
-- Add join with inc_inv_source and inv_source with its where condition--> many-to-many
-- =========================================
IF( ExtractValue(xmlData, 'count(//InvSourceParamId)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,',  group_concat(`inv_source`.`InvSourceName`
                        separator '; ') AS InvSourceParamId');
	SET @queryFrom = CONCAT(@queryFrom,'      LEFT JOIN  (`inc_inv_source` join `inv_source` ON `inv_source`.`InvSourceId` = `inc_inv_source`.`InvSourceId`    ) ON inc.IncidentId = inc_inv_source.IncidentId  ');	
                
	SET @Col =  extractvalue(xmlData, CONCAT('//','InvSourceParamId'));
	IF (@Col != '' AND @Col !='NULL') THEN	 
		SET @queryWhere = CONCAT(@queryWhere,'  and  `inv_source`.`InvSourceName` ' ,' like '"'%", @Col ,"%'" );
	END IF; 
END IF;
-- *******************************************************************************************************************************************************
-- ========================================================================================================================================
-- Add join with inc_obser_ana and `observation_analysis_param` with its where condition--> many-to-many
-- ========================================================================
-- =========================================
-- Energy Form 
-- Add join with inc_obser_ana and `observation_analysis_param` as oape with its where condition--> many-to-many
-- =========================================
IF  ExtractValue(xmlData, 'count(//EnergyForm)') >0  
THEN 
	SET @selectquery = CONCAT(@selectquery,',                 group_concat(`oape`.`ObservationAndAnalysisParamName`
                        separator '; ') AS EnergyForm ');
	SET @queryFrom = CONCAT(@queryFrom,'    left join (`inc_obser_ana` ioae inner join `observation_analysis_param` oape ON `oape`.`ObservationAndAnalysisParamId` = `ioae`.`ObservationAndAnalysisParamId`
inner join `observation_analysis` oae ON `oae`.`ObservationAndAnalysisId` = `oape`.`ObservationAndAnalysisId` AND oae.ObservationAndAnalysisCode = 'EnergyForm' )      on inc.IncidentId = ioae.IncidentId  ');
	SET @Col =  extractvalue(xmlData, CONCAT('//','EnergyForm'));
	IF (@Col != '' AND @Col !='NULL') THEN	 
		SET @queryWhere = CONCAT(@queryWhere,'  and  `oape`.`ObservationAndAnalysisParamName` ' ,' like '"'%", @Col ,"%'" );
	END IF; 
END IF;
-- =========================================
-- SubActions 
-- Add join with inc_obser_ana and `observation_analysis_param` as oapsa with its where condition--> many-to-many
-- =========================================
IF ExtractValue(xmlData, 'count(//SubActions)') >0   THEN 
	SET @selectquery = CONCAT(@selectquery,',                 group_concat(`oapsa`.`ObservationAndAnalysisParamName`
                        separator '; ') AS SubActions ');
	SET @queryFrom = CONCAT(@queryFrom,'    left join (`inc_obser_ana` ioasa  inner join `observation_analysis_param` oapsa ON `oapsa`.`ObservationAndAnalysisParamId` = `ioasa`.`ObservationAndAnalysisParamId`
inner join `observation_analysis` oasa ON `oasa`.`ObservationAndAnalysisId` = `oapsa`.`ObservationAndAnalysisId` AND oasa.ObservationAndAnalysisCode = 'SubActions') on inc.IncidentId = ioasa.IncidentId  ');
	SET @Col =  extractvalue(xmlData, CONCAT('//','SubActions'));
	IF (@Col != '' AND @Col !='NULL') THEN	 
		SET @queryWhere = CONCAT(@queryWhere,'  and  `oapsa`.`ObservationAndAnalysisParamName` ' ,' like '"'%", @Col ,"%'" );
	END IF; 
END IF;
-- =========================================
-- UnderLyingCauses 
-- Add join with inc_obser_ana and `observation_analysis_param` as oapuc with its where condition--> many-to-many
-- =========================================
IF ExtractValue(xmlData, 'count(//UnderLyingCauses)') >0	 THEN 
	SET @selectquery = CONCAT(@selectquery,',                 group_concat(`oapuc`.`ObservationAndAnalysisParamName`
                        separator '; ') AS UnderLyingCauses ');
	SET @queryFrom = CONCAT(@queryFrom,'    left join (`inc_obser_ana` ioauc inner join `observation_analysis_param` oapuc ON `oapuc`.`ObservationAndAnalysisParamId` = `ioauc`.`ObservationAndAnalysisParamId`
inner join `observation_analysis` oauc ON `oauc`.`ObservationAndAnalysisId` = `oapuc`.`ObservationAndAnalysisId` AND oauc.ObservationAndAnalysisCode = 'UnderLyingCauses' ) on inc.IncidentId = ioauc.IncidentId  ');
	SET @Col =  extractvalue(xmlData, CONCAT('//','UnderLyingCauses'));
	IF (@Col != '' AND @Col !='NULL') THEN	 
		SET @queryWhere = CONCAT(@queryWhere,'  and  `oapuc`.`ObservationAndAnalysisParamName` ' ,' like '"'%", @Col ,"%'" );
	END IF;
END IF;
-- =========================================
-- SubConditions 
-- Add join with inc_obser_ana and `observation_analysis_param` as oapsc with its where condition--> many-to-many
-- =========================================
IF ExtractValue(xmlData, 'count(//SubConditions)') >0 THEN 
	SET @selectquery = CONCAT(@selectquery,',                 group_concat(`oapsc`.`ObservationAndAnalysisParamName`
                        separator '; ') AS SubConditions ');
	SET @queryFrom = CONCAT(@queryFrom,'    left join (`inc_obser_ana` ioasc inner join `observation_analysis_param` oapsc ON `oapsc`.`ObservationAndAnalysisParamId` = `ioasc`.`ObservationAndAnalysisParamId`
inner join `observation_analysis` oasc ON `oasc`.`ObservationAndAnalysisId` = `oapsc`.`ObservationAndAnalysisId` AND oasc.ObservationAndAnalysisCode = 'SubConditions'   ) on inc.IncidentId = ioasc.IncidentId
  ');
  
	SET @Col =  extractvalue(xmlData, CONCAT('//','SubConditions'));
	IF (@Col != '' AND @Col !='NULL') THEN	 
		SET @queryWhere = CONCAT(@queryWhere,'  and  `oapsc`.`ObservationAndAnalysisParamName` ' ,' like '"'%", @Col ,"%'" );
	END IF;
END IF;
-- *******************************************************************************************************************************************************
-- =======================================================================
-- Add join with people_involved and other related tables with where conditions
-- =======================================================================
IF( ExtractValue(xmlData, 'count(//PeopleInvolvedName)') >0  or ExtractValue(xmlData, 'count(//Company)') >0 or ExtractValue(xmlData, 'count(//Position)') >0
or ExtractValue(xmlData, 'count(//Email)') >0  or ExtractValue(xmlData, 'count(//PrimaryPhone)') >0  or ExtractValue(xmlData, 'count(//AlternatePhone)') >0
or  ExtractValue(xmlData, 'count(//ExpInCurrentPostion)') >0  or ExtractValue(xmlData, 'count(//ExpOverAll)') >0 or ExtractValue(xmlData, 'count(//Age)') >0
or ExtractValue(xmlData, 'count(//HowHeInvolved)') >0  or ExtractValue(xmlData, 'count(//RoleDescription)') >0  or ExtractValue(xmlData, 'count(//CertificateId)') >0
) THEN
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join people_involved pinv on pinv.IncidentId = inc.IncidentId  ');
-- ---------------------------------------------------------
	IF( ExtractValue(xmlData, 'count(//PeopleInvolvedName)') >0) then
		SET @selectquery = CONCAT(@selectquery,', ( GROUP_CONCAT(DISTINCT if(pinv.PeopleInvolvedName ='',null, pinv.PeopleInvolvedName) separator "; ")  ) as PeopleInvolvedName');
	END IF;
-- ---------------------------------------------------------    
	IF( ExtractValue(xmlData, 'count(//Company)') >0) then
		SET @selectquery = CONCAT(@selectquery,', ( GROUP_CONCAT(DISTINCT if(pinv.Company = '', NULL, pinv.Company) SEPARATOR '; ' ) ) as Company');
	END IF;
-- ---------------------------------------------------------
	IF( ExtractValue(xmlData, 'count(//Position)') >0) then
		SET @selectquery = CONCAT(@selectquery,', (  GROUP_CONCAT(DISTINCT if( pinv.Position = '', NULL, pinv.Position) SEPARATOR '; ') ) as Position');
	END IF;
-- ---------------------------------------------------------
	IF( ExtractValue(xmlData, 'count(//Email)') >0) then
		SET @selectquery = CONCAT(@selectquery,', ( GROUP_CONCAT(DISTINCT if( pinv.Email = '' , NULL, pinv.Email) SEPARATOR '; ') ) as Email');
	END IF;
-- ---------------------------------------------------------
	IF( ExtractValue(xmlData, 'count(//PrimaryPhone)') >0) then
		SET @selectquery = CONCAT(@selectquery,', (  GROUP_CONCAT(DISTINCT if(pinv.PrimaryPhone= '', NULL, pinv.PrimaryPhone) SEPARATOR '; ') ) as PrimaryPhone');
	END IF;
-- ---------------------------------------------------------
	IF( ExtractValue(xmlData, 'count(//AlternatePhone)') >0) then
			SET @selectquery = CONCAT(@selectquery,', ( GROUP_CONCAT(DISTINCT if(pinv.AlternatePhone = '', NULL,  pinv.AlternatePhone) SEPARATOR '; ' ) ) as AlternatePhone');
	END IF;
-- ---------------------------------------------------------
	IF( ExtractValue(xmlData, 'count(//ExpInCurrentPostion)') >0) then
		SET @selectquery = CONCAT(@selectquery,', (  GROUP_CONCAT(DISTINCT if(pinv.ExpInCurrentPostion = '', NULL,  pinv.ExpInCurrentPostion) SEPARATOR '; ') ) as ExpInCurrentPostion');
	END IF;
-- ---------------------------------------------------------
	IF( ExtractValue(xmlData, 'count(//ExpOverAll)') >0) then
		SET @selectquery = CONCAT(@selectquery,', (  GROUP_CONCAT(DISTINCT if(pinv.ExpOverAll= '', NULL, pinv.ExpOverAll ) SEPARATOR '; ' ) ) as ExpOverAll');
	END IF;
-- ---------------------------------------------------------
	IF( ExtractValue(xmlData, 'count(//Age)') >0) then
		SET @selectquery = CONCAT(@selectquery,', ( GROUP_CONCAT(DISTINCT if(pinv.Age = '', NULL,  pinv.Age) SEPARATOR '; ' ) ) as Age');
	END IF;
-- ---------------------------------------------------------
	IF( ExtractValue(xmlData, 'count(//HowHeInvolved)') >0) then
		SET @selectquery = CONCAT(@selectquery,', ( GROUP_CONCAT(DISTINCT if(pinv.HowHeInvolved = '', NULL, pinv.HowHeInvolved ) SEPARATOR '; ' ) ) as HowHeInvolved');
	END IF;
-- ---------------------------------------------------------
	IF( ExtractValue(xmlData, 'count(//RoleDescription)') >0) then
		SET @selectquery = CONCAT(@selectquery,', (  GROUP_CONCAT(DISTINCT if(pinv.RoleDescription = '', NULL, pinv.RoleDescription ) SEPARATOR '; ' ) ) as RoleDescription');
	END IF;
-- =========================================
-- Add join with have_certificate and certificate with its where condition--> many-to-many
-- =========================================
	IF( ExtractValue(xmlData, 'count(//CertificateId)') >0) then
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(CertificateName separator "; ") ) as CertificateId');
        SET @queryFrom = CONCAT(@queryFrom,'      left outer join (have_certificate hv inner join  certificate  on certificate.CertificateId = hv.CertificateId
) on pinv.PeopleInvolvedId = hv.PeopleInvolvedId  ');
		SET @Col =  extractvalue(xmlData, CONCAT('//','CertificateId'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `certificate`.`CertificateName` ' ,' like '"'%", @Col ,"%'" );
		END IF;
	END IF;
END IF;
-- *******************************************************************************************************************************************************
-- =======================================================================
-- Add join with corrective actions and other related tables with where conditions
-- =======================================================================
IF( ExtractValue(xmlData, 'count(//AssignedToId)') >0  or ExtractValue(xmlData, 'count(//EmployeeId)') >0 or ExtractValue(xmlData, 'count(//TaskStatusId)') >0
or ExtractValue(xmlData, 'count(//PriorityId)') >0  or ExtractValue(xmlData, 'count(//StartDate)') >0  or ExtractValue(xmlData, 'count(//TargetEndDate)') >0
or  ExtractValue(xmlData, 'count(//ActualEndDate)') >0  or ExtractValue(xmlData, 'count(//TaskEstimatedCost)') >0 or ExtractValue(xmlData, 'count(//TaskDescription)') >0
or ExtractValue(xmlData, 'count(//OutComeFollowUp)') >0  or ExtractValue(xmlData, 'count(//DesiredResults)') >0  or ExtractValue(xmlData, 'count(//Comments)') >0
) THEN
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join corrective_action ca on ca.IncidentId = inc.IncidentId  ');
	
    IF( ExtractValue(xmlData, 'count(//AssignedToId)') >0) then
		SET @selectquery = CONCAT(@selectquery,', ( group_concat( CONCAT(`empAssigned`.`FirstName`, '  ', `empAssigned`.`LastName`) separator "; ") )as AssignedToId');
                                                        
		SET @queryFrom = CONCAT(@queryFrom,'    LEFT JOIN `employee` `empAssigned` ON `empAssigned`.`EmployeeId` = `ca`.`AssignedToId`  ');
        
        
        SET @Col =  extractvalue(xmlData, CONCAT('//','AssignedToId'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
				SET @queryWhere = CONCAT(@queryWhere,'  and  CONCAT(`empAssigned`.`FirstName`, ' ',    `empAssigned`.`LastName` )  ' ,' like '"'%", @Col ,"%'" );
		END IF;         
	END IF;
-- ---------------------------------------------------------
	IF( ExtractValue(xmlData, 'count(//EmployeeId)') >0) then
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(CONCAT(`empNotified`.`FirstName`, ' ',    `empNotified`.`LastName` ) separator "; ") ) as EmployeeId');
		SET @queryFrom = CONCAT(@queryFrom,'    LEFT JOIN ( `corrective_action_notified` `can`    JOIN `employee`  `empNotified` ON `empNotified`.`EmployeeId` = `can`.`EmployeeId`   ) ON `can`.`CorrectiveActionId` = `ca`.`CorrectiveActionId` ');
			    
		SET @Col =  extractvalue(xmlData, CONCAT('//','EmployeeId'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  CONCAT(`empNotified`.`FirstName`, ' ',    `empNotified`.`LastName` )  ' ,' like '"'%", @Col ,"%'" );
		END IF;
	END IF;
-- ---------------------------------------------------------
	IF( ExtractValue(xmlData, 'count(//TaskStatusId)') >0) then
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(CorrActStatusName separator "; ") ) as TaskStatusId');
	
		SET @queryFrom = CONCAT(@queryFrom,'    LEFT JOIN `corr_act_status` ON `corr_act_status`.`CorrActStatusId` = `ca`.`CorrActStatusId`  '); 
        
        SET @Col =  extractvalue(xmlData, CONCAT('//','TaskStatusId'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `corr_act_status`.`CorrActStatusName` ' ,' like '"'%", @Col ,"%'" );
		END IF;                                                        
    END IF;
-- ---------------------------------------------------------
	IF( ExtractValue(xmlData, 'count(//PriorityId)') >0) then
		SET @selectquery = CONCAT(@selectquery,',  group_concat(PriorityName separator "; ") as PriorityId');
        SET @queryFrom = CONCAT(@queryFrom,'    LEFT JOIN `priority` ON  `priority`.`PriorityId` = `ca`.`PriorityId`  ');  
        
        SET @Col =  extractvalue(xmlData, CONCAT('//','PriorityId'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `priority`.`PriorityName` ' ,' like '"'%", @Col ,"%'" );
		END IF;   
	END IF;
-- ---------------------------------------------------------
	IF( ExtractValue(xmlData, 'count(//StartDate)') >0) then
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(date_format(StartDate,'%m/%d/%Y') separator "; ")  ) as StartDate');
	END IF;
-- ---------------------------------------------------------
	IF( ExtractValue(xmlData, 'count(//TargetEndDate)') >0) then
		SET @selectquery = CONCAT(@selectquery,', ( group_concat( date_format(TargetEndDate,'%m/%d/%Y') separator "; ")  ) as TargetEndDate');
	END IF;
-- ----------------------------------------------------------	
	IF( ExtractValue(xmlData, 'count(//ActualEndDate)') >0) then
		SET @selectquery = CONCAT(@selectquery,', ( group_concat( date_format(ActualEndDate,'%m/%d/%Y') separator "; ")  ) as ActualEndDate');
	END IF;
-- ---------------------------------------------------------	
	IF( ExtractValue(xmlData, 'count(//TaskEstimatedCost)') >0) then
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(ca.EstimatedCost separator "; ")  ) as TaskEstimatedCost');
	END IF;
-- ---------------------------------------------------------
	IF( ExtractValue(xmlData, 'count(//TaskDescription)') >0) then
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(TaskDescription separator "; ")  ) as TaskDescription');
	END IF;
-- ---------------------------------------------------------
	IF( ExtractValue(xmlData, 'count(//OutComeFollowUp)') >0) then
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(OutComeFollowUp separator "; ")  ) as OutComeFollowUp');
	END IF;
-- ---------------------------------------------------------
	IF( ExtractValue(xmlData, 'count(//DesiredResults)') >0) then
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(CASE `ca`.`DesiredResults`  WHEN '0' THEN 'No' WHEN '1' THEN 'Yes'   END  separator "; ")  ) as DesiredResults');
	END IF;
-- ---------------------------------------------------------
	IF( ExtractValue(xmlData, 'count(//Comments)') >0) then
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(Comments separator "; ") ) as Comments');
	END IF;
END IF;
/* impact type part   */
set @impactWhere='  ';
IF(ExtractValue(xmlData, 'count(//ImpactTypeId)') >0 ) THEN
	-- SET @queryFrom = CONCAT(@queryFrom,'    left outer join inc_impact_type_view on inc_impact_type_view.IncidentId = inc.IncidentId  ');
	
	SET @selectquery = CONCAT(@selectquery,',    CONCAT_WS(', ',
                            (SELECT DISTINCT
                                    GROUP_CONCAT(`impact_type`.`ImpactTypeName`
                                            SEPARATOR ', ')
                                FROM
                                    ((`impact`
                                    JOIN `impact_sub_type` ON ((`impact_sub_type`.`ImpactSubTypeId` = `impact`.`ImpactSubTypeId`)))
                                    JOIN `impact_type` ON ((`impact_sub_type`.`ImpactTypeId` = `impact_type`.`ImpactTypeId`)))
                                WHERE
                                    (`impact`.`IncidentId` = `inc`.`IncidentId`)) ,
                            (SELECT DISTINCT
                                    GROUP_CONCAT(`impact_type`.`ImpactTypeName`
                                             SEPARATOR ', ')
                                FROM
                                    ((`injury`
                                    JOIN `impact_sub_type` ON ((`impact_sub_type`.`ImpactSubTypeId` = `injury`.`ImpactSubTypeId`)))
                                    JOIN `impact_type` ON ((`impact_sub_type`.`ImpactTypeId` = `impact_type`.`ImpactTypeId`)))
                                WHERE
                                    (`injury`.`IncidentId` = `inc`.`IncidentId`)) ,
                            (SELECT DISTINCT
                                    GROUP_CONCAT(`impact_type`.`ImpactTypeName`
                                             SEPARATOR ', ')
                                FROM
                                    ((`illness`
                                    JOIN `impact_sub_type` ON ((`impact_sub_type`.`ImpactSubTypeId` = `illness`.`ImpactSubTypeId`)))
                                    JOIN `impact_type` ON ((`impact_sub_type`.`ImpactTypeId` = `impact_type`.`ImpactTypeId`)))
                                WHERE
                                    (`illness`.`IncidentId` = `inc`.`IncidentId`)) ,
                            (SELECT DISTINCT
                                    GROUP_CONCAT(`impact_type`.`ImpactTypeName`
                                             SEPARATOR ', ')
                                FROM
                                    ((`spill_release`
                                    JOIN `impact_sub_type` ON ((`impact_sub_type`.`ImpactSubTypeId` = `spill_release`.`ImpactSubTypeId`)))
                                    JOIN `impact_type` ON ((`impact_sub_type`.`ImpactTypeId` = `impact_type`.`ImpactTypeId`)))
                                WHERE
                                    (`spill_release`.`IncidentId` = `inc`.`IncidentId`)) ,
                            (SELECT DISTINCT
                                    GROUP_CONCAT(`impact_type`.`ImpactTypeName`
                                             SEPARATOR ', ')
                                FROM
                                    ((`vehicle_damage`
                                    JOIN `impact_sub_type` ON ((`impact_sub_type`.`ImpactSubTypeId` = `vehicle_damage`.`ImpactSubTypeId`)))
                                    JOIN `impact_type` ON ((`impact_sub_type`.`ImpactTypeId` = `impact_type`.`ImpactTypeId`)))
                                WHERE
                                    (`vehicle_damage`.`IncidentId` = `inc`.`IncidentId`)) ,
                            (SELECT DISTINCT
                                    GROUP_CONCAT(`impact_type`.`ImpactTypeName`
                                             SEPARATOR ', ')
                                FROM
                                    ((`traffic_violation`
                                    JOIN `impact_sub_type` ON ((`impact_sub_type`.`ImpactSubTypeId` = `traffic_violation`.`ImpactSubTypeId`)))
                                    JOIN `impact_type` ON ((`impact_sub_type`.`ImpactTypeId` = `impact_type`.`ImpactTypeId`)))
                                WHERE
                                    (`traffic_violation`.`IncidentId` = `inc`.`IncidentId`)))
             AS `ImpactTypeId`');	
            
            
            
		
	
End If;
/* impact sub type part   */
IF(ExtractValue(xmlData, 'count(//ImpactSubTypeId)') >0 ) THEN
SET @selectquery = CONCAT(@selectquery,',     (SELECT 
                CONCAT_WS(', ',
                            (SELECT DISTINCT
                                    GROUP_CONCAT(`impact_sub_type`.`ImpactSubTypeName`
                                            SEPARATOR ', ')
                                FROM
                                    (`impact`
                                    JOIN `impact_sub_type` ON ((`impact_sub_type`.`ImpactSubTypeId` = `impact`.`ImpactSubTypeId`)))
                                WHERE
                                    (`impact`.`IncidentId` = `inc`.`IncidentId`)),
                            (SELECT DISTINCT
                                    GROUP_CONCAT(`impact_sub_type`.`ImpactSubTypeName`
                                            SEPARATOR ', ')
                                FROM
                                    (`injury`
                                    JOIN `impact_sub_type` ON ((`impact_sub_type`.`ImpactSubTypeId` = `injury`.`ImpactSubTypeId`)))
                                WHERE
                                    (`injury`.`IncidentId` = `inc`.`IncidentId`)),
                            (SELECT DISTINCT
                                    GROUP_CONCAT(`impact_sub_type`.`ImpactSubTypeName`
                                             SEPARATOR ', ')
                                FROM
                                    (`illness`
                                    JOIN `impact_sub_type` ON ((`impact_sub_type`.`ImpactSubTypeId` = `illness`.`ImpactSubTypeId`)))
                                WHERE
                                    (`illness`.`IncidentId` = `inc`.`IncidentId`)),
                            (SELECT DISTINCT
                                    GROUP_CONCAT(`impact_sub_type`.`ImpactSubTypeName`
                                             SEPARATOR ', ')
                                FROM
                                    (`spill_release`
                                    JOIN `impact_sub_type` ON ((`impact_sub_type`.`ImpactSubTypeId` = `spill_release`.`ImpactSubTypeId`)))
                                WHERE
                                    (`spill_release`.`IncidentId` = `inc`.`IncidentId`)),
                            (SELECT DISTINCT
                                    GROUP_CONCAT(`impact_sub_type`.`ImpactSubTypeName`
                                             SEPARATOR ', ')
                                FROM
                                    (`vehicle_damage`
                                    JOIN `impact_sub_type` ON ((`impact_sub_type`.`ImpactSubTypeId` = `vehicle_damage`.`ImpactSubTypeId`)))
                                WHERE
                                    (`vehicle_damage`.`IncidentId` = `inc`.`IncidentId`)),
                            (SELECT DISTINCT
                                    GROUP_CONCAT(`impact_sub_type`.`ImpactSubTypeName`
                                             SEPARATOR ', ')
                                FROM
                                    (`traffic_violation`
                                    JOIN `impact_sub_type` ON ((`impact_sub_type`.`ImpactSubTypeId` = `traffic_violation`.`ImpactSubTypeId`)))
                                WHERE
                                    (`traffic_violation`.`IncidentId` = `inc`.`IncidentId`)))
            ) AS `ImpactSubTypeId`  ');	
	-- SET @queryFrom = CONCAT(@queryFrom,'    left outer join inc_impact_subtype_view on inc_impact_subtype_view.IncidentId = inc.IncidentId  ');	
 -- 	SET @selectquery = CONCAT(@selectquery,', inc_impact_subtype_view.ImpactSubTypeId ');	
	
END IF;
IF(ExtractValue(xmlData, 'count(//ExtAgencyId)') >0 ) THEN
	-- SET @queryFrom = CONCAT(@queryFrom,'    left outer join inc_impact_extagency_view on inc_impact_extagency_view.IncidentId = inc.IncidentId  ');	
	SET @selectquery = CONCAT(@selectquery,' ,         (SELECT CONCAT_WS(', ',
                (SELECT DISTINCT
                        GROUP_CONCAT(`external_agency`.`ExtAgencyName`
                                 SEPARATOR '; ')
                    FROM
                        ((`impact`
                        LEFT JOIN `impacts_ext_agency` ON ((`impacts_ext_agency`.`ImpactId` = `impact`.`ImpactId`)))
                        LEFT JOIN `external_agency` ON ((`external_agency`.`ExtAgencyId` = `impacts_ext_agency`.`ExtAgencyId`)))
                    WHERE
                        (`impact`.`IncidentId` = `inc`.`IncidentId`)),
                (SELECT DISTINCT
                        GROUP_CONCAT(`external_agency`.`ExtAgencyName`
                                 SEPARATOR '; ')
                    FROM
                        ((`injury`
                        LEFT JOIN `impacts_ext_agency` ON ((`impacts_ext_agency`.`InjuryId` = `injury`.`InjuryId`)))
                        LEFT JOIN `external_agency` ON ((`external_agency`.`ExtAgencyId` = `impacts_ext_agency`.`ExtAgencyId`)))
                    WHERE
                        (`injury`.`IncidentId` = `inc`.`IncidentId`)),
                (SELECT DISTINCT
                        GROUP_CONCAT(`external_agency`.`ExtAgencyName`
                                 SEPARATOR '; ')
                    FROM
                        ((`illness`
                        LEFT JOIN `impacts_ext_agency` ON ((`impacts_ext_agency`.`IllnessId` = `illness`.`IllnessId`)))
                        LEFT JOIN `external_agency` ON ((`external_agency`.`ExtAgencyId` = `impacts_ext_agency`.`ExtAgencyId`)))
                    WHERE
                        (`illness`.`IncidentId` = `inc`.`IncidentId`)),
                (SELECT DISTINCT
                        GROUP_CONCAT(`external_agency`.`ExtAgencyName`
                                 SEPARATOR '; ')
                    FROM
                        ((`spill_release`
                        LEFT JOIN `impacts_ext_agency` ON ((`impacts_ext_agency`.`SpillReleaseId` = `spill_release`.`SpillReleaseId`)))
                        LEFT JOIN `external_agency` ON ((`external_agency`.`ExtAgencyId` = `impacts_ext_agency`.`ExtAgencyId`)))
                    WHERE
                        (`spill_release`.`IncidentId` = `inc`.`IncidentId`)),
                (SELECT DISTINCT
                        GROUP_CONCAT(`external_agency`.`ExtAgencyName`
                                 SEPARATOR '; ')
                    FROM
                        ((`vehicle_damage`
                        LEFT JOIN `impacts_ext_agency` ON ((`impacts_ext_agency`.`VehicleDamageId` = `vehicle_damage`.`VehicleDamageId`)))
                        LEFT JOIN `external_agency` ON ((`external_agency`.`ExtAgencyId` = `impacts_ext_agency`.`ExtAgencyId`)))
                    WHERE
                        (`vehicle_damage`.`IncidentId` = `inc`.`IncidentId`)),
                (SELECT DISTINCT
                        GROUP_CONCAT(`external_agency`.`ExtAgencyName`
                                 SEPARATOR '; ')
                    FROM
                        ((`traffic_violation`
                        LEFT JOIN `impacts_ext_agency` ON ((`impacts_ext_agency`.`TrafficViolationId` = `traffic_violation`.`TrafficViolationId`)))
                        LEFT JOIN `external_agency` ON ((`external_agency`.`ExtAgencyId` = `impacts_ext_agency`.`ExtAgencyId`)))
                    WHERE
                        (`traffic_violation`.`IncidentId` = `inc`.`IncidentId`)))) AS `ExtAgencyId`   ');	
	
END IF;
 SET @Col =  extractvalue(xmlData, CONCAT('//','ImpactTypeId'));
 IF (@Col != '' AND @Col !='NULL') THEN	 
	SET @impactWhere = CONCAT(@impactWhere,'  and  `ImpactTypeId` ' ,' like '"'%", @Col ,"%'" );
END IF;      
SET @queryhave = CONCAT(@queryhave, @impactWhere);
 SET @Col =  extractvalue(xmlData, CONCAT('//','ImpactSubTypeId'));
 IF (@Col != '' AND @Col !='NULL') THEN	 
	SET @impactWhere = CONCAT(@impactWhere,'  and  `ImpactSubTypeId` ' ,' like '"'%", @Col ,"%'" );
END IF;      
SET @queryhave = CONCAT(@queryhave, @impactWhere);
 
 SET @Col =  extractvalue(xmlData, CONCAT('//','ExtAgencyId'));
 IF (@Col != '' AND @Col !='NULL') THEN	 
	SET @impactWhere = CONCAT(@impactWhere,'  and  `ExtAgencyId` ' ,' like '"'%", @Col ,"%'" );
END IF;      
SET @queryhave = CONCAT(@queryhave, @impactWhere);
/* impact part   */
IF (ExtractValue(xmlData, 'count(//ImpactDescription)') >0 OR ExtractValue(xmlData, 'count(//IntEmployeeName1)') >0 
	OR ExtractValue(xmlData, 'count(//IntEmployeeDept1)') >0 OR ExtractValue(xmlData, 'count(//IntEmployeeName2)') >0
	OR ExtractValue(xmlData, 'count(//IntEmployeeDept2)') >0 OR ExtractValue(xmlData, 'count(//IntEmployeeName3)') >0 
	OR ExtractValue(xmlData, 'count(//IntEmployeeDept3)') >0 OR ExtractValue(xmlData, 'count(//CustomOpenTxt)') >0 
	OR ExtractValue(xmlData, 'count(//PrimRespondName)') >0 OR ExtractValue(xmlData, 'count(//ImpactEstimatedCost)') >0) THEN
    
	-- SET @queryFrom = CONCAT(@queryFrom,'    left outer join  impact_common_view on impact_common_view.IncidentId = inc.IncidentId  ');
	SET @queryFrom = CONCAT(@queryFrom,'   LEFT JOIN `injury` `inj` ON `inc`.`IncidentId` = `inj`.`IncidentId`
										LEFT JOIN `impact` `imp` ON `inc`.`IncidentId` = `imp`.`IncidentId`
										LEFT JOIN `illness` `ill` ON `inc`.`IncidentId` = `ill`.`IncidentId`
										LEFT JOIN `spill_release` `sp` ON `inc`.`IncidentId` = `sp`.`IncidentId`
										LEFT JOIN `vehicle_damage` `vd` ON `inc`.`IncidentId` = `vd`.`IncidentId`
										LEFT JOIN `traffic_violation` `tv` ON `inc`.`IncidentId` = `tv`.`IncidentId`  ');
    
	
    IF(ExtractValue(xmlData, 'count(//IntEmployeeName1)') >0 )then 	SET @selectquery = CONCAT(@selectquery,', ( SELECT (   CONCAT_WS(', ',
											`inj`.`IntEmployeeName1`,
											`imp`.`IntEmployeeName1`,
											`ill`.`IntEmployeeName1`,
											`sp`.`IntEmployeeName1`,
											`vd`.`IntEmployeeName1`,
											`tv`.`IntEmployeeName1`) )) AS `IntEmployeeName1` ');	END IF;
                                            
	IF(ExtractValue(xmlData, 'count(//IntEmployeeDept1)') >0 )then 	SET @selectquery = CONCAT(@selectquery,',  ( SELECT (   CONCAT_WS(', ',
											`inj`.`IntEmployeeDept1`,
											`imp`.`IntEmployeeDept1`,
											`ill`.`IntEmployeeDept1`,
											`sp`.`IntEmployeeDept1`,
											`vd`.`IntEmployeeDept1`,
											`tv`.`IntEmployeeDept1`) )) AS `IntEmployeeDept1`  ');	END IF;
	IF(ExtractValue(xmlData, 'count(//IntEmployeeName2)') >0 )then 	SET @selectquery = CONCAT(@selectquery,',  ( SELECT (   CONCAT_WS(', ',
											`inj`.`IntEmployeeName2`,
											`imp`.`IntEmployeeName2`,
											`ill`.`IntEmployeeName2`,
											`sp`.`IntEmployeeName2`,
											`vd`.`IntEmployeeName2`,
											`tv`.`IntEmployeeName2`) )) AS `IntEmployeeName2`  ');	END IF;
	IF(ExtractValue(xmlData, 'count(//IntEmployeeDept2)') >0 )then 	SET @selectquery = CONCAT(@selectquery,',  ( SELECT (   CONCAT_WS(', ',
											`inj`.`IntEmployeeDept2`,
											`imp`.`IntEmployeeDept2`,
											`ill`.`IntEmployeeDept2`,
											`sp`.`IntEmployeeDept2`,
											`vd`.`IntEmployeeDept2`,
											`tv`.`IntEmployeeDept2`) )) AS `IntEmployeeDept2`  ');	END IF;
	IF(ExtractValue(xmlData, 'count(//IntEmployeeName3)') >0 )then 	SET @selectquery = CONCAT(@selectquery,',  ( SELECT (   CONCAT_WS(', ',
											`inj`.`IntEmployeeName3`,
											`imp`.`IntEmployeeName3`,
											`ill`.`IntEmployeeName3`,
											`sp`.`IntEmployeeName3`,
											`vd`.`IntEmployeeName3`,
											`tv`.`IntEmployeeName3`) )) AS `IntEmployeeName3` ');	END IF;
	IF(ExtractValue(xmlData, 'count(//IntEmployeeDept3)') >0 )then 	SET @selectquery = CONCAT(@selectquery,',  ( SELECT (   CONCAT_WS(', ',
											`inj`.`IntEmployeeDept3`,
											`imp`.`IntEmployeeDept3`,
											`ill`.`IntEmployeeDept3`,
											`sp`.`IntEmployeeDept3`,
											`vd`.`IntEmployeeDept3`,
											`tv`.`IntEmployeeDept3`) )) AS `IntEmployeeDept3`  ');	END IF;
	IF(ExtractValue(xmlData, 'count(//PrimRespondName)') >0 )then 	SET @selectquery = CONCAT(@selectquery,',  ( SELECT (   CONCAT_WS(', ',
											`inj`.`PrimRespondName`,
											`imp`.`PrimRespondName`,
											`ill`.`PrimRespondName`,
											`sp`.`PrimRespondName`,
											`vd`.`PrimRespondName`,
											`tv`.`PrimRespondName`) )) AS `PrimRespondName`  ');	END IF;
	IF(ExtractValue(xmlData, 'count(//ImpactDescription)') >0 )then 	SET @selectquery = CONCAT(@selectquery,',  ( SELECT (   CONCAT_WS(', ',
											`inj`.`Description`,
											`imp`.`Description`,
											`ill`.`Description`,
											`sp`.`Description`,
											`vd`.`Description`,
											`tv`.`Description`) )) AS `ImpactDescription`  ');	END IF;
	IF(ExtractValue(xmlData, 'count(//ImpactEstimatedCost)') >0 )then 	SET @selectquery = CONCAT(@selectquery,',  ( SELECT (   CONCAT_WS(', ',
											`inj`.`EstimatedCost`,
											`imp`.`EstimatedCost`,
											`ill`.`EstimatedCost`,
											`sp`.`EstimatedCost`,
											`vd`.`EstimatedCost`,
											`tv`.`EstimatedCost`) )) AS `ImpactEstimatedCost` ');	END IF;
 SET @Col =  extractvalue(xmlData, CONCAT('//','ImpactDescription'));
 IF (@Col != '' AND @Col !='NULL') THEN	 
	SET @impactWhere = CONCAT(@impactWhere,'  and  `ImpactDescription` ' ,' like '"'%", @Col ,"%'" );
END IF;      
SET @queryhave = CONCAT(@queryhave, @impactWhere);
 SET @Col =  extractvalue(xmlData, CONCAT('//','IntEmployeeName1'));
 IF (@Col != '' AND @Col !='NULL') THEN	 
	SET @impactWhere = CONCAT(@impactWhere,'  and  `IntEmployeeName1` ' ,' like '"'%", @Col ,"%'" );
END IF;      
SET @queryhave = CONCAT(@queryhave, @impactWhere);
 SET @Col =  extractvalue(xmlData, CONCAT('//','IntEmployeeDept1'));
 IF (@Col != '' AND @Col !='NULL') THEN	 
	SET @impactWhere = CONCAT(@impactWhere,'  and  `IntEmployeeDept1` ' ,' like '"'%", @Col ,"%'" );
END IF;      
SET @queryhave = CONCAT(@queryhave, @impactWhere);
 SET @Col =  extractvalue(xmlData, CONCAT('//','IntEmployeeName2'));
 IF (@Col != '' AND @Col !='NULL') THEN	 
	SET @impactWhere = CONCAT(@impactWhere,'  and  `IntEmployeeName2` ' ,' like '"'%", @Col ,"%'" );
END IF;      
SET @queryhave = CONCAT(@queryhave, @impactWhere);
 SET @Col =  extractvalue(xmlData, CONCAT('//','IntEmployeeDept2'));
 IF (@Col != '' AND @Col !='NULL') THEN	 
	SET @impactWhere = CONCAT(@impactWhere,'  and  `IntEmployeeDept2` ' ,' like '"'%", @Col ,"%'" );
END IF;      
SET @queryhave = CONCAT(@queryhave, @impactWhere);
 SET @Col =  extractvalue(xmlData, CONCAT('//','IntEmployeeName3'));
 IF (@Col != '' AND @Col !='NULL') THEN	 
	SET @impactWhere = CONCAT(@impactWhere,'  and  `IntEmployeeName3` ' ,' like '"'%", @Col ,"%'" );
END IF;      
SET @queryhave = CONCAT(@queryhave, @impactWhere);
 SET @Col =  extractvalue(xmlData, CONCAT('//','IntEmployeeDept3'));
 IF (@Col != '' AND @Col !='NULL') THEN	 
	SET @impactWhere = CONCAT(@impactWhere,'  and  `IntEmployeeDept3` ' ,' like '"'%", @Col ,"%'" );
END IF;      
SET @queryhave = CONCAT(@queryhave, @impactWhere);
 SET @Col =  extractvalue(xmlData, CONCAT('//','PrimRespondName'));
 IF (@Col != '' AND @Col !='NULL') THEN	 
	SET @impactWhere = CONCAT(@impactWhere,'  and  `PrimRespondName` ' ,' like '"'%", @Col ,"%'" );
END IF;      
SET @queryhave = CONCAT(@queryhave, @impactWhere);
SET @EstimatedCostTo =  extractvalue(xmlData, '//ImpactEstimatedCostTo');
SET @EstimatedCostFrom =  extractvalue(xmlData, '//ImpactEstimatedCostFrom');
IF( @EstimatedCostTo !='' ) THEN
	SET @queryhave = CONCAT(@queryhave,' AND  ImpactEstimatedCost  BETWEEN ', @EstimatedCostFrom, ' and ', @EstimatedCostTo);
ELSE 
	IF( @EstimatedCostFrom !=''  and @EstimatedCostFrom != 'NULL')	 THEN
set  @EstimatedCostFrom  = (replace(@EstimatedCostFrom, '&lt;', '<'));
set  @EstimatedCostFrom  = (replace(@EstimatedCostFrom, '&gt;', '>'));
		SET @queryhave = CONCAT(@queryhave,' AND  ImpactEstimatedCost  ', @EstimatedCostFrom);
	END IF;
END IF;
END IF;
/* injury part   */
IF(ExtractValue(xmlData, 'count(//InjuryTypeId)') >0 OR ExtractValue(xmlData, 'count(//BodyPartId)') >0 
OR ExtractValue(xmlData, 'count(//BodyAreaId)') >0 OR ExtractValue(xmlData, 'count(//PersonalInjured)') >0 
OR ExtractValue(xmlData, 'count(//ContactCodeId)') >0 OR ExtractValue(xmlData, 'count(//RecordableId)') >0
OR ExtractValue(xmlData, 'count(//InitialTreatmentId)') >0 OR ExtractValue(xmlData, 'count(//InjuryExtAgencyId)') >0 
OR ExtractValue(xmlData, 'count(//LostTimeEnd)') >0 OR ExtractValue(xmlData, 'count(//TotalDaysOff)') >0 
OR ExtractValue(xmlData, 'count(//InjuryDescription)') >0 OR ExtractValue(xmlData, 'count(//AdjustmentDays)') >0
OR ExtractValue(xmlData, 'count(//LostTimeStart)') >0) THEN
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join injury on injury.IncidentId = inc.IncidentId  ');
	
	IF(ExtractValue(xmlData, 'count(//InjuryTypeId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(InjuryTypeName separator "; ")  ) as InjuryTypeId' );
              SET @queryFrom = CONCAT(@queryFrom,'    left outer join ( `injury_type_injury` join  `injury_type` on  `injury_type`.`InjuryTypeId` = `injury_type_injury`.`InjuryTypeId`)  on  `injury_type_injury`.`InjuryId` = `injury`.`InjuryId`  ');
         
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//BodyPartId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(BodyPartName separator "; ")  ) as BodyPartId' );
		SET @queryFrom = CONCAT(@queryFrom,'     left outer join ( `body_part_injury` join  `body_part` on `body_part`.`BodyPartId` = `body_part_injury`.`BodyPartId` ) on `body_part_injury`.`InjuryId` = `injury`.`InjuryId` ');
       
	END IF;
	
	
		IF(ExtractValue(xmlData, 'count(//BodyAreaId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(BodyAreaName separator "; ")  ) as BodyAreaId' );	
        SET @queryFrom = CONCAT(@queryFrom,'    left outer join (  `body_area_injury` join `body_area` on `body_area`.`BodyAreaId` = `body_area_injury`.`BodyAreaId`) on `body_area_injury`.`InjuryId` = `injury`.`InjuryId`      ');
      --  SET @queryFrom = CONCAT(@queryFrom,'    left outer join  `body_area` on `body_area`.`BodyAreaId` = `body_area_injury`.`BodyAreaId`  ');
        
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//PersonalInjured)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(injury.PersonalInjuredName separator "; ")  ) as PersonalInjured' );	
	
		
	 SET @Col =  extractvalue(xmlData, CONCAT('//','PersonalInjured'));
	 IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  injury.`PersonalInjuredName` ' ,' like '"'%", @Col ,"%'" );
	END IF; 
   
    
    END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//ContactCodeId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(ContactCodeName separator "; ")  ) as ContactCodeId' );	
        SET @queryFrom = CONCAT(@queryFrom,'    left outer join  `contact_code` on `contact_code`.`ContactCodeId` = `injury`.`ContactCodeId`  ');
         
           SET @Col =  extractvalue(xmlData, CONCAT('//','ContactCodeId'));
		 IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  contact_code.`ContactCodeName` ' ,' like '"'%", @Col ,"%'" );
		END IF; 
         
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//RecordableId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(RecordableName separator "; ")  ) as RecordableId' );	
        SET @queryFrom = CONCAT(@queryFrom,'    left outer join  `injury_recordable` on `injury_recordable`.`RecordableId` = `injury`.`RecordableId` ');        
        
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//InitialTreatmentId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(`initial_treatment`.InitialTreatmentName separator "; ")  ) as InitialTreatmentId' );	
        SET @queryFrom = CONCAT(@queryFrom,'    left outer join  `initial_treatment` on  `initial_treatment`.`InitialTreatmentId` = `injury`.`InitialTreatmentId` ');   
                
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//InjuryExtAgencyId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(ContactAgencyName separator "; ")  ) as InjuryExtAgencyId' );	
        SET @queryFrom = CONCAT(@queryFrom,'    left outer join  `contact_agency` on  `contact_agency`.`ContactAgencyId` = `injury`.`ContactAgencyId` ');   
	
    
      SET @Col =  extractvalue(xmlData, CONCAT('//','TaskStatusId'));
		 IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `contact_agency`.`ContactAgencyName` ' ,' like '"'%", @Col ,"%'" );
		END IF;
    
    END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//AdjustmentDays)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(`injury`.AdjustmentDays separator "; ")  ) as AdjustmentDays' );	
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//TotalDaysOff)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(`injury`.TotalDaysOff separator "; ")  ) as TotalDaysOff' );	
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//InjuryDescription)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(`injury`.InjuryDescription separator "; ")  ) as InjuryDescription' );	
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//LostTimeEnd)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(date_format(`injury`.LostTimeEnd,'%m/%d/%Y') separator "; ")  ) as LostTimeEnd' );	
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//LostTimeStart)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(date_format(`injury`.LostTimeStart,'%m/%d/%Y') separator "; ")  ) as LostTimeStart' );	
	END IF;
	
END IF;
/* Illness part   */
IF(ExtractValue(xmlData, 'count(//IllnessDescription)') >0 OR ExtractValue(xmlData, 'count(//Illness_RestrictedWorkId)') >0 
OR ExtractValue(xmlData, 'count(//Illness_PersonalInjured)') >0 OR ExtractValue(xmlData, 'count(//Illness_InitialTreatmentId)') >0 
OR ExtractValue(xmlData, 'count(//ContactCodeId)') >0 OR ExtractValue(xmlData, 'count(//RecordableId)') >0
OR ExtractValue(xmlData, 'count(//Illness_AdjustmentDays)') >0 OR ExtractValue(xmlData, 'count(//Illness_AdjustmentDays)') >0 
OR ExtractValue(xmlData, 'count(//Illness_LostTimeEnd)') >0 OR ExtractValue(xmlData, 'count(//Illness_LostTimeStart)') >0 
OR ExtractValue(xmlData, 'count(//Illness_TotalDaysOff)') >0 OR ExtractValue(xmlData, 'count(//SymptomsId)') >0 ) THEN
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join illness on illness.IncidentId = inc.IncidentId  ');
	
	IF(ExtractValue(xmlData, 'count(//IllnessDescription)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(illness.IllnessDescription separator "; ") ) as IllnessDescription' );	
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//Illness_RestrictedWorkId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(`restricted_work`.RestrictedWorkName separator "; ") ) as Illness_RestrictedWorkId' );	
        SET @queryFrom = CONCAT(@queryFrom,'    left outer join restricted_work on `restricted_work`.`RestrictedWorkId` = `illness`.`RestrictedWorkId` ');
	END IF;
	
	
		IF(ExtractValue(xmlData, 'count(//Illness_PersonalInjured)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(PersonalAfflictedName separator "; ") ) as Illness_PersonalInjured' );	
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//Illness_InitialTreatmentId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(`illt`.InitialTreatmentName separator "; "))  as Illness_InitialTreatmentId' );
        SET @queryFrom = CONCAT(@queryFrom,'    left outer join initial_treatment  illt on `illt`.`InitialTreatmentId` = `illness`.`InitialTreatmentId` ');
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//Illness_AdjustmentDays)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(`illness`.AdjustmentDays separator "; ") ) as Illness_AdjustmentDays' );	
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//SymptomsId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(`symptoms`.`Description` separator "; ") ) as SymptomsId' );	
		SET @queryFrom = CONCAT(@queryFrom,'    left outer join ( illness_symptoms  join symptoms on symptoms.SymptomsId = illness_symptoms.SymptomsId) on `illness_symptoms`.`IllnessId` = `illness`.`IllnessId` ');
         
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//Illness_TotalDaysOff)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(`illness`.TotalDaysOff separator "; ") ) as Illness_TotalDaysOff' );	
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//Illness_LostTimeEnd)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(date_format(`illness`.LostTimeEnd,'%m/%d/%Y') separator "; ") ) as Illness_LostTimeEnd' );	
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//Illness_LostTimeStart)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(date_format(`illness`.LostTimeStart,'%m/%d/%Y') separator "; ") ) as Illness_LostTimeStart' );	
	END IF;
	
END IF;
/* traffic_violation part   */
IF(ExtractValue(xmlData, 'count(//TrafficDriverName)') >0 OR ExtractValue(xmlData, 'count(//TrafficDriverLicence)') >0 
OR ExtractValue(xmlData, 'count(//TrafficVehicleTypeId)') >0 OR ExtractValue(xmlData, 'count(//TrafficVehicleLicence)') >0 
OR ExtractValue(xmlData, 'count(//Details)') >0 OR ExtractValue(xmlData, 'count(//ValueOfFine)') >0
OR ExtractValue(xmlData, 'count(//TicketNumber)') >0 OR ExtractValue(xmlData, 'count(//HowDidThatOccur)') >0   ) THEN
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join traffic_violation on traffic_violation.IncidentId = inc.IncidentId  ');
	
	IF(ExtractValue(xmlData, 'count(//TrafficDriverName)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(`traffic_violation`.DriverName separator "; ")  ) as TrafficDriverName' );	
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//TrafficDriverLicence)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(`traffic_violation`.DriverLicence separator "; ")  ) as TrafficDriverLicence' );	
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//TrafficVehicleTypeId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(tvt.VehicleTypeName separator "; ")  ) as TrafficVehicleTypeId' );	
        SET @queryFrom = CONCAT(@queryFrom,'    left outer join vehicle_type tvt on `tvt`.`VehicleTypeId` = `traffic_violation`.`VehicleTypeId` ');
        
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//TrafficVehicleLicence)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(`traffic_violation`.VehicleLicence separator "; ")  ) as TrafficVehicleLicence' );	
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//Details)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(Details separator "; ")  ) as Details' );	
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//ValueOfFine)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(ValueOfFine separator "; ")  ) as ValueOfFine' );	
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//TicketNumber)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(TicketNumber separator "; ")  ) as TicketNumber' );	
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//HowDidThatOccur)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(HowDidThatOccur separator "; ")  ) as HowDidThatOccur' );	
	END IF;
	
END IF;
/* vehicle_damage part   */
IF(ExtractValue(xmlData, 'count(//DamageDriverName)') >0 OR ExtractValue(xmlData, 'count(//DamageDriverLicence)') >0 
OR ExtractValue(xmlData, 'count(//DamageVehicleTypeId)') >0 OR ExtractValue(xmlData, 'count(//DamageVehicleLicence)') >0 
OR ExtractValue(xmlData, 'count(//HowDidThatDone)') >0 OR ExtractValue(xmlData, 'count(//DamageDescription)') >0 ) THEN
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join vehicle_damage on vehicle_damage.IncidentId = inc.IncidentId  ');
	
	IF(ExtractValue(xmlData, 'count(//DamageDriverName)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(vehicle_damage.DriverName separator "; ") ) as DamageDriverName' );	
	
		SET @Col =  extractvalue(xmlData, CONCAT('//','DamageDriverName'));
		 IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @impactWhere = CONCAT(@impactWhere,'  and  vehicle_damage.DriverName ' ,' like '"'%", @Col ,"%'" );
		END IF;   
    
    END IF;
	
	IF(ExtractValue(xmlData, 'count(//DamageDriverLicence)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(vehicle_damage.DriverLicence separator "; ") ) as DamageDriverLicence' );	
        
        SET @Col =  extractvalue(xmlData, CONCAT('//','DamageDriverLicence'));
		 IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @impactWhere = CONCAT(@impactWhere,'  and  vehicle_damage.DriverLicence  ' ,' like '"'%", @Col ,"%'" );
		END IF;   
       
        
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//DamageVehicleTypeId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(dvt.VehicleTypeName separator "; ") ) as DamageVehicleTypeId' );	
		SET @queryFrom = CONCAT(@queryFrom,'    left outer join vehicle_type dvt on `dvt`.`VehicleTypeId` = `vehicle_damage`.`VehicleTypeId` ');
        
        
		 SET @Col =  extractvalue(xmlData, CONCAT('//','DamageVehicleTypeId'));
		 IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @impactWhere = CONCAT(@impactWhere,'  and  dvt.VehicleTypeName  ' ,' like '"'%", @Col ,"%'" );
		END IF;   
       
       
         
	END IF;	
	
	IF(ExtractValue(xmlData, 'count(//DamageVehicleLicence)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(vehicle_damage.VehicleLicence separator "; ") ) as DamageVehicleLicence' );	
        
         SET @Col =  extractvalue(xmlData, CONCAT('//','DamageVehicleLicence'));
		 IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @impactWhere = CONCAT(@impactWhere,'  and  vehicle_damage.VehicleLicence  ' ,' like '"'%", @Col ,"%'" );
		END IF;   
        
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//HowDidThatDone)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(HowDidThatDone separator "; ") ) as HowDidThatDone' );	
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//DamageDescription)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat( vehicle_damage.DamageDescription separator "; ") ) as DamageDescription' );	
        
          
		SET @Col =  extractvalue(xmlData, CONCAT('//','DamageDescription'));
		 IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @impactWhere = CONCAT(@impactWhere,'  and  vehicle_damage.DamageDescription   ' ,' like '"'%", @Col ,"%'" );
		END IF; 
        
        
	END IF;	
	
END IF;
/* spill_release part   */
IF(ExtractValue(xmlData, 'count(//SourceId)') >0 OR ExtractValue(xmlData, 'count(//DurationValue)') >0 
OR ExtractValue(xmlData, 'count(//DurationUnitId)') >0 OR ExtractValue(xmlData, 'count(//QuantityValue)') >0 
OR ExtractValue(xmlData, 'count(//QuantityUnitId)') >0 OR ExtractValue(xmlData, 'count(//QuantityRecoveredValue)') >0 
OR ExtractValue(xmlData, 'count(//RecoveredUnitId)') >0 OR ExtractValue(xmlData, 'count(//WhatWasIt)') >0 OR ExtractValue(xmlData, 'count(//HowDidSROccur)') >0 
OR ExtractValue(xmlData, 'count(//IsReportable)') >0 OR ExtractValue(xmlData, 'count(//ImpactsExtAgencyId)') >0 ) THEN
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join spill_release on spill_release.IncidentId = inc.IncidentId  ');
	
	IF(ExtractValue(xmlData, 'count(//SourceId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(spill_release_source.`SourceName` separator "; ") ) as SourceId' );	
        SET @queryFrom = CONCAT(@queryFrom,'    left outer join spill_release_source on `spill_release_source`.`SourceId` = `spill_release`.`SourceId`  ');
        
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//DurationValue)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(DurationValue separator "; ")  ) as DurationValue' );	
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//DurationUnitId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(`duration_unit`.`DurationUnitName` separator "; ")  ) as DurationUnitId' );	
        SET @queryFrom = CONCAT(@queryFrom,'    left outer join `duration_unit` ON  `duration_unit`.`DurationUnitId` = `spill_release`.`DurationUnitId`  ');
        
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//QuantityValue)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(QuantityValue separator "; ")  ) as QuantityValue' );	
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//QuantityUnitId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat( `quq`.`QuantityUnitName` separator "; ") )  as QuantityUnitId' );	
        SET @queryFrom = CONCAT(@queryFrom,'    left outer join `quantity_unit` quq ON  `quq`.`QuantityUnitId` = `spill_release`.`QuantityUnitId` ');
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//QuantityRecoveredValue)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(QuantityRecoveredValue separator "; ")  ) as QuantityRecoveredValue' );	
	END IF;	
	
		IF(ExtractValue(xmlData, 'count(//RecoveredUnitId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(`quantity_recovered`.`QuantityUnitName` separator "; ")  ) as RecoveredUnitId' );
        SET @queryFrom = CONCAT(@queryFrom,'    left outer join `quantity_unit` `quantity_recovered` ON `quantity_recovered`.`QuantityUnitId` = `spill_release`.`RecoveredUnitId` ');
        
	END IF;
	
		IF(ExtractValue(xmlData, 'count(//WhatWasIt)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(WhatWasIt separator "; ") ) as WhatWasIt' );	
	END IF;
	
		IF(ExtractValue(xmlData, 'count(//HowDidSROccur)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(HowDidSROccur separator "; ") ) as HowDidSROccur' );	
	END IF;
	
		IF(ExtractValue(xmlData, 'count(//IsReportable)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat( case `spill_release`.`IsReportable`  WHEN '0' THEN 'No'   WHEN '1' THEN 'Yes' END separator "; ") ) as IsReportable' );	
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//ImpactsExtAgencyId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(`sp_rel_agency`.`SpRelAgencyName` separator "; ") ) as ImpactsExtAgencyId' );	
        SET @queryFrom = CONCAT(@queryFrom,'    left outer join `sp_rel_agency` ON `sp_rel_agency`.`SpRelAgencyId` = `spill_release`.`SpRelAgencyId` ');
        
        
        
		SET @Col =  extractvalue(xmlData, CONCAT('//','ImpactsExtAgencyId'));
		 IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @impactWhere = CONCAT(@impactWhere,'  and  `sp_rel_agency`.`SpRelAgencyName`   ' ,' like '"'%", @Col ,"%'" );
		END IF; 
        
	END IF;
	
END IF;
 -- select @selectquery;
/* search part*/
  SET@myArrayOfValue='SourceId,DurationValue,DurationUnitId,QuantityValue,QuantityUnitId,QuantityRecoveredValue,RecoveredUnitId,WhatWasIt,HowDidSROccur,IsReportable,HowDidThatDone,DamageDescription,TrafficTrafficDriverName,TrafficTrafficDriverLicence,TrafficVehicleTypeId,TrafficVehicleLicence,Details,ValueOfFine,  TicketNumber,HowDidThatOccur,SymptomsId,IllnessDescription,Illness_RestrictedWorkId,Illness_PersonalInjured,Illness_InitialTreatmentId,Illness_AdjustmentDays,Illness_TotalDaysOff,InjuryTypeId,BodyPartId,BodyAreaId,RecordableId,InitialTreatmentId,AdjustmentDays,TotalDaysOff,InjuryDescription,TaskDescription,OutComeFollowUp,Comments,  PeopleInvolvedName,Company,Position,Email,PrimaryPhone,AlternatePhone,ExpInCurrentPostion,ExpOverAll,Age,HowHeInvolved,RoleDescription,VersionNumber,IncidentNumber,EventTypeId,CreatorName,IncidentHour,IncidentMinute,IsEmerRP,RepName,RepEmail,RepPosition,RepCompany,RepPrimaryPhone,RepAlternatePhone,Location1Id,Location2Id,Location3Id,Location4Id,OtherLocation,EventSequence,EnvConditionNote,IncDescription,FilledByName,EnergyFormNote,SubStandardActionNote,SubStandardConditionNote,UnderLyingCauseNote,InvStatusId,InvestigatorName1,InvestigatorName2,InvestigatorName3,OtherRootCause,InvSummary,FollowUpNote,IncidentSeverityId,SourceDetails,RootCauseNote,UpdatedByName,RiskOfRecurrenceId,OperationTypeId,';
  
  
 SET @Postition = LOCATE(',', @myArrayOfValue);
WHILE ( @Postition > 0 ) DO
 SET @STR = SUBSTRING(@myArrayOfValue, 1, @Postition-1);
 SET @STR= TRIM(@STR);
 
 SET @myArrayOfValue = SUBSTRING(@myArrayOfValue, @Postition + 1);
 SET @Col =  extractvalue(xmlData, CONCAT('//',@STR));
	IF (@Col != '' AND @Col !='NULL') THEN
  
	
    IF (@STR  = 'CreatorName' ) then set @STR= 'concat (empCreator.FirstName," ",empCreator.LastName) '; END IF;
	IF (@STR  = 'IncidentId' ) then set @STR= 'inc.IncidentId';  END IF;
	IF (@STR  = 'Location1Id' ) then set @STR= 'location1.Location1Name'; END IF;
	IF (@STR  = 'Location2Id' ) then set @STR= 'location2.Location2Name';  END IF;
	IF (@STR  = 'Location3Id' ) then set @STR= 'location3.Location3Name'; END IF;
	IF (@STR  = 'Location4Id' ) then set @STR= 'location4.Location4Name'; END IF; 
	IF (@STR  = 'OperationTypeId' ) then set @STR= 'operation_type.OperationTypeName';  END IF;
	IF (@STR  = 'RiskOfRecurrenceId' ) then set @STR= 'risk_of_recurrence.RiskOfRecurrenceName';  END IF;
	IF (@STR  = 'IncidentSeverityId' ) then set @STR= 'incident_severity.IncidentSeverityName';  END IF;
	IF (@STR  = 'InvStatusId') then set@STR='inv_status.InvStatusName';  END IF;	
	IF (@STR  = 'EventTypeId' ) then set @STR= 'event_type.EventTypeName';  END IF;	
	
    IF (@STR  = 'IncidentId'  or @STR  = 'IncidentDate'  or @STR  = 'IncidentHour'  or @STR  = 'IncidentMinute'  or @STR  = 'IsEmerRP'  
		or @STR  = 'RepName'  or @STR  = 'RepEmail'  or @STR  = 'RepPosition'  or @STR  = 'RepCompany'  or @STR  = 'RepPrimaryPhone'  
        or @STR  = 'RepAlternatePhone'  or @STR  = 'OtherLocation'  or @STR  = 'EventSequence'  or @STR  = 'EnvConditionNote'  
        or @STR  = 'IncDescription'  or @STR  = 'EnergyFormNote'  or @STR  = 'SubStorardActionNote'  or @STR  = 'SubStorardConditionNote'  
        or @STR  = 'UnderLyingCauseNote'  or @STR  = 'InvestigationDate'  or @STR  = 'InvestigatorName1'  or @STR  = 'InvestigatorName2'  
        or @STR  = 'InvestigatorName3'  or @STR  = 'InvSummary'  or @STR  = 'FollowUpNote'  or @STR  = 'ResponseCost'  
        or @STR  = 'RepairCost'  or @STR  = 'InsuranceCost'  or @STR  = 'WCBCost'  or @STR  = 'OtherCost'  or @STR  = 'TotalCost'  
        or @STR  = 'SourceDetails'  or @STR  = 'RootCauseNote'  or @STR  = 'SignOffInvestigatorName'  or @STR  = 'SignOffDate'  
        or @STR  = 'IncidentNumber' )then 
   
	   set @STR=  CONCAT('inc.' , @STR);
	END IF;	
	IF (@STR  = 'UpdatedByName' ) then 
		set @STR= CONCAT('CONCAT',' (','empModifier.FirstName,',"'","  '" ,',empModifier.LastName',') '); 
    END IF;
	
    
	SET @queryWhere = CONCAT(@queryWhere,CONCAT(' AND ',@STR,' like '"'%", @Col ,"%'" )); 
 END IF;
 
	SET @Postition = LOCATE(',', @myArrayOfValue);
END WHILE;
 
-- select @queryWhere;
-- select CONCAT( @selectquery, @queryFrom, @queryWhere );
SET @LostTimeStartFrom =  extractvalue(xmlData, '//LostTimeStartFrom');
SET @LostTimeStartTo =  extractvalue(xmlData, '//LostTimeStartTo');
IF(@LostTimeStartTo != '') THEN
	SET @LostTimeStartFrom  = STR_TO_DATE(@LostTimeStartFrom , '%m/%d/%Y');
	SET @LostTimeStartTo  = STR_TO_DATE(@LostTimeStartTo , '%m/%d/%Y');
	SET @LostTimeStartTo2 = DATE_ADD(@LostTimeStartTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_injury_view.LostTimeStart >  ', "'" , @LostTimeStartFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_injury_view.LostTimeStart <=  ', "'",  @LostTimeStartTo2  ,"'" );										
ELSE 
IF(@LostTimeStartTo = '' AND @LostTimeStartFrom !='' ) THEN
	SET @LostTimeStartFrom  = STR_TO_DATE(@LostTimeStartFrom , '%m/%d/%Y');
	SET @LostTimeStartFrom2 = DATE_ADD(@LostTimeStartFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_injury_view.LostTimeStart >=  ',  "'", @LostTimeStartFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_injury_view.LostTimeStart <  ', "'", @LostTimeStartFrom2  ,"'");	
END IF;
END IF;
SET @LostTimeEndFrom =  extractvalue(xmlData, '//LostTimeEndFrom');
SET @LostTimeEndTo =  extractvalue(xmlData, '//LostTimeEndTo');
IF(@LostTimeEndTo != '') THEN
	SET @LostTimeEndFrom  = STR_TO_DATE(@LostTimeEndFrom , '%m/%d/%Y');
	SET @LostTimeEndTo  = STR_TO_DATE(@LostTimeEndTo , '%m/%d/%Y');
	SET @LostTimeEndTo2 = DATE_ADD(@LostTimeEndTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_injury_view.LostTimeEnd >  ', "'" , @LostTimeEndFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_injury_view.LostTimeEnd <=  ', "'",  @LostTimeEndTo2  ,"'" );										
ELSE 
IF(@LostTimeEndTo = '' AND @LostTimeEndFrom !='' ) THEN
	SET @LostTimeEndFrom  = STR_TO_DATE(@LostTimeEndFrom , '%m/%d/%Y');
	SET @LostTimeEndFrom2 = DATE_ADD(@LostTimeEndFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_injury_view.LostTimeEnd >=  ',  "'", @LostTimeEndFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_injury_view.LostTimeEnd <  ', "'", @LostTimeEndFrom2  ,"'");	
END IF;
END IF;
SET @Illness_LostTimeStartFrom =  extractvalue(xmlData, '//Illness_LostTimeStartFrom');
SET @Illness_LostTimeStartTo =  extractvalue(xmlData, '//Illness_LostTimeStartTo');
IF(@Illness_LostTimeStartTo != '') THEN
	SET @Illness_LostTimeStartFrom  = STR_TO_DATE(@Illness_LostTimeStartFrom , '%m/%d/%Y');
	SET @Illness_LostTimeStartTo  = STR_TO_DATE(@Illness_LostTimeStartTo , '%m/%d/%Y');
	SET @Illness_LostTimeStartTo2 = DATE_ADD(@Illness_LostTimeStartTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_illness_view.Illness_LostTimeStart >  ', "'" , @Illness_LostTimeStartFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_illness_view.Illness_LostTimeStart <=  ', "'",  @Illness_LostTimeStartTo2  ,"'" );										
ELSE 
IF(@Illness_LostTimeStartTo = '' AND @Illness_LostTimeStartFrom !='' ) THEN
	SET @Illness_LostTimeStartFrom  = STR_TO_DATE(@Illness_LostTimeStartFrom , '%m/%d/%Y');
	SET @Illness_LostTimeStartFrom2 = DATE_ADD(@Illness_LostTimeStartFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_illness_view.Illness_LostTimeStart >=  ',  "'", @Illness_LostTimeStartFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_illness_view.Illness_LostTimeStart <  ', "'", @Illness_LostTimeStartFrom2  ,"'");	
END IF;
END IF;
SET @Illness_LostTimeEndFrom =  extractvalue(xmlData, '//Illness_LostTimeEndFrom');
SET @Illness_LostTimeEndTo =  extractvalue(xmlData, '//Illness_LostTimeEndTo');
IF(@Illness_LostTimeEndTo != '') THEN
	SET @Illness_LostTimeEndFrom  = STR_TO_DATE(@Illness_LostTimeEndFrom , '%m/%d/%Y');
	SET @Illness_LostTimeEndTo  = STR_TO_DATE(@Illness_LostTimeEndTo , '%m/%d/%Y');
	SET @Illness_LostTimeEndTo2 = DATE_ADD(@Illness_LostTimeEndTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_illness_view.Illness_LostTimeEnd >  ', "'" , @Illness_LostTimeEndFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_illness_view.Illness_LostTimeEnd <=  ', "'",  @Illness_LostTimeEndTo2  ,"'" );										
ELSE 
IF(@Illness_LostTimeEndTo = '' AND @Illness_LostTimeEndFrom !='' ) THEN
	SET @Illness_LostTimeEndFrom  = STR_TO_DATE(@Illness_LostTimeEndFrom , '%m/%d/%Y');
	SET @Illness_LostTimeEndFrom2 = DATE_ADD(@Illness_LostTimeEndFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_illness_view.Illness_LostTimeEnd >=  ',  "'", @Illness_LostTimeEndFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_illness_view.Illness_LostTimeEnd <  ', "'", @Illness_LostTimeEndFrom2  ,"'");	
END IF;
END IF;
SET @StartDateFrom =  extractvalue(xmlData, '//StartDateFrom');
SET @StartDateTo =  extractvalue(xmlData, '//StartDateTo');
IF(@StartDateTo != '') THEN
	SET @StartDateFrom  = STR_TO_DATE(@StartDateFrom , '%m/%d/%Y');
	SET @StartDateTo  = STR_TO_DATE(@StartDateTo , '%m/%d/%Y');
	SET @StartDateTo2 = DATE_ADD(@StartDateTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND ca.StartDate >  ', "'" , @StartDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND ca.StartDate <=  ', "'",  @StartDateTo2  ,"'" );										
ELSE 
IF(@StartDateTo = '' AND @StartDateFrom !='' ) THEN
	SET @StartDateFrom  = STR_TO_DATE(@StartDateFrom , '%m/%d/%Y');
	SET @StartDateFrom2 = DATE_ADD(@StartDateFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND ca.StartDate >=  ',  "'", @StartDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND ca.StartDate <  ', "'", @StartDateFrom2  ,"'");	
END IF;
END IF;
SET @TargetEndDateFrom =  extractvalue(xmlData, '//TargetEndDateFrom');
SET @TargetEndDateTo =  extractvalue(xmlData, '//TargetEndDateTo');
IF(@TargetEndDateTo != '') THEN
	SET @TargetEndDateFrom  = STR_TO_DATE(@TargetEndDateFrom , '%m/%d/%Y');
	SET @TargetEndDateTo  = STR_TO_DATE(@TargetEndDateTo , '%m/%d/%Y');
	SET @TargetEndDateTo2 = DATE_ADD(@TargetEndDateTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND ca.TargetEndDate >  ', "'" , @TargetEndDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND ca.TargetEndDate <=  ', "'",  @TargetEndDateTo2  ,"'" );										
ELSE 
IF(@TargetEndDateTo = '' AND @TargetEndDateFrom !='' ) THEN
	SET @TargetEndDateFrom  = STR_TO_DATE(@TargetEndDateFrom , '%m/%d/%Y');
	SET @TargetEndDateFrom2 = DATE_ADD(@TargetEndDateFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND ca.TargetEndDate >=  ',  "'", @TargetEndDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND ca.TargetEndDate <  ', "'", @TargetEndDateFrom2  ,"'");	
END IF;
END IF;
SET @ActualEndDateFrom =  extractvalue(xmlData, '//ActualEndDateFrom');
SET @ActualEndDateTo =  extractvalue(xmlData, '//ActualEndDateTo');
IF(@ActualEndDateTo != '') THEN
	SET @ActualEndDateFrom  = STR_TO_DATE(@ActualEndDateFrom , '%m/%d/%Y');
	SET @ActualEndDateTo  = STR_TO_DATE(@ActualEndDateTo , '%m/%d/%Y');
	SET @ActualEndDateTo2 = DATE_ADD(@ActualEndDateTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND ca.ActualEndDate >  ', "'" , @ActualEndDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND ca.ActualEndDate <=  ', "'",  @ActualEndDateTo2  ,"'" );										
ELSE 
IF(@ActualEndDateTo = '' AND @ActualEndDateFrom !='' ) THEN
	SET @ActualEndDateFrom  = STR_TO_DATE(@ActualEndDateFrom , '%m/%d/%Y');
	SET @ActualEndDateFrom2 = DATE_ADD(@ActualEndDateFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND ca.ActualEndDate >=  ',  "'", @ActualEndDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND ca.ActualEndDate <  ', "'", @ActualEndDateFrom2  ,"'");	
END IF;
END IF;
SET @IncidentDateFrom =  extractvalue(xmlData, '//IncidentDateFrom');
SET @IncidentDateTo =  extractvalue(xmlData, '//IncidentDateTo');
IF(@IncidentDateTo != '') THEN
	SET @IncidentDateFrom  = STR_TO_DATE(@IncidentDateFrom , '%m/%d/%Y');
	SET @IncidentDateTo  = STR_TO_DATE(@IncidentDateTo , '%m/%d/%Y');
	SET @IncidentDateTo2 = DATE_ADD(@IncidentDateTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND inc.IncidentDate >  ', "'" , @IncidentDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND inc.IncidentDate <=  ', "'",  @IncidentDateTo2  ,"'" );										
ELSE 
IF(@IncidentDateTo = '' AND @IncidentDateFrom !='' ) THEN
	SET @IncidentDateFrom  = STR_TO_DATE(@IncidentDateFrom , '%m/%d/%Y');
	SET @IncidentDateFrom2 = DATE_ADD(@IncidentDateFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND inc.IncidentDate >=  ',  "'", @IncidentDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND inc.IncidentDate <  ', "'", @IncidentDateFrom2  ,"'");	
END IF;
END IF;
SET @InvestigationDateFrom =  extractvalue(xmlData, '//InvestigationDateFrom');
SET @InvestigationDateTo =  extractvalue(xmlData, '//InvestigationDateTo');
IF(@InvestigationDateTo != '') THEN
	SET @InvestigationDateFrom  = STR_TO_DATE(@InvestigationDateFrom , '%m/%d/%Y');
	SET @InvestigationDateTo  = STR_TO_DATE(@InvestigationDateTo , '%m/%d/%Y');
	SET @InvestigationDateTo2 = DATE_ADD(@InvestigationDateTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND inc.InvestigationDate >  ', "'" , @InvestigationDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND inc.InvestigationDate <=  ', "'",  @InvestigationDateTo2  ,"'" );										
ELSE 
IF(@InvestigationDateTo = '' AND @InvestigationDateFrom !='' ) THEN
	SET @InvestigationDateFrom  = STR_TO_DATE(@InvestigationDateFrom , '%m/%d/%Y');
	SET @InvestigationDateFrom2 = DATE_ADD(@InvestigationDateFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND inc.InvestigationDate >=  ',  "'", @InvestigationDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND inc.InvestigationDate <  ', "'", @InvestigationDateFrom2  ,"'");	
END IF;
END IF;
SET @SignOffDateFrom =  extractvalue(xmlData, '//SignOffDateFrom');
SET @SignOffDateTo =  extractvalue(xmlData, '//SignOffDateTo');
IF(@SignOffDateTo != '') THEN
	SET @SignOffDateFrom  = STR_TO_DATE(@SignOffDateFrom , '%m/%d/%Y');
	SET @SignOffDateTo  = STR_TO_DATE(@SignOffDateTo , '%m/%d/%Y');
	SET @SignOffDateTo2 = DATE_ADD(@SignOffDateTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND inc.SignOffDate >  ', "'" , @SignOffDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND inc.SignOffDate <=  ', "'",  @SignOffDateTo2  ,"'" );										
ELSE 
IF(@SignOffDateTo = '' AND @SignOffDateFrom !='' ) THEN
	SET @SignOffDateFrom  = STR_TO_DATE(@SignOffDateFrom , '%m/%d/%Y');
	SET @SignOffDateFrom2 = DATE_ADD(@SignOffDateFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND inc.SignOffDate >=  ',  "'", @SignOffDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND inc.SignOffDate <  ', "'", @SignOffDateFrom2  ,"'");	
END IF;
END IF;
SET @TaskEstimatedCostTo =  extractvalue(xmlData, '//TaskEstimatedCostTo');
SET @TaskEstimatedCostFrom =  extractvalue(xmlData, '//TaskEstimatedCostFrom');
IF( @TaskEstimatedCostTo !='' ) THEN
	SET @queryWhere = CONCAT(@queryWhere,' AND  ca.EstimatedCost    BETWEEN ', @TaskEstimatedCostFrom, ' and ', @TaskEstimatedCostTo);
ELSE 
	IF( @TaskEstimatedCostFrom !=''  and @TaskEstimatedCostFrom != 'NULL')	 THEN
set  @TaskEstimatedCostFrom  = (replace(@TaskEstimatedCostFrom, '&lt;', '<'));
set  @TaskEstimatedCostFrom  = (replace(@TaskEstimatedCostFrom, '&gt;', '>'));
		SET @queryWhere = CONCAT(@queryWhere,' AND  ca.EstimatedCost  ', @TaskEstimatedCostFrom);
	END IF;
END IF;
SET @WCBCostTo =  extractvalue(xmlData, '//WCBCostTo');
SET @WCBCostFrom =  extractvalue(xmlData, '//WCBCostFrom');
IF( @WCBCostTo !='' ) THEN
	SET @queryWhere = CONCAT(@queryWhere,' AND  inc.WCBCost  BETWEEN ', @WCBCostFrom, ' and ', @WCBCostTo);
ELSE 
	IF( @WCBCostFrom !=''  and @WCBCostFrom != 'NULL')	 THEN
set  @WCBCostFrom  = (replace(@WCBCostFrom, '&lt;', '<'));
set  @WCBCostFrom  = (replace(@WCBCostFrom, '&gt;', '>'));
		SET @queryWhere = CONCAT(@queryWhere,' AND  inc.WCBCost  ', @WCBCostFrom);
	END IF;
END IF;
SET @RepairCostTo =  extractvalue(xmlData, '//RepairCostTo');
SET @RepairCostFrom =  extractvalue(xmlData, '//RepairCostFrom');
IF( @RepairCostTo !='' ) THEN
	SET @queryWhere = CONCAT(@queryWhere,' AND  inc.RepairCost  BETWEEN ', @RepairCostFrom, ' and ', @RepairCostTo);
ELSE 
	IF( @RepairCostFrom !=''  and @RepairCostFrom != 'NULL')	 THEN
set  @RepairCostFrom  = (replace(@RepairCostFrom, '&lt;', '<'));
set  @RepairCostFrom  = (replace(@RepairCostFrom, '&gt;', '>'));
		SET @queryWhere = CONCAT(@queryWhere,' AND  inc.RepairCost  ', @RepairCostFrom);
	END IF;
END IF;
SET @OtherCostTo =  extractvalue(xmlData, '//OtherCostTo');
SET @OtherCostFrom =  extractvalue(xmlData, '//OtherCostFrom');
IF( @OtherCostTo !='' ) THEN
	SET @queryWhere = CONCAT(@queryWhere,' AND  inc.OtherCost  BETWEEN ', @OtherCostFrom, ' and ', @OtherCostTo);
ELSE 
	IF( @OtherCostFrom !=''  and @OtherCostFrom != 'NULL')	 THEN
set  @OtherCostFrom  = (replace(@OtherCostFrom, '&lt;', '<'));
set  @OtherCostFrom  = (replace(@OtherCostFrom, '&gt;', '>'));
		SET @queryWhere = CONCAT(@queryWhere,' AND  inc.OtherCost  ', @OtherCostFrom);
	END IF;
END IF;
SET @OtherCostTo =  extractvalue(xmlData, '//OtherCostTo');
SET @OtherCostFrom =  extractvalue(xmlData, '//OtherCostFrom');
IF( @OtherCostTo !='' ) THEN
	SET @queryWhere = CONCAT(@queryWhere,' AND  inc.OtherCost  BETWEEN ', @OtherCostFrom, ' and ', @OtherCostTo);
ELSE 
	IF( @OtherCostFrom !=''  and @OtherCostFrom != 'NULL')	 THEN
set  @OtherCostFrom  = (replace(@OtherCostFrom, '&lt;', '<'));
set  @OtherCostFrom  = (replace(@OtherCostFrom, '&gt;', '>'));
		SET @queryWhere = CONCAT(@queryWhere,' AND  inc.OtherCost  ', @OtherCostFrom);
	END IF;
END IF;
SET @ResponseCostTo =  extractvalue(xmlData, '//ResponseCostTo');
SET @ResponseCostFrom =  extractvalue(xmlData, '//ResponseCostFrom');
IF( @ResponseCostTo !='' ) THEN
	SET @queryWhere = CONCAT(@queryWhere,' AND  inc.ResponseCost  BETWEEN ', @ResponseCostFrom, ' and ', @ResponseCostTo);
ELSE 
	IF( @ResponseCostFrom !=''  and @ResponseCostFrom != 'NULL')	 THEN
set  @ResponseCostFrom  = (replace(@ResponseCostFrom, '&lt;', '<'));
set  @ResponseCostFrom  = (replace(@ResponseCostFrom, '&gt;', '>'));
		SET @queryWhere = CONCAT(@queryWhere,' AND  inc.ResponseCost  ', @ResponseCostFrom);
	END IF;
END IF;
SET @TotalCostTo =  extractvalue(xmlData, '//TotalCostTo');
SET @TotalCostFrom =  extractvalue(xmlData, '//TotalCostFrom');
IF( @TotalCostTo !='' ) THEN
	SET @queryWhere = CONCAT(@queryWhere,' AND  inc.TotalCost  BETWEEN ', @TotalCostFrom, ' and ', @TotalCostTo);
ELSE 
	IF( @TotalCostFrom !=''  and @TotalCostFrom != 'NULL')	 THEN
set  @TotalCostFrom  = (replace(@TotalCostFrom, '&lt;', '<'));
set  @TotalCostFrom  = (replace(@TotalCostFrom, '&gt;', '>'));
		SET @queryWhere = CONCAT(@queryWhere,' AND  inc.TotalCost  ', @TotalCostFrom);
	END IF;
END IF;
-- SET @queryWhere = CONCAT(@queryWhere, '  group by inc.IncidentId  ');
SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere, @querygroup, @queryhave );
 -- select @query;
SET @querycount =  CONCAT( 'SELECT count(*) into @cnt from  (', @query, ' ) t');
PREPARE stmt1 FROM @querycount;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
SET @selectquery = CONCAT (@selectquery,', ', @cnt, ' as Count ');
SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere, @querygroup, @queryhave  );
IF(@index  = 'IncidentId'  or @index  = 'IncidentDate'  or @index  = 'IncidentHour'  or @index  = 'IncidentMinute'  or @index  = 'IsEmerRP'  or @inde  = 'RepName'  or @index  = 'RepEmail'  or @index  = 'RepPosition'  or @index  = 'RepCompany'  or @index  = 'RepPrimaryPhone'  or @index  = 'RepAlternatePhone'  or @index  = 'OtherLocation'  or @index  = 'OperationTypeId'  or @index  = 'EventSequence'  or @index  = 'EnvConditionNote'  or @index  = 'IncDescription'  or @index  = 'EnergyFormNote'  or @index  = 'SubStorardActionNote'  or @index  = 'SubStorardConditionNote'  or @index  = 'UnderLyingCauseNote'  or @index  = 'InvestigationDate'  or @index  = 'InvestigatorName1'  or @index  = 'InvestigatorName2'  or @index  = 'InvestigatorName3'  or @index  = 'InvSummary'  or @index  = 'FollowUpNote'  or @index  = 'ResponseCost'  or @index  = 'RepairCost'  or @index  = 'InsuranceCost'  or @index  = 'WCBCost'  or @index  = 'OtherCost'  or @index  = 'TotalCost'  or @index  = 'SourceDetails'  or @index  = 'RootCauseNote'  or @index  = 'SignOffInvestigatorName'  or @index  = 'SignOffDate'  or @index  = 'IncidentNumber' ) then
	SET @index=  CONCAT('inc.' , @index);
END IF;
-- if(@index ='CreatorName') then	set @index ='CreatorId'; end if;
-- if(@index ='CreatorName') then	set @index ='CreatorId'; end if;
IF (@index  = 'inc.Location1Id' ) then set @index= 'location1.Location1Name'; end if; 
IF (@index  = 'inc.Location2Id' ) then set @index= 'location2.Location2Name'; end if;  
IF (@index  = 'inc.Location3Id' ) then set @index= 'location3.Location3Name'; end if; 
IF (@index  = 'inc.Location4Id' ) then set @index= 'location4.Location4Name'; end if; 
IF (@index  = 'inc.OperationTypeId' ) then set @index= 'operation_type.OperationTypeName'; end if;  
IF (@index  = 'inc.RiskOfRecurrenceId' ) then set @index= 'risk_of_recurrence.RiskOfRecurrenceName'; end if;  
IF (@index  = 'inc.IncidentSeverityId' ) then set @index= 'incident_severity.IncidentSeverityName'; end if;  
IF (@index  = 'inc.InvStatusId') then set@index='inv_status.InvStatusName'; end if;
SET @query = CONCAT(@query, ' order by ', @index,'  ', @sortOrder);
if( @Export ="false") then
SET @page = (@page - 1) * @limit;
SET @query = CONCAT(@query, ' LIMIT ', @limit ,' OFFSET ',  @page);
end if;
-- select @query;
PREPARE stmt1 FROM @query;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
 -- select @query;
END
;
