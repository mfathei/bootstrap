CREATE PROCEDURE ABCanTrackV2.DeleteOrgGroups(IN `$OrgId` VARCHAR(100))
  BEGIN
	DECLARE $Count INT;
    
    
    -- Step1: CommonDB.group_permission
	SET $Count = (SELECT COUNT(*) FROM `CommonDB`.`group_permission` WHERE GroupId IN (SELECT GroupId FROM `CommonDB`.`group` WHERE OrgId = $OrgId));
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgGroups',  'CommonDB.group_permission', NULL, $Count, 1);
    
	-- ************
	DELETE FROM `CommonDB`.`group_permission` WHERE GroupId IN (SELECT GroupId FROM `CommonDB`.`group` WHERE OrgId = $OrgId);
    -- #
    
    
    -- Step2: CommonDB.product_group
	SET $Count = (SELECT COUNT(*) FROM `CommonDB`.`product_group` WHERE GroupId IN (SELECT GroupId FROM `CommonDB`.`group` WHERE OrgId = $OrgId));
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgGroups',  'CommonDB.product_group', NULL, $Count, 2);
    
	-- ************
	DELETE FROM `CommonDB`.`product_group` WHERE GroupId IN (SELECT GroupId FROM `CommonDB`.`group` WHERE OrgId = $OrgId);
    -- #
    
    
    -- Step3: ABCanTrackV2.emp_group
	SET $Count = (SELECT COUNT(*) FROM `ABCanTrackV2`.`emp_group` WHERE GroupId IN (SELECT GroupId FROM `CommonDB`.`group` WHERE OrgId = $OrgId));
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgGroups',  'ABCanTrackV2.emp_group', NULL, $Count, 3);
    
	-- ************
	DELETE FROM `ABCanTrackV2`.`emp_group` WHERE GroupId IN (SELECT GroupId FROM `CommonDB`.`group` WHERE OrgId = $OrgId);
    -- #
    
    
    -- Step4: CommonDB.emp_group
	SET $Count = (SELECT COUNT(*) FROM `CommonDB`.`emp_group` WHERE GroupId IN (SELECT GroupId FROM `CommonDB`.`group` WHERE OrgId = $OrgId));
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgGroups',  'CommonDB.emp_group', NULL, $Count, 4);
    
	-- ************
	DELETE FROM `CommonDB`.`emp_group` WHERE GroupId IN (SELECT GroupId FROM `CommonDB`.`group` WHERE OrgId = $OrgId);
    -- #
    
    
    -- Step5: ABCanTrackV2.group
	SET $Count = (SELECT COUNT(*) FROM `ABCanTrackV2`.`group` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgGroups',  'ABCanTrackV2.product_group', NULL, $Count, 5);
    
	-- ************
	DELETE FROM `ABCanTrackV2`.`group` WHERE OrgId = $OrgId;
    -- #
    
    
    -- Step6: CommonDB.group
	SET $Count = (SELECT COUNT(*) FROM `CommonDB`.`group` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgGroups',  'CommonDB.product_group', NULL, $Count, 6);
    
	-- ************
	DELETE FROM `CommonDB`.`group` WHERE OrgId = $OrgId;
    -- #
    
    -- Step7: Done
	SET $Count = (SELECT COUNT(*) FROM `CommonDB`.`group` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgGroups',  'Done', NULL, $Count, 7);
	-- #
    
END;
