CREATE PROCEDURE ABCanTrackV2.InsertThirdPartyValue(IN `$IncidentId` VARCHAR(100))
  BEGIN
DECLARE $HistIncidentId VARCHAR(100);
-- DECLARE $ThirdPartyName, $JobNumber, $ContactName TEXT;
DECLARE $VersionNumber INT;
SET $VersionNumber = (SELECT MAX(VersionNumber) FROM hist_incident WHERE IncidentId = $IncidentId);
SET $HistIncidentId = (SELECT HistIncidentId FROM hist_incident WHERE IncidentId = $IncidentId AND VersionNumber = $VersionNumber);
SET @ThirdPartyName = (SELECT group_concat(ThirdPartyName SEPARATOR ' ;| ') FROM third_party WHERE ThirdPartyId IN (SELECT ThirdPartyId FROM inc_third_party WHERE IncidentId = $IncidentId));
call updateHistIncThirdPartiesSub($IncidentId);-- histinc_thirdparties table
SET @JobNumber = (SELECT group_concat(JobNumber SEPARATOR ' ;| ') FROM inc_third_party WHERE IncidentId = $IncidentId);
SET @ContactName = (SELECT group_concat(ContactName SEPARATOR ' ;| ') FROM inc_third_party WHERE IncidentId = $IncidentId);
UPDATE hist_incident 
SET 
    ThirdPartyName = @ThirdPartyName,
    JobNumber = @JobNumber, 
    ContactName = @ContactName
WHERE
    HistIncidentId = $HistIncidentId;
END;
