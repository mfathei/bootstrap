CREATE PROCEDURE ABCanTrackV2.DeleteFrom_vehicle_damage_Tables(IN `$IncidentId` VARCHAR(100))
  BEGIN
DECLARE fetch_status int default 0;
DECLARE $VehicleDamageId varchar(100);
DECLARE incident_cursor CURSOR FOR 
select VehicleDamageId from vehicle_damage where incidentid = $IncidentId;
DECLARE CONTINUE HANDLER FOR NOT FOUND SET fetch_status = 100;
Open Incident_cursor;
FETCH NEXT FROM incident_cursor 
		INTO $VehicleDamageId;
WHILE fetch_status = 0
			do
delete from impacts_ext_agency where VehicleDamageId = $VehicleDamageId;
FETCH NEXT FROM incident_cursor 
			INTO $VehicleDamageId;
		END while;
	CLOSE incident_cursor;
delete from vehicle_damage where incidentid = $incidentid;
END;
