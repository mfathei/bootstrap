CREATE FUNCTION ABCanTrackV2.getDamageDescription2(`$VehicleDamageId`         VARCHAR(100),
                                                   `$OriginalVehicleDamageId` VARCHAR(100))
  RETURNS TEXT
  BEGIN
if $OriginalVehicleDamageId is null   or $OriginalVehicleDamageId  =''   then
	set $OriginalVehicleDamageId = $VehicleDamageId ;
end if;
set session group_concat_max_len = 10000;
select (group_concat(DATE_FORMAT(UpdatedDate, '%b %d %Y') ,' ', '(',  concat(firstname ,' ', lastname) ,')',': <pr>', DamageDescription separator '<br><br>' ) ) as DamageDescription   
 into @newDamageDescription2 
 from(
 select UpdatedDate, DamageDescription, firstname,lastname FROM hist_vehicle_damage hi 
join employee e on e.EmployeeId = hi.UpdatedbyId
 where OriginalVehicleDamageId = $OriginalVehicleDamageId  
order by UpdatedDate asc  ) temp ; 
return @newDamageDescription2;
END;
