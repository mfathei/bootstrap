CREATE FUNCTION ABCanTrackV2.getActionDescription(`$correctiveactionid`         VARCHAR(100),
                                                  `$Originalcorrectiveactionid` VARCHAR(100))
  RETURNS TEXT
  BEGIN
if $Originalcorrectiveactionid is null   or $Originalcorrectiveactionid  =''   then
	set $Originalcorrectiveactionid = $correctiveactionid ;
end if;
set session group_concat_max_len = 10000;
select ( group_concat(DATE_FORMAT(UpdatedDate, '%b %d %Y') ,' ', '(',  concat(firstname ,' ', lastname) ,')',': <pr>', Description separator '<br><br>' ) ) as Description   
 into @newDescription 
 from(
 select UpdatedDate, Description, firstname,lastname FROM hist_corrective_action hi 
join employee e on e.EmployeeId = hi.UpdatedbyId
 where Originalcorrectiveactionid = $Originalcorrectiveactionid  
order by UpdatedDate asc  ) temp ; 
return @newDescription;
END;
