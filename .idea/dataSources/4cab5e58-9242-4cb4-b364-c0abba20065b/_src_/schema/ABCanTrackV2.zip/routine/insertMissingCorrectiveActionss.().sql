CREATE PROCEDURE ABCanTrackV2.insertMissingCorrectiveActionss()
  begin 
	
    declare cid varchar(255);
    declare hid varchar(255);
     declare finished int default 0;

	DECLARE g_p_cursor CURSOR FOR
	SELECT CorrectiveActionId ,  IncidentId from corrective_action
		where CorrectiveActionId not in (select CorrectiveActionId from hist_corrective_action);
 -- declare NOT FOUND handler
	DECLARE CONTINUE HANDLER 
	FOR NOT FOUND SET finished = 1;

set @counter = 0;

 OPEN g_p_cursor;
-- FETCH g_p_cursor INTO $gid , $fcode, $pcode, $pid;
ex: LOOP
	FETCH g_p_cursor INTO cid , hid;
	IF finished = 1 THEN 
		LEAVE ex;
	END IF;
    
    set @UpdatedById = (select UpdatedById from hist_incident where IncidentId= hid order by VersionNumber desc limit 1);
    
   call InsertInto_hist_corrective_action(cid,null,null,@UpdatedById );
    
    set @counter = @counter + 1;
    
    end loop ex;
    
    close g_p_cursor;

select @counter;

end;
