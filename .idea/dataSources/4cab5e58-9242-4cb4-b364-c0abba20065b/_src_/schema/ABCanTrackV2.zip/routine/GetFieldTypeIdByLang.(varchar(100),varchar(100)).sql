CREATE FUNCTION ABCanTrackV2.GetFieldTypeIdByLang(pFieldTypeId VARCHAR(100), pLangId VARCHAR(100))
  RETURNS VARCHAR(100)
  begin
    declare vFieldTypeId varchar(100);
    set @tmpFieldTypeCode = (select FieldTypeCode from field_type where FieldTypeId = pFieldTypeId);
    set vFieldTypeId = (select FieldTypeId from field_type where FieldTypeCode = @tmpFieldTypeCode AND LanguageId = pLangId);
    return vFieldTypeId;
end;
