CREATE PROCEDURE ABCanTrackV2.updateHistIncidentVersions(IN `_HistIncidentId` VARCHAR(100),
                                                         IN `_IncidentId`     VARCHAR(100), IN `_VersionNumber` INT)
  BEGIN
        -- set @_incidentId = null;-- reset counter for getVersionNumber function
        SET @originid = (SELECT OriginalId FROM ABCanTrackV1.Incident WHERE IncidentId = _IncidentId);
        IF @originid IS NOT NULL THEN
                SET @_incidentId = NULL;-- reset counter for getVersionNumber function
				SET @vdate = (SELECT VersionDate  FROM 
				    (SELECT VersionDate,ABCanTrackV1.getVersionNumber(OriginalId) AS VersionNumber FROM ABCanTrackV1.Incident WHERE OriginalId = @originid ORDER BY VersionDate ASC ) AS tmp
				WHERE VersionNumber = _VersionNumber LIMIT 1); 
				
				UPDATE hist_incident SET UpdatedDate = @vdate WHERE HistIncidentId = _HistIncidentId;
        END IF;
END;
