CREATE PROCEDURE ABCanTrackV2.DeleteOrgCorrectiveAction(IN `$OrgId` VARCHAR(100))
  BEGIN
	DECLARE $Count INT;
    	
        
	-- Step1: corrective_action_notified
    SET $Count = (SELECT COUNT(*) FROM corrective_action_notified WHERE CorrectiveActionId IN (SELECT CorrectiveActionId FROM corrective_action WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId)));
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgCorrectiveAction', 'corrective_action_notified', NULL, $Count, 1);
	-- ************
	DELETE FROM corrective_action_notified WHERE CorrectiveActionId IN (SELECT CorrectiveActionId FROM corrective_action WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId));
	-- #
    	
        
	-- Step2: corrective_action
    SET $Count = (SELECT COUNT(*) FROM corrective_action WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId));
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgCorrectiveAction', 'corrective_action', NULL, $Count, 2);
	-- ************
	DELETE FROM corrective_action WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId);
	-- #
    
    -- Step3: DONE
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgCorrectiveAction', 'DONE', NULL, NULL, 3);
    -- # 
    
    
END;
