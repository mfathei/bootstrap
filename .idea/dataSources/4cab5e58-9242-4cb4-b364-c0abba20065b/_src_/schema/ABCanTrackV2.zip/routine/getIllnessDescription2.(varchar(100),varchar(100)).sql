CREATE FUNCTION ABCanTrackV2.getIllnessDescription2(`$IllnessId` VARCHAR(100), `$OriginalIllnessId` VARCHAR(100))
  RETURNS TEXT
  BEGIN
if $OriginalIllnessId is null   or $OriginalIllnessId  =''   then
	set $OriginalIllnessId = $IllnessId ;
end if;
set session group_concat_max_len = 10000;
select (group_concat(DATE_FORMAT(UpdatedDate, '%b %d %Y') ,' ', '(',  concat(firstname ,' ', lastname) ,')',': <pr>', ImpactDescription separator '<br><br>' ) ) as ImpactDescription  
 into @newIllnessDescription2 
 from(
 select UpdatedDate, ImpactDescription, firstname,lastname FROM hist_illness hi 
join employee e on e.EmployeeId = hi.UpdatedbyId
 where OriginalIllnessId = $OriginalIllnessId  
order by UpdatedDate asc  ) temp ; 
return @newIllnessDescription2;
END;
