CREATE PROCEDURE ABCanTrackV2.DeleteFrom_injury_Tables(IN `$IncidentId` VARCHAR(100))
  BEGIN
DECLARE fetch_status int default 0;
DECLARE $InjuryId varchar(100);
DECLARE incident_cursor CURSOR FOR 
select InjuryId from injury where incidentid = $IncidentId;
DECLARE CONTINUE HANDLER FOR NOT FOUND SET fetch_status = 100;
Open Incident_cursor;
FETCH NEXT FROM incident_cursor 
		INTO $InjuryId;
WHILE fetch_status = 0
			do
delete from body_part_injury where InjuryId = $InjuryId;
delete from body_area_injury where InjuryId = $InjuryId;
delete from impacts_ext_agency where InjuryId = $InjuryId;
delete from injury_type_injury where InjuryId = $InjuryId;
FETCH NEXT FROM incident_cursor 
			INTO $InjuryId;
		END while;
	CLOSE incident_cursor;
delete from injury where IncidentId = $incidentid;
END;
