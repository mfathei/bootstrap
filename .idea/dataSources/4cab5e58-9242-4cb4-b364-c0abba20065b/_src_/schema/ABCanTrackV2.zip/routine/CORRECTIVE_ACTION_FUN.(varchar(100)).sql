CREATE FUNCTION ABCanTrackV2.CORRECTIVE_ACTION_FUN(`$OriginalCorrectiveActionId` VARCHAR(100))
  RETURNS DATETIME
  BEGIN
DECLARE $SentDate DATETIME;
SET $SentDate = 
(select SentDate from email_log e
		join corr_act_email ce on e.EmailLogId = ce.EmailLogId
        join hist_corrective_action hc on hc.HistCorrectiveActionId = ce.HistCorrectiveActionId
	where OriginalCorrectiveActionId=$OriginalCorrectiveActionId     	
    order by SentDate desc limit 1);
    /**
(SELECT SentDate FROM corr_act_email
		JOIN email_log ON email_log.EmailLogId = corr_act_email.EmailLogId
		WHERE HistCorrectiveActionId =$HistCorrectiveActionId 	ORDER BY SentDate DESC LIMIT 1);
        */
RETURN $SentDate;
END;
