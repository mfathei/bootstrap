CREATE FUNCTION ABCanTrackV2.EMAIL_TO_FUN(`$OrgId`      VARCHAR(100), `$GroupId` VARCHAR(100),
                                          `$EmployeeId` VARCHAR(100), `$TypeValue` INT, `$TableName` VARCHAR(255))
  RETURNS INT
  BEGIN
DECLARE $Result INT;
-- ---- Type Value
-- DaysStart = 1
-- DaysFreq  = 2
IF $EmployeeId IS NULL
THEN
	IF $TypeValue = 1 AND $TableName = 'corrective_action'
	THEN
		SET $Result = (SELECT DaysStart FROM email_to_esc WHERE OrgId = $OrgId AND GroupId = $GroupId AND TableName = $TableName LIMIT 1);
	ELSEIF $TypeValue = 2 AND $TableName = 'corrective_action'
	THEN
		SET $Result = (SELECT DaysFreq FROM email_to_esc WHERE OrgId = $OrgId AND GroupId = $GroupId AND TableName = $TableName LIMIT 1);
	ELSEIF $TypeValue = 1 AND $TableName = 'incident'
	THEN
		SET $Result = (SELECT DaysStart FROM email_to_esc WHERE OrgId = $OrgId AND GroupId = $GroupId AND TableName = $TableName LIMIT 1);
	ELSEIF $TypeValue = 2 AND $TableName = 'incident'
	THEN
		SET $Result = (SELECT DaysFreq FROM email_to_esc WHERE OrgId = $OrgId AND GroupId = $GroupId AND TableName = $TableName LIMIT 1);
	END IF;
ELSEIF $GroupId IS NULL
THEN
	IF $TypeValue = 1 AND $TableName = 'corrective_action'
	THEN
		SET $Result = (SELECT DaysStart FROM email_to_esc WHERE OrgId = $OrgId AND EmployeeId = $EmployeeId AND TableName = $TableName LIMIT 1);
	ELSEIF $TypeValue = 2 AND $TableName = 'corrective_action'
	THEN
		SET $Result = (SELECT DaysFreq FROM email_to_esc WHERE OrgId = $OrgId AND EmployeeId = $EmployeeId AND TableName = $TableName LIMIT 1);
	ELSEIF $TypeValue = 1 AND $TableName = 'incident'
	THEN
		SET $Result = (SELECT DaysStart FROM email_to_esc WHERE OrgId = $OrgId AND EmployeeId = $EmployeeId AND TableName = $TableName LIMIT 1);
	ELSEIF $TypeValue = 2 AND $TableName = 'incident'
	THEN
		SET $Result = (SELECT DaysFreq FROM email_to_esc WHERE OrgId = $OrgId AND EmployeeId = $EmployeeId AND TableName = $TableName LIMIT 1);
	END IF;
ELSE IF $GroupId IS NOT NULL AND $EmployeeId IS NOT NULL
THEN	
	IF $TypeValue = 1 AND $TableName = 'corrective_action'
	THEN
		SET $Result = (SELECT DaysStart FROM email_to_esc WHERE OrgId = $OrgId AND GroupId = $GroupId AND EmployeeId = $EmployeeId AND TableName = $TableName LIMIT 1);
	ELSEIF $TypeValue = 2 AND $TableName = 'corrective_action'
	THEN
		SET $Result = (SELECT DaysFreq FROM email_to_esc WHERE OrgId = $OrgId AND GroupId = $GroupId AND EmployeeId = $EmployeeId AND TableName = $TableName LIMIT 1);
	ELSEIF $TypeValue = 1 AND $TableName = 'incident'
	THEN
		SET $Result = (SELECT DaysStart FROM email_to_esc WHERE OrgId = $OrgId AND GroupId = $GroupId AND EmployeeId = $EmployeeId AND TableName = $TableName LIMIT 1);
	ELSEIF $TypeValue = 2 AND $TableName = 'incident'
	THEN
		SET $Result = (SELECT DaysFreq FROM email_to_esc WHERE OrgId = $OrgId AND GroupId = $GroupId AND EmployeeId = $EmployeeId AND TableName = $TableName LIMIT 1);
	END IF;
END IF;
END IF;
RETURN $Result;
END;
