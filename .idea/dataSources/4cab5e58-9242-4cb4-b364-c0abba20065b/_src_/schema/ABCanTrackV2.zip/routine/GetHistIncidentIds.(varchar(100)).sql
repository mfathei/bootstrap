CREATE PROCEDURE ABCanTrackV2.GetHistIncidentIds(IN `$incidentid` VARCHAR(100))
  BEGIN
declare $MinHistIncident, $MaxHistIncident varchar(100);
set $MinHistIncident = (select min(histincidentid) from hist_incident where incidentid = $incidentid );
set $MaxHistIncident = (select max(histincidentid) from hist_incident where incidentid = $incidentid );
HistIncLoop: While $minHistIncident <= $maxHistincident
do  
select histincidentid from hist_incident where histincidentid = $minhistincident;
 (select group_concat(concat( DATE_FORMAT(IncidentDate, '%b %d %Y'),' (' , EmployeeName,'): ', '	', IFNULL(hist_corrective_action.Description,'') )  separator ' <br><br> ') as OldTaskDescription
                                from hist_corrective_action	
                                inner join hist_incident on hist_incident.IncidentId = hist_corrective_action.IncidentId
                                where hist_corrective_action.IncidentId =$IncidentId and histincidentid = $minhistincident) ;
                        (select group_concat(concat( DATE_FORMAT(IncidentDate, '%b %d %Y'),' (' , EmployeeName,'): ', '	', IFNULL(OutComeFollowUp,'') )  separator ' <br><br> ') as OldOutComeFollowUp
                        from hist_corrective_action		
                        inner join hist_incident on hist_incident.IncidentId = hist_corrective_action.IncidentId
                             where hist_corrective_action.IncidentId =$IncidentId and histincidentid = $minhistincident) ;
                        (select group_concat(concat( DATE_FORMAT(IncidentDate, '%b %d %Y'),' (' , EmployeeName,'): ', '	', IFNULL(Comments,'') )  separator ' <br><br> ') as OldComments
                        from hist_corrective_action		
                        inner join hist_incident on hist_incident.IncidentId = hist_corrective_action.IncidentId
                                 where hist_corrective_action.IncidentId =$IncidentId and histincidentid = $minhistincident) ;
set $minhistincident = (select histincidentid from hist_incident where histincidentid > $minhistincident and incidentid = $incidentid limit 1);
if $minhistincident is null then LEAVE HistIncLoop;
end if;
end while;
END;
