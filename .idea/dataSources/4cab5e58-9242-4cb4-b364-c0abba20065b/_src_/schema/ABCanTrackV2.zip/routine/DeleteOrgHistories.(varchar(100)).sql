CREATE PROCEDURE ABCanTrackV2.DeleteOrgHistories(IN `$OrgId` VARCHAR(100))
  BEGIN
	DECLARE $Count INT;
    
    
    -- Step1: hist_corrective_action
    
		-- Step1.1: corr_act_email
		SET $Count = (SELECT COUNT(*) FROM corr_act_email WHERE HistCorrectiveActionId IN (SELECT HistCorrectiveActionId FROM hist_corrective_action WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId)));
		-- ************
		INSERT INTO `ABCanTrackV2`.`delete_org_log`
			(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
		VALUES
			($OrgId, 'DeleteOrgHistories', 'corr_act_email 1.1', NULL, $Count, 1);
		-- ************
		DELETE FROM corr_act_email WHERE HistCorrectiveActionId IN (SELECT HistCorrectiveActionId FROM hist_corrective_action WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId));
		-- #
		
		-- Step1.2: hist_corrective_action
		SET $Count = (SELECT COUNT(*) FROM hist_corrective_action WHERE HistIncidentId IN (SELECT HistIncidentId FROM hist_incident WHERE OrgId = $OrgId));
		-- ************
		INSERT INTO `ABCanTrackV2`.`delete_org_log`
			(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
		VALUES
			($OrgId, 'DeleteOrgHistories', 'hist_corrective_action 1.2', NULL, $Count, 1);
		-- ************
		DELETE FROM hist_corrective_action WHERE HistIncidentId IN (SELECT HistIncidentId FROM hist_incident WHERE OrgId = $OrgId);
        -- #
        
	-- #
    
    
    -- Step2: hist_field_value
	SET $Count = (SELECT COUNT(*) FROM hist_field_value WHERE HistIncidentId IN (SELECT HistIncidentId FROM hist_incident WHERE OrgId = $OrgId));
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgHistories',  'hist_field_value', NULL, $Count, 2);
    
	-- ************
	DELETE FROM hist_field_value WHERE HistIncidentId IN (SELECT HistIncidentId FROM hist_incident WHERE OrgId = $OrgId);
    -- #
    
    
    -- Step3: hist_illness
	SET $Count = (SELECT COUNT(*) FROM hist_illness WHERE HistIncidentId IN (SELECT HistIncidentId FROM hist_incident WHERE OrgId = $OrgId));
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgHistories',  'hist_illness', NULL, $Count, 3);
    
	-- ************
	DELETE FROM hist_illness WHERE HistIncidentId IN (SELECT HistIncidentId FROM hist_incident WHERE OrgId = $OrgId);
    -- #
    
    
    -- Step4: hist_impact
	SET $Count = (SELECT COUNT(*) FROM hist_impact WHERE HistIncidentId IN (SELECT HistIncidentId FROM hist_incident WHERE OrgId = $OrgId));
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgHistories', 'hist_impact', NULL, $Count, 4);
    
	-- ************
	DELETE FROM hist_impact WHERE HistIncidentId IN (SELECT HistIncidentId FROM hist_incident WHERE OrgId = $OrgId);
    -- #
    
    
    -- Step5: hist_injury
	SET $Count = (SELECT COUNT(*) FROM hist_injury WHERE HistIncidentId IN (SELECT HistIncidentId FROM hist_incident WHERE OrgId = $OrgId));
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgHistories', 'hist_injury', NULL, $Count, 5);
    
	-- ************
	DELETE FROM hist_injury WHERE HistIncidentId IN (SELECT HistIncidentId FROM hist_incident WHERE OrgId = $OrgId);
    -- #
    
    
    -- Step6: hist_people_involved
	SET $Count = (SELECT COUNT(*) FROM hist_people_involved WHERE HistIncidentId IN (SELECT HistIncidentId FROM hist_incident WHERE OrgId = $OrgId));
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgHistories', 'hist_people_involved', NULL, $Count, 6);
    
	-- ************
	DELETE FROM hist_people_involved WHERE HistIncidentId IN (SELECT HistIncidentId FROM hist_incident WHERE OrgId = $OrgId);
    -- #
    
    
    -- Step7: hist_spill_release
	SET $Count = (SELECT COUNT(*) FROM hist_spill_release WHERE HistIncidentId IN (SELECT HistIncidentId FROM hist_incident WHERE OrgId = $OrgId));
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgHistories', 'hist_spill_release', NULL, $Count, 7);
    
	-- ************
	DELETE FROM hist_spill_release WHERE HistIncidentId IN (SELECT HistIncidentId FROM hist_incident WHERE OrgId = $OrgId);
    -- #
    
    
    -- Step8: hist_traffic_violation
	SET $Count = (SELECT COUNT(*) FROM hist_traffic_violation WHERE HistIncidentId IN (SELECT HistIncidentId FROM hist_incident WHERE OrgId = $OrgId));
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgHistories', 'hist_traffic_violation', NULL, $Count, 8);
    
	-- ************
	DELETE FROM hist_traffic_violation WHERE HistIncidentId IN (SELECT HistIncidentId FROM hist_incident WHERE OrgId = $OrgId);
    -- #
    
    
    -- Step10: hist_vehicle_damage
	SET $Count = (SELECT COUNT(*) FROM hist_vehicle_damage WHERE HistIncidentId IN (SELECT HistIncidentId FROM hist_incident WHERE OrgId = $OrgId));
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgHistories', 'hist_vehicle_damage', NULL, $Count, 10);
    
	-- ************
	DELETE FROM hist_vehicle_damage WHERE HistIncidentId IN (SELECT HistIncidentId FROM hist_incident WHERE OrgId = $OrgId);
    -- #
    
    
    -- Step11: hist_incident
    
		-- Step11.1: attachment
		SET $Count = (SELECT COUNT(*) FROM attachment WHERE IncidentId IN (SELECT HistIncidentId FROM hist_incident WHERE OrgId = $OrgId));
		-- ************
		INSERT INTO `ABCanTrackV2`.`delete_org_log`
			(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
		VALUES
			($OrgId, 'DeleteOrgHistories', 'attachment 11.1', NULL, $Count, 11);
		
		-- ************
		DELETE FROM attachment WHERE IncidentId IN (SELECT HistIncidentId FROM hist_incident WHERE OrgId = $OrgId);
		-- #
    
		-- Step11.2: inc_email_log
		SET $Count = (SELECT COUNT(*) FROM inc_email_log WHERE HistIncidentId IN (SELECT HistIncidentId FROM hist_incident WHERE OrgId = $OrgId));
		-- ************
		INSERT INTO `ABCanTrackV2`.`delete_org_log`
			(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
		VALUES
			($OrgId, 'DeleteOrgHistories', 'inc_email_log 11.2', NULL, $Count, 11);
		
		-- ************
		DELETE FROM inc_email_log WHERE HistIncidentId IN (SELECT HistIncidentId FROM hist_incident WHERE OrgId = $OrgId);
		-- #
    
		-- Step11.3: email_log
		SET $Count = (SELECT COUNT(*) FROM email_log WHERE OrgId = $OrgId);
		-- ************
		INSERT INTO `ABCanTrackV2`.`delete_org_log`
			(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
		VALUES
			($OrgId, 'DeleteOrgHistories', 'email_log 11.3', NULL, $Count, 11);
		
		-- ************
		DELETE FROM email_log WHERE OrgId = $OrgId;
		-- #
    
		-- Step11.4: hist_incident
		SET $Count = (SELECT COUNT(*) FROM hist_incident WHERE OrgId = $OrgId);
		-- ************
		INSERT INTO `ABCanTrackV2`.`delete_org_log`
			(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
		VALUES
			($OrgId, 'DeleteOrgHistories', 'hist_incident 11.4', NULL, $Count, 11);
		
		-- ************
		DELETE FROM hist_incident WHERE OrgId = $OrgId;
		-- #
	-- #
    
    
    -- Step12: CommonDB.hist_employee
	SET $Count = (SELECT COUNT(*) FROM `CommonDB`.`hist_employee` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgHistories', 'CommonDB.hist_employee', NULL, $Count, 12);
    
	-- ************
	DELETE FROM `CommonDB`.`hist_employee` WHERE OrgId = $OrgId;
    -- #
    
    
    -- Step13: CommonDB.hist_organization
	SET $Count = (SELECT COUNT(*) FROM `CommonDB`.`hist_organization` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgHistories', 'CommonDB.hist_organization', NULL, $Count, 13);
    
	-- ************
	DELETE FROM `CommonDB`.`hist_organization` WHERE OrgId = $OrgId;
    -- #
    
    
    -- Step14: CommonDB.hist_location1
	SET $Count = (SELECT COUNT(*) FROM `CommonDB`.`hist_location1` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgHistories', 'CommonDB.hist_location1', NULL, $Count, 14);
    
	-- ************
	DELETE FROM `CommonDB`.`hist_location1` WHERE OrgId = $OrgId;
    -- #
    
    
    -- Step15: CommonDB.hist_location2
	SET $Count = (SELECT COUNT(*) FROM `CommonDB`.`hist_location2` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgHistories', 'CommonDB.hist_location2', NULL, $Count, 15);
    
	-- ************
	DELETE FROM `CommonDB`.`hist_location2` WHERE OrgId = $OrgId;
    -- #
    
    
    -- Step16: CommonDB.hist_location3
	SET $Count = (SELECT COUNT(*) FROM `CommonDB`.`hist_location3` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgHistories', 'CommonDB.hist_location3', NULL, $Count, 16);
    
	-- ************
	DELETE FROM `CommonDB`.`hist_location3` WHERE OrgId = $OrgId;
    -- #
    
    
    -- Step17: CommonDB.hist_location4
	SET $Count = (SELECT COUNT(*) FROM `CommonDB`.`hist_location4` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgHistories', 'CommonDB.hist_location4', NULL, $Count, 17);
    
	-- ************
	DELETE FROM `CommonDB`.`hist_location4` WHERE OrgId = $OrgId;
    -- #
    
    -- Step18: DONE
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgHistories', 'DONE', NULL, NULL, 18);
    -- #    
    
END;
