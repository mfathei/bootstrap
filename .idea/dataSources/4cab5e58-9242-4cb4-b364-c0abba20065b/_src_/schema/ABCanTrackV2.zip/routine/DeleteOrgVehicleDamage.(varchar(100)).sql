CREATE PROCEDURE ABCanTrackV2.DeleteOrgVehicleDamage(IN `$OrgId` VARCHAR(100))
  BEGIN
	DECLARE $Count INT;
    
    
    -- Step1: impacts_ext_agency
	SET $Count = (SELECT COUNT(*) FROM impacts_ext_agency WHERE VehicleDamageId IN (SELECT VehicleDamageId FROM vehicle_damage WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId)));
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgVehicleDamage',  'impacts_ext_agency', NULL, $Count, 1);
    
	-- ************
	DELETE FROM impacts_ext_agency WHERE VehicleDamageId IN (SELECT VehicleDamageId FROM vehicle_damage WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId));
    -- #
    
    
    -- Step2: vehicle_damage
	SET $Count = (SELECT COUNT(*) FROM vehicle_damage WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId));
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgVehicleDamage',  'vehicle_damage', NULL, $Count, 2);
    
	-- ************
	DELETE FROM vehicle_damage WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId);
    -- #
    
    -- Step3: DONE
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgVehicleDamage', 'DONE', NULL, NULL, 3);
    -- # 
END;
