CREATE PROCEDURE ABCanTrackV2.InsertInto_inc_email_log(IN `$CorrectiveActionId` VARCHAR(100),
                                                       IN `$IncidentId`         VARCHAR(100),
                                                       IN `$EmailLogId`         VARCHAR(100))
  BEGIN
SET @VersionNumber = (SELECT MAX(VersionNumber) FROM hist_incident WHERE IncidentId = $IncidentId);
SET @HistIncidentId = (SELECT HistIncidentId FROM hist_incident WHERE IncidentId = $IncidentId AND VersionNumber = @VersionNumber);

INSERT INTO `inc_email_log`
	   (HistIncidentId, EmailLogId)
VALUES (@HistIncidentId,$EmailLogId);
                        

IF $CorrectiveActionId is not null and $CorrectiveActionId <> '' and $CorrectiveActionId <> '0'
THEN
	SET @HistCorrectiveActionId =(SELECT HistCorrectiveActionId from hist_corrective_action    
				where  hist_corrective_action.CorrectiveActionId  =$CorrectiveActionId  
                   and hist_corrective_action.HistIncidentId = @HistIncidentId )  ;
                
	INSERT INTO `corr_act_email`
				(HistCorrectiveActionId, EmailLogId)
		 VALUES (@HistCorrectiveActionId ,$EmailLogId);
 
END IF;

END;
