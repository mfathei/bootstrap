CREATE PROCEDURE ABCanTrackV2.DeleteOrgInjury(IN `$OrgId` VARCHAR(100))
  BEGIN
	DECLARE $Count INT;
    
    
    -- Step1: body_area_injury
	SET $Count = (SELECT COUNT(*) FROM body_area_injury WHERE InjuryId IN (SELECT InjuryId FROM injury WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId)));
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgInjury',  'body_area_injury', NULL, $Count, 1);
    
	-- ************
	DELETE FROM body_area_injury WHERE InjuryId IN (SELECT InjuryId FROM injury WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId));
    -- #
    
    
    -- Step2: body_part_injury
	SET $Count = (SELECT COUNT(*) FROM body_part_injury WHERE InjuryId IN (SELECT InjuryId FROM injury WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId)));
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgInjury',  'body_part_injury', NULL, $Count, 2);
    
	-- ************
	DELETE FROM body_part_injury WHERE InjuryId IN (SELECT InjuryId FROM injury WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId));
    -- #
    
    
    -- Step3: impacts_ext_agency
	SET $Count = (SELECT COUNT(*) FROM impacts_ext_agency WHERE InjuryId IN (SELECT InjuryId FROM injury WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId)));
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgInjury',  'impacts_ext_agency', NULL, $Count, 3);
    
	-- ************
	DELETE FROM impacts_ext_agency WHERE InjuryId IN (SELECT InjuryId FROM injury WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId));
    -- #
    
    
    -- Step4: injury_type_injury
	SET $Count = (SELECT COUNT(*) FROM injury_type_injury WHERE InjuryId IN (SELECT InjuryId FROM injury WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId)));
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgInjury',  'injury_type_injury', NULL, $Count, 4);
    
	-- ************
	DELETE FROM injury_type_injury WHERE InjuryId IN (SELECT InjuryId FROM injury WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId));
    -- #
    
    
    -- Step5: injury
	SET $Count = (SELECT COUNT(*) FROM injury WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId));
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgInjury',  'injury', NULL, $Count, 5);
    
	-- ************
	DELETE FROM injury WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId);
    -- #
    
    -- Step6: DONE
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgInjury', 'DONE', NULL, NULL, 6);
    -- # 
    
END;
