CREATE PROCEDURE ABCanTrackV2.GetOrgSubObservationAndAnalysis(IN xmlData TEXT)
  BEGIN
SET @Orgid = extractvalue(xmlData, '//OrgId');
SET @page = extractvalue(xmlData, '//page');
SET @limit = extractvalue(xmlData, '//limit');
SET @sortOrder =  extractvalue(xmlData, '//sortOrder');
SET @index =  extractvalue(xmlData, '//index');
SET @Export =  extractvalue(xmlData, '//Export');
SET @checkOrg =  extractvalue(xmlData, '//check');  
SET @ParentId =  extractvalue(xmlData, '//ParentId');
SET @ObservationAndAnalysisCode =  extractvalue(xmlData, '//ObservationAndAnalysisCode');
set @selectquery ="SELECT OrgName, sub_observ_ana_param_view.OrgId,ObservationAndAnalysisParamId, ObservationAndAnalysisParamName, ParentObservationAndAnalysisParamName as ParentObservationAndAnalysisParamId,
`Order`, sub_observ_ana_param_view.Hide, ParentId ";
                
set @queryFrom = " from sub_observ_ana_param_view inner join organization on sub_observ_ana_param_view.OrgId = organization.OrgId";
SET @queryWhere = ' where 1= 1 ';
if(@checkOrg  = 'false') then 
SET @queryWhere = CONCAT(@queryWhere,' and sub_observ_ana_param_view.OrgId =  "', @Orgid,'" ');
end if;
SET @queryWhere = CONCAT(@queryWhere,' and sub_observ_ana_param_view.Hide = 0 ');
SET @queryWhere = CONCAT(@queryWhere,' and sub_observ_ana_param_view.ParentHide = 0 ');
if( @ParentId != '' and @ParentId != 'null') then
SET @queryWhere = CONCAT(@queryWhere,' and sub_observ_ana_param_view.ParentId = "', @ParentId,'" ');
else 
SET @queryWhere = CONCAT(@queryWhere,' and ObservationAndAnalysisCode =  ',"'", @ObservationAndAnalysisCode,"'");
 end if;
SET @myArrayOfValue = 'ObservationAndAnalysisParamName,ParentObservationAndAnalysisParamId,Order,OrgName,';
SET @Postition = LOCATE(',', @myArrayOfValue);
-- select concat(@selectquery,@queryFrom, @queryWhere);
WHILE ( @Postition > 0 ) DO
 SET @STR = SUBSTRING(@myArrayOfValue, 1, @Postition-1);
 SET @myArrayOfValue = SUBSTRING(@myArrayOfValue, @Postition + 1);
 SET @Col =  extractvalue(xmlData, CONCAT('//',@STR));
 IF (@Col != '' AND @Col !='NULL') THEN 
 if( @STR = 'Order') then set  @STR = 'sub_observ_ana_param_view.`Order`';  end if;
 if( @STR = 'ParentObservationAndAnalysisParamId') then set  @STR = 'ParentObservationAndAnalysisParamName';  end if;
  SET @queryWhere = CONCAT(@queryWhere,CONCAT(' AND    ',@STR,'  like '"'%", @Col ,"%'"));
 END IF;
 
 SET @Postition = LOCATE(',', @myArrayOfValue);
END WHILE;
SET @querycount = CONCAT( 'SELECT count(*) into @cnt ', @queryFrom, @queryWhere );
PREPARE stmt1 FROM @querycount;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
	
SET @selectquery = CONCAT(@selectquery,', ', @cnt, ' as Count ');
SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );
if( @index = 'Order') then set  @index = '`Order`';  end if;
if( @index = 'ParentOrder') then set  @index = '`Order`';  end if;
if( @index = 'ParentObservationAndAnalysisParamId') then set  @index = 'ParentObservationAndAnalysisParamName';  end if;
if( @index ='ParentObservationAndAnalysisParamName,Order ') then set  @index = 'ParentObservationAndAnalysisParamName, sub_observ_ana_param_view.`Order`';  end if;
-- select @index;
SET @query = CONCAT(@query, ' order by ', @index,'  ', @sortOrder);
if( @Export ="false") then
SET @page = (@page - 1) * @limit;
SET @query = CONCAT(@query, ' LIMIT ', @limit ,' OFFSET ',  @page);
end if;
 -- select  @query;
PREPARE stmt1 FROM @query;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
-- select  @query;
END;
