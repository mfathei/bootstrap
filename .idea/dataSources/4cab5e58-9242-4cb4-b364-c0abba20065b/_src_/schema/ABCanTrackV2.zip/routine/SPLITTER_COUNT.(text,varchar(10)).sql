CREATE FUNCTION ABCanTrackV2.SPLITTER_COUNT(str TEXT, delim VARCHAR(10))
  RETURNS INT(6)
  IF str <> '' AND str IS NOT NULL AND POSITION(delim IN str) = 0 THEN
	RETURN 1;
    ELSE
		RETURN 
ROUND (   
(
    CHAR_LENGTH(str)
    - CHAR_LENGTH( REPLACE ( str, delim, "") ) 
) / CHAR_LENGTH(delim));
END IF;
