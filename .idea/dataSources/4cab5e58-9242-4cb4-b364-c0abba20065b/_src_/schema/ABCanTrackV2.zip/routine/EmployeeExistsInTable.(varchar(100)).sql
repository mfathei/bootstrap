CREATE FUNCTION ABCanTrackV2.EmployeeExistsInTable(`$EmployeeId` VARCHAR(100))
  RETURNS TEXT
  BEGIN
DECLARE $OccurIn TEXT;
SET $OccurIn = '';
IF  (SELECT  COUNT(*) FROM `alert_message` WHERE `EditingBy` = $EmployeeId) > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'alert_message', ' || ');
 END IF; 
IF  (SELECT  COUNT(*) FROM `benchmark` WHERE `EditingBy` = $EmployeeId) > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'benchmark', ' || ');
 END IF; 
IF  (SELECT  COUNT(*) FROM `body_area` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'body_area', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `body_part` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'body_part', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `certificate` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'certificate', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `city` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'city', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `contact` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'contact', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `contact_agency` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'contact_agency', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `contact_code` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'contact_code', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `corr_act_status` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'corr_act_status', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `corrective_action` WHERE `AssignedById` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'corrective_action.AssignedById', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `corrective_action` WHERE `AssignedToId` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'corrective_action.AssignedToId', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `corrective_action_notified` WHERE `EmployeeId` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'corrective_action_notified.EmployeeId', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `country` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'country', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `data_type` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'data_type', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `duration_unit` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'duration_unit', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `email_log` WHERE `CcEmployeeId` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'email_log.CcEmployeeId', ' || ');
 END IF;  
-- IF  (SELECT  COUNT(*) FROM `email_log` WHERE `CcEmployeeId` = $EmployeeId)  > 0 
/* THEN 
 	 SET $OccurIn = CONCAT($OccurIn, '', ' || ');
 END IF;  */
-- IF  (SELECT  COUNT(*) FROM `email_log` WHERE `SendToEmployeeId` = $EmployeeId)  > 0 
 /*THEN 
 	 SET $OccurIn = CONCAT($OccurIn, '', ' || ');
 END IF;  */
IF  (SELECT  COUNT(*) FROM `email_log` WHERE `SendToEmployeeId` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'email_log.SendToEmployeeId', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `email_to` WHERE `EmployeeId` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'email_to.EmployeeId', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `email_to_esc` WHERE `EmployeeId` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'email_to_esc.EmployeeId', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `emp_group` WHERE `EmployeeId` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'emp_group.EmployeeId', ' || ');
 END IF;  
-- IF  (SELECT  COUNT(*) FROM `emp_group` WHERE `EmployeeId` = $EmployeeId)  > 0 
 /*THEN 
 	 SET $OccurIn = CONCAT($OccurIn, '', ' || ');
 END IF; */ 
IF  (SELECT  COUNT(*) FROM `employee` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'employee', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `env_cond_parameter` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'env_cond_parameter', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `env_condition` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'env_condition', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `event_type` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'event_type', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `external_agency` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'external_agency', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `favorite_table` WHERE `EmployeeId` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'favorite_table.EmployeeId', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `favorite_type` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'favorite_type', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `field` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'field', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `field_type` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'field_type', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `hist_corrective_action` WHERE `UpdatedById` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'hist_corrective_action.UpdatedById', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `hist_field_value` WHERE `UpdatedById` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'hist_field_value.UpdatedById', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `hist_illness` WHERE `UpdatedById` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'hist_illness.UpdatedById', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `hist_impact` WHERE `UpdatedById` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'hist_impact.UpdatedById', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `hist_incident` WHERE `UpdatedById` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'hist_incident.UpdatedById', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `hist_injury` WHERE `UpdatedById` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'hist_injury.UpdatedById', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `hist_people_involved` WHERE `UpdatedById` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'hist_people_involved.UpdatedById', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `hist_spill_release` WHERE `UpdatedById` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'hist_spill_release.UpdatedById', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `hist_traffic_violation` WHERE `UpdatedById` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'hist_traffic_violation.UpdatedById', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `hist_vehicle_damage` WHERE `UpdatedById` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'hist_vehicle_damage.UpdatedById', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `history_operation` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'history_operation', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `illness` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'illness', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `illness` WHERE `IntEmployeeId1` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'illness.IntEmployeeId1', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `illness` WHERE `IntEmployeeId2` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'illness.IntEmployeeId2', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `illness` WHERE `IntEmployeeId3` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'illness.IntEmployeeId3', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `illness` WHERE `PersonalAfflictedId` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'illness.PersonalAfflictedId', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `illness` WHERE `PrimRespondId` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'illness.PrimRespondId', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `impact` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'impact', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `impact` WHERE `IntEmployeeId1` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'impact.IntEmployeeId1', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `impact` WHERE `IntEmployeeId2` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'impact.IntEmployeeId2', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `impact` WHERE `IntEmployeeId3` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'impact.IntEmployeeId3', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `impact` WHERE `PrimRespondId` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'impact.PrimRespondId', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `impact_sub_type` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'impact_sub_type', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `impact_type` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'impact_type', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `inc_deletion_info` WHERE `EmployeeId` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'inc_deletion_info.EmployeeId', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `incident` WHERE `CreatorId` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'incident.CreatorId', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `incident` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'incident', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `incident` WHERE `InvestigatorId1` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'incident.InvestigatorId1', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `incident` WHERE `InvestigatorId2` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'incident.InvestigatorId2', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `incident` WHERE `InvestigatorId3` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'incident.InvestigatorId3', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `incident` WHERE `ModifierId` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'incident.ModifierId', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `incident` WHERE `ReporterId` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'incident.ReporterId', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `incident` WHERE `SignOffInvestigatorId` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'incident.SignOffInvestigatorId', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `incident` WHERE `SignOffInvestigatorId` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'incident.SignOffInvestigatorId', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `incident_severity` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'incident_severity', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `initial_treatment` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'initial_treatment', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `injury` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'injury.', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `injury` WHERE `IntEmployeeId1` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'injury.IntEmployeeId1', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `injury` WHERE `IntEmployeeId2` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'injury.IntEmployeeId2', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `injury` WHERE `IntEmployeeId3` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'injury.IntEmployeeId3', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `injury` WHERE `PersonalInjuredId` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'injury.PersonalInjuredId', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `injury` WHERE `PrimRespondId` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'injury.PrimRespondId', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `injury_recordable` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'injury_recordable', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `injury_type` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'injury_type', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `inv_source` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'inv_source', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `inv_status` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'inv_status', ' || ');
 END IF;  
-- IF  (SELECT  COUNT(*) FROM `language` WHERE `EditingBy` = $EmployeeId)  > 0 
 /*THEN 
 	 SET $OccurIn = CONCAT($OccurIn, '', ' || ');
 END IF;  */
IF  (SELECT  COUNT(*) FROM `language` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'language', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `location1` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'location1', ' || ');
 END IF;  
-- IF  (SELECT  COUNT(*) FROM `location1` WHERE `EditingBy` = $EmployeeId)  > 0 
/* THEN 
 	 SET $OccurIn = CONCAT($OccurIn, '', ' || ');
 END IF;  */
IF  (SELECT  COUNT(*) FROM `location2` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'location2', ' || ');
 END IF;  
-- IF  (SELECT  COUNT(*) FROM `location2` WHERE `EditingBy` = $EmployeeId)  > 0 
 /*THEN 
 	 SET $OccurIn = CONCAT($OccurIn, '', ' || ');
 END IF;  */
IF  (SELECT  COUNT(*) FROM `location3` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'location3', ' || ');
 END IF;  
-- IF  (SELECT  COUNT(*) FROM `location3` WHERE `EditingBy` = $EmployeeId)  > 0 
 /*THEN 
 	 SET $OccurIn = CONCAT($OccurIn, '', ' || ');
 END IF; */ 
IF  (SELECT  COUNT(*) FROM `location4` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'location4', ' || ');
 END IF;  
-- IF  (SELECT  COUNT(*) FROM `location4` WHERE `EditingBy` = $EmployeeId)  > 0 
 /*THEN 
 	 SET $OccurIn = CONCAT($OccurIn, '', ' || ');
 END IF;  */
IF  (SELECT  COUNT(*) FROM `observation_analysis` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'observation_analysis', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `observation_analysis_param` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'observation_analysis_param', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `oe_department` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'oe_department', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `operation` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'operation', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `operation_type` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'operation_type', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `option` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'option', ' || ');
 END IF;  
-- IF  (SELECT  COUNT(*) FROM `org_employee` WHERE `EmployeeId` = $EmployeeId)  > 0 
 /*THEN 
 	 SET $OccurIn = CONCAT($OccurIn, '', ' || ');
 END IF; */ 
-- IF  (SELECT  COUNT(*) FROM `org_employee` WHERE `EmployeeId` = $EmployeeId)  > 0 
 /*THEN 
 	 SET $OccurIn = CONCAT($OccurIn, '', ' || ');
 END IF;  */
IF  (SELECT  COUNT(*) FROM `organization` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'organization', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `output_type` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'output_type', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `people_involved` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'people_involved.', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `people_involved` WHERE `PeopleId` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'people_involved.PeopleId', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `priority` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'priority', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `province` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'province', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `quantity_unit` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'quantity_unit', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `restricted_work` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'restricted_work', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `risk_of_recurrence` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'risk_of_recurrence', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `root_cause` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'root_cause', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `root_cause_param` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'root_cause_param', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `sp_rel_agency` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'sp_rel_agency', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `spill_release` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'spill_release', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `spill_release` WHERE `IntEmployeeId1` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'spill_release.IntEmployeeId1', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `spill_release` WHERE `IntEmployeeId2` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'spill_release.IntEmployeeId2', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `spill_release` WHERE `IntEmployeeId3` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'spill_release.IntEmployeeId3', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `spill_release` WHERE `PrimRespondId` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'spill_release.PrimRespondId', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `spill_release_source` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'spill_release_source', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `stat_table` WHERE `EmployeeId` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'stat_table', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `sub_tab` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'sub_tab', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `symptoms` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'symptoms', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `tab` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'tab', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `template` WHERE `EmployeeId` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'template.EmployeeId', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `third_party` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'third_party', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `third_party` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'third_party', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `third_party_type` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'third_party_type', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `third_party_type` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'third_party_type', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `time_frame` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'time_frame', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `traffic_violation` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'traffic_violation', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `traffic_violation` WHERE `IntEmployeeId1` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'traffic_violation.IntEmployeeId1', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `traffic_violation` WHERE `IntEmployeeId2` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'traffic_violation.IntEmployeeId2', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `traffic_violation` WHERE `IntEmployeeId3` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'traffic_violation.IntEmployeeId3', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `traffic_violation` WHERE `PrimRespondId` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'traffic_violation.PrimRespondId', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `vehicle_damage` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'vehicle_damage', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `vehicle_damage` WHERE `IntEmployeeId1` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'vehicle_damage.IntEmployeeId1', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `vehicle_damage` WHERE `IntEmployeeId2` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'vehicle_damage.IntEmployeeId2', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `vehicle_damage` WHERE `IntEmployeeId3` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'vehicle_damage.IntEmployeeId3', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `vehicle_damage` WHERE `PrimRespondId` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'vehicle_damage.PrimRespondId', ' || ');
 END IF;  
IF  (SELECT  COUNT(*) FROM `vehicle_type` WHERE `EditingBy` = $EmployeeId)  > 0 
 THEN 
 	 SET $OccurIn = CONCAT($OccurIn, 'vehicle_type');
 END IF;  
 
-- Checking in CommonDB
IF  (SELECT COUNT(*) FROM `CommonDB`.`email_log` WHERE `CcEmployeeId` = $EmployeeId) > 0
 THEN
  SET $OccurIn = CONCAT($OccurIn, 'email_log.CcEmployeeId', ' || ');
 END IF; 
IF  (SELECT COUNT(*) FROM `CommonDB`.`email_log` WHERE `SendToEmployeeId` = $EmployeeId) > 0
 THEN
  SET $OccurIn = CONCAT($OccurIn, 'email_log.SendToEmployeeId', ' || ');
 END IF; 
IF  (SELECT COUNT(*) FROM `CommonDB`.`emp_dashboard` WHERE `EmployeeId` = $EmployeeId) > 0
 THEN
  SET $OccurIn = CONCAT($OccurIn, 'emp_dashboard.EmployeeId', ' || ');
 END IF; 
IF  (SELECT COUNT(*) FROM `CommonDB`.`emp_group` WHERE `EmployeeId` = $EmployeeId) > 0
 THEN
  SET $OccurIn = CONCAT($OccurIn, 'emp_group.EmployeeId', ' || ');
 END IF; 
IF  (SELECT COUNT(*) FROM `CommonDB`.`hist_employee` WHERE `UpdatedById` = $EmployeeId) > 0
 THEN
  SET $OccurIn = CONCAT($OccurIn, 'hist_employee.UpdatedById', ' || ');
 END IF; 
IF  (SELECT COUNT(*) FROM `CommonDB`.`hist_location1` WHERE `UpdatedById` = $EmployeeId) > 0
 THEN
  SET $OccurIn = CONCAT($OccurIn, 'hist_location1.UpdatedById', ' || ');
 END IF; 
IF  (SELECT COUNT(*) FROM `CommonDB`.`hist_location2` WHERE `UpdatedById` = $EmployeeId) > 0
 THEN
  SET $OccurIn = CONCAT($OccurIn, 'hist_location2.UpdatedById', ' || ');
 END IF; 
IF  (SELECT COUNT(*) FROM `CommonDB`.`hist_location3` WHERE `UpdatedById` = $EmployeeId) > 0
 THEN
  SET $OccurIn = CONCAT($OccurIn, 'hist_location3.UpdatedById', ' || ');
 END IF; 
IF  (SELECT COUNT(*) FROM `CommonDB`.`hist_location4` WHERE `UpdatedById` = $EmployeeId) > 0
 THEN
  SET $OccurIn = CONCAT($OccurIn, 'hist_location4.UpdatedById', ' || ');
 END IF; 
IF  (SELECT COUNT(*) FROM `CommonDB`.`hist_third_party` WHERE `UpdatedById` = $EmployeeId) > 0
 THEN
  SET $OccurIn = CONCAT($OccurIn, 'hist_third_party.UpdatedById', ' || ');
 END IF; 
IF  (SELECT COUNT(*) FROM `CommonDB`.`language` WHERE `EditingBy` = $EmployeeId) > 0
 THEN
  SET $OccurIn = CONCAT($OccurIn, 'language', ' || ');
 END IF; 
IF  (SELECT COUNT(*) FROM `CommonDB`.`location1` WHERE `EditingBy` = $EmployeeId) > 0
 THEN
  SET $OccurIn = CONCAT($OccurIn, 'location1', ' || ');
 END IF; 
IF  (SELECT COUNT(*) FROM `CommonDB`.`location2` WHERE `EditingBy` = $EmployeeId) > 0
 THEN
  SET $OccurIn = CONCAT($OccurIn, 'location2', ' || ');
 END IF; 
IF  (SELECT COUNT(*) FROM `CommonDB`.`location3` WHERE `EditingBy` = $EmployeeId) > 0
 THEN
  SET $OccurIn = CONCAT($OccurIn, 'location3', ' || ');
 END IF; 
IF  (SELECT COUNT(*) FROM `CommonDB`.`location4` WHERE `EditingBy` = $EmployeeId) > 0
 THEN
  SET $OccurIn = CONCAT($OccurIn, 'location4', ' || ');
 END IF; 
IF  (SELECT COUNT(*) FROM `CommonDB`.`location_request` WHERE `EditingBy` = $EmployeeId) > 0
 THEN
  SET $OccurIn = CONCAT($OccurIn, 'location_request', ' || ');
 END IF; 
IF  (SELECT COUNT(*) FROM `CommonDB`.`location_request` WHERE `EmployeeId` = $EmployeeId) > 0
 THEN
  SET $OccurIn = CONCAT($OccurIn, 'location_request.EmployeeId', ' || ');
 END IF; 
IF  (SELECT COUNT(*) FROM `CommonDB`.`location_request` WHERE `RepliedById` = $EmployeeId) > 0
 THEN
  SET $OccurIn = CONCAT($OccurIn, 'location_request.RepliedById', ' || ');
 END IF; 
IF  (SELECT COUNT(*) FROM `CommonDB`.`login_history` WHERE `EmployeeId` = $EmployeeId) > 0
 THEN
  SET $OccurIn = CONCAT($OccurIn, 'login_history.EmployeeId', ' || ');
 END IF; 
IF  (SELECT COUNT(*) FROM `CommonDB`.`operation_type` WHERE `EditingBy` = $EmployeeId) > 0
 THEN
  SET $OccurIn = CONCAT($OccurIn, 'operation_type', ' || ');
 END IF; 
IF  (SELECT COUNT(*) FROM `CommonDB`.`org_employee` WHERE `EmployeeId` = $EmployeeId) > 0
 THEN
  SET $OccurIn = CONCAT($OccurIn, 'org_employee.EmployeeId', ' || ');
 END IF; 
IF  (SELECT COUNT(*) FROM `CommonDB`.`org_employee` WHERE `SupervisorId` = $EmployeeId) > 0
 THEN
  SET $OccurIn = CONCAT($OccurIn, 'org_employee.SupervisorId', ' || ');
 END IF; 
IF  (SELECT COUNT(*) FROM `CommonDB`.`organization` WHERE `SystemAdminId` = $EmployeeId) > 0
 THEN
  SET $OccurIn = CONCAT($OccurIn, 'organization.SystemAdminId', ' || ');
 END IF; 
IF  (SELECT COUNT(*) FROM `CommonDB`.`third_party` WHERE `EditingBy` = $EmployeeId) > 0
 THEN
  SET $OccurIn = CONCAT($OccurIn, 'third_party', ' || ');
 END IF; 
IF  (SELECT COUNT(*) FROM `CommonDB`.`third_party_type` WHERE `EditingBy` = $EmployeeId) > 0
 THEN
  SET $OccurIn = CONCAT($OccurIn, 'third_party_type', ' || ');
 END IF; 
RETURN $OccurIn;
END;
