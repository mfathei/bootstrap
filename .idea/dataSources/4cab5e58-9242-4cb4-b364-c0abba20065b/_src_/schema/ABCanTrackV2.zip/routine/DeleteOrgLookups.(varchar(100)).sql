CREATE PROCEDURE ABCanTrackV2.DeleteOrgLookups(IN `$OrgId` VARCHAR(100))
  BEGIN
	DECLARE $Count INT;
    
    
    -- Step1: body_area
	SET $Count = (SELECT COUNT(*) from `ABCanTrackV2`.`body_area` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgLookups',  'body_area', NULL, $Count, 1);
    
	-- ************
	DELETE FROM body_area WHERE OrgId = $OrgId;
    -- #
    
    
    -- Step2: body_part
	SET $Count = (SELECT COUNT(*) from `ABCanTrackV2`.`body_part` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgLookups',  'body_part', NULL, $Count, 2);
    
	-- ************
	DELETE FROM body_part WHERE OrgId = $OrgId;
    -- #
    
    
    -- Step3: certificate
	SET $Count = (SELECT COUNT(*) from `ABCanTrackV2`.`certificate` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgLookups',  'certificate', NULL, $Count, 3);
    
	-- ************
	DELETE FROM certificate WHERE OrgId = $OrgId;
    -- #
    
    
    -- Step4: contact
	SET $Count = (SELECT COUNT(*) from `ABCanTrackV2`.`contact` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgLookups',  'contact', NULL, $Count, 4);
    
	-- ************
	DELETE FROM contact WHERE OrgId = $OrgId;
    -- # 
    
    
    -- Step5: contact_agency
	SET $Count = (SELECT COUNT(*) from `ABCanTrackV2`.`contact_agency` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgLookups',  'contact_agency', NULL, $Count, 5);
    
	-- ************
	DELETE FROM contact_agency WHERE OrgId = $OrgId;
    -- #  
    -- ==========================================================================================================================================
    
    -- Step6: contact_code
	SET $Count = (SELECT COUNT(*) from `ABCanTrackV2`.`contact_code` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgLookups',  'contact_code', NULL, $Count, 6);
    
	-- ************
	DELETE FROM contact_code WHERE OrgId = $OrgId;
    -- #
    
    
    -- Step7: corr_act_status
	SET $Count = (SELECT COUNT(*) from `ABCanTrackV2`.`corr_act_status` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgLookups',  'corr_act_status', NULL, $Count, 7);
    
	-- ************
	DELETE FROM corr_act_status WHERE OrgId = $OrgId;
    -- #
    
    
    -- Step8: duration_unit
	SET $Count = (SELECT COUNT(*) from `ABCanTrackV2`.`duration_unit` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgLookups',  'duration_unit', NULL, $Count, 8);
    
	-- ************
	DELETE FROM duration_unit WHERE OrgId = $OrgId;
    -- #
    
    -- Step9: env_cond
    
		-- Step9.1: env_cond_parameter
		SET $Count = (SELECT COUNT(*) from `ABCanTrackV2`.`env_cond_parameter` WHERE EnvConditionId in (SELECT EnvConditionId FROM `ABCanTrackV2`.`env_condition` WHERE OrgId = $OrgId ));
		-- ************
		INSERT INTO `ABCanTrackV2`.`delete_org_log`
			(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
		VALUES
			($OrgId, 'DeleteOrgLookups',  'env_cond_parameter 9.1', NULL, $Count, 9);
		
		-- ************
		DELETE FROM `ABCanTrackV2`.`env_cond_parameter` WHERE EnvConditionId IN (SELECT EnvConditionId FROM `ABCanTrackV2`.`env_condition` WHERE OrgId = $OrgId );
		-- #
        
		-- Step9.2: env_cond
		SET $Count = (SELECT COUNT(*) from `ABCanTrackV2`.`env_condition` WHERE OrgId = $OrgId);
		-- ************
		INSERT INTO `ABCanTrackV2`.`delete_org_log`
			(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
		VALUES
			($OrgId, 'DeleteOrgLookups',  'env_condition 9.2', NULL, $Count, 9);
		
		-- ************
		DELETE FROM `ABCanTrackV2`.`env_condition` WHERE OrgId = $OrgId ;
		-- #
        
	-- #
    
    
    -- Step10: event_type
	SET $Count = (SELECT COUNT(*) from `ABCanTrackV2`.`event_type` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgLookups',  'event_type', NULL, $Count, 10);
    
	-- ************
	DELETE FROM event_type WHERE OrgId = $OrgId;
    -- #
    
    
    -- Step11: external_agency
	SET $Count = (SELECT COUNT(*) from `ABCanTrackV2`.`external_agency` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgLookups',  'external_agency', NULL, $Count, 11);
    
	-- ************
	DELETE FROM external_agency WHERE OrgId = $OrgId;
    -- #
    
    
    -- Step12: impact_type
    
		-- Step12.1: impact_sub_type
		SET $Count = (SELECT COUNT(*) from `ABCanTrackV2`.`impact_sub_type` WHERE ImpactTypeId in (SELECT ImpactTypeId FROM `ABCanTrackV2`.`impact_type`  WHERE OrgId = $OrgId ));
		-- ************
		INSERT INTO `ABCanTrackV2`.`delete_org_log`
			(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
		VALUES
			($OrgId, 'DeleteOrgLookups',  'impact_sub_type 12.1', NULL, $Count, 12);
		
		-- ************
		DELETE FROM `ABCanTrackV2`.`impact_sub_type` WHERE ImpactTypeId IN (SELECT ImpactTypeId FROM `ABCanTrackV2`.`impact_type`  WHERE OrgId = $OrgId );
		-- #
		
		-- Step12.2: impact_sub_type
		SET $Count = (SELECT COUNT(*) from `ABCanTrackV2`.`impact_type`  WHERE OrgId = $OrgId);
		-- ************
		INSERT INTO `ABCanTrackV2`.`delete_org_log`
			(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
		VALUES
			($OrgId, 'DeleteOrgLookups',  'impact_sub_type 12.2', NULL, $Count, 12);
		
		-- ************
		DELETE FROM `ABCanTrackV2`.`impact_type`  WHERE OrgId = $OrgId ;
		-- #
        
	-- #
    
    
    -- Step13: incident_severity
	SET $Count = (SELECT COUNT(*) from `ABCanTrackV2`.`incident_severity` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgLookups',  'incident_severity', NULL, $Count, 13);
    
	-- ************
	DELETE FROM incident_severity WHERE OrgId = $OrgId;
    -- #
    
    
    -- Step14: initial_treatment
	SET $Count = (SELECT COUNT(*) from `ABCanTrackV2`.`initial_treatment` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgLookups',  'initial_treatment', NULL, $Count, 14);
    
	-- ************
	DELETE FROM initial_treatment WHERE OrgId = $OrgId;
    -- #
    
    
    -- Step15: injury_recordable
	SET $Count = (SELECT COUNT(*) from `ABCanTrackV2`.`injury_recordable` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgLookups',  'injury_recordable', NULL, $Count, 15);
    
	-- ************
	DELETE FROM injury_recordable WHERE OrgId = $OrgId;
    -- # 
    
    
    -- Step16: injury_type
	SET $Count = (SELECT COUNT(*) from `ABCanTrackV2`.`injury_type` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgLookups',  'injury_type', NULL, $Count, 16);
    
	-- ************
	DELETE FROM injury_type WHERE OrgId = $OrgId;
    -- #
    
    
    -- Step17: inv_source
	SET $Count = (SELECT COUNT(*) from `ABCanTrackV2`.`inv_source` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgLookups',  'inv_source', NULL, $Count, 17);
    
	-- ************
	DELETE FROM inv_source WHERE OrgId = $OrgId;
    -- #
    
    
    -- Step18: inv_status
	SET $Count = (SELECT COUNT(*) from `ABCanTrackV2`.`inv_status` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgLookups',  'inv_status', NULL, $Count, 18);
    
	-- ************
	DELETE FROM inv_status WHERE OrgId = $OrgId;
    -- #
    
    
    -- Step19: observation_analysis
		-- Step19.1: observation_analysis_param
		SET $Count = (SELECT COUNT(*) from `ABCanTrackV2`.`observation_analysis_param` WHERE ObservationAndAnalysisId IN (SELECT ObservationAndAnalysisId FROM `ABCanTrackV2`.`observation_analysis` WHERE OrgId = $OrgId ) /*AND ParentId IS NOT NULL*/ );
		-- ************
		INSERT INTO `ABCanTrackV2`.`delete_org_log`
			(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
		VALUES
			($OrgId, 'DeleteOrgLookups',  'observation_analysis_param 19.1', NULL, $Count, 19);
		
		-- ************
		DELETE FROM `ABCanTrackV2`.`observation_analysis_param` WHERE ObservationAndAnalysisId IN (SELECT ObservationAndAnalysisId FROM `ABCanTrackV2`.`observation_analysis` WHERE OrgId = $OrgId ) ORDER BY ParentId DESC;
		-- #
        
		-- Step19.2: observation_analysis
		SET $Count = (SELECT COUNT(*) FROM `ABCanTrackV2`.`observation_analysis` WHERE OrgId = $OrgId);
		-- ************
		INSERT INTO `ABCanTrackV2`.`delete_org_log`
			(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
		VALUES
			($OrgId, 'DeleteOrgLookups',  'observation_analysis 19.2', NULL, $Count, 19);
		
		-- ************
		DELETE FROM `ABCanTrackV2`.`observation_analysis` WHERE OrgId = $OrgId ;
		-- #
	
    -- #
    
    
    -- Step20: oe_department
	SET $Count = (SELECT COUNT(*) from `ABCanTrackV2`.`oe_department` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgLookups',  'oe_department', NULL, $Count, 20);
    
	-- ************
	DELETE FROM oe_department WHERE OrgId = $OrgId;
    -- #
    
    
    -- Step21: priority
	SET $Count = (SELECT COUNT(*) from `ABCanTrackV2`.`priority` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgLookups',  'priority', NULL, $Count, 21);
    
	-- ************
	DELETE FROM priority WHERE OrgId = $OrgId;
    -- #
    
    
    -- Step22: quantity_unit
	SET $Count = (SELECT COUNT(*) from `ABCanTrackV2`.`quantity_unit` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgLookups',  'quantity_unit', NULL, $Count, 22);
    
	-- ************
	DELETE FROM quantity_unit WHERE OrgId = $OrgId;
    -- #
    
    
    -- Step23: risk_of_recurrence
	SET $Count = (SELECT COUNT(*) from `ABCanTrackV2`.`risk_of_recurrence` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgLookups',  'risk_of_recurrence', NULL, $Count, 23);
    
	-- ************
	DELETE FROM risk_of_recurrence WHERE OrgId = $OrgId;
    -- #
    
    
    -- Step23: root_cause
    
		-- Step24.1: root_cause_param
		SET $Count = (SELECT COUNT(*) FROM `ABCanTrackV2`.`root_cause_param` WHERE RootCauseId IN (SELECT RootCauseId FROM `ABCanTrackV2`.`root_cause` WHERE OrgId = $OrgId ));
		-- ************
		INSERT INTO `ABCanTrackV2`.`delete_org_log`
			(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
		VALUES
			($OrgId, 'DeleteOrgLookups',  'root_cause_param 24.1', NULL, $Count, 24);
		
		-- ************
		DELETE FROM `ABCanTrackV2`.`root_cause_param` WHERE RootCauseId IN (SELECT RootCauseId FROM `ABCanTrackV2`.`root_cause` WHERE OrgId = $OrgId);
		-- #
        
		-- Step23.2: root_cause
		SET $Count = (SELECT COUNT(*) FROM `ABCanTrackV2`.`root_cause` WHERE OrgId = $OrgId);
		-- ************
		INSERT INTO `ABCanTrackV2`.`delete_org_log`
			(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
		VALUES
			($OrgId, 'DeleteOrgLookups',  'root_cause 24.2', NULL, $Count, 24);
		
		-- ************
		DELETE FROM `ABCanTrackV2`.`root_cause` WHERE OrgId = $OrgId;
		-- #
        
	-- #
    
    
    -- Step25: spill_release_source
	SET $Count = (SELECT COUNT(*) from `ABCanTrackV2`.`spill_release_source` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgLookups',  'spill_release_source', NULL, $Count, 25);
    
	-- ************
	DELETE FROM spill_release_source WHERE OrgId = $OrgId;
    -- #
    
    
    -- Step26: symptoms
	SET $Count = (SELECT COUNT(*) from `ABCanTrackV2`.`symptoms` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgLookups',  'symptoms', NULL, $Count, 26);
    
	-- ************
	DELETE FROM symptoms WHERE OrgId = $OrgId;
    -- # 
    
    
    -- Step27: vehicle_type
	SET $Count = (SELECT COUNT(*) from `ABCanTrackV2`.`vehicle_type` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgLookups',  'vehicle_type', NULL, $Count, 27);
    
	-- ************
	DELETE FROM vehicle_type WHERE OrgId = $OrgId;
    -- #
    
    
    -- Step28: ABCanTrackV2.operation_type
	SET $Count = (SELECT COUNT(*) from `ABCanTrackV2`.`operation_type` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgLookups',  'ABCanTrackV2.operation_type', NULL, $Count, 28);
    
	-- ************
	DELETE FROM `ABCanTrackV2`.`operation_type` WHERE OrgId = $OrgId;
    -- #
    
    
    -- Step29: CommonDB.operation_type
	SET $Count = (SELECT COUNT(*) from `CommonDB`.`operation_type` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgLookups',  'CommonDB.operation_type', NULL, $Count, 29);
    
	-- ************
	DELETE FROM `CommonDB`.`operation_type` WHERE OrgId = $OrgId;
    -- #
    
    
    -- Step30: ABCanTrackV2.email_template
	SET $Count = (SELECT COUNT(*) from `ABCanTrackV2`.`email_template` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgLookups',  'ABCanTrackV2.email_template', NULL, $Count, 30);
    
	-- ************
	DELETE FROM `ABCanTrackV2`.`email_template` WHERE OrgId = $OrgId;
    -- #
    
    
    -- Step31: CommonDB.email_template
	SET $Count = (SELECT COUNT(*) from `CommonDB`.`email_template` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgLookups',  'CommonDB.email_template', NULL, $Count, 31);
    
	-- ************
	DELETE FROM `CommonDB`.`email_template` WHERE OrgId = $OrgId;
    -- #
    
    
    -- Step32: ABCanTrackV2.template
		-- Step32.1: ABCanTrackV2.template_field
		SET $Count = (SELECT COUNT(*) FROM `ABCanTrackV2`.`template_field` WHERE TemplateId IN (SELECT TemplateId FROM `ABCanTrackV2`.`template` WHERE OrgId = $OrgId));
		-- ************
		INSERT INTO `ABCanTrackV2`.`delete_org_log`
			(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
		VALUES
			($OrgId, 'DeleteOrgLookups',  'ABCanTrackV2.template_field 32.1', NULL, $Count, 32);
		
		-- ************
		DELETE FROM `ABCanTrackV2`.`template_field` WHERE TemplateId IN (SELECT TemplateId FROM `ABCanTrackV2`.`template` WHERE OrgId = $OrgId);
		-- #
        
		-- Step32.2: ABCanTrackV2.template
		SET $Count = (SELECT COUNT(*) from `ABCanTrackV2`.`template` WHERE OrgId = $OrgId);
		-- ************
		INSERT INTO `ABCanTrackV2`.`delete_org_log`
			(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
		VALUES
			($OrgId, 'DeleteOrgLookups',  'ABCanTrackV2.template 32.2', NULL, $Count, 32);
		
		-- ************
		DELETE FROM `ABCanTrackV2`.`template` WHERE OrgId = $OrgId;
		-- #
	-- #
    
    
    -- Step33: ABCanTrackV2.restricted_work
	SET $Count = (SELECT COUNT(*) from `ABCanTrackV2`.`restricted_work` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgLookups',  'ABCanTrackV2.restricted_work', NULL, $Count, 33);
    
	-- ************
	DELETE FROM `ABCanTrackV2`.`restricted_work` WHERE OrgId = $OrgId;
    -- #
    DELETE FROM `ABCanTrackV2`.`sp_rel_agency` WHERE OrgId = $OrgId;
    
    -- Step34: DONE
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgLookups',  'DONE', NULL, $Count, 34);
END;
