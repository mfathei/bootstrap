CREATE PROCEDURE ABCanTrackV2.deleteOrgIncidents(IN `$OrgId` VARCHAR(100))
  begin

    declare eid varchar(255);
    declare finished int default 0;

	DECLARE g_p_cursor CURSOR FOR
	SELECT IncidentId FROM ABCanTrackV2.incident where OrgId = $OrgId; -- 'cs4sql-1e88d9ec-7db3-11e5-850e-5254000a52fa';
 -- declare NOT FOUND handler
	DECLARE CONTINUE HANDLER 
	FOR NOT FOUND SET finished = 1;

set @counter = 0;
 
 OPEN g_p_cursor;
-- FETCH g_p_cursor INTO $gid , $fcode, $pcode, $pid;
ex: LOOP
	FETCH g_p_cursor INTO eid ;
	IF finished = 1 THEN 
		LEAVE ex;
	END IF;
    
    CALL DeleteFrom_incident(eid);
    insert into log_deleted_incidents(incidentid) values(eid);
    
    set @counter = @counter + 1;
    
end loop ex;
    
close g_p_cursor;

select @counter;

end;
