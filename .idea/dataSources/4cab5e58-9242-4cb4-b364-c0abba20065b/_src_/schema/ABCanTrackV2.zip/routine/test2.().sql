CREATE PROCEDURE ABCanTrackV2.test2()
  BEGIN
SET @parent_id = 24;
IF (@parent_id is not null) then
Select @parent_id;
END IF;
END;
