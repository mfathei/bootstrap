CREATE PROCEDURE ABCanTrackV2.UpdateDefaultParentLookup(IN `$OrgId` VARCHAR(100))
  BEGIN
DECLARE $Min, $Max, $PMin, $PMax, $CurId, $PCurId VARCHAR(100);
DELETE FROM `env_cond_parameter` WHERE EnvConditionId IN (SELECT EnvConditionId FROM env_condition WHERE OrgId IS NULL) ;
DELETE FROM `env_condition` WHERE OrgId IS NULL;
-- Loop for insert into env_condition and env_cond_parameter --
SET $Min = (select min(EnvConditionId) from env_condition where OrgId = $OrgId);
SET $Max = (select max(EnvConditionId) from env_condition where OrgId =  $OrgId);
select $Min;
select $Max;
EnvLoop: While $Min <= $Max
do 
select $Min;
INSERT INTO `ABCanTrackV2`.`env_condition`
(
    `env_condition`.`EnvConditionName`,
    `env_condition`.`OrgId`,
    `env_condition`.`IsMulti`,
    `env_condition`.`Order`,
    `env_condition`.`LastUpdateDate`,
    `env_condition`.`EditingBy`,
    `env_condition`.`Hide`
)
SELECT 
    `env_condition`.`EnvConditionName`,
     NULL,
    `env_condition`.`IsMulti`,
    `env_condition`.`Order`,
    `env_condition`.`LastUpdateDate`,
    `env_condition`.`EditingBy`,
    `env_condition`.`Hide`
FROM `ABCanTrackV2`.`env_condition` where EnvConditionId = $Min;
SET $CurId = (SELECT LastId from last_uuid where TableName = 'env_condition');
INSERT INTO `ABCanTrackV2`.`env_cond_parameter`
(
    `env_cond_parameter`.`EnvCondParameterName`,
    `env_cond_parameter`.`EnvConditionId`,
    `env_cond_parameter`.`Order`,
    `env_cond_parameter`.`LastUpdateDate`,
    `env_cond_parameter`.`EditingBy`,
    `env_cond_parameter`.`Hide`
)
SELECT
    `env_cond_parameter`.`EnvCondParameterName`,
    $CurId,
    `env_cond_parameter`.`Order`,
    `env_cond_parameter`.`LastUpdateDate`,
    `env_cond_parameter`.`EditingBy`,
    `env_cond_parameter`.`Hide`
FROM `ABCanTrackV2`.`env_cond_parameter` where EnvConditionId = $Min;
IF $Min = $Max then
LEAVE EnvLoop;
Else
SET $Min = (select min(EnvConditionId) from env_condition where OrgId =  $OrgId and EnvConditionId > $Min);
END IF;
END While;
-- end env_condition and env_cond_parameter Loop --
DELETE FROM `impact_sub_type` WHERE ImpactTypeId IN (SELECT ImpactTypeId FROM impact_type WHERE OrgId IS NULL) ;
DELETE FROM `impact_type` WHERE OrgId IS NULL;
-- Loop for insert into impact_type and impact_sub_type --
SET $Min = (select min(ImpactTypeId) from impact_type where OrgId =  $OrgId);
SET $Max = (select max(ImpactTypeId) from impact_type where OrgId =  $OrgId);
ImpactLoop: While $Min <= $Max
DO
INSERT INTO `ABCanTrackV2`.`impact_type` 
(
    `impact_type`.`ImpactTypeName`,
    `impact_type`.`ImpactTypeCode`,
    `impact_type`.`IsPotential`,
    `impact_type`.`OrgId`,
    `impact_type`.`Order`,
    `impact_type`.`LastUpdateDate`,
    `impact_type`.`EditingBy`,
    `impact_type`.`Hide`
)
SELECT
    `impact_type`.`ImpactTypeName`,
    `impact_type`.`ImpactTypeCode`,
    `impact_type`.`IsPotential`,
     NULL,
    `impact_type`.`Order`,
    `impact_type`.`LastUpdateDate`,
    `impact_type`.`EditingBy`,
    `impact_type`.`Hide`
FROM `ABCanTrackV2`.`impact_type` where ImpactTypeId = $Min;
SET $CurId = (SELECT LastId from last_uuid where TableName = 'impact_type');
INSERT INTO `ABCanTrackV2`.`impact_sub_type`
(    
	`impact_sub_type`.`ImpactSubTypeName`,
    `impact_sub_type`.`ImpactTypeId`,
    `impact_sub_type`.`Order`,
    `impact_sub_type`.`LastUpdateDate`,
    `impact_sub_type`.`EditingBy`,
    `impact_sub_type`.`Hide`
)
SELECT 
    `impact_sub_type`.`ImpactSubTypeName`,
    $CurId,
    `impact_sub_type`.`Order`,
    `impact_sub_type`.`LastUpdateDate`,
    `impact_sub_type`.`EditingBy`,
    `impact_sub_type`.`Hide`
FROM `ABCanTrackV2`.`impact_sub_type` where ImpactTypeId = $Min;
IF $Min = $Max then
LEAVE ImpactLoop;
Else
SET $Min = (select min(ImpactTypeId) from impact_type where OrgId =  $OrgId and ImpactTypeId > $Min);
END IF;
END While;
-- end impact_type and impact_sub_type Loop --
DELETE FROM `observation_analysis_param` WHERE ObservationAndAnalysisId IN (SELECT ObservationAndAnalysisId FROM observation_analysis WHERE OrgId IS NULL) ;
DELETE FROM `observation_analysis` WHERE OrgId IS NULL;
-- Loop for insert into observation_analysis and observation_analysis_param --
SET $Min = (select min(ObservationAndAnalysisId) from observation_analysis where OrgId =  $OrgId);
SET $Max = (select max(ObservationAndAnalysisId) from observation_analysis where OrgId =  $OrgId);
ObserLoop: While $Min <= $Max
DO
INSERT INTO `ABCanTrackV2`.`observation_analysis` 
(
    `observation_analysis`.`ObservationAndAnalysisCode`,
    `observation_analysis`.`ObservationAndAnalysisName`,
    `observation_analysis`.`ObservationAndAnalysisDetails`,
    `observation_analysis`.`OrgId`,
    `observation_analysis`.`Order`,
    `observation_analysis`.`LastUpdateDate`,
    `observation_analysis`.`EditingBy`,
    `observation_analysis`.`Hide`
)
SELECT
    `observation_analysis`.`ObservationAndAnalysisCode`,
    `observation_analysis`.`ObservationAndAnalysisName`,
    `observation_analysis`.`ObservationAndAnalysisDetails`,
     NULL,
    `observation_analysis`.`Order`,
    `observation_analysis`.`LastUpdateDate`,
    `observation_analysis`.`EditingBy`,
    `observation_analysis`.`Hide`
FROM `ABCanTrackV2`.`observation_analysis` Where ObservationAndAnalysisId = $Min;
SET $CurId = (SELECT LastId from last_uuid where TableName = 'observation_analysis');
SET $PMin = (SELECT MIN(ObservationAndAnalysisParamId) FROM observation_analysis_param where ObservationAndAnalysisId = $Min and ParentId is null);
SET $PMax = (SELECT MAX(ObservationAndAnalysisParamId) FROM observation_analysis_param where ObservationAndAnalysisId = $Min and ParentId is null);
ParentLoop : While $PMin <= $PMax
do			 
INSERT INTO `ABCanTrackV2`.`observation_analysis_param`
(    
    `observation_analysis_param`.`ObservationAndAnalysisId`,
    `observation_analysis_param`.`ObservationAndAnalysisParamName`,
    `observation_analysis_param`.`ObservationAndAnalysisParamDetails`,
    `observation_analysis_param`.`Order`,
    `observation_analysis_param`.`IsMulti`,
    `observation_analysis_param`.`ParentId`,
    `observation_analysis_param`.`LastUpdateDate`,
    `observation_analysis_param`.`EditingBy`,
    `observation_analysis_param`.`Hide`
)
SELECT 
    $CurId,
    `observation_analysis_param`.`ObservationAndAnalysisParamName`,
    `observation_analysis_param`.`ObservationAndAnalysisParamDetails`,
    `observation_analysis_param`.`Order`,
    `observation_analysis_param`.`IsMulti`,
    `observation_analysis_param`.`ParentId`,
    `observation_analysis_param`.`LastUpdateDate`,
    `observation_analysis_param`.`EditingBy`,
    `observation_analysis_param`.`Hide`
FROM `ABCanTrackV2`.`observation_analysis_param` where ObservationAndAnalysisParamId = $PMin;
SET $PCurId = (SELECT LastId from last_uuid where TableName = 'observation_analysis_param');
INSERT INTO `ABCanTrackV2`.`observation_analysis_param`
(    
    `observation_analysis_param`.`ObservationAndAnalysisId`,
    `observation_analysis_param`.`ObservationAndAnalysisParamName`,
    `observation_analysis_param`.`ObservationAndAnalysisParamDetails`,
    `observation_analysis_param`.`Order`,
    `observation_analysis_param`.`IsMulti`,
    `observation_analysis_param`.`ParentId`,
    `observation_analysis_param`.`LastUpdateDate`,
    `observation_analysis_param`.`EditingBy`,
    `observation_analysis_param`.`Hide`
)
SELECT 
    $CurId,
    `observation_analysis_param`.`ObservationAndAnalysisParamName`,
    `observation_analysis_param`.`ObservationAndAnalysisParamDetails`,
    `observation_analysis_param`.`Order`,
    `observation_analysis_param`.`IsMulti`,
     $PCurId,
    `observation_analysis_param`.`LastUpdateDate`,
    `observation_analysis_param`.`EditingBy`,
    `observation_analysis_param`.`Hide`
FROM `ABCanTrackV2`.`observation_analysis_param` where ParentId = $PMin;
IF $PMin = $PMax
THEN 
LEAVE ParentLoop;
ELSE 
SET $PMin = (SELECT MIN(ObservationAndAnalysisParamId) FROM observation_analysis_param where ObservationAndAnalysisId = $Min and ParentId is null and ObservationAndAnalysisParamId > $PMin );
END IF;
END WHILE;
IF $Min = $Max then
LEAVE ObserLoop;
Else
SET $Min = (select min(ObservationAndAnalysisId) from observation_analysis where OrgId =  $OrgId and ObservationAndAnalysisId > $Min);
END IF;
END While;
-- end observation_analysis and observation_analysis_param Loop --
DELETE FROM `root_cause_param` WHERE RootCauseId IN (SELECT RootCauseId FROM root_cause WHERE OrgId IS NULL) ;
DELETE FROM `root_cause` WHERE OrgId IS NULL;
-- Loop for insert into root_cause and root_cause_param --
SET $Min = (select min(RootCauseId) from root_cause where OrgId =  $OrgId);
SET $Max = (select max(RootCauseId) from root_cause where OrgId =  $OrgId);
RootCauseLoop: While $Min <= $Max
DO
INSERT INTO `ABCanTrackV2`.`root_cause`
(
    `root_cause`.`RootCauseName`,
    `root_cause`.`OrgId`,
    `root_cause`.`Order`,
    `root_cause`.`LastUpdateDate`,
    `root_cause`.`EditingBy`,
    `root_cause`.`Hide`
)
SELECT
    `root_cause`.`RootCauseName`,
     NULL,
    `root_cause`.`Order`,
    `root_cause`.`LastUpdateDate`,
    `root_cause`.`EditingBy`,
    `root_cause`.`Hide`
FROM `ABCanTrackV2`.`root_cause` Where RootCauseId = $Min; 
SET $CurId = (SELECT LastId from last_uuid where TableName = 'root_cause');
 
 INSERT INTO `ABCanTrackV2`.`root_cause_param`
 (
    `root_cause_param`.`RootCauseParamName`,
    `root_cause_param`.`RootCauseId`,
    `root_cause_param`.`RootCauseParamDescription`,
    `root_cause_param`.`Order`,
    `root_cause_param`.`LastUpdateDate`,
    `root_cause_param`.`EditingBy`,
    `root_cause_param`.`Hide`
)
 SELECT
    `root_cause_param`.`RootCauseParamName`,
    $CurId,
    `root_cause_param`.`RootCauseParamDescription`,
    `root_cause_param`.`Order`,
    `root_cause_param`.`LastUpdateDate`,
    `root_cause_param`.`EditingBy`,
    `root_cause_param`.`Hide`
FROM `ABCanTrackV2`.`root_cause_param`  where RootCauseId = $Min;
IF $Min = $Max then
LEAVE RootCauseLoop;
Else
SET $Min = (select min(RootCauseId) from root_cause where OrgId =  $OrgId and RootCauseId > $Min);
END IF;
END While;
-- end root_cause and root_cause_param Loop --
END;
