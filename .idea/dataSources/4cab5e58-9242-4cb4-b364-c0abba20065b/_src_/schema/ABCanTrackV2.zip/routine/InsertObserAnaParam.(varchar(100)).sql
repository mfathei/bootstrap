CREATE PROCEDURE ABCanTrackV2.InsertObserAnaParam(IN `$OrgId` VARCHAR(100))
  BEGIN
DECLARE $OrgMin, $OrgMax, $Min, $Max, $ParentId, $DEnergyFormId, $OEnergyFormId VARCHAR(100);
DECLARE $ParentName VARCHAR(255);
SET $DEnergyFormId = (SELECT ObservationAndAnalysisId FROM ABCanTrackV2.observation_analysis WHERE ObservationAndAnalysisCode = 'EnergyForm' AND OrgId IS NULL);
SET $OrgMin = $OrgId; -- (SELECT MIN(CompanyId) FROM MigrationDB.OrgToBeMigrated);
SET $OrgMax = $OrgId; -- (SELECT MAX(CompanyId) FROM MigrationDB.OrgToBeMigrated);
OrgLoop: WHILE $OrgMin <= $OrgMax
DO
	SET $OEnergyFormId = (SELECT ObservationAndAnalysisId FROM ABCanTrackV2.observation_analysis WHERE ObservationAndAnalysisCode = 'EnergyForm' AND OrgId = $OrgMin);
	INSERT INTO `ABCanTrackV2`.`observation_analysis_param`
	(
		`ObservationAndAnalysisParamId`,
		`ObservationAndAnalysisId`,
		`ObservationAndAnalysisParamName`,
		`ObservationAndAnalysisParamDetails`,
		`Order`,
		`IsMulti`,
		`ParentId`,
		`LastUpdateDate`,
		`EditingBy`,
		`Hide`,
		`OldId`
	)
	SELECT
		MyUUID(),
		$OEnergyFormId,
		`ObservationAndAnalysisParamName`,
		`ObservationAndAnalysisParamDetails`,
		`Order`,
		`IsMulti`,
		`ParentId`,
		`LastUpdateDate`,
		`EditingBy`,
		`Hide`,
		`OldId`
	FROM  `ABCanTrackV2`.`observation_analysis_param`
	WHERE ObservationAndAnalysisId = $DEnergyFormId AND `ParentId` IS NULL;
	
	SET $Min = (SELECT MIN(ObservationAndAnalysisParamId) FROM `ABCanTrackV2`.`observation_analysis_param` WHERE ObservationAndAnalysisId = $OEnergyFormId);	
	SET $Max = (SELECT MAX(ObservationAndAnalysisParamId) FROM `ABCanTrackV2`.`observation_analysis_param` WHERE ObservationAndAnalysisId = $OEnergyFormId);
	ParentLoop: WHILE $Min <= $Max
	DO
		SET $ParentName = (SELECT `ObservationAndAnalysisParamName` FROM `ABCanTrackV2`.`observation_analysis_param` WHERE ObservationAndAnalysisParamId = $Min);
		SET $ParentId = (SELECT ObservationAndAnalysisParamId FROM `ABCanTrackV2`.`observation_analysis_param` WHERE ObservationAndAnalysisId = $DEnergyFormId AND ObservationAndAnalysisParamName = $ParentName);
		INSERT INTO `ABCanTrackV2`.`observation_analysis_param`
		(
			`ObservationAndAnalysisParamId`,
			`ObservationAndAnalysisId`,
			`ObservationAndAnalysisParamName`,
			`ObservationAndAnalysisParamDetails`,
			`Order`,
			`IsMulti`,
			`ParentId`,
			`LastUpdateDate`,
			`EditingBy`,
			`Hide`,
			`OldId`
		)
		SELECT
			MyUUID(),
			$OEnergyFormId,
			`ObservationAndAnalysisParamName`,
			`ObservationAndAnalysisParamDetails`,
			`Order`,
			`IsMulti`,
			$Min,
			`LastUpdateDate`,
			`EditingBy`,
			`Hide`,
			`OldId`
		FROM  `ABCanTrackV2`.`observation_analysis_param`
		WHERE ObservationAndAnalysisId = $DEnergyFormId AND `ParentId` = $ParentId;
		IF $Min = $Max
		THEN
			LEAVE ParentLoop;
		ELSE
			SET $Min = (SELECT MIN(ObservationAndAnalysisParamId) FROM `ABCanTrackV2`.`observation_analysis_param` WHERE ObservationAndAnalysisId = $OEnergyFormId AND ParentId IS NULL AND ObservationAndAnalysisParamId > $Min);
		END IF;
	END WHILE;
	IF $OrgMin = $OrgMax
	THEN
		LEAVE OrgLoop;
	ELSE
		SET $OrgMin = (SELECT MIN(CompanyId) FROM MigrationDB.OrgToBeMigrated WHERE CompanyId > $OrgMin);
	END IF;
END WHILE;
END;
