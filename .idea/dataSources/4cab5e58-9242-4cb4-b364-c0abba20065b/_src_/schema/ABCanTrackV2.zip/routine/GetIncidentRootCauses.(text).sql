CREATE PROCEDURE ABCanTrackV2.GetIncidentRootCauses(IN xmlData TEXT)
  BEGIN 
DECLARE $ids TEXT;
DECLARE $FieldId VARCHAR(100);
SET @OrgId = extractvalue(xmlData, '//OrgId');
SET @page = extractvalue(xmlData, '//page');
SET @limit = extractvalue(xmlData, '//limit');
SET @sortOrder =  extractvalue(xmlData, '//sortOrder');
SET @index =  extractvalue(xmlData, '//index');
SET @Mine =  extractvalue(xmlData, '//Mine');
SET @CreatorId = extractvalue(xmlData, '//CreatorId');
SET @Export =  extractvalue(xmlData, '//Export');
SET @queryhave = ' HAVING 1 = 1    ';
set @selectquery ="
SELECT   
	incident.IncidentId, incident.IncidentNumber, date_format(incident.IncidentDate,'%m/%d/%Y') as IncidentDate,
	RootCauseParamName  as RootCauseParamId, root_cause.RootCauseName,
	incident.IsEmerRP,
	incident.RepName,
	incident.RepEmail,
	incident.RepPosition,
	incident.RepCompany,
	incident.RepPrimaryPhone,
	incident.RepAlternatePhone,
	incident.OtherLocation,
	incident.EventSequence,
	incident.EnvConditionNote,
	incident.IncDescription,
	incident.EnergyFormNote,
	incident.SubStandardActionNote,
	incident.SubStandardConditionNote,
	incident.UnderLyingCauseNote,
	date_format(incident.InvestigationDate,'%m/%d/%Y')as InvestigationDate,
	incident.InvestigatorName1,
	incident.InvestigatorName2,
	incident.InvestigatorName3,
	incident.InvSummary,
	incident.FollowUpNote,
	incident.ResponseCost,
	incident.RepairCost,
	incident.InsuranceCost,
	incident.WCBCost,
	incident.OtherCost,
	incident.TotalCost,
	incident.SourceDetails,
	incident.RootCauseNote,
	incident.SignOffInvestigatorName,
	date_format(incident.SignOffDate,'%m/%d/%Y')as  SignOffDate
 ";
set @queryFrom = " from inc_root_cause
	inner join root_cause_param on root_cause_param.RootCauseParamId = inc_root_cause.RootCauseParamId
	inner join root_cause on root_cause.RootCauseId = root_cause_param.RootCauseId
	inner join incident on incident.IncidentId = inc_root_cause.IncidentId  ";
SET @queryWhere = ' where 1= 1 ';
IF (@OrgId != '' AND @OrgId !='0') THEN
	SET @queryWhere = CONCAT(@queryWhere,' and incident.OrgId =   "', @Orgid,'" ');
END IF;
SET $ids = extractvalue(xmlData, '//FieldNamesIds');
SET @Postition = LOCATE(',', $ids);
WHILE ( @Postition > 0 ) DO
	SET @STR = SUBSTRING($ids, 1, @Postition-1);
	SET $ids  = SUBSTRING($ids, @Postition + 1);
	set  @STR = TRIM(@STR);
    SET $FieldId = (SELECT FieldId FROM ABCanTrackV2.field where FieldName = @STR and Orgid=@OrgId );
       
   if ((SELECT INSTR( @STR , 'calendar') > 0)) THEN 
		SET @selectquery = CONCAT(@selectquery , ', (select group_concat(FieldValue  separator ', ' ) from field_value tbl1
				where tbl1.incidentid = incident.incidentid and tbl1.FieldId ="', $FieldId,'"   limit 1) as `',@STR,'`');	
	elseif ((SELECT INSTR( @STR , 'textbox') > 0)) THEN 
		SET @selectquery = CONCAT(@selectquery , ',    (select  group_concat(FieldValue  separator ', ' )  from field_value tbl1
			where tbl1.incidentid = incident.incidentid and tbl1.FieldId ="', $FieldId,'"   limit 1) as `',@STR,'`');	
            
	elseif ((SELECT INSTR( @STR , 'textarea') > 0)) THEN 
		SET @selectquery = CONCAT(@selectquery , ',    (select  group_concat(FieldValue  separator ', ' )  from field_value tbl1
				where tbl1.incidentid = incident.incidentid and tbl1.FieldId ="', $FieldId,'"   limit 1) as `',@STR,'`');	
	else    
		SET @selectquery = CONCAT(@selectquery , ',   (select group_concat(trim(tbl3.OptionName) separator ', ') from field_value tbl1
		inner join `option` tbl3
		on tbl1.OptionId = tbl3.OptionId
		where tbl1.incidentid = incident.incidentid and tbl1.FieldId ="', $FieldId,'") as `',@STR,'`');	
	
    END IF;  
    
	SET @Col =  extractvalue(xmlData, CONCAT('//',@STR));
	IF (@Col != '' AND @Col !='NULL') THEN	 
	SET @queryhave = CONCAT(@queryhave,'  and  ', @STR ,' like '"'%", @Col ,"%'" );
	END IF; 	
        
	SET @Postition = LOCATE(',', $ids);
END WHILE;
IF (@Mine = 'true') THEN
	SET @queryWhere = CONCAT(@queryWhere,' AND incident.CreatorId =  "',@CreatorId,'" '  );
END IF;
SET @queryWhere = CONCAT(@queryWhere,' AND incident.Hide =  0');
IF( ExtractValue(xmlData, 'count(//EventTypeId)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', event_type.EventTypeName as EventTypeId ');
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join event_type on incident.EventTypeId = event_type.EventTypeId  ');
END IF;
IF( ExtractValue(xmlData, 'count(//OperationTypeId)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', operation_type.OperationTypeName as OperationTypeId ');
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join operation_type on incident.OperationTypeId = operation_type.OperationTypeId  ');
END IF;
IF( ExtractValue(xmlData, 'count(//Location1Id)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', location1.Location1Name as Location1Id ');
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join location1 on incident.Location1Id = location1.Location1Id  ');
END IF;
IF( ExtractValue(xmlData, 'count(//Location2Id)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', location2.Location2Name as Location2Id ');
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join location2 on incident.Location2Id = location2.Location2Id  ');
END IF;
IF( ExtractValue(xmlData, 'count(//Location3Id)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', location3.Location3Name as Location3Id ');
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join location3 on incident.Location3Id = location3.Location3Id  ');
END IF;
IF( ExtractValue(xmlData, 'count(//Location4Id)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', location4.Location4Name as Location4Id ');
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join location4 on incident.Location4Id = location4.Location4Id  ');
END IF;
IF( ExtractValue(xmlData, 'count(//InvStatusId)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', inv_status.InvStatusName as InvStatusId ');
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join inv_status on incident.InvStatusId = inv_status.InvStatusId  ');
END IF;
IF( ExtractValue(xmlData, 'count(//RiskOfRecurrenceId)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', risk_of_recurrence.RiskOfRecurrenceName as RiskOfRecurrenceId ');
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join risk_of_recurrence on incident.RiskOfRecurrenceId = risk_of_recurrence.RiskOfRecurrenceId  ');
END IF;
IF( ExtractValue(xmlData, 'count(//IncidentSeverityId)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', incident_severity.IncidentSeverityName as IncidentSeverityId ');
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join incident_severity on incident.IncidentSeverityId = incident_severity.IncidentSeverityId  ');
END IF;
IF( ExtractValue(xmlData, 'count(//UpdatedByName)') >0 ) THEN
		IF( ExtractValue(xmlData, 'count(//UpdatedByName)') >0)THEN		
			SET @selectquery = CONCAT(@selectquery,', ', ' CONCAT',' (','empModifier.FirstName,',"'","  '" ,',empModifier.LastName',')  as UpdatedByName ');
			SET @queryFrom = CONCAT(@queryFrom,'   left outer join hist_incident on hist_incident.Incidentid = incident.IncidentId  and  hist_incident.HistIncidentId =   hist_incident(incident.IncidentId) 
													inner join employee as empModifier on hist_incident.UpdatedById = empModifier.EmployeeId  ');
		END IF;
END IF;
IF( ExtractValue(xmlData, 'count(//CreatorName)') >0 ) THEN
	SET @selectquery = CONCAT(@selectquery,', ', 'CONCAT',' (','empCreator.FirstName,',"'","  '" ,',empCreator.LastName',') ',' as CreatorName ');
	SET @queryFrom = CONCAT(@queryFrom,'    inner join employee as empCreator on incident.CreatorId = empCreator.EmployeeId  ');
END IF;
-- end select 
SET @IncidentDateFrom =  extractvalue(xmlData, '//IncidentDateFrom');
SET @IncidentDateTo =  extractvalue(xmlData, '//IncidentDateTo');
IF(@IncidentDateTo != '') THEN
	SET @IncidentDateFrom  = STR_TO_DATE(@IncidentDateFrom , '%m/%d/%Y');
	SET @IncidentDateTo  = STR_TO_DATE(@IncidentDateTo , '%m/%d/%Y');
	SET @IncidentDateTo2 = DATE_ADD(@IncidentDateTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident.IncidentDate >  ', "'" , @IncidentDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident.IncidentDate <=  ', "'",  @IncidentDateTo2  ,"'" );										
ELSE 
IF(@IncidentDateTo = '' AND @IncidentDateFrom !='' ) THEN
	SET @IncidentDateFrom  = STR_TO_DATE(@IncidentDateFrom , '%m/%d/%Y');
	SET @IncidentDateFrom2 = DATE_ADD(@IncidentDateFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident.IncidentDate >=  ',  "'", @IncidentDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident.IncidentDate <  ', "'", @IncidentDateFrom2  ,"'");	
END IF;
END IF;
SET @InvestigationDateFrom =  extractvalue(xmlData, '//InvestigationDateFrom');
SET @InvestigationDateTo =  extractvalue(xmlData, '//InvestigationDateTo');
IF(@InvestigationDateTo != '') THEN
	SET @InvestigationDateFrom  = STR_TO_DATE(@InvestigationDateFrom , '%m/%d/%Y');
	SET @InvestigationDateTo  = STR_TO_DATE(@InvestigationDateTo , '%m/%d/%Y');
	SET @InvestigationDateTo2 = DATE_ADD(@InvestigationDateTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident.InvestigationDate >  ', "'" , @InvestigationDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident.InvestigationDate <=  ', "'",  @InvestigationDateTo2  ,"'" );										
ELSE 
IF(@InvestigationDateTo = '' AND @InvestigationDateFrom !='' ) THEN
	SET @InvestigationDateFrom  = STR_TO_DATE(@InvestigationDateFrom , '%m/%d/%Y');
	SET @InvestigationDateFrom2 = DATE_ADD(@InvestigationDateFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident.InvestigationDate >=  ',  "'", @InvestigationDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident.InvestigationDate <  ', "'", @InvestigationDateFrom2  ,"'");	
END IF;
END IF;
SET @SignOffDateFrom =  extractvalue(xmlData, '//SignOffDateFrom');
SET @SignOffDateTo =  extractvalue(xmlData, '//SignOffDateTo');
IF(@SignOffDateTo != '') THEN
	SET @SignOffDateFrom  = STR_TO_DATE(@SignOffDateFrom , '%m/%d/%Y');
	SET @SignOffDateTo  = STR_TO_DATE(@SignOffDateTo , '%m/%d/%Y');
	SET @SignOffDateTo2 = DATE_ADD(@SignOffDateTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident.SignOffDate >  ', "'" , @SignOffDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident.SignOffDate <=  ', "'",  @SignOffDateTo2  ,"'" );										
ELSE 
IF(@SignOffDateTo = '' AND @SignOffDateFrom !='' ) THEN
	SET @SignOffDateFrom  = STR_TO_DATE(@SignOffDateFrom , '%m/%d/%Y');
	SET @SignOffDateFrom2 = DATE_ADD(@SignOffDateFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident.SignOffDate >=  ',  "'", @SignOffDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident.SignOffDate <  ', "'", @SignOffDateFrom2  ,"'");	
END IF;
END IF;
SET @WCBCostTo =  extractvalue(xmlData, '//WCBCostTo');
SET @WCBCostFrom =  extractvalue(xmlData, '//WCBCostFrom');
IF( @WCBCostTo !='' ) THEN
	SET @queryWhere = CONCAT(@queryWhere,' AND  incident.WCBCost  BETWEEN ', @WCBCostFrom, ' and ', @WCBCostTo);
ELSE 
	IF( @WCBCostFrom !=''  and @WCBCostFrom != 'NULL')	 THEN
set  @WCBCostFrom  = (replace(@WCBCostFrom, '&lt;', '<'));
set  @WCBCostFrom  = (replace(@WCBCostFrom, '&gt;', '>'));
		SET @queryWhere = CONCAT(@queryWhere,' AND  incident.WCBCost  ', @WCBCostFrom);
	END IF;
END IF;
SET @RepairCostTo =  extractvalue(xmlData, '//RepairCostTo');
SET @RepairCostFrom =  extractvalue(xmlData, '//RepairCostFrom');
IF( @RepairCostTo !='' ) THEN
	SET @queryWhere = CONCAT(@queryWhere,' AND  incident.RepairCost  BETWEEN ', @RepairCostFrom, ' and ', @RepairCostTo);
ELSE 
	IF( @RepairCostFrom !=''  and @RepairCostFrom != 'NULL')	 THEN
set  @RepairCostFrom  = (replace(@RepairCostFrom, '&lt;', '<'));
set  @RepairCostFrom  = (replace(@RepairCostFrom, '&gt;', '>'));
		SET @queryWhere = CONCAT(@queryWhere,' AND  incident.RepairCost  ', @RepairCostFrom);
	END IF;
END IF;
SET @OtherCostTo =  extractvalue(xmlData, '//OtherCostTo');
SET @OtherCostFrom =  extractvalue(xmlData, '//OtherCostFrom');
IF( @OtherCostTo !='' ) THEN
	SET @queryWhere = CONCAT(@queryWhere,' AND  incident.OtherCost  BETWEEN ', @OtherCostFrom, ' and ', @OtherCostTo);
ELSE 
	IF( @OtherCostFrom !=''  and @OtherCostFrom != 'NULL')	 THEN
set  @OtherCostFrom  = (replace(@OtherCostFrom, '&lt;', '<'));
set  @OtherCostFrom  = (replace(@OtherCostFrom, '&gt;', '>'));
		SET @queryWhere = CONCAT(@queryWhere,' AND  incident.OtherCost  ', @OtherCostFrom);
	END IF;
END IF;
SET @OtherCostTo =  extractvalue(xmlData, '//OtherCostTo');
SET @OtherCostFrom =  extractvalue(xmlData, '//OtherCostFrom');
IF( @OtherCostTo !='' ) THEN
	SET @queryWhere = CONCAT(@queryWhere,' AND  incident.OtherCost  BETWEEN ', @OtherCostFrom, ' and ', @OtherCostTo);
ELSE 
	IF( @OtherCostFrom !=''  and @OtherCostFrom != 'NULL')	 THEN
set  @OtherCostFrom  = (replace(@OtherCostFrom, '&lt;', '<'));
set  @OtherCostFrom  = (replace(@OtherCostFrom, '&gt;', '>'));
		SET @queryWhere = CONCAT(@queryWhere,' AND  incident.OtherCost  ', @OtherCostFrom);
	END IF;
END IF;
SET @ResponseCostTo =  extractvalue(xmlData, '//ResponseCostTo');
SET @ResponseCostFrom =  extractvalue(xmlData, '//ResponseCostFrom');
IF( @ResponseCostTo !='' ) THEN
	SET @queryWhere = CONCAT(@queryWhere,' AND  incident.ResponseCost  BETWEEN ', @ResponseCostFrom, ' and ', @ResponseCostTo);
ELSE 
	IF( @ResponseCostFrom !=''  and @ResponseCostFrom != 'NULL')	 THEN
set  @ResponseCostFrom  = (replace(@ResponseCostFrom, '&lt;', '<'));
set  @ResponseCostFrom  = (replace(@ResponseCostFrom, '&gt;', '>'));
		SET @queryWhere = CONCAT(@queryWhere,' AND  incident.ResponseCost  ', @ResponseCostFrom);
	END IF;
END IF;
SET @TotalCostTo =  extractvalue(xmlData, '//TotalCostTo');
SET @TotalCostFrom =  extractvalue(xmlData, '//TotalCostFrom');
IF( @TotalCostTo !='' ) THEN
	SET @queryWhere = CONCAT(@queryWhere,' AND  incident.TotalCost  BETWEEN ', @TotalCostFrom, ' and ', @TotalCostTo);
ELSE 
	IF( @TotalCostFrom !=''  and @TotalCostFrom != 'NULL')	 THEN
set  @TotalCostFrom  = (replace(@TotalCostFrom, '&lt;', '<'));
set  @TotalCostFrom  = (replace(@TotalCostFrom, '&gt;', '>'));
		SET @queryWhere = CONCAT(@queryWhere,' AND  incident.TotalCost  ', @TotalCostFrom);
	END IF;
END IF;
/* search part*/
 SET@myArrayOfValue='RootCauseName,IncidentNumber,EventTypeId,RootCauseParamId,IsEmerRP,RepName,RepEmail,RepPosition,RepCompany,RepPrimaryPhone,RepAlternatePhone,Location1Id,Location2Id,Location3Id,Location4Id,OtherLocation,OperationTypeId,OEDepartmentId,';
SET @Postition = LOCATE(',', @myArrayOfValue);
WHILE ( @Postition > 0 ) DO
 SET @STR = SUBSTRING(@myArrayOfValue, 1, @Postition-1);
 SET @myArrayOfValue = SUBSTRING(@myArrayOfValue, @Postition + 1);
 SET @Col =  extractvalue(xmlData, CONCAT('//',@STR));
 IF (@Col != '' AND @Col !='NULL') THEN
		IF (@STR  = 'EventTypeId') then set@STR='event_type.EventTypeName';  END IF;
		IF(@STR = 'RootCauseParamId' )then set @STR = 'RootCauseParamName'; END IF;
	    IF (@STR  = 'CreatorName' ) then set @STR= 'concat (empCreator.FirstName," ",empCreator.LastName) '; END IF;
		IF (@STR  = 'IncidentId' ) then set @STR= 'incident.IncidentId';  END IF;
		IF (@STR  = 'Location1Id' ) then set @STR= 'location1.Location1Name'; END IF;
		IF (@STR  = 'Location2Id' ) then set @STR= 'location2.Location2Name';  END IF;
		IF (@STR  = 'Location3Id' ) then set @STR= 'location3.Location3Name'; END IF;
		IF (@STR  = 'Location4Id' ) then set @STR= 'location4.Location4Name';  END IF;
		IF (@STR  = 'OperationTypeId' ) then set @STR= 'operation_type.OperationTypeName';  END IF;
		IF (@STR  = 'RiskOfRecurrenceId' ) then set @STR= 'risk_of_recurrence.RiskOfRecurrenceName';  END IF;
		IF (@STR  = 'IncidentSeverityId' ) then set @STR= 'incident_severity.IncidentSeverityName';  END IF;
		IF (@STR  = 'InvStatusId') then set@STR='inv_status.InvStatusName';  END IF;
		
	SET @queryWhere = CONCAT(@queryWhere,CONCAT(' AND ',@STR,' like '"'%", @Col ,"%'" )); 
	END IF;
 SET @Postition = LOCATE(',', @myArrayOfValue);
END WHILE;
 
 -- select @queryWhere;
SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere, @queryhave );
-- select @query;
SET @querycount =  CONCAT( 'SELECT count(*) into @cnt from  (', @query, ' ) t');
PREPARE stmt1 FROM @querycount;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
SET @selectquery = CONCAT (@selectquery,', ', @cnt, ' as Count ');
SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere, @queryhave );
IF (@index  = 'incident.Location1Id' 		or @index  = 'Location1Id') 		then set @index= 'location1.Location1Name'; end if; 
IF (@index  = 'incident.Location2Id' 		or @index  = 'Location2Id') 		then set @index= 'location2.Location2Name'; end if;  
IF (@index  = 'incident.Location3Id' 		or @index  = 'Location3Id')		 	then set @index= 'location3.Location3Name'; end if; 
IF (@index  = 'incident.Location4Id' 		or @index  = 'Location4Id') 		then set @index= 'location4.Location4Name'; end if; 
IF (@index  = 'incident.OperationTypeId' 	or @index  = 'OperationTypeId') 	then set @index= 'operation_type.OperationTypeName'; end if;  
IF (@index  = 'incident.RiskOfRecurrenceId' or @index  = 'RiskOfRecurrenceId') 	then set @index= 'risk_of_recurrence.RiskOfRecurrenceName'; end if;  
IF (@index  = 'incident.IncidentSeverityId' or @index  = 'IncidentSeverityId') 	then set @index= 'incident_severity.IncidentSeverityName'; end if;  
IF (@index  = 'incident.InvStatusId' 		or @index  = 'InvStatusId') 		then set@index='inv_status.InvStatusName'; end if;
SET @query = CONCAT(@query, ' order by ', @index,'  ', @sortOrder);
if( @Export ="false") then
SET @page = (@page - 1) * @limit;
SET @query = CONCAT(@query, ' LIMIT ', @limit ,' OFFSET ',  @page);
end if;
PREPARE stmt1 FROM @query;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
-- select @query;
END;
