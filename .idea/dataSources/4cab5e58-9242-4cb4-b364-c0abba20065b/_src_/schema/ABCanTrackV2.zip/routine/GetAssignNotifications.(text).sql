CREATE PROCEDURE ABCanTrackV2.GetAssignNotifications(IN xmlData TEXT)
  BEGIN
SET @Orgid = extractvalue(xmlData, '//OrgId');
SET @page = extractvalue(xmlData, '//page');
SET @limit = extractvalue(xmlData, '//limit');
SET @sortOrder =  extractvalue(xmlData, '//sortOrder');
SET @index =  extractvalue(xmlData, '//index');
SET @Export =  extractvalue(xmlData, '//Export');
set @selectquery1 ='
SELECT  
SQL_CALC_FOUND_ROWS
EmailToId, 
GroupId, 
EmployeeId, 
EmployeeName, 
-- GROUP_CONCAT(DISTINCT LastSentDate SEPARATOR ', ') AS LastSentDate,
Position, 
GroupName, 
EmailTypeName AS EmailTypeName, 
GROUP_CONCAT(DISTINCT AssignedNotifications SEPARATOR ', ') AS AssignedNotifications, 
GROUP_CONCAT(DISTINCT DaysStart SEPARATOR ', ') AS DaysStart, 
GROUP_CONCAT(DISTINCT DaysFreq SEPARATOR ', ') AS DaysFreq,  
GROUP_CONCAT(DISTINCT DaysStartInc SEPARATOR ', ') AS DaysStartInc, 
GROUP_CONCAT(DISTINCT DaysFreqInc SEPARATOR ', ') AS DaysFreqInc,
LastSentDate
FROM
(      
SELECT 
        `eto`.`EmailToId` AS `EmailToId`,
        `eto`.`GroupId` AS `GroupId`,
        `eto`.`EmployeeId` AS `EmployeeId`, 
        CONCAT(`e`.`FirstName`,  '  ' , `e`.`LAStName`) AS `EmployeeName`,
        -- Null as LastSentDate,
        `e`.`PositiON` AS `PositiON`,
        `g`.`GroupName` AS `GroupName`,
        group_CONCAT(distinct `et`.`EmailTypeName`
            separator ', ') AS `EmailTypeName`,
        `eto`.`OrgId` AS `OrgId`,
        GETASSIGNNOTIFICATIONSFUN(`eto`.`EmployeeId`,
                `eto`.`GroupId`,
                `eto`.`OrgId`) AS `ASsignedNotificatiONs`,
        NULL AS `DaysStart`,
        NULL AS `DaysFreq`,
        NULL AS `DaysStartInc`,
        NULL AS `DaysFreqInc`,
`last_sent_date_fun`(`eto`.`EmployeeId`, `eto`.`GroupId`) AS LastSentDate ';
                
set @selectquery2 ='
  UNION ALL SELECT
        `etoesc`.`EmailToEscId` AS `EmailToId`,
        `etoesc`.`GroupId` AS `GroupId`,
        `etoesc`.`EmployeeId` AS `EmployeeId`,
        CONCAT(`e`.`FirstName`, '  ' , `e`.`LAStName`) AS `EmployeeName`,
         -- `etoesc`.`LastSentDate` as `LastSentDate`,
        `e`.`PositiON` AS `PositiON`,
        `g`.`GroupName` AS `GroupName`,
        NULL AS `EmailTypeName`,
        `etoesc`.`OrgId` AS `OrgId`,
        EscEmailOnly(`etoesc`.`EmployeeId`,
                `etoesc`.`GroupId`,
                `etoesc`.`OrgId`) AS `ASsignedNotificatiONs`,
        email_to_fun(`etoesc`.`OrgId`,
                `etoesc`.`GroupId`,
                `etoesc`.`EmployeeId`,
                1,
                'corrective_action') AS `DaysStart`,
        email_to_fun(`etoesc`.`OrgId`,
                `etoesc`.`GroupId`,
                `etoesc`.`EmployeeId`,
                2,
                'corrective_action') AS `DaysFreq`,
        email_to_fun(`etoesc`.`OrgId`,
                `etoesc`.`GroupId`,
                `etoesc`.`EmployeeId`,
                1,
                'incident') AS `DaysStartInc`,
        email_to_fun(`etoesc`.`OrgId`,
                `etoesc`.`GroupId`,
                `etoesc`.`EmployeeId`,
                2,
                'incident') AS `DaysFreqInc`,
		`last_sent_date_fun`(`etoesc`.`EmployeeId`, `etoesc`.`GroupId`) AS LastSentDate ';
-- SELECT @selectquery1, @selectquery2;
set @queryFrom1 = CONCAT('    from
        ((((`email_to` `eto`
        left join `email_to_esc` `etoesc` ON (((`eto`.`OrgId` = `etoesc`.`OrgId`)
            and (`eto`.`EmployeeId` = `etoesc`.`EmployeeId`)
            and (`eto`.`GroupId` = `etoesc`.`GroupId`))))
        left join `employee` `e` ON ((`eto`.`EmployeeId` = `e`.`EmployeeId`)))
        join `email_type` `et` ON ((`et`.`EmailTypeId` = `eto`.`EmailTypeId`)))
        left join `group` `g` ON ((`g`.`GroupId` = `eto`.`GroupId`)))
where eto.orgid = "', @Orgid,'"
GROUP BY `eto`.`EmployeeId` , `eto`.`GroupId`
');
-- select  @queryFrom1;
set @queryFrom2 = CONCAT('
 from
        (((`email_to_esc` `etoesc`
        left join `email_to` `eto` ON (((`eto`.`OrgId` = `etoesc`.`OrgId`)
            and (`eto`.`EmployeeId` = `etoesc`.`EmployeeId`)
            and (`eto`.`GroupId` = `etoesc`.`GroupId`))))
        left join `employee` `e` ON ((`etoesc`.`EmployeeId` = `e`.`EmployeeId`)))
        left join `group` `g` ON ((`g`.`GroupId` = `etoesc`.`GroupId`)))
where etoesc.orgid = "', @Orgid,'" 
');
SET @queryWhere = ' where 1= 1 ';
-- SET @queryWhere = CONCAT(@queryWhere,' and email_to_view.OrgId =   "', @Orgid,'" ');
SET @queryFrom1 =  CONCAT(@queryFrom1,' having  1 = 1 ' );
SET @queryFrom2 = CONCAT(@queryFrom2,' having  1 = 1 ' );
SET @myArrayOfValue = 'EmailToId,EmployeeName,Position,GroupName,EmailTypeName,AssignedNotifications,LastNotificationSent,DaysStart,DaysFreq,DaysStartInc,DaysFreqInc,';
SET @Postition = LOCATE(',', @myArrayOfValue);
WHILE ( @Postition > 0 ) DO
 SET @STR = SUBSTRING(@myArrayOfValue, 1, @Postition-1);
 SET @myArrayOfValue = SUBSTRING(@myArrayOfValue, @Postition + 1);
 SET @Col =  extractvalue(xmlData, CONCAT('//',@STR));
 IF (@Col != '' AND @Col !='NULL') THEN
  -- SET @queryWhere = CONCAT(@queryWhere,CONCAT(' AND    ',@STR,' like '"'%", @Col ,"%'")); 
    SET @queryFrom2 = CONCAT(@queryFrom2,CONCAT(' AND    ',@STR,' like '"'%", @Col ,"%'")); 
      SET @queryFrom1 = CONCAT(@queryFrom1,CONCAT(' AND    ',@STR,' like '"'%", @Col ,"%'")); 
      
 END IF;
 
 SET @Postition = LOCATE(',', @myArrayOfValue);
END WHILE;
SET @LastSentDateFrom =  extractvalue(xmlData, '//LastSentDateFrom');
SET @LastSentDateTo =  extractvalue(xmlData, '//LastSentDateTo');
IF(@LastSentDateTo ="" AND @LastSentDateFrom !="" ) THEN
	SET @LastSentDateFrom  = STR_TO_DATE(@LastSentDateFrom , '%m/%d/%Y');
	SET @LastSentDateFrom2 = DATE_ADD(@LastSentDateFrom ,INTERVAL 1 DAY) ;
    
    SET @queryFrom2 = CONCAT(@queryFrom2,'  AND LastSentDate >=  ',  "'", @LastSentDateFrom ,"'" );	
	SET @queryFrom2 = CONCAT(@queryFrom2,'  AND LastSentDate <  ', "'", @LastSentDateFrom2  ,"'");
	SET @queryFrom1 = CONCAT(@queryFrom1,'  AND LastSentDate >=  ',  "'", @LastSentDateFrom ,"'" );	
	SET @queryFrom1 = CONCAT(@queryFrom1,'  AND LastSentDate <  ', "'", @LastSentDateFrom2  ,"'");
ELSE IF(@LastSentDateTo !="") then
		SET @LastSentDateFrom  = STR_TO_DATE(@LastSentDateFrom , '%m/%d/%Y');
		SET @LastSentDateTo  = STR_TO_DATE(@LastSentDateTo , '%m/%d/%Y');
		SET @LastSentDateTo2 = DATE_ADD(@LastSentDateTo ,INTERVAL 1 DAY) ;
        
        SET @queryFrom1 = CONCAT(@queryFrom1,'  AND LastSentDate >  ', "'" , @LastSentDateFrom ,"'" );	
		SET @queryFrom1 = CONCAT(@queryFrom1,'  AND LastSentDate <=  ', "'",  @LastSentDateTo2  ,"'" );	
        
		SET @queryFrom2 = CONCAT(@queryFrom2,'  AND LastSentDate >  ', "'" , @LastSentDateFrom ,"'" );	
		SET @queryFrom2 = CONCAT(@queryFrom2,'  AND LastSentDate <=  ', "'",  @LastSentDateTo2  ,"'" );	
	
	END IF;
END IF;
SET @GrpOrdrQry = '
) tbl1
GROUP BY `EmployeeId` , `GroupId`  ';
set  @selectquery=CONCAT(@selectquery1, @queryFrom1, @selectquery2, @queryFrom2, @GrpOrdrQry);
SET @query = CONCAT( @selectquery);
if( @index = 'Order') then set  @index = '`Order`';  end if;
SET @query = CONCAT(@query, ' order by ', @index,'  ', @sortOrder);
if( @Export ="false") then
SET @page = (@page - 1) * @limit;
SET @query = CONCAT(@query, ' LIMIT ', @limit ,' OFFSET ',  @page);
end if;
SET @query = CONCAT(@query ,  ' ;');
-- select  @query;
PREPARE stmt1 FROM @query;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
SELECT FOUND_ROWS();
select  @query;
END;
