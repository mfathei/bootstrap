CREATE PROCEDURE ABCanTrackV2.UpdateObserAnaParam(IN `$OrgId` VARCHAR(100))
  BEGIN
DECLARE $OrgMin, $OrgMax, $Min, $Max, $ParentId, $DEnergyFormId, $OEnergyFormId VARCHAR(100);
DECLARE $ParentName VARCHAR(255);
SET $DEnergyFormId = (SELECT ObservationAndAnalysisId FROM ABCanTrackV2.observation_analysis WHERE ObservationAndAnalysisCode = 'EnergyForm' AND OrgId IS NULL);
SET $OrgMin = $OrgId; -- (SELECT MIN(CompanyId) FROM MigrationDB.OrgToBeMigrated);
SET $OrgMax = $OrgId; -- (SELECT MAX(CompanyId) FROM MigrationDB.OrgToBeMigrated);
OrgLoop: WHILE $OrgMin <= $OrgMax
DO
	SET $OEnergyFormId = (SELECT ObservationAndAnalysisId FROM ABCanTrackV2.observation_analysis WHERE ObservationAndAnalysisCode = 'EnergyForm' AND OrgId = $OrgMin);
	/*INSERT INTO `ABCanTrackV2`.`observation_analysis_param`
	(
		`ObservationAndAnalysisParamId`,
		`ObservationAndAnalysisId`,
		`ObservationAndAnalysisParamName`,
		`ObservationAndAnalysisParamDetails`,
		`Order`,
		`IsMulti`,
		`ParentId`,
		`LastUpdateDate`,
		`EditingBy`,
		`Hide`,
		`OldId`
	)
	SELECT
		MyUUID(),
		$OEnergyFormId,
		`ObservationAndAnalysisParamName`,
		`ObservationAndAnalysisParamDetails`,
		`Order`,
		`IsMulti`,
		`ParentId`,
		`LastUpdateDate`,
		`EditingBy`,
		`Hide`,
		`OldId`
	FROM  `ABCanTrackV2`.`observation_analysis_param`
	WHERE ObservationAndAnalysisId = $DEnergyFormId AND `ParentId` IS NULL;*/
	
	SET $Min = (SELECT MIN(ObservationAndAnalysisParamId) FROM `ABCanTrackV2`.`observation_analysis_param` WHERE ObservationAndAnalysisId = $DEnergyFormId AND ParentId IS NULL);	
	SET $Max = (SELECT MAX(ObservationAndAnalysisParamId) FROM `ABCanTrackV2`.`observation_analysis_param` WHERE ObservationAndAnalysisId = $DEnergyFormId AND ParentId IS NULL);
	ParentLoop: WHILE $Min <= $Max
	DO
		SET $ParentName = (SELECT `ObservationAndAnalysisParamName` FROM `ABCanTrackV2`.`observation_analysis_param` WHERE ObservationAndAnalysisParamId = $Min);
		SET $ParentId = (SELECT ObservationAndAnalysisParamId FROM `ABCanTrackV2`.`observation_analysis_param` WHERE ObservationAndAnalysisId = $OEnergyFormId AND ObservationAndAnalysisParamName = $ParentName);
        SELECT $Min, $Max, $parentName, $ParentId, $DEnergyFormId, $OEnergyFormId;
        
        
        
		UPDATE `ABCanTrackV2`.`observation_analysis_param` tbl1 INNER JOIN `ABCanTrackV2`.`observation_analysis_param` tbl2
				ON tbl1.`ObservationAndAnalysisParamName` = tbl2.`ObservationAndAnalysisParamName` AND tbl2.ParentId = $Min
				SET
			tbl1.`Order` = tbl2.`Order`, 
			tbl1.`IsMulti` = tbl2.`IsMulti`,
			tbl1.ParentId = $ParentId 
		WHERE tbl1.ObservationAndAnalysisId = $OEnergyFormId
		AND tbl2.ObservationAndAnalysisId = $DEnergyFormId;
		
		/*
		INSERT INTO `ABCanTrackV2`.`observation_analysis_param`
		(
			`ObservationAndAnalysisParamId`,
			`ObservationAndAnalysisId`,
			`ObservationAndAnalysisParamName`,
			`ObservationAndAnalysisParamDetails`,
			`Order`,
			`IsMulti`,
			`ParentId`,
			`LastUpdateDate`,
			`EditingBy`,
			`Hide`,
			`OldId`
		)
		SELECT
			MyUUID(),
			$OEnergyFormId,
			`ObservationAndAnalysisParamName`,
			`ObservationAndAnalysisParamDetails`,
			`Order`,
			`IsMulti`,
			$Min,
			`LastUpdateDate`,
			`EditingBy`,
			`Hide`,
			`OldId`
		FROM  `ABCanTrackV2`.`observation_analysis_param`
		WHERE ObservationAndAnalysisId = $DEnergyFormId AND `ParentId` = $ParentId;*/
		IF $Min = $Max
		THEN
			LEAVE ParentLoop;
		ELSE
			SET $Min = (SELECT MIN(ObservationAndAnalysisParamId) FROM `ABCanTrackV2`.`observation_analysis_param` WHERE ObservationAndAnalysisId = $DEnergyFormId AND ParentId IS NULL AND ObservationAndAnalysisParamId > $Min);
		END IF;
	END WHILE;
	IF $OrgMin = $OrgMax
	THEN
		LEAVE OrgLoop;
	ELSE
		SET $OrgMin = (SELECT MIN(CompanyId) FROM MigrationDB.OrgToBeMigrated WHERE CompanyId > $OrgMin);
	END IF;
END WHILE;
END;
