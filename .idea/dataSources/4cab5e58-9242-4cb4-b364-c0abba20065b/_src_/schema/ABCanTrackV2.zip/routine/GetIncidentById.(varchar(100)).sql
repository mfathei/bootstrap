CREATE PROCEDURE ABCanTrackV2.GetIncidentById(IN `$IncidentId` VARCHAR(100))
  BEGIN
Declare $histincidentid, $maxhistincidentid varchar(100);
DECLARE $VersionNumber INT;
SET $VersionNumber = (SELECT MAX(VersionNumber) FROM hist_incident WHERE incidentid = $IncidentId);
set $maxhistincidentid =  (select  HistIncidentId from hist_incident where incidentid = $IncidentId AND VersionNumber = $VersionNumber);
SELECT 
IncidentNumber, hi.VersionNumber,
hi.EnvConditionNote,
hi.HistIncidentId,
i.IncidentId,
    hi.EventTypeName,
    i.OrgId,
	i.EventTypeId,
    CreatorId,
	ReporterId,
    concat(empCreator.FirstName, " " , empCreator.LastName) as CreatorName,
    DATE_FORMAT(hi.IncidentDate, '%m/%d/%Y')  as  IncidentDate,
    hi.IncidentHour,
    hi.IncidentMinute,
    CASE hi.IsEmerRP
        WHEN '0' THEN  REPLACEYESNO(i.`OrgId`, 'no')
        WHEN '1' THEN  REPLACEYESNO(i.`OrgId`, 'yes')
    END AS IsEmerRP,
    hi.RepName,
    hi.RepEmail,
    hi.RepPosition,
    hi.RepCompany,
    hi.RepPrimaryPhone,
    hi.RepAlternatePhone,
    hi.Location1Name,
    hi.Location2Name,
    hi.Location3Name,
    hi.Location4Name,
    hi.OtherLocation,
	i.Location1Id,
    i.Location2Id,
    i.Location3Id,
    i.Location4Id,
    hi.OperationTypeName,    i.OperationTypeId,
    (select group_concat(ObservationAndAnalysisParamName separator ' ; ') from observation_analysis_param  inner join observation_analysis on observation_analysis.ObservationAndAnalysisId = observation_analysis_param.ObservationAndAnalysisId where ObservationAndAnalysisCode ='EnergyForm' and  ObservationAndAnalysisParamId in (select ObservationAndAnalysisParamId  from inc_obser_ana where incidentid = $incidentid)) as EnergyForm,
	(select group_concat(ObservationAndAnalysisParamName separator ' ; ') from observation_analysis_param  inner join observation_analysis on observation_analysis.ObservationAndAnalysisId = observation_analysis_param.ObservationAndAnalysisId where ObservationAndAnalysisCode ='SubActions' and  ObservationAndAnalysisParamId in (select ObservationAndAnalysisParamId  from inc_obser_ana where incidentid = $incidentid)) as SubActions,
	(select group_concat(ObservationAndAnalysisParamName separator ' ; ') from observation_analysis_param  inner join observation_analysis on observation_analysis.ObservationAndAnalysisId = observation_analysis_param.ObservationAndAnalysisId where ObservationAndAnalysisCode ='SubConditions' and  ObservationAndAnalysisParamId in (select ObservationAndAnalysisParamId  from inc_obser_ana where incidentid = $incidentid)) as SubConditions,
	(select group_concat(ObservationAndAnalysisParamName separator ' ; ') from observation_analysis_param  inner join observation_analysis on observation_analysis.ObservationAndAnalysisId = observation_analysis_param.ObservationAndAnalysisId where ObservationAndAnalysisCode ='UnderLyingCauses' and  ObservationAndAnalysisParamId in (select ObservationAndAnalysisParamId  from inc_obser_ana where incidentid = $incidentid)) as UnderLyingCauses,    
    hi.OEDepartmentName,
    hi.EventSequence,	
    hi.EnvConditionName as EnvConditions,
    hi.IncDescription,
	hi.IncInvSourceName as InvSourceName,
    hi.EnergyFormNote,
    hi.SubStandardActionNote,
    hi.SubStandardConditionNote,
    hi.UnderLyingCauseNote,	
    hi.InvStatusName,i.InvStatusId,
     DATE_FORMAT(hi.InvestigationDate, '%m/%d/%Y')  as InvestigationDate,
    hi.InvestigatorName1,i.InvestigatorId1,
    hi.InvestigatorName2,   i.InvestigatorId2,
    hi.InvestigatorName3, i.InvestigatorId3,
	hi.RootCauseName as  RootCauseName,
	hi. OtherRootCause,
	(select group_concat(ThirdPartyName separator ' ; ') from third_party left outer join third_party_type on third_party_type.ThirdPartyTypeId = third_party.ThirdPartyTypeId where ThirdPartyTypeName  = 'Customer' and ThirdPartyId in (select ThirdPartyId from inc_third_party where incidentid = $incidentid)) as CustomerName,
	(select group_concat(inc_third_party.ContactName separator ' ; ') from inc_third_party left outer join third_party on inc_third_party.ThirdPartyId = third_party.ThirdPartyId left outer join third_party_type on third_party_type.ThirdPartyTypeId = third_party.ThirdPartyTypeId  where ThirdPartyTypeName  = 'Customer'  and incidentid = $incidentid)  as CustName,
	(select group_concat(JobNumber separator ' ; ') from inc_third_party left outer join third_party on inc_third_party.ThirdPartyId = third_party.ThirdPartyId left outer join third_party_type on third_party_type.ThirdPartyTypeId = third_party.ThirdPartyTypeId  where ThirdPartyTypeName  = 'Customer'  and incidentid = $incidentid) as CustomerJobNumber,
	(select group_concat(ThirdPartyName separator ' ; ') from third_party left outer join third_party_type on third_party_type.ThirdPartyTypeId = third_party.ThirdPartyTypeId where ThirdPartyTypeName  = 'Contractor' and ThirdPartyId in (select ThirdPartyId from inc_third_party where incidentid = $incidentid)) as ContractorName, 
	(select group_concat(JobNumber separator ' ; ') from inc_third_party left outer join third_party on inc_third_party.ThirdPartyId = third_party.ThirdPartyId left outer join third_party_type on third_party_type.ThirdPartyTypeId = third_party.ThirdPartyTypeId  where ThirdPartyTypeName  = 'Contractor'  and incidentid = $incidentid) as ContractorJobNumber,
	(select group_concat(inc_third_party.ContactName separator ' ; ') from inc_third_party left outer join third_party on inc_third_party.ThirdPartyId = third_party.ThirdPartyId left outer join third_party_type on third_party_type.ThirdPartyTypeId = third_party.ThirdPartyTypeId  where ThirdPartyTypeName  = 'Contractor'  and incidentid = $incidentid)  as ContName,
	hi.InvSummary,   
    hi.ResponseCost,
    hi.RepairCost,
    hi.InsuranceCost,
    hi.WCBCost,
    hi.OtherCost,
    hi.TotalCost,i.FollowUpNote,
    hi.RiskOfRecurrenceName,
    hi.IncidentSeverityName,
	i.RiskOfRecurrenceId,
    i.IncidentSeverityId,
    hi.SourceDetails,
    hi.RootCauseNote,	
    hi.SignOffInvestigatorName,
	SignOffInvestigatorId,
	i.ModifierId,
	DATE_FORMAT(i.SignOffDate, '%m/%d/%Y')  as  SignOffDate
from
    incident  i
 join hist_incident hi on hi.Incidentid = i.IncidentId 
 join employee as empCreator on empCreator.EmployeeId = i.CreatorId
 left outer join employee as empModifier on empModifier.EmployeeId = i.ModifierId
where hi.HistIncidentId=  $maxhistincidentid;
END;
