CREATE FUNCTION ABCanTrackV2.remove_duplicated_mails(x TEXT, delim VARCHAR(12))
  RETURNS TEXT
  BEGIN
	declare tmp text;
	declare str text;
	declare indx INTEGER;
    
    SET indx = 1;
    SET str = REPLACE(SUBSTRING(SUBSTRING_INDEX(x, delim, indx),LENGTH(SUBSTRING_INDEX(x, delim, indx -1)) + 1),delim, '');
    SET tmp = CONCAT(" ",str);
    
    WHILE str != '' DO
		if instr(tmp,str) = 0 THEN
			SET tmp = CONCAT(tmp,delim);
			SET tmp = CONCAT(tmp,str);
		end if;
		SET indx = indx + 1;
		SET str = REPLACE(SUBSTRING(SUBSTRING_INDEX(x, delim, indx),LENGTH(SUBSTRING_INDEX(x, delim, indx -1)) + 1),delim, '');
    end WHILE;
    
    RETURN TRIM(tmp);

END;
