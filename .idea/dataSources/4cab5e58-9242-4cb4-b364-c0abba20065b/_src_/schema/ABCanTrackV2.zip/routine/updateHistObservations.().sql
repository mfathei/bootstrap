CREATE PROCEDURE ABCanTrackV2.updateHistObservations()
  BEGIN
    DECLARE finish INT DEFAULT 0 ;
  
    DECLARE vObserAnaName TEXT  ;    
	DECLARE newvObserAnaName TEXT DEFAULT '';
	DECLARE vEnergyForm TEXT DEFAULT '';
	DECLARE vSubActions TEXT DEFAULT '';
	DECLARE vSubConditions TEXT DEFAULT '';
	DECLARE vUnderLyingCauses TEXT DEFAULT '';
		
    
    DECLARE vHistIncidentId VARCHAR (100) ;
    DECLARE vIncidentId VARCHAR (100) ;
	DECLARE vOrgId VARCHAR (100) ;
    DECLARE delim VARCHAR (10) DEFAULT ';| ' ;
     DECLARE ret TEXT DEFAULT '';	
  
    
    DECLARE std_name_sur CURSOR FOR 
 
  
	SELECT ObserAnaName, hist_incident.HistIncidentId,IncidentId, OrgId 
    FROM hist_incident     WHERE ObserAnaName IS NOT NULL   ;
        
	
		
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET finish = 1 ;
    SET @cnt = 0 ;
    SET @ObserAnaNameOccur = 0 ;
    OPEN std_name_sur ;
    std_name_loop :
    LOOP
        FETCH std_name_sur INTO vObserAnaName, vHistIncidentId, vIncidentId, vOrgId;
        IF finish = 1 
        THEN LEAVE std_name_loop ;
        END IF ;
        SET @cnt = @cnt + 1 ;
		
		SET vEnergyForm = '';
		SET vSubActions = '';
		SET vSubConditions = '';
		SET vUnderLyingCauses = '';
		-- select vObserAnaName;
        SET @ObserAnaNameOccur = SPLITTER_COUNT (vObserAnaName, delim) ;
        IF @ObserAnaNameOccur > 0 
        THEN SET @ObserAnaNameOccur = @ObserAnaNameOccur + 1 ;
        SET @curr = 1 ;
        ObserAnaName_loop :
        LOOP
            IF @curr > @ObserAnaNameOccur 
            THEN LEAVE ObserAnaName_loop ;
            END IF ;
            -- set ret = concat('Machine Energy, Struck by moving object, projectiles, particulate, motor vehicle ;| Congestion or Restricted Action ;| Inadequate Preparation/Planning ;| Failure to Identify Hazard/Risk ;| Failure to Check/Monitor ;| Failure to Communicate/Coordinate ;| Improper Placement ;| Other (explain below)');
            
            SET newvObserAnaName = SPLIT_STRING (vObserAnaName, delim, @curr) ;
			-- select vHistIncidentId;
            
            -- set @exception =vObserAnaName;
             
			 SET @ObservationAndAnalysisCode = (SELECT ObservationAndAnalysisCode
										FROM    observation_analysis_param op
										JOIN observation_analysis oa  ON(op.ObservationAndAnalysisId = oa.ObservationAndAnalysisId)   
										WHERE oa.OrgId = vOrgId 
										and  op.ObservationAndAnalysisParamName  = newvObserAnaName  LIMIT 1) ;
                         
		   IF @ObservationAndAnalysisCode = 'EnergyForm' THEN
            IF vEnergyForm = '' THEN
                SET vEnergyForm =newvObserAnaName;
            ELSE
                SET vEnergyForm = CONCAT(vEnergyForm , ';| ',newvObserAnaName);
            END IF;
        ELSEIF @ObservationAndAnalysisCode = 'SubActions' THEN
            IF vSubActions = '' THEN
                SET vSubActions =newvObserAnaName;
            ELSE
                SET vSubActions = CONCAT(vSubActions , ';| ',newvObserAnaName);
            END IF;
        ELSEIF @ObservationAndAnalysisCode = 'SubConditions' THEN
            IF vSubConditions = '' THEN
                SET vSubConditions =newvObserAnaName;
            ELSE
                SET vSubConditions = CONCAT(vSubConditions , ';| ',newvObserAnaName);
            END IF;
        ELSEIF @ObservationAndAnalysisCode = 'UnderLyingCauses' THEN
            IF vUnderLyingCauses = '' THEN
                SET vUnderLyingCauses =newvObserAnaName;
            ELSE
                SET vUnderLyingCauses = CONCAT(vUnderLyingCauses , ';| ',newvObserAnaName);
            END IF;
        END IF;
		  
            SET @curr = @curr + 1 ;
        END LOOP ObserAnaName_loop ;
        END IF ;
		
	-- 	select vHistIncidentId, vEnergyForm, vSubActions, vUnderLyingCauses, vSubConditions;
      
	 -- set ret = concat(ret, 'INSERT INTO histinc_thirdparties(HistIncidentId, EnergyForm, SubActions, UnderLyingCauses, SubConditions) VALUES(vHistIncidentId, vEnergyForm, vSubActions, vUnderLyingCauses, vSubConditions) ON DUPLICATE KEY UPDATE EnergyForm = vEnergyForm, SubActions = vSubActions, UnderLyingCauses = UnderLyingCauses, SubConditions = vSubConditions');
	INSERT INTO histinc_thirdparties(HistIncidentId, EnergyForm, SubActions, UnderLyingCauses, SubConditions) VALUES(vHistIncidentId, vEnergyForm, vSubActions, vUnderLyingCauses, vSubConditions) ON DUPLICATE KEY UPDATE EnergyForm = vEnergyForm, SubActions = vSubActions, UnderLyingCauses = vUnderLyingCauses, SubConditions = vSubConditions;
	  
    END LOOP std_name_loop ;
   
    CLOSE std_name_sur ;
END;
