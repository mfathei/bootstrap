CREATE PROCEDURE ABCanTrackV2.ReplaceIncidentEmails(IN `$IncidentId` VARCHAR(100))
  BEGIN
select   HistIncidentId,
concat(empCreator.FirstName, " " , empCreator.LastName) as CreatorName,
 IncidentNumber,VersionNumber,
    EventTypeName,
    DATE_FORMAT(incident.IncidentDate, '%m/%d/%Y') AS IncidentDate,
    incident.IncidentHour,
    incident.IncidentMinute,
    CASE incident.IsEmerRP
        WHEN '0' THEN 'no'
        WHEN '1' THEN 'yes'
    END AS IsEmerRP,
    incident.RepName,
    incident.RepEmail,
    incident.RepPosition,
    incident.RepCompany,
    incident.RepPrimaryPhone,
    incident.RepAlternatePhone,
    Location1Name,
    Location2Name,
    Location3Name,
    Location4Name,
    incident.OtherLocation,
    OperationTypeName,
    RiskOfRecurrenceName,
    IncidentSeverityName,
    DATE_FORMAT(incident.SignOffDate, '%m/%d/%Y') AS SignOffDate,
    InvStatusName,
    DATE_FORMAT(incident.InvestigationDate, '%m/%d/%Y') AS InvestigationDate,
    incident.InvestigatorName1,
    incident.InvestigatorName2,
    incident.InvestigatorName3,
    incident.IncDescription,
    incident.EnergyFormNote,
    incident.SubStandardActionNote,
    incident.SubStandardConditionNote,
    incident.UnderLyingCauseNote,
    incident.InvSummary,       
    incident.EventSequence,   
  
   	EventTypeName as EventTypeId, 
	OperationTypeName as OperationTypeId,
	Location1Name as Location1Id,
	Location2Name as Location2Id, 
	Location3Name as Location3Id,
	Location4Name as Location4Id,  
	(select group_concat(ObservationAndAnalysisParamName separator '; ') from observation_analysis_param  inner join observation_analysis on observation_analysis.ObservationAndAnalysisId = observation_analysis_param.ObservationAndAnalysisId where ObservationAndAnalysisCode ='SubActions' and  ObservationAndAnalysisParamId in (select ObservationAndAnalysisParamId  from inc_obser_ana where incidentid = $IncidentId)) as SubActions,
	(select group_concat(ObservationAndAnalysisParamName separator '; ') from observation_analysis_param  inner join observation_analysis on observation_analysis.ObservationAndAnalysisId = observation_analysis_param.ObservationAndAnalysisId where ObservationAndAnalysisCode ='SubConditions' and  ObservationAndAnalysisParamId in (select ObservationAndAnalysisParamId  from inc_obser_ana where incidentid = $IncidentId)) as SubConditions,
   -- (select group_concat(ObservationAndAnalysisParamName separator '; ') from observation_analysis_param  inner join observation_analysis on observation_analysis.ObservationAndAnalysisId = observation_analysis_param.ObservationAndAnalysisId where ObservationAndAnalysisCode ='UnderLyingCauses' and  ObservationAndAnalysisParamId in (select ObservationAndAnalysisParamId  from inc_obser_ana where incidentid = $IncidentId)) as UnderLyingCauses,
    OEDepartmentName as OEDepartmentId,
	RiskOfRecurrenceName as RiskOfRecurrenceId,
    IncidentSeverityName as IncidentSeverityId,    
    EnvConditionName as EnvConditions,
    RootCauseName as RootCauseParamId,
    
	IncInvSourceName as InvSourceParamId,
    
    InvStatusName as InvStatusId,
    incident.InvestigatorName1 as InvestigatorId1,
    incident.InvestigatorName2 as InvestigatorId2, 
    incident.InvestigatorName3 as InvestigatorId3,
    incident.ResponseCost,
    incident.RepairCost,
    incident.InsuranceCost,
    incident.WCBCost,
    incident.OtherCost,
    incident.TotalCost,
    incident.FollowUpNote,

	incident.SourceDetails,
    incident.RootCauseNote,	
    incident.SignOffInvestigatorName as SignOffInvestigatorId,
concat(updator.FirstName, " " , updator.LastName) as UpdatedByName

from  incident
INNER JOIN hist_incident hinc ON incident.IncidentId = hinc.IncidentId 
join employee as empCreator on empCreator.EmployeeId = incident.CreatorId
join employee as updator on updator.EmployeeId = hinc.UpdatedById
where incident.IncidentId=$IncidentId
order by VersionNumber desc limit 1;
END;
