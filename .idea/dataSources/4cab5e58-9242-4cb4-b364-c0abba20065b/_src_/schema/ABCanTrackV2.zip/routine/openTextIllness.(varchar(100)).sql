CREATE PROCEDURE ABCanTrackV2.openTextIllness(IN `$IncidentId` VARCHAR(100))
  begin
    set session group_concat_max_len = 10000;
      SELECT distinct 
 `illness`.`IllnessId`,
        `impact_type`.`ImpactTypeName` AS `ImpactTypeId`,
        `impact_type`.`ImpactTypeCode` AS `ImpactTypeCode`,
        `impact_sub_type`.`ImpactSubTypeName` AS `ImpactSubTypeId`,
        `illness`.`IntEmployeeName1` AS `IntEmployeeName1`,
        `illness`.`IntEmployeeName2` AS `IntEmployeeName2`,
        `illness`.`IntEmployeeName3` AS `IntEmployeeName3`,
        `illness`.`IntEmployeeDept1` AS `IntEmployeeDept1`,
        `illness`.`IntEmployeeDept2` AS `IntEmployeeDept2`,
        `illness`.`IntEmployeeDept3` AS `IntEmployeeDept3`,
        `illness`.`PrimRespondName` AS `PrimRespondName`,
        `illness`.`Description` AS `Description`,
        GETILLNESSDESCRIPTION2(`hist_illness`.`IllnessId`,
                `hist_illness`.`OriginalIllnessId`) AS `OldImpactDescription`,
         CASE `illness`.`EstimatedCost` WHEN '0.00' THEN ''  END AS `ImpactEstimatedCost`,
        (SELECT 
                GROUP_CONCAT(DISTINCT `external_agency`.`ExtAgencyName`
                        SEPARATOR ', ')
            FROM
                (`impacts_ext_agency`
                JOIN `external_agency` ON ((`external_agency`.`ExtAgencyId` = `impacts_ext_agency`.`ExtAgencyId`)))
            WHERE
                (`impacts_ext_agency`.`IllnessId` = `illness`.`IllnessId`)
            GROUP BY `impacts_ext_agency`.`IllnessId`) AS `ExtAgencyId`,
        `initial_treatment`.`InitialTreatmentName` AS `InitialTreatmentId`,
        `restricted_work`.`RestrictedWorkName` AS `RestrictedWorkId`,
        DATE_FORMAT(`illness`.`LostTimeStart`, '%m/%d/%Y') AS `LostTimeStart`,
        DATE_FORMAT(`illness`.`LostTimeEnd`, '%m/%d/%Y') AS `LostTimeEnd`,
        `illness`.`AdjustmentDays` AS `AdjustmentDays`,
        `illness`.`TotalDaysOff` AS `TotalDaysOff`,
        `illness`.`IllnessDescription` AS `ImpactTypeDescription`,
        GETILLNESSDESCRIPTION(`hist_illness`.`IllnessId`,
                `hist_illness`.`OriginalIllnessId`) AS `OldImpactTypeDescription`,
        `illness`.`PersonalAfflictedName` AS `Illness_PersonalInjured`,        
        (SELECT                  GROUP_CONCAT(`symptoms`.`Description`                        SEPARATOR ' ; ')
            FROM                `symptoms`           
            WHERE
                `symptoms`.`SymptomsId` IN (SELECT                         `illness_symptoms`.`SymptomsId`
                    FROM                        `illness_symptoms`
                    WHERE                        (`illness_symptoms`.`IllnessId` = `illness`.`IllnessId`))) AS `SymptomsId`
    FROM
        (((((`illness`
        JOIN `impact_sub_type` ON ((`impact_sub_type`.`ImpactSubTypeId` = `illness`.`ImpactSubTypeId`)))
        JOIN `impact_type` ON ((`impact_sub_type`.`ImpactTypeId` = `impact_type`.`ImpactTypeId`)))
        LEFT JOIN `restricted_work` ON ((`illness`.`RestrictedWorkId` = `restricted_work`.`RestrictedWorkId`)))
        LEFT JOIN `initial_treatment` ON ((`illness`.`InitialTreatmentId` = `initial_treatment`.`InitialTreatmentId`)))
        JOIN `hist_illness` ON ((`hist_illness`.`IllnessId` = `illness`.`IllnessId`))) 
	where illness.Incidentid = $IncidentId;
        end;
