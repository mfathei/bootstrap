CREATE PROCEDURE ABCanTrackV2.openTextSpill_release(IN `$IncidentId` VARCHAR(100))
  begin
    set session group_concat_max_len = 10000;
     SELECT distinct
     `spill_release`.`SpillReleaseId`,      
        `impact_type`.`ImpactTypeName` AS `ImpactTypeId`,
        `impact_type`.`ImpactTypeCode` AS `ImpactTypeCode`,
        `impact_sub_type`.`ImpactSubTypeName` AS `ImpactSubTypeId`,
        `spill_release`.`IntEmployeeName1` AS `IntEmployeeName1`,
        `spill_release`.`IntEmployeeName2` AS `IntEmployeeName2`,
        `spill_release`.`IntEmployeeName3` AS `IntEmployeeName3`,
        `spill_release`.`IntEmployeeDept1` AS `IntEmployeeDept1`,
        `spill_release`.`IntEmployeeDept2` AS `IntEmployeeDept2`,
        `spill_release`.`IntEmployeeDept3` AS `IntEmployeeDept3`,
        `spill_release`.`PrimRespondName` AS `PrimRespondName`,
        `spill_release`.`Description` AS `Description`,
        GETIMPACTDESCRIPTION3(`hist_spill_release`.`SpillReleaseId`,
                `hist_spill_release`.`OriginalSpillReleaseId`) AS `OldImpactDescription`,
      --  `spill_release`.`EstimatedCost` AS `ImpactEstimatedCost`,
         CASE `spill_release`.`EstimatedCost` WHEN '0.00' THEN ''  END AS `ImpactEstimatedCost`,
        (SELECT 
                GROUP_CONCAT(DISTINCT `external_agency`.`ExtAgencyName`
                        SEPARATOR ', ')
            FROM
                (`impacts_ext_agency`
                JOIN `external_agency` ON ((`external_agency`.`ExtAgencyId` = `impacts_ext_agency`.`ExtAgencyId`)))
            WHERE
                (`impacts_ext_agency`.`SpillReleaseId` = `spill_release`.`SpillReleaseId`)
            GROUP BY `impacts_ext_agency`.`SpillReleaseId`) AS `ExtAgencyId`,
        `spill_release_source`.`SourceName` AS `SourceId`,
        `spill_release`.`DurationValue` AS `DurationValue`,
        `duration_unit`.`DurationUnitName` AS `DurationUnitId`,
        `spill_release`.`QuantityValue` AS `QuantityValue`,
        `quantity_unit`.`QuantityUnitName` AS `QuantityUnitId`,
        `spill_release`.`QuantityRecoveredValue` AS `QuantityRecoveredValue`,
        `qtu1`.`QuantityUnitName` AS `RecoveredUnitId`,
        `spill_release`.`WhatWasIt` AS `WhatWasIt`,
        `spill_release`.`HowDidSROccur` AS `HowDidSROccur`,
      CASE  `spill_release`.IsReportable WHEN '0' THEN 'no' WHEN '1' THEN 'yes' END AS IsReportable,
        `sp_rel_agency`.`SpRelAgencyName` AS `SpRelAgencyName`,
        GETWHATWASIT(`hist_spill_release`.`SpillReleaseId`,
                `hist_spill_release`.`OriginalSpillReleaseId`) AS `OldWhatWasIt`,
        GETHOWDIDSROCCUR(`hist_spill_release`.`SpillReleaseId`,
                `hist_spill_release`.`OriginalSpillReleaseId`) AS `OldHowDidSROccur`
    FROM
        ((((((((`spill_release`
        JOIN `impact_sub_type` ON ((`impact_sub_type`.`ImpactSubTypeId` = `spill_release`.`ImpactSubTypeId`)))
        JOIN `impact_type` ON ((`impact_sub_type`.`ImpactTypeId` = `impact_type`.`ImpactTypeId`)))
        LEFT JOIN `spill_release_source` ON ((`spill_release`.`SourceId` = `spill_release_source`.`SourceId`)))
        LEFT JOIN `duration_unit` ON ((`spill_release`.`DurationUnitId` = `duration_unit`.`DurationUnitId`)))
        LEFT JOIN `quantity_unit` ON ((`spill_release`.`QuantityUnitId` = `quantity_unit`.`QuantityUnitId`)))
        LEFT JOIN `quantity_unit` `qtu1` ON ((`spill_release`.`QuantityUnitId` = `qtu1`.`QuantityUnitId`)))
        LEFT JOIN `sp_rel_agency` ON ((`spill_release`.`SpRelAgencyId` = `sp_rel_agency`.`SpRelAgencyId`)))
        JOIN `hist_spill_release` ON ((`hist_spill_release`.`SpillReleaseId` = `spill_release`.`SpillReleaseId`))) 
	where spill_release.Incidentid = $IncidentId;
        end;
