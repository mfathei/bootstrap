CREATE PROCEDURE ABCanTrackV2.GetDraftIncident(IN xmlData TEXT)
  BEGIN
 
SET @OrgId = extractvalue(xmlData, '//OrgId');
SET @page = extractvalue(xmlData, '//page');
SET @limit = extractvalue(xmlData, '//limit');
SET @sortOrder =  extractvalue(xmlData, '//sortOrder');
SET @index =  extractvalue(xmlData, '//index');
SET @Mine =  extractvalue(xmlData, '//Mine');
SET @CreatorId = extractvalue(xmlData, '//CreatorId');
SET @Export =  extractvalue(xmlData, '//Export');
set @selectquery ="
SELECT   
	incident.IncidentId, incident.IncidentNumber, date_format(incident.LastUpdateDate,'%m/%d/%Y') as LastUpdateDate,
	date_format(incident.IncidentDate,'%m/%d/%Y') as IncidentDate,	incident.IncDescription,
	event_type.EventTypeName as EventTypeId 
";
set @queryFrom = " from incident  
left outer join event_type on incident.EventTypeId = event_type.EventTypeId ";
SET @queryWhere = ' where 1= 1 ';
IF (@OrgId != '' AND @OrgId !='0') THEN
	SET @queryWhere = CONCAT(@queryWhere,' and incident.OrgId =   "', @Orgid,'" ');
END IF;
SET @queryWhere = CONCAT(@queryWhere,' AND incident.CreatorId =  "',@CreatorId,'" '  );
SET @queryWhere = CONCAT(@queryWhere,' AND incident.EditingBy =  "',@CreatorId,'" '  );
SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );
-- select @query;
SET @querycount =  CONCAT( 'SELECT count(*) into @cnt from  (', @query, ' ) t');
PREPARE stmt1 FROM @querycount;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
SET @selectquery = CONCAT (@selectquery,', ', @cnt, ' as Count ');
SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );
SET @query = CONCAT(@query, ' order by ', @index,'  ', @sortOrder);
SET @page = (@page - 1) * @limit;
SET @query = CONCAT(@query, ' LIMIT ', @limit ,' OFFSET ',  @page);
-- select @query;
PREPARE stmt1 FROM @query;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
END;
