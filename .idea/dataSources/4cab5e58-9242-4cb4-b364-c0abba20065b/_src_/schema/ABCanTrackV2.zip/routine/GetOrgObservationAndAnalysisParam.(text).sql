CREATE PROCEDURE ABCanTrackV2.GetOrgObservationAndAnalysisParam(IN xmlData TEXT)
  BEGIN
SET @page = extractvalue(xmlData, '//page');
SET @limit = extractvalue(xmlData, '//limit');
SET @sortOrder =  extractvalue(xmlData, '//sortOrder');
SET @index =  extractvalue(xmlData, '//index');
SET @Mine =  extractvalue(xmlData, '//Mine');
SET @CreatorId = extractvalue(xmlData, '//CreatorId');
SET @Export =  extractvalue(xmlData, '//Export');
SET @OrgId =  extractvalue(xmlData, '//OrgId');
SET @checkOrg =  extractvalue(xmlData, '//check');
SET @ObservationAndAnalysisCode =  extractvalue(xmlData, '//ObservationAndAnalysisCode');
SET @LanguageCode =  extractvalue(xmlData, '//LanguageCode');
SET @lblSingle = (select GetItemLabel(@LanguageCode,'singleselection'));
SET @lblMulti = (select GetItemLabel(@LanguageCode,'multipleselection'));
set @selectquery =concat('SELECT OrgName,observation_analysis.OrgId, ObservationAndAnalysisParamId as ParentObservationAndAnalysisParamId ,  
	ObservationAndAnalysisParamName as ParentObservationAndAnalysisParamName, observation_analysis_param.`Order` as ParentOrder,
  CASE IsMulti WHEN '0' THEN '',@lblSingle,'' WHEN '1' THEN '', @lblMulti,'' END AS IsMulti ');
      
set @queryFrom = ' from  observation_analysis_param
inner join  observation_analysis on observation_analysis.ObservationAndAnalysisId = observation_analysis_param.ObservationAndAnalysisId inner join organization on observation_analysis.OrgId = organization.OrgId';
SET @queryWhere = ' where 1= 1 ';
SET @queryWhere = CONCAT(@queryWhere,' and observation_analysis_param.Hide = 0 ');
SET @queryWhere = CONCAT(@queryWhere,' and observation_analysis.Hide = 0 ');
if(@checkOrg  = 'false') then 
SET @queryWhere = CONCAT(@queryWhere,' and observation_analysis.OrgId = "', @Orgid ,'"');
end if;
SET @queryWhere = CONCAT(@queryWhere,' and ParentId is null and ObservationAndAnalysisCode =  ',"'", @ObservationAndAnalysisCode,"'");
SET @myArrayOfValue = 'ObservationAndAnalysisParamId,ParentObservationAndAnalysisParamName,ParentOrder,';
SET @Postition = LOCATE(',', @myArrayOfValue);
WHILE ( @Postition > 0 ) DO
 SET @STR = SUBSTRING(@myArrayOfValue, 1, @Postition-1);
 SET @myArrayOfValue = SUBSTRING(@myArrayOfValue, @Postition + 1);
 SET @Col =  extractvalue(xmlData, CONCAT('//',@STR));
 IF (@Col != '' AND @Col !='NULL') THEN
set  @STR = TRIM(@STR);
	if( @STR = 'ParentOrder') then set  @STR = 'observation_analysis_param.`Order`';  end if;
	if( @STR = 'ParentObservationAndAnalysisParamName') then set  @STR = 'ObservationAndAnalysisParamName';  end if;
	SET @queryWhere = CONCAT(@queryWhere,CONCAT(' AND   ',@STR,' like '"'%", @Col ,"%'")); 
 END IF;
 
 SET @Postition = LOCATE(',', @myArrayOfValue);
END WHILE;
SET @IsMulti =  extractvalue(xmlData, '//IsMulti');
IF (@IsMulti != '' AND @IsMulti !='NULL') THEN
	IF( @IsMulti  != '2' ) THEN 
		SET @queryWhere = CONCAT(@queryWhere,'  AND IsMulti = ',  @IsMulti ); 
	END IF;	
END IF;
-- select @queryWhere;
SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );
-- select  @query;
SET @querycount = CONCAT( 'SELECT count(*) into @cnt ', @queryFrom, @queryWhere );
PREPARE stmt1 FROM @querycount;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
	
SET @selectquery = CONCAT (@selectquery,', ', @cnt, ' as Count ');
-- select  @query;
SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );
if( @index = 'Order') then set  @index = 'observation_analysis_param.`Order`';  end if;
if( @index = 'ParentOrder') then set  @index = 'observation_analysis_param.`Order`';  end if;
if( @index = 'Order, ParentObservationAndAnalysisParamName') then set  @index = 'observation_analysis_param.`Order`,  ParentObservationAndAnalysisParamName';  end if;
if( @index = 'ParentObservationAndAnalysisParamName,Order') then set  @index = 'observation_analysis_param.`Order`,  ParentObservationAndAnalysisParamName';  end if;
SET @query = CONCAT(@query, ' order by ', @index,'  ', @sortOrder);
if( @Export ="false") then
SET @page = (@page - 1) * @limit;
SET @query = CONCAT(@query, ' LIMIT ', @limit ,' OFFSET ',  @page);
end if;
-- select  @query;
PREPARE stmt1 FROM @query;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
END;
