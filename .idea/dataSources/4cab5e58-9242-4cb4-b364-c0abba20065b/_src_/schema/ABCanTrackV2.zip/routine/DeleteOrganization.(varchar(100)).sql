CREATE PROCEDURE ABCanTrackV2.DeleteOrganization(IN `$OrgId` VARCHAR(100))
  BEGIN
DECLARE $Err TEXT;
DECLARE $Location, $Count INT;
    
	DECLARE EXIT HANDLER FOR SQLEXCEPTION
	BEGIN
		set @CurrState = RETURNED_SQLSTATE,
		@ErrNo = MYSQL_ERRNO, @ErrDesc = MESSAGE_TEXT;
		SET @FullError = CONCAT('ERROR ', @ErrNo, " (", @CurrState, "): ", @ErrDesc);
		ROLLBACK;
		INSERT INTO `ABCanTrackV2`.`delete_org_log`
			(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
		VALUES
			($OrgId, 'DeleteOrganization',  @FullError, NULL, $Count, 1002);
		RESIGNAL;
	END;
    
	START TRANSACTION;
	-- 1
	CALL `ABCanTrackV2`.`DeleteOrgHistories`($OrgId);
	-- 2
	CALL `ABCanTrackV2`.`DeleteOrgFieldValue`($OrgId);
	-- 3
	CALL `ABCanTrackV2`.`DeleteOrgCorrectiveAction`($OrgId);
	-- 4
	CALL `ABCanTrackV2`.`DeleteOrgPeopleInvolved`($OrgId);
	-- 5
	CALL `ABCanTrackV2`.`DeleteOrgImpact`($OrgId);
	-- 6
	CALL `ABCanTrackV2`.`DeleteOrgInjury`($OrgId);
	-- 7
	CALL `ABCanTrackV2`.`DeleteOrgIlness`($OrgId);
	-- 8 
	CALL `ABCanTrackV2`.`DeleteOrgSpillRelease`($OrgId);
	-- 9
	CALL `ABCanTrackV2`.`DeleteOrgVehicleDamage`($OrgId);
	-- 10
	CALL `ABCanTrackV2`.`DeleteOrgTrafficViolation`($OrgId);
	-- 11
	CALL `ABCanTrackV2`.`DeleteOrgIncident`($OrgId);
	-- 12
	CALL `ABCanTrackV2`.`DeleteOrgLookups`($OrgId);
	-- 13
	CALL `ABCanTrackV2`.`DeleteOrgLocations`($OrgId);
	-- 14
	CALL `ABCanTrackV2`.`DeleteOrgThirdParties`($OrgId);
	-- 15
	CALL `ABCanTrackV2`.`DeleteOrgFields`($OrgId);
	-- 16
	CALL `ABCanTrackV2`.`DeleteOrgEmployees`($OrgId);
	-- 17
	CALL `ABCanTrackV2`.`DeleteOrgGroups`($OrgId);
-- *************************************************************************************************************************************
    
    
    -- Step1: ABCanTrackV2.org_employee
	SET $Count = (SELECT COUNT(*) from `ABCanTrackV2`.`org_employee` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrganization',  'ABCanTrackV2.org_product', NULL, $Count, 1);
    
	-- ************
	DELETE FROM `ABCanTrackV2`.`org_employee` WHERE OrgId = $OrgId;
    -- #
    
    
    -- Step2: CommonDB.org_employee
	SET $Count = (SELECT COUNT(*) from `CommonDB`.`org_employee` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrganization',  'CommonDB.org_product', NULL, $Count, 2);
    
	-- ************
	DELETE FROM `CommonDB`.`org_employee` WHERE OrgId = $OrgId;
    -- #
    
    
    -- Step3: CommonDB.org_product
	SET $Count = (SELECT COUNT(*) from `CommonDB`.`org_product` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrganization',  'CommonDB.org_product', NULL, $Count, 3);
    
	-- ************
	DELETE FROM `CommonDB`.`org_product` WHERE OrgId = $OrgId;
    -- #
    
    
    -- Step4: ABCanTrackV2.organization
	SET $Count = (SELECT COUNT(*) from `ABCanTrackV2`.`organization` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrganization',  'ABCanTrackV2.organization', NULL, $Count, 4);
    
	-- ************
	DELETE FROM `ABCanTrackV2`.`organization` WHERE OrgId = $OrgId;
    -- #
    
    
    -- Step5: CommonDB.organization
	SET $Count = (SELECT COUNT(*) from `CommonDB`.`organization` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrganization',  'CommonDB.organization', NULL, $Count, 5);
    
	-- ************
	DELETE FROM `CommonDB`.`organization` WHERE OrgId = $OrgId;
	COMMIT;
    -- #
END;
