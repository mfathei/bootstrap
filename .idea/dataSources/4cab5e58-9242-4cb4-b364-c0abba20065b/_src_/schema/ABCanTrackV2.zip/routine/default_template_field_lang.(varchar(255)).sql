CREATE PROCEDURE ABCanTrackV2.default_template_field_lang(IN `$LangId` VARCHAR(255))
  BEGIN
DECLARE finished INTEGER DEFAULT 0;
DECLARE $gid , $fcode, $pcode, $pid VARCHAR(255);
 DECLARE g_p_cursor CURSOR FOR
 SELECT `template`.TemplateId,`template`.TemplateName,`field`.FieldName,`field`.FieldId FROM ABCanTrackV2.template_field JOIN ABCanTrackV2.`template` 
 ON (`template`.TemplateId = template_field.TemplateId  AND `template`.IsTranslatable = 1 AND `template`.LanguageId = GetLanguageId('en'))
 JOIN ABCanTrackV2.`field`
 ON (template_field.FieldId = `field`.FieldId AND `field`.OrgId IS NULL AND `field`.LanguageId = GetLanguageId('en'))
 INNER JOIN organization ON(template.OrgId=organization.OrgId AND organization.OrgCode='Alliance');
 -- declare NOT FOUND handler
	DECLARE CONTINUE HANDLER 
	FOR NOT FOUND SET finished = 1;
    
 OPEN g_p_cursor;
-- FETCH g_p_cursor INTO $gid , $fcode, $pcode, $pid;
ex: LOOP
	FETCH g_p_cursor INTO $gid , $fcode, $pcode, $pid;
	IF finished = 1 THEN 
		LEAVE ex;
	END IF;
-- select $fcode,$pcode;
SET @new_tid = (SELECT TemplateId FROM ABCanTrackV2.`template` INNER JOIN organization ON(template.OrgId=organization.OrgId AND organization.OrgCode='Alliance') WHERE TemplateName = $fcode AND template.LanguageId = $LangId);
SET @new_fid = (SELECT FieldId FROM ABCanTrackV2.`field` WHERE FieldName = $pcode AND OrgId IS NULL AND LanguageId = $LangId);
INSERT INTO ABCanTrackV2.template_field
VALUES(@new_tid,@new_fid, NULL);
END LOOP ex;
CLOSE g_p_cursor;
END;
