CREATE PROCEDURE ABCanTrackV2.new_procedure(IN `$OrgId` VARCHAR(100))
  BEGIN
DECLARE $Min, $Max, $Location int;
DELETE from hist_corrective_action where IncidentId in (select IncidentId from incident where OrgId = $OrgId);
DELETE from hist_illness where IncidentId in (select IncidentId from incident where OrgId = $OrgId);
DELETE from hist_impact where IncidentId in (select IncidentId from incident where OrgId = $OrgId);
DELETE from hist_incident where IncidentId in (select IncidentId from incident where OrgId = $OrgId);
DELETE from hist_injury where IncidentId in (select IncidentId from incident where OrgId = $OrgId);
DELETE from hist_people_involved where IncidentId in (select IncidentId from incident where OrgId = $OrgId);
DELETE from hist_spill_release where IncidentId in (select IncidentId from incident where OrgId = $OrgId);
DELETE from hist_traffic_violation where IncidentId in (select IncidentId from incident where OrgId = $OrgId);
DELETE from hist_vehicle_damage where IncidentId in (select IncidentId from incident where OrgId = $OrgId);
DELETE FROM inc_env_cond where IncidentId in (select IncidentId from incident where OrgId = $OrgId);
DELETE FROM inc_inv_source where IncidentId in (select IncidentId from incident where OrgId = $OrgId);
DELETE FROM inc_obser_ana where IncidentId in (select IncidentId from incident where OrgId = $OrgId);
DELETE FROM inc_oe_department where IncidentId in (select IncidentId from incident where OrgId = $OrgId);
DELETE FROM inc_root_cause where IncidentId in (select IncidentId from incident where OrgId = $OrgId);
DELETE FROM inc_third_party where IncidentId in (select IncidentId from incident where OrgId = $OrgId);
DELETE FROM hist_incident where IncidentId in (select IncidentId from incident where OrgId = $OrgId);
SET $Min = (SELECT Min(IncidentId) from incident where OrgId = $OrgId);
SET $Max = (SELECT Max(IncidentId) from incident where OrgId = $OrgId);
While $Min <= $Max
do
CALL `ABCanTrackV2`.`DeleteFrom_illness_Tables`($IncMin);
CALL `ABCanTrackV2`.`DeleteFrom_impacts_Tables`($IncMin);
CALL `ABCanTrackV2`.`DeleteFrom_injury_Tables`($IncMin);
CALL `ABCanTrackV2`.`DeleteFrom_spill_release_Tables`($IncMin);
CALL `ABCanTrackV2`.`DeleteFrom_traffic_violation_Tables`($IncMin);
CALL `ABCanTrackV2`.`DeleteFrom_vehicle_damage_Tables`($IncMin);
CALL `ABCanTrackV2`.`DeleteFrom_people_involved_Tables`($IncMin);
CALL `ABCanTrackV2`.`DeleteFrom_corrective_action_Tables`($IncMin);
If $Min = $Max 
then
SET $Min = $Max + 100;
else
SET $Min = (SELECT Min(IncidentId) from incident where OrgId = $OrgId and IncidentId > $Min);
END If;
END While;
DELETE FROM `ABCanTrackV2`.`inc_deletion_info` where IncidentId in (select IncidentId from incident where OrgId = $OrgId);
DELETE FROM `ABCanTrackV2`.`incident` where OrgId = $OrgId;
delete from `ABCanTrackV2`.`org_alert_message` WHERE OrgId = $OrgId ;
delete from `ABCanTrackV2`.`body_area` WHERE OrgId = $OrgId ;
delete from `ABCanTrackV2`.`body_part` WHERE OrgId = $OrgId ;
delete from `ABCanTrackV2`.`certificate` WHERE OrgId = $OrgId ;
delete from `ABCanTrackV2`.`contact` WHERE OrgId = $OrgId ;
delete from `ABCanTrackV2`.`contact_agency` WHERE OrgId = $OrgId ;
delete from `ABCanTrackV2`.`contact_code` WHERE OrgId = $OrgId ;
delete from `ABCanTrackV2`.`corr_act_status` WHERE OrgId = $OrgId ;
delete from `ABCanTrackV2`.`duration_unit` WHERE OrgId = $OrgId ;
delete from `ABCanTrackV2`.`env_cond_parameter` WHERE EnvConditionId in (SELECT EnvConditionId FROM `ABCanTrackV2`.`env_condition` WHERE OrgId = $OrgId );
delete from `ABCanTrackV2`.`env_condition` WHERE OrgId = $OrgId ;
										 
delete from `ABCanTrackV2`.`event_type` WHERE OrgId = $OrgId ;
delete from `ABCanTrackV2`.`external_agency` WHERE OrgId = $OrgId ;
delete from `ABCanTrackV2`.`impact_sub_type` WHERE ImpactTypeId in (SELECT ImpactTypeId FROM `ABCanTrackV2`.`impact_type`  WHERE OrgId = $OrgId );
delete from `ABCanTrackV2`.`impact_type`  WHERE OrgId = $OrgId ;
										 
delete from `ABCanTrackV2`.`incident_severity` WHERE OrgId = $OrgId ;
delete from `ABCanTrackV2`.`initial_treatment` WHERE OrgId = $OrgId ;
delete from `ABCanTrackV2`.`injury_recordable` WHERE OrgId = $OrgId ;
delete from `ABCanTrackV2`.`injury_type` WHERE OrgId = $OrgId ;
delete from `ABCanTrackV2`.`inv_source` WHERE OrgId = $OrgId ;
delete from `ABCanTrackV2`.`inv_status` WHERE OrgId = $OrgId ;
										
delete from `ABCanTrackV2`.`observation_analysis_param` WHERE ObservationAndAnalysisId in (SELECT ObservationAndAnalysisId from `ABCanTrackV2`.`observation_analysis`  WHERE OrgId = $OrgId );
delete from `ABCanTrackV2`.`observation_analysis`  WHERE OrgId = $OrgId ;
										 
delete from `ABCanTrackV2`.`oe_department` WHERE OrgId = $OrgId ;
delete from `ABCanTrackV2`.`org_field` WHERE OrgId = $OrgId ;
delete from `ABCanTrackV2`.`priority` WHERE OrgId = $OrgId ;
delete from `ABCanTrackV2`.`quantity_unit` WHERE OrgId = $OrgId ;
delete from `ABCanTrackV2`.`restricted_work` WHERE OrgId = $OrgId ;
delete from `ABCanTrackV2`.`risk_of_recurrence` WHERE OrgId = $OrgId ;
										 
delete from `ABCanTrackV2`.`root_cause_param` WHERE RootCauseId in (SELECT RootCauseId FROM `ABCanTrackV2`.`root_cause` WHERE OrgId = $OrgId );
delete from `ABCanTrackV2`.`root_cause` WHERE OrgId = $OrgId ;
							 
delete from `ABCanTrackV2`.`spill_release_source` WHERE OrgId = $OrgId ;
delete from `ABCanTrackV2`.`symptoms` WHERE OrgId = $OrgId ;
delete from `ABCanTrackV2`.`vehicle_type` WHERE OrgId = $OrgId ;
-- Delete organization's fields 
delete from `ABCanTrackV2`.`favorite_field` where FavoriteTableId in (select FavoriteTableId from `ABCanTrackV2`.`favorite_table` where OrgId = $OrgId);
delete from `ABCanTrackV2`.`favorite_table` where OrgId = $OrgId;
delete from `ABCanTrackV2`.`field_value` where FieldId in (Select FieldId from org_field where OrgId = $OrgId) or fieldid in (Select FieldId from field where OrgId = $OrgId);
delete from `ABCanTrackV2`.`option` where FieldId in (Select FieldId from org_field where OrgId = $OrgId) or fieldid in (Select FieldId from field where OrgId = $OrgId);
delete from `ABCanTrackV2`.`stat_table_time_frame` where StatTableId in (select StatTableId from stat_table where OrgId = $OrgId);
delete from `ABCanTrackV2`.`stat_table` where OrgId = $OrgId;
delete from `ABCanTrackV2`.`org_field` where OrgId = $OrgId;
delete from `ABCanTrackV2`.`field` where OrgId = $OrgId;
-- delete organization's locations
delete from `CommonDB`.`location_request` where OrgId = $OrgId;
set $Location = (select LocationLevel from `CommonDB`.`organization` where OrgId = $OrgId);
If $location = 2
then
delete from `ABCanTrackV2`.`location2` Where Location1Id in (select Location1Id from `ABCanTrackV2`.`location1` where OrgId = $OrgId);
delete from `CommonDB`.`location2` Where Location1Id in (select Location1Id from `CommonDB`.`location1` where OrgId = $OrgId);
delete from `CommonDB`.`hist_location2` where Location2Id not in (select Location2Id from `CommonDB`.`location2`);
delete from `ABCanTrackV2`.`location1` where OrgId = $OrgId;
delete from `CommonDB`.`location1` where OrgId = $OrgId;
delete from `CommonDB`.`hist_location1` where Location1Id not in (select Location1Id from `CommonDB`.`location1`);
END if;
if $location = 3
then 
delete from `ABCanTrackV2`.`location3` where Location2Id in (select location2Id from `ABCanTrackV2`.`location2` Where Location1Id in (select Location1Id from `ABCanTrackV2`.`location1` where OrgId = $OrgId));
delete from `CommonDB`.`location3` where Location2Id in (select location2Id from `CommonDB`.`location2` Where Location1Id in (select Location1Id from `CommonDB`.`location1` where OrgId = $OrgId));
delete from `CommonDB`.`hist_location3` where Location3Id not in (select Location3Id from `CommonDB`.`location3`);
delete from `ABCanTrackV2`.`location2` Where Location1Id in (select Location1Id from `ABCanTrackV2`.`location1` where OrgId = $OrgId);
delete from `CommonDB`.`location2` Where Location1Id in (select Location1Id from `CommonDB`.`location1` where OrgId = $OrgId);
delete from `CommonDB`.`hist_location2` where Location2Id not in (select Location2Id from `CommonDB`.`location2`);
delete from `ABCanTrackV2`.`location1` where OrgId = $OrgId;
delete from `CommonDB`.`location1` where OrgId = $OrgId;
delete from `CommonDB`.`hist_location1` where Location1Id not in (select Location1Id from `CommonDB`.`location1`);
END IF;
if $location = 4
then
delete from `ABCanTrackV2`.`location4` where Location3Id in (select Location3Id from `ABCanTrackV2`.`location3` where Location2Id in (select location2Id from `ABCanTrackV2`.`location2` Where Location1Id in (select Location1Id from `ABCanTrackV2`.`location1` where OrgId = $OrgId)));
delete from `CommonDB`.`location4` where Location3Id in (select Location3Id from `ABCanTrackV2`.`location3` where Location2Id in (select location2Id from `CommonDB`.`location2` Where Location1Id in (select Location1Id from `CommonDB`.`location1` where OrgId = $OrgId)));
delete from `CommonDB`.`hist_location4` where Location4Id not in (select Location4Id from `CommonDB`.`location4`);
delete from `ABCanTrackV2`.`location3` where Location2Id in (select location2Id from `ABCanTrackV2`.`location2` Where Location1Id in (select Location1Id from `ABCanTrackV2`.`location1` where OrgId = $OrgId));
delete from `CommonDB`.`location3` where Location2Id in (select location2Id from `CommonDB`.`location2` Where Location1Id in (select Location1Id from `CommonDB`.`location1` where OrgId = $OrgId));
delete from `CommonDB`.`hist_location3` where Location3Id not in (select Location3Id from `CommonDB`.`location3`);
delete from `ABCanTrackV2`.`location2` Where Location1Id in (select Location1Id from `ABCanTrackV2`.`location1` where OrgId = $OrgId);
delete from `CommonDB`.`location2` Where Location1Id in (select Location1Id from `CommonDB`.`location1` where OrgId = $OrgId);
delete from `CommonDB`.`hist_location2` where Location2Id not in (select Location2Id from `CommonDB`.`location2`);
delete from `ABCanTrackV2`.`location1` where OrgId = $OrgId;
delete from `CommonDB`.`location1` where OrgId = $OrgId;
delete from `CommonDB`.`hist_location1` where Location1Id not in (select Location1Id from `CommonDB`.`location1`);
END If;
-- Delete organization's groups
delete from `ABCanTrackV2`.`emp_group` where GroupId in (select GroupId from `ABCanTrackV2`.`group` where OrgId = $OrgId);
delete from `CommonDB`.`emp_group` where GroupId in (select GroupId from `CommonDB`.`group` where OrgId = $OrgId);
delete from `CommonDB`.`group_permission` where GroupId in (select GroupId from `CommonDB`.`group` where OrgId = $OrgId);
delete from `CommonDB`.`product_group` where GroupId in (select GroupId from `CommonDB`.`group` where OrgId = $OrgId);
delete from `ABCanTrackV2`.`group` where OrgId = $OrgId;
delete from `CommonDB`.`group` where OrgId = $OrgId;
-- Delete organization's employees
set $Min = (select Min(EmployeeId) from `CommonDB`.`org_employee` where EmployeeId not in (select EmployeeId from org_employee where OrgId <> $OrgId));
set $Max = (select Max(EmployeeId) from `CommonDB`.`org_employee` where EmployeeId not in (select EmployeeId from org_employee where OrgId <> $OrgId));
while $Min <= $Max
do
delete from `CommonDB`.`org_employee` where EmployeeId = $Min;
delete from `CommonDB`.`login_history` where EmployeeId = $Min;
delete from `CommonDB`.`hist_employee` where EmployeeId = $Min;
delete from `CommonDB`.`employee` where EmployeeId = $Min;
If $Min = $Max 
then
SET $Min = $Max + 100;
else
SET $Min = (select Min(EmployeeId) from `CommonDB`.`org_employee` where EmployeeId not in (select EmployeeId from org_employee where OrgId <> $OrgId) and EmployeeId > $Min);
END If;
End while;
delete from `CommonDB`.`org_employee` where OrgId = $OrgId;
-- operation_type 
delete from `ABCanTrackV2`.`operation_type` where OrgId = $OrgId;
delete from `CommonDB`.`operation_type` where OrgId = $OrgId;
-- CommonDB org_alert_message
delete from `CommonDB`.`org_alert_message` where OrgId = $OrgId;
delete from `CommonDB`.`org_field` where OrgId = $OrgId;
delete from `CommonDB`.`org_product` where OrgId = $OrgId;
-- third_party
delete from `ABCanTrackV2`.`third_party` where OrgId = $OrgId;
delete from `CommonDB`.`third_party` where OrgId = $OrgId;
delete from `ABCanTrackV2`.`third_party_type` where OrgId = $OrgId;
delete from `CommonDB`.`third_party_type` where OrgId = $OrgId;
delete from `ABCanTrackV2`.`email_template` where OrgId = $OrgId;
-- delete organization
delete from `CommonDB`.`hist_organization` where OrgId = $OrgId;
delete from `ABCanTrackV2`.`organization` where OrgId = $OrgId;
delete from `CommonDB`.`organization` where OrgId = $OrgId;
END;
