CREATE PROCEDURE ABCanTrackV2.InsertInto_email_log(IN pFrom             VARCHAR(255), IN pTo TEXT,
                                                   IN pSendToEmployeeId VARCHAR(100), IN pSendToGroupId VARCHAR(100),
                                                   IN pIsSent           SMALLINT(6), IN pError VARCHAR(255),
                                                   IN pEmailTypeId      VARCHAR(100), IN pSubject TEXT,
                                                   IN pOrgId            VARCHAR(100), IN pClientTimeZone VARCHAR(10),
                                                   IN pCc               TEXT)
  BEGIN
SET @SentDate =  TIMESTAMPADD(HOUR, CAST(ifnull(pClientTimeZone, 0) AS SIGNED),UTC_TIMESTAMP());
IF pSendToEmployeeId is not null and pSendToEmployeeId <> ''
THEN
    INSERT INTO `ABCanTrackV2`.`email_log`
    (`OrgId`,
    `From`,
    `To`,
    `SendToEmployeeId`,
    `IsSent`,
    `Error`,
    `EmailTypeId`,
    `Subject`,
    `SentDate`,
    `CC`)
    VALUES
    (pOrgId,
    pFrom,
    pTo,
    pSendToEmployeeId,
    pIsSent,
    pError,
    pEmailTypeId,
    pSubject,
    @SentDate
    , pCc);
elseif pSendToGroupId is not null and pSendToGroupId <> ''
then
    INSERT INTO `ABCanTrackV2`.`email_log`
    (`OrgId`,
    `From`,
    `To`, 
    `SendToGroupId`,
    `IsSent`,
    `Error`,
    `EmailTypeId`,
    `Subject`,
    `SentDate`,
    `CC`)
    VALUES
    (pOrgId,
    pFrom,
    pTo,
    pSendToGroupId,
    pIsSent,
    pError,
    pEmailTypeId,
    pSubject,
    @SentDate
    , pCc);
END IF;
END;
