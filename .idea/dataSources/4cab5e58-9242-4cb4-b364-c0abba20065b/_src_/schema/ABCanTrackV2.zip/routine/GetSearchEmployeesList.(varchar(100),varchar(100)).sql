CREATE PROCEDURE ABCanTrackV2.GetSearchEmployeesList(IN `$OrgId` VARCHAR(100), IN `$searchString` VARCHAR(100))
  BEGIN
set @selectquery =" SELECT employee.EmployeeId, FirstName, LastName, Email, Position, PrimaryPhone, AlternatePhone, OrgName, EmpIsActive ";
set @queryFrom = "  FROM  employee
				inner join org_employee on org_employee.EmployeeId = employee.EmployeeId
				inner join organization on organization.OrgId = org_employee.OrgId ";
SET @queryWhere = CONCAT(" where employee.Email is not null and employee.Email <> ''  and EmpIsActive = 1 ");
SET @queryWhere =CONCAT(@queryWhere, " and   org_employee.OrgId = '", $OrgId,"'"  );
IF ($searchString !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,'  AND CONCAT (FirstName', ' ,','LastName)',' like('"'%", $searchString ,"%'"')');	
END IF;	
SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );
-- select @query; 
PREPARE stmt1 FROM @query;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
END;
