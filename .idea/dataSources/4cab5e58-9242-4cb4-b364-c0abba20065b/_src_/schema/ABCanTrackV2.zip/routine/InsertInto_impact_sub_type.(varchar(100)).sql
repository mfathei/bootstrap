CREATE PROCEDURE ABCanTrackV2.InsertInto_impact_sub_type(IN `$OrgId` VARCHAR(100))
  BEGIN
Declare $Count int;
Declare $impacttypeorgid varchar(100);
Declare $MaxImpactTypeId int;
Declare $cond int;
set $MaxImpactTypeId = (select max(impacttypeid) from impact_type where orgid is null and ispotential = 0);
set $count = 1;
while $count <= $MaxImpactTypeId
do
set $cond = (select impactsubtypeid from impact_sub_type where impacttypeid = $count limit 1);
if $cond is not null then 
set $impacttypeorgid = (select impacttypeid from impact_type where ImpactTypeCode = (select impacttypecode from impact_type where impacttypeid = $count)and orgid = $orgid);
insert into impact_sub_type 
(
`impactsubtypename`,
`impacttypeid`
)
select `impactsubtypename`, $impacttypeorgid
from impact_sub_type where impacttypeid = $count;
end if;
set $count = $count + 1;
end while;
END;
