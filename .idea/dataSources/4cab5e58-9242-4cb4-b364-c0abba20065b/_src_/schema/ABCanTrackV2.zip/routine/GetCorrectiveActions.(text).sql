CREATE PROCEDURE ABCanTrackV2.GetCorrectiveActions(IN xmlData TEXT)
  BEGIN
DECLARE $ids TEXT;
DECLARE $FieldId VARCHAR(100);

SET @OrgId = extractvalue(xmlData, '//OrgId');

SET @page = extractvalue(xmlData, '//page');

SET @limit = extractvalue(xmlData, '//limit');

SET @sortOrder =  extractvalue(xmlData, '//sortOrder');

SET @index =  extractvalue(xmlData, '//index');

SET @Mine =  extractvalue(xmlData, '//Mine');

SET @AssignedTo = extractvalue(xmlData, '//AssignedTo');

SET @Export =  extractvalue(xmlData, '//Export');

SET @LanguageCode =  extractvalue(xmlData, '//LanguageCode');
SET @lblYes = (select GetItemLabel(@LanguageCode,'isreportableyes'));
SET @lblNo = (select GetItemLabel(@LanguageCode,'isreportableno'));


set @selectquery =concat('SELECT corrective_action_view.CorrectiveActionId, IncidentNumber, IncidentId, date_format(IncidentDate,'%m/%d/%Y') AS IncidentDate, date_format(TargetEndDate,'%m/%d/%Y') AS TargetEndDate,date_format(StartDate,'%m/%d/%Y') AS StartDate,date_format(ActualEndDate,'%m/%d/%Y') AS ActualEndDate, TaskEstimatedCost, CorrActStatusName as TaskStatusId , priorityName as PriorityId, TaskDescription, OutComeFollowUp, Comments, AssignedToName as AssignedToId, NotifiedNames  as EmployeeId,  CASE DesiredResults   WHEN '0' THEN '',@lblNo,'' WHEN '1' THEN '', @lblYes,'' END AS DesiredResults,OriginalCorrectiveActionId,SentDate, EditingBy, EditingBy as LockedId
 , IncidentDate as orderDate   ');
 
 
 SET @queryhave = ' having 1 = 1  ';
 
 SET $ids = extractvalue(xmlData, '//FieldNamesIds'); 

SET @Postition = LOCATE(',', $ids);
WHILE ( @Postition > 0 ) DO
	SET @STR = SUBSTRING($ids, 1, @Postition-1);
	SET $ids  = SUBSTRING($ids, @Postition + 1);
	set  @STR = TRIM(@STR);
    SET $FieldId = (SELECT FieldId FROM ABCanTrackV2.field where FieldName = @STR and Orgid=@OrgId );
       
   if ((SELECT INSTR( @STR , 'calendar') > 0)) THEN 
		SET @selectquery = CONCAT(@selectquery , ', (select FieldValue from field_value tbl1
				where tbl1.TableKeyId = corrective_action_view.CorrectiveActionId and tbl1.FieldId ="', $FieldId,'"   limit 1) as `',@STR,'`');	

	elseif ((SELECT INSTR( @STR , 'textbox') > 0)) THEN 
		SET @selectquery = CONCAT(@selectquery , ',    (select FieldValue from field_value tbl1
			where tbl1.TableKeyId = corrective_action_view.CorrectiveActionId and tbl1.FieldId ="', $FieldId,'"   limit 1) as `',@STR,'`');	
            
	elseif ((SELECT INSTR( @STR , 'textarea') > 0)) THEN 
		SET @selectquery = CONCAT(@selectquery , ',    (select FieldValue from field_value tbl1
				where tbl1.TableKeyId = corrective_action_view.CorrectiveActionId and tbl1.FieldId ="', $FieldId,'"   limit 1) as `',@STR,'`');	

	else    
		SET @selectquery = CONCAT(@selectquery , ',   (select group_concat(tbl3.OptionName separator ', ') from field_value tbl1
		inner join `option` tbl3
		on tbl1.OptionId = tbl3.OptionId
		 where tbl1.TableKeyId = corrective_action_view.CorrectiveActionId and tbl1.FieldId ="', $FieldId,'") as `',@STR,'`');	
	
    END IF;  
    
	SET @Col =  extractvalue(xmlData, CONCAT('//',@STR));
	IF (@Col != '' AND @Col !='NULL') THEN	 
	SET @queryhave = CONCAT(@queryhave,'  and  ', @STR ,' like '"'%", @Col ,"%'" );
	END IF; 	
        
	SET @Postition = LOCATE(',', $ids);
END WHILE;
 

set @queryFrom = " from corrective_action_view  ";

SET @queryWhere = ' where 1= 1 ';


IF (@OrgId != '' AND @OrgId !='0') THEN
	SET @queryWhere = CONCAT(@queryWhere,' and OrgId =   "', @Orgid,'" ');
END IF;


IF (@Mine = 'true') THEN
	SET @queryWhere = CONCAT(@queryWhere,' AND AssignedToId =  "', @AssignedTo,'" ');
END IF;

SET @myArrayOfValue = 'IncidentNumber,TaskDescription,OutComeFollowUp,Comments,TaskStatusId,AssignedToId,PriorityId,EmployeeId,';
SET @Postition = LOCATE(',', @myArrayOfValue);

WHILE ( @Postition > 0 ) DO

 SET @STR = SUBSTRING(@myArrayOfValue, 1, @Postition-1);

 SET @myArrayOfValue = SUBSTRING(@myArrayOfValue, @Postition + 1);

 SET @Col =  extractvalue(xmlData, CONCAT('//',@STR));
 IF (@Col != '' AND @Col !='NULL') THEN
	IF (@STR  = 'TaskStatusId' ) then set @STR= 'CorrActStatusName';  END IF;	
	IF (@STR  = 'AssignedToId' ) then set @STR= 'AssignedToName';  END IF;
	IF (@STR  = 'PriorityId' ) then set @STR= 'priorityName';  END IF;
	IF (@STR  = 'EmployeeId' ) then set @STR= 'NotifiedNames';  END IF;

  SET @queryWhere = CONCAT(@queryWhere,CONCAT(' AND ',@STR,' like('"'%", @Col ,"%'"') '));  
 END IF;
 
 SET @Postition = LOCATE(',', @myArrayOfValue);
END WHILE;

 -- select @queryWhere;  

SET @IncidentDateFrom =  extractvalue(xmlData, '//IncidentDateFrom');
SET @IncidentDateTo =  extractvalue(xmlData, '//IncidentDateTo');
IF(@IncidentDateTo != '') THEN

	SET @IncidentDateFrom  = STR_TO_DATE(@IncidentDateFrom , '%m/%d/%Y');
	SET @IncidentDateTo  = STR_TO_DATE(@IncidentDateTo , '%m/%d/%Y');
	SET @IncidentDateTo2 = DATE_ADD(@IncidentDateTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND IncidentDate >  ', "'" , @IncidentDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND IncidentDate <=  ', "'",  @IncidentDateTo2  ,"'" );										
ELSE 
IF(@IncidentDateTo = '' AND @IncidentDateFrom !='' ) THEN

	SET @IncidentDateFrom  = STR_TO_DATE(@IncidentDateFrom , '%m/%d/%Y');
	SET @IncidentDateFrom2 = DATE_ADD(@IncidentDateFrom ,INTERVAL 1 DAY) ;

	SET @queryWhere = CONCAT(@queryWhere,'  AND IncidentDate >=  ',  "'", @IncidentDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND IncidentDate <  ', "'", @IncidentDateFrom2  ,"'");	
END IF;

END IF;

SET @ActualEndDateFrom =  extractvalue(xmlData, '//ActualEndDateFrom');
SET @ActualEndDateTo =  extractvalue(xmlData, '//ActualEndDateTo');
IF(@ActualEndDateTo != '') THEN
	SET @ActualEndDateFrom  = STR_TO_DATE(@ActualEndDateFrom , '%m/%d/%Y');
	SET @ActualEndDateTo  = STR_TO_DATE(@ActualEndDateTo , '%m/%d/%Y');
	SET @ActualEndDateTo2 = DATE_ADD(@ActualEndDateTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND ActualEndDate >  ', "'" , @ActualEndDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND ActualEndDate <=  ', "'",  @ActualEndDateTo2  ,"'" );										
ELSE 
IF(@ActualEndDateTo = '' AND @ActualEndDateFrom !='' ) THEN

	SET @ActualEndDateFrom  = STR_TO_DATE(@ActualEndDateFrom , '%m/%d/%Y');
	SET @ActualEndDateFrom2 = DATE_ADD(@ActualEndDateFrom ,INTERVAL 1 DAY) ;

	SET @queryWhere = CONCAT(@queryWhere,'  AND ActualEndDate >=  ',  "'", @ActualEndDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND ActualEndDate <  ', "'", @ActualEndDateFrom2  ,"'");	
END IF;

END IF;


SET @StartDateFrom =  extractvalue(xmlData, '//StartDateFrom');
SET @StartDateTo =  extractvalue(xmlData, '//StartDateTo');
IF(@StartDateTo != '') THEN
	SET @StartDateFrom  = STR_TO_DATE(@StartDateFrom , '%m/%d/%Y');
	SET @StartDateTo  = STR_TO_DATE(@StartDateTo , '%m/%d/%Y');
	SET @StartDateTo2 = DATE_ADD(@StartDateTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND StartDate >  ', "'" , @StartDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND StartDate <=  ', "'",  @StartDateTo2  ,"'" );										
ELSE 
IF(@StartDateTo = '' AND @StartDateFrom !='' ) THEN

	SET @StartDateFrom  = STR_TO_DATE(@StartDateFrom , '%m/%d/%Y');
	SET @StartDateFrom2 = DATE_ADD(@StartDateFrom ,INTERVAL 1 DAY) ;

	SET @queryWhere = CONCAT(@queryWhere,'  AND StartDate >=  ',  "'", @StartDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND StartDate <  ', "'", @StartDateFrom2  ,"'");	
END IF;

END IF;


SET @TargetEndDateFrom =  extractvalue(xmlData, '//TargetEndDateFrom');
SET @TargetEndDateTo =  extractvalue(xmlData, '//TargetEndDateTo');
IF(@TargetEndDateTo != '') THEN
	SET @TargetEndDateFrom  = STR_TO_DATE(@TargetEndDateFrom , '%m/%d/%Y');
	SET @TargetEndDateTo  = STR_TO_DATE(@TargetEndDateTo , '%m/%d/%Y');
	SET @TargetEndDateTo2 = DATE_ADD(@TargetEndDateTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND TargetEndDate >  ', "'" , @TargetEndDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND TargetEndDate <=  ', "'",  @TargetEndDateTo2  ,"'" );										
ELSE 
IF(@TargetEndDateTo = '' AND @TargetEndDateFrom !='' ) THEN

	SET @TargetEndDateFrom  = STR_TO_DATE(@TargetEndDateFrom , '%m/%d/%Y');
	SET @TargetEndDateFrom2 = DATE_ADD(@TargetEndDateFrom ,INTERVAL 1 DAY) ;

	SET @queryWhere = CONCAT(@queryWhere,'  AND TargetEndDate >=  ',  "'", @TargetEndDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND TargetEndDate <  ', "'", @TargetEndDateFrom2  ,"'");	
END IF;

END IF;

SET @SentDateFrom =  extractvalue(xmlData, '//SentDateFrom');
SET @SentDateTo =  extractvalue(xmlData, '//SentDateTo');
IF(@SentDateTo != '') THEN
	SET @SentDateFrom  = STR_TO_DATE(@SentDateFrom , '%m/%d/%Y');
	SET @SentDateTo  = STR_TO_DATE(@SentDateTo , '%m/%d/%Y');
	SET @SentDateTo2 = DATE_ADD(@SentDateTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND SentDate >  ', "'" , @SentDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND SentDate <=  ', "'",  @SentDateTo2  ,"'" );										
ELSE 
IF(@SentDateTo = '' AND @SentDateFrom !='' ) THEN

	SET @SentDateFrom  = STR_TO_DATE(@SentDateFrom , '%m/%d/%Y');
	SET @SentDateFrom2 = DATE_ADD(@SentDateFrom ,INTERVAL 1 DAY) ;

	SET @queryWhere = CONCAT(@queryWhere,'  AND SentDate >=  ',  "'", @SentDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND SentDate <  ', "'", @SentDateFrom2  ,"'");	
END IF;

END IF;

SET @TaskEstimatedCostTo =  extractvalue(xmlData, '//TaskEstimatedCostTo');
SET @TaskEstimatedCostFrom =  extractvalue(xmlData, '//TaskEstimatedCostFrom');
IF( @TaskEstimatedCostTo !='' ) THEN
	SET @queryWhere = CONCAT(@queryWhere,' AND  EstimatedCost  BETWEEN ', @TaskEstimatedCostFrom, ' and ', @TaskEstimatedCostTo);
ELSE 
	IF( @TaskEstimatedCostFrom !=''  and @TaskEstimatedCostFrom != 'NULL')	 THEN

set  @TaskEstimatedCostFrom  = (replace(@TaskEstimatedCostFrom, '&lt;', '<'));
set  @TaskEstimatedCostFrom  = (replace(@TaskEstimatedCostFrom, '&gt;', '>'));

		SET @queryWhere = CONCAT(@queryWhere,' AND  TaskEstimatedCost  ', @TaskEstimatedCostFrom);
	END IF;
END IF;

SET @DesiredResults =  extractvalue(xmlData, '//DesiredResults');
IF (@DesiredResults != '' AND @DesiredResults !='NULL') THEN
	IF( @DesiredResults  != '2' ) THEN 
		SET @queryWhere = CONCAT(@queryWhere,'  AND DesiredResults = ',  @DesiredResults ); 
	END IF;	
END IF;

-- select @queryWhere;
SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere , @queryhave);



SET @querycount =  CONCAT( 'SELECT count(*) into @cnt from  (', @query, ' ) t');

-- SET @querycount = CONCAT( 'SELECT count(*) into @cnt ', @queryFrom, @queryWhere );
PREPARE stmt1 FROM @querycount;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 


SET @selectquery = CONCAT (@selectquery,', ', @cnt, ' as Count ');


SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere, @queryhave );

IF (@index = 'IncidentDate') then set @index='orderDate'; end if;

SET @query = CONCAT(@query, ' order by ', @index,'  ', @sortOrder);

if( @Export ="false") then
SET @page = (@page - 1) * @limit;
SET @query = CONCAT(@query, ' LIMIT ', @limit ,' OFFSET ',  @page);

end if;

-- select CONCAT( @selectquery, @queryFrom, @queryWhere );

PREPARE stmt1 FROM @query;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 

-- select @query;
 -- select CONCAT( @selectquery, @queryFrom, @queryWhere );

END;
