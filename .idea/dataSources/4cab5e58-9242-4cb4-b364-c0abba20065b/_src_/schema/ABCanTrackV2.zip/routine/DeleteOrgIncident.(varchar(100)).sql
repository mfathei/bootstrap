CREATE PROCEDURE ABCanTrackV2.DeleteOrgIncident(IN `$OrgId` VARCHAR(100))
  BEGIN
	DECLARE $Count INT;
    
    
    -- Step1: inc_env_cond
	SET $Count = (SELECT COUNT(*) FROM inc_env_cond WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId));
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgIncident',  'inc_env_cond', NULL, $Count, 1);
    
	-- ************
	DELETE FROM inc_env_cond WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId);
    -- #
    
    
    -- Step2: inc_inv_source
	SET $Count = (SELECT COUNT(*) FROM inc_inv_source WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId));
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgIncident',  'inc_inv_source', NULL, $Count, 2);
    
	-- ************
	DELETE FROM inc_inv_source WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId);
    -- #
    
    
    -- Step3: inc_obser_ana
	SET $Count = (SELECT COUNT(*) FROM inc_obser_ana WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId));
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgIncident',  'inc_obser_ana', NULL, $Count, 3);
    
	-- ************
	DELETE FROM inc_obser_ana WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId);
    -- #
    
    
    -- Step4: inc_oe_department
	SET $Count = (SELECT COUNT(*) FROM inc_oe_department WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId));
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgIncident',  'inc_oe_department', NULL, $Count, 4);
    
	-- ************
	DELETE FROM inc_oe_department WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId);
    -- #
    
    
    -- Step5: inc_root_cause
	SET $Count = (SELECT COUNT(*) FROM inc_root_cause WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId));
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgIncident',  'inc_root_cause', NULL, $Count, 5);
    
	-- ************
	DELETE FROM inc_root_cause WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId);
    -- #
    
    
    -- Step6: inc_third_party
	SET $Count = (SELECT COUNT(*) FROM inc_third_party WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId));
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgIncident',  'inc_third_party', NULL, $Count, 6);
    
	-- ************
	DELETE FROM inc_third_party WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId);
    -- #
    
    
    -- Step7: incident
	SET $Count = (SELECT COUNT(*) FROM incident WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgIncident',  'incident', NULL, $Count, 7);
    
	-- ************
	DELETE FROM incident WHERE OrgId = $OrgId;
    -- #
    
    -- Step8: DONE
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgIncident', 'DONE', NULL, NULL, 8);
    -- # 
END;
