CREATE PROCEDURE ABCanTrackV2.InsertInto_hist_illness(IN `$IllnessId`         VARCHAR(100),
                                                      IN `$OldHistIllnessId`  VARCHAR(100),
                                                      IN `$OriginalIllnessId` VARCHAR(100),
                                                      IN `$UpdatedById`       VARCHAR(100))
  BEGIN
/*
DECLARE @PersonalAfflictedName, @RestrictedWorkName, @InitialTreatmentName, @SymptomsName, @ImpactTypeName, @ImpactSubTypeName, @IntEmployeeName1, @IntEmployeeDept1, @IntEmployeeName2, @IntEmployeeDept2, @IntEmployeeName3, @IntEmployeeDept3, @PrimRespondName, @UpdatedByName varchar(255) ;
DECLARE @IncidentId, @HistoryOperationId, @HistIncidentId varchar(100) ;
DECLARE @IllnessDescription, @OldIllnessDescription, @ExtAgencyName, @CustomOpenTxt, @OldCustomOpenTxt, @ImpactDescription, @OldImpactDescription  TEXT;
DECLARE @LostTimeStart, @LostTimeEnd, @UpdatedDate  DATETIME;
DECLARE @AdjustmentDays, @TotalDaysOff, @VersionNumber  INT;
DECLARE @EstimatedCost DECIMAL(10,2) ;
*/
SET  @UpdatedByName = (  select concat(firstname ,' ', lastname) from employee where employeeid = $UpdatedById ) ;
SET @PersonalAfflictedName = (  select personalafflictedname from illness where illnessid = $IllnessId );
SET @IncidentId = ( select incidentid from illness where IllnessId = $IllnessId  );
SET @RestrictedWorkName = (  select restrictedworkname from restricted_work where restrictedworkid = (select restrictedworkid from illness where illnessid = $IllnessId) );
SET @InitialTreatmentName = (  select initialtreatmentname from initial_treatment where initialtreatmentid = (select initialtreatmentid from illness where illnessid = $IllnessId) );
SET @SymptomsName = ( select group_concat(Description separator ' ;| ') from symptoms where symptomsid in (select symptomsid from illness_symptoms where illnessid = $IllnessId) );
SET @IllnessDescription = (  select illnessdescription from illness where illnessid = $IllnessId );
		if($OldHistIllnessId is null   or $OldHistIllnessId = '') then
			set $OriginalIllnessId= $IllnessId;
		SET  @OldIllnessDescription =( select concat(DATE_FORMAT(curdate(), '%b %d %Y'),' ', '(',@UpdatedByName,')',': ', ifnull((@IllnessDescription), '') ));
		else
		SET @OldIllnessDescription = ( select concat(DATE_FORMAT(curdate(), '%b %d %Y'),' ', '(',@UpdatedByName,')',': ', ifnull((@IllnessDescription), '') ,' <br><br> ', ifnull((OldIllnessDescription), '')) from hist_illness where histillnessid = $OldHistIllnessId);
		end if;
SET @LostTimeStart = ( select losttimestart from illness where illnessid = $IllnessId  );
SET @LostTimeEnd = (  select losttimeend from illness where illnessid = $IllnessId );
SET @AdjustmentDays = (  select adjustmentdays from illness where illnessid = $IllnessId );
SET @TotalDaysOff = (  select totaldaysoff from illness where illnessid = $IllnessId );
SET @ImpactTypeName = (select ImpactTypeName from impact_type where impacttypeid = (select impacttypeid from impact_sub_type where impactsubTypeid = (select impactsubtypeid from illness where illnessid = $IllnessId)));
SET @ImpactSubTypeName = (  select impactsubtypename from impact_sub_type where impactsubtypeid = (select ImpactSubTypeid from illness where illnessid = $IllnessId) );
SET @ExtAgencyName = ( select group_concat(ExtAgencyName separator' ;| ') from external_agency where ExtAgencyId in (select ExtAgencyId from impacts_ext_agency where illnessid = $IllnessId));
SET @IntEmployeeName1 = (  select IntEmployeeName1 from illness where illnessid = $IllnessId );
SET @IntEmployeeDept1 = (  select IntEmployeeDept1 from illness where illnessid = $IllnessId );
SET @IntEmployeeName2 = (  select IntEmployeeName2 from illness where illnessid = $IllnessId );
SET @IntEmployeeDept2 = (  select IntEmployeeDept2 from illness where illnessid = $IllnessId );
SET @IntEmployeeName3 = (  select IntEmployeeName3 from illness where illnessid = $IllnessId );
SET @IntEmployeeDept3 = (  select IntEmployeeDept3 from illness where illnessid = $IllnessId );
/*
SET @CustomOpenTxt = (  select CustomOpenTxt from illness where illnessid = $IllnessId );
		if($OldHistIllnessId is null) then
		SET  @OldCustomOpenTxt =( select concat(DATE_FORMAT(curdate(), '%b %d %Y'),' ', '(',@UpdatedByName,')',': ', ifnull((@CustomOpenTxt), '') ));
		else
		SET @OldCustomOpenTxt = ( select concat(DATE_FORMAT(curdate(), '%b %d %Y'),' ', '(',@UpdatedByName,')',': ', ifnull((@CustomOpenTxt), '') ,' <br><br> ', ifnull((OldCustomOpenTxt), '')) from hist_illness where histillnessid = $OldHistIllnessId);
		end if;
*/
SET @PrimRespondName = ( select primrespondname from illness where illnessid = $IllnessId  );
SET @ImpactDescription = (  select Description from illness where illnessid = $IllnessId );
		if($OldHistIllnessId is null) then
		SET  @OldImpactDescription =( select concat(DATE_FORMAT(curdate(), '%b %d %Y'),' ', '(',@UpdatedByName,')',': ', ifnull((@ImpactDescription), '') ));
		else
		SET @OldImpactDescription = ( select concat(DATE_FORMAT(curdate(), '%b %d %Y'),' ', '(',@UpdatedByName,')',': ', ifnull((@ImpactDescription), '') ,' <br><br> ', ifnull((OldImpactDescription), '')) from hist_illness where histillnessid = $OldHistIllnessId);
		END If;
SET @EstimatedCost = (  select estimatedcost from illness where illnessid = $IllnessId );
	SET @VersionNumber = (SELECT MAX(VersionNumber) FROM hist_incident WHERE IncidentId = @IncidentId);
	SET @HistIncidentId = (SELECT HistIncidentId FROM hist_incident WHERE IncidentId = @IncidentId AND VersionNumber = @VersionNumber);
	SET  @HistoryOperationId = (SELECT HistoryOperationId FROM hist_incident WHERE HistIncidentId = @HistIncidentId);
if($OriginalIllnessId is null  or $OriginalIllnessId='') then
set $OriginalIllnessId= $IllnessId;
END IF;
SET @UpdatedDate = current_timestamp();
INSERT INTO `hist_illness`
(
`HistIllnessId`,
`IllnessId`,
`PersonalAfflictedName`,
`IncidentId`,
`RestrictedWorkName`,
`InitialTreatmentName`,
`SymptomsName`,
`IllnessDescription`,
`OldIllnessDescription`,
`LostTimeStart`,
`LostTimeEnd`,
`AdjustmentDays`,
`TotalDaysOff`,
`ImpactTypeName`,
`ImpactSubTypeName`,
`ExtAgencyName`,
`IntEmployeeName1`,
`IntEmployeeDept1`,
`IntEmployeeName2`,
`IntEmployeeDept2`,
`IntEmployeeName3`,
`IntEmployeeDept3`,
-- `CustomOpenTxt`,
-- `OldCustomOpenTxt`,
`PrimRespondName`,
`ImpactDescription`,
`OldImpactDescription`,
`EstimatedCost`,
`HistoryOperationId`,
`UpdatedById`,
`UpdatedDate`,
`HistIncidentId`,
`OriginalIllnessId`
)
VALUES
(
MyUUID(),
$IllnessId,
@PersonalAfflictedName,
@IncidentId,
@RestrictedWorkName,
@InitialTreatmentName,
@SymptomsName,
@IllnessDescription,
@OldIllnessDescription,
@LostTimeStart,
@LostTimeEnd,
@AdjustmentDays,
@TotalDaysOff,
@ImpactTypeName,
@ImpactSubTypeName,
@ExtAgencyName,
@IntEmployeeName1,
@IntEmployeeDept1,
@IntEmployeeName2,
@IntEmployeeDept2,
@IntEmployeeName3,
@IntEmployeeDept3,
-- @CustomOpenTxt,
-- @OldCustomOpenTxt,
@PrimRespondName,
@ImpactDescription,
@OldImpactDescription,
@EstimatedCost,
@HistoryOperationId,
$UpdatedById,
@UpdatedDate,
@HistIncidentId,
$OriginalIllnessId
)
;
END;
