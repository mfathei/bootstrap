CREATE PROCEDURE ABCanTrackV2.DeleteFrom_corrective_action_Tables(IN `$IncidentId` VARCHAR(100))
  BEGIN
DECLARE fetch_status int default 0;
DECLARE $CorrectiveActionId varchar(100);
DECLARE incident_cursor CURSOR FOR 
select CorrectiveActionId from corrective_action where incidentid = $IncidentId;
DECLARE CONTINUE HANDLER FOR NOT FOUND SET fetch_status = 100;
Open Incident_cursor;
FETCH NEXT FROM incident_cursor 
		INTO $CorrectiveActionId;
WHILE fetch_status = 0
			do
delete from corrective_action_notified where CorrectiveActionId = $CorrectiveActionId;
FETCH NEXT FROM incident_cursor 
			INTO $CorrectiveActionId;
		END while;
	CLOSE incident_cursor;
delete from corrective_action where incidentid = $incidentid;
END;
