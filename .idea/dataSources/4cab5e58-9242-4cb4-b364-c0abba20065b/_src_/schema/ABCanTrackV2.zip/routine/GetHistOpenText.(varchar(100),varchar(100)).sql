CREATE PROCEDURE ABCanTrackV2.GetHistOpenText(IN `$IncidentId` VARCHAR(100), IN `$FieldName` VARCHAR(100))
  BEGIN
SET SESSION group_concat_max_len = 10000;

set @qry = concat("select (   group_concat(DATE_FORMAT(UpdatedDate, '%b %d %Y') ,' ', '(',  concat(firstname ,' ', lastname) ,')',': <pr>', ", $FieldName," separator '<br><br>' ) ) as IncDescription   
 into @newDescription 
 from(
 select UpdatedDate, ", $FieldName,", firstname,lastname FROM hist_incident hi 
join employee e on e.EmployeeId = hi.UpdatedbyId
 where IncidentId = '", $IncidentId , "'  
order by UpdatedDate asc  ) temp ; ");
 
 -- select  @qry;
PREPARE stmt FROM @qry;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
 
END;
