CREATE PROCEDURE ABCanTrackV2.InsertObserAnaParamTrigger2(IN `$Code1` VARCHAR(255), IN `$LangId` VARCHAR(100),
                                                          IN `$OldId` VARCHAR(100))
  BEGIN
DECLARE $Min_i, $Max_i, $ParentId, $CurId, $OldId VARCHAR(100);
DECLARE $OATypeCode, $ParentName VARCHAR(255);
-- SET $OATypeCode = (SELECT ObservationAndAnalysisCode FROM ABCanTrackV2.observation_analysis WHERE ObservationAndAnalysisId = $OATypeId);
SET $CurId = (SELECT ObservationAndAnalysisId FROM ABCanTrackV2.observation_analysis WHERE ObservationAndAnalysisCode = $Code1 AND OrgId IS NULL AND LanguageId = $LangId);
SET $OldId = (SELECT ObservationAndAnalysisId FROM ABCanTrackV2.observation_analysis WHERE ObservationAndAnalysisCode = $Code1 AND OrgId IS NULL AND LanguageId = GetLanguageId('en'));
-- select $CurId,$OldId;
	INSERT INTO `ABCanTrackV2`.`observation_analysis_param`
	(
        `FieldCode`,
	    `LanguageId`,
		`ObservationAndAnalysisId`,
		`ObservationAndAnalysisParamName`,
		`ObservationAndAnalysisParamDetails`,
		`Order`,
		`IsMulti`,
		`ParentId`,
		`LastUpdateDate`,
		`EditingBy`,
		`Hide`
	)
	SELECT
        `FieldCode`,
	    $LangId,
		$CurId,
		`ObservationAndAnalysisParamName`,
		`ObservationAndAnalysisParamDetails`,
		`Order`,
		`IsMulti`,
		`ParentId`,
		CURRENT_TIMESTAMP(),
		`EditingBy`,
		`Hide`
	FROM  `ABCanTrackV2`.`observation_analysis_param`
	WHERE ObservationAndAnalysisId = $OldId AND `ParentId` IS NULL AND LanguageId = GetLanguageId('en');
	
	SET $Min_i = (SELECT MIN(ObservationAndAnalysisParamId) FROM `ABCanTrackV2`.`observation_analysis_param` WHERE ObservationAndAnalysisId = $OldId AND LanguageId = GetLanguageId('en') );
	SET $Max_i = (SELECT MAX(ObservationAndAnalysisParamId) FROM `ABCanTrackV2`.`observation_analysis_param` WHERE ObservationAndAnalysisId = $OldId AND LanguageId = GetLanguageId('en') );
	ParentLoop: WHILE $Min_i <= $Max_i
	DO
		-- SET $ParentName = (SELECT `ObservationAndAnalysisParamName` FROM `ABCanTrackV2`.`observation_analysis_param` WHERE ObservationAndAnalysisParamId = $Min_i AND LanguageId = GetLanguageId('en'));
		SET $ParentId = (SELECT ObservationAndAnalysisParamId FROM `ABCanTrackV2`.`observation_analysis_param` WHERE ObservationAndAnalysisId = $OldId AND ObservationAndAnalysisParamName in (SELECT `ObservationAndAnalysisParamName` FROM `ABCanTrackV2`.`observation_analysis_param` WHERE ObservationAndAnalysisParamId = $Min_i AND LanguageId = GetLanguageId('en')) AND LanguageId = GetLanguageId('en'));
		INSERT INTO `ABCanTrackV2`.`observation_analysis_param`
		(
			`FieldCode`,
			`LanguageId`,
			`ObservationAndAnalysisId`,
			`ObservationAndAnalysisParamName`,
			`ObservationAndAnalysisParamDetails`,
			`Order`,
			`IsMulti`,
			`ParentId`,
			`LastUpdateDate`,
			`EditingBy`,
			`Hide`
		)
		SELECT
        	`FieldCode`,
			$LangId,
			$CurId,
			`ObservationAndAnalysisParamName`,
			`ObservationAndAnalysisParamDetails`,
			`Order`,
			`IsMulti`,
			$Min_i,
			CURRENT_TIMESTAMP(),
			`EditingBy`,
			`Hide`
		FROM  `ABCanTrackV2`.`observation_analysis_param`
		WHERE ObservationAndAnalysisId = $OldId AND `ParentId` = $ParentId AND LanguageId = GetLanguageId('en');
		IF $Min_i = $Max_i
		THEN
			LEAVE ParentLoop;
		ELSE
			SET $Min_i = (SELECT MIN(ObservationAndAnalysisParamId) FROM `ABCanTrackV2`.`observation_analysis_param` WHERE ObservationAndAnalysisId = $OldId AND ObservationAndAnalysisParamId > $Min_i AND ParentId IS NULL AND LanguageId = GetLanguageId('en'));
		END IF;
	END WHILE;
    
END;
