CREATE PROCEDURE ABCanTrackV2.InsertInto_hist_traffic_violation(IN `$TrafficViolationId`         VARCHAR(100),
                                                                IN `$OldTrafficViolationId`      VARCHAR(100),
                                                                IN `$OriginalTrafficViolationId` VARCHAR(100),
                                                                IN `$UpdatedById`                VARCHAR(100))
  BEGIN
/*
DECLARE @IncidentId  varchar(100) ;
DECLARE @DriverName  varchar(255) ;
DECLARE @DriverLicence  varchar(255) ;
DECLARE @VehicleTypeName  varchar(255) ; 
DECLARE @VehicleLicence   varchar(255);
DECLARE @Details  TEXT ;
DECLARE @OldDetails TEXT ;
DECLARE @ValueOfFine  DECIMAL(10,2) ;
DECLARE @TicketNumber  varchar(255) ;
DECLARE @HowDidThatOccur  TEXT ;
DECLARE @OldHowDidThatOccur TEXT ;
DECLARE @ImpactTypeName varchar(255);
DECLARE @ImpactSubTypeName  varchar(255) ;
DECLARE @ExtAgencyName  varchar(255) ;
DECLARE @IntEmployeeName1  varchar(255) ;
DECLARE @IntEmployeeDept1  varchar(255) ;
DECLARE @IntEmployeeName2  varchar(255) ;
DECLARE @IntEmployeeDept2  varchar(255) ;
DECLARE @IntEmployeeName3  varchar(255) ;
DECLARE @IntEmployeeDept3  varchar(255) ;
DECLARE @CustomOpenTxt  TEXT ;
DECLARE @OldCustomOpenTxt TEXT;
DECLARE @PrimRespondName  varchar(255) ;
DECLARE @ImpactDescription  TEXT ;
DECLARE @OldImpactDescription TEXT;
DECLARE @EstimatedCost  DECIMAL(10,2) ;
DECLARE @HistoryOperationId  varchar(100) ;
DECLARE @UpdatedDate  DATETIME ;
DECLARE @UpdatedByName varchar(255) ;
DECLARE @HistIncidentId varchar(100);
DECLARE @VersionNumber INT;
*/
SET  @UpdatedByName = (  select concat(firstname ,' ', lastname) from employee where employeeid = $UpdatedById ) ;
SET @IncidentId  = ( select incidentid from  traffic_violation where TrafficViolationId = $TrafficViolationId );
SET @DriverName  = ( select DriverName from  traffic_violation where TrafficViolationId = $TrafficViolationId  );
SET @DriverLicence  = ( select DriverLicence from  traffic_violation where TrafficViolationId = $TrafficViolationId  );
SET @VehicleTypeName = ( select VehicleTypeName from  vehicle_type where VehicleTypeId = ( select VehicleTypeId from traffic_violation where TrafficViolationId =  $TrafficViolationId)  );
SET @VehicleLicence  = ( select VehicleLicence from  traffic_violation where TrafficViolationId = $TrafficViolationId  );
SET @Details  = ( select Details from  traffic_violation where TrafficViolationId = $TrafficViolationId  );
if($OldTrafficViolationId is null    or $OldTrafficViolationId = '') then
set $OriginalTrafficViolationId = $TrafficViolationId ;
SET  @OldDetails =( select concat(DATE_FORMAT(curdate(), '%b %d %Y'),' ', '(',@UpdatedByName,')',': ', ifnull((@Details), '') ));
ELSE
SET @OldDetails = ( select concat(DATE_FORMAT(curdate(), '%b %d %Y'),' ', '(',@UpdatedByName,')',': ', ifnull((@Details), '') ,' <br><br> ', ifnull((OldDetails), '')) from hist_traffic_violation where TrafficViolationId = $OldTrafficViolationId limit 1);
END IF;
SET @ValueOfFine  = ( select ValueOfFine from  traffic_violation where TrafficViolationId = $TrafficViolationId  );
SET @TicketNumber  = ( select TicketNumber from  traffic_violation where TrafficViolationId = $TrafficViolationId  );
SET @HowDidThatOccur  = ( select HowDidThatOccur from  traffic_violation where TrafficViolationId = $TrafficViolationId  );
if($OldTrafficViolationId is null) then
SET  @OldHowDidThatOccur =( select concat(DATE_FORMAT(curdate(), '%b %d %Y'),' ', '(',@UpdatedByName,')',': ', ifnull((@HowDidThatOccur), '') ));
ELSE
SET @OldHowDidThatOccur = ( select concat(DATE_FORMAT(curdate(), '%b %d %Y'),' ', '(',@UpdatedByName,')',': ', ifnull((@HowDidThatOccur), '') ,' <br><br> ', ifnull((OldHowDidThatOccur), '')) from hist_traffic_violation where TrafficViolationId = $OldTrafficViolationId limit 1);
END IF;
if($OriginalTrafficViolationId is null or $OriginalTrafficViolationId = '') then
set $OriginalTrafficViolationId = $TrafficViolationId ;
END IF;
SET @ImpactTypeName = (select ImpactTypeName from impact_type where impacttypeid = (select impacttypeid from impact_sub_type where impactsubTypeid = (select impactsubtypeid from  traffic_violation where TrafficViolationId = $TrafficViolationId)));
SET @ImpactSubTypeName = (  select ImpactSubTypeName from impact_sub_type where impactsubtypeid = (select ImpactSubTypeid from  traffic_violation where TrafficViolationId = $TrafficViolationId) );
SET @ExtAgencyName = ( select group_concat(ExtAgencyName separator' ;| ') from external_agency where ExtAgencyId in (select ExtAgencyId from impacts_ext_agency where TrafficViolationId = $TrafficViolationId));
SET @IntEmployeeName1 = (  select IntEmployeeName1 from  traffic_violation where TrafficViolationId = $TrafficViolationId );
SET @IntEmployeeDept1 = (  select IntEmployeeDept1 from  traffic_violation where TrafficViolationId = $TrafficViolationId );
SET @IntEmployeeName2 = (  select IntEmployeeName2 from  traffic_violation where TrafficViolationId = $TrafficViolationId );
SET @IntEmployeeDept2 = (  select IntEmployeeDept2 from  traffic_violation where TrafficViolationId = $TrafficViolationId );
SET @IntEmployeeName3 = (  select IntEmployeeName3 from  traffic_violation where TrafficViolationId = $TrafficViolationId );
SET @IntEmployeeDept3 = (  select IntEmployeeDept3 from  traffic_violation where TrafficViolationId = $TrafficViolationId );
-- SET @CustomOpenTxt = (  select CustomOpenTxt from  traffic_violation where TrafficViolationId = $TrafficViolationId );
/*
if($OldTrafficViolationId is null) then
SET  @OldCustomOpenTxt =( select concat(DATE_FORMAT(curdate(), '%b %d %Y'),' ', '(',@UpdatedByName,')',': ', ifnull((@CustomOpenTxt), '') ));
ELSE
SET @OldCustomOpenTxt = ( select concat(DATE_FORMAT(curdate(), '%b %d %Y'),' ', '(',@UpdatedByName,')',': ', ifnull((@CustomOpenTxt), '') ,' <br><br> ', ifnull((OldCustomOpenTxt), '')) from hist_traffic_violation where TrafficViolationId = $OldTrafficViolationId limit 1);
END IF;
*/
SET @PrimRespondName = ( select primrespondname from  traffic_violation where TrafficViolationId = $TrafficViolationId  );
SET @ImpactDescription = (  select description from  traffic_violation where TrafficViolationId = $TrafficViolationId );
IF($OldTrafficViolationId is null) then
SET  @OldImpactDescription =( select concat(DATE_FORMAT(curdate(), '%b %d %Y'),' ', '(',@UpdatedByName,')',': ', ifnull((@ImpactDescription), '') ));
ELSE
SET @OldImpactDescription = ( select concat(DATE_FORMAT(curdate(), '%b %d %Y'),' ', '(',@UpdatedByName,')',': ', ifnull((@ImpactDescription), '') ,' <br><br> ', ifnull((OldImpactDescription), '')) from hist_traffic_violation where TrafficViolationId = $OldTrafficViolationId limit 1);
END IF;
SET @EstimatedCost = (  select estimatedcost from  traffic_violation where TrafficViolationId = $TrafficViolationId );
SET @VersionNumber = (SELECT MAX(VersionNumber) FROM hist_incident WHERE IncidentId = @IncidentId);
SET @HistIncidentId = (SELECT HistIncidentId FROM hist_incident WHERE IncidentId = @IncidentId AND VersionNumber = @VersionNumber);
SET @HistoryOperationId = (SELECT HistoryOperationId FROM hist_incident WHERE HistIncidentId = @HistIncidentId);
SET @UpdatedDate = CURRENT_TIMESTAMP();
INSERT INTO `hist_traffic_violation`
(
`HistTrafficViolationId`,
`TrafficViolationId`,
`IncidentId`,
`DriverName`,
`DriverLicence`,
`VehicleTypeName`,
`VehicleLicence`,
`Details`,
`OldDetails`,
`ValueOfFine`,
`TicketNumber`,
`HowDidThatOccur`,
`OldHowDidThatOccur`,
`ImpactTypeName`,
`ImpactSubTypeName`,
`ExtAgencyName`,
`IntEmployeeName1`,
`IntEmployeeDept1`,
`IntEmployeeName2`,
`IntEmployeeDept2`,
`IntEmployeeName3`,
`IntEmployeeDept3`,
-- `CustomOpenTxt`,
-- `OldCustomOpenTxt`,
`PrimRespondName`,
`ImpactDescription`,
`OldImpactDescription`,
`EstimatedCost`,
`HistoryOperationId`,
`UpdatedById`,
`UpdatedDate`,
`HistIncidentId`,
`OriginalTrafficViolationId`
)
VALUES
(
MyUUID(),
$TrafficViolationId,
@IncidentId,
@DriverName,
@DriverLicence,
@VehicleTypeName,
@VehicleLicence,
@Details,
@OldDetails,
@ValueOfFine,
@TicketNumber,
@HowDidThatOccur,
@OldHowDidThatOccur,
@ImpactTypeName,
@ImpactSubTypeName,
@ExtAgencyName,
@IntEmployeeName1,
@IntEmployeeDept1,
@IntEmployeeName2,
@IntEmployeeDept2,
@IntEmployeeName3,
@IntEmployeeDept3,
-- @CustomOpenTxt,
-- @OldCustomOpenTxt,
@PrimRespondName,
@ImpactDescription,
@OldImpactDescription,
@EstimatedCost,
@HistoryOperationId,
$UpdatedById,
@UpdatedDate,
@HistIncidentId,
$OriginalTrafficViolationId
);
end;
