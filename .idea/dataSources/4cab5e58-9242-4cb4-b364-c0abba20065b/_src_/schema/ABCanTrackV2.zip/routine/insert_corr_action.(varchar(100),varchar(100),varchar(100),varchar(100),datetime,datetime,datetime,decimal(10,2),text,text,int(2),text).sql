CREATE PROCEDURE ABCanTrackV2.insert_corr_action(IN `$IncidentId`      VARCHAR(100), IN `$CorrActStatusId` VARCHAR(100),
                                                 IN `$PriorityId`      VARCHAR(100), IN `$AssignedToId` VARCHAR(100),
                                                 IN `$StartDate`       DATETIME, IN `$TargetEndDate` DATETIME,
                                                 IN `$ActualEndDate`   DATETIME, IN `$EstimatedCost` DECIMAL(10, 2),
                                                 IN `$TaskDescription` TEXT, IN `$OutComeFollowUp` TEXT,
                                                 IN `$DesiredResults`  INT(2), IN `$Comments` TEXT)
  BEGIN
	
 
INSERT INTO corrective_action
				(CorrectiveActionId, IncidentId,CorrActStatusId,PriorityId,AssignedToId,StartDate,TargetEndDate,
				ActualEndDate,EstimatedCost,TaskDescription,OutComeFollowUp,DesiredResults,Comments)
			VALUES
				('', $IncidentId,$CorrActStatusId,$PriorityId,$AssignedToId,$StartDate,$TargetEndDate,
				$ActualEndDate,$EstimatedCost,$TaskDescription, $OutComeFollowUp, $DesiredResults, $Comments);
			
 select @session_corr_id as CorrectiveActionId;
END;
