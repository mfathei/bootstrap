CREATE PROCEDURE ABCanTrackV2.InsertInto_hist_people_involved(IN `$PeopleInvolvedId`         VARCHAR(100),
                                                              IN `$OldPeopleInvolvedId`      VARCHAR(100),
                                                              IN `$OriginalPeopleInvolvedId` VARCHAR(100),
                                                              IN `$UpdatedById`              VARCHAR(100))
  BEGIN
/* 
DECLARE @IncidentId  varchar(100) ;
DECLARE @PeopleInvolvedName  varchar(255) ;
DECLARE @CertificateName  varchar(255) ;
DECLARE @Company  varchar(255) ;
DECLARE @Position  varchar(255) ;
DECLARE @Email  varchar(255) ;
DECLARE @PrimaryPhone  varchar(255) ;
DECLARE @AlternatePhone  varchar(255) ;
DECLARE @ExpInCurrentPostion  INT ;
DECLARE @ExpOverAll  INT ;
DECLARE @HowHeInvolved  TEXT ;
DECLARE @RoleDescription  TEXT ;
DECLARE @OldRoleDescription  TEXT ;
DECLARE @HistoryOperationId  varchar(100) ;
DECLARE @UpdatedDate  DATETIME ;
DECLARE @UpdatedByName varchar(255) ;
DECLARE @HistIncidentId varchar(100);
DECLARE @VersionNumber INT;
*/
SET  @UpdatedByName = (  SELECT CONCAT(firstname ,' ', lastname) FROM employee WHERE employeeid = $UpdatedById ) ;
SET  @IncidentId  = ( SELECT incidentid FROM people_involved WHERE PeopleInvolvedId = $PeopleInvolvedId );
SET  @PeopleInvolvedName  = ( SELECT PeopleInvolvedName FROM people_involved WHERE PeopleInvolvedId = $PeopleInvolvedId );
SET  @Age  = ( SELECT Age FROM people_involved WHERE PeopleInvolvedId = $PeopleInvolvedId );
SET  @CertificateName  = ( SELECT GROUP_CONCAT(CertificateName SEPARATOR ' ;| ') FROM certificate WHERE certificateid IN (SELECT certificateid FROM have_certificate WHERE peopleinvolvedid = $PeopleInvolvedId));
SET  @Company  = ( SELECT company FROM people_involved WHERE PeopleInvolvedId = $PeopleInvolvedId  );
SET  @Position  = ( SELECT POSITION FROM people_involved WHERE PeopleInvolvedId = $PeopleInvolvedId );
SET  @Email  = ( SELECT Email FROM people_involved WHERE PeopleInvolvedId = $PeopleInvolvedId );
SET  @PrimaryPhone  = ( SELECT PrimaryPhone FROM people_involved WHERE PeopleInvolvedId = $PeopleInvolvedId );
SET  @AlternatePhone  = ( SELECT AlternatePhone FROM people_involved WHERE PeopleInvolvedId = $PeopleInvolvedId );
SET  @ExpInCurrentPostion  = ( SELECT ExpInCurrentPostion FROM people_involved WHERE PeopleInvolvedId = $PeopleInvolvedId );
SET  @ExpOverAll  = ( SELECT ExpOverAll FROM people_involved WHERE PeopleInvolvedId = $PeopleInvolvedId );
SET  @HowHeInvolved  = ( SELECT HowHeInvolved FROM people_involved WHERE PeopleInvolvedId = $PeopleInvolvedId );
SET @RoleDescription =  ( SELECT RoleDescription FROM people_involved WHERE PeopleInvolvedId = $PeopleInvolvedId );
IF($OldPeopleInvolvedId IS NULL ) THEN
SET  @OldRoleDescription =( SELECT CONCAT(DATE_FORMAT(CURDATE(), '%b %d %Y'),' ', '(',@UpdatedByName,')',': ', IFNULL((@RoleDescription), '') ));
SET $OriginalPeopleInvolvedId = $PeopleInvolvedId ;
ELSE
SET  @OldRoleDescription = ( SELECT CONCAT(DATE_FORMAT(CURDATE(), '%b %d %Y'),' ', '(',@UpdatedByName,')',': ', IFNULL((@RoleDescription), '') ,' <br><br> ', IFNULL((OldRoleDescription), '')) FROM hist_people_involved WHERE PeopleInvolvedId = $OldPeopleInvolvedId LIMIT 1);
END IF;
IF($OriginalPeopleInvolvedId IS NULL  OR $OriginalPeopleInvolvedId='') THEN
SET $OriginalPeopleInvolvedId = $PeopleInvolvedId ;
END IF;
	SET @VersionNumber = (SELECT MAX(VersionNumber) FROM hist_incident WHERE IncidentId = @IncidentId);
	SET @HistIncidentId = (SELECT HistIncidentId FROM hist_incident WHERE IncidentId = @IncidentId AND VersionNumber = @VersionNumber);
	SET @HistoryOperationId = (SELECT HistoryOperationId FROM hist_incident WHERE HistIncidentId = @HistIncidentId);
SET  @UpdatedDate  = CURRENT_TIMESTAMP();
INSERT INTO `hist_people_involved`
(
`HistPeopleInvolvedId`,
`PeopleInvolvedId`,
`IncidentId`,
`PeopleInvolvedName`,
`Age`,
`CertificateName`,
`Company`,
`Position`,
`Email`,
`PrimaryPhone`,
`AlternatePhone`,
`ExpInCurrentPostion`,
`ExpOverAll`,
`HowHeInvolved`,
`RoleDescription`,
`OldRoleDescription`,
`HistoryOperationId`,
`UpdatedById`,
`UpdatedDate`,
`HistIncidentId`,
`OriginalPeopleInvolvedId`
)
VALUES
(
MyUUID(),
$PeopleInvolvedId,
@IncidentId,
@PeopleInvolvedName,
@Age,
@CertificateName,
@Company,
@Position,
@Email,
@PrimaryPhone,
@AlternatePhone,
@ExpInCurrentPostion,
@ExpOverAll,
@HowHeInvolved,
@RoleDescription,
@OldRoleDescription,
@HistoryOperationId,
$UpdatedById,
@UpdatedDate,
@HistIncidentId,
$OriginalPeopleInvolvedId
);
END;
