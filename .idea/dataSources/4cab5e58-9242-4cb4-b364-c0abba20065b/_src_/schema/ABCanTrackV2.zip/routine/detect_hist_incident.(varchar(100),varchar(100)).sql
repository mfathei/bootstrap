CREATE PROCEDURE ABCanTrackV2.detect_hist_incident(IN pIncidentId VARCHAR(100), IN lCorrectiveActionId VARCHAR(100))
  BEGIN
DECLARE p_finished INTEGER DEFAULT 0;
-- ----------------------------
DECLARE vHistCorrectiveActionId VARCHAR(100);
DECLARE vCorrectiveActionId VARCHAR(100);
DECLARE vOriginalCorrectiveActionId VARCHAR(100);
DECLARE vIncidentId VARCHAR(100);
DECLARE vStatusName VARCHAR(255);
DECLARE vPriorityName VARCHAR(255);
DECLARE vAssignedToName VARCHAR(255);
DECLARE vAlsoNotifyName VARCHAR(255);
DECLARE vStartDate DATE;
DECLARE vTargetEndDate DATE;
DECLARE vActualEndDate DATE;
DECLARE vEstimatedCost DECIMAL(10,2);
DECLARE vDescription TEXT;
DECLARE vOldDescription TEXT;
DECLARE vOutComeFollowUp TEXT;
DECLARE vOldOutComeFollowUp TEXT;
DECLARE vDesiredResults BIT(1);
DECLARE vComments TEXT;
DECLARE vOldComments TEXT;
DECLARE vAssignedByName VARCHAR(255);
DECLARE vHistoryOperationId VARCHAR(100);
DECLARE vUpdatedById VARCHAR(100);
DECLARE vUpdatedDate DATETIME;
DECLARE vHistIncidentId VARCHAR(100);
-- ----------------------------
DECLARE vMaxHistIncidentId VARCHAR(100);
DECLARE vPreMaxHistIncidentId VARCHAR(100);
DECLARE lCorrectiveActionId VARCHAR(100);
-- ----------------------------
DECLARE nHistCorrectiveActionId VARCHAR(100);
DECLARE nCorrectiveActionId VARCHAR(100);
DECLARE nOriginalCorrectiveActionId VARCHAR(100);
DECLARE nIncidentId VARCHAR(100);
DECLARE nStatusName VARCHAR(255);
DECLARE nPriorityName VARCHAR(255);
DECLARE nAssignedToName VARCHAR(255);
DECLARE nAlsoNotifyName VARCHAR(255);
DECLARE nStartDate DATE;
DECLARE nTargetEndDate DATE;
DECLARE nActualEndDate DATE;
DECLARE nEstimatedCost DECIMAL(10,2);
DECLARE nDescription TEXT;
DECLARE nOldDescription TEXT;
DECLARE nOutComeFollowUp TEXT;
DECLARE nOldOutComeFollowUp TEXT;
DECLARE nDesiredResults BIT(1);
DECLARE nComments TEXT;
DECLARE nOldComments TEXT;
DECLARE nAssignedByName VARCHAR(255);
DECLARE nHistoryOperationId VARCHAR(100);
DECLARE nUpdatedById VARCHAR(100);
DECLARE nUpdatedDate DATETIME;
DECLARE nHistIncidentId VARCHAR(100);
-- ----------------------------
 DECLARE p_cursor CURSOR FOR
 SELECT `CorrectiveActionId` FROM `corrective_action` WHERE IncidentId = pIncidentId;
 -- declare NOT FOUND handler
 DECLARE CONTINUE HANDLER FOR NOT FOUND SET p_finished = 1;
 
SET @result = ''; 
    
 OPEN p_cursor;
ex: LOOP
	FETCH p_cursor INTO lCorrectiveActionId;
	IF p_finished = 1 THEN 
		LEAVE ex;
	END IF;
	SET vMaxHistIncidentId = (SELECT MAX(HistIncidentId) FROM hist_corrective_action WHERE IncidentId = pIncidentId AND OriginalCorrectiveActionId = lCorrectiveActionId);
	SET vPreMaxHistIncidentId = (SELECT MAX(HistIncidentId) FROM hist_corrective_action WHERE IncidentId = pIncidentId AND OriginalCorrectiveActionId = lCorrectiveActionId AND HistIncidentId < vMaxHistIncidentId);
	
	SELECT * INTO vHistCorrectiveActionId,vCorrectiveActionId,vOriginalCorrectiveActionId,vIncidentId,vStatusName,vPriorityName,vAssignedToName,vAlsoNotifyName,vStartDate,vTargetEndDate,vActualEndDate,vEstimatedCost,vDescription,vOldDescription,vOutComeFollowUp,vOldOutComeFollowUp,vDesiredResults,vComments,vOldComments,vAssignedByName,vHistoryOperationId,vUpdatedById,vUpdatedDate,vHistIncidentId
	FROM hist_corrective_action WHERE IncidentId = pIncidentId AND OriginalCorrectiveActionId = lCorrectiveActionId AND HistIncidentId = vMaxHistIncidentId;
	
	SELECT * INTO nHistCorrectiveActionId,nCorrectiveActionId,nOriginalCorrectiveActionId,nIncidentId,nStatusName,nPriorityName,nAssignedToName,nAlsoNotifyName,nStartDate,nTargetEndDate,nActualEndDate,nEstimatedCost,nDescription,nOldDescription,nOutComeFollowUp,nOldOutComeFollowUp,nDesiredResults,nComments,nOldComments,nAssignedByName,nHistoryOperationId,nUpdatedById,nUpdatedDate,nHistIncidentId
	FROM hist_corrective_action WHERE IncidentId = pIncidentId AND OriginalCorrectiveActionId = lCorrectiveActionId AND HistIncidentId = vPreMaxHistIncidentId;
    
    IF 
      --   vOriginalCorrectiveActionId != nOriginalCorrectiveActionId 
       --  OR vIncidentId != nIncidentId 
     vStatusName != nStatusName 
    OR vPriorityName != nPriorityName 
    OR vAssignedToName != nAssignedToName 
    OR vAlsoNotifyName != nAlsoNotifyName 
    OR vStartDate != nStartDate 
    OR vTargetEndDate != nTargetEndDate 
    OR vActualEndDate != nActualEndDate 
    OR vEstimatedCost != nEstimatedCost 
    OR vDescription != nDescription 
       --  OR vOldDescription != nOldDescription 
    OR vOutComeFollowUp != nOutComeFollowUp 
        -- OR vOldOutComeFollowUp != nOldOutComeFollowUp 
    OR vDesiredResults != nDesiredResults 
    OR vComments != nComments 
      --   OR vOldComments != nOldComments 
    OR vAssignedByName != nAssignedByName 
    -- OR vHistoryOperationId != nHistoryOperationId 
    -- OR vUpdatedById != nUpdatedById 
    -- OR vUpdatedDate != nUpdatedDate 
    -- OR vHistIncidentId != nHistIncidentId 
    THEN 
        if @result = '' then
            SET @result = CONCAT(@result, lCorrectiveActionId) ;
        else
            SET @result = CONCAT(@result, ',', lCorrectiveActionId) ;
        end if;
    END IF ;
	
END LOOP ex;
CLOSE p_cursor;
SELECT @result;
END;
