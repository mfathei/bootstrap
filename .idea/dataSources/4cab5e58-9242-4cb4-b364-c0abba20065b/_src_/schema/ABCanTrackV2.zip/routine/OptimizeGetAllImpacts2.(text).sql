CREATE PROCEDURE ABCanTrackV2.OptimizeGetAllImpacts2(IN xmlData TEXT)
  BEGIN 
-- ========================================================================
-- Reviewed and altered by AbdulRahman Shamsan.
-- ========================================================================
-- Custom fields parameters
DECLARE $ids TEXT;
DECLARE $FieldId VARCHAR(100);
-- #
-- Parameters to check the existance of Custom fields.
DECLARE $InjuryFound, $IllnessFound, $SpillReleaseFound, $VehicleDamageFound, $TrafficViolationFound BOOLEAN;
SET $InjuryFound = FALSE, $IllnessFound = FALSE, $SpillReleaseFound = FALSE, $VehicleDamageFound = FALSE, $TrafficViolationFound = FALSE;
-- #
SET @OrgId = extractvalue(xmlData, '//OrgId');
SET @page = extractvalue(xmlData, '//page');
SET @limit = extractvalue(xmlData, '//limit');
SET @sortOrder =  extractvalue(xmlData, '//sortOrder');
SET @index =  extractvalue(xmlData, '//index');
SET @Mine =  extractvalue(xmlData, '//Mine');
SET @CreatorId = extractvalue(xmlData, '//CreatorId');
SET @Export =  extractvalue(xmlData, '//Export');
-- ========================================================================
-- Default select statment: BEGIN
-- ========================================================================
-- Default select clause
set @selectquery ="
SELECT  
SQL_CALC_FOUND_ROWS
incident_IncidentId, 
incident_IncidentNumber, 
date_format(incident_IncidentDate,'%m/%d/%Y') as IncidentDate,
incident_EditingBy, incident_EditingBy as LockedId,
incident_OtherLocation,
all_impact_types_ImpactId, 
all_impact_types_ImpactTypeName as ImpactTypeId,
all_impact_types_ImpactTypeCode ,
all_impact_types_ImpactSubTypeName as ImpactSubTypeId,
all_impact_types_IntEmployeeName1 ,
all_impact_types_IntEmployeeName2  ,
all_impact_types_IntEmployeeName3  ,
all_impact_types_IntEmployeeDept1 ,
all_impact_types_IntEmployeeDept2 ,
all_impact_types_IntEmployeeDept3  ,
all_impact_types_CustomOpenTxt ,
all_impact_types_PrimRespondName,
all_impact_types_Description as ImpactDescription ,
all_impact_types_EstimatedCost as ImpactEstimatedCost,
all_impact_types_ExtAgencyName as ExtAgencyId, 
all_impact_types_Identification ";
-- Default from clause
set @queryFrom = " from all_impact_types inner join incident  on incident.IncidentId = all_impact_types.IncidentId  ";
-- #
-- Default have clause
SET @queryhave = ' having 1 = 1  ';
-- #
-- Default where clause
SET @queryWhere = ' where 1= 1 ';
-- #
-- Custom Fields Part
SET $ids = extractvalue(xmlData, '//FieldNamesIds');
SET @Postition = LOCATE(',', $ids);
WHILE ( @Postition > 0 ) DO
	SET @STR = SUBSTRING($ids, 1, @Postition-1);
	SET $ids  = SUBSTRING($ids, @Postition + 1);
	set  @STR = TRIM(@STR);
    SET $FieldId = (SELECT FieldId FROM ABCanTrackV2.field where FieldName = @STR and Orgid=@OrgId );
       
        if ((SELECT INSTR( @STR , 'Impacts') > 0)) THEN          
	-- Impact custom fields
		-- Calendar
			   if ((SELECT INSTR( @STR , 'calendar') > 0)) THEN 
					SET @selectquery = CONCAT(@selectquery , ', (select FieldValue from field_value tbl1
							where tbl1.TableKeyId = all_impact_types_ImpactId and tbl1.FieldId ="', $FieldId,'"   limit 1) as `',@STR,'`');	
		-- Textbox
				elseif ((SELECT INSTR( @STR , 'textbox') > 0)) THEN 
					SET @selectquery = CONCAT(@selectquery , ',    (select FieldValue from field_value tbl1
						where  tbl1.TableKeyId = all_impact_types_ImpactId and tbl1.FieldId ="', $FieldId,'"   limit 1) as `',@STR,'`');	
		-- Textarea
				elseif ((SELECT INSTR( @STR , 'textarea') > 0)) THEN 
					SET @selectquery = CONCAT(@selectquery , ',    (select FieldValue from field_value tbl1
							where  tbl1.TableKeyId = all_impact_types_ImpactId  and tbl1.FieldId ="', $FieldId,'"   limit 1) as `',@STR,'`');	
		-- Other types
				else    
					SET @selectquery = CONCAT(@selectquery , ',   (select group_concat(tbl3.OptionName separator ', ') from field_value tbl1
					inner join `option` tbl3
					on tbl1.OptionId = tbl3.OptionId
					 where  tbl1.TableKeyId = all_impact_types_ImpactId and tbl1.FieldId ="', $FieldId,'") as `',@STR,'`');	
				
				END IF;  
	  elseif ((SELECT INSTR( @STR , 'Injury') > 0)) THEN          
       
       set $InjuryFound = TRUE; 
       
	-- Injury custom fields
		-- Calendar       
			   if ((SELECT INSTR( @STR , 'calendar') > 0)) THEN 
					SET @selectquery = CONCAT(@selectquery , ', (select FieldValue from field_value tbl1
							where tbl1.TableKeyId = injury_InjuryId  and tbl1.FieldId ="', $FieldId,'"   limit 1) as `',@STR,'`');	
		-- Textbox 
				elseif ((SELECT INSTR( @STR , 'textbox') > 0)) THEN 
					SET @selectquery = CONCAT(@selectquery , ',    (select FieldValue from field_value tbl1
						where  tbl1.TableKeyId = injury_InjuryId  and tbl1.FieldId ="', $FieldId,'"   limit 1) as `',@STR,'`');	
		-- Textarea 						
				elseif ((SELECT INSTR( @STR , 'textarea') > 0)) THEN 
					SET @selectquery = CONCAT(@selectquery , ',    (select FieldValue from field_value tbl1
							where  tbl1.TableKeyId = injury_InjuryId   and tbl1.FieldId ="', $FieldId,'"   limit 1) as `',@STR,'`');	
		-- Other types 
				else    
					SET @selectquery = CONCAT(@selectquery , ',   (select group_concat(tbl3.OptionName separator ', ') from field_value tbl1
					inner join `option` tbl3
					on tbl1.OptionId = tbl3.OptionId
					 where  tbl1.TableKeyId = injury_InjuryId  and tbl1.FieldId ="', $FieldId,'") as `',@STR,'`');	
				
				END IF; 
                
	  elseif ((SELECT INSTR( @STR , 'VehicleDamage') > 0)) THEN  
			
            SET $VehicleDamageFound = TRUE;
       
	-- Vehicle Damage custom fields
		-- Calendar               
			   if ((SELECT INSTR( @STR , 'calendar') > 0)) THEN 
					SET @selectquery = CONCAT(@selectquery , ', (select FieldValue from field_value tbl1
							where tbl1.TableKeyId = vehicle_damage_VehicleDamageId  and tbl1.FieldId ="', $FieldId,'"   limit 1) as `',@STR,'`');	
		-- Textbox      
				elseif ((SELECT INSTR( @STR , 'textbox') > 0)) THEN 
					SET @selectquery = CONCAT(@selectquery , ',    (select FieldValue from field_value tbl1
						where  tbl1.TableKeyId = vehicle_damage_VehicleDamageId  and tbl1.FieldId ="', $FieldId,'"   limit 1) as `',@STR,'`');	
					
		-- Textarea  
				elseif ((SELECT INSTR( @STR , 'textarea') > 0)) THEN 
					SET @selectquery = CONCAT(@selectquery , ',    (select FieldValue from field_value tbl1
							where  tbl1.TableKeyId = vehicle_damage_VehicleDamageId   and tbl1.FieldId ="', $FieldId,'"   limit 1) as `',@STR,'`');	
		-- Other types 
				else    
					SET @selectquery = CONCAT(@selectquery , ',   (select group_concat(tbl3.OptionName separator ', ') from field_value tbl1
					inner join `option` tbl3
					on tbl1.OptionId = tbl3.OptionId
					 where  tbl1.TableKeyId = vehicle_damage_VehicleDamageId  and tbl1.FieldId ="', $FieldId,'") as `',@STR,'`');	
				
				END IF; 
         elseif ((SELECT INSTR( @STR , 'SpillRelease') > 0)) THEN   
         
				SET $SpillReleaseFound = TRUE;
       
	-- Spill Release custom fields
		-- Calendar                         
			   if ((SELECT INSTR( @STR , 'calendar') > 0)) THEN 
					SET @selectquery = CONCAT(@selectquery , ', (select FieldValue from field_value tbl1
							where tbl1.TableKeyId = spill_release_SpillReleaseId  and tbl1.FieldId ="', $FieldId,'"   limit 1) as `',@STR,'`');	
		-- Textbox 
				elseif ((SELECT INSTR( @STR , 'textbox') > 0)) THEN 
					SET @selectquery = CONCAT(@selectquery , ',    (select FieldValue from field_value tbl1
						where  tbl1.TableKeyId = spill_release_SpillReleaseId  and tbl1.FieldId ="', $FieldId,'"   limit 1) as `',@STR,'`');	
					
		-- Textarea 
				elseif ((SELECT INSTR( @STR , 'textarea') > 0)) THEN 
					SET @selectquery = CONCAT(@selectquery , ',    (select FieldValue from field_value tbl1
							where  tbl1.TableKeyId = spill_release_SpillReleaseId   and tbl1.FieldId ="', $FieldId,'"   limit 1) as `',@STR,'`');	
		-- Other types 
				else    
					SET @selectquery = CONCAT(@selectquery , ',   (select group_concat(tbl3.OptionName separator ', ') from field_value tbl1
					inner join `option` tbl3
					on tbl1.OptionId = tbl3.OptionId
					 where  tbl1.TableKeyId = spill_release_SpillReleaseId  and tbl1.FieldId ="', $FieldId,'") as `',@STR,'`');	
				
				END IF; 
                         
       elseif ((SELECT INSTR( @STR , 'Illness') > 0)) THEN   
       
				SET $IllnessFound = TRUE;
	-- Illness custom fields
		-- Calendar        
			   if ((SELECT INSTR( @STR , 'calendar') > 0)) THEN 
					SET @selectquery = CONCAT(@selectquery , ', (select FieldValue from field_value tbl1
							where tbl1.TableKeyId = illness.IllnessId  and tbl1.FieldId ="', $FieldId,'"   limit 1) as `',@STR,'`');	
		-- Textbox   
				elseif ((SELECT INSTR( @STR , 'textbox') > 0)) THEN 
					SET @selectquery = CONCAT(@selectquery , ',    (select FieldValue from field_value tbl1
						where  tbl1.TableKeyId = illness.IllnessId  and tbl1.FieldId ="', $FieldId,'"   limit 1) as `',@STR,'`');	
		-- Textarea 
				elseif ((SELECT INSTR( @STR , 'textarea') > 0)) THEN 
					SET @selectquery = CONCAT(@selectquery , ',    (select FieldValue from field_value tbl1
							where  tbl1.TableKeyId = illness.IllnessId   and tbl1.FieldId ="', $FieldId,'"   limit 1) as `',@STR,'`');	
		-- Other types 
				else    
					SET @selectquery = CONCAT(@selectquery , ',   (select group_concat(tbl3.OptionName separator ', ') from field_value tbl1
					inner join `option` tbl3
					on tbl1.OptionId = tbl3.OptionId
					 where  tbl1.TableKeyId = illness_IllnessId  and tbl1.FieldId ="', $FieldId,'") as `',@STR,'`');	
				
				END IF;     
                
	   elseif ((SELECT INSTR( @STR , 'TrafficViolation') > 0)) THEN   
       
				SET $TrafficViolationFound = TRUE;
	-- Traffic Violation custom fields
		-- Calendar 
			   if ((SELECT INSTR( @STR , 'calendar') > 0)) THEN 
					SET @selectquery = CONCAT(@selectquery , ', (select FieldValue from field_value tbl1
							where tbl1.TableKeyId = traffic_violation.TrafficViolationId  and tbl1.FieldId ="', $FieldId,'"   limit 1) as `',@STR,'`');	
		-- Textbox 
				elseif ((SELECT INSTR( @STR , 'textbox') > 0)) THEN 
					SET @selectquery = CONCAT(@selectquery , ',    (select FieldValue from field_value tbl1
						where  tbl1.TableKeyId = traffic_violation.TrafficViolationId and tbl1.FieldId ="', $FieldId,'"   limit 1) as `',@STR,'`');	
		-- Textarea
				elseif ((SELECT INSTR( @STR , 'textarea') > 0)) THEN 
					SET @selectquery = CONCAT(@selectquery , ',    (select FieldValue from field_value tbl1
							where  tbl1.TableKeyId = traffic_violation.TrafficViolationId   and tbl1.FieldId ="', $FieldId,'"   limit 1) as `',@STR,'`');	
		-- Other types
				else    
					SET @selectquery = CONCAT(@selectquery , ',   (select group_concat(tbl3.OptionName separator ', ') from field_value tbl1
					inner join `option` tbl3
					on tbl1.OptionId = tbl3.OptionId
					 where  tbl1.TableKeyId = traffic_violation_TrafficViolationId and tbl1.FieldId ="', $FieldId,'") as `',@STR,'`');	
				
				END IF; 
                                
                   elseif ((SELECT INSTR( @STR , 'WhatHappened') > 0)) THEN   
				if ((SELECT INSTR( @STR , 'calendar') > 0)) THEN 
					SET @selectquery = CONCAT(@selectquery , ', (select group_concat(FieldValue  separator ', ' ) from field_value tbl1
							where tbl1.incidentid = incident_incidentid and tbl1.FieldId ="', $FieldId,'"   limit 1) as `',@STR,'`');	
				elseif ((SELECT INSTR( @STR , 'textbox') > 0)) THEN 
					SET @selectquery = CONCAT(@selectquery , ',    (select  group_concat(FieldValue  separator ', ' )  from field_value tbl1
						where tbl1.incidentid = incident_incidentid and tbl1.FieldId ="', $FieldId,'"   limit 1) as `',@STR,'`');	
						
				elseif ((SELECT INSTR( @STR , 'textarea') > 0)) THEN 
					SET @selectquery = CONCAT(@selectquery , ',    (select  group_concat(FieldValue  separator ', ' )  from field_value tbl1
							where tbl1.incidentid = incident_incidentid and tbl1.FieldId ="', $FieldId,'"   limit 1) as `',@STR,'`');	
				else    
					SET @selectquery = CONCAT(@selectquery , ',   (select group_concat(trim(tbl3.OptionName) separator ', ') from field_value tbl1
					inner join `option` tbl3
					on tbl1.OptionId = tbl3.OptionId
					where tbl1.incidentid = incident_incidentid and tbl1.FieldId ="', $FieldId,'") as `',@STR,'`');	
				
				END IF;     
                
    END IF; 	
    
    	SET @Col =  extractvalue(xmlData, CONCAT('//',@STR));
		IF (@Col != '' AND @Col !='NULL') THEN	 
		SET @queryhave = CONCAT(@queryhave,'  and  ', @STR ,' like '"'%", @Col ,"%'" );
		END IF; 	
        
	SET @Postition = LOCATE(',', $ids);
END WHILE;
-- End of Custom Fields part
-- #
-- Add OrgId and check if the Creator is the one how logged in now or not;
IF (@OrgId != '' AND @OrgId !='0') THEN
	SET @queryWhere = CONCAT(@queryWhere,' and incident_OrgId =   "', @Orgid,'" ');
END IF;
IF (@Mine = 'TRUE') THEN
	SET @queryWhere = CONCAT(@queryWhere,' AND incident.CreatorId =  "',@CreatorId,'" '  );
END IF;
SET @queryWhere = CONCAT(@queryWhere,' AND incident_Hide =  0');
-- #
-- join with event_type
IF( ExtractValue(xmlData, 'count(//EventTypeId)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', event_type_EventTypeName as EventTypeId ');
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join event_type on incident.EventTypeId = event_type.EventTypeId  ');
END IF;
-- #
-- join with operation_type
IF( ExtractValue(xmlData, 'count(//OperationTypeId)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', operation_type_OperationTypeName as OperationTypeId ');
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join operation_type on incident.OperationTypeId = operation_type.OperationTypeId  ');
END IF;
-- #
-- join with location1
IF( ExtractValue(xmlData, 'count(//Location1Id)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', location1_Location1Name as Location1Id ');
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join location1 on incident.Location1Id = location1.Location1Id  ');
END IF;
-- #
-- join with location2
IF( ExtractValue(xmlData, 'count(//Location2Id)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', location2_Location2Name as Location2Id ');
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join location2 on incident.Location2Id = location2.Location2Id  ');
END IF;
-- #
-- join with location3
IF( ExtractValue(xmlData, 'count(//Location3Id)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', location3_Location3Name as Location3Id ');
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join location3 on incident.Location3Id = location3.Location3Id  ');
END IF;
-- #
-- join with location4
IF( ExtractValue(xmlData, 'count(//Location4Id)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', location4_Location4Name as Location4Id ');
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join location4 on incident.Location4Id = location4.Location4Id  ');
END IF;
-- #
-- join with hist_incident to add UpdatedByName and VersionNumber
IF( ExtractValue(xmlData, 'count(//UpdatedByName)') >0 OR ExtractValue(xmlData, 'count(//VersionNumber)') >0) THEN
		SET @selectquery = CONCAT(@selectquery,',  hist_incident_VersionNumber ');
		SET @queryFrom = CONCAT(@queryFrom,'   inner join hist_incident on hist_incident.Incidentid = incident.IncidentId  and  hist_incident.HistIncidentId =   hist_incident(incident.IncidentId)    ');
-- MAX ???	
		IF( ExtractValue(xmlData, 'count(//UpdatedByName)') >0)THEN		
			SET @selectquery = CONCAT(@selectquery,', ', 'max( CONCAT',' (','empModifier_FirstName,',"'","  '" ,',empModifier_LastName',') ',') as UpdatedByName ');
			SET @queryFrom = CONCAT(@queryFrom,'  inner join employee as empModifier on hist_incident.UpdatedById = empModifier.EmployeeId  ');
		END IF;
END IF;
-- #
-- join with employee
IF( ExtractValue(xmlData, 'count(//CreatorName)') >0 ) THEN
	SET @selectquery = CONCAT(@selectquery,', ', 'CONCAT',' (','empCreator_FirstName,',"'","  '" ,',empCreator_LastName',') ',' as CreatorName ');
	SET @queryFrom = CONCAT(@queryFrom,'    inner join employee as empCreator on incident.CreatorId = empCreator.EmployeeId  ');
END IF;
-- #
/* injury part   */
IF(ExtractValue(xmlData, 'count(//InjuryTypeId)') >0 OR ExtractValue(xmlData, 'count(//BodyPartId)') >0 
OR ExtractValue(xmlData, 'count(//BodyAreaId)') >0 OR ExtractValue(xmlData, 'count(//PersonalInjured)') >0 
OR ExtractValue(xmlData, 'count(//ContactCodeId)') >0 OR ExtractValue(xmlData, 'count(//RecordableId)') >0
OR ExtractValue(xmlData, 'count(//InitialTreatmentId)') >0 OR ExtractValue(xmlData, 'count(//InjuryExtAgencyId)') >0 
OR ExtractValue(xmlData, 'count(//LostTimeEnd)') >0 OR ExtractValue(xmlData, 'count(//TotalDaysOff)') >0 
OR ExtractValue(xmlData, 'count(//InjuryDescription)') >0 OR ExtractValue(xmlData, 'count(//AdjustmentDays)') >0
OR ExtractValue(xmlData, 'count(//LostTimeStart)') >0 OR $InjuryFound = TRUE) THEN
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join injury on injury.InjuryId = all_impact_types.ImpactId  ');
	
	IF(ExtractValue(xmlData, 'count(//InjuryTypeId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(distinct  injury_type_InjuryTypeName separator "; ")  ) as InjuryTypeId' );
		SET @queryFrom = CONCAT(@queryFrom,'    left outer join ( `injury_type_injury` join  `injury_type` on  `injury_type`.`InjuryTypeId` = `injury_type_injury`.`InjuryTypeId`)  on  `injury_type_injury`.`InjuryId` = `injury`.`InjuryId`  ');
         
		SET @Col =  extractvalue(xmlData, CONCAT('//','InjuryTypeId'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  injury_type_InjuryTypeName ' ,' like '"'%", @Col ,"%'" );
		END IF; 
         
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//BodyPartId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(distinct  body_part_BodyPartName separator "; ")  ) as BodyPartId' );
		SET @queryFrom = CONCAT(@queryFrom,'     left outer join ( `body_part_injury` join  `body_part` on `body_part`.`BodyPartId` = `body_part_injury`.`BodyPartId` ) on `body_part_injury`.`InjuryId` = `injury`.`InjuryId` ');
         
		SET @Col =  extractvalue(xmlData, CONCAT('//','BodyPartId'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  body_part_BodyPartName ' ,' like '"'%", @Col ,"%'" );
		END IF; 
       
	END IF;
	
	
		IF(ExtractValue(xmlData, 'count(//BodyAreaId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(BodyAreaId separator "; ") 
														from incident_injury_view
														where incident_injury_view.InjuryId = all_impact_types_ImpactId) as BodyAreaId' );	
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//PersonalInjured)') >0 )then 	
    
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(distinct injury_PersonalInjuredName separator "; ")  ) as PersonalInjured' );	
		
		SET @Col =  extractvalue(xmlData, CONCAT('//','PersonalInjured'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
				SET @queryWhere = CONCAT(@queryWhere,'  and `injury_PersonalInjuredName` ' ,' like '"'%", @Col ,"%'" );
		END IF; 
   
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//ContactCodeId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(distinct  contact_code_ContactCodeName separator "; ")  ) as ContactCodeId' );	
        SET @queryFrom = CONCAT(@queryFrom,'    left outer join  `contact_code` on `contact_code`.`ContactCodeId` = `injury_ContactCodeId`  ');
         
		SET @Col =  extractvalue(xmlData, CONCAT('//','ContactCodeId'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  contact_code_ContactCodeName ' ,' like '"'%", @Col ,"%'" );
		END IF; 
         
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//RecordableId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(distinct  injury_recordable_RecordableName separator "; ")  ) as RecordableId' );	
        SET @queryFrom = CONCAT(@queryFrom,'    left outer join  `injury_recordable` on `injury_recordable`.`RecordableId` = `injury_RecordableId` ');        
         
		SET @Col =  extractvalue(xmlData, CONCAT('//','RecordableId'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `injury_recordable_RecordableName` ' ,' like '"'%", @Col ,"%'" );
		END IF; 
        
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//InitialTreatmentId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(distinct  initial_treatment_InitialTreatmentName separator "; ")  ) as InitialTreatmentId' );	
        SET @queryFrom = CONCAT(@queryFrom,'    left outer join  `initial_treatment` on  `initial_treatment`.`InitialTreatmentId` = `injury`.`InitialTreatmentId` ');   
         
		SET @Col =  extractvalue(xmlData, CONCAT('//','InitialTreatmentId'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  initial_treatment_InitialTreatmentName ' ,' like '"'%", @Col ,"%'" );
		END IF; 
                
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//InjuryExtAgencyId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(distinct  contact_agency_ContactAgencyName separator "; ")  ) as InjuryExtAgencyId' );	
        SET @queryFrom = CONCAT(@queryFrom,'    left outer join  `contact_agency` on  `contact_agency`.`ContactAgencyId` = `injury`.`ContactAgencyId` ');   	
    
      SET @Col =  extractvalue(xmlData, CONCAT('//','InjuryExtAgencyId'));
		 IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `contact_agency_ContactAgencyName` ' ,' like '"'%", @Col ,"%'" );
		END IF;
    
    END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//AdjustmentDays)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(injury_AdjustmentDays separator "; ")  ) as AdjustmentDays' );	
		
		SET @Col =  extractvalue(xmlData, CONCAT('//','AdjustmentDays'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `injury_AdjustmentDays` ' ,' like '"'%", @Col ,"%'"   );
		END IF;
		
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//TotalDaysOff)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(injury_TotalDaysOff separator "; ")  ) as TotalDaysOff' );	
		
		SET @Col =  extractvalue(xmlData, CONCAT('//','TotalDaysOff'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `injury_TotalDaysOff` ' ,' like '"'%", @Col ,"%'"  );
		END IF;
		
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//InjuryDescription)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(injury_InjuryDescription separator "; ")  ) as InjuryDescription' );	
		
		SET @Col =  extractvalue(xmlData, CONCAT('//','InjuryDescription'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `injury_InjuryDescription` ' ,' like '"'%", @Col ,"%'" );
		END IF;
		
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//LostTimeEnd)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(date_format(injury_LostTimeEnd,'%m/%d/%Y') separator "; ")  ) as LostTimeEnd' );	
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//LostTimeStart)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(date_format(injury_LostTimeStart,'%m/%d/%Y') separator "; ")  ) as LostTimeStart' );	
	END IF;
	
END IF;
/* Illness part   */
IF(ExtractValue(xmlData, 'count(//IllnessDescription)') >0 OR ExtractValue(xmlData, 'count(//Illness_RestrictedWorkId)') >0 
OR ExtractValue(xmlData, 'count(//Illness_PersonalInjured)') >0 OR ExtractValue(xmlData, 'count(//Illness_InitialTreatmentId)') >0 
OR ExtractValue(xmlData, 'count(//ContactCodeId)') >0 OR ExtractValue(xmlData, 'count(//RecordableId)') >0
OR ExtractValue(xmlData, 'count(//Illness_AdjustmentDays)') >0 OR ExtractValue(xmlData, 'count(//Illness_AdjustmentDays)') >0 
OR ExtractValue(xmlData, 'count(//Illness_LostTimeEnd)') >0 OR ExtractValue(xmlData, 'count(//Illness_LostTimeStart)') >0 
OR ExtractValue(xmlData, 'count(//Illness_TotalDaysOff)') >0 OR ExtractValue(xmlData, 'count(//SymptomsId)') >0
OR $IllnessFound = TRUE) THEN
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join illness on illness.IllnessId = all_impact_types.ImpactId  ');
	
	IF(ExtractValue(xmlData, 'count(//IllnessDescription)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(illness_IllnessDescription separator "; ") ) as IllnessDescription' );	
         
		SET @Col =  extractvalue(xmlData, CONCAT('//','IllnessDescription'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  illness_IllnessDescription ' ,' like '"'%", @Col ,"%'" );
		END IF; 
         
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//Illness_RestrictedWorkId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(distinct restricted_work_RestrictedWorkName separator "; ") ) as Illness_RestrictedWorkId' );	
        SET @queryFrom = CONCAT(@queryFrom,'    left outer join restricted_work on `restricted_work`.`RestrictedWorkId` = `illness`.`RestrictedWorkId` ');
         
		SET @Col =  extractvalue(xmlData, CONCAT('//','Illness_RestrictedWorkId'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and restricted_work_RestrictedWorkName` ' ,' like '"'%", @Col ,"%'" );
		END IF; 
         
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//Illness_PersonalInjured)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(distinct  illness_PersonalAfflictedName separator "; ") ) as Illness_PersonalInjured' );	
         
		SET @Col =  extractvalue(xmlData, CONCAT('//','Illness_PersonalInjured'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `illness_PersonalAfflictedName` ' ,' like '"'%", @Col ,"%'" );
		END IF; 
         
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//Illness_InitialTreatmentId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(distinct  initial_treatment_InitialTreatmentName separator "; "))  as Illness_InitialTreatmentId' );
        SET @queryFrom = CONCAT(@queryFrom,'    left outer join initial_treatment  illt on `illt`.`InitialTreatmentId` = `illness`.`InitialTreatmentId` ');
         
		SET @Col =  extractvalue(xmlData, CONCAT('//','Illness_InitialTreatmentId'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `initial_treatment_InitialTreatmentName` ' ,' like '"'%", @Col ,"%'" );
		END IF; 
         
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//Illness_AdjustmentDays)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(illness_AdjustmentDays separator "; ") ) as Illness_AdjustmentDays' );	
         
		SET @Col =  extractvalue(xmlData, CONCAT('//','Illness_AdjustmentDays'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `illness_AdjustmentDays` ' ,' like '"'%", @Col ,"%'" );
		END IF; 
         
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//SymptomsId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(symptoms_Description separator "; ") ) as SymptomsId' );	
		SET @queryFrom = CONCAT(@queryFrom,'    left outer join ( illness_symptoms  join symptoms on symptoms.SymptomsId = illness_symptoms.SymptomsId) on `illness_symptoms`.`IllnessId` = `illness`.`IllnessId` ');
         
		SET @Col =  extractvalue(xmlData, CONCAT('//','SymptomsId'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `symptoms_Description` ' ,' like '"'%", @Col ,"%'" );
		END IF; 
                  
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//Illness_TotalDaysOff)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(illness_TotalDaysOff separator "; ") ) as Illness_TotalDaysOff' );	
         
		SET @Col =  extractvalue(xmlData, CONCAT('//','Illness_TotalDaysOff'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `illness_TotalDaysOff` ' ,' like '"'%", @Col ,"%'");
		END IF; 
                
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//Illness_LostTimeEnd)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(date_format(illness_LostTimeEnd,'%m/%d/%Y') separator "; ") ) as Illness_LostTimeEnd' );	
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//Illness_LostTimeStart)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(date_format(illness_LostTimeStart,'%m/%d/%Y') separator "; ") ) as Illness_LostTimeStart' );	
	END IF;
	
END IF;
/* traffic_violation part   */
IF(ExtractValue(xmlData, 'count(//TrafficDriverName)') >0 OR ExtractValue(xmlData, 'count(//TrafficDriverLicence)') >0 
OR ExtractValue(xmlData, 'count(//TrafficVehicleTypeId)') >0 OR ExtractValue(xmlData, 'count(//TrafficVehicleLicence)') >0 
OR ExtractValue(xmlData, 'count(//Details)') >0 OR ExtractValue(xmlData, 'count(//ValueOfFine)') >0
OR ExtractValue(xmlData, 'count(//TicketNumber)') >0 OR ExtractValue(xmlData, 'count(//HowDidThatOccur)') >0 
OR $TrafficViolationFound = TRUE  ) THEN
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join traffic_violation on traffic_violation.TrafficViolationId = all_impact_types_ImpactId  ');
	IF(ExtractValue(xmlData, 'count(//TrafficDriverName)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(distinct traffic_violation_DriverName separator "; ")  ) as TrafficDriverName' );	
         
		SET @Col =  extractvalue(xmlData, CONCAT('//','TrafficDriverName'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `traffic_violation_DriverName` ' ,' like '"'%", @Col ,"%'" );
		END IF; 
                  
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//TrafficDriverLicence)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(traffic_violation_DriverLicence separator "; ")  ) as TrafficDriverLicence' );	
         
		SET @Col =  extractvalue(xmlData, CONCAT('//','TrafficDriverLicence'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `traffic_violation_DriverLicence` ' ,' like '"'%", @Col ,"%'" );
		END IF; 
            
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//TrafficVehicleTypeId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(distinct  tvt_VehicleTypeName separator "; ")  ) as TrafficVehicleTypeId' );	
        SET @queryFrom = CONCAT(@queryFrom,'    left outer join vehicle_type tvt on `tvt`.`VehicleTypeId` = `traffic_violation`.`VehicleTypeId` ');	
         
		SET @Col =  extractvalue(xmlData, CONCAT('//','TrafficVehicleTypeId'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `tvt_VehicleTypeName` ' ,' like '"'%", @Col ,"%'" );
		END IF; 
        
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//TrafficVehicleLicence)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(traffic_violation_VehicleLicence separator "; ")  ) as TrafficVehicleLicence' );	
         
		SET @Col =  extractvalue(xmlData, CONCAT('//','TrafficVehicleLicence'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `traffic_violation_VehicleLicence` ' ,' like '"'%", @Col ,"%'" );
		END IF; 
        
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//Details)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(traffic_violation_Details separator "; ")  ) as Details' );	
         
		SET @Col =  extractvalue(xmlData, CONCAT('//','Details'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  traffic_violation_Details ' ,' like '"'%", @Col ,"%'" );
		END IF; 
        
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//ValueOfFine)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(traffic_violation_ValueOfFine separator "; ")  ) as ValueOfFine' );	
         
		SET @Col =  extractvalue(xmlData, CONCAT('//','ValueOfFine'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `traffic_violation_ValueOfFine` ' ,' like '"'%", @Col ,"%'" );
		END IF; 
        
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//TicketNumber)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(traffic_violation_TicketNumber separator "; ")  ) as TicketNumber' );
         
		SET @Col =  extractvalue(xmlData, CONCAT('//','TicketNumber'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `traffic_violation_TicketNumber` ' ,' like '"'%", @Col ,"%'" );
		END IF; 
        	
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//HowDidThatOccur)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(traffic_violation_HowDidThatOccur separator "; ")  ) as HowDidThatOccur' );	
         
		SET @Col =  extractvalue(xmlData, CONCAT('//','HowDidThatOccur'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `traffic_violation_HowDidThatOccur` ' ,' like '"'%", @Col ,"%'" );
		END IF; 
        	
	END IF;
	
END IF;
/* vehicle_damage part   */
IF(ExtractValue(xmlData, 'count(//DamageDriverName)') >0 OR ExtractValue(xmlData, 'count(//DamageDriverLicence)') >0 
OR ExtractValue(xmlData, 'count(//DamageVehicleTypeId)') >0 OR ExtractValue(xmlData, 'count(//DamageVehicleLicence)') >0 
OR ExtractValue(xmlData, 'count(//vehicle_damage_HowDidThatDone)') >0 OR ExtractValue(xmlData, 'count(//DamageDescription)') >0 
OR $VehicleDamageFound = TRUE) THEN
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join vehicle_damage on vehicle_damage.VehicleDamageId = all_impact_types.ImpactId  ');
	
	IF(ExtractValue(xmlData, 'count(//DamageDriverName)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(distinct  traffic_violation_DriverName separator "; ") ) as DamageDriverName' );	
	
		SET @Col =  extractvalue(xmlData, CONCAT('//','DamageDriverName'));
		 IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  traffic_violation_DriverName ' ,' like '"'%", @Col ,"%'" );
		END IF;   
    
    END IF;
	
	IF(ExtractValue(xmlData, 'count(//DamageDriverLicence)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(traffic_violation_DriverLicence separator "; ") ) as DamageDriverLicence' );	
        
        SET @Col =  extractvalue(xmlData, CONCAT('//','DamageDriverLicence'));
		 IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  traffic_violation_DriverLicence  ' ,' like '"'%", @Col ,"%'" );
		END IF;   
       
        
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//DamageVehicleTypeId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(distinct  dvt_VehicleTypeName separator "; ") ) as DamageVehicleTypeId' );	
		SET @queryFrom = CONCAT(@queryFrom,'    left outer join vehicle_type dvt on `dvt`.`VehicleTypeId` = `vehicle_damage`.`VehicleTypeId` ');
        
        
		 SET @Col =  extractvalue(xmlData, CONCAT('//','DamageVehicleTypeId'));
		 IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  dvt_VehicleTypeName  ' ,' like '"'%", @Col ,"%'" );
		END IF;   
       
       
         
	END IF;	
	
	IF(ExtractValue(xmlData, 'count(//DamageVehicleLicence)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(traffic_violation_VehicleLicence separator "; ") ) as DamageVehicleLicence' );	
        
        SET @Col =  extractvalue(xmlData, CONCAT('//','DamageVehicleLicence'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  traffic_violation_VehicleLicence  ' ,' like '"'%", @Col ,"%'" );
		END IF;   
        
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//vehicle_damage_HowDidThatDone)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(vehicle_damage_HowDidThatDone separator "; ") ) as vehicle_damage_HowDidThatDone' );	
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//DamageDescription)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat( vehicle_damage_DamageDescription separator "; ") ) as DamageDescription' );	
          
		SET @Col =  extractvalue(xmlData, CONCAT('//','DamageDescription'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  vehicle_damage_DamageDescription   ' ,' like '"'%", @Col ,"%'" );
		END IF; 
        
	END IF;	
	
END IF;
/* spill_release part   */
IF(ExtractValue(xmlData, 'count(//SourceId)') >0 OR ExtractValue(xmlData, 'count(//DurationValue)') >0 
OR ExtractValue(xmlData, 'count(//DurationUnitId)') >0 OR ExtractValue(xmlData, 'count(//QuantityValue)') >0 
OR ExtractValue(xmlData, 'count(//QuantityUnitId)') >0 OR ExtractValue(xmlData, 'count(//QuantityRecoveredValue)') >0 
OR ExtractValue(xmlData, 'count(//RecoveredUnitId)') >0 OR ExtractValue(xmlData, 'count(//WhatWasIt)') >0 OR ExtractValue(xmlData, 'count(//HowDidSROccur)') >0 
OR ExtractValue(xmlData, 'count(//IsReportable)') >0 OR ExtractValue(xmlData, 'count(//ImpactsExtAgencyId)') >0
OR $SpillReleaseFound = TRUE ) THEN
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join spill_release on spill_release.SpillReleaseId = all_impact_types.ImpactId  ');
	
	IF(ExtractValue(xmlData, 'count(//SourceId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(distinct  `spill_release_source_SourceName` separator "; ") ) as SourceId' );	
        SET @queryFrom = CONCAT(@queryFrom,'    left outer join spill_release_source on `spill_release_source`.`SourceId` = `spill_release`.`SourceId`  ');
          
		SET @Col =  extractvalue(xmlData, CONCAT('//','SourceId'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  spill_release_source_SourceName   ' ,' like '"'%", @Col ,"%'" );
		END IF; 
        
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//DurationValue)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(spill_release_DurationValue separator "; ")  ) as DurationValue' );	
          
		SET @Col =  extractvalue(xmlData, CONCAT('//','DurationValue'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  spill_release_DurationValue   ' ,' like '"'%", @Col ,"%'" );
		END IF; 
        
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//DurationUnitId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(distinct  `duration_unit_DurationUnitName` separator "; ")  ) as DurationUnitId' );	
        SET @queryFrom = CONCAT(@queryFrom,'    left outer join `duration_unit` ON  `duration_unit`.`DurationUnitId` = `spill_release`.`DurationUnitId`  ');
          
		SET @Col =  extractvalue(xmlData, CONCAT('//','DurationUnitId'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  duration_unit_DurationUnitName   ' ,' like '"'%", @Col ,"%'" );
		END IF; 
        
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//QuantityValue)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(spill_release_QuantityValue separator "; ")  ) as QuantityValue' );	
          
		SET @Col =  extractvalue(xmlData, CONCAT('//','QuantityValue'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  spill_release_QuantityValue   ' ,' like '"'%", @Col ,"%'" );
		END IF; 
        
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//QuantityUnitId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat( distinct `quq_QuantityUnitName` separator "; ") )  as QuantityUnitId' );	
        SET @queryFrom = CONCAT(@queryFrom,'    left outer join `quantity_unit` quq ON  `quq`.`QuantityUnitId` = `spill_release`.`QuantityUnitId` ');
          
		SET @Col =  extractvalue(xmlData, CONCAT('//','QuantityUnitId'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  quq_QuantityUnitName   ' ,' like '"'%", @Col ,"%'" );
		END IF; 
        
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//QuantityRecoveredValue)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(spill_release_QuantityRecoveredValue separator "; ")  ) as QuantityRecoveredValue' );
          
		SET @Col =  extractvalue(xmlData, CONCAT('//','QuantityRecoveredValue'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  spill_release_QuantityRecoveredValue   ' ,' like '"'%", @Col ,"%'" );
		END IF; 
        	
	END IF;	
	
	IF(ExtractValue(xmlData, 'count(//RecoveredUnitId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(distinct  `quantity_recovered_QuantityUnitName` separator "; ")  ) as RecoveredUnitId' );
        SET @queryFrom = CONCAT(@queryFrom,'    left outer join `quantity_unit` `quantity_recovered` ON `quantity_recovered`.`QuantityUnitId` = `spill_release`.`RecoveredUnitId` ');
          
		SET @Col =  extractvalue(xmlData, CONCAT('//','RecoveredUnitId'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  quantity_recovered_QuantityUnitName   ' ,' like '"'%", @Col ,"%'" );
		END IF; 
        
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//WhatWasIt)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(spill_release_WhatWasIt separator "; ") ) as WhatWasIt' );	
          
		SET @Col =  extractvalue(xmlData, CONCAT('//','WhatWasIt'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  spill_release_WhatWasIt   ' ,' like '"'%", @Col ,"%'" );
		END IF; 
        
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//HowDidSROccur)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(spill_release_HowDidSROccur separator "; ") ) as HowDidSROccur' );	
          
		SET @Col =  extractvalue(xmlData, CONCAT('//','HowDidSROccur'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  spill_release_HowDidSROccur   ' ,' like '"'%", @Col ,"%'" );
		END IF; 
        
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//IsReportable)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat( case `spill_release_IsReportable`  WHEN '0' THEN 'No'   WHEN '1' THEN 'Yes' END separator "; ") ) as IsReportable' );	
          
		SET @Col =  extractvalue(xmlData, CONCAT('//','IsReportable'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryhave = CONCAT(@queryhave,'  and  spill_release_IsReportable   ' ,' like '"'%", @Col ,"%'" );
		END IF; 
        
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//ImpactsExtAgencyId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(distinct  `sp_rel_agency_SpRelAgencyName` separator "; ") ) as ImpactsExtAgencyId' );	
        SET @queryFrom = CONCAT(@queryFrom,'    left outer join `sp_rel_agency` ON `sp_rel_agency`.`SpRelAgencyId` = `spill_release`.`SpRelAgencyId` ');
        
        
        
		SET @Col =  extractvalue(xmlData, CONCAT('//','ImpactsExtAgencyId'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `sp_rel_agency_SpRelAgencyName`   ' ,' like '"'%", @Col ,"%'" );
		END IF; 
        
	END IF;
	
END IF;
/* search part*/
 SET@myArrayOfValue='VersionNumber,IncidentNumber,EventTypeId,CreatorName,UpdatedByName,Location1Id,Location2Id,Location3Id,Location4Id,OtherLocation,OperationTypeId,IncDescription,QuantityRecoveredValue,RecoveredUnitId,DamageDescriptio,BodyAreaId,ImpactTypeId,ImpactSubTypeId,ImpactDescription,IntEmployeeName1,IntEmployeeDept1,IntEmployeeName2,IntEmployeeDept2,IntEmployeeName3,IntEmployeeDept3,CustomOpenTxt,PrimRespondName,';
 SET @Postition = LOCATE(',', @myArrayOfValue);
WHILE ( @Postition > 0 ) DO
 SET @STR = SUBSTRING(@myArrayOfValue, 1, @Postition-1);
 SET @myArrayOfValue = SUBSTRING(@myArrayOfValue, @Postition + 1);
 SET @Col =  extractvalue(xmlData, CONCAT('//',@STR));
 IF (@Col != '' AND @Col !='NULL') THEN
	
    IF (@STR  = 'CreatorName' ) then set @STR= 'concat (empCreator_FirstName," ",empCreator_LastName) '; END IF;
	IF (@STR  = 'IncidentId' ) then set @STR= 'incident_IncidentId';  END IF;
	IF (@STR  = 'Location1Id' ) then set @STR= 'location1_Location1Name'; END IF;
	IF (@STR  = 'Location2Id' ) then set @STR= 'location2_Location2Name';  END IF;
	IF (@STR  = 'Location3Id' ) then set @STR= 'location3_Location3Name'; END IF;
	IF (@STR  = 'Location4Id' ) then set @STR= 'location4_Location4Name';  END IF;
	IF (@STR  = 'OperationTypeId' ) then set @STR= 'operation_type_OperationTypeName';  END IF;	
	IF (@STR  = 'EventTypeId' ) then set @STR= 'event_type_EventTypeName';  END IF;	
	IF (@STR  = 'UpdatedByName' ) then set @STR= CONCAT('CONCAT',' (','empCreator_FirstName,',"'","  '" ,',empCreator_LastName',') '); END IF;	
	IF(@STR  = 'ImpactTypeId' )then 		SET @STR= 'all_impact_types_ImpactTypeName ';	END IF;
	IF(@STR  = 'ImpactSubTypeId' )then 		SET @STR= 'all_impact_types_ImpactSubTypeName';	END IF;
	IF(@STR  = 'IntEmployeeName1' )then 	SET @STR= 'all_impact_types_IntEmployeeName1 ';	END IF;
	IF(@STR  = 'IntEmployeeDept1' )then 	SET @STR= 'all_impact_types_IntEmployeeDept1 ';	END IF;
	IF(@STR  = 'IntEmployeeName2' )then 	SET @STR= 'all_impact_types_IntEmployeeName2 ';	END IF;
	IF(@STR  = 'IntEmployeeDept2' )then 	SET @STR= 'all_impact_types.IntEmployeeDept2 ';	END IF;
	IF(@STR  = 'IntEmployeeName3' )then 	SET @STR= 'all_impact_types.IntEmployeeName3 ';	END IF;
	IF(@STR  = 'IntEmployeeDept3' )then 	SET @STR= 'all_impact_types.IntEmployeeDept3 ';	END IF;
	IF(@STR  = 'CustomOpenTxt' )then 		SET @STR= 'all_impact_types.ustomOpenTxt ';		END IF;
	IF(@STR  = 'PrimRespondName' )then 		SET @STR= 'all_impact_types.PrimRespondName ';	END IF;
	IF(@STR  = 'ImpactDescription' )then 	SET @STR= 'all_impact_types.Description ';		END IF;
	IF(@STR  = 'ImpactEstimatedCost' )then 	SET @STR= 'all_impact_types.EstimatedCost as ImpactEstimatedCost ';	END IF;
	IF(@STR  = 'ExtAgencyId' )then 			SET @STR= 'all_impact_types.ExtAgencyName ';	END IF;
	SET @queryWhere = CONCAT(@queryWhere,CONCAT(' AND ',@STR,' like '"'%", @Col ,"%'" )); 
 END IF;
 
 SET @Postition = LOCATE(',', @myArrayOfValue);
END WHILE;
 
-- select @queryWhere;
-- select CONCAT( @selectquery, @queryFrom, @queryWhere );
SET @LostTimeStartFrom =  extractvalue(xmlData, '//LostTimeStartFrom');
SET @LostTimeStartTo =  extractvalue(xmlData, '//LostTimeStartTo');
IF(@LostTimeStartTo != '') THEN
	SET @LostTimeStartFrom  = STR_TO_DATE(@LostTimeStartFrom , '%m/%d/%Y');
	SET @LostTimeStartTo  = STR_TO_DATE(@LostTimeStartTo , '%m/%d/%Y');
	SET @LostTimeStartTo2 = DATE_ADD(@LostTimeStartTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND injury_LostTimeStart >  ', "'" , @LostTimeStartFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND injury_LostTimeStart <=  ', "'",  @LostTimeStartTo2  ,"'" );										
ELSE 
IF(@LostTimeStartTo = '' AND @LostTimeStartFrom !='' ) THEN
	SET @LostTimeStartFrom  = STR_TO_DATE(@LostTimeStartFrom , '%m/%d/%Y');
	SET @LostTimeStartFrom2 = DATE_ADD(@LostTimeStartFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND injury_LostTimeStart >=  ',  "'", @LostTimeStartFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND injury_LostTimeStart <  ', "'", @LostTimeStartFrom2  ,"'");	
END IF;
END IF;
SET @LostTimeEndFrom =  extractvalue(xmlData, '//LostTimeEndFrom');
SET @LostTimeEndTo =  extractvalue(xmlData, '//LostTimeEndTo');
IF(@LostTimeEndTo != '') THEN
	SET @LostTimeEndFrom  = STR_TO_DATE(@LostTimeEndFrom , '%m/%d/%Y');
	SET @LostTimeEndTo  = STR_TO_DATE(@LostTimeEndTo , '%m/%d/%Y');
	SET @LostTimeEndTo2 = DATE_ADD(@LostTimeEndTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND injury_LostTimeEnd >  ', "'" , @LostTimeEndFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND injury_LostTimeEnd <=  ', "'",  @LostTimeEndTo2  ,"'" );										
ELSE 
IF(@LostTimeEndTo = '' AND @LostTimeEndFrom !='' ) THEN
	SET @LostTimeEndFrom  = STR_TO_DATE(@LostTimeEndFrom , '%m/%d/%Y');
	SET @LostTimeEndFrom2 = DATE_ADD(@LostTimeEndFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND injury-LostTimeEnd >=  ',  "'", @LostTimeEndFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND injury_LostTimeEnd <  ', "'", @LostTimeEndFrom2  ,"'");	
END IF;
END IF;
SET @Illness_LostTimeStartFrom =  extractvalue(xmlData, '//Illness_LostTimeStartFrom');
SET @Illness_LostTimeStartTo =  extractvalue(xmlData, '//Illness_LostTimeStartTo');
IF(@Illness_LostTimeStartTo != '') THEN
	SET @Illness_LostTimeStartFrom  = STR_TO_DATE(@Illness_LostTimeStartFrom , '%m/%d/%Y');
	SET @Illness_LostTimeStartTo  = STR_TO_DATE(@Illness_LostTimeStartTo , '%m/%d/%Y');
	SET @Illness_LostTimeStartTo2 = DATE_ADD(@Illness_LostTimeStartTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND illness_LostTimeStart >  ', "'" , @Illness_LostTimeStartFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND illness_LostTimeStart <=  ', "'",  @Illness_LostTimeStartTo2  ,"'" );										
ELSE 
IF(@Illness_LostTimeStartTo = '' AND @Illness_LostTimeStartFrom !='' ) THEN
	SET @Illness_LostTimeStartFrom  = STR_TO_DATE(@Illness_LostTimeStartFrom , '%m/%d/%Y');
	SET @Illness_LostTimeStartFrom2 = DATE_ADD(@Illness_LostTimeStartFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND illness_LostTimeStart >=  ',  "'", @Illness_LostTimeStartFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND illness_LostTimeStart <  ', "'", @Illness_LostTimeStartFrom2  ,"'");	
END IF;
END IF;
SET @Illness_LostTimeEndFrom =  extractvalue(xmlData, '//Illness_LostTimeEndFrom');
SET @Illness_LostTimeEndTo =  extractvalue(xmlData, '//Illness_LostTimeEndTo');
IF(@Illness_LostTimeEndTo != '') THEN
	SET @Illness_LostTimeEndFrom  = STR_TO_DATE(@Illness_LostTimeEndFrom , '%m/%d/%Y');
	SET @Illness_LostTimeEndTo  = STR_TO_DATE(@Illness_LostTimeEndTo , '%m/%d/%Y');
	SET @Illness_LostTimeEndTo2 = DATE_ADD(@Illness_LostTimeEndTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND illness_LostTimeEnd >  ', "'" , @Illness_LostTimeEndFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND illness-LostTimeEnd <=  ', "'",  @Illness_LostTimeEndTo2  ,"'" );										
ELSE 
IF(@Illness_LostTimeEndTo = '' AND @Illness_LostTimeEndFrom !='' ) THEN
	SET @Illness_LostTimeEndFrom  = STR_TO_DATE(@Illness_LostTimeEndFrom , '%m/%d/%Y');
	SET @Illness_LostTimeEndFrom2 = DATE_ADD(@Illness_LostTimeEndFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND illness_LostTimeEnd >=  ',  "'", @Illness_LostTimeEndFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND illness_LostTimeEnd <  ', "'", @Illness_LostTimeEndFrom2  ,"'");	
END IF;
END IF;
SET @IncidentDateFrom =  extractvalue(xmlData, '//IncidentDateFrom');
SET @IncidentDateTo =  extractvalue(xmlData, '//IncidentDateTo');
IF(@IncidentDateTo != '') THEN
	SET @IncidentDateFrom  = STR_TO_DATE(@IncidentDateFrom , '%m/%d/%Y');
	SET @IncidentDateTo  = STR_TO_DATE(@IncidentDateTo , '%m/%d/%Y');
	SET @IncidentDateTo2 = DATE_ADD(@IncidentDateTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_IncidentDate >  ', "'" , @IncidentDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_IncidentDate <=  ', "'",  @IncidentDateTo2  ,"'" );										
ELSE 
IF(@IncidentDateTo = '' AND @IncidentDateFrom !='' ) THEN
	SET @IncidentDateFrom  = STR_TO_DATE(@IncidentDateFrom , '%m/%d/%Y');
	SET @IncidentDateFrom2 = DATE_ADD(@IncidentDateFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_IncidentDate >=  ',  "'", @IncidentDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_IncidentDate <  ', "'", @IncidentDateFrom2  ,"'");	
END IF;
END IF;
SET @EstimatedCostTo =  extractvalue(xmlData, '//ImpactEstimatedCostTo');
SET @EstimatedCostFrom =  extractvalue(xmlData, '//ImpactEstimatedCostFrom');
IF( @EstimatedCostTo !='' ) THEN
	SET @queryWhere = CONCAT(@queryWhere,' AND  all_impact_types_EstimatedCost  BETWEEN ', @EstimatedCostFrom, ' and ', @EstimatedCostTo);
ELSE 
	IF( @EstimatedCostFrom !=''  and @EstimatedCostFrom != 'NULL')	 THEN
set  @EstimatedCostFrom  = (replace(@EstimatedCostFrom, '&lt;', '<'));
set  @EstimatedCostFrom  = (replace(@EstimatedCostFrom, '&gt;', '>'));
		SET @queryWhere = CONCAT(@queryWhere,' AND  all_impact_types_EstimatedCost  ', @EstimatedCostFrom);
	END IF;
END IF;
/*
SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere , @queryhave);
select @query;
SET @querycount =  CONCAT( 'SELECT count(*) into @cnt from  (', @query, ' ) t');
PREPARE stmt1 FROM @querycount;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
SET @selectquery = CONCAT (@selectquery,', ', @cnt, ' as Count ');
*/
SET @queryFrom = " from OptimizeGetAllImpacts_vw "; -- by Mohamed Fathy
SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere , @queryhave);
IF (@index  = 'incident_Location1Id' 		or @index  = 'Location1Id') 		then set @index= 'location1_Location1Name'; end if; 
IF (@index  = 'incident_Location2Id' 		or @index  = 'Location2Id') 		then set @index= 'location2_Location2Name'; end if;  
IF (@index  = 'incident_Location3Id' 		or @index  = 'Location3Id')		 	then set @index= 'location3_Location3Name'; end if; 
IF (@index  = 'incident_Location4Id' 		or @index  = 'Location4Id') 		then set @index= 'location4_Location4Name'; end if; 
IF (@index  = 'incident_OperationTypeId' 	or @index  = 'OperationTypeId') 	then set @index= 'operation_type_OperationTypeName'; end if;  
IF (@index  = 'incident_RiskOfRecurrenceId' or @index  = 'RiskOfRecurrenceId') 	then set @index= 'risk_of_recurrence_RiskOfRecurrenceName'; end if;  
IF (@index  = 'incident_IncidentSeverityId' or @index  = 'IncidentSeverityId') 	then set @index= 'incident_severity_IncidentSeverityName'; end if;  
IF (@index  = 'incident_InvStatusId' 		or @index  = 'InvStatusId') 		then set@index='inv_status_InvStatusName'; end if;
IF(@index  = 'IncidentId'  or @index  = 'IncidentDate'  or @index  = 'IncidentHour'  or @index  = 'IncidentMinute'  or @index  = 'IsEmerRP'  or @inde  = 'RepName'  or @index  = 'RepEmail'  or @index  = 'RepPosition'  or @index  = 'RepCompany'  or @index  = 'RepPrimaryPhone'  or @index  = 'RepAlternatePhone'  or @index  = 'OtherLocation'  or @index  = 'OperationTypeId'  or @index  = 'EventSequence'  or @index  = 'EnvConditionNote'  or @index  = 'IncDescription'  or @index  = 'EnergyFormNote'  or @index  = 'SubStorardActionNote'  or @index  = 'SubStorardConditionNote'  or @index  = 'UnderLyingCauseNote'  or @index  = 'InvestigationDate'  or @index  = 'InvestigatorName1'  or @index  = 'InvestigatorName2'  or @index  = 'InvestigatorName3'  or @index  = 'InvSummary'  or @index  = 'FollowUpNote'  or @index  = 'ResponseCost'  or @index  = 'RepairCost'  or @index  = 'InsuranceCost'  or @index  = 'WCBCost'  or @index  = 'OtherCost'  or @index  = 'TotalCost'  or @index  = 'SourceDetails'  or @index  = 'RootCauseNote'  or @index  = 'SignOffInvestigatorName'  or @index  = 'SignOffDate'  or @index  = 'IncidentNumber' ) then
	SET @index=  CONCAT('incident_' , @index);
END IF;
-- if(@index ='CreatorName') then	set @index ='CreatorId'; end if;
-- if(@index ='UpdatedByName') then	set @index ='UpdatedByName'; end if;
SET @groupby = ' GROUP BY all_impact_types_ImpactId ';
SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere , @groupby , @queryhave);
SET @query = CONCAT(@query, ' order by ', @index,'  ', @sortOrder);
if( @Export ="FALSE") then
SET @page = (@page - 1) * @limit;
SET @query = CONCAT(@query, ' LIMIT ', @limit ,' OFFSET ',  @page);
end if;
-- select @query;
PREPARE stmt1 FROM @query;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
SELECT FOUND_ROWS();
END;
