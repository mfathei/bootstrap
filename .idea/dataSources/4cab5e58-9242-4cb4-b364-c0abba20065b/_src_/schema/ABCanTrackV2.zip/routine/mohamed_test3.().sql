CREATE PROCEDURE ABCanTrackV2.mohamed_test3()
  begin
-- declare $sm varchar(255);
set @sm = (select OperationTypeName from ABCanTrackV2.`operation_type` where OperationTypeId = 'multilanguage-faefa9d6-00bd-11e6-9118-525400adf91d');
select @sm;
end;
