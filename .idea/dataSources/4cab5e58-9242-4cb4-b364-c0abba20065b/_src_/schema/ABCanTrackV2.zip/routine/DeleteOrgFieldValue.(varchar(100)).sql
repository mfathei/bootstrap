CREATE PROCEDURE ABCanTrackV2.DeleteOrgFieldValue(IN `$OrgId` VARCHAR(100))
  BEGIN
	DECLARE $Count INT;
    
    
    -- Step1: field_value
	SET $Count = (SELECT COUNT(*) FROM field_value WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId));
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgFieldValue',  'field_value', NULL, $Count, 1);
    
	-- ************
	DELETE FROM field_value WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId);
    -- #
    
    -- Step2: DONE
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgFieldValue', 'DONE', NULL, NULL, 2);
    -- #    
    
END;
