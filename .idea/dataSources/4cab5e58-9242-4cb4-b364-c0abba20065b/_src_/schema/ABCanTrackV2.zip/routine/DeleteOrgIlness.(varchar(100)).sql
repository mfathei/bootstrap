CREATE PROCEDURE ABCanTrackV2.DeleteOrgIlness(IN `$OrgId` VARCHAR(100))
  BEGIN
	DECLARE $Count INT;
    
    -- Step1: illness_symptoms
	SET $Count = (SELECT COUNT(*) FROM illness_symptoms WHERE IllnessId IN (SELECT IllnessId FROM illness WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId)));
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgIlness',  'illness_symptoms', NULL, $Count, 1);
    
	-- ************
	DELETE FROM illness_symptoms WHERE IllnessId IN (SELECT IllnessId FROM illness WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId));
    -- #
    
    
    -- Step2: impacts_ext_agency
	SET $Count = (SELECT COUNT(*) FROM impacts_ext_agency WHERE IllnessId IN (SELECT IllnessId FROM illness WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId)));
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgIlness',  'impacts_ext_agency', NULL, $Count, 2);
    
	-- ************
	DELETE FROM impacts_ext_agency WHERE IllnessId IN (SELECT IllnessId FROM illness WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId));
    -- #
    
    
    -- Step3: illness
	SET $Count = (SELECT COUNT(*) FROM illness WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId));
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgIlness',  'illness', NULL, $Count, 3);
    
	-- ************
	DELETE FROM illness WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId);
    -- #
    
    -- Step4: DONE
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgIlness', 'DONE', NULL, NULL, 4);
    -- # 
    
END;
