CREATE FUNCTION ABCanTrackV2.getImpactDescription(`$TrafficViolationId`         VARCHAR(100),
                                                  `$OriginalTrafficViolationId` VARCHAR(100))
  RETURNS TEXT
  BEGIN
IF $OriginalTrafficViolationId is null   or $OriginalTrafficViolationId  =''   then
	SET $OriginalTrafficViolationId = $TrafficViolationId ;
END IF;
SET SESSION group_concat_max_len = 10000;
SELECT (GROUP_CONCAT(DATE_FORMAT(UpdatedDate, '%b %d %Y') ,' ', '(',  CONCAT(firstname ,' ', lastname) ,')',': <pr>', ImpactDescription separator '<br><br>' ) ) AS ImpactDescription   
 INTO @newImpactDescription 
 FROM(
 SELECT UpdatedDate, ImpactDescription, firstname,lastname FROM hist_traffic_violation hi 
JOIN employee e ON e.EmployeeId = hi.UpdatedbyId
 WHERE OriginalTrafficViolationId = $OriginalTrafficViolationId  
ORDER BY UpdatedDate asc  ) temp ; 
RETURN @newImpactDescription;
END;
