CREATE FUNCTION ABCanTrackV2.last_sent_date_fun(`$EmployeeId` VARCHAR(100), `$GroupId` VARCHAR(100))
  RETURNS DATETIME
  BEGIN
DECLARE $Ret DATETIME;

IF ($GroupId IS NULL OR $GroupId = '')
THEN

	SET $Ret = (SELECT MAX(SentDate) FROM email_log WHERE SendToEmployeeId = $EmployeeId);
ELSEIF ($EmployeeId IS NULL OR $EmployeeId = '')
THEN
	SET $Ret = (SELECT MAX(SentDate) FROM email_log WHERE SendToGroupId = $GroupId);
END IF;
RETURN $Ret;
END;
