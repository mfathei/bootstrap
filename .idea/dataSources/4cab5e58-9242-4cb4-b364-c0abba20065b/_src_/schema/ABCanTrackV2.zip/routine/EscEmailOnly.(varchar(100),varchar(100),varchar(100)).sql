CREATE FUNCTION ABCanTrackV2.EscEmailOnly(`$EmployeeId` VARCHAR(100), `$GroupId` VARCHAR(100), `$OrgId` VARCHAR(100))
  RETURNS TEXT
  BEGIN
DECLARE $DaysFrq TEXT;

 IF $GroupId is null
		then 
			SET $DaysFrq = (SELECT DaysFreq FROM email_to_esc WHERE EmployeeId = $EmployeeId AND OrgId = $OrgId AND TableName = 'corrective_action' LIMIT 1);
			IF $DaysFrq IS NOT NULL
			THEN
					SET $DaysFrq = 'Expired Corrective Actions';
			ELSE
					SET $DaysFrq = NULL;
            END IF;
            IF $DaysFrq IS NULL THEN
				SET $DaysFrq = (SELECT DaysFreq FROM email_to_esc WHERE EmployeeId = $EmployeeId AND OrgId = $OrgId AND TableName = 'incident' LIMIT 1);
					IF $DaysFrq IS NOT NULL THEN
						SET $DaysFrq = 'Investigations not yet Closed';
					END IF;
			ELSE
            
				SET $DaysFrq = (SELECT DaysFreq FROM email_to_esc WHERE EmployeeId = $EmployeeId AND OrgId = $OrgId AND TableName = 'incident' LIMIT 1);
				IF $DaysFrq IS NOT NULL THEN
					SET $DaysFrq = 'Expired Corrective Actions, Investigations not yet Closed';
				ELSE
					SET $DaysFrq = 'Expired Corrective Actions';
				END IF;
            END IF;
End If;
		
IF $EmployeeId is null
		then 
        
			SET $DaysFrq = (SELECT DaysFreq FROM email_to_esc WHERE GroupId = $GroupId AND OrgId = $OrgId AND TableName = 'corrective_action' LIMIT 1);
			IF $DaysFrq IS NOT NULL
			THEN
					SET $DaysFrq = 'Expired Corrective Actions';
			ELSE
					SET $DaysFrq = NULL;
            END IF;
            
            IF $DaysFrq IS NULL THEN
				SET $DaysFrq = (SELECT DaysFreq FROM email_to_esc WHERE GroupId = $GroupId AND OrgId = $OrgId AND TableName = 'incident' LIMIT 1);
					IF $DaysFrq IS NOT NULL THEN
						SET $DaysFrq = 'Investigations not yet Closed';
					END IF;
			ELSE
            
				SET $DaysFrq = (SELECT DaysFreq FROM email_to_esc WHERE GroupId = $GroupId AND OrgId = $OrgId AND TableName = 'incident' LIMIT 1);
				IF $DaysFrq IS NOT NULL THEN
					SET $DaysFrq = 'Expired Corrective Actions, Investigations not yet Closed';
				ELSE
					SET $DaysFrq = 'Expired Corrective Actions';
				END IF;
            END IF;
end If;
RETURN $DaysFrq;
END;
