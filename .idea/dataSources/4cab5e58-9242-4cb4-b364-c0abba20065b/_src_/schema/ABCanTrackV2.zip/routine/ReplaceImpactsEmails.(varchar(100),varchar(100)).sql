CREATE PROCEDURE ABCanTrackV2.ReplaceImpactsEmails(IN `$INCIDENTID` VARCHAR(100), IN `$ImpactSubTypeId` VARCHAR(100))
  BEGIN
set @query ="";
set @query =CONCAT(@query,"
	SELECT ImpactSubTypeId
		,ImpactTypeName AS ImpactTypeId
		,ImpactSubTypeName AS ImpactSubTypeId
		,IntEmployeeName1
		,IntEmployeeName2
		,IntEmployeeName3
		,IntEmployeeDept1
		,IntEmployeeDept2
		,IntEmployeeDept3
		,PrimRespondName
		,Description AS ImpactDescription
		,EstimatedCost AS ImpactEstimatedCost
		,ExtAgencyName AS ExtAgencyId
		,PersonalInjuredName
		,InitialTreatmentName AS InitialTreatmentId
		,ContactCodeName AS ContactCodeId
		,RecordableName AS RecordableId
		,RestrictedWorkName AS RestrictedWorkId
		,LostTimeStart
		,LostTimeEnd
		,AdjustmentDays
		,TotalDaysOff
		,ImpactTypeDescription
		,ContactAgencyName AS ContactAgencyId
		,PersonalAfflictedName
		,SourceName AS SourceId
		,DurationValue
		,DurationUnitName AS DurationUnitId
		,QuantityValue
		,QuantityUnitName AS QuantityUnitId
		,QuantityRecoveredValue
		,RecoveredUnitName AS RecoveredUnitId
		,WhatWasIt
		,HowDidSROccur
		,CASE IsReportable
			WHEN '0'
				THEN 'no'
			WHEN '1'
				THEN 'yes'
			END AS IsReportable
		,SpRelAgencyName AS ImpactsExtAgencyId
		,DriverName
		,DriverLicence
		,VehicleTypeName AS VehicleTypeId
		,VehicleLicence
		,HowDidThatDone
		,Details
		,ValueOfFine
		,TicketNumber
		,HowDidThatOccur
		,InjuryTypeName AS InjuryTypeId
		,BodyPartName
		,BodyAreaName
		,SymptomsName AS SymptomsId
		,ImpactTypeCode
	FROM (
		SELECT *
		FROM (
			(
				SELECT impact_sub_type.ImpactSubTypeId
					,`hist_impact`.`OriginalImpactId` AS `OriginalId`
					,NULL AS `PersonalInjuredId`
					,NULL AS `ContactCodeId`
					,NULL AS `RecordableId`
					,NULL AS `RestrictedWorkId`
					,NULL AS `InitialTreatmentId`
					,NULL AS `ContactAgencyId`
					,NULL AS `PersonalAfflictedId`
					,NULL AS `SourceId`
					,NULL AS `DurationUnitId`
					,NULL AS `QuantityUnitId`
					,NULL AS `RecoveredUnitId`
					,NULL AS `Reportable`
					,`hist_impact`.`IncidentId` AS `IncidentId`
					,`hist_impact`.`ImpactTypeName` AS `ImpactTypeName`
					,`hist_impact`.`ImpactSubTypeName` AS `ImpactSubTypeName`
					,`hist_impact`.`IntEmployeeName1` AS `IntEmployeeName1`
					,`hist_impact`.`IntEmployeeName2` AS `IntEmployeeName2`
					,`hist_impact`.`IntEmployeeName3` AS `IntEmployeeName3`
					,`hist_impact`.`IntEmployeeDept1` AS `IntEmployeeDept1`
					,`hist_impact`.`IntEmployeeDept2` AS `IntEmployeeDept2`
					,`hist_impact`.`IntEmployeeDept3` AS `IntEmployeeDept3`
					,`hist_impact`.`PrimRespondName` AS `PrimRespondName`
					,`hist_impact`.`ImpactDescription` AS `Description`
					,`hist_impact`.`EstimatedCost` AS `EstimatedCost`
					, replace(ExtAgencyName,';|',';') as ExtAgencyName
					,NULL AS `PersonalInjuredName`
					,NULL AS `InitialTreatmentName`
					,NULL AS `ContactCodeName`
					,NULL AS `RecordableName`
					,NULL AS `RestrictedWorkName`
					,NULL AS `LostTimeStart`
					,NULL AS `LostTimeEnd`
					,NULL AS `AdjustmentDays`
					,NULL AS `TotalDaysOff`
					,NULL AS `ImpactTypeDescription`
					,NULL AS `ContactAgencyName`
					,NULL AS `PersonalAfflictedName`
					,NULL AS `SourceName`
					,NULL AS `DurationValue`
					,NULL AS `DurationUnitName`
					,NULL AS `QuantityValue`
					,NULL AS `QuantityUnitName`
					,NULL AS `QuantityRecoveredValue`
					,NULL AS `RecoveredUnitName`
					,NULL AS `WhatWasIt`
					,NULL AS `HowDidSROccur`
					,NULL AS `IsReportable`
					,NULL AS `SpRelAgencyName`
					,NULL AS `DriverName`
					,NULL AS `DriverLicence`
					,NULL AS `VehicleTypeName`
					,NULL AS `VehicleLicence`
					,NULL AS `HowDidThatDone`
					,NULL AS `Details`
					,NULL AS `ValueOfFine`
					,NULL AS `TicketNumber`
					,NULL AS `HowDidThatOccur`
					,NULL AS `InjuryTypeName`
					,NULL AS `BodyPartName`
					,NULL AS `BodyAreaName`
					,NULL AS `VehicleTypeId`
					,NULL AS `SymptomsName`
					,impact_type.ImpactTypeCode AS ImpactTypeCode
				FROM `hist_impact`
                join impact on impact.ImpactId = hist_impact.ImpactId
                join impact_sub_type ON(impact.ImpactSubTypeId = impact_sub_type.ImpactSubTypeId)
                join impact_type on(impact_sub_type.ImpactTypeId=impact_type.ImpactTypeId)
				WHERE impact.IncidentId = '", $INCIDENTID ,"'");
                
                 IF ($ImpactSubTypeId != '' AND $ImpactSubTypeId !='NULL') THEN
                 SET @query =CONCAT(@query, "   and impact_sub_type.ImpactSubTypeId = '", $ImpactSubTypeId,"'");
                  END IF;
                  
			SET @query =CONCAT(@query,"	ORDER BY UpdatedDate DESC limit 1  )	UNION
			
			(
				SELECT impact_sub_type.ImpactSubTypeId
					,`OriginalInjuryId` AS `OriginalId`
					,NULL AS `PersonalInjuredId`
					,NULL AS `ContactCodeId`
					,NULL AS `RecordableId`
					,NULL AS `RestrictedWorkId`
					,NULL AS `InitialTreatmentId`
					,NULL AS `ContactAgencyId`
					,NULL AS `PersonalAfflictedId`
					,NULL AS `SourceId`
					,NULL AS `DurationUnitId`
					,NULL AS `QuantityUnitId`
					,NULL AS `RecoveredUnitId`
					,NULL AS `Reportable`
					,injury.`IncidentId`
					,`hist_injury`.`ImpactTypeName`
					,`hist_injury`.`ImpactSubTypeName`
					,`hist_injury`.`IntEmployeeName1`
					,`hist_injury`.`IntEmployeeName2`
					,`hist_injury`.`IntEmployeeName3`
					,`hist_injury`.`IntEmployeeDept1`
					,`hist_injury`.`IntEmployeeDept2`
					,`hist_injury`.`IntEmployeeDept3`
					,`hist_injury`.`PrimRespondName`
					,NULL AS `Description`
					,`hist_injury`.`EstimatedCost`
					, replace(ExtAgencyName,';|',';') as ExtAgencyName
					,`hist_injury`.`PersonalInjuredName`
					,`hist_injury`.`InitialTreatmentName`
					,`hist_injury`.`ContactCodeName`
					,`hist_injury`.`RecordableName`
					,`hist_injury`.`RestrictedWorkName`
					,DATE_FORMAT(`hist_injury`.`LostTimeStart`,  '%m/%d/%Y') AS `LostTimeStart`
					,DATE_FORMAT(`hist_injury`.`LostTimeEnd`,  '%m/%d/%Y') AS `LostTimeEnd`
					,`hist_injury`.`AdjustmentDays`
					,`hist_injury`.`TotalDaysOff`
					,NULL AS `ImpactTypeDescription`
					,`ContactAgencyName`
					,NULL AS `PersonalAfflictedName`
					,NULL AS `SourceName`
					,NULL AS `DurationValue`
					,NULL AS `DurationUnitName`
					,NULL AS `QuantityValue`
					,NULL AS `QuantityUnitName`
					,NULL AS `QuantityRecoveredValue`
					,NULL AS `RecoveredUnitName`
					,NULL AS `WhatWasIt`
					,NULL AS `HowDidSROccur`
					,NULL AS `IsReportable`
					,NULL AS `SpRelAgencyName`
					,NULL AS `DriverName`
					,NULL AS `DriverLicence`
					,NULL AS `VehicleTypeName`
					,NULL AS `VehicleLicence`
					,NULL AS `HowDidThatDone`
					,NULL AS `Details`
					,NULL AS `ValueOfFine`
					,NULL AS `TicketNumber`
					,NULL AS `HowDidThatOccur`
					,replace(InjuryTypeName,';|',';') as InjuryTypeName
					,replace(BodyPartName,';|',';') as BodyPartName
					,replace(`BodyAreaName`,';|',';') as  BodyAreaName
					,NULL AS `VehicleTypeId`
					,NULL AS `SymptomsName`
					,impact_type.ImpactTypeCode AS ImpactTypeCode
				FROM `hist_injury`
                join injury on injury.InjuryId = hist_injury.InjuryId
                join impact_sub_type ON(injury.ImpactSubTypeId = impact_sub_type.ImpactSubTypeId)
                join impact_type on(impact_sub_type.ImpactTypeId=impact_type.ImpactTypeId)
				WHERE injury.IncidentId = '", $INCIDENTID ,"'");
                
                
                 IF ($ImpactSubTypeId != '' AND $ImpactSubTypeId !='NULL') THEN
                 SET @query =CONCAT(@query, '   and impact_sub_type.ImpactSubTypeId = "', $ImpactSubTypeId,'" ');
                  END IF;
                
				SET @query =CONCAT(@query,"  	ORDER BY `UpdatedDate` DESC limit 1
				)
			
			UNION
			
			(
				SELECT impact_sub_type.ImpactSubTypeId
					,`OriginalIllnessId` AS `OriginalId`
					,NULL AS `PersonalInjuredId`
					,NULL AS `ContactCodeId`
					,NULL AS `RecordableId`
					,NULL AS `RestrictedWorkId`
					,NULL AS `InitialTreatmentId`
					,NULL AS `ContactAgencyId`
					,NULL AS `PersonalAfflictedId`
					,NULL AS `SourceId`
					,NULL AS `DurationUnitId`
					,NULL AS `QuantityUnitId`
					,NULL AS `RecoveredUnitId`
					,NULL AS `Reportable`
					,illness.`IncidentId`
					,`hist_illness`.`ImpactTypeName`
					,`hist_illness`.`ImpactSubTypeName`
					,`hist_illness`.`IntEmployeeName1`
					,`hist_illness`.`IntEmployeeName2`
					,`hist_illness`.`IntEmployeeName3`
					,`hist_illness`.`IntEmployeeDept1`
					,`hist_illness`.`IntEmployeeDept2`
					,`hist_illness`.`IntEmployeeDept3`
					,`hist_illness`.`PrimRespondName`
					,NULL AS `Description`
					,`hist_illness`.`EstimatedCost`
					, replace(ExtAgencyName,';|',';') as ExtAgencyName
					,NULL AS `PersonalInjuredName`
					,`hist_illness`.`InitialTreatmentName`
					,NULL AS `ContactCodeName`
					,NULL AS `RecordableName`
					,`RestrictedWorkName`
					,DATE_FORMAT(`hist_illness`.`LostTimeStart`, '%m/%d/%Y') AS `LostTimeStart`
        ,DATE_FORMAT(`hist_illness`.`LostTimeEnd`, '%m/%d/%Y') AS `LostTimeEnd`
					,`hist_illness`.`AdjustmentDays`
					,`hist_illness`.`TotalDaysOff`
					,NULL AS `ImpactTypeDescription`
					,NULL AS `ContactAgencyName`
					,`hist_illness`.`PersonalAfflictedName`
					,NULL AS `SourceName`
					,NULL AS `DurationValue`
					,NULL AS `DurationUnitName`
					,NULL AS `QuantityValue`
					,NULL AS `QuantityUnitName`
					,NULL AS `QuantityRecoveredValue`
					,NULL AS `RecoveredUnitName`
					,NULL AS `WhatWasIt`
					,NULL AS `HowDidSROccur`
					,NULL AS `IsReportable`
					,NULL AS `SpRelAgencyName`
					,NULL AS `DriverName`
					,NULL AS `DriverLicence`
					,NULL AS `VehicleTypeName`
					,NULL AS `VehicleLicence`
					,NULL AS `HowDidThatDone`
					,NULL AS `Details`
					,NULL AS `ValueOfFine`
					,NULL AS `TicketNumber`
					,NULL AS `HowDidThatOccur`
					,NULL AS `InjuryTypeName`
					,NULL AS `BodyPartName`
					,NULL AS `BodyAreaName`
					,NULL AS `VehicleTypeId`
					, replace(SymptomsName,';|',';') AS SymptomsName
					,impact_type.ImpactTypeCode AS ImpactTypeCode
				FROM `hist_illness`
                join illness on illness.IllnessId = hist_illness.IllnessId
                join impact_sub_type ON(illness.ImpactSubTypeId = impact_sub_type.ImpactSubTypeId)
                join impact_type on(impact_sub_type.ImpactTypeId=impact_type.ImpactTypeId)
				WHERE illness.IncidentId = '", $INCIDENTID ,"'");
                
                 IF ($ImpactSubTypeId != '' AND $ImpactSubTypeId !='NULL') THEN
                 SET @query =CONCAT(@query, '   and impact_sub_type.ImpactSubTypeId = "', $ImpactSubTypeId,'" ');
                  END IF;
                
				SET @query =CONCAT(@query,"
				ORDER BY `UpdatedDate` DESC limit 1
				)
			
			UNION
			
			(
				SELECT impact_sub_type.ImpactSubTypeId
					,`OriginalTrafficViolationId` AS `OriginalId`
					,NULL AS `PersonalInjuredId`
					,NULL AS `ContactCodeId`
					,NULL AS `RecordableId`
					,NULL AS `RestrictedWorkId`
					,NULL AS `InitialTreatmentId`
					,NULL AS `ContactAgencyId`
					,NULL AS `PersonalAfflictedId`
					,NULL AS `SourceId`
					,NULL AS `DurationUnitId`
					,NULL AS `QuantityUnitId`
					,NULL AS `RecoveredUnitId`
					,NULL AS `Reportable`
					,traffic_violation.`IncidentId`
					,impact_type.`ImpactTypeName`
					,impact_sub_type.`ImpactSubTypeName`
					,`hist_traffic_violation`.`IntEmployeeName1`
					,`hist_traffic_violation`.`IntEmployeeName2`
					,`hist_traffic_violation`.`IntEmployeeName3`
					,`hist_traffic_violation`.`IntEmployeeDept1`
					,`hist_traffic_violation`.`IntEmployeeDept2`
					,`hist_traffic_violation`.`IntEmployeeDept3`
					,`hist_traffic_violation`.`PrimRespondName`
					,NULL AS `Description`
					,`hist_traffic_violation`.`EstimatedCost`
					, replace(ExtAgencyName,';|',';') as ExtAgencyName
					,NULL AS `PersonalInjuredName`
					,NULL AS `InitialTreatmentName`
					,NULL AS `ContactCodeName`
					,NULL AS `RecordableName`
					,NULL AS `RestrictedWorkName`
					,NULL AS `LostTimeStart`
					,NULL AS `LostTimeEnd`
					,NULL AS `AdjustmentDays`
					,NULL AS `TotalDaysOff`
					,NULL AS `ImpactTypeDescription`
					,NULL AS `ContactAgencyName`
					,NULL AS `PersonalAfflictedName`
					,NULL AS `SourceName`
					,NULL AS `DurationValue`
					,NULL AS `DurationUnitName`
					,NULL AS `QuantityValue`
					,NULL AS `QuantityUnitName`
					,NULL AS `QuantityRecoveredValue`
					,NULL AS `RecoveredUnitName`
					,NULL AS `WhatWasIt`
					,NULL AS `HowDidSROccur`
					,NULL AS `IsReportable`
					,NULL AS `SpRelAgencyName`
					,`hist_traffic_violation`.`DriverName`
					,`hist_traffic_violation`.`DriverLicence`
					,`hist_traffic_violation`.`VehicleTypeName`
					,`hist_traffic_violation`.`VehicleLicence`
					,NULL AS `HowDidThatDone`
					,`hist_traffic_violation`.`Details`
					,`hist_traffic_violation`.`ValueOfFine`
					,`hist_traffic_violation`.`TicketNumber`
					,`hist_traffic_violation`.`HowDidThatOccur`
					,NULL AS `InjuryTypeName`
					,NULL AS `BodyPartName`
					,NULL AS `BodyAreaName`
					,NULL AS `VehicleTypeId`
					,NULL AS `SymptomsName`
					,impact_type.ImpactTypeCode AS ImpactTypeCode
				FROM `hist_traffic_violation`
                join traffic_violation on traffic_violation.TrafficViolationId = hist_traffic_violation.TrafficViolationId
                join impact_sub_type ON(traffic_violation.ImpactSubTypeId = impact_sub_type.ImpactSubTypeId)
                join impact_type on(impact_sub_type.ImpactTypeId=impact_type.ImpactTypeId)
				WHERE traffic_violation.IncidentId = '", $INCIDENTID ,"'");
                
                 IF ($ImpactSubTypeId != '' AND $ImpactSubTypeId !='NULL') THEN
                 SET @query =CONCAT(@query, '   and impact_sub_type.ImpactSubTypeId = "', $ImpactSubTypeId,'" ');
                  END IF;
                
				SET @query =CONCAT(@query,"
				ORDER BY `UpdatedDate` DESC limit 1
				)
			
			UNION
			
			(
				SELECT impact_sub_type.ImpactSubTypeId
					,`HistSpillReleaseId` AS `OriginalId`
					,NULL AS `PersonalInjuredId`
					,NULL AS `ContactCodeId`
					,NULL AS `RecordableId`
					,NULL AS `RestrictedWorkId`
					,NULL AS `InitialTreatmentId`
					,NULL AS `ContactAgencyId`
					,NULL AS `PersonalAfflictedId`
					,NULL AS `SourceId`
					,NULL AS `DurationUnitId`
					,NULL AS `QuantityUnitId`
					,NULL AS `RecoveredUnitId`
					,NULL AS `Reportable`
					,spill_release.`IncidentId`
					,impact_type.`ImpactTypeName`
					,impact_sub_type.`ImpactSubTypeName`
					,`hist_spill_release`.`IntEmployeeName1`
					,`hist_spill_release`.`IntEmployeeName2`
					,`hist_spill_release`.`IntEmployeeName3`
					,`hist_spill_release`.`IntEmployeeDept1`
					,`hist_spill_release`.`IntEmployeeDept2`
					,`hist_spill_release`.`IntEmployeeDept3`
					,`hist_spill_release`.`PrimRespondName`
					,NULL AS `Description`
					,`hist_spill_release`.`EstimatedCost`
					, replace(ExtAgencyName,';|',';') as ExtAgencyName
					,NULL AS `PersonalInjuredName`
					,NULL AS `InitialTreatmentName`
					,NULL AS `ContactCodeName`
					,NULL AS `RecordableName`
					,NULL AS `RestrictedWorkName`
					,NULL AS `LostTimeStart`
					,NULL AS `LostTimeEnd`
					,NULL AS `AdjustmentDays`
					,NULL AS `TotalDaysOff`
					,NULL AS `ImpactTypeDescription`
					,NULL AS `ContactAgencyName`
					,NULL AS `PersonalAfflictedName`
					,`hist_spill_release`.`SourceName`
					,`hist_spill_release`.`DurationValue`
					,NULL AS `DurationUnitName`
					,`hist_spill_release`.`QuantityValue`
					,NULL AS `QuantityUnitName`
					,`hist_spill_release`.`QuantityRecoveredValue`
					,NULL AS `RecoveredUnitName`
					,`hist_spill_release`.`WhatWasIt`
					,`hist_spill_release`.`HowDidSROccur`
					,`hist_spill_release`.`IsReportable`
					,NULL AS `SpRelAgencyName`
					,NULL AS `DriverName`
					,NULL AS `DriverLicence`
					,NULL AS `VehicleTypeName`
					,NULL AS `VehicleLicence`
					,NULL AS `HowDidThatDone`
					,NULL AS `Details`
					,NULL AS `ValueOfFine`
					,NULL AS `TicketNumber`
					,NULL AS `HowDidThatOccur`
					,NULL AS `InjuryTypeName`
					,NULL AS `BodyPartName`
					,NULL AS `BodyAreaName`
					,NULL AS `VehicleTypeId`
					,NULL AS `SymptomsName`
					,impact_type.ImpactTypeCode AS ImpactTypeCode
				FROM `hist_spill_release`
                 join spill_release on spill_release.SpillReleaseId = hist_spill_release.SpillReleaseId
                join impact_sub_type ON(spill_release.ImpactSubTypeId = impact_sub_type.ImpactSubTypeId)
                join impact_type on(impact_sub_type.ImpactTypeId=impact_type.ImpactTypeId)
				WHERE spill_release.IncidentId = '", $INCIDENTID ,"'");
                 IF ($ImpactSubTypeId != '' AND $ImpactSubTypeId !='NULL') THEN
                 SET @query =CONCAT(@query, '   and impact_sub_type.ImpactSubTypeId = "', $ImpactSubTypeId,'" ');
                  END IF;
                
				SET @query =CONCAT(@query,"
				ORDER BY `UpdatedDate` DESC limit 1
				)
			
			UNION
			
			(
				SELECT impact_sub_type.ImpactSubTypeId
					,OriginalVehicleDamageId AS OriginalId
					,NULL AS PersonalInjuredId
					,NULL AS ContactCodeId
					,NULL AS RecordableId
					,NULL AS RestrictedWorkId
					,NULL AS InitialTreatmentId
					,NULL AS ContactAgencyId
					,NULL AS PersonalAfflictedId
					,NULL AS SourceId
					,NULL AS DurationUnitId
					,NULL AS QuantityUnitId
					,NULL AS RecoveredUnitId
					,NULL AS Reportable
					,vehicle_damage.IncidentId
					,impact_type.ImpactTypeName
					,impact_sub_type.ImpactSubTypeName
					,`hist_vehicle_damage`.IntEmployeeName1
					,`hist_vehicle_damage`.IntEmployeeName2
					,`hist_vehicle_damage`.IntEmployeeName3
					,`hist_vehicle_damage`.IntEmployeeDept1
					,`hist_vehicle_damage`.IntEmployeeDept2
					,`hist_vehicle_damage`.IntEmployeeDept3
					,`hist_vehicle_damage`.PrimRespondName
					,NULL AS Description
					,`hist_vehicle_damage`.EstimatedCost
					, replace(ExtAgencyName,';|',';') as ExtAgencyName
					,NULL AS PersonalInjuredName
					,NULL AS InitialTreatmentName
					,NULL AS ContactCodeName
					,NULL AS RecordableName
					,NULL AS RestrictedWorkName
					,NULL AS LostTimeStart
					,NULL AS LostTimeEnd
					,NULL AS AdjustmentDays
					,NULL AS TotalDaysOff
					,NULL AS ImpactTypeDescription
					,NULL AS ContactAgencyName
					,NULL AS PersonalAfflictedName
					,NULL AS SourceName
					,NULL AS DurationValue
					,NULL AS DurationUnitName
					,NULL AS QuantityValue
					,NULL AS QuantityUnitName
					,NULL AS QuantityRecoveredValue
					,NULL AS RecoveredUnitName
					,NULL AS WhatWasIt
					,NULL AS HowDidSROccur
					,NULL AS IsReportable
					,NULL AS SpRelAgencyName
					,`hist_vehicle_damage`.DriverName
					,`hist_vehicle_damage`.DriverLicence
					,`hist_vehicle_damage`.VehicleTypeName
					,`hist_vehicle_damage`.VehicleLicence
					,`hist_vehicle_damage`.HowDidThatDone
					,NULL AS Details
					,NULL AS ValueOfFine
					,NULL AS TicketNumber
					,NULL AS HowDidThatOccur
					,NULL AS InjuryTypeName
					,NULL AS BodyPartName
					,NULL AS BodyAreaName
					,NULL AS VehicleTypeId
					,NULL AS SymptomsName
					,impact_type.ImpactTypeCode AS ImpactTypeCode
				FROM `hist_vehicle_damage`
                join vehicle_damage on vehicle_damage.VehicleDamageId = hist_vehicle_damage.VehicleDamageId
                join impact_sub_type ON(vehicle_damage.ImpactSubTypeId = impact_sub_type.ImpactSubTypeId)
                join impact_type on(impact_sub_type.ImpactTypeId=impact_type.ImpactTypeId)
				WHERE vehicle_damage.IncidentId = '", $INCIDENTID ,"'");
                
				IF ($ImpactSubTypeId != '' AND $ImpactSubTypeId !='NULL') THEN
					SET @query =CONCAT(@query, '   and impact_sub_type.ImpactSubTypeId = "', $ImpactSubTypeId,'" ');
				END IF;
                
				SET @query =CONCAT(@query,"
				ORDER BY `UpdatedDate` DESC limit 1
				)
			) allqry
		) impacts");
-- select  @query;
PREPARE stmt1 FROM @query;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
	END;
