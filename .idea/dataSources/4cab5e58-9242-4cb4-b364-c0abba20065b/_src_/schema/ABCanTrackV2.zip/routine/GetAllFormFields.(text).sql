CREATE PROCEDURE ABCanTrackV2.GetAllFormFields(IN xmlData TEXT)
  BEGIN
 DECLARE $ids TEXT;
 
 SET @@group_concat_max_len = 10240;
 
SET @Orgid = extractvalue(xmlData, '//OrgId');
SET @page = extractvalue(xmlData, '//page');
SET @limit = extractvalue(xmlData, '//limit');
SET @sortOrder =  extractvalue(xmlData, '//sortOrder');
SET @index =  extractvalue(xmlData, '//index');
SET @Mine =  extractvalue(xmlData, '//Mine');
SET @CreatorId = extractvalue(xmlData, '//CreatorId');
SET @Export =  extractvalue(xmlData, '//Export');
SET @LanguageCode =  extractvalue(xmlData, '//LanguageCode');
SET @lblYes = (select GetItemLabel(@LanguageCode,'isreportableyes'));
SET @lblNo = (select GetItemLabel(@LanguageCode,'isreportableno'));
SET @ShowDefaultFields =  extractvalue(xmlData, '//ShowDefaultFields');
SET @ShowCustomFields =  extractvalue(xmlData, '//ShowCustomFields');
set @selectquery =concat('SELECT FieldName, org_field.FieldId, HelpMeDescription as HelpDesc, DefaultFieldLabel , org_field.FieldLabel, SubTabLabel, HelpMeName as HelpTitle,SubTabName, CASE org_field.IsHidden WHEN '0' THEN '',@lblNo,'' WHEN '1' THEN '', @lblYes,'' END  as IsHidden, FieldTypeName, FieldDescription, CASE org_field.IsMandatory WHEN '0' THEN '',@lblNo,'' WHEN '1' THEN '', @lblYes,'' END  as IsMandatory, CASE field.IsMandatory WHEN '0' THEN '0' WHEN '1' THEN '1' END AS DefaultMandatory,field.`Order`, field.AdminNotes, CASE org_field.IsHidden  WHEN '0' THEN '0' WHEN '1' THEN '1' END  as Hidde  ');
   
 
SET @selectquery = CONCAT(@selectquery,', CASE FieldName 
WHEN 'EventTypeId' THEN (select  group_concat( distinct EventTypeName separator ', ' ) from event_type  where  event_type.Hide= 0  and event_type.orgid = '',    @Orgid ,'' )  
WHEN 'OperationTypeId' THEN (select  group_concat( distinct OperationTypeName separator ', ' ) from operation_type  where  operation_type.Hide= 0 and  operation_type.orgid = '',    @Orgid ,'' )   
WHEN 'Location1Id' THEN (select  group_concat( distinct Location1Name separator ', ' ) from location_view  where  location_view.Location1Hide= 0 and  location_view.orgid =  '',    @Orgid ,'' )  
WHEN 'Location2Id' THEN (select  group_concat( distinct Location2Name separator ', ' ) from location_view  where  location_view.Location2Hide= 0 and  location_view.orgid = '',    @Orgid ,'' )  
WHEN 'Location3Id' THEN (select  group_concat( distinct Location3Name separator ', ' ) from location_view  where  location_view.Location3Hide= 0 and  location_view.orgid =  '',    @Orgid ,'' )  
WHEN 'Location4Id' THEN (select  group_concat( distinct Location4Name separator ', ' ) from location_view  where  location_view.Location4Hide= 0 and  location_view.orgid =  '',    @Orgid ,'' )  
WHEN 'RiskOfRecurrenceId' THEN (select  group_concat( distinct RiskOfRecurrenceName separator ', ' ) from risk_of_recurrence  where  risk_of_recurrence.Hide= 0 and  risk_of_recurrence.orgid = '',    @Orgid ,'' )  
WHEN 'IncidentSeverityId' THEN (select  group_concat( distinct IncidentSeverityName separator ', ' ) from incident_severity  where  incident_severity.Hide= 0 and  incident_severity.orgid = '',    @Orgid ,'' )  
WHEN 'RootCauseParamId' THEN (select  group_concat( distinct RootCauseParamName separator ', ' ) from root_cause_param inner join root_cause on root_cause.RootCauseId = root_cause_param.RootCauseId   where  root_cause_param.Hide= 0 and root_cause.Hide= 0  and  root_cause.orgid = '',    @Orgid ,'' )  
WHEN 'EnvConditions' THEN (select  group_concat( distinct EnvCondParameterName separator ', ' ) from env_cond_parameter inner join env_condition on env_condition.EnvConditionId = env_cond_parameter.EnvConditionId   where  env_cond_parameter.Hide= 0 and  env_condition.Hide= 0  and  env_condition.orgid = '',    @Orgid ,'' )  
WHEN 'ExtAgencyId' THEN (select  group_concat( distinct ExtAgencyName separator ', ' ) from external_agency  where  external_agency.Hide= 0 and  external_agency.orgid = '',    @Orgid ,'' )  
WHEN 'InjuryExtAgencyId' THEN (select  group_concat( distinct ContactAgencyName separator ', ' ) from contact_agency  where  contact_agency.Hide= 0 and  contact_agency.orgid = '',    @Orgid ,'' )  
WHEN 'BodyAreaId' THEN (select  group_concat( distinct BodyAreaName separator ', ' ) from body_area  where  body_area.Hide= 0 and  body_area.orgid = '',    @Orgid ,'' )  
WHEN 'BodyPartId' THEN (select  group_concat( distinct BodyPartName separator ', ' ) from body_part  where  body_part.Hide= 0 and  body_part.orgid = '',    @Orgid ,'' )  
WHEN 'CertificateId' THEN (select  group_concat( distinct CertificateName separator ', ' ) from certificate  where  certificate.Hide= 0 and   certificate.orgid = '',    @Orgid ,'' )  
WHEN 'ContactAgencyId' THEN (select  group_concat( distinct ContactAgencyName separator ', ' ) from contact_agency  where  contact_agency.Hide= 0 and  contact_agency.orgid = '',    @Orgid ,'' )  
WHEN 'ContactCodeId' THEN (select  group_concat( distinct ContactCodeName separator ', ' ) from contact_code  where  contact_code.Hide= 0 and  contact_code.orgid = '',    @Orgid ,'' )  
WHEN 'CorrActStatusId' THEN (select  group_concat( distinct CorrActStatusName separator ', ' ) from corr_act_status  where  corr_act_status.Hide= 0 and  corr_act_status.orgid = '',    @Orgid ,'' )  
WHEN 'DurationUnitId' THEN (select  group_concat( distinct DurationUnitName separator ', ' ) from duration_unit  where  duration_unit.Hide= 0 and  duration_unit.orgid = '',    @Orgid ,'' )  
WHEN 'SymptomsId' THEN (select  group_concat( distinct Description separator ', ' ) from symptoms  where  symptoms.Hide= 0 and  symptoms.orgid = '',    @Orgid ,'' )  
WHEN 'InvStatusId' THEN (select  group_concat( distinct InvStatusName separator ', ' ) from inv_status  where  inv_status.Hide= 0 and  inv_status.orgid = '',    @Orgid ,'' )  
WHEN 'SubActions' THEN (select  group_concat( distinct ObservationAndAnalysisParamName separator ', ' ) from observation_analysis_param inner join observation_analysis on observation_analysis_param.ObservationAndAnalysisId = observation_analysis.ObservationAndAnalysisId   where  observation_analysis_param.Hide= 0 and   ObservationAndAnalysisCode ='SubActions' and observation_analysis.orgid = '',    @Orgid ,'' ) 
WHEN 'UnderLyingCauses' THEN (select  group_concat( distinct ObservationAndAnalysisParamName separator ', ' ) from observation_analysis_param inner join observation_analysis on observation_analysis_param.ObservationAndAnalysisId = observation_analysis.ObservationAndAnalysisId   where  observation_analysis_param.Hide= 0  and   ParentId is null   and   ObservationAndAnalysisCode ='UnderLyingCauses' and observation_analysis.orgid = '',    @Orgid ,'' ) 
WHEN 'EnergyForm' THEN (select  group_concat( distinct ObservationAndAnalysisParamName separator ', ' ) from observation_analysis_param inner join observation_analysis on observation_analysis_param.ObservationAndAnalysisId = observation_analysis.ObservationAndAnalysisId   where  observation_analysis_param.Hide= 0 and   ParentId is null  and  ObservationAndAnalysisCode ='EnergyForm' and observation_analysis.orgid = '',    @Orgid ,'' ) 
WHEN 'SubConditions' THEN (select  group_concat( distinct ObservationAndAnalysisParamName separator ', ' ) from observation_analysis_param inner join observation_analysis on observation_analysis_param.ObservationAndAnalysisId = observation_analysis.ObservationAndAnalysisId   where  observation_analysis_param.Hide= 0 and   ObservationAndAnalysisCode ='SubConditions' and observation_analysis.orgid = '',    @Orgid ,'' ) 
WHEN 'ImpactTypeId' THEN (select  group_concat( distinct ImpactTypeName separator ', ' ) from impact_type  where  impact_type.Hide= 0 and  impact_type.orgid = '',    @Orgid ,'' )    
WHEN 'IncidentSeverityId' THEN (select  group_concat( distinct IncidentSeverityName separator ', ' ) from incident_severity  where  incident_severity.Hide= 0 and  incident_severity.orgid = '',    @Orgid ,'' ) 
WHEN 'InitialTreatmentId' THEN (select  group_concat( distinct InitialTreatmentName separator ', ' ) from initial_treatment  where  initial_treatment.Hide= 0 and  initial_treatment.orgid = '',    @Orgid ,'' ) 
WHEN 'Illness_InitialTreatmentId' THEN (select  group_concat( distinct InitialTreatmentName separator ', ' ) from initial_treatment  where  initial_treatment.Hide= 0 and  initial_treatment.orgid = '',    @Orgid ,'' ) 
WHEN 'RecordableId' THEN (select  group_concat( distinct RecordableName separator ', ' ) from injury_recordable  where  injury_recordable.Hide= 0 and  injury_recordable.orgid = '',    @Orgid ,'' ) 
WHEN 'InjuryTypeId' THEN (select  group_concat( distinct InjuryTypeName separator ', ' ) from injury_type  where  injury_type.Hide= 0 and  injury_type.orgid = '',    @Orgid ,'' ) 
WHEN 'OEDepartmentId' THEN (select  group_concat( distinct OEDepartmentName separator ', ' ) from oe_department  where  oe_department.Hide= 0 and  oe_department.orgid = '',    @Orgid ,'' ) 
WHEN 'PriorityId' THEN (select  group_concat( distinct PriorityName separator ', ' ) from priority  where  priority.Hide= 0 and  priority.orgid = '',    @Orgid ,'' ) 
WHEN 'QuantityUnitId' THEN (select  group_concat( distinct QuantityUnitName separator ', ' ) from quantity_unit  where  quantity_unit.Hide= 0 and  quantity_unit.orgid = '',    @Orgid ,'' ) 
WHEN 'RecoveredUnitId' THEN (select  group_concat( distinct QuantityUnitName separator ', ' ) from quantity_unit  where  quantity_unit.Hide= 0 and  quantity_unit.orgid = '',    @Orgid ,'' ) 
WHEN 'Illness_RestrictedWorkId' THEN (select  group_concat( distinct RestrictedWorkName separator ', ' ) from restricted_work  where  restricted_work.Hide= 0 and  restricted_work.orgid = '',    @Orgid ,'' ) 
WHEN 'Injury_RestrictedWorkId' THEN (select  group_concat( distinct RestrictedWorkName separator ', ' ) from restricted_work  where  restricted_work.Hide= 0 and  restricted_work.orgid = '',    @Orgid ,'' ) 
WHEN 'ImpactsExtAgencyId' THEN (select  group_concat( distinct SpRelAgencyName separator ', ' ) from sp_rel_agency  where  sp_rel_agency.Hide= 0 and  sp_rel_agency.orgid = '',    @Orgid ,'' ) 
WHEN 'SourceId' THEN (select  group_concat( distinct SourceName separator ', ' ) from spill_release_source  where  spill_release_source.Hide= 0 and  spill_release_source.orgid = '',    @Orgid ,'' ) 
WHEN 'ImpactSubTypeId' THEN (select  group_concat( distinct ImpactSubTypeName separator ', ' ) from impact_sub_type inner join impact_type on impact_sub_type.ImpactTypeId = impact_type.ImpactTypeId   where  impact_sub_type.Hide= 0  and  impact_type.Hide= 0  and  impact_type.orgid = '',    @Orgid ,'' ) 
WHEN 'DamageVehicleTypeId' THEN (select  group_concat( distinct VehicleTypeName separator ', ' ) from vehicle_type  where  vehicle_type.Hide= 0 and  vehicle_type.orgid = '',    @Orgid ,'' ) 
WHEN 'TrafficVehicleTypeId' THEN (select  group_concat( distinct VehicleTypeName separator ', ' ) from vehicle_type  where  vehicle_type.Hide= 0 and  vehicle_type.orgid = '',    @Orgid ,'' ) 
WHEN 'TaskStatusId' THEN (select  group_concat( distinct InvStatusName separator ', ' ) from inv_status  where  inv_status.Hide= 0 and  inv_status.orgid = '',    @Orgid ,'' ) 
WHEN 'InvSourceParamId' THEN (select  group_concat( distinct InvSourceName separator ', ' ) from inv_source  where  inv_source.Hide= 0 and  inv_source.orgid = '',    @Orgid ,'' ) 
');
  
SET $ids = extractvalue(xmlData, '//FieldNamesIds');
 
SET @Postition = LOCATE(',', $ids);
WHILE ( @Postition > 0 ) DO
	SET @STR = SUBSTRING($ids, 1, @Postition-1);
	SET $ids  = SUBSTRING($ids, @Postition + 1);
	set  @STR = TRIM(@STR);
    
    set @selectquery =concat(@selectquery,' 
						WHEN '',@STR,'' 
                        THEN (select group_concat( trim( OptionName)  separator ', ') 
						from `option`
						join field on field.Fieldid = `option`.fieldid
						where fieldname ='',@STR,'' and field.OrgId = '',    @Orgid ,'')');
        
	SET @Postition = LOCATE(',', $ids);
END WHILE;
set @selectquery =concat(@selectquery,'END  as FieldValues');
set @queryFrom = ' from org_field
					inner join field on field.FieldId = org_field.FieldId
					left outer  join sub_tab on sub_tab.SubTabId = field.SubTabId
					left outer  join tab on sub_tab.TabId = tab.TabId
					left outer  join field_type on field_type.FieldTypeId = field.FieldTypeId		'; 
SET @queryWhere = ' where 1= 1 ';
SET @queryWhere = CONCAT(@queryWhere,' and org_field.FieldLabel <> ''  and org_field.OrgId = "', @Orgid,'"');
 IF(@ShowDefaultFields = 'true') THEN
	SET @queryWhere = CONCAT(@queryWhere,' and field.OrgId is null ');
 END IF;
 IF(@ShowCustomFields = 'true') THEN 
	SET @queryWhere = CONCAT(@queryWhere,' and field.OrgId=  "', @Orgid,'"');
 END IF;
SET @myArrayOfValue = 'FieldValues,HelpTitle,HelpDesc,FieldLabel,SubTabLabel,FieldTypeName,';
SET @Postition = LOCATE(',', @myArrayOfValue);
WHILE ( @Postition > 0 ) DO
 SET @STR = SUBSTRING(@myArrayOfValue, 1, @Postition-1);
 SET @myArrayOfValue = SUBSTRING(@myArrayOfValue, @Postition + 1);
 SET @Col =  extractvalue(xmlData, CONCAT('//',@STR));
 IF (@Col != '' AND @Col !='NULL') THEN
	IF (@STR  = 'HelpTitle' ) then set @STR= 'HelpMeName';  END IF; 
	IF (@STR  = 'HelpDesc' ) then set @STR= 'HelpMeDescription';  END IF;
	SET @queryWhere = CONCAT(@queryWhere,CONCAT(' AND ',@STR,' like('"'%", @Col ,"%'"') ')); 
 END IF;
 
 SET @Postition = LOCATE(',', @myArrayOfValue);
END WHILE;
SET @IsMandatory =  extractvalue(xmlData, '//IsMandatory');
IF (@IsMandatory != '' AND @IsMandatory !='NULL') THEN
	IF( @IsMandatory  != '2' ) THEN 
		SET @queryWhere = CONCAT(@queryWhere,'  AND org_field.IsMandatory = ',  @IsMandatory ); 
	END IF;	
END IF;
SET @IsHidden =  extractvalue(xmlData, '//IsHidden');
IF (@IsHidden != '' AND @IsHidden !='NULL') THEN
	IF( @IsHidden  != '2' ) THEN 
		SET @queryWhere = CONCAT(@queryWhere,'  AND org_field.IsHidden = ',  @IsHidden ); 
	END IF;	
END IF;
SET @querycount = CONCAT( 'SELECT count(*) into @cnt ', @queryFrom, @queryWhere );
PREPARE stmt1 FROM @querycount;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
	
SET @selectquery = CONCAT (@selectquery,', ', @cnt, ' as Count ');
SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );
if( @index = 'Order') then set  @index = 'field.`Order`';  end if;
SET @query = CONCAT(@query, ' order by ', @index,'  ', @sortOrder);
if( @Export ="false") then
SET @page = (@page - 1) * @limit;
SET @query = CONCAT(@query, ' LIMIT ', @limit ,' OFFSET ',  @page);
end if;
 -- select @query ;
PREPARE stmt1 FROM @query;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
END;
