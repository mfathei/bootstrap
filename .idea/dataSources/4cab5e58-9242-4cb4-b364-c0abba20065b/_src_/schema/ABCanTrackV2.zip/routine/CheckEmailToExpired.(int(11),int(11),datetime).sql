CREATE FUNCTION ABCanTrackV2.CheckEmailToExpired(`$DaysStart` INT, `$DaysFreq` INT, `$SentDate` DATETIME)
  RETURNS VARCHAR(255)
  BEGIN
DECLARE $ret varchar(255) ;
	
	SET $SentDate = DATE_ADD($SentDate, INTERVAL $DaysFreq DAY);
	IF $SentDate <= CURRENT_TIMESTAMP()
	THEN
		SET $ret = 'ToDay';
	ELSE
		SET $ret = 'NotToDay';
	END IF;

RETURN $ret;
END;
