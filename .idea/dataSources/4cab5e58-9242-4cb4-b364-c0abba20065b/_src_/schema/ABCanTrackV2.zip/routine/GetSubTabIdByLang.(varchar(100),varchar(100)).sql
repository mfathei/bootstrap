CREATE FUNCTION ABCanTrackV2.GetSubTabIdByLang(pSubTabId VARCHAR(100), pLangId VARCHAR(100))
  RETURNS VARCHAR(100)
  begin
    declare vSubTabId varchar(100);
    set @tmpSubTabCode = (select FieldCode from sub_tab where SubTabId = pSubTabId);
    set vSubTabId = (select SubTabId from sub_tab where FieldCode = @tmpSubTabCode AND LanguageId = pLangId);
    return vSubTabId;
end;
