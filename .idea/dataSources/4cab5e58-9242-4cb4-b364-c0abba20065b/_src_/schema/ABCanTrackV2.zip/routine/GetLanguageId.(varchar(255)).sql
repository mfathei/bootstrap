CREATE FUNCTION ABCanTrackV2.GetLanguageId(`$LanguageCode` VARCHAR(255))
  RETURNS VARCHAR(100)
  BEGIN
set @lang_id = (select language.LanguageId from ABCanTrackV2.language where LanguageCode=$LanguageCode );
RETURN @lang_id;
END;
