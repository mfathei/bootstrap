CREATE PROCEDURE ABCanTrackV2.GetCompanyProcedures(IN xmlData TEXT)
  BEGIN
SET @page = extractvalue(xmlData, '//page');
SET @limit = extractvalue(xmlData, '//limit');
SET @sortOrder =  extractvalue(xmlData, '//sortOrder');
SET @index =  extractvalue(xmlData, '//index');
SET @Export =  extractvalue(xmlData, '//Export');
SET @Orgid = extractvalue(xmlData, '//OrgId');
set @selectquery ='SELECT SQL_CALC_FOUND_ROWS HelpId, HelpName, HelpDescription, concat(FirstName,' ' , LastName) as UpdatedById, UpdatedDate  ';
                
set @queryFrom = ' from  CommonDB.help
inner join CommonDB.employee on help.UpdatedById = employee.EmployeeId ';
SET @queryWhere = ' where 1= 1 and IsActive=1 ';
IF (@Orgid != '' AND @Orgid !='0') THEN 
	SET @queryWhere = CONCAT(@queryWhere,' and `help`.OrgId =   "', @Orgid,'" ');
END IF;
SET @myArrayOfValue = 'HelpName,HelpDescription,UpdatedById,';
SET @Postition = LOCATE(',', @myArrayOfValue);
WHILE ( @Postition > 0 ) DO
 SET @STR = SUBSTRING(@myArrayOfValue, 1, @Postition-1);
 SET @myArrayOfValue = SUBSTRING(@myArrayOfValue, @Postition + 1);
	SET @Col =  extractvalue(xmlData, CONCAT('//',@STR));
	IF (@Col != '' AND @Col !='NULL') THEN
		if( @STR = 'UpdatedById') then set  @STR = 'concat(FirstName,' ' , LastName)';  end if;
		SET @queryWhere = CONCAT(@queryWhere,CONCAT(' AND    ',@STR,' like '"'%", @Col ,"%'")); 
	END IF;
 
 SET @Postition = LOCATE(',', @myArrayOfValue);
END WHILE;
SET @UpdatedDateFrom =  extractvalue(xmlData, '//UpdatedDateFrom');
SET @UpdatedDateTo =  extractvalue(xmlData, '//UpdatedDateTo');
IF(@UpdatedDateTo != '') THEN
	
	SET @UpdatedDateTo  = STR_TO_DATE(@UpdatedDateTo , '%m/%d/%Y');
	SET @UpdatedDateTo2 = DATE_ADD(@UpdatedDateTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND help.UpdatedDate >  ', "'" , @UpdatedDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND help.UpdatedDate <=  ', "'",  @UpdatedDateTo2  ,"'" );										
ELSE 
IF(@UpdatedDateTo = '' AND @UpdatedDateFrom !='' ) THEN
	SET @UpdatedDateFrom  = STR_TO_DATE(@UpdatedDateFrom , '%m/%d/%Y');
	SET @UpdatedDateFrom2 = DATE_ADD(@UpdatedDateFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND help.UpdatedDate >=  ',  "'", @UpdatedDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND help.UpdatedDate <  ', "'", @UpdatedDateFrom2  ,"'");	
END IF;
END IF;
/*
SET @querycount = CONCAT( 'SELECT count(*) into @cnt ', @queryFrom, @queryWhere );
-- select  @querycount;
PREPARE stmt1 FROM @querycount;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
	
SET @selectquery = CONCAT (@selectquery,', ', @cnt, ' as Count ');
*/
SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );
if( @index = 'Order') then set  @index = 'help.`Order`';  end if;
-- HelpTypeName,Order,HelpDescription,UpdatedById,UpdatedDate
if(@index =@index ='UpdatedById' or @index ='HelpDescription'  or @index ='UpdatedDate' or @index ='HelpName')then
SET @query = CONCAT(@query, ' order by ', @index,'  ', @sortOrder);
end if;
if( @Export ="false") then
SET @page = (@page - 1) * @limit;
SET @query = CONCAT(@query, ' LIMIT ', @limit ,' OFFSET ',  @page);
end if;
-- select  @query;
PREPARE stmt1 FROM @query;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1;  
SELECT FOUND_ROWS();
END;
