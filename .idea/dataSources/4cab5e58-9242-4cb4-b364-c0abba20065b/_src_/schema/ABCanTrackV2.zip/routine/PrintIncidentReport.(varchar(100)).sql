CREATE PROCEDURE ABCanTrackV2.PrintIncidentReport(IN `$IncidentId` VARCHAR(100))
  BEGIN
select
    
    concat(empCreator.FirstName, " " , empCreator.LastName) as CreatorName,
    DATE_FORMAT(IncidentDate, '%m/%d/%Y')  as  IncidentDate,
    IncidentHour,
    IncidentMinute,
    CASE IsEmerRP   WHEN '0' THEN 'No'        WHEN '1' THEN 'Yes' END AS IsEmerRP,
    RepName,
    RepEmail,
    RepPosition,
    RepCompany,
    RepPrimaryPhone,
    RepAlternatePhone,
   	EventTypeName as EventTypeId, 
	OperationTypeName as OperationTypeId,
	Location1Name as Location1Id,
	Location2Name as Location2Id, 
	Location3Name as Location3Id,
	Location4Name as Location4Id,
    OtherLocation,EnvConditionNote,
    (select group_concat(ObservationAndAnalysisParamName separator '; ') from observation_analysis_param  inner join observation_analysis on observation_analysis.ObservationAndAnalysisId = observation_analysis_param.ObservationAndAnalysisId where ObservationAndAnalysisCode ='EnergyForm' and  ObservationAndAnalysisParamId in (select ObservationAndAnalysisParamId  from inc_obser_ana where incidentid = $IncidentId)) as EnergyForm,
	(select group_concat(ObservationAndAnalysisParamName separator '; ') from observation_analysis_param  inner join observation_analysis on observation_analysis.ObservationAndAnalysisId = observation_analysis_param.ObservationAndAnalysisId where ObservationAndAnalysisCode ='SubActions' and  ObservationAndAnalysisParamId in (select ObservationAndAnalysisParamId  from inc_obser_ana where incidentid = $IncidentId)) as SubActions,
	(select group_concat(ObservationAndAnalysisParamName separator '; ') from observation_analysis_param  inner join observation_analysis on observation_analysis.ObservationAndAnalysisId = observation_analysis_param.ObservationAndAnalysisId where ObservationAndAnalysisCode ='SubConditions' and  ObservationAndAnalysisParamId in (select ObservationAndAnalysisParamId  from inc_obser_ana where incidentid = $IncidentId)) as SubConditions,
	(select group_concat(ObservationAndAnalysisParamName separator '; ') from observation_analysis_param  inner join observation_analysis on observation_analysis.ObservationAndAnalysisId = observation_analysis_param.ObservationAndAnalysisId where ObservationAndAnalysisCode ='UnderLyingCauses' and  ObservationAndAnalysisParamId in (select ObservationAndAnalysisParamId  from inc_obser_ana where incidentid = $IncidentId)) as UnderLyingCauses,
    (select group_concat(OEDepartmentName separator ' ; ') from oe_department where OEDepartmentid in (select OEDepartmentid from inc_oe_department where incidentid = $IncidentId)) as OEDepartmentId,
    EventSequence ,
	
    (select group_concat(EnvCondParameterName separator '; ') from env_cond_parameter where EnvCondParameterId in (select EnvCondParameterId from inc_env_cond where incidentid = $IncidentId)) as EnvConditions,
    (select group_concat(RootCauseParamName separator '; ') from root_cause_param where RootCauseParamId in (select RootCauseParamId from inc_root_cause where incidentid = $IncidentId)) as RootCauseParamId, 
    IncDescription,
	(select group_concat(InvSourceName separator '; ') from inv_source where InvSourceId in (select InvSourceId from inc_inv_source where incidentid = $IncidentId)) as InvSourceParamId,
    EnergyFormNote,
    SubStandardActionNote,
    SubStandardConditionNote,
    UnderLyingCauseNote,	
    InvStatusName as InvStatusId,
     DATE_FORMAT(InvestigationDate, '%m/%d/%Y')  as InvestigationDate,
    InvestigatorName1 as InvestigatorId1,
    InvestigatorName2 as InvestigatorId2, 
    InvestigatorName3 as InvestigatorId3,
	InvSummary,   
    ResponseCost,
    RepairCost,
    InsuranceCost,
    WCBCost,
    OtherCost,
    TotalCost,FollowUpNote,
    RiskOfRecurrenceName as RiskOfRecurrenceId,
    IncidentSeverityName as IncidentSeverityId,
	SourceDetails,
    RootCauseNote,	
    SignOffInvestigatorName as SignOffInvestigatorId,
	DATE_FORMAT(SignOffDate, '%m/%d/%Y')  as  SignOffDate,
	(select max(versionnumber) from hist_incident where incidentid = $IncidentId ) as VersionNumber, IncidentNumber
    ,(select  concat( FirstName, ' ', LastName)  from hist_incident
		 join employee on employee.EmployeeId = hist_incident.UpdatedById
		 where incidentid = $IncidentId   order by HistIncidentId desc limit 1) as UpdatedByName
from
    incident
left outer join event_type on event_type.EventTypeId = incident.EventTypeId
left outer join operation_type on operation_type.OperationTypeId = incident.OperationTypeId
left outer join incident_severity on incident_severity.IncidentSeverityId = incident.IncidentSeverityId
left outer join risk_of_recurrence on risk_of_recurrence.RiskOfRecurrenceId = incident.RiskOfRecurrenceId
left outer join inv_status on inv_status.InvStatusId = incident.InvStatusId
left outer join location1 on location1.Location1Id= incident.Location1Id
left outer join location2 on location2.Location2Id= incident.Location2Id
left outer join location3 on location3.Location3Id= incident.Location3Id
left outer join location4 on location4.Location4Id= incident.Location4Id
left outer join employee as empCreator on empCreator.EmployeeId = incident.CreatorId
left outer join employee as empModifier on empModifier.EmployeeId = incident.ModifierId
where incidentid = $IncidentId;
END;
