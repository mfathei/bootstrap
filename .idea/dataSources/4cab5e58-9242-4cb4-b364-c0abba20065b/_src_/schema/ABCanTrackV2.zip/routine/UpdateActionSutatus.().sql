CREATE PROCEDURE ABCanTrackV2.UpdateActionSutatus()
  BEGIN
DECLARE $IMax, $IMin, $InvStatusId, $ActionStatus, $HistIncidentId VARCHAR(100);
DECLARE $InvStatusName, $LastInvStatusName VARCHAR(255);
DECLARE $VMax, $VMin INT;
SET $IMin = (SELECT MIN(IncidentId) FROM ABCanTrackV2.hist_incident WHERE ActionStatus = '0' LIMIT 1);
SET $IMax = (SELECT MAX(IncidentId) FROM ABCanTrackV2.hist_incident WHERE ActionStatus = '0' LIMIT 1);
-- select $IMin, $IMax;
IncLoop: WHILE $IMin <= $IMax
DO
	IF (SELECT COUNT(HistIncidentId) FROM hist_incident WHERE IncidentId = $IMin) = 1
	THEN
		SET $HistIncidentId = (SELECT HistIncidentId from hist_incident WHERE IncidentId = $IMin);
		SET $InvStatusName = (SELECT InvStatusName FROM ABCanTrackV2.hist_incident WHERE IncidentId = $IMin);
		IF $InvStatusName = 'Closed'
		THEN
			UPDATE hist_incident
			SET ActionStatus = 'cs4sql-529974f1-dc90-11e4-b362-5254000a52fa'
			WHERE IncidentId = $IMin AND HistIncidentId = $HistIncidentId;
		ELSEIF $InvStatusName = 'Open'
		THEN
			UPDATE hist_incident
			SET ActionStatus = 'cs4sql-529ba531-dc90-11e4-b362-5254000a52fa'
			WHERE IncidentId = $IMin AND HistIncidentId = $HistIncidentId;
		END IF;
	ELSE
		SET $VMin = (SELECT MIN(VersionNumber) FROM ABCanTrackV2.hist_incident WHERE IncidentId = $IMin);
		SET $VMax = (SELECT MAX(VersionNumber) FROM ABCanTrackV2.hist_incident WHERE IncidentId = $IMin);
		
		VersionLoop: WHILE $VMin <= $VMax
		DO
			SET $HistIncidentId = (SELECT HistIncidentId from hist_incident WHERE IncidentId = $IMin AND VersionNumber = $VMin);
			SET $InvStatusName = (SELECT InvStatusName FROM ABCanTrackV2.hist_incident WHERE IncidentId = $IMin AND VersionNumber = $VMin); 
			IF  $LastInvStatusName = 'Open' AND $InvStatusName = 'Closed' 
			THEN
				SET $ActionStatus = (SELECT histstatusid FROM hist_status WHERE histstatuscode = 'Closed') ;
				UPDATE ABCanTrackV2.hist_incident
				SET ActionStatus = $ActionStatus
				WHERE IncidentId = $IMin AND HistIncidentId = $HistIncidentId;
			-- select $IMin, $VMin, $ActionStatus;
			ELSEIF  $LastInvStatusName = 'Closed' AND $InvStatusName = 'Open' 
			THEN
				SET $ActionStatus = (SELECT histstatusid FROM hist_status WHERE histstatuscode = 'Re-opened') ;
				UPDATE ABCanTrackV2.hist_incident
				SET ActionStatus = $ActionStatus
				WHERE IncidentId = $IMin AND HistIncidentId = $HistIncidentId;
			-- select $IMin, $VMin, $ActionStatus;
			End IF;
			
			IF $VMin = $VMax
			THEN
				LEAVE VersionLoop;
			ELSE
				SET $LastInvStatusName = $InvStatusName;
				SET $VMin = (SELECT MIN(VersionNumber) FROM hist_incident WHERE IncidentId = $IMin AND VersionNumber > $VMin);
			END IF;
		END WHILE;
	END IF;
	IF $IMin = $IMax 
	THEN
		LEAVE IncLoop;
	ELSE
		SET $IMin = (SELECT MIN(IncidentId) FROM ABCanTrackV2.hist_incident WHERE ActionStatus = '0' AND IncidentId > $IMin LIMIT 1); 
	END IF;
END WHILE;
END;
