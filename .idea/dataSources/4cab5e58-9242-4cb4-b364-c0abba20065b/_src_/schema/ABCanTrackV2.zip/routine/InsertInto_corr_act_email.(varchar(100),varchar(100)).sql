CREATE PROCEDURE ABCanTrackV2.InsertInto_corr_act_email(IN `$CorrectiveActionId` VARCHAR(100),
                                                        IN `$EmailLogId`         VARCHAR(100))
  BEGIN
SET @HistIncidentId = (SELECT HistIncidentId FROM hist_corrective_action WHERE CorrectiveActionId = $CorrectiveActionId  limit 1 );
SET @HistCorrectiveActionId = (SELECT HistCorrectiveActionId FROM hist_corrective_action WHERE CorrectiveActionId = $CorrectiveActionId limit 1 );   
                        
                        
IF @HistIncidentId is not null and @HistIncidentId <> '' and @HistIncidentId <> '0'
then                        
   insert into inc_email_log(HistIncidentId,EmailLogId) 
    select * from(select @HistIncidentId, $EmailLogId) as tmp
    where not exists(
		select HistIncidentId,EmailLogId from inc_email_log where HistIncidentId=@HistIncidentId and EmailLogId=$EmailLogId
    ) limit 1;                        
END IF;
IF @HistCorrectiveActionId is not null and @HistCorrectiveActionId <> '' and @HistCorrectiveActionId <> '0'
then		
INSERT INTO `corr_act_email`
 select * from(select @HistCorrectiveActionId, $EmailLogId) as tmp
    where not exists(
		select HistCorrectiveActionId,EmailLogId from corr_act_email where HistCorrectiveActionId=@HistCorrectiveActionId and EmailLogId=$EmailLogId
    ) limit 1;      
END IF;
END;
