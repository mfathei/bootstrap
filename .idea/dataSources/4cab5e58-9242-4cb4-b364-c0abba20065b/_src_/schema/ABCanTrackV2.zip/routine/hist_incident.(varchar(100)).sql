CREATE FUNCTION ABCanTrackV2.hist_incident(`$incidentid` VARCHAR(100))
  RETURNS VARCHAR(100)
  BEGIN
declare $histincidentid varchar(100);
DECLARE $VersionNumber INT;

SET $VersionNumber = (SELECT MAX(VersionNumber) FROM hist_incident WHERE incidentid = $incidentid);

select  HistIncidentId from hist_incident where incidentid = $incidentid AND VersionNumber = $VersionNumber into $histincidentid;

-- select Max(histincidentid) from hist_incident where incidentid = $incidentid into $histincidentid;
RETURN $histincidentid;
END;
