CREATE PROCEDURE ABCanTrackV2.GetIncidentsVersions(IN xmlData TEXT)
  BEGIN 
DECLARE $ids TEXT;
DECLARE $FieldId VARCHAR(100);
SET @Orgid = extractvalue(xmlData, '//OrgId');
SET @page = extractvalue(xmlData, '//page');
SET @limit = extractvalue(xmlData, '//limit');
SET @sortOrder =  extractvalue(xmlData, '//sortOrder');
SET @index =  extractvalue(xmlData, '//index');
SET @Mine =  extractvalue(xmlData, '//Mine');
SET @CreatorId = extractvalue(xmlData, '//CreatorId');
SET @Export =  extractvalue(xmlData, '//Export');
 
SET @LanguageCode =  extractvalue(xmlData, '//LanguageCode');
SET @lblYes = (select GetItemLabel(@LanguageCode,'isreportableyes'));
SET @lblNo = (select GetItemLabel(@LanguageCode,'isreportableno'));
 
set @selectquery =concat('SELECT  incident_versions_view.VersionNumber,  incident_versions_view.IncidentNumber, incident_versions_view.HistIncidentId ,incident_versions_view.IncidentId , incident_versions_view.UpdatedDate, IncInvSourceName as InvSourceParamId,EventTypeName AS EventTypeId,OperationTypeName as OperationTypeId ,OrgId ,EmployeeName as CreatorName,date_format(IncidentDate,'%m/%d/%Y') AS IncidentDate,date_format(SignOffDate,'%m/%d/%Y') AS SignOffDate,date_format(InvestigationDate,'%m/%d/%Y') AS InvestigationDate , IncidentHour ,IncidentMinute ,CASE IsEmerRP   WHEN '0' THEN '',@lblNo,'' WHEN '1' THEN '', @lblYes,'' END AS IsEmerRP ,RepName ,RepEmail,RepPosition ,RepCompany ,RepPrimaryPhone ,RepAlternatePhone ,Location1Name as Location1Id ,Location2Name as Location2Id ,Location3Name as Location3Id,Location4Name as Location4Id ,OtherLocation ,
 replace(`OEDepartmentName`, ';|',';')   as OEDepartmentId ,
  EventSequence ,EnvConditionNote,
    replace(`EnvConditionName`, ';|',';')    as EnvConditions ,IncDescription ,ObserAnaName as ObservationAndAnalysisParamId,EnergyFormNote ,SubStandardActionNote ,SubStandardConditionNote ,UnderLyingCauseNote ,InvStatusName as InvStatusId ,InvestigatorName1 ,InvestigatorName2 ,InvestigatorName3,
      replace(`RootCauseName`, ';|',';')  as RootCauseParamId ,OtherRootCause ,  
replace(`CustomerName`, ';|',';')  as CustomerId, 
replace(`CustomerJobNumber`, ';|',';')  as CustomerJobNumber ,
replace(`CustName`, ';|',';')  as CustName ,  
replace(`ContractorName`, ';|',';') as ContractorId,
replace(`ContractorJobNumber`, ';|',';')  as ContractorJobNumber ,
replace(`ContName`, ';|',';')  as ContName ,
 replace(`EnergyForm`, ';|',';')  as   `EnergyForm`  , 
 replace(`SubActions`, ';|',';')  as   `SubActions`  ,
 replace(`SubConditions`, ';|',';')  as    `SubConditions` ,
 replace(`UnderLyingCauses`, ';|',';')  as    `UnderLyingCauses`  ,
InvSummary ,FollowUpNote ,ResponseCost,RepairCost ,InsuranceCost  ,WCBCost  ,OtherCost ,TotalCost ,RiskOfRecurrenceName as RiskOfRecurrenceId,IncidentSeverityName as IncidentSeverityId ,SourceDetails ,RootCauseNote ,SignOffInvestigatorName as SignOffInvestigatorId,
	UpdatedByName');
    
    
   -- select @selectquery;
-- =========================================
-- Group clause
SET @queryhave = ' having 1 = 1  ';
    
SET $ids = extractvalue(xmlData, '//FieldNamesIds');
-- select $ids;
if($ids  !='') then
	SET @Postition = LOCATE(',', $ids);
	WHILE ( @Postition > 0 ) DO
		SET @STR = SUBSTRING($ids, 1, @Postition-1);
		SET $ids  = SUBSTRING($ids, @Postition + 1);
		set  @STR = TRIM(@STR);
		SET $FieldId = (SELECT FieldId FROM ABCanTrackV2.field where FieldName = @STR and Orgid=@OrgId );
		   
	   if ((SELECT INSTR( @STR , 'calendar') > 0)) THEN 
			SET @selectquery = CONCAT(@selectquery , ',  (select group_concat(FieldValue  separator ', ' ) from hist_field_value tbl1
					where tbl1.HistIncidentId = incident_versions_view.HistIncidentId and tbl1.FieldId ="', $FieldId,'"   limit 1) as `',@STR,'`');	
		elseif ((SELECT INSTR( @STR , 'textbox') > 0)) THEN 
			SET @selectquery = CONCAT(@selectquery , ',     (select group_concat(FieldValue  separator ', ' ) from hist_field_value tbl1
				where tbl1.HistIncidentId = incident_versions_view.HistIncidentId and tbl1.FieldId ="', $FieldId,'"   limit 1) as `',@STR,'`');	
				
		elseif ((SELECT INSTR( @STR , 'textarea') > 0)) THEN 
			SET @selectquery = CONCAT(@selectquery , ',     (select group_concat(FieldValue  separator ', ' ) from hist_field_value tbl1
					where tbl1.HistIncidentId = incident_versions_view.HistIncidentId and tbl1.FieldId ="', $FieldId,'"   limit 1) as `',@STR,'`');	
		else    
			SET @selectquery = CONCAT(@selectquery , ',   (select group_concat(trim(tbl1.OptionName) separator ', ')  from hist_field_value tbl1
					where tbl1.HistIncidentId = incident_versions_view.HistIncidentId and tbl1.FieldId ="', $FieldId,'"   limit 1) as `',@STR,'`');		
		END IF;  
		
		SET @Col =  extractvalue(xmlData, CONCAT('//',@STR));
		IF (@Col != '' AND @Col !='NULL') THEN	 
		SET @queryhave = CONCAT(@queryhave,'  and  ', @STR ,' like '"'%", @Col ,"%'" );
		END IF; 	
			
		SET @Postition = LOCATE(',', $ids);
	END WHILE;
end if;
-- select @queryhave;
set @queryFrom = " from incident_versions_view ";
/* impact part   */
IF(ExtractValue(xmlData, 'count(//ImpactTypeId)') >0 )then 	
SET @selectquery = CONCAT(@selectquery,', incident_versions_view.ImpactTypeName as ImpactTypeId ');	END IF;
	IF(ExtractValue(xmlData, 'count(//ImpactSubTypeId)') >0 )then 	SET @selectquery = CONCAT(@selectquery,', incident_versions_view.ImpactSubTypeName as ImpactSubTypeId ');	END IF;
	IF(ExtractValue(xmlData, 'count(//IntEmployeeName1)') >0 )then 	SET @selectquery = CONCAT(@selectquery,', incident_versions_view.IntEmployeeName1 ');	END IF;
	IF(ExtractValue(xmlData, 'count(//IntEmployeeDept1)') >0 )then 	SET @selectquery = CONCAT(@selectquery,', incident_versions_view.IntEmployeeDept1 ');	END IF;
	IF(ExtractValue(xmlData, 'count(//IntEmployeeName2)') >0 )then 	SET @selectquery = CONCAT(@selectquery,', incident_versions_view.IntEmployeeName2 ');	END IF;
	IF(ExtractValue(xmlData, 'count(//IntEmployeeDept2)') >0 )then 	SET @selectquery = CONCAT(@selectquery,', incident_versions_view.IntEmployeeDept2 ');	END IF;
	IF(ExtractValue(xmlData, 'count(//IntEmployeeName3)') >0 )then 	SET @selectquery = CONCAT(@selectquery,', incident_versions_view.IntEmployeeName3 ');	END IF;
	IF(ExtractValue(xmlData, 'count(//IntEmployeeDept3)') >0 )then 	SET @selectquery = CONCAT(@selectquery,', incident_versions_view.IntEmployeeDept3 ');	END IF;
	IF(ExtractValue(xmlData, 'count(//PrimRespondName)') >0 )then 	SET @selectquery = CONCAT(@selectquery,', incident_versions_view.PrimRespondName ');	END IF;
	IF(ExtractValue(xmlData, 'count(//ImpactDescription)') >0 )then 	SET @selectquery = CONCAT(@selectquery,', incident_versions_view.ImpactDescription ');	END IF;
	IF(ExtractValue(xmlData, 'count(//ImpactEstimatedCost)') >0 )then 	SET @selectquery = CONCAT(@selectquery,', incident_versions_view.EstimatedCost as ImpactEstimatedCost ');	END IF;
	
/* injury part   */
IF(ExtractValue(xmlData, 'count(//InjuryTypeId)') >0 OR ExtractValue(xmlData, 'count(//BodyPartId)') >0 
OR ExtractValue(xmlData, 'count(//BodyAreaId)') >0 OR ExtractValue(xmlData, 'count(//PersonalInjured)') >0 
OR ExtractValue(xmlData, 'count(//ContactCodeId)') >0 OR ExtractValue(xmlData, 'count(//RecordableId)') >0
OR ExtractValue(xmlData, 'count(//InitialTreatmentId)') >0 OR ExtractValue(xmlData, 'count(//InjuryExtAgencyId)') >0 
OR ExtractValue(xmlData, 'count(//LostTimeEnd)') >0 OR ExtractValue(xmlData, 'count(//TotalDaysOff)') >0 
OR ExtractValue(xmlData, 'count(//InjuryDescription)') >0 OR ExtractValue(xmlData, 'count(//AdjustmentDays)') >0
OR ExtractValue(xmlData, 'count(//LostTimeStart)') >0) THEN
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join hist_injury on hist_injury.HistIncidentId = incident_versions_view.HistIncidentId  ');
	
	IF(ExtractValue(xmlData, 'count(//InjuryTypeId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(InjuryTypeName separator "; ") 
														from hist_injury
														where hist_injury.HistIncidentId = incident_versions_view.HistIncidentId) as InjuryTypeId' );	
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//BodyPartId)') >0 )then 
	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(BodyPartName separator "; ") 
														from hist_injury
														where hist_injury.HistIncidentId = incident_versions_view.HistIncidentId) as BodyPartId' );	
	END IF;
	
	
		IF(ExtractValue(xmlData, 'count(//BodyAreaId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(BodyAreaName separator "; ") 
														from hist_injury
														where hist_injury.HistIncidentId = incident_versions_view.HistIncidentId) as BodyAreaId' );	
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//PersonalInjured)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(PersonalInjuredName separator "; ") 
														from hist_injury
														where hist_injury.HistIncidentId = incident_versions_view.HistIncidentId) as PersonalInjured' );	
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//ContactCodeId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(ContactCodeName separator "; ") 
														from hist_injury
														where hist_injury.HistIncidentId = incident_versions_view.HistIncidentId) as ContactCodeId' );	
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//RecordableId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(RecordableName separator "; ") 
														from hist_injury
														where hist_injury.HistIncidentId = incident_versions_view.HistIncidentId) as RecordableId' );	
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//InitialTreatmentId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(InitialTreatmentName separator "; ") 
														from hist_injury
														where hist_injury.HistIncidentId = incident_versions_view.HistIncidentId) as InitialTreatmentId' );	
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//InjuryExtAgencyId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(ExtAgencyName separator "; ") 
														from hist_injury
														where hist_injury.HistIncidentId = incident_versions_view.HistIncidentId) as InjuryExtAgencyId' );	
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//AdjustmentDays)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(AdjustmentDays separator "; ") 
														from hist_injury
														where hist_injury.HistIncidentId = incident_versions_view.HistIncidentId) as AdjustmentDays' );	
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//TotalDaysOff)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(TotalDaysOff separator "; ") 
														from hist_injury
														where hist_injury.HistIncidentId = incident_versions_view.HistIncidentId) as TotalDaysOff' );	
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//InjuryDescription)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(InjuryDescription separator "; ") 
														from hist_injury
														where hist_injury.HistIncidentId = incident_versions_view.HistIncidentId) as InjuryDescription' );	
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//LostTimeEnd)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(date_format(LostTimeEnd,'%m/%d/%Y') separator "; ") 
														from hist_injury
														where hist_injury.HistIncidentId = incident_versions_view.HistIncidentId) as LostTimeEnd' );	
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//LostTimeStart)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(date_format(LostTimeStart,'%m/%d/%Y') separator "; ") 
														from hist_injury
														where hist_injury.HistIncidentId = incident_versions_view.HistIncidentId) as LostTimeStart' );	
	END IF;
	
END IF;
/* Illness part   */
IF(ExtractValue(xmlData, 'count(//IllnessDescription)') >0 OR ExtractValue(xmlData, 'count(//Illness_RestrictedWorkId)') >0 
OR ExtractValue(xmlData, 'count(//Illness_PersonalInjured)') >0 OR ExtractValue(xmlData, 'count(//Illness_InitialTreatmentId)') >0 
OR ExtractValue(xmlData, 'count(//ContactCodeId)') >0 OR ExtractValue(xmlData, 'count(//RecordableId)') >0
OR ExtractValue(xmlData, 'count(//Illness_AdjustmentDays)') >0 OR ExtractValue(xmlData, 'count(//Illness_AdjustmentDays)') >0 
OR ExtractValue(xmlData, 'count(//Illness_LostTimeEnd)') >0 OR ExtractValue(xmlData, 'count(//Illness_LostTimeStart)') >0 
OR ExtractValue(xmlData, 'count(//Illness_TotalDaysOff)') >0 OR ExtractValue(xmlData, 'count(//SymptomsId)') >0 ) THEN
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join hist_illness on hist_illness.HistIncidentId = incident_versions_view.HistIncidentId  ');
	
	IF(ExtractValue(xmlData, 'count(//IllnessDescription)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(IllnessDescription separator "; ") 
														from hist_illness
														where hist_illness.HistIncidentId = incident_versions_view.HistIncidentId) as IllnessDescription' );	
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//Illness_RestrictedWorkId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(RestrictedWorkName separator "; ") 
														from hist_illness
														where hist_illness.HistIncidentId = incident_versions_view.HistIncidentId) as Illness_RestrictedWorkId' );	
	END IF;
	
	
		IF(ExtractValue(xmlData, 'count(//Illness_PersonalInjured)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(PersonalAfflictedName separator "; ") 
														from hist_illness
														where hist_illness.HistIncidentId = incident_versions_view.HistIncidentId) as Illness_PersonalInjured' );	
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//Illness_InitialTreatmentId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(InitialTreatmentName separator "; ") 
														from hist_illness
														where hist_illness.HistIncidentId = incident_versions_view.HistIncidentId) as Illness_InitialTreatmentId' );	
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//Illness_AdjustmentDays)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(AdjustmentDays separator "; ") 
														from hist_illness
														where hist_illness.HistIncidentId = incident_versions_view.HistIncidentId) as Illness_AdjustmentDays' );	
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//SymptomsId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(SymptomsName separator "; ") 
														from hist_illness
														where hist_illness.HistIncidentId = incident_versions_view.HistIncidentId) as SymptomsId' );	
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//Illness_TotalDaysOff)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(TotalDaysOff separator "; ") 
														from hist_illness
														where hist_illness.HistIncidentId = incident_versions_view.HistIncidentId) as Illness_TotalDaysOff' );	
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//Illness_LostTimeEnd)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(date_format(LostTimeEnd,'%m/%d/%Y') separator "; ") 
														from hist_illness
														where hist_illness.HistIncidentId = incident_versions_view.HistIncidentId) as Illness_LostTimeEnd' );	
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//Illness_LostTimeStart)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(date_format(LostTimeStart,'%m/%d/%Y') separator "; ") 
														from hist_illness
														where hist_illness.HistIncidentId = incident_versions_view.HistIncidentId) as Illness_LostTimeStart' );	
	END IF;
	
END IF;
/* traffic_damage part   */
IF(ExtractValue(xmlData, 'count(//TrafficDriverName)') >0 OR ExtractValue(xmlData, 'count(//TrafficDriverLicence)') >0 
OR ExtractValue(xmlData, 'count(//TrafficVehicleTypeId)') >0 OR ExtractValue(xmlData, 'count(//TrafficVehicleLicence)') >0 
OR ExtractValue(xmlData, 'count(//Details)') >0 OR ExtractValue(xmlData, 'count(//ValueOfFine)') >0
OR ExtractValue(xmlData, 'count(//TicketNumber)') >0 OR ExtractValue(xmlData, 'count(//HowDidThatOccur)') >0   ) THEN
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join hist_traffic_violation on hist_traffic_violation.HistIncidentId = incident_versions_view.HistIncidentId  ');
	
	IF(ExtractValue(xmlData, 'count(//TrafficDriverName)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(DriverName separator "; ") 
														from hist_traffic_violation
														where hist_traffic_violation.HistIncidentId = incident_versions_view.HistIncidentId) as TrafficDriverName' );	
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//TrafficDriverLicence)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(DriverLicence separator "; ") 
														from hist_traffic_violation
														where hist_traffic_violation.HistIncidentId = incident_versions_view.HistIncidentId) as TrafficDriverLicence' );	
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//TrafficVehicleTypeId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(VehicleTypeName separator "; ") 
														from hist_traffic_violation
														where hist_traffic_violation.HistIncidentId = incident_versions_view.HistIncidentId) as TrafficVehicleTypeId' );	
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//TrafficVehicleLicence)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(VehicleLicence separator "; ") 
														from hist_traffic_violation
														where hist_traffic_violation.HistIncidentId = incident_versions_view.HistIncidentId) as TrafficVehicleLicence' );	
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//Details)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(Details separator "; ") 
														from hist_traffic_violation
														where hist_traffic_violation.HistIncidentId = incident_versions_view.HistIncidentId) as Details' );	
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//ValueOfFine)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(ValueOfFine separator "; ") 
														from hist_traffic_violation
														where hist_traffic_violation.HistIncidentId = incident_versions_view.HistIncidentId) as ValueOfFine' );	
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//TicketNumber)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(TicketNumber separator "; ") 
														from hist_traffic_violation
														where hist_traffic_violation.HistIncidentId = incident_versions_view.HistIncidentId) as TicketNumber' );	
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//HowDidThatOccur)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(HowDidThatOccur separator "; ") 
														from hist_traffic_violation
														where hist_traffic_violation.HistIncidentId = incident_versions_view.HistIncidentId) as HowDidThatOccur' );	
	END IF;
	
END IF;
/* traffic_violation part   */
IF(ExtractValue(xmlData, 'count(//DamageDriverName)') >0 OR ExtractValue(xmlData, 'count(//DamageDriverLicence)') >0 
OR ExtractValue(xmlData, 'count(//DamageVehicleTypeId)') >0 OR ExtractValue(xmlData, 'count(//DamageVehicleLicence)') >0 
OR ExtractValue(xmlData, 'count(//HowDidThatDone)') >0 OR ExtractValue(xmlData, 'count(//DamageDescription)') >0 ) THEN
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join hist_vehicle_damage on hist_vehicle_damage.HistIncidentId = incident_versions_view.HistIncidentId  ');
	
	IF(ExtractValue(xmlData, 'count(//DamageDriverName)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(DriverName separator "; ") 
														from hist_vehicle_damage
														where hist_vehicle_damage.HistIncidentId = incident_versions_view.HistIncidentId) as DamageDriverName' );	
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//DamageDriverLicence)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(DriverLicence separator "; ") 
														from hist_vehicle_damage
														where hist_vehicle_damage.HistIncidentId = incident_versions_view.HistIncidentId) as DamageDriverLicence' );	
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//DamageVehicleTypeId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(VehicleTypeName separator "; ") 
														from hist_vehicle_damage
														where hist_vehicle_damage.HistIncidentId = incident_versions_view.HistIncidentId) as DamageVehicleTypeId' );	
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//DamageVehicleLicence)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(VehicleLicence separator "; ") 
														from hist_vehicle_damage
														where hist_vehicle_damage.HistIncidentId = incident_versions_view.HistIncidentId) as DamageVehicleLicence' );	
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//HowDidThatDone)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(HowDidThatDone separator "; ") 
														from hist_vehicle_damage
														where hist_vehicle_damage.HistIncidentId = incident_versions_view.HistIncidentId) as HowDidThatDone' );	
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//DamageDescription)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(DamageDescription separator "; ") 
														from hist_vehicle_damage
														where hist_vehicle_damage.HistIncidentId = incident_versions_view.HistIncidentId) as DamageDescription' );	
	END IF;	
	
END IF;
/* spill_release part   */
IF(ExtractValue(xmlData, 'count(//SourceId)') >0 OR ExtractValue(xmlData, 'count(//DurationValue)') >0 
OR ExtractValue(xmlData, 'count(//DurationUnitId)') >0 OR ExtractValue(xmlData, 'count(//QuantityValue)') >0 
OR ExtractValue(xmlData, 'count(//QuantityUnitId)') >0 OR ExtractValue(xmlData, 'count(//QuantityRecoveredValue)') >0 
OR ExtractValue(xmlData, 'count(//RecoveredUnitId)') >0 OR ExtractValue(xmlData, 'count(//WhatWasIt)') >0 OR ExtractValue(xmlData, 'count(//HowDidSROccur)') >0 
OR ExtractValue(xmlData, 'count(//IsReportable)') >0 OR ExtractValue(xmlData, 'count(//ImpactsExtAgencyId)') >0 ) THEN
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join hist_spill_release on hist_spill_release.HistIncidentId = incident_versions_view.HistIncidentId  ');
	
	IF(ExtractValue(xmlData, 'count(//SourceId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(SourceName separator "; ") 
														from hist_spill_release
														where hist_spill_release.HistIncidentId = incident_versions_view.HistIncidentId) as SourceId' );	
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//DurationValue)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(DurationValue separator "; ") 
														from hist_spill_release
														where hist_spill_release.HistIncidentId = incident_versions_view.HistIncidentId) as DurationValue' );	
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//DurationUnitId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(DurationUnit separator "; ") 
														from hist_spill_release
														where hist_spill_release.HistIncidentId = incident_versions_view.HistIncidentId) as DurationUnitId' );	
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//QuantityValue)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(QuantityValue separator "; ") 
														from hist_spill_release
														where hist_spill_release.HistIncidentId = incident_versions_view.HistIncidentId) as QuantityValue' );	
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//QuantityUnitId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(QuantityUnit separator "; ") 
														from hist_spill_release
														where hist_spill_release.HistIncidentId = incident_versions_view.HistIncidentId) as QuantityUnitId' );	
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//QuantityRecoveredValue)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(QuantityRecoveredValue separator "; ") 
														from hist_spill_release
														where hist_spill_release.HistIncidentId = incident_versions_view.HistIncidentId) as QuantityRecoveredValue' );	
	END IF;	
	
		IF(ExtractValue(xmlData, 'count(//RecoveredUnitId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(QuantityRecoveredUnit separator "; ") 
														from hist_spill_release
														where hist_spill_release.HistIncidentId = incident_versions_view.HistIncidentId) as RecoveredUnitId' );	
	END IF;
	
		IF(ExtractValue(xmlData, 'count(//WhatWasIt)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(WhatWasIt separator "; ") 
														from hist_spill_release
														where hist_spill_release.HistIncidentId = incident_versions_view.HistIncidentId) as WhatWasIt' );	
	END IF;
	
		IF(ExtractValue(xmlData, 'count(//HowDidSROccur)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(HowDidSROccur separator "; ") 
														from hist_spill_release
														where hist_spill_release.HistIncidentId = incident_versions_view.HistIncidentId) as HowDidSROccur' );	
	END IF;
	
		IF(ExtractValue(xmlData, 'count(//IsReportable)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat( CASE IsReportable WHEN "0" THEN "No" WHEN "1" THEN "Yes" END  separator "; ") 
														from hist_spill_release
														where hist_spill_release.HistIncidentId = incident_versions_view.HistIncidentId) as IsReportable' );	
	END IF;
	
		IF(ExtractValue(xmlData, 'count(//ImpactsExtAgencyId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(ExtAgencyName separator "; ") 
														from hist_spill_release
														where hist_spill_release.HistIncidentId = incident_versions_view.HistIncidentId) as ImpactsExtAgencyId' );	
	END IF;
	
END IF;
/*  People Involved */
IF( ExtractValue(xmlData, 'count(//PeopleInvolvedName)') >0  or ExtractValue(xmlData, 'count(//Company)') >0 or ExtractValue(xmlData, 'count(//Position)') >0
or ExtractValue(xmlData, 'count(//Email)') >0  or ExtractValue(xmlData, 'count(//PrimaryPhone)') >0  or ExtractValue(xmlData, 'count(//AlternatePhone)') >0
or  ExtractValue(xmlData, 'count(//ExpInCurrentPostion)') >0  or ExtractValue(xmlData, 'count(//ExpOverAll)') >0 or ExtractValue(xmlData, 'count(//Age)') >0
or ExtractValue(xmlData, 'count(//HowHeInvolved)') >0  or ExtractValue(xmlData, 'count(//RoleDescription)') >0  or ExtractValue(xmlData, 'count(//CertificateId)') >0
) THEN
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join hist_people_involved on hist_people_involved.HistIncidentId = incident_versions_view.HistIncidentId  ');
	IF( ExtractValue(xmlData, 'count(//PeopleInvolvedName)') >0) then
		SET @selectquery = CONCAT(@selectquery,', (select  group_concat(distinct PeopleInvolvedName separator "; ") 
														from hist_people_involved
														where hist_people_involved.HistIncidentId = incident_versions_view.HistIncidentId) as PeopleInvolvedName');
	END IF;
		IF( ExtractValue(xmlData, 'count(//Company)') >0) then
		SET @selectquery = CONCAT(@selectquery,', (select  group_concat(distinct Company separator "; ") 
														from hist_people_involved
														where hist_people_involved.HistIncidentId = incident_versions_view.HistIncidentId) as Company');
	END IF;
	
	IF( ExtractValue(xmlData, 'count(//Position)') >0) then
		SET @selectquery = CONCAT(@selectquery,', (select  group_concat(distinct Position separator "; ") 
														from hist_people_involved
														where hist_people_involved.HistIncidentId = incident_versions_view.HistIncidentId) as Position');
	END IF;
	
	IF( ExtractValue(xmlData, 'count(//Email)') >0) then
		SET @selectquery = CONCAT(@selectquery,', (select  group_concat(distinct Email separator "; ") 
														from hist_people_involved
														where hist_people_involved.HistIncidentId = incident_versions_view.HistIncidentId) as Email');
	END IF;
	
	IF( ExtractValue(xmlData, 'count(//PrimaryPhone)') >0) then
		SET @selectquery = CONCAT(@selectquery,', (select  group_concat(distinct PrimaryPhone separator "; ") 
														from hist_people_involved
														where hist_people_involved.HistIncidentId = incident_versions_view.HistIncidentId) as PrimaryPhone');
	END IF;
		IF( ExtractValue(xmlData, 'count(//AlternatePhone)') >0) then
		SET @selectquery = CONCAT(@selectquery,', (select  group_concat(distinct AlternatePhone separator "; ") 
														from hist_people_involved
														where hist_people_involved.HistIncidentId = incident_versions_view.HistIncidentId) as AlternatePhone');
	END IF;
	
	IF( ExtractValue(xmlData, 'count(//ExpInCurrentPostion)') >0) then
		SET @selectquery = CONCAT(@selectquery,', (select  group_concat(distinct ExpInCurrentPostion separator "; ") 
														from hist_people_involved
														where hist_people_involved.HistIncidentId = incident_versions_view.HistIncidentId) as ExpInCurrentPostion');
	END IF;
	
	
	IF( ExtractValue(xmlData, 'count(//ExpOverAll)') >0) then
		SET @selectquery = CONCAT(@selectquery,', (select  group_concat(distinct ExpOverAll separator "; ") 
														from hist_people_involved
														where hist_people_involved.HistIncidentId = incident_versions_view.HistIncidentId) as ExpOverAll');
	END IF;
	
	IF( ExtractValue(xmlData, 'count(//Age)') >0) then
		SET @selectquery = CONCAT(@selectquery,', (select  group_concat(distinct Age separator "; ") 
														from hist_people_involved
														where hist_people_involved.HistIncidentId = incident_versions_view.HistIncidentId) as Age');
	END IF;
	
	IF( ExtractValue(xmlData, 'count(//HowHeInvolved)') >0) then
		SET @selectquery = CONCAT(@selectquery,', (select  group_concat(distinct HowHeInvolved separator "; ") 
														from hist_people_involved
														where hist_people_involved.HistIncidentId = incident_versions_view.HistIncidentId) as HowHeInvolved');
	END IF;
	
	
	IF( ExtractValue(xmlData, 'count(//RoleDescription)') >0) then
		SET @selectquery = CONCAT(@selectquery,', (select  group_concat(distinct RoleDescription separator "; ") 
														from hist_people_involved
														where hist_people_involved.HistIncidentId = incident_versions_view.HistIncidentId) as RoleDescription');
	END IF;
	
	IF( ExtractValue(xmlData, 'count(//CertificateId)') >0) then
		SET @selectquery = CONCAT(@selectquery,', (select  group_concat(distinct CertificateName separator "; ") 
														from hist_people_involved
														where hist_people_involved.HistIncidentId = incident_versions_view.HistIncidentId) as CertificateId');
	END IF;
END IF;
/*  corrective actions */
IF( ExtractValue(xmlData, 'count(//AssignedToId)') >0  or ExtractValue(xmlData, 'count(//EmployeeId)') >0 or ExtractValue(xmlData, 'count(//TaskStatusId)') >0
or ExtractValue(xmlData, 'count(//PriorityId)') >0  or ExtractValue(xmlData, 'count(//StartDate)') >0  or ExtractValue(xmlData, 'count(//TargetEndDate)') >0
or  ExtractValue(xmlData, 'count(//ActualEndDate)') >0  or ExtractValue(xmlData, 'count(//TaskEstimatedCost)') >0 or ExtractValue(xmlData, 'count(//TaskDescription)') >0
or ExtractValue(xmlData, 'count(//OutComeFollowUp)') >0  or ExtractValue(xmlData, 'count(//DesiredResults)') >0  or ExtractValue(xmlData, 'count(//Comments)') >0
) THEN
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join hist_corrective_action on hist_corrective_action.HistIncidentId = incident_versions_view.HistIncidentId  ');
	IF( ExtractValue(xmlData, 'count(//AssignedToId)') >0) then
		SET @selectquery = CONCAT(@selectquery,', (select  group_concat(distinct AssignedToName separator "; ") 
														from hist_corrective_action
														where hist_corrective_action.HistIncidentId = incident_versions_view.HistIncidentId) as AssignedToId');
	END IF;
		IF( ExtractValue(xmlData, 'count(//EmployeeId)') >0) then
		SET @selectquery = CONCAT(@selectquery,', (select  group_concat(distinct AlsoNotifyName separator "; ") 
														from hist_corrective_action
														where hist_corrective_action.HistIncidentId = incident_versions_view.HistIncidentId) as EmployeeId');
	END IF;
	
	IF( ExtractValue(xmlData, 'count(//TaskStatusId)') >0) then
		SET @selectquery = CONCAT(@selectquery,', (select  group_concat(distinct StatusName separator "; ") 
														from hist_corrective_action
														where hist_corrective_action.HistIncidentId = incident_versions_view.HistIncidentId) as TaskStatusId');
	END IF;
	
	IF( ExtractValue(xmlData, 'count(//PriorityId)') >0) then
		SET @selectquery = CONCAT(@selectquery,', (select  group_concat(distinct PriorityName separator "; ") 
														from hist_corrective_action
														where hist_corrective_action.HistIncidentId = incident_versions_view.HistIncidentId) as PriorityId');
	END IF;
	
	IF( ExtractValue(xmlData, 'count(//StartDate)') >0) then
		SET @selectquery = CONCAT(@selectquery,', (select  group_concat(distinct date_format(StartDate,'%m/%d/%Y') separator "; ") 
														from hist_corrective_action
														where hist_corrective_action.HistIncidentId = incident_versions_view.HistIncidentId) as StartDate');
	END IF;
		IF( ExtractValue(xmlData, 'count(//TargetEndDate)') >0) then
		SET @selectquery = CONCAT(@selectquery,', (select  group_concat(distinct  date_format(TargetEndDate,'%m/%d/%Y') separator "; ") 
														from hist_corrective_action
														where hist_corrective_action.HistIncidentId = incident_versions_view.HistIncidentId) as TargetEndDate');
	END IF;
	
	IF( ExtractValue(xmlData, 'count(//ActualEndDate)') >0) then
		SET @selectquery = CONCAT(@selectquery,', (select  group_concat(distinct  date_format(ActualEndDate,'%m/%d/%Y') separator "; ") 
														from hist_corrective_action
														where hist_corrective_action.HistIncidentId = incident_versions_view.HistIncidentId) as ActualEndDate');
	END IF;
	
	
	IF( ExtractValue(xmlData, 'count(//TaskEstimatedCost)') >0) then
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(distinct EstimatedCost separator "; ") 
														from hist_corrective_action
														where hist_corrective_action.HistIncidentId = incident_versions_view.HistIncidentId) as TaskEstimatedCost');
	END IF;
	
	IF( ExtractValue(xmlData, 'count(//TaskDescription)') >0) then
		SET @selectquery = CONCAT(@selectquery,', (select  group_concat(distinct Description separator "; ") 
														from hist_corrective_action
														where hist_corrective_action.HistIncidentId = incident_versions_view.HistIncidentId) as TaskDescription');
	END IF;
	
	IF( ExtractValue(xmlData, 'count(//OutComeFollowUp)') >0) then
		SET @selectquery = CONCAT(@selectquery,', (select  group_concat(distinct OutComeFollowUp separator "; ") 
														from hist_corrective_action
														where hist_corrective_action.HistIncidentId = incident_versions_view.HistIncidentId) as OutComeFollowUp');
	END IF;
	
	
	IF( ExtractValue(xmlData, 'count(//DesiredResults)') >0) then
		SET @selectquery = CONCAT(@selectquery,', (select  group_concat(CASE `DesiredResults`  WHEN '0' THEN '', @lblNo, '' WHEN '1' THEN '', @lblYes,''   END  separator '; ') 
														from hist_corrective_action
														where hist_corrective_action.HistIncidentId = incident_versions_view.HistIncidentId) as DesiredResults');
	END IF;
	
	IF( ExtractValue(xmlData, 'count(//Comments)') >0) then
		SET @selectquery = CONCAT(@selectquery,', (select  group_concat(distinct Comments separator "; ") 
														from hist_corrective_action
														where hist_corrective_action.HistIncidentId = incident_versions_view.HistIncidentId) as Comments');
	END IF;
END IF;
-- select CONCAT( @selectquery, @queryFrom);
SET @queryWhere = ' where 1= 1 ';
IF (@Orgid != '' AND @Orgid !='0') THEN
	SET @queryWhere = CONCAT(@queryWhere,' and incident_versions_view.OrgId =   "', @Orgid,'" ');
END IF;
SET @OriginalId = extractvalue(xmlData, '//OriginalId');
IF (@OriginalId != '' AND @OriginalId !='0' ) THEN
	SET @queryWhere = CONCAT(@queryWhere,' and incident_versions_view.IncidentId = "', @OriginalId,'"');
END IF;
IF (@Mine = 'true') THEN
	SET @queryWhere = CONCAT(@queryWhere,' AND ( incident_versions_view.IncidentId in ( select IncidentId from incident where incident.CreatorId =  "',@CreatorId,'" ' ,'))' );
END IF;
 SET@myArrayOfValue='SourceId,DurationValue,DurationUnitId,QuantityValue,QuantityUnitId,QuantityRecoveredValue,RecoveredUnitId,WhatWasIt,HowDidSROccur,IsReportable,ImpactsExtAgencyId,DamageDriverName,DamageDriverLicence,DamageVehicleTypeId,DamageVehicleLicence,HowDidThatDone,DamageDescription,TrafficTrafficDriverName,TrafficTrafficDriverLicence,TrafficVehicleTypeId,TrafficVehicleLicence,Details,ValueOfFine,TicketNumber,HowDidThatOccur,SymptomsId,IllnessDescription,Illness_RestrictedWorkId,Illness_PersonalInjured,Illness_InitialTreatmentId,Illness_AdjustmentDays,Illness_TotalDaysOff,InjuryTypeId,BodyPartId,BodyAreaId,PersonalInjured,ContactCodeId,RecordableId,InitialTreatmentId,InjuryExtAgencyId,AdjustmentDays,TotalDaysOff,InjuryDescription,AssignedToId,EmployeeId,TaskStatusId,PriorityId,TaskDescription,OutComeFollowUp,Comments,PeopleInvolvedName,Company,Position,Email,PrimaryPhone,AlternatePhone,ExpInCurrentPostion,ExpOverAll,Age,HowHeInvolved,RoleDescription,CertificateId,InvSourceParamId,ImpactTypeId,ImpactSubTypeId,ImpactDescription,IntEmployeeName1,IntEmployeeDept1,IntEmployeeName2,IntEmployeeDept2,IntEmployeeName3,IntEmployeeDept3,PrimRespondName,VersionNumber,IncidentNumber,EventTypeId,CreatorName,IncidentHour,IncidentMinute,RepName,RepEmail,RepPosition,RepCompany,RepPrimaryPhone,RepAlternatePhone,Location1Id,Location2Id,Location3Id,Location4Id,OtherLocation,OperationTypeId,OEDepartmentId,EventSequence,EnvConditionNote,EnvConditions,IncDescription,EnergyForm,SubActions,SubConditions,UnderLyingCauses,FilledByName,EnergyFormNote,SubStandardActionNote,SubStandardConditionNote,UnderLyingCauseNote,InvStatusId,InvestigatorName1,InvestigatorName2,InvestigatorName3,RootCauseParamId,OtherRootCause,CustomerId,CustomerJobNumber,CustName,ContractorId,ContractorJobNumber,ContName,InvSummary,FollowUpNote,RiskOfRecurrenceId,IncidentSeverityId,SourceDetails,RootCauseNote,UpdatedByName,';
 SET @Postition = LOCATE(',', @myArrayOfValue);
WHILE ( @Postition > 0 ) DO
 SET @STR = SUBSTRING(@myArrayOfValue, 1, @Postition-1);
 SET @myArrayOfValue = SUBSTRING(@myArrayOfValue, @Postition + 1);
 SET @Col =  extractvalue(xmlData, CONCAT('//',@STR));
	IF (@Col != '' AND @Col !='NULL') THEN
	IF (@STR  = 'CreatorName' ) then set @STR= 'EmployeeName';  END IF;
	IF (@STR  = 'InvSourceParamId' ) then set @STR= 'IncInvSourceName';  END IF;
	IF (@STR  = 'IncidentId' ) then set @STR= 'incident_versions_view.IncidentId';  END IF;
	IF (@STR  = 'EventTypeId' ) then set @STR= 'EventTypeName';  END IF;
	IF (@STR  = 'OperationTypeId' ) then set @STR= 'OperationTypeName';  END IF;
	IF (@STR  = 'Location1Id' ) then set @STR= 'Location1Name';  END IF;
	IF (@STR  = 'Location2Id' ) then set @STR= 'Location2Name';  END IF;
	IF (@STR  = 'Location3Id' ) then set @STR= 'Location3Name';  END IF;
	IF (@STR  = 'Location4Id' ) then set @STR= 'Location4Name';  END IF;
	IF (@STR  = 'OEDepartmentId' ) then set @STR= 'OEDepartmentName';  END IF;
	IF (@STR  = 'EnvConditions' ) then set @STR= 'EnvConditionName';  END IF;
	IF (@STR  = 'ObservationAndAnalysisParamId' ) then set @STR= 'ObserAnaName';  END IF;
	IF (@STR  = 'InvStatusId' ) then set @STR= 'InvStatusName';  END IF;
	IF (@STR  = 'CustomerId' ) then set @STR= 'CustomerName';  END IF;
	IF (@STR  = 'ContractorId' ) then set @STR= 'ContractorName';  END IF;
	IF (@STR  = 'RiskOfRecurrenceId' ) then set @STR= 'RiskOfRecurrenceName';  END IF;
	IF (@STR  = 'IncidentSeverityId' ) then set @STR= 'IncidentSeverityName';  END IF;
	IF (@STR  = 'SignOffInvestigatorId' ) then set @STR= 'SignOffInvestigatorName';  END IF;
	IF (@STR  = 'RootCauseParamId' ) then set @STR= 'RootCauseName';  END IF;
	
	IF (@STR  = 'AssignedToId' ) then set @STR= 'AssignedToName';  END IF;
	IF (@STR  = 'TaskStatusId' ) then set @STR= 'StatusName';  END IF;
	IF (@STR  = 'PriorityId' ) then set @STR= 'PriorityName';  END IF;
	IF (@STR  = 'EmployeeId' ) then set @STR= 'AlsoNotifyName';  END IF;
	IF (@STR  = 'TaskDescription' ) then set @STR= 'Description';  END IF;
	
	IF (@STR  = 'DamageDriverLicence' ) then set @STR= 'hist_vehicle_damage.DriverLicence';  END IF;
	IF (@STR  = 'DamageVehicleTypeId' ) then set @STR= 'hist_vehicle_damage.VehicleTypeName';  END IF;
	IF (@STR  = 'DamageVehicleLicence' ) then set @STR= 'hist_vehicle_damage.VehicleLicence';  END IF;
	IF (@STR  = 'TrafficDriverName' ) then set @STR= 'hist_traffic_violation.DriverName';  END IF;
	IF (@STR  = 'TrafficDriverLicence' ) then set @STR= 'hist_traffic_violation.DriverName';  END IF;
	IF (@STR  = 'TrafficVehicleTypeId' ) then set @STR= 'hist_traffic_violation.DriverLicence';  END IF;
	IF (@STR  = 'TrafficVehicleLicence' ) then set @STR= 'hist_traffic_violation.VehicleTypeName';  END IF;
	IF (@STR  = 'Illness_PersonalInjured' ) then set @STR= 'hist_illness.PersonalAfflictedName';  END IF;
	IF (@STR  = 'Illness_RestrictedWorkId' ) then set @STR= 'hist_illness.RestrictedWorkName';  END IF;
	IF (@STR  = 'Illness_InitialTreatmentId' ) then set @STR= 'hist_illness.InitialTreatmentName';  END IF;
	IF (@STR  = 'SymptomsId' ) then set @STR= 'hist_illness.SymptomsName';  END IF;
	IF (@STR  = 'Illness_LostTimeStart' ) then set @STR= 'hist_illness.LostTimeStart';  END IF;
	IF (@STR  = 'Illness_LostTimeEnd' ) then set @STR= 'hist_illness.LostTimeEnd';  END IF;
	IF (@STR  = 'Illness_AdjustmentDays' ) then set @STR= 'hist_illness.AdjustmentDays';  END IF;
	IF (@STR  = 'Illness_TotalDaysOff' ) then set @STR= 'hist_illness.TotalDaysOff';  END IF;
	
	IF (@STR  = 'PersonalInjured' ) then set @STR= 'hist_injury.PersonalInjuredName';  END IF;
	IF (@STR  = 'RestrictedWorkId' ) then set @STR= 'hist_injury.RestrictedWorkName';  END IF;
	IF (@STR  = 'InitialTreatmentId' ) then set @STR= 'hist_injury.InitialTreatmentName';  END IF;
	IF (@STR  = 'BodyAreaId' ) then set @STR= 'hist_injury.BodyAreaName';  END IF;
	IF (@STR  = 'LostTimeStart' ) then set @STR= 'hist_injury.LostTimeStart';  END IF;
	IF (@STR  = 'LostTimeEnd' ) then set @STR= 'hist_injury.LostTimeEnd';  END IF;
	IF (@STR  = 'AdjustmentDays' ) then set @STR= 'hist_injury.AdjustmentDays';  END IF;
	IF (@STR  = 'TotalDaysOff' ) then set @STR= 'hist_injury.TotalDaysOff';  END IF;
	IF (@STR  = 'InjuryTypeId' ) then set @STR= 'InjuryTypeName';  END IF;
	IF (@STR  = 'BodyPartId' ) then set @STR= 'BodyPartName';  END IF;
	IF (@STR  = 'ContactCodeId' ) then set @STR= 'ContactCodeName';  END IF;
	IF (@STR  = 'RecordableId' ) then set @STR= 'RecordableName';  END IF;
	IF (@STR  = 'SourceId' ) then set @STR= 'SourceName';  END IF;
	IF (@STR  = 'DurationUnitId' ) then set @STR= 'DurationUnit';  END IF;
	IF (@STR  = 'QuantityUnitId' ) then set @STR= 'QuantityUnit';  END IF;
	IF (@STR  = 'RecoveredUnitId' ) then set @STR= 'QuantityRecoveredUnit';  END IF;
	IF (@STR  = 'ImpactsExtAgencyId' ) then set @STR= 'incident_versions_view.ExtAgencyName';  END IF;
    
    IF (@STR  = 'ImpactSubTypeId' ) then set @STR= 'incident_versions_view.ImpactSubTypeName';  END IF;
    IF (@STR  = 'ImpactTypeId' ) then set @STR= 'incident_versions_view.ImpactTypeName';  END IF;
	IF (@STR  = 'ImpactDescription' ) then set @STR= 'incident_versions_view.ImpactDescription';  END IF;
	IF (@STR  = 'IntEmployeeName1' ) then set @STR= 'incident_versions_view.IntEmployeeName1';  END IF;
	IF (@STR  = 'IntEmployeeDept1' ) then set @STR= 'incident_versions_view.IntEmployeeDept1';  END IF;
	IF (@STR  = 'IntEmployeeName2' ) then set @STR= 'incident_versions_view.IntEmployeeName2';  END IF;
	IF (@STR  = 'IntEmployeeDept2' ) then set @STR= 'incident_versions_view.IntEmployeeDept2';  END IF;
	IF (@STR  = 'IntEmployeeName3' ) then set @STR= 'incident_versions_view.IntEmployeeName3';  END IF;
	IF (@STR  = 'IntEmployeeDept3' ) then set @STR= 'incident_versions_view.IntEmployeeDept3';  END IF;
	IF (@STR  = 'PrimRespondName' ) then set @STR= 'incident_versions_view.PrimRespondName';  END IF;
    
  SET @queryWhere = CONCAT(@queryWhere,CONCAT(' AND ',@STR,' like('"'%", @Col ,"%'"') ')); 
 END IF;
 
 SET @Postition = LOCATE(',', @myArrayOfValue);
END WHILE;
SET @IncidentDateFrom =  extractvalue(xmlData, '//IncidentDateFrom');
SET @IncidentDateTo =  extractvalue(xmlData, '//IncidentDateTo');
IF(@IncidentDateTo != '') THEN
	SET @IncidentDateFrom  = STR_TO_DATE(@IncidentDateFrom , '%m/%d/%Y');
	SET @IncidentDateTo  = STR_TO_DATE(@IncidentDateTo , '%m/%d/%Y');
	SET @IncidentDateTo2 = DATE_ADD(@IncidentDateTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_versions_view.IncidentDate >  ', "'" , @IncidentDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_versions_view.IncidentDate <=  ', "'",  @IncidentDateTo2  ,"'" );										
ELSE 
IF(@IncidentDateTo = '' AND @IncidentDateFrom !='' ) THEN
	SET @IncidentDateFrom  = STR_TO_DATE(@IncidentDateFrom , '%m/%d/%Y');
	SET @IncidentDateFrom2 = DATE_ADD(@IncidentDateFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_versions_view.IncidentDate >=  ',  "'", @IncidentDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_versions_view.IncidentDate <  ', "'", @IncidentDateFrom2  ,"'");	
END IF;
END IF;
SET @InvestigationDateFrom =  extractvalue(xmlData, '//InvestigationDateFrom');
SET @InvestigationDateTo =  extractvalue(xmlData, '//InvestigationDateTo');
IF(@InvestigationDateTo != '') THEN
	SET @InvestigationDateFrom  = STR_TO_DATE(@InvestigationDateFrom , '%m/%d/%Y');
	SET @InvestigationDateTo  = STR_TO_DATE(@InvestigationDateTo , '%m/%d/%Y');
	SET @InvestigationDateTo2 = DATE_ADD(@InvestigationDateTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_versions_view.InvestigationDate >  ', "'" , @InvestigationDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_versions_view.InvestigationDate <=  ', "'",  @InvestigationDateTo2  ,"'" );										
ELSE 
IF(@InvestigationDateTo = '' AND @InvestigationDateFrom !='' ) THEN
	SET @InvestigationDateFrom  = STR_TO_DATE(@InvestigationDateFrom , '%m/%d/%Y');
	SET @InvestigationDateFrom2 = DATE_ADD(@InvestigationDateFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_versions_view.InvestigationDate >=  ',  "'", @InvestigationDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_versions_view.InvestigationDate <  ', "'", @InvestigationDateFrom2  ,"'");	
END IF;
END IF;
SET @SignOffDateFrom =  extractvalue(xmlData, '//SignOffDateFrom');
SET @SignOffDateTo =  extractvalue(xmlData, '//SignOffDateTo');
IF(@SignOffDateTo != '') THEN
	SET @SignOffDateFrom  = STR_TO_DATE(@SignOffDateFrom , '%m/%d/%Y');
	SET @SignOffDateTo  = STR_TO_DATE(@SignOffDateTo , '%m/%d/%Y');
	SET @SignOffDateTo2 = DATE_ADD(@SignOffDateTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_versions_view.SignOffDate >  ', "'" , @SignOffDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_versions_view.SignOffDate <=  ', "'",  @SignOffDateTo2  ,"'" );										
ELSE 
IF(@SignOffDateTo = '' AND @SignOffDateFrom !='' ) THEN
	SET @SignOffDateFrom  = STR_TO_DATE(@SignOffDateFrom , '%m/%d/%Y');
	SET @SignOffDateFrom2 = DATE_ADD(@SignOffDateFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_versions_view.SignOffDate >=  ',  "'", @SignOffDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_versions_view.SignOffDate <  ', "'", @SignOffDateFrom2  ,"'");	
END IF;
END IF;
SET @UpdatedDateFrom =  extractvalue(xmlData, '//UpdatedDateFrom');
SET @UpdatedDateTo =  extractvalue(xmlData, '//UpdatedDateTo');
IF(@UpdatedDateTo != '') THEN
	SET @UpdatedDateFrom  = STR_TO_DATE(@UpdatedDateFrom , '%m/%d/%Y');
	SET @UpdatedDateTo  = STR_TO_DATE(@UpdatedDateTo , '%m/%d/%Y');
	SET @UpdatedDateTo2 = DATE_ADD(@UpdatedDateTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_versions_view.UpdatedDate >  ', "'" , @UpdatedDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_versions_view.UpdatedDate <=  ', "'",  @UpdatedDateTo2  ,"'" );										
ELSE 
IF(@UpdatedDateTo = '' AND @UpdatedDateFrom !='' ) THEN
	SET @UpdatedDateFrom  = STR_TO_DATE(@UpdatedDateFrom , '%m/%d/%Y');
	SET @UpdatedDateFrom2 = DATE_ADD(@UpdatedDateFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_versions_view.UpdatedDate >=  ',  "'", @UpdatedDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_versions_view.UpdatedDate <  ', "'", @UpdatedDateFrom2  ,"'");	
END IF;
END IF;
SET @EstimatedCostTo =  extractvalue(xmlData, '//ImpactEstimatedCostTo');
SET @EstimatedCostFrom =  extractvalue(xmlData, '//ImpactEstimatedCostFrom'); 
IF( @EstimatedCostTo !='' ) THEN	
	SET @queryWhere = CONCAT(@queryWhere,' AND  incident_versions_view.EstimatedCost  BETWEEN ', @EstimatedCostFrom, ' and ', @EstimatedCostTo);
ELSE 
IF( @EstimatedCostFrom !=''  and @EstimatedCostFrom != 'NULL')	 THEN
	set  @EstimatedCostFrom  = (replace(@EstimatedCostFrom, '&lt;', '<'));
	set  @EstimatedCostFrom  = (replace(@EstimatedCostFrom, '&gt;', '>'));
	SET @queryWhere = CONCAT(@queryWhere,' AND  incident_versions_view.EstimatedCost  ', @EstimatedCostFrom);
	END IF;
END IF;
SET @WCBCostTo =  extractvalue(xmlData, '//WCBCostTo');
SET @WCBCostFrom =  extractvalue(xmlData, '//WCBCostFrom');
IF( @WCBCostTo !='' ) THEN
	SET @queryWhere = CONCAT(@queryWhere,' AND  WCBCost  BETWEEN ', @WCBCostFrom, ' and ', @WCBCostTo);
ELSE 
	IF( @WCBCostFrom !=''  and @WCBCostFrom != 'NULL')	 THEN
set  @WCBCostFrom  = (replace(@WCBCostFrom, '&lt;', '<'));
set  @WCBCostFrom  = (replace(@WCBCostFrom, '&gt;', '>'));
		SET @queryWhere = CONCAT(@queryWhere,' AND  WCBCost  ', @WCBCostFrom);
	END IF;
END IF;
SET @RepairCostTo =  extractvalue(xmlData, '//RepairCostTo');
SET @RepairCostFrom =  extractvalue(xmlData, '//RepairCostFrom');
IF( @RepairCostTo !='' ) THEN
	SET @queryWhere = CONCAT(@queryWhere,' AND  RepairCost  BETWEEN ', @RepairCostFrom, ' and ', @RepairCostTo);
ELSE 
	IF( @RepairCostFrom !=''  and @RepairCostFrom != 'NULL')	 THEN
set  @RepairCostFrom  = (replace(@RepairCostFrom, '&lt;', '<'));
set  @RepairCostFrom  = (replace(@RepairCostFrom, '&gt;', '>'));
		SET @queryWhere = CONCAT(@queryWhere,' AND  RepairCost  ', @RepairCostFrom);
	END IF;
END IF;
SET @OtherCostTo =  extractvalue(xmlData, '//OtherCostTo');
SET @OtherCostFrom =  extractvalue(xmlData, '//OtherCostFrom');
IF( @OtherCostTo !='' ) THEN
	SET @queryWhere = CONCAT(@queryWhere,' AND  OtherCost  BETWEEN ', @OtherCostFrom, ' and ', @OtherCostTo);
ELSE 
	IF( @OtherCostFrom !=''  and @OtherCostFrom != 'NULL')	 THEN
set  @OtherCostFrom  = (replace(@OtherCostFrom, '&lt;', '<'));
set  @OtherCostFrom  = (replace(@OtherCostFrom, '&gt;', '>'));
		SET @queryWhere = CONCAT(@queryWhere,' AND  OtherCost  ', @OtherCostFrom);
	END IF;
END IF;
SET @OtherCostTo =  extractvalue(xmlData, '//OtherCostTo');
SET @OtherCostFrom =  extractvalue(xmlData, '//OtherCostFrom');
IF( @OtherCostTo !='' ) THEN
	SET @queryWhere = CONCAT(@queryWhere,' AND  OtherCost  BETWEEN ', @OtherCostFrom, ' and ', @OtherCostTo);
ELSE 
	IF( @OtherCostFrom !=''  and @OtherCostFrom != 'NULL')	 THEN
set  @OtherCostFrom  = (replace(@OtherCostFrom, '&lt;', '<'));
set  @OtherCostFrom  = (replace(@OtherCostFrom, '&gt;', '>'));
		SET @queryWhere = CONCAT(@queryWhere,' AND  OtherCost  ', @OtherCostFrom);
	END IF;
END IF;
SET @ResponseCostTo =  extractvalue(xmlData, '//ResponseCostTo');
SET @ResponseCostFrom =  extractvalue(xmlData, '//ResponseCostFrom');
IF( @ResponseCostTo !='' ) THEN
	SET @queryWhere = CONCAT(@queryWhere,' AND  ResponseCost  BETWEEN ', @ResponseCostFrom, ' and ', @ResponseCostTo);
ELSE 
	IF( @ResponseCostFrom !=''  and @ResponseCostFrom != 'NULL')	 THEN
set  @ResponseCostFrom  = (replace(@ResponseCostFrom, '&lt;', '<'));
set  @ResponseCostFrom  = (replace(@ResponseCostFrom, '&gt;', '>'));
		SET @queryWhere = CONCAT(@queryWhere,' AND  ResponseCost  ', @ResponseCostFrom);
	END IF;
END IF;
SET @TotalCostTo =  extractvalue(xmlData, '//TotalCostTo');
SET @TotalCostFrom =  extractvalue(xmlData, '//TotalCostFrom');
IF( @TotalCostTo !='' ) THEN
	SET @queryWhere = CONCAT(@queryWhere,' AND  TotalCost  BETWEEN ', @TotalCostFrom, ' and ', @TotalCostTo);
ELSE 
	IF( @TotalCostFrom !=''  and @TotalCostFrom != 'NULL')	 THEN
set  @TotalCostFrom  = (replace(@TotalCostFrom, '&lt;', '<'));
set  @TotalCostFrom  = (replace(@TotalCostFrom, '&gt;', '>'));
		SET @queryWhere = CONCAT(@queryWhere,' AND  TotalCost  ', @TotalCostFrom);
	END IF;
END IF;
-- 
SET @LostTimeStartFrom =  extractvalue(xmlData, '//LostTimeStartFrom');
SET @LostTimeStartTo =  extractvalue(xmlData, '//LostTimeStartTo');
IF(@LostTimeStartTo != '') THEN
	SET @LostTimeStartFrom  = STR_TO_DATE(@LostTimeStartFrom , '%m/%d/%Y');
	SET @LostTimeStartTo  = STR_TO_DATE(@LostTimeStartTo , '%m/%d/%Y');
	SET @LostTimeStartTo2 = DATE_ADD(@LostTimeStartTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_injury.LostTimeStart >  ', "'" , @LostTimeStartFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_injury.LostTimeStart <=  ', "'",  @LostTimeStartTo2  ,"'" );										
ELSE 
IF(@LostTimeStartTo = '' AND @LostTimeStartFrom !='' ) THEN
	SET @LostTimeStartFrom  = STR_TO_DATE(@LostTimeStartFrom , '%m/%d/%Y');
	SET @LostTimeStartFrom2 = DATE_ADD(@LostTimeStartFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_injury.LostTimeStart >=  ',  "'", @LostTimeStartFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_injury.LostTimeStart <  ', "'", @LostTimeStartFrom2  ,"'");	
END IF;
END IF;
SET @LostTimeEndFrom =  extractvalue(xmlData, '//LostTimeEndFrom');
SET @LostTimeEndTo =  extractvalue(xmlData, '//LostTimeEndTo');
IF(@LostTimeEndTo != '') THEN
	SET @LostTimeEndFrom  = STR_TO_DATE(@LostTimeEndFrom , '%m/%d/%Y');
	SET @LostTimeEndTo  = STR_TO_DATE(@LostTimeEndTo , '%m/%d/%Y');
	SET @LostTimeEndTo2 = DATE_ADD(@LostTimeEndTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_injury.LostTimeEnd >  ', "'" , @LostTimeEndFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_injury.LostTimeEnd <=  ', "'",  @LostTimeEndTo2  ,"'" );										
ELSE 
IF(@LostTimeEndTo = '' AND @LostTimeEndFrom !='' ) THEN
	SET @LostTimeEndFrom  = STR_TO_DATE(@LostTimeEndFrom , '%m/%d/%Y');
	SET @LostTimeEndFrom2 = DATE_ADD(@LostTimeEndFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_injury.LostTimeEnd >=  ',  "'", @LostTimeEndFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_injury.LostTimeEnd <  ', "'", @LostTimeEndFrom2  ,"'");	
END IF;
END IF;
SET @Illness_LostTimeStartFrom =  extractvalue(xmlData, '//Illness_LostTimeStartFrom');
SET @Illness_LostTimeStartTo =  extractvalue(xmlData, '//Illness_LostTimeStartTo');
IF(@Illness_LostTimeStartTo != '') THEN
	SET @Illness_LostTimeStartFrom  = STR_TO_DATE(@Illness_LostTimeStartFrom , '%m/%d/%Y');
	SET @Illness_LostTimeStartTo  = STR_TO_DATE(@Illness_LostTimeStartTo , '%m/%d/%Y');
	SET @Illness_LostTimeStartTo2 = DATE_ADD(@Illness_LostTimeStartTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_illness.Illness_LostTimeStart >  ', "'" , @Illness_LostTimeStartFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_illness.Illness_LostTimeStart <=  ', "'",  @Illness_LostTimeStartTo2  ,"'" );										
ELSE 
IF(@Illness_LostTimeStartTo = '' AND @Illness_LostTimeStartFrom !='' ) THEN
	SET @Illness_LostTimeStartFrom  = STR_TO_DATE(@Illness_LostTimeStartFrom , '%m/%d/%Y');
	SET @Illness_LostTimeStartFrom2 = DATE_ADD(@Illness_LostTimeStartFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_illness.Illness_LostTimeStart >=  ',  "'", @Illness_LostTimeStartFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_illness.Illness_LostTimeStart <  ', "'", @Illness_LostTimeStartFrom2  ,"'");	
END IF;
END IF;
SET @Illness_LostTimeEndFrom =  extractvalue(xmlData, '//Illness_LostTimeEndFrom');
SET @Illness_LostTimeEndTo =  extractvalue(xmlData, '//Illness_LostTimeEndTo');
IF(@Illness_LostTimeEndTo != '') THEN
	SET @Illness_LostTimeEndFrom  = STR_TO_DATE(@Illness_LostTimeEndFrom , '%m/%d/%Y');
	SET @Illness_LostTimeEndTo  = STR_TO_DATE(@Illness_LostTimeEndTo , '%m/%d/%Y');
	SET @Illness_LostTimeEndTo2 = DATE_ADD(@Illness_LostTimeEndTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_illness.Illness_LostTimeEnd >  ', "'" , @Illness_LostTimeEndFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_illness.Illness_LostTimeEnd <=  ', "'",  @Illness_LostTimeEndTo2  ,"'" );										
ELSE 
IF(@Illness_LostTimeEndTo = '' AND @Illness_LostTimeEndFrom !='' ) THEN
	SET @Illness_LostTimeEndFrom  = STR_TO_DATE(@Illness_LostTimeEndFrom , '%m/%d/%Y');
	SET @Illness_LostTimeEndFrom2 = DATE_ADD(@Illness_LostTimeEndFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_illness.Illness_LostTimeEnd >=  ',  "'", @Illness_LostTimeEndFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_illness.Illness_LostTimeEnd <  ', "'", @Illness_LostTimeEndFrom2  ,"'");	
END IF;
END IF;
-- 
-- corrective actions search
SET @StartDateFrom =  extractvalue(xmlData, '//StartDateFrom');
SET @StartDateTo =  extractvalue(xmlData, '//StartDateTo');
IF(@StartDateTo != '') THEN
	SET @StartDateFrom  = STR_TO_DATE(@StartDateFrom , '%m/%d/%Y');
	SET @StartDateTo  = STR_TO_DATE(@StartDateTo , '%m/%d/%Y');
	SET @StartDateTo2 = DATE_ADD(@StartDateTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_corrective_action.StartDate >  ', "'" , @StartDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_corrective_action.StartDate <=  ', "'",  @StartDateTo2  ,"'" );										
ELSE 
IF(@StartDateTo = '' AND @StartDateFrom !='' ) THEN
	SET @StartDateFrom  = STR_TO_DATE(@StartDateFrom , '%m/%d/%Y');
	SET @StartDateFrom2 = DATE_ADD(@StartDateFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_corrective_action.StartDate >=  ',  "'", @StartDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_corrective_action.StartDate <  ', "'", @StartDateFrom2  ,"'");	
END IF;
END IF;
SET @TargetEndDateFrom =  extractvalue(xmlData, '//TargetEndDateFrom');
SET @TargetEndDateTo =  extractvalue(xmlData, '//TargetEndDateTo');
IF(@TargetEndDateTo != '') THEN
	SET @TargetEndDateFrom  = STR_TO_DATE(@TargetEndDateFrom , '%m/%d/%Y');
	SET @TargetEndDateTo  = STR_TO_DATE(@TargetEndDateTo , '%m/%d/%Y');
	SET @TargetEndDateTo2 = DATE_ADD(@TargetEndDateTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_corrective_action.TargetEndDate >  ', "'" , @TargetEndDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_corrective_action.TargetEndDate <=  ', "'",  @TargetEndDateTo2  ,"'" );										
ELSE 
IF(@TargetEndDateTo = '' AND @TargetEndDateFrom !='' ) THEN
	SET @TargetEndDateFrom  = STR_TO_DATE(@TargetEndDateFrom , '%m/%d/%Y');
	SET @TargetEndDateFrom2 = DATE_ADD(@TargetEndDateFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_corrective_action.TargetEndDate >=  ',  "'", @TargetEndDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_corrective_action.TargetEndDate <  ', "'", @TargetEndDateFrom2  ,"'");	
END IF;
END IF;
SET @ActualEndDateFrom =  extractvalue(xmlData, '//ActualEndDateFrom');
SET @ActualEndDateTo =  extractvalue(xmlData, '//ActualEndDateTo');
IF(@ActualEndDateTo != '') THEN
	SET @ActualEndDateFrom  = STR_TO_DATE(@ActualEndDateFrom , '%m/%d/%Y');
	SET @ActualEndDateTo  = STR_TO_DATE(@ActualEndDateTo , '%m/%d/%Y');
	SET @ActualEndDateTo2 = DATE_ADD(@ActualEndDateTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_corrective_action.ActualEndDate >  ', "'" , @ActualEndDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_corrective_action.ActualEndDate <=  ', "'",  @ActualEndDateTo2  ,"'" );										
ELSE 
IF(@ActualEndDateTo = '' AND @ActualEndDateFrom !='' ) THEN
	SET @ActualEndDateFrom  = STR_TO_DATE(@ActualEndDateFrom , '%m/%d/%Y');
	SET @ActualEndDateFrom2 = DATE_ADD(@ActualEndDateFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_corrective_action.ActualEndDate >=  ',  "'", @ActualEndDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_corrective_action.ActualEndDate <  ', "'", @ActualEndDateFrom2  ,"'");	
END IF;
END IF;
SET @TaskEstimatedCostTo =  extractvalue(xmlData, '//TaskEstimatedCostTo');
SET @TaskEstimatedCostFrom =  extractvalue(xmlData, '//TaskEstimatedCostFrom');
IF( @TaskEstimatedCostTo !='' ) THEN
	SET @queryWhere = CONCAT(@queryWhere,' AND  hist_corrective_action.TaskEstimatedCost  BETWEEN ', @TaskEstimatedCostFrom, ' and ', @TaskEstimatedCostTo);
ELSE 
	IF( @TaskEstimatedCostFrom !=''  and @TaskEstimatedCostFrom != 'NULL')	 THEN
set  @TaskEstimatedCostFrom  = (replace(@TaskEstimatedCostFrom, '&lt;', '<'));
set  @TaskEstimatedCostFrom  = (replace(@TaskEstimatedCostFrom, '&gt;', '>'));
		SET @queryWhere = CONCAT(@queryWhere,' AND  hist_corrective_action.TaskEstimatedCost  ', @TaskEstimatedCostFrom);
	END IF;
END IF;
SET @IsEmerRP =  extractvalue(xmlData, '//IsEmerRP');
IF (@IsEmerRP != '' AND @IsEmerRP !='NULL') THEN
	IF( @IsEmerRP  != '2' ) THEN 
		SET @queryWhere = CONCAT(@queryWhere,'  AND IsEmerRP = ',  @IsEmerRP ); 
	END IF;	
END IF;
SET @DesiredResults =  extractvalue(xmlData, '//DesiredResults');
IF (@DesiredResults != '' AND @DesiredResults !='NULL') THEN
	IF( @DesiredResults  != '2' ) THEN 
		SET @queryWhere = CONCAT(@queryWhere,'  AND DesiredResults = ',  @DesiredResults ); 
	END IF;	
END IF;
/* end where conditions  */
SET @queryWhere = CONCAT(@queryWhere, '  group by incident_versions_view.HistIncidentId  ');
SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere, @queryhave );
-- select @query;
SET @querycount =  CONCAT( 'SELECT count(*) into @cnt from  (', @query, ' ) t');
PREPARE stmt1 FROM @querycount;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
SET @selectquery = CONCAT (@selectquery,', ', @cnt, ' as Count ');
SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere , @queryhave);
IF (@index  = 'incident.Location1Id' 		or @index  = 'Location1Id') 		then set @index= 'location1.Location1Name'; end if; 
IF (@index  = 'incident.Location2Id' 		or @index  = 'Location2Id') 		then set @index= 'location2.Location2Name'; end if;  
IF (@index  = 'incident.Location3Id' 		or @index  = 'Location3Id')		 	then set @index= 'location3.Location3Name'; end if; 
IF (@index  = 'incident.Location4Id' 		or @index  = 'Location4Id') 		then set @index= 'location4.Location4Name'; end if; 
IF (@index  = 'incident.OperationTypeId' 	or @index  = 'OperationTypeId') 	then set @index= 'operation_type.OperationTypeName'; end if;  
IF (@index  = 'incident.RiskOfRecurrenceId' or @index  = 'RiskOfRecurrenceId') 	then set @index= 'risk_of_recurrence.RiskOfRecurrenceName'; end if;  
IF (@index  = 'incident.IncidentSeverityId' or @index  = 'IncidentSeverityId') 	then set @index= 'incident_severity.IncidentSeverityName'; end if;  
IF (@index  = 'incident.InvStatusId' 		or @index  = 'InvStatusId') 		then set@index='inv_status.InvStatusName'; end if;
IF (@index  = 'ImpactEstimatedCost' ) then set @index= 'incident_versions_view.EstimatedCost';  END IF;
SET @query = CONCAT(@query, ' order by ', @index,'  ', @sortOrder);
if( @Export ="false") then
SET @page = (@page - 1) * @limit;
SET @query = CONCAT(@query, ' LIMIT ', @limit ,' OFFSET ',  @page);
end if;
PREPARE stmt1 FROM @query;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
-- select CONCAT( @selectquery, @queryFrom, @queryWhere );
-- select @query;
END
;
