CREATE PROCEDURE ABCanTrackV2.InsertInto_hist_impact(IN `$ImpactId`         VARCHAR(100),
                                                     IN `$OldImpactId`      VARCHAR(100),
                                                     IN `$OriginalImpactId` VARCHAR(100),
                                                     IN `$UpdatedById`      VARCHAR(100))
  BEGIN
/*
DECLARE @IncidentId  varchar(100) ;
DECLARE @ImpactTypeName varchar(255);
DECLARE @ImpactSubTypeName  varchar(255) ;
DECLARE @ImpactDescription  TEXT ;
DECLARE @OldImpactDescription TEXT ;
DECLARE @ExtAgencyName  TEXT ;
DECLARE @IntEmployeeName1  varchar(255) ;
DECLARE @IntEmployeeDept1  varchar(255) ;
DECLARE @IntEmployeeName2  varchar(255) ;
DECLARE @IntEmployeeDept2  varchar(255) ;
DECLARE @IntEmployeeName3  varchar(255) ;
DECLARE @IntEmployeeDept3  varchar(255) ;
DECLARE @CustomOpenTxt  TEXT ;
DECLARE @OldCustomOpenTxt TEXT ;
DECLARE @PrimRespondName  varchar(255) ;
DECLARE @EstimatedCost  DECIMAL(10,2) ;
DECLARE @HistoryOperationId  varchar(100) ;
DECLARE @UpdatedDate  DATETIME ;
DECLARE @UpdatedByName varchar(255) ;
DECLARE @HistIncidentId varchar(100);
DECLARE @VersionNumber INT;
*/
SET @UpdatedByName = (  select concat(firstname ,' ', lastname) from employee where employeeid = $UpdatedById ) ;
SET @IncidentId = ( select incidentid from impact where impactid = $ImpactId  );
SET @ImpactTypeName = (select ImpactTypeName from impact_type where impacttypeid = (select impacttypeid from impact_sub_type where impactsubTypeid = (select impactsubtypeid from impact where impactid = $ImpactId)));
SET @ImpactSubTypeName = (  select impactsubtypename from impact_sub_type where impactsubtypeid = (select ImpactSubTypeid from impact where impactid = $ImpactId) );
SET @ImpactDescription = ( select Description from impact where impactid = $ImpactId  );
			if($OldImpactId is null) then
			SET  @OldImpactDescription =( select concat(DATE_FORMAT(curdate(), '%b %d %Y'),' ', '(',@UpdatedByName,')',': ', ifnull((@ImpactDescription), '') ));
			ELSE
			SET  @OldImpactDescription = ( select concat(DATE_FORMAT(curdate(), '%b %d %Y'),' ', '(',@UpdatedByName,')',': ', ifnull((@ImpactDescription), '') ,' <br><br> ', ifnull((OldImpactDescription), '')) from hist_impact where ImpactId = $OldImpactId limit 1);
			END IF;
SET @ExtAgencyName = ( select group_concat(ExtAgencyName separator' ;| ') from external_agency where ExtAgencyId in (select ExtAgencyId from impacts_ext_agency where impactid = $ImpactId));
SET @IntEmployeeName1 = (  select IntEmployeeName1 from impact where impactid = $ImpactId );
SET @IntEmployeeDept1 = (  select IntEmployeeDept1 from impact where impactid = $ImpactId );
SET @IntEmployeeName2 = (  select IntEmployeeName2 from impact where impactid = $ImpactId );
SET @IntEmployeeDept2 = (  select IntEmployeeDept2 from impact where impactid = $ImpactId );
SET @IntEmployeeName3 = (  select IntEmployeeName3 from impact where impactid = $ImpactId );
SET @IntEmployeeDept3 = (  select IntEmployeeDept3 from impact where impactid = $ImpactId );
if($OriginalImpactId is null or $OriginalImpactId = '') then
	SET  $OriginalImpactId=	$ImpactId ;
END IF;
SET @PrimRespondName = ( select primrespondname from impact where impactid = $ImpactId  );
SET @EstimatedCost = (  select estimatedcost from impact where impactid = $ImpactId );
	SET @VersionNumber = (SELECT MAX(VersionNumber) FROM hist_incident WHERE IncidentId = @IncidentId);
	SET @HistIncidentId = (SELECT HistIncidentId FROM hist_incident WHERE IncidentId = @IncidentId AND VersionNumber = @VersionNumber);
	SET @HistoryOperationId = (SELECT HistoryOperationId FROM hist_incident WHERE HistIncidentId = @HistIncidentId);
SET @UpdatedDate = current_timestamp();
INSERT INTO `hist_impact`
(
`HistImpactId`,
`ImpactId`,
`IncidentId`,
`ImpactTypeName`,
`ImpactSubTypeName`,
`ImpactDescription`,
`OldImpactDescription`,
`ExtAgencyName`,
`IntEmployeeName1`,
`IntEmployeeDept1`,
`IntEmployeeName2`,
`IntEmployeeDept2`,
`IntEmployeeName3`,
`IntEmployeeDept3`,
`PrimRespondName`,
`EstimatedCost`,
`HistoryOperationId`,
`UpdatedById`,
`UpdatedDate`,
`HistIncidentId`,
`OriginalImpactId`
)
VALUES
(
MyUUID(),
$ImpactId,
@IncidentId,
@ImpactTypeName,
@ImpactSubTypeName,
@ImpactDescription,
@OldImpactDescription,
@ExtAgencyName,
@IntEmployeeName1,
@IntEmployeeDept1,
@IntEmployeeName2,
@IntEmployeeDept2,
@IntEmployeeName3,
@IntEmployeeDept3,
@PrimRespondName,
@EstimatedCost,
@HistoryOperationId,
$UpdatedById,
@UpdatedDate,
@HistIncidentId,
$OriginalImpactId
);
END;
