CREATE PROCEDURE ABCanTrackV2.DeletionInfo(IN xmlData TEXT)
  BEGIN
SET @Orgid = extractvalue(xmlData, '//OrgId');
SET @page = extractvalue(xmlData, '//page');
SET @limit = extractvalue(xmlData, '//limit');
SET @sortOrder =  extractvalue(xmlData, '//sortOrder');
SET @index =  extractvalue(xmlData, '//index');
SET @Export =  extractvalue(xmlData, '//Export');
set @selectquery ="SELECT OrgId,inc_deletion_info.IncidentId,FirstName, LastName,Position, IncidentNumber, DeletionDate, DeletionReason  ";
set @queryFrom = " FROM inc_deletion_info
join employee on employee.EmployeeId = inc_deletion_info.EmployeeId   ";
SET @queryWhere = 'where 1 = 1 ';
IF (@OrgId != '' AND @OrgId !='0') THEN
	SET @queryWhere = CONCAT(@queryWhere,' and OrgId =   "', @Orgid,'" ');
END IF;
SET @myArrayOfValue = 'FirstName,LastName,Position,IncidentNumber,DeletionReason, ';
                    
SET @Postition = LOCATE(',', @myArrayOfValue);
WHILE ( @Postition > 0 ) DO
 SET @STR = SUBSTRING(@myArrayOfValue, 1, @Postition-1);
 SET @myArrayOfValue = SUBSTRING(@myArrayOfValue, @Postition + 1);
 SET @Col =  extractvalue(xmlData, CONCAT('//',@STR));
 IF (@Col != '' AND @Col !='NULL') THEN
 
 if(@STR ='IncidentId') then
 set @STR = 'inc_deletion_info.IncidentId';
 end if;
 
 
    SET @queryWhere = CONCAT(@queryWhere,CONCAT(' AND   ',@STR,'  like '"'%", @Col ,"%'")); 
 END IF;
 
 SET @Postition = LOCATE(',', @myArrayOfValue);
END WHILE;
SET @DeletionDateFrom =  extractvalue(xmlData, '//DeletionDateFrom');
SET @DeletionDateTo =  extractvalue(xmlData, '//DeletionDateTo');
IF(@DeletionDateTo ="" AND @DeletionDateFrom !="" ) THEN
	SET @DeletionDateFrom  = STR_TO_DATE(@DeletionDateFrom , '%m/%d/%Y');
	SET @DeletionDateFrom2 = DATE_ADD(@DeletionDateFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND DeletionDate >=  ',  "'", @DeletionDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND DeletionDate <  ', "'", @DeletionDateFrom2  ,"'");
ELSE IF(@DeletionDateTo !="") then
		SET @DeletionDateFrom  = STR_TO_DATE(@DeletionDateFrom , '%m/%d/%Y');
		SET @DeletionDateTo  = STR_TO_DATE(@DeletionDateTo , '%m/%d/%Y');
		SET @DeletionDateTo2 = DATE_ADD(@DeletionDateTo ,INTERVAL 1 DAY) ;
		SET @queryWhere = CONCAT(@queryWhere,'  AND DeletionDate >  ', "'" , @DeletionDateFrom ,"'" );	
		SET @queryWhere = CONCAT(@queryWhere,'  AND DeletionDate <=  ', "'",  @DeletionDateTo2  ,"'" );	
	
	END IF;
END IF;
SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );
 -- select  @queryWhere;
SET @querycount =  CONCAT( 'SELECT count(*) into @cnt from  (', @query, ' ) t');
PREPARE stmt1 FROM @querycount;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
--
 SET @selectquery = CONCAT (@selectquery,', ', @cnt, ' as Count ');
SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );
 if(@index ='EmailLogId') then
 set @index = 'hst.EmailLogId';
 end if;
SET @query = CONCAT(@query, ' order by `', @index,'`  ', @sortOrder);
if( @Export ="false") then
SET @page = (@page - 1) * @limit;
SET @query = CONCAT(@query, ' LIMIT ', @limit ,' OFFSET ',  @page);
end if;
-- select  @query;
PREPARE stmt1 FROM @query;
EXECUTE stmt1;
-- select @query; 
END;
