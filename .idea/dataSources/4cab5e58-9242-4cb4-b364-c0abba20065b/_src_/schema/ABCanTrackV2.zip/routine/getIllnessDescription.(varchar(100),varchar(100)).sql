CREATE FUNCTION ABCanTrackV2.getIllnessDescription(`$IllnessId` VARCHAR(100), `$OriginalIllnessId` VARCHAR(100))
  RETURNS TEXT
  BEGIN
IF $OriginalIllnessId is null   or $OriginalIllnessId  =''   then
	SET $OriginalIllnessId = $IllnessId ;
END IF;
SET SESSION group_concat_max_len = 10000;
SELECT (GROUP_CONCAT(DATE_FORMAT(UpdatedDate, '%b %d %Y') ,' ', '(',  CONCAT(firstname ,' ', lastname) ,')',': <pr>', IllnessDescription separator '<br><br>' ) ) AS IllnessDescription   
 INTO @newIllnessDescription 
 FROM(
 SELECT UpdatedDate, IllnessDescription, firstname,lastname FROM hist_illness hi 
JOIN employee e ON e.EmployeeId = hi.UpdatedbyId
 WHERE OriginalIllnessId = $OriginalIllnessId  
ORDER BY UpdatedDate asc  ) temp ; 
RETURN @newIllnessDescription;
END;
