CREATE PROCEDURE ABCanTrackV2.InsertIncInvSourceValue(IN `$IncidentId` VARCHAR(100))
  BEGIN
DECLARE $HistIncidentId VARCHAR(100);
-- DECLARE $IncInvSourceName TEXT;
DECLARE $VersionNumber INT;
SET $VersionNumber = (SELECT MAX(VersionNumber) FROM hist_incident WHERE IncidentId = $IncidentId);
SET $HistIncidentId = (SELECT HistIncidentId FROM hist_incident WHERE IncidentId = $IncidentId AND VersionNumber = $VersionNumber);
SET @IncInvSourceName = (SELECT group_concat(InvSourceName SEPARATOR ' ;| ') FROM inv_source WHERE InvSourceId IN (SELECT InvSourceId FROM inc_inv_source WHERE incidentid = $incidentid));
UPDATE hist_incident
SET IncInvSourceName = @IncInvSourceName
WHERE HistIncidentId = $HistIncidentId;
END;
