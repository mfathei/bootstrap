CREATE PROCEDURE ABCanTrackV2.ins_org_env_cond_params(IN `$OldEnvCondId` VARCHAR(100), IN `$NewEnvCondId` VARCHAR(100),
                                                      IN `$LangId`       VARCHAR(100))
  BEGIN
DECLARE p_finished INTEGER DEFAULT 0;
DECLARE $pcode, $pid ,$NewId VARCHAR(255);
 DECLARE p_cursor CURSOR FOR
 select op.EnvCondParameterId,op.FieldCode from `ABCanTrackV2`.env_cond_parameter op
 WHERE op.EnvConditionId = $OldEnvCondId AND op.LanguageId = $LangId;
 -- declare NOT FOUND handler
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET p_finished = 1;
    
 open p_cursor;
-- FETCH g_p_cursor INTO $gid , $fcode, $pcode, $pid;
ex: LOOP
	FETCH p_cursor INTO $pid ,$pcode;
	IF p_finished = 1 THEN 
		LEAVE ex;
	END IF;
-- select $fcode,$pcode;
    INSERT INTO `ABCanTrackV2`.`env_cond_parameter`
    (
        `env_cond_parameter`.`FieldCode`,
        `env_cond_parameter`.`LanguageId`,
        `env_cond_parameter`.`EnvCondParameterName`,
        `env_cond_parameter`.`EnvConditionId`,
        `env_cond_parameter`.`Order`,
        `env_cond_parameter`.`LastUpdateDate`,
        `env_cond_parameter`.`EditingBy`,
        `env_cond_parameter`.`Hide`
    )
    SELECT
        `env_cond_parameter`.`FieldCode`,
        `env_cond_parameter`.`LanguageId`,
        `env_cond_parameter`.`EnvCondParameterName`,
        $NewEnvCondId,
        `env_cond_parameter`.`Order`,
        CURRENT_TIMESTAMP(),
        `env_cond_parameter`.`EditingBy`,
        `env_cond_parameter`.`Hide`
    FROM `ABCanTrackV2`.`env_cond_parameter` where EnvCondParameterId = $pid AND LanguageId = $LangId;
END LOOP ex;
CLOSE p_cursor;
END;
