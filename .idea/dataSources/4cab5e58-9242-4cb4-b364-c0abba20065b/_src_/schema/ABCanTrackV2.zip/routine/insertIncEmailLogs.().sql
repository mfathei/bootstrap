CREATE PROCEDURE ABCanTrackV2.insertIncEmailLogs()
  begin
	
    declare eid varchar(255);
    declare hid varchar(255);
    declare finished int default 0;

	DECLARE g_p_cursor CURSOR FOR
	SELECT ce.EmailLogId,hi.HistIncidentId FROM ABCanTrackV2.corr_act_email ce
	join hist_corrective_action hi on (hi.HistCorrectiveActionId = ce.HistCorrectiveActionId)
    join email_log el on(el.EmailLogId = ce.EmailLogId);
 -- declare NOT FOUND handler
	DECLARE CONTINUE HANDLER 
	FOR NOT FOUND SET finished = 1;

set @counter = 0;

 OPEN g_p_cursor;
-- FETCH g_p_cursor INTO $gid , $fcode, $pcode, $pid;
ex: LOOP
	FETCH g_p_cursor INTO eid , hid;
	IF finished = 1 THEN 
		LEAVE ex;
	END IF;
    
    insert into inc_email_log(HistIncidentId,EmailLogId) 
    select * from(select hid, eid) as tmp
    where not exists(
		select HistIncidentId,EmailLogId from inc_email_log where HistIncidentId=hid and EmailLogId=eid
    ) limit 1;
    
    set @counter = @counter + 1;
    
    end loop ex;
    
    close g_p_cursor;

select @counter;

end;
