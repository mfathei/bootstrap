CREATE FUNCTION ABCanTrackV2.REPLACEYESNO(`$OrgId` VARCHAR(100), `$AlertMessageCode` VARCHAR(100))
  RETURNS VARCHAR(255)
  BEGIN
declare $lblItem varchar(255)  charset utf8;


set @LanguageId= (select LanguageId from organization where OrgId = $OrgId );
 
SET $lblItem = (SELECT AlertMessageDescription FROM CommonDB.alert_message
				where AlertMessageCode=$AlertMessageCode and LanguageId=@LanguageId);
                
RETURN $lblItem;
END;
