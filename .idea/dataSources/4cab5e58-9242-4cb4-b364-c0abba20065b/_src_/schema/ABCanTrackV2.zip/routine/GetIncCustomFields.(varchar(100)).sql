CREATE PROCEDURE ABCanTrackV2.GetIncCustomFields(IN `$IncidentId` VARCHAR(100))
  BEGIN
DECLARE $FieldValueId, $MinFieldValueId, $MaxFieldValueId varchar(100);
DECLARE $FieldLabel varchar(255);
DECLARE $FieldLabelTrim varchar(255);
DECLARE $SelectStmts TEXT;
DECLARE $query1 TEXT;
#declare variable
  DECLARE fid, vid int;
  -- DECLARE v_id, v_agency_id INT DEFAULT NULL;
  DECLARE done INT DEFAULT FALSE;
  
-- SET $MinFieldValueId = (select Min(FieldValueId) from field_value where IncidentId = $IncidentId);
-- SET $MaxFieldValueId = (select Max(FieldValueId) from field_value where IncidentId = $IncidentId);
  -- declare cursor
  DECLARE cur1 CURSOR FOR SELECT fieldid, MIN(FieldValueId) AS FieldValueId FROM field_value WHERE IncidentId = $IncidentId GROUP BY fieldid;
 
  #declare handle 
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
 
 
-- First query: get custom fields
SET @stmt1Select = ' Select `field_value`.`IncidentId` AS `IncidentId` ';
SET @stmt1From = ' FROM (`field_value`
		  JOIN `org_field` ON ((`org_field`.`FieldId` = `field_value`.`FieldId`))) ';
		
SET @stmt1Where = CONCAT(' WHERE ((`field_value`.`IncidentId` = "',$IncidentId,'")
		AND (`org_field`.`IsHidden` <> 1)) ');		
		
-- Loop on custom fields
SET @Cust1 = '';
SET @Cust2 = ''	;
  -- open cursor
  OPEN cur1;
 
  -- starts the loop
  the_loop: LOOP
 
    -- get the values of each column into our variables
    FETCH cur1 INTO fid, vid;
    IF done THEN
      LEAVE the_loop;
    END IF;
 
    #Do some post processing
    SET $FieldLabel = (SELECT FieldLabel FROM org_field WHERE FieldId = fid limit 1); -- (SELECT Fieldid FROM field_value WHERE FieldValueId = $MinFieldValueId));
    SET $FieldLabelTrim = TRIM($FieldLabel);
    SET @Cust1 = CONCAT(@Cust1,' , (CASE WHEN (TRIM(`org_field`.`FieldLabel`) =  '', $FieldLabelTrim,'' ) THEN (SELECT GROUP_CONCAT(`field_value`.`FieldValue` SEPARATOR ',') FROM (`field_value` JOIN `org_field` ON ((`org_field`.`FieldId` = `field_value`.`FieldId`))) WHERE ((`field_value`.`IncidentId` = "', $IncidentId,'") AND (TRIM(`org_field`.`FieldLabel`) = '', $FieldLabelTrim, '') AND (`org_field`.`IsHidden` <> 1))) END) AS `', $FieldLabelTrim, '_',fid,'` ');
    SET @Cust2 = CONCAT(@Cust2,' , GROUP_CONCAT(`custom_fields_view`.`', $FieldLabelTrim,'_',fid,'` SEPARATOR ',') AS `', $FieldLabelTrim,'` ');
 
  END LOOP the_loop;
 
  CLOSE cur1;
/*
FieldLoop: While $MinFieldValueId <= $MaxFieldValueId 
do 
set $FieldLabel = (select FieldLabel from org_field where FieldId = (select Fieldid from field_value where FieldValueId = $MinFieldValueId));
SET $FieldLabelTrim = TRIM($FieldLabel);
set @Cust1 = Concat(@Cust1,' , (CASE WHEN (TRIM(`org_field`.`FieldLabel`) =  \'', $FieldLabelTrim,'\' ) THEN (SELECT GROUP_CONCAT(`field_value`.`FieldValue` SEPARATOR \',\') FROM (`field_value` JOIN `org_field` ON ((`org_field`.`FieldId` = `field_value`.`FieldId`))) WHERE ((`field_value`.`IncidentId` = ', $IncidentId,') AND (TRIM(`org_field`.`FieldLabel`) = \'', $FieldLabelTrim, '\') AND (`org_field`.`IsHidden` <> 1))) END) AS `', $FieldLabelTrim, '` ');
SET @Cust2 = CONCAT(@Cust2,' , GROUP_CONCAT(`custom_fields_view`.`', $FieldLabelTrim,'` SEPARATOR \',\') AS `', $FieldLabelTrim,'` ');
-- ghada: should increment to the next custom field
If ($MinFieldValueId = $MaxFieldValueId)
Then
 LEAVE FieldLoop;
Else
 SET $FieldValueId = $MinFieldValueId;
 SET $MinFieldValueId = (SELECT MIN(FieldValueId) FROM field_value WHERE IncidentId = $IncidentId AND FieldValueId > $FieldValueId);
End If;
END WHILE;
*/
SET @query1 = CONCAT( @stmt1Select, @Cust1, @stmt1From, @stmt1Where);
select @query1 ;
/*PREPARE stmt1 FROM @query1;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
select @query1;
*/
-- Second query: group custom fields
SET @stmt2Select1 = ' Select `custom_fields_view`.`IncidentId`     AS `IncID` ';
SET @stmt2Select2 = ' , incident.* ';
SET @stmt2From = CONCat(' FROM ((',@query1,') as `custom_fields_view`
			JOIN `incident`
			ON ((`incident`.`IncidentId` = `custom_fields_view`.`IncidentId`)))
			GROUP BY `custom_fields_view`.`IncidentId` ');
	
SET @query2 = CONCAT( @stmt2Select1, @Cust2, @stmt2Select2, @stmt2From);
select @query2;
PREPARE stmt2 FROM @query2;
EXECUTE stmt2;
DEALLOCATE PREPARE stmt2; 
/*
select @query2;
*/
END;
