CREATE PROCEDURE ABCanTrackV2.AddEmailTemplateToAllOrgs(IN `$TemplateId` VARCHAR(100))
  BEGIN
DECLARE $max, $min, $OrgId varchar(100);
SET $OrgId = (select OrgId from email_template where TemplateId = $TemplateId);
if $OrgId is null
then
set $min = (select min(orgid) from organization);
set $max = (select max(orgid) from organization);
OrgLoop: while $min <= $max
do
    INSERT INTO `ABCanTrackV2`.`email_template`
(    
    `email_template`.`EmailTemplateId`,
    `email_template`.`OrgId`,
    `email_template`.`EmailTypeId`,
    `email_template`.`Title`,
    `email_template`.`Subject`,
    `email_template`.`Body`,
    `email_template`.`UpdatedDate`,
    `email_template`.`IsActive`,
    `email_template`.`Order`
)
select 
	  MyUUID(),    
	  $min,     
     `EmailTypeId`,
     `Title`,
     `Subject`,
     `Body`,
     `UpdatedDate`,
     `IsActive`,
     `Order`
 from email_template where TemplateId = $TemplateId
;
if 
$min = $max
then 
leave OrgLoop;
else
set $min = (select min(orgid) from organization where OrgId > $min);
End if;
end while;
end if;
END;
