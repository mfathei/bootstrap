CREATE PROCEDURE ABCanTrackV2.procEmployeeExistsInTable()
  BEGIN
DECLARE $Min, $Max, $EmployeeName VARCHAR(255);
DECLARE $TableName TEXT;
SET $Min = (SELECT MIN(EmployeeId) FROM .employee WHERE EmployeeId NOT IN (SELECT employeeId FROM ABCanTrackV2.org_employee));
SET $Max = (SELECT MAX(EmployeeId) FROM ABCanTrackV2.employee WHERE EmployeeId NOT IN (SELECT employeeId FROM ABCanTrackV2.org_employee));
EmpLoop: WHILE $Min <= $Max
DO	
	
	SET $EmployeeName = (SELECT CONCAT(FirstName , ' ' , LastName) FROM employee WHERE EmployeeId = $Min);
    
	SET $TableName = (SELECT EmployeeExistsInTable($Min));
	IF ($TableName IS NULL OR $TableName = '')
	THEN
		IF $Min = $Max
		THEN
			LEAVE EmpLoop;
		ELSE
			SET $Min = (SELECT MIN(EmployeeId) FROM ABCanTrackV2.employee WHERE EmployeeId NOT IN (SELECT employeeId FROM ABCanTrackV2.org_employee) AND EmployeeId > $Min);
		END IF;
	ELSE
    
		SELECT $Min, $EmployeeName, $TableName AS ExistsInTable;
        
		IF $Min = $Max
		THEN
			LEAVE EmpLoop;
		ELSE
			SET $Min = (SELECT MIN(EmployeeId) FROM ABCanTrackV2.employee WHERE EmployeeId NOT IN (SELECT employeeId FROM ABCanTrackV2.org_employee) AND EmployeeId > $Min);
		END IF;
    END IF;
    
END WHILE;
END;
