CREATE PROCEDURE ABCanTrackV2.openTextInjury(IN `$IncidentId` VARCHAR(100))
  begin
    set session group_concat_max_len = 10000;
     SELECT distinct 
        `injury`.InjuryId,
        `impact_type`.`ImpactTypeName` AS `ImpactTypeId`,
        `impact_type`.`ImpactTypeCode` AS `ImpactTypeCode`,
        `impact_sub_type`.`ImpactSubTypeName` AS `ImpactSubTypeId`,
        `injury`.`IntEmployeeName1` AS `IntEmployeeName1`,
        `injury`.`IntEmployeeName2` AS `IntEmployeeName2`,
        `injury`.`IntEmployeeName3` AS `IntEmployeeName3`,
        `injury`.`IntEmployeeDept1` AS `IntEmployeeDept1`,
        `injury`.`IntEmployeeDept2` AS `IntEmployeeDept2`,
        `injury`.`IntEmployeeDept3` AS `IntEmployeeDept3`,
        `injury`.`PrimRespondName` AS `PrimRespondName`,
        `injury`.`Description` AS `Description`,
        getInjuryDescription(`hist_injury`.`InjuryId`,
                `hist_injury`.`OriginalInjuryId`) AS `OldImpactDescription`,
      --  `injury`.`EstimatedCost` AS `ImpactEstimatedCost`,
      CASE `injury`.`EstimatedCost` WHEN '0.00' THEN ''  END AS `ImpactEstimatedCost`,
        (SELECT  
                GROUP_CONCAT(DISTINCT `external_agency`.`ExtAgencyName`
                        SEPARATOR ', ')
            FROM
                (`impacts_ext_agency`
                JOIN `external_agency` ON ((`external_agency`.`ExtAgencyId` = `impacts_ext_agency`.`ExtAgencyId`)))
            WHERE
                (`impacts_ext_agency`.`InjuryId` = `injury`.`InjuryId`)
            GROUP BY `impacts_ext_agency`.`InjuryId`) AS `ExtAgencyId`,
        `injury`.`PersonalInjuredName` AS `PersonalInjured`,
        `initial_treatment`.`InitialTreatmentName` AS `InitialTreatmentId`,
        `contact_code`.`ContactCodeName` AS `ContactCodeId`,
        `injury_recordable`.`RecordableName` AS `RecordableId`,
        `restricted_work`.`RestrictedWorkName` AS `RestrictedWorkId`,
        DATE_FORMAT(`injury`.`LostTimeStart`, '%m/%d/%Y') AS `LostTimeStart`,
        DATE_FORMAT(`injury`.`LostTimeEnd`, '%m/%d/%Y') AS `LostTimeEnd`,
        `injury`.`AdjustmentDays` AS `AdjustmentDays`,
        `injury`.`TotalDaysOff` AS `TotalDaysOff`,
        `injury`.`InjuryDescription` AS `ImpactTypeDescription`,
        getInjuryDescription2(`hist_injury`.`InjuryId`,
                `hist_injury`.`OriginalInjuryId`) AS `OldImpactTypeDescription`,
        `contact_agency`.`ContactAgencyName` AS `InjuryExtAgencyId`,
        (SELECT 
                GROUP_CONCAT(`injury_type`.`InjuryTypeName`
                        SEPARATOR ' ; ')
            FROM
                `injury_type`
            WHERE
                `injury_type`.`InjuryTypeId` IN (SELECT 
                        `injury_type_injury`.`InjuryTypeId`
                    FROM
                        `injury_type_injury`
                    WHERE
                        (`injury_type_injury`.`InjuryId` = `injury`.`InjuryId`))) AS `InjuryTypeId`,
        (SELECT 
                GROUP_CONCAT(`body_part`.`BodyPartName`
                        SEPARATOR ' ; ')
            FROM
                `body_part`
            WHERE
                `body_part`.`BodyPartId` IN (SELECT 
                        `body_part_injury`.`BodyPartId`
                    FROM
                        `body_part_injury`
                    WHERE
                        (`body_part_injury`.`InjuryId` = `injury`.`InjuryId`))) AS `BodyPartId`,
        (SELECT 
                GROUP_CONCAT(`body_area`.`BodyAreaName`
                        SEPARATOR ' ; ')
            FROM
                `body_area`
            WHERE
                `body_area`.`BodyAreaId` IN (SELECT 
                        `body_area_injury`.`BodyAreaId`
                    FROM
                        `body_area_injury`
                    WHERE
                        (`body_area_injury`.`InjuryId` = `injury`.`InjuryId`))) AS `BodyAreaId`
    FROM
        ((((((((`injury`
        JOIN `impact_sub_type` ON ((`impact_sub_type`.`ImpactSubTypeId` = `injury`.`ImpactSubTypeId`)))
        JOIN `impact_type` ON ((`impact_sub_type`.`ImpactTypeId` = `impact_type`.`ImpactTypeId`)))
        LEFT JOIN `initial_treatment` ON ((`injury`.`InitialTreatmentId` = `initial_treatment`.`InitialTreatmentId`)))
        LEFT JOIN `contact_code` ON ((`injury`.`ContactCodeId` = `contact_code`.`ContactCodeId`)))
        LEFT JOIN `injury_recordable` ON ((`injury`.`RecordableId` = `injury_recordable`.`RecordableId`)))
        LEFT JOIN `restricted_work` ON ((`injury`.`RestrictedWorkId` = `restricted_work`.`RestrictedWorkId`)))
        LEFT JOIN `contact_agency` ON ((`injury`.`ContactAgencyId` = `contact_agency`.`ContactAgencyId`)))
        JOIN `hist_injury` ON ((`hist_injury`.`InjuryId` = `injury`.`InjuryId`))) 
	where injury.Incidentid = $IncidentId;
        end;
