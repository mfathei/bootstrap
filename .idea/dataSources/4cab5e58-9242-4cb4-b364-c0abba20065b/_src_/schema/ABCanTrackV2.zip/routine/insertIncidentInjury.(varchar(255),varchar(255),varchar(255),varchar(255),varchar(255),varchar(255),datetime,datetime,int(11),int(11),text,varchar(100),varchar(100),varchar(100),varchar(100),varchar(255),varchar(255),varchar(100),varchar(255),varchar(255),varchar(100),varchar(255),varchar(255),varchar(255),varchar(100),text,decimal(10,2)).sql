CREATE PROCEDURE ABCanTrackV2.insertIncidentInjury(IN `$PersonalInjuredName` VARCHAR(255),
                                                   IN `$PersonalInjuredId`   VARCHAR(255),
                                                   IN `$InitialTreatmentId`  VARCHAR(255),
                                                   IN `$ContactCodeId`       VARCHAR(255),
                                                   IN `$RecordableId`        VARCHAR(255),
                                                   IN `$RestrictedWorkId`    VARCHAR(255), IN `$LostTimeStart` DATETIME,
                                                   IN `$LostTimeEnd`         DATETIME, IN `$AdjustmentDays` INT,
                                                   IN `$TotalDaysOff`        INT, IN `$InjuryDescription` TEXT,
                                                   IN `$IncidentId`          VARCHAR(100),
                                                   IN `$ImpactSubTypeId`     VARCHAR(100),
                                                   IN `$ContactAgencyId`     VARCHAR(100),
                                                   IN `$IntEmployeeId1`      VARCHAR(100),
                                                   IN `$IntEmployeeName1`    VARCHAR(255),
                                                   IN `$IntEmployeeDept1`    VARCHAR(255),
                                                   IN `$IntEmployeeId2`      VARCHAR(100),
                                                   IN `$IntEmployeeName2`    VARCHAR(255),
                                                   IN `$IntEmployeeDept2`    VARCHAR(255),
                                                   IN `$IntEmployeeId3`      VARCHAR(100),
                                                   IN `$IntEmployeeName3`    VARCHAR(255),
                                                   IN `$IntEmployeeDept3`    VARCHAR(255),
                                                   IN `$PrimRespondName`     VARCHAR(255),
                                                   IN `$PrimRespondId`       VARCHAR(100), IN `$Description` TEXT,
                                                   IN `$EstimatedCost`       DECIMAL(10, 2))
    my_proc :BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        SELECT 0 ;
        ROLLBACK ;
    END ;
    DECLARE EXIT HANDLER FOR SQLWARNING 
    BEGIN
        SELECT 0 ;
        ROLLBACK ;
    END ;
    
    SET $IntEmployeeId1 = 
    (SELECT 
        EmployeeId 
    FROM
        employee 
    WHERE EmployeeId = $IntEmployeeId1) ;
    SET $IntEmployeeId2 = 
    (SELECT 
        EmployeeId 
    FROM
        employee 
    WHERE EmployeeId = $IntEmployeeId2) ;
    SET $IntEmployeeId3 = 
    (SELECT 
        EmployeeId 
    FROM
        employee 
    WHERE EmployeeId = $IntEmployeeId3) ;
    SET $PrimRespondId = 
    (SELECT 
        EmployeeId 
    FROM
        employee 
    WHERE EmployeeId = $PrimRespondId) ;
    
    SET $PersonalInjuredId = 
    (SELECT 
        EmployeeId 
    FROM
        employee 
    WHERE EmployeeId = $PersonalInjuredId) ;
    
    SET $InitialTreatmentId = 
    (SELECT 
        `InitialTreatmentId` 
    FROM
        initial_treatment 
    WHERE `InitialTreatmentId` = $InitialTreatmentId) ;
    
    SET $ContactCodeId = 
    (SELECT 
        `ContactCodeId` 
    FROM
        contact_code 
    WHERE `ContactCodeId` = $ContactCodeId) ;
    
    SET $RecordableId = 
    (SELECT 
        `RecordableId` 
    FROM
        injury_recordable 
    WHERE `RecordableId` = $RecordableId) ;
    
    SET $RestrictedWorkId = 
    (SELECT 
        `RestrictedWorkId` 
    FROM
        restricted_work 
    WHERE `RestrictedWorkId` = $RestrictedWorkId) ;
    
    SET $ImpactSubTypeId = 
    (SELECT 
        `ImpactSubTypeId` 
    FROM
        impact_sub_type 
    WHERE `ImpactSubTypeId` = $ImpactSubTypeId) ;
    
    SET $ContactAgencyId = 
    (SELECT 
        `ContactAgencyId` 
    FROM
        contact_agency 
    WHERE `ContactAgencyId` = $ContactAgencyId) ;
    
    SET $ContactAgencyId = 
    (SELECT 
        `ContactAgencyId` 
    FROM
        contact_agency 
    WHERE `ContactAgencyId` = $ContactAgencyId) ;
    
    INSERT INTO injury (
    PersonalInjuredName,
    PersonalInjuredId,
    InitialTreatmentId,
    ContactCodeId,
    RecordableId,
    RestrictedWorkId,
    LostTimeStart,
    LostTimeEnd,
    AdjustmentDays,
    TotalDaysOff,
    InjuryDescription,
    IncidentId,
    ImpactSubTypeId,
    ContactAgencyId,
    IntEmployeeId1,
    IntEmployeeName1,
    IntEmployeeDept1,
    IntEmployeeId2,
    IntEmployeeName2,
    IntEmployeeDept2,
    IntEmployeeId3,
    IntEmployeeName3,
    IntEmployeeDept3,
    PrimRespondName,
    PrimRespondId,
    Description,
    EstimatedCost
    ) 
    VALUES
    (
        $PersonalInjuredName,
        $PersonalInjuredId,
        $InitialTreatmentId,
        $ContactCodeId,
        $RecordableId,
        $RestrictedWorkId,
        $LostTimeStart,
        $LostTimeEnd,
        $AdjustmentDays,
        $TotalDaysOff,
        $InjuryDescription,
        $IncidentId,
        $ImpactSubTypeId,
        $ContactAgencyId,
        $IntEmployeeId1,
        $IntEmployeeName1,
        $IntEmployeeDept1,
        $IntEmployeeId2,
        $IntEmployeeName2,
        $IntEmployeeDept2,
        $IntEmployeeId3,
        $IntEmployeeName3,
        $IntEmployeeDept3,
        $PrimRespondName,
        $PrimRespondId,
        $Description,
        $EstimatedCost
    );
    
    SELECT 1 ;
END;
