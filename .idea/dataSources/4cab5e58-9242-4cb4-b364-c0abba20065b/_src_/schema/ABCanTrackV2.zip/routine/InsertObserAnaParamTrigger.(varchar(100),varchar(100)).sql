CREATE PROCEDURE ABCanTrackV2.InsertObserAnaParamTrigger(IN `$OATypeId` VARCHAR(100), IN `$LangId` VARCHAR(100))
  BEGIN
DECLARE $Min, $Max, $ParentId, $DEnergyFormId VARCHAR(100);
DECLARE $OATypeCode, $ParentName VARCHAR(255);
SET $OATypeCode = (SELECT ObservationAndAnalysisCode FROM ABCanTrackV2.observation_analysis WHERE ObservationAndAnalysisId = $OATypeId AND LanguageId = $LangId);
SET $DEnergyFormId = (SELECT ObservationAndAnalysisId FROM ABCanTrackV2.observation_analysis WHERE ObservationAndAnalysisCode = $OATypeCode AND OrgId IS NULL AND LanguageId = $LangId);
	INSERT INTO `ABCanTrackV2`.`observation_analysis_param`
	(
        `FieldCode`,
	    `LanguageId`,
		`ObservationAndAnalysisId`,
		`ObservationAndAnalysisParamName`,
		`ObservationAndAnalysisParamDetails`,
		`Order`,
		`IsMulti`,
		`ParentId`,
		`LastUpdateDate`,
		`EditingBy`,
		`Hide`
	)
	SELECT
        `FieldCode`,
	    `LanguageId`,
		$OATypeId,
		`ObservationAndAnalysisParamName`,
		`ObservationAndAnalysisParamDetails`,
		`Order`,
		`IsMulti`,
		`ParentId`,
		CURRENT_TIMESTAMP(),
		`EditingBy`,
		`Hide`
	FROM  `ABCanTrackV2`.`observation_analysis_param`
	WHERE ObservationAndAnalysisId = $DEnergyFormId AND `ParentId` IS NULL AND LanguageId = $LangId;
	
	SET $Min = (SELECT MIN(ObservationAndAnalysisParamId) FROM `ABCanTrackV2`.`observation_analysis_param` WHERE ObservationAndAnalysisId = $OATypeId AND LanguageId = $LangId);	
	SET $Max = (SELECT MAX(ObservationAndAnalysisParamId) FROM `ABCanTrackV2`.`observation_analysis_param` WHERE ObservationAndAnalysisId = $OATypeId AND LanguageId = $LangId);
	ParentLoop: WHILE $Min <= $Max
	DO
		SET $ParentName = (SELECT `ObservationAndAnalysisParamName` FROM `ABCanTrackV2`.`observation_analysis_param` WHERE ObservationAndAnalysisParamId = $Min AND LanguageId = $LangId);
		SET $ParentId = (SELECT ObservationAndAnalysisParamId FROM `ABCanTrackV2`.`observation_analysis_param` WHERE ObservationAndAnalysisId = $DEnergyFormId AND ObservationAndAnalysisParamName = $ParentName AND LanguageId = $LangId);
		INSERT INTO `ABCanTrackV2`.`observation_analysis_param`
		(
			`FieldCode`,
			`LanguageId`,
			`ObservationAndAnalysisId`,
			`ObservationAndAnalysisParamName`,
			`ObservationAndAnalysisParamDetails`,
			`Order`,
			`IsMulti`,
			`ParentId`,
			`LastUpdateDate`,
			`EditingBy`,
			`Hide`
		)
		SELECT
        	`FieldCode`,
			`LanguageId`,
			$OATypeId,
			`ObservationAndAnalysisParamName`,
			`ObservationAndAnalysisParamDetails`,
			`Order`,
			`IsMulti`,
			$Min,
			CURRENT_TIMESTAMP(),
			`EditingBy`,
			`Hide`
		FROM  `ABCanTrackV2`.`observation_analysis_param`
		WHERE ObservationAndAnalysisId = $DEnergyFormId AND `ParentId` = $ParentId AND LanguageId = $LangId;
		IF $Min = $Max
		THEN
			LEAVE ParentLoop;
		ELSE
			SET $Min = (SELECT MIN(ObservationAndAnalysisParamId) FROM `ABCanTrackV2`.`observation_analysis_param` WHERE ObservationAndAnalysisId = $OATypeId AND ObservationAndAnalysisParamId > $Min AND ParentId IS NULL AND LanguageId = $LangId);
		END IF;
	END WHILE;
END;
