CREATE FUNCTION ABCanTrackV2.getEmailTypeIdByLang(pEmailTypeId VARCHAR(100), pLangId VARCHAR(100))
  RETURNS VARCHAR(100)
  BEGIN
        declare vEmailTypeId VARCHAR(100) CHARSET utf8 default null;
        set @emailTypeCode = (select EmailTypeCode from ABCanTrackV2.`email_type` where EmailTypeId = pEmailTypeId and LanguageId = ABCanTrackV2.GetLanguageId('en'));
        set vEmailTypeId = (select EmailTypeId from ABCanTrackV2.`email_type` where EmailTypeCode = @emailTypeCode and LanguageId = pLangId);
        return vEmailTypeId;
    END;
