CREATE PROCEDURE ABCanTrackV2.LockIncident(IN `$IncidentId` VARCHAR(100), IN `$EmployeeId` VARCHAR(100))
  BEGIN
 UPDATE incident
		SET LastUpdateDate = CURRENT_TIMESTAMP(),
				EditingBy  =$EmployeeId
		WHERE IncidentId   =$IncidentId ;
END;
