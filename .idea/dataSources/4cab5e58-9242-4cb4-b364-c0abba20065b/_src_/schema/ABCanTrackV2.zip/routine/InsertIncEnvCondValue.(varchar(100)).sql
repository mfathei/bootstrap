CREATE PROCEDURE ABCanTrackV2.InsertIncEnvCondValue(IN `$IncidentId` VARCHAR(100))
  BEGIN
DECLARE $HistIncidentId VARCHAR(100);
-- DECLARE $EnvConditionName TEXT;
DECLARE $VersionNumber INT;
SET $VersionNumber = (SELECT MAX(VersionNumber) FROM hist_incident WHERE IncidentId = $IncidentId);
SET $HistIncidentId = (SELECT HistIncidentId FROM hist_incident WHERE IncidentId = $IncidentId AND VersionNumber = $VersionNumber);
SET @EnvConditionName = (SELECT GROUP_CONCAT(EnvCondParameterName SEPARATOR ' ;| ') FROM env_cond_parameter WHERE EnvCondParameterId IN (SELECT EnvCondParameterId FROM inc_env_cond WHERE incidentid = $incidentid));
UPDATE hist_incident 
SET EnvConditionName = @EnvConditionName
WHERE HistIncidentId = $HistIncidentId;
END;
