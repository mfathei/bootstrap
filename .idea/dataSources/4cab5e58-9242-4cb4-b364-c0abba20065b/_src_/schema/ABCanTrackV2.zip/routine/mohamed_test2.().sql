CREATE PROCEDURE ABCanTrackV2.mohamed_test2()
  begin
select @sm;
end;
