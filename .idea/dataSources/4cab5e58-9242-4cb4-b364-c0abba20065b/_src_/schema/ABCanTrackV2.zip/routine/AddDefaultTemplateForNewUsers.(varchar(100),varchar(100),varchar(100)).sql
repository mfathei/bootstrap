CREATE PROCEDURE ABCanTrackV2.AddDefaultTemplateForNewUsers(IN `$DefaultTemplateId` VARCHAR(100),
                                                            IN `$EmployeeId`        VARCHAR(100),
                                                            IN `$GroupId`           VARCHAR(100))
  BEGIN
	DECLARE $OrgId, $NewTemplateId VARCHAR(100);
	DECLARE $TemplateName VARCHAR(100);
	SET $TemplateName = (SELECT TemplateName FROM `ABCanTrackV2`.template WHERE TemplateId = $DefaultTemplateId);
	SET $OrgId = (SELECT tbl2.OrgId FROM `ABCanTrackV2`.emp_group tbl1 JOIN `ABCanTrackV2`.`group` tbl2 ON tbl2.GroupId= tbl1.GroupId 
					WHERE EmployeeId = $EmployeeId AND tbl1.GroupId = $GroupId);
                    
	-- insert into template
	INSERT INTO `ABCanTrackV2`.`template`
	(
		`TemplateName`,
		`EmployeeId`,
		`OrgId`,
		`LastUpdatedDate`
	)
	VALUES
	(
		$TemplateName,
		$EmployeeId,
		$OrgId,
		CURRENT_TIMESTAMP()
	);
	SET $NewTemplateId = (SELECT LastId FROM `ABCanTrackV2`.last_uuid WHERE TableName = 'template');
	
	-- insert template fields into template_field from DefaultTemplateId 
	INSERT INTO `ABCanTrackV2`.`template_field`
	(
		`TemplateId`,
		`FieldId`
	)
	SELECT
	$NewTemplateId,
	`FieldId`
	FROM template_field WHERE TemplateId = $DefaultTemplateId;
	END;
