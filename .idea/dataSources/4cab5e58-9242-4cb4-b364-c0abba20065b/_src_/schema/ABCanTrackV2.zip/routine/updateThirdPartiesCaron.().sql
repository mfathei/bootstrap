CREATE PROCEDURE ABCanTrackV2.updateThirdPartiesCaron()
  begin
	declare finished int default 0;
    declare incid varchar(100);
	declare my_cur cursor for  select distinct incidentid from hist_incident where OrgId='prototest-c2121334-da73-11e4-9e79-5254009b7e74'
 and UpdatedDate>'2016-10-30'  and ThirdPartyName is null ;
 
 declare continue handler for not found set finished = 1;

	open my_cur;
    
    my_loop: loop
		fetch my_cur into incid;
        if finished = 1 then
			leave my_loop;
        end if;
        
        select ThirdPartyId, ifnull(JobNumber, ''), ifnull(ContactName, '') into @thrid, @jnum, @cntnm
        from inc_third_party where IncidentId = incid limit 1;
        
        set @ThirdPartyName = (select ThirdPartyName from third_party where ThirdPartyId = @thrid);
        
        update hist_incident set ThirdPartyName = @ThirdPartyName, JobNumber = @jnum, ContactName = @cntnm
        where IncidentId = incid and OrgId='prototest-c2121334-da73-11e4-9e79-5254009b7e74'
 and UpdatedDate>'2016-10-30'  and ThirdPartyName is null;
        
    end loop my_loop;
	close my_cur;
end;
