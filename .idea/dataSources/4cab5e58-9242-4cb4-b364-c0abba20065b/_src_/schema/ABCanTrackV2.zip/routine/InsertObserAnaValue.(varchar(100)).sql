CREATE PROCEDURE ABCanTrackV2.InsertObserAnaValue(IN `$IncidentId` VARCHAR(100))
  BEGIN
DECLARE finish INT DEFAULT 0;
DECLARE $HistIncidentId VARCHAR(100);
DECLARE $VersionNumber INT;
DECLARE $ObservationAndAnalysisCode VARCHAR(100);
DECLARE $ObservationAndAnalysisParamName VARCHAR(255);
DECLARE vEnergyForm TEXT DEFAULT '';
DECLARE vSubActions TEXT DEFAULT '';
DECLARE vUnderLyingCauses TEXT DEFAULT '';
DECLARE vSubConditions TEXT DEFAULT '';
DECLARE my_cursor CURSOR FOR
SELECT  
        ObservationAndAnalysisParamName , observation_analysis.ObservationAndAnalysisCode
FROM
    observation_analysis_param JOIN observation_analysis ON(observation_analysis_param.ObservationAndAnalysisId = observation_analysis.ObservationAndAnalysisId)
    JOIN inc_obser_ana ON(inc_obser_ana.ObservationAndAnalysisParamId = observation_analysis_param.ObservationAndAnalysisParamId)
    WHERE incidentid =  $IncidentId ;

DECLARE CONTINUE HANDLER FOR NOT FOUND SET finish=1;

SET $HistIncidentId = (SELECT HistIncidentId FROM hist_incident_vw WHERE IncidentId = $IncidentId );

    OPEN my_cursor;
    std_name_loop: LOOP
        FETCH my_cursor INTO $ObservationAndAnalysisParamName, $ObservationAndAnalysisCode;
        IF finish=1 THEN
            LEAVE std_name_loop;
        END IF;
        
        IF $ObservationAndAnalysisCode = 'EnergyForm' THEN
            IF vEnergyForm = '' THEN
                SET vEnergyForm = $ObservationAndAnalysisParamName;
            ELSE
                SET vEnergyForm = CONCAT(vEnergyForm , ';| ', $ObservationAndAnalysisParamName);
            END IF;
        ELSEIF $ObservationAndAnalysisCode = 'SubActions' THEN
            IF vSubActions = '' THEN
                SET vSubActions = $ObservationAndAnalysisParamName;
            ELSE
                SET vSubActions = CONCAT(vSubActions , ';| ', $ObservationAndAnalysisParamName);
            END IF;
        ELSEIF $ObservationAndAnalysisCode = 'SubConditions' THEN
            IF vSubConditions = '' THEN
                SET vSubConditions = $ObservationAndAnalysisParamName;
            ELSE
                SET vSubConditions = CONCAT(vSubConditions , ';| ', $ObservationAndAnalysisParamName);
            END IF;
        ELSEIF $ObservationAndAnalysisCode = 'UnderLyingCauses' THEN
            IF vUnderLyingCauses = '' THEN
                SET vUnderLyingCauses = $ObservationAndAnalysisParamName;
            ELSE
                SET vUnderLyingCauses = CONCAT(vUnderLyingCauses , ';| ', $ObservationAndAnalysisParamName);
            END IF;
        END IF;
        
    END LOOP std_name_loop;
    CLOSE my_cursor;
    
SET @ObserAnaName = (SELECT GROUP_CONCAT(ObservationAndAnalysisParamName SEPARATOR ' ;| ') FROM observation_analysis_param WHERE ObservationAndAnalysisParamId IN (SELECT ObservationAndAnalysisParamId FROM inc_obser_ana WHERE incidentid = $incidentid));
UPDATE hist_incident 
SET ObserAnaName = @ObserAnaName
WHERE HistIncidentId = $HistIncidentId;


INSERT INTO histinc_thirdparties(HistIncidentId, EnergyForm, SubActions, UnderLyingCauses, SubConditions) VALUES($HistIncidentId, vEnergyForm, vSubActions, vUnderLyingCauses, vSubConditions) ON DUPLICATE KEY UPDATE EnergyForm = vEnergyForm, SubActions = vSubActions, UnderLyingCauses = UnderLyingCauses, SubConditions = vSubConditions;

END;
