CREATE PROCEDURE ABCanTrackV2.GetInvestigationStausLabel(IN `$IncidentId` VARCHAR(100))
  BEGIN
Declare $histincidentid, $maxhistincidentid varchar(100);
Declare $HistStatusCode varchar(255);
DECLARE $VersionNumber INT;
SET $VersionNumber = (SELECT MAX(VersionNumber) FROM hist_incident WHERE incidentid = $IncidentId);
set $maxhistincidentid =  (select  HistIncidentId from hist_incident where incidentid = $IncidentId AND VersionNumber = $VersionNumber);
set $HistStatusCode = (select HistStatusCode from hist_incident 
	inner join hist_status on hist_status.HistStatusId = hist_incident.ActionStatus
	where hist_incident.histincidentid = $maxhistincidentid );
SELECT
(select concat('Investigation ',histstatusname,'	by ',concat(FirstName, ' ', LastName) ,'	at Date: ', DATE_FORMAT(updateddate, '%m/%d/%Y'))
	from hist_incident 
	inner join hist_status on hist_status.HistStatusId = hist_incident.ActionStatus
	inner join employee on employee.EmployeeId = hist_incident.UpdatedById 
	where hist_incident.histincidentid = $maxhistincidentid ) as InvestigationStausLabel ,
 
CASE $HistStatusCode
        WHEN 'Closed' THEN (select concat('Investigation sign-off info added by ', concat(FirstName, ' ', LastName) ,'	at: ', DATE_FORMAT(updateddate, '%m/%d/%Y'))
							from hist_incident 
							inner join employee on employee.EmployeeId = hist_incident.UpdatedById 
							where hist_incident.histincidentid = $maxhistincidentid ) 
		WHEN 'Re-opened' THEN  (select concat('Investigation sign-off info removed by ', concat(FirstName, ' ', LastName) ,'	at: ', DATE_FORMAT(updateddate, '%m/%d/%Y'))
								from hist_incident 
								inner join employee on employee.EmployeeId = hist_incident.UpdatedById 
								where hist_incident.histincidentid = $maxhistincidentid ) 
END AS InvestigationsignedoffLabel;
END;
