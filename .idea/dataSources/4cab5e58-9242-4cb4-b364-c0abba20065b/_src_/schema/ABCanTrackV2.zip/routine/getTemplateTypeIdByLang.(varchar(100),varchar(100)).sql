CREATE FUNCTION ABCanTrackV2.getTemplateTypeIdByLang(pTemplateTypeId VARCHAR(100), pLangId VARCHAR(100))
  RETURNS VARCHAR(100)
  BEGIN
        declare vTemplateTypeId VARCHAR(100) default NULL;
        set @templateTypeCode = (select TemplateTypeCode from ABCanTrackV2.`template_type` where TemplateTypeId = pTemplateTypeId and LanguageId = ABCanTrackV2.GetLanguageId('en'));
        set vTemplateTypeId = (select TemplateTypeId from ABCanTrackV2.`template_type` where TemplateTypeCode = @templateTypeCode and LanguageId = pLangId);
        return vTemplateTypeId;
    END;
