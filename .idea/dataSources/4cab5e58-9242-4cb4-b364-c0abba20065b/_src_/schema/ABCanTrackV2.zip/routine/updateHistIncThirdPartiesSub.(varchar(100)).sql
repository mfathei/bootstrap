CREATE PROCEDURE ABCanTrackV2.updateHistIncThirdPartiesSub(IN `$IncidentId` VARCHAR(100))
  BEGIN
            DECLARE finish INT DEFAULT 0;
          --  DECLARE vThirdPartyName VARCHAR(255);
            DECLARE vJobNumber TEXT DEFAULT '';
            DECLARE vThirdPartyId VARCHAR(100);
            DECLARE vIncidentId VARCHAR(100);
            DECLARE vContactName TEXT DEFAULT '';
            
DECLARE vCustomerName TEXT DEFAULT '';
DECLARE vCustName TEXT DEFAULT '';
DECLARE vCustomerJobNumber TEXT DEFAULT '';
DECLARE vContractorName TEXT DEFAULT '';
DECLARE vContName TEXT DEFAULT '';
DECLARE vContJobNumber TEXT DEFAULT '';
DECLARE $HistIncidentId VARCHAR(100);

            DECLARE std_name_sur CURSOR FOR 
            SELECT * FROM inc_third_party WHERE IncidentId = $IncidentId ;
            
            DECLARE CONTINUE HANDLER FOR NOT FOUND SET finish=1;
            
            SET $HistIncidentId = (SELECT HistIncidentId FROM hist_incident_vw WHERE IncidentId = $IncidentId);

            SET @cnt = 0;            
            OPEN std_name_sur;
            std_name_loop: LOOP
                FETCH std_name_sur INTO  vIncidentId, vThirdPartyId, vJobNumber, vContactName;
                IF finish=1 THEN
                    LEAVE std_name_loop;
                END IF;
                SET @cnt = @cnt + 1;
                -- ------------------------------------ custname -----------------------------------------
				SET @ThirdPartyTypeCode = (SELECT ThirdPartyTypeCode FROM third_party_type JOIN third_party ON(third_party_type.ThirdPartyTypeId = third_party.ThirdPartyTypeId) WHERE third_party.ThirdPartyId = vThirdPartyId LIMIT 1);                
       IF @ThirdPartyTypeCode = 'Customer' THEN                    
                    SELECT ThirdPartyName INTO @one FROM third_party WHERE ThirdPartyId = vThirdPartyId;
                    
            IF vCustomerName = '' THEN
			SET vCustomerName = @one;
            ELSE
                SET vCustomerName = CONCAT(vCustomerName , ';| ', @one);
            END IF;
            
            IF vCustName = '' THEN
			SET vCustName = vContactName;
            ELSE
                SET vCustName = CONCAT(vCustName , ';| ', vContactName);
            END IF;
            
            IF vCustomerJobNumber = '' THEN
			SET vCustomerJobNumber = vJobNumber;
            ELSE
                SET vCustomerJobNumber = CONCAT(vCustomerJobNumber , ';| ', vJobNumber);
            END IF;
            
                  
	ELSEIF @ThirdPartyTypeCode = 'Contractor' THEN
                    SELECT ThirdPartyName INTO @one FROM third_party WHERE ThirdPartyId = vThirdPartyId;
                    
	    IF vContractorName = '' THEN
			SET vContractorName = @one;
            ELSE
                SET vContractorName = CONCAT(vContractorName , ';| ', @one);
            END IF;
            
            IF vContName = '' THEN
			SET vContName = vContactName;
            ELSE
                SET vContName = CONCAT(vContName , ';| ', vContactName);
            END IF;
            
            IF vContJobNumber = '' THEN
			SET vContJobNumber = vJobNumber;
            ELSE
                SET vContJobNumber = CONCAT(vContJobNumber , ';| ', vJobNumber);
            END IF;                    
	END IF;
                
            END LOOP std_name_loop;
            
            INSERT INTO histinc_thirdparties(HistIncidentId, CustomerName, CustName, CustomerJobNumber) VALUES($HistIncidentId, vCustomerName, vCustName, vCustomerJobNumber) ON DUPLICATE KEY UPDATE CustomerName = vCustomerName, CustName = vCustName, CustomerJobNumber = vCustomerJobNumber;            
            
            INSERT INTO histinc_thirdparties(HistIncidentId, ContractorName, ContName, ContractorJobNumber) VALUES($HistIncidentId, vContractorName, vContName, vContJobNumber) ON DUPLICATE KEY UPDATE ContractorName = vContractorName, ContName = vContName, ContractorJobNumber = vContJobNumber;
            
            -- SELECT @cnt AS counter;
            CLOSE std_name_sur;
    END;
