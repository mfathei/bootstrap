CREATE PROCEDURE ABCanTrackV2.DeleteOrgSpillRelease(IN `$OrgId` VARCHAR(100))
  BEGIN
	DECLARE $Count INT;
    
    
    -- Step1: impacts_ext_agency
	SET $Count = (SELECT COUNT(*) FROM impacts_ext_agency WHERE SpillReleaseId IN (SELECT SpillReleaseId FROM spill_release WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId)));
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgSpillRelease',  'impacts_ext_agency', NULL, $Count, 1);
    
	-- ************
	DELETE FROM impacts_ext_agency WHERE SpillReleaseId IN (SELECT SpillReleaseId FROM spill_release WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId));
    -- #
    
    
    -- Step2: spill_release
	SET $Count = (SELECT COUNT(*) FROM spill_release WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId));
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgSpillRelease',  'spill_release', NULL, $Count, 2);
    
	-- ************
	DELETE FROM spill_release WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId);
    -- #
    
    -- Step3: DONE
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgSpillRelease', 'DONE', NULL, NULL, 3);
    -- # 
END;
