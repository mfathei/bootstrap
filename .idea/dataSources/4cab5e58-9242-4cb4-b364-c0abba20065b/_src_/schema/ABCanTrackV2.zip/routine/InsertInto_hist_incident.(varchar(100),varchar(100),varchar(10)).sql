CREATE PROCEDURE ABCanTrackV2.InsertInto_hist_incident(IN `$IncidentId`     VARCHAR(100),
                                                       IN `$UpdatedById`    VARCHAR(100),
                                                       IN `$ClientTimeZone` VARCHAR(10))
  BEGIN
IF $IncidentId <> '0'
THEN
/** start declaration**/
SET @EventTypeName = (select EventTypeName from event_type where eventtypeid = (select eventtypeid from incident where incidentid = $incidentid));
SET @OrgId = (select orgid from incident where incidentid = $incidentid);
SET @EmployeeName = (select concat(firstname ,' ', lastname) from employee where employeeid = (select creatorid from incident where incidentid = $incidentid));
SET @IncidentDate = (select incidentdate from incident where incidentid = $incidentid);
SET @IncidentHour = (select incidenthour from incident where incidentid = $incidentid);
SET @IncidentMinute = (select incidentminute from incident where incidentid = $incidentid);
SET @IsEmerRP = (select IsEmerRP from incident where incidentid = $incidentid);
if (select reporterid from incident where incidentid = $incidentid) is not null then
SET @RepName = (select concat(firstname ,' ', lastname) from employee where employeeid = (select reporterid from incident where incidentid = $incidentid));
else
set @RepName = (select RepName from incident where incidentid = $incidentid);
end if;
SET @RepEmail = (select RepEmail from incident where incidentid = $incidentid);
SET @RepPosition = (select RepPosition from incident where incidentid = $incidentid);
SET @RepCompany = (select RepCompany from incident where incidentid = $incidentid);
SET @RepPrimaryPhone = (select RepPrimaryPhone from incident where incidentid = $incidentid);
SET @RepAlternatePhone = (select RepAlternatePhone from incident where incidentid = $incidentid);
SET @Location1Name = (select location1name from location1 where location1id = (select location1id from incident where incidentid = $incidentid));
SET @Location2Name = (select location2name from location2 where location2id = (select location2id from incident where incidentid = $incidentid));
SET @Location3Name = (select location3name from location3 where location3id = (select location3id from incident where incidentid = $incidentid));
SET @Location4Name = (select location4name from location4 where location4id = (select location4id from incident where incidentid = $incidentid));
SET @OtherLocation = (select otherlocation from incident where incidentid = $incidentid);
SET @OperationTypeName = (select operationtypename from operation_type where operationtypeid = (select operationtypeid from incident where incidentid = $incidentid));
-- SET @OEDepartmentName = (select group_concat(OEDepartmentName separator ' ;| ') from oe_department where OEDepartmentid in (select OEDepartmentid from inc_oe_department where incidentid = $incidentid));
SET @EventSequence = (select eventsequence from incident where incidentid = $incidentid);
SET @EnvConditionNote = (select envconditionnote from incident where incidentid = $incidentid);
-- SET @EnvConditionName = (select group_concat(EnvCondParameterName separator ' ;| ') from env_cond_parameter where EnvCondParameterId in (select EnvCondParameterId from inc_env_cond where incidentid = $incidentid));
SET @IncDescription = (select incdescription from incident where incidentid = $incidentid);
-- SET @ObserAnaName = (select group_concat(ObservationAndAnalysisParamName separator ' ;| ') from observation_analysis_param where ObservationAndAnalysisParamId in (select ObservationAndAnalysisParamId from inc_obser_ana where incidentid = $incidentid));
-- SET @IncInvSourceName = (select group_concat(InvSourceName separator ' ;| ') from inv_source where InvSourceId in (select InvSourceId from inc_inv_source where incidentid = $incidentid));
SET @EnergyFormNote = (select energyformnote from incident where incidentid = $incidentid);
SET @SubStandardActionNote = (select substandardactionnote from incident where incidentid = $incidentid);
SET @SubStandardConditionNote = (select SubStandardConditionNote from incident where incidentid = $incidentid);
SET @UnderLyingCauseNote = (select UnderLyingCauseNote from incident where incidentid = $incidentid);
SET @InvStatusName = (select invstatusname from inv_status where invstatusid = (select invstatusid from incident where incidentid = $incidentid));
SET @InvestigationDate = (select InvestigationDate from incident where incidentid = $incidentid);
SET @InvestigatorName1 = (select InvestigatorName1 from incident where incidentid = $incidentid);
SET @InvestigatorName2 = (select InvestigatorName2 from incident where incidentid = $incidentid);
SET @InvestigatorName3 = (select InvestigatorName3 from incident where incidentid = $incidentid);
-- SET @RootCauseName = (select group_concat(RootCauseParamName separator ' ;| ') from root_cause_param where RootCauseParamId in (select RootCauseParamId from inc_root_cause where incidentid = $incidentid));
-- SET @OtherRootCause = (select group_concat(other separator ' ;| ') from inc_root_cause where incidentid = $incidentid);
-- SET @ThirdPartyName = (select group_concat(ThirdPartyName separator ' ;| ') from third_party where ThirdPartyId in (select ThirdPartyId from inc_third_party where incidentid = $incidentid));
-- SET @JobNumber = (select group_concat(JobNumber separator ' ;| ') from inc_third_party where incidentid = $incidentid);
-- SET @ContactName = (select group_concat(ContactName separator ' ;| ') from inc_third_party where incidentid = $incidentid);
SET @InvSummary = (select invsummary from incident where incidentid = $incidentid);
SET @FollowUpNote = (select FollowUpNote from incident where incidentid = $incidentid);
SET @ResponseCost = (select ResponseCost from incident where incidentid = $incidentid);
SET @RepairCost = (select RepairCost from incident where incidentid = $incidentid);
SET @InsuranceCost = (select InsuranceCost from incident where incidentid = $incidentid);
SET @WCBCost = (select WCBCost from incident where incidentid = $incidentid);
SET @OtherCost = (select OtherCost from incident where incidentid = $incidentid);
SET @TotalCost = (select TotalCost from incident where incidentid = $incidentid);
SET @RiskOfRecurrenceName = (select RiskOfRecurrenceName from risk_of_recurrence where RiskOfRecurrenceId = (select RiskOfRecurrenceId from incident where incidentid = $incidentid));
SET @IncidentSeverityName = (select IncidentSeverityName from incident_severity where IncidentSeverityId = (select IncidentSeverityId from incident where incidentid = $incidentid));
SET @SourceDetails = (select SourceDetails from incident where incidentid = $incidentid);
SET @RootCauseNote = (select RootCauseNote from incident where incidentid = $incidentid);
SET @SignOffInvestigatorName = (select SignOffInvestigatorName from incident where incidentid = $incidentid);
SET @ModifierId = (select ModifierId from incident where incidentid = $incidentid) ;
SET @SignOffDate = (select SignOffDate from incident where incidentid = $incidentid);
-- SET @UpdatedById = (select creatorid from incident where incidentid = $incidentid);
SET @oldVersionNumber = (select MAX(VersionNumber) from hist_incident where incidentid = $incidentid);                                        
/** Update section **/
SET @HistIncidentId = ( select histincidentid  from hist_incident where incidentid = $incidentid  and VersionNumber = @oldVersionNumber);
if  @HistIncidentId is not null then
SET @VersionNumber = (select (MAX(VersionNumber) + 1) from hist_incident where incidentid = $incidentid);
SET @LastInvStatusName = (select InvStatusName from hist_incident where histincidentid = @histincidentid);
SET @LastSignOffInvestigatorName = (select SignOffInvestigatorName from hist_incident where histincidentid = @histincidentid);
SET @LastSignOffDate = (select SignOffDate from hist_incident where histincidentid = @histincidentid);
SET @languageId = (SELECT languageId FROM organization WHERE OrgId =@OrgId);
SET @HistoryOperationId = (SELECT HistoryOperationId FROM ABCanTrackV2.history_operation WHERE FieldCode = 'Update'  and LanguageId = @languageId);
If  @LastInvStatusName = 'Open' and @InvStatusName = 'Closed' then
SET @ActionStatus = (select histstatusid from hist_status where histstatuscode = 'Closed') ;
End If;
If  @LastInvStatusName = 'Closed' and @InvStatusName = 'Open' then
SET @ActionStatus = (select histstatusid from hist_status where histstatuscode = 'Re-opened') ;
End IF; /** End Of InvStatus's If condition  **/
If @LastSignOffInvestigatorName Is NULL and @SignOffInvestigatorName Is Not Null then
set @ActionSignOffStatus = (select histstatusid from hist_status where histstatuscode = 'Added');
END IF;
IF (@LastSignOffInvestigatorName Is Not Null and @SignOffInvestigatorName is not null) and @LastSignOffInvestigatorName <> @SignOffInvestigatorName then
set @ActionSignOffStatus = (select histstatusid from hist_status where histstatuscode = 'Changed');
END IF;
IF @LastSignOffInvestigatorName is not null and @SignOffInvestigatorName is null then 
set @ActionSignOffStatus = (select histstatusid from hist_status where histstatuscode = 'Removed');
END IF;
If @LastSignOffDate Is NULL and @SignOffDate Is Not Null then
set @ActionDateStatus = (select histstatusid from hist_status where histstatuscode = 'Added');
END IF;
IF (@LastSignOffDate Is Not Null and @SignOffDate is not null) and @LastSignOffDate <> @SignOffDate then
set @ActionDateStatus = (select histstatusid from hist_status where histstatuscode = 'Changed');
END IF;
IF @LastSignOffDate is not null and @SignOffDate is null then 
set @ActionDateStatus = (select histstatusid from hist_status where histstatuscode = 'Removed');
END IF;
else 
SET @ActionStatus = null ;
SET @ActionSignOffStatus = null;
SET @ActionDateStatus = null; 
SET @VersionNumber = 1;
end if;
/** Update section **/
SET @languageId = (SELECT languageId FROM organization WHERE OrgId =@OrgId);
SET @HistoryOperationId = (SELECT HistoryOperationId FROM ABCanTrackV2.history_operation WHERE FieldCode = 'Add'  and LanguageId = @languageId);
SET @UpdatedDate =  TIMESTAMPADD(hour, cast($ClientTimeZone AS unsigned),UTC_TIMESTAMP());
INSERT INTO `hist_incident`
(
`HistIncidentId`,
`IncidentId`,
`EventTypeName`,
`OrgId`,
`EmployeeName`,
`IncidentDate`,
`IncidentHour`,
`IncidentMinute`,
`IsEmerRP`,
`RepName`,
`RepEmail`,
`RepPosition`,
`RepCompany`,
`RepPrimaryPhone`,
`RepAlternatePhone`,
`Location1Name`,
`Location2Name`,
`Location3Name`,
`Location4Name`,
`OtherLocation`,
`OperationTypeName`,
`EventSequence`,
`EnvConditionNote`,
`IncDescription`,
`EnergyFormNote`,
`SubStandardActionNote`,
`SubStandardConditionNote`,
`UnderLyingCauseNote`,
`InvStatusName`,
`InvestigationDate`,
`InvestigatorName1`,
`InvestigatorName2`,
`InvestigatorName3`,
`InvSummary`,
`FollowUpNote`,
`ResponseCost`,
`RepairCost`,
`InsuranceCost`,
`WCBCost`,
`OtherCost`,
`TotalCost`,
`RiskOfRecurrenceName`,
`IncidentSeverityName`,
`SourceDetails`,
`RootCauseNote`,
`SignOffInvestigatorName`,
`ModifierId`,
`SignOffDate`,
`ActionStatus`,
`ActionSignOffStatus`,
`ActionDateStatus`,
`HistoryOperationId`,
`UpdatedById`,
`UpdatedDate`,
`VersionNumber`
)
values
(
MyUUID(),
$incidentid,
@EventTypeName,
@OrgId,
@EmployeeName,
@IncidentDate,
@IncidentHour,
@IncidentMinute,
@IsEmerRP,
@RepName,
@RepEmail,
@RepPosition,
@RepCompany,
@RepPrimaryPhone,
@RepAlternatePhone,
@Location1Name,
@Location2Name,
@Location3Name,
@Location4Name,
@OtherLocation,
@OperationTypeName,
@EventSequence,
@EnvConditionNote,
@IncDescription,
@EnergyFormNote,
@SubStandardActionNote,
@SubStandardConditionNote,
@UnderLyingCauseNote,
@InvStatusName,
@InvestigationDate,
@InvestigatorName1,
@InvestigatorName2,
@InvestigatorName3,
@InvSummary,
@FollowUpNote,
@ResponseCost,
@RepairCost,
@InsuranceCost,
@WCBCost,
@OtherCost,
@TotalCost,
@RiskOfRecurrenceName,
@IncidentSeverityName,
@SourceDetails,
@RootCauseNote,
@SignOffInvestigatorName,
@ModifierId,
@SignOffDate,
@ActionStatus,
@ActionSignOffStatus,
@ActionDateStatus,
@HistoryOperationId,
$UpdatedById,
@UpdatedDate,
@VersionNumber
)
;
END IF;
END;
