CREATE PROCEDURE ABCanTrackV2.InsertInto_hist_spill_release(IN `$SpillReleaseId`         VARCHAR(100),
                                                            IN `$OldSpillReleaseId`      VARCHAR(100),
                                                            IN `$OriginalSpillReleaseId` VARCHAR(100),
                                                            IN `$UpdatedById`            VARCHAR(100))
  BEGIN 
/*
DECLARE @IncidentId  varchar(100) ;
DECLARE @SourceName  varchar(255) ;
DECLARE @DurationValue  DECIMAL(10,5) ;
DECLARE @DurationUnit  varchar(255) ;
DECLARE @QuantityValue  DECIMAL(10,5) ;
DECLARE @QuantityUnit  varchar(255) ;
DECLARE @QuantityRecoveredValue DECIMAL(10,5)  ;
DECLARE @QuantityRecoveredUnit varchar(255)  ;
DECLARE @WhatWasIt  TEXT ;
DECLARE @OldWhatWasIt TEXT ;
DECLARE @HowDidSROccur  TEXT ;
DECLARE @OldHowDidSROccur TEXT ;
DECLARE @IsReportable  BIT ;
DECLARE @ImpactTypeName varchar(255);
DECLARE @ImpactSubTypeName varchar(255)  ;
DECLARE @ExtAgencyName  TEXT ;
DECLARE @IntEmployeeName1  varchar(255) ;
DECLARE @IntEmployeeDept1  varchar(255) ;
DECLARE @IntEmployeeName2  varchar(255) ;
DECLARE @IntEmployeeDept2  varchar(255) ;
DECLARE @IntEmployeeName3  varchar(255) ;
DECLARE @IntEmployeeDept3  varchar(255) ;
DECLARE @CustomOpenTxt  TEXT ;
DECLARE @OldCustomOpenTxt TEXT ;
DECLARE @PrimRespondName  varchar(255) ;
DECLARE @ImpactDescription  TEXT ;
DECLARE @OldImpactDescription TEXT ;
DECLARE @EstimatedCost  DECIMAL(10,2) ;
DECLARE @HistoryOperationId  varchar(100) ;
DECLARE @UpdatedDate  DATETIME ;
DECLARE @UpdatedByName varchar(255) ;
DECLARE @HistIncidentId varchar(100);
DECLARE @VersionNumber INT;
*/
SET  @UpdatedByName = (  select concat(firstname ,' ', lastname) from employee where employeeid = $UpdatedById ) ;
SET @IncidentId = ( select incidentid from spill_release where SpillReleaseId = $SpillReleaseId  );
SET @SourceName = ( select sourcename from  spill_release_source where sourceid = (select sourceid from spill_release where SpillReleaseId = $SpillReleaseId) );
SET @DurationValue = ( select DurationValue from spill_release where SpillReleaseId = $SpillReleaseId  );
SET @DurationUnit = ( select DurationUnitName from  duration_unit where DurationUnitId = (select DurationUnitId from spill_release where spillreleaseid = $SpillReleaseId) );
SET @QuantityValue = ( select QuantityValue from spill_release where SpillReleaseId = $SpillReleaseId  );
SET @QuantityUnit = (  select QuantityUnitName from quantity_unit where QuantityUnitId = (select QuantityUnitId from spill_release where spillreleaseid = $SpillReleaseId) );
SET @QuantityRecoveredValue = ( select QuantityRecoveredValue from spill_release where SpillReleaseId = $SpillReleaseId  );
SET @QuantityRecoveredUnit = ( select QuantityUnitName from quantity_unit where QuantityUnitId = (select RecoveredUnitId from spill_release where spillreleaseid = $SpillReleaseId)  );
SET @WhatWasIt = (  select WhatWasIt from spill_release where SpillReleaseId = $SpillReleaseId );
if($OldSpillReleaseId is null  or $OldSpillReleaseId = '') then
set $OriginalSpillReleaseId = $SpillReleaseId;
SET  @OldWhatWasIt =( select concat(DATE_FORMAT(curdate(), '%b %d %Y'),' ', '(',@UpdatedByName,')',': ', ifnull((@WhatWasIt), '') ));
Else
SET @OldWhatWasIt = ( select concat(DATE_FORMAT(curdate(), '%b %d %Y'),' ', '(',@UpdatedByName,')',': ', ifnull((@WhatWasIt), '') ,' <br><br> ', ifnull((OldWhatWasIt), '')) from hist_spill_release where SpillReleaseId =  $OldSpillReleaseId limit 1 );
END IF;
SET @HowDidSROccur = (  select HowDidSROccur from spill_release where SpillReleaseId = $SpillReleaseId );
if($OldSpillReleaseId is null) then
SET  @OldHowDidSROccur =( select concat(DATE_FORMAT(curdate(), '%b %d %Y'),' ', '(',@UpdatedByName,')',': ', ifnull((@HowDidSROccur), '') ));
Else
SET @OldHowDidSROccur = ( select concat(DATE_FORMAT(curdate(), '%b %d %Y'),' ', '(',@UpdatedByName,')',': ', ifnull((@HowDidSROccur), '') ,' <br><br> ', ifnull((OldHowDidSROccur), '')) from hist_spill_release where SpillReleaseId =  $OldSpillReleaseId limit 1 );
END IF;
if($OriginalSpillReleaseId is null or $OriginalSpillReleaseId = '') then
set $OriginalSpillReleaseId = $SpillReleaseId;
END IF;
SET @IsReportable = (  select IsReportable from spill_release where SpillReleaseId = $SpillReleaseId );
SET @ImpactTypeName = (select ImpactTypeName from impact_type where impacttypeid = (select impacttypeid from impact_sub_type where impactsubTypeid = (select impactsubtypeid from spill_release where SpillReleaseId = $SpillReleaseId)));
SET @ImpactSubTypeName = (  select ImpactSubTypeName from impact_sub_type where impactsubtypeid = (select ImpactSubTypeid from spill_release where SpillReleaseId = $SpillReleaseId) );
SET @ExtAgencyName = ( select group_concat(ExtAgencyName separator' ;| ') from external_agency where ExtAgencyId in (select ExtAgencyId from impacts_ext_agency where SpillReleaseId = $SpillReleaseId));
SET @IntEmployeeName1 = (  select IntEmployeeName1 from spill_release where SpillReleaseId = $SpillReleaseId );
SET @IntEmployeeDept1 = (  select IntEmployeeDept1 from spill_release where SpillReleaseId = $SpillReleaseId );
SET @IntEmployeeName2 = (  select IntEmployeeName2 from spill_release where SpillReleaseId = $SpillReleaseId );
SET @IntEmployeeDept2 = (  select IntEmployeeDept2 from spill_release where SpillReleaseId = $SpillReleaseId );
SET @IntEmployeeName3 = (  select IntEmployeeName3 from spill_release where SpillReleaseId = $SpillReleaseId );
SET @IntEmployeeDept3 = (  select IntEmployeeDept3 from spill_release where SpillReleaseId = $SpillReleaseId );
-- SET @CustomOpenTxt = (  select CustomOpenTxt from spill_release where SpillReleaseId = $SpillReleaseId );
/*
if($OldSpillReleaseId is null) then
SET  @OldCustomOpenTxt =( select concat(DATE_FORMAT(curdate(), '%b %d %Y'),' ', '(',@UpdatedByName,')',': ', ifnull((@CustomOpenTxt), '') ));
Else
SET @OldCustomOpenTxt = ( select concat(DATE_FORMAT(curdate(), '%b %d %Y'),' ', '(',@UpdatedByName,')',': ', ifnull((@CustomOpenTxt), '') ,' <br><br> ', ifnull((OldCustomOpenTxt), ''))  from hist_spill_release where SpillReleaseId =  $OldSpillReleaseId limit 1);
END IF;
*/
SET @PrimRespondName = ( select primrespondname from spill_release where SpillReleaseId = $SpillReleaseId  );
SET @ImpactDescription = (  select description from spill_release where SpillReleaseId = $SpillReleaseId );
if($OldSpillReleaseId is null) then
SET  @OldImpactDescription =( select concat(DATE_FORMAT(curdate(), '%b %d %Y'),' ', '(',@UpdatedByName,')',': ', ifnull((@ImpactDescription), '') ));
Else
SET @OldImpactDescription = ( select concat(DATE_FORMAT(curdate(), '%b %d %Y'),' ', '(',@UpdatedByName,')',': ', ifnull((@ImpactDescription), '') ,' <br><br> ', ifnull((OldImpactDescription), '')) from hist_spill_release where SpillReleaseId =  $OldSpillReleaseId limit 1);
END IF;
SET @EstimatedCost = (  select estimatedcost from spill_release where SpillReleaseId = $SpillReleaseId );
SET @VersionNumber = (SELECT MAX(VersionNumber) FROM hist_incident WHERE IncidentId = @IncidentId);
SET @HistIncidentId = (SELECT HistIncidentId FROM hist_incident WHERE IncidentId = @IncidentId AND VersionNumber = @VersionNumber);
SET @HistoryOperationId = (SELECT HistoryOperationId FROM hist_incident WHERE HistIncidentId = @HistIncidentId);
SET @UpdatedDate = CURRENT_TIMESTAMP();
INSERT INTO `hist_spill_release`
(
`HistSpillReleaseId`,
`SpillReleaseId`,
`IncidentId`,
`SourceName`,
`DurationValue`,
`DurationUnit`,
`QuantityValue`,
`QuantityUnit`,
`QuantityRecoveredValue`,
`QuantityRecoveredUnit`,
`WhatWasIt`,
`OldWhatWasIt`,
`HowDidSROccur`,
`OldHowDidSROccur`,
`IsReportable`,
`ImpactTypeName`,
`ImpactSubTypeName`,
`ExtAgencyName`,
`IntEmployeeName1`,
`IntEmployeeDept1`,
`IntEmployeeName2`,
`IntEmployeeDept2`,
`IntEmployeeName3`,
`IntEmployeeDept3`,
`PrimRespondName`,
`ImpactDescription`,
`OldImpactDescription`,
`EstimatedCost`,
`HistoryOperationId`,
`UpdatedById`,
`UpdatedDate`,
`HistIncidentId`,
`OriginalSpillReleaseId`
)
VALUES
(
MyUUID(),
$SpillReleaseId,
@IncidentId,
@SourceName,
@DurationValue,
@DurationUnit,
@QuantityValue,
@QuantityUnit,
@QuantityRecoveredValue,
@QuantityRecoveredUnit,
@WhatWasIt,
@OldWhatWasIt,
@HowDidSROccur,
@OldHowDidSROccur,
@IsReportable,
@ImpactTypeName,
@ImpactSubTypeName,
@ExtAgencyName,
@IntEmployeeName1,
@IntEmployeeDept1,
@IntEmployeeName2,
@IntEmployeeDept2,
@IntEmployeeName3,
@IntEmployeeDept3,
@PrimRespondName,
@ImpactDescription,
@OldImpactDescription,
@EstimatedCost,
@HistoryOperationId,
$UpdatedById,
@UpdatedDate,
@HistIncidentId,
$OriginalSpillReleaseId
);
END;
