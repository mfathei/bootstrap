CREATE FUNCTION ABCanTrackV2.new_function(`$ids` TEXT)
  RETURNS TEXT
  BEGIN
/*
cs4sql-039b0850-e55a-11e4-b146-5254000a52fa,cs4sql-03a22f67-e55a-11e4-b146-5254000a52fa,cs4sql-03a61447-e55a-11e4-b146-5254000a52fa,cs4sql-03a9fbfb-e55a-11e4-b146-5254000a52fa,cs4sql-03ae4add-e55a-11e4-b146-5254000a52fa
*/
DECLARE $qry TEXT;
DECLARE $Label VARCHAR(255);
SET $ids = 'cs4sql-039b0850-e55a-11e4-b146-5254000a52fa,cs4sql-03a22f67-e55a-11e4-b146-5254000a52fa,cs4sql-03a61447-e55a-11e4-b146-5254000a52fa,cs4sql-03a9fbfb-e55a-11e4-b146-5254000a52fa,cs4sql-03ae4add-e55a-11e4-b146-5254000a52fa';
    SET $qry = ' ';
SET @Postition = LOCATE(',', $ids);
WHILE ( @Postition > 0 ) DO
	SET @STR = SUBSTRING($ids, 1, @Postition-1);
	SET $ids  = SUBSTRING($ids, @Postition + 1);
	set  @STR = TRIM(@STR);
    SET $Label = (SELECT DefaultFieldLabel FROM ABCanTrackV2.field where FieldId = @STR);
	SET $qry = CONCAT($qry , ', 
    (select group_concat(tbl3.OptionName separator ', ') from t tbl1
inner join `option` tbl3
on tbl1.OptionId = tbl3.OptionId
where tbl1.incidentid = inc.incidentid and tbl1.FieldId = '@STR') as '$Label')');	
	
	SET @Postition = LOCATE(',', $ids);
END WHILE;
RETURN $qry;
END;
