CREATE PROCEDURE ABCanTrackV2.GetIncidentReport(IN `$IncidentId` VARCHAR(100))
  BEGIN
SELECT   
	incident.IncidentId, incident.IncidentNumber, 
	date_format(incident.IncidentDate,'%m/%d/%Y') as IncidentDate,
	incident.IncidentHour,
	incident.IncidentMinute,
	OrgName, incident.OrgId ,
	EventTypeName , 
	OperationTypeName ,
	Location1Name ,
	Location2Name, 
	Location3Name ,
	Location4Name, 
	incident.OtherLocation,
	InvStatusName , 
	RiskOfRecurrenceName , 
	IncidentSeverityName ,  
	CASE IsEmerRP   WHEN '0' THEN 'No'        WHEN '1' THEN 'Yes' END AS IsEmerRP,
	incident.RepName,
	incident.RepEmail,
	incident.RepPosition,
	incident.RepCompany,
	incident.RepPrimaryPhone,
	incident.RepAlternatePhone,	
	incident.EventSequence,
	incident.EnvConditionNote,
	incident.IncDescription,
	incident.EnergyFormNote,
	incident.SubStandardActionNote,
	incident.SubStandardConditionNote,
	incident.UnderLyingCauseNote,
	date_format(incident.InvestigationDate,'%m/%d/%Y')as InvestigationDate,
	incident.InvestigatorName1,
	incident.InvestigatorName2,
	incident.InvestigatorName3,
	incident.InvSummary,
	incident.FollowUpNote,
	incident.ResponseCost,
	incident.RepairCost,
	incident.InsuranceCost,
	incident.WCBCost,
	incident.OtherCost,
	incident.TotalCost,
	incident.SourceDetails,
	incident.RootCauseNote,
	incident.SignOffInvestigatorName,
	date_format(incident.SignOffDate,'%m/%d/%Y')as  SignOffDate,	
	CustomerId as CustomerName, CustomerJobNumber, CustName, ContractorId as ContractorName, ContractorJobNumber, ContName  
 
from incident
left outer join event_type on incident.EventTypeId = event_type.EventTypeId      
left outer join operation_type on incident.OperationTypeId = operation_type.OperationTypeId      
left outer join location1 on incident.Location1Id = location1.Location1Id      
left outer join location2 on incident.Location2Id = location2.Location2Id  
left outer join location3 on incident.Location3Id = location3.Location3Id  
left outer join location4 on incident.Location4Id = location4.Location4Id      
left outer join inv_status on incident.InvStatusId = inv_status.InvStatusId      
left outer join risk_of_recurrence on incident.RiskOfRecurrenceId = risk_of_recurrence.RiskOfRecurrenceId      
left outer join incident_severity on incident.IncidentSeverityId = incident_severity.IncidentSeverityId   
left outer join incident_third_party on incident_third_party.IncidentId = incident.IncidentId      
inner join organization on organization.OrgId = incident.OrgId 
where incident.incidentId = $IncidentId;
END;
