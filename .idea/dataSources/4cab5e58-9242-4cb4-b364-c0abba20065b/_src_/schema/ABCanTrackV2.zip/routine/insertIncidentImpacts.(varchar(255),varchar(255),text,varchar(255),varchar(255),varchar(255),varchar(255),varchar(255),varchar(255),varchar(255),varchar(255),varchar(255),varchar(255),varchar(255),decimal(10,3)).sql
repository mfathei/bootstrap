CREATE PROCEDURE ABCanTrackV2.insertIncidentImpacts(IN `$IncidentId`       VARCHAR(255),
                                                    IN `$ImpactSubTypeId`  VARCHAR(255), IN `$Description` TEXT,
                                                    IN `$IntEmployeeId1`   VARCHAR(255),
                                                    IN `$IntEmployeeName1` VARCHAR(255),
                                                    IN `$IntEmployeeDept1` VARCHAR(255),
                                                    IN `$IntEmployeeId2`   VARCHAR(255),
                                                    IN `$IntEmployeeName2` VARCHAR(255),
                                                    IN `$IntEmployeeDept2` VARCHAR(255),
                                                    IN `$IntEmployeeId3`   VARCHAR(255),
                                                    IN `$IntEmployeeName3` VARCHAR(255),
                                                    IN `$IntEmployeeDept3` VARCHAR(255),
                                                    IN `$PrimRespondName`  VARCHAR(255),
                                                    IN `$PrimRespondId`    VARCHAR(255),
                                                    IN `$EstimatedCost`    DECIMAL(10, 3))
    my_proc :
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        select 
            0 ;
        ROLLBACK ;
    END ;
    DECLARE EXIT HANDLER FOR SQLWARNING 
    BEGIN
        select 
            0 ;
        ROLLBACK ;
    END ;
    set $IntEmployeeId1 = 
    (select 
        EmployeeId 
    from
        employee 
    where EmployeeId = $IntEmployeeId1) ;
    set $IntEmployeeId2 = 
    (select 
        EmployeeId 
    from
        employee 
    where EmployeeId = $IntEmployeeId2) ;
    set $IntEmployeeId3 = 
    (select 
        EmployeeId 
    from
        employee 
    where EmployeeId = $IntEmployeeId3) ;
    set $PrimRespondId = 
    (select 
        EmployeeId 
    from
        employee 
    where EmployeeId = $PrimRespondId) ;
    INSERT INTO impact (
        IncidentId,
        ImpactSubTypeId,
        Description,
        IntEmployeeId1,
        IntEmployeeName1,
        IntEmployeeDept1,
        IntEmployeeId2,
        IntEmployeeName2,
        IntEmployeeDept2,
        IntEmployeeId3,
        IntEmployeeName3,
        IntEmployeeDept3,
        PrimRespondName,
        PrimRespondId,
        EstimatedCost
    ) 
    VALUES
        (
            $IncidentId,
            $ImpactSubTypeId,
            $Description,
            $IntEmployeeId1,
            $IntEmployeeName1,
            $IntEmployeeDept1,
            $IntEmployeeId2,
            $IntEmployeeName2,
            $IntEmployeeDept2,
            $IntEmployeeId3,
            $IntEmployeeName3,
            $IntEmployeeDept3,
            $PrimRespondName,
            $PrimRespondId,
            $EstimatedCost
        ) ;
    select 
        1 ;
END;
