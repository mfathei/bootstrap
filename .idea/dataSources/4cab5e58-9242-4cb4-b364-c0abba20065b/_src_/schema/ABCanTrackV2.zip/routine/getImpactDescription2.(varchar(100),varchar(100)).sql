CREATE FUNCTION ABCanTrackV2.getImpactDescription2(`$ImpactId` VARCHAR(100), `$OriginalImpactId` VARCHAR(100))
  RETURNS TEXT
  BEGIN
if $OriginalImpactId is null   or $OriginalImpactId  =''   then
	set $OriginalImpactId = $ImpactId ;
end if;
set session group_concat_max_len = 10000;
select (group_concat(DATE_FORMAT(UpdatedDate, '%b %d %Y') ,' ', '(',  concat(firstname ,' ', lastname) ,')',': <pr>', ImpactDescription separator '<br><br>' ) ) as ImpactDescription   
 into @newImpactDescription2 
 from(
 select UpdatedDate, ImpactDescription, firstname,lastname FROM hist_impact hi 
join employee e on e.EmployeeId = hi.UpdatedbyId
 where OriginalImpactId = $OriginalImpactId  
order by UpdatedDate asc  ) temp ; 
return @newImpactDescription2;
END;
