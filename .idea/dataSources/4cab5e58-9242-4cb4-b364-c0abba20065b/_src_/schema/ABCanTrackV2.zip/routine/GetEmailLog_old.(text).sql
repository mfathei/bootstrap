CREATE PROCEDURE ABCanTrackV2.GetEmailLog_old(IN xmlData TEXT)
  BEGIN
SET @Orgid = extractvalue(xmlData, '//OrgId');
SET @OriginalCorrectiveActionId = extractvalue(xmlData, '//OriginalCorrectiveActionId');
SET @page = extractvalue(xmlData, '//page');
SET @limit = extractvalue(xmlData, '//limit');
SET @sortOrder =  extractvalue(xmlData, '//sortOrder');
SET @index =  extractvalue(xmlData, '//index');
SET @Export =  extractvalue(xmlData, '//Export');
set @selectquery =" SELECT  EmailLogId, IncidentNumber, IncidentDate, Location1Name,Location2Name,Location3Name,Location4Name ,`From`,`To`,`Subject`,SentDate,
CASE IsSent WHEN '0' THEN 'No' WHEN '1' THEN 'Yes' END AS IsSent,
CASE IsManual WHEN '0' THEN 'No' WHEN '1' THEN 'Yes' END AS IsManual   ";
set @queryFrom = " FROM EmailLogData  ";
SET @queryWhere = ' where 1 = 1 ';
IF (@OrgId != '' AND @OrgId !='0') THEN
	SET @queryWhere = CONCAT(@queryWhere,' and OrgId = "', @OrgId,'"');
    SET @queryWhere = CONCAT(@queryWhere,' and ( IsDeleted = 0 or IsDeleted is null ) ');
END IF;



IF (@OriginalCorrectiveActionId != 'null' AND @OriginalCorrectiveActionId !='0') THEN
	SET @queryWhere = CONCAT(@queryWhere,' and OriginalCorrectiveActionId = "', @OriginalCorrectiveActionId,'"');
END IF;
SET @myArrayOfValue = 'From,To,Subject,Location1Name,Location2Name,Location3Name,Location4Name,IncidentNumber, ';
                    
SET @Postition = LOCATE(',', @myArrayOfValue);
WHILE ( @Postition > 0 ) DO
 SET @STR = SUBSTRING(@myArrayOfValue, 1, @Postition-1);
 SET @myArrayOfValue = SUBSTRING(@myArrayOfValue, @Postition + 1);
 SET @Col =  extractvalue(xmlData, CONCAT('//',@STR));
 IF (@Col != '' AND @Col !='NULL') THEN
 
 
if(@STR ='From') then
set @STR = '`From`';
end if;
if(@STR ='To') then
set @STR = '`To`';
end if;
  
  
    SET @queryWhere = CONCAT(@queryWhere,CONCAT(' AND   ',@STR,'  like '"'%", @Col ,"%'")); 
 END IF;
 
 SET @Postition = LOCATE(',', @myArrayOfValue);
END WHILE;
SET @IsSent =  extractvalue(xmlData, '//IsSent');
IF (@IsSent != '' AND @IsSent !='NULL') THEN
	IF( @IsSent  != '2' ) THEN 
		SET @queryWhere = CONCAT(@queryWhere,'  AND IsSent = ',  @IsSent ); 
	END IF;	
END IF;
SET @IsManual =  extractvalue(xmlData, '//IsManual');
IF (@IsManual != '' AND @IsManual !='NULL') THEN
	IF( @IsManual  != '2' ) THEN 
		SET @queryWhere = CONCAT(@queryWhere,'  AND  IsManual = ',  @IsManual ); 
	END IF;	
END IF;
SET @IncidentDateFrom =  extractvalue(xmlData, '//IncidentDateFrom');
SET @IncidentDateTo =  extractvalue(xmlData, '//IncidentDateTo');
IF(@IncidentDateTo ="" AND @IncidentDateFrom !="" ) THEN
	SET @IncidentDateFrom  = STR_TO_DATE(@IncidentDateFrom , '%m/%d/%Y');
	SET @IncidentDateFrom2 = DATE_ADD(@IncidentDateFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND IncidentDate >=  ',  "'", @IncidentDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND IncidentDate <  ', "'", @IncidentDateFrom2  ,"'");
ELSE IF(@IncidentDateTo !="") then
		SET @IncidentDateFrom  = STR_TO_DATE(@IncidentDateFrom , '%m/%d/%Y');
		SET @IncidentDateTo  = STR_TO_DATE(@IncidentDateTo , '%m/%d/%Y');
		SET @IncidentDateTo2 = DATE_ADD(@IncidentDateTo ,INTERVAL 1 DAY) ;
		SET @queryWhere = CONCAT(@queryWhere,'  AND IncidentDate >  ', "'" , @IncidentDateFrom ,"'" );	
		SET @queryWhere = CONCAT(@queryWhere,'  AND IncidentDate <=  ', "'",  @IncidentDateTo2  ,"'" );	
	
	END IF;
END IF;
SET @SentDateFrom =  extractvalue(xmlData, '//SentDateFrom');
SET @SentDateTo =  extractvalue(xmlData, '//SentDateTo');
IF(@SentDateTo ="" AND @SentDateFrom !="" ) THEN
	SET @SentDateFrom  = STR_TO_DATE(@SentDateFrom , '%m/%d/%Y');
	SET @SentDateFrom2 = DATE_ADD(@SentDateFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND SentDate >=  ',  "'", @SentDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND SentDate <  ', "'", @SentDateFrom2  ,"'");
ELSE IF(@SentDateTo !="") then
		SET @SentDateFrom  = STR_TO_DATE(@SentDateFrom , '%m/%d/%Y');
		SET @SentDateTo  = STR_TO_DATE(@SentDateTo , '%m/%d/%Y');
		SET @SentDateTo2 = DATE_ADD(@SentDateTo ,INTERVAL 1 DAY) ;
		SET @queryWhere = CONCAT(@queryWhere,'  AND SentDate >  ', "'" , @SentDateFrom ,"'" );	
		SET @queryWhere = CONCAT(@queryWhere,'  AND SentDate <=  ', "'",  @SentDateTo2  ,"'" );	
	
	END IF;
END IF;
SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );
-- select  @query;
SET @querycount =  CONCAT( 'SELECT count(*) into @cnt from  (', @query, ' ) t');
PREPARE stmt1 FROM @querycount;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
--
 SET @selectquery = CONCAT (@selectquery,', ', @cnt, ' as Count ');
SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );
 if(@index ='EmailLogId') then
 set @index = 'hst.EmailLogId';
 end if;

 if(@index ='Order') then
  set @index = 'SentDate';
 end if;

 
SET @query = CONCAT(@query, ' order by `', @index,'`  ', @sortOrder);
if( @Export ="false") then
SET @page = (@page - 1) * @limit;
SET @query = CONCAT(@query, ' LIMIT ', @limit ,' OFFSET ',  @page);
end if;
-- select  @query;
PREPARE stmt1 FROM @query;
EXECUTE stmt1;
-- select @query; 
END;
