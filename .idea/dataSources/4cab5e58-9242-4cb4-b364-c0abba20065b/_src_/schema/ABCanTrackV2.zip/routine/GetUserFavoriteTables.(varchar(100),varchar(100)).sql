CREATE PROCEDURE ABCanTrackV2.GetUserFavoriteTables(IN `$OrgId` VARCHAR(100), IN `$EmployeeId` VARCHAR(100))
  BEGIN
declare  $GroupId VARCHAR(100);
set  $GroupId = (select g.GroupId from `group` g
inner join emp_group eg
on g.GroupId = eg.GroupId and g.OrgId=$OrgId  and EmployeeId = $EmployeeId);
-- select  $GroupId;
SELECT DISTINCT
    FavoriteTableId,
    FavoriteTableName,
    FavoriteTypeId,
    FavoriteTypeName,
    IsShared,
    FullName,
    EmployeeId
FROM
    (SELECT 
        FavoriteTableId,
            FavoriteTableName,
            favorite_table.FavoriteTypeId,
            FavoriteTypeName,
            CASE IsShared
                WHEN '0' THEN '0'
                WHEN '1' THEN '1'
            END AS IsShared,
            CONCAT(e.FirstName, ' ', e.LastName) AS FullName,
            favorite_table.EmployeeId
    FROM
        favorite_table
    INNER JOIN favorite_type ON favorite_type.FavoriteTypeId = favorite_table.FavoriteTypeId
    INNER JOIN employee e ON favorite_table.EmployeeId = e.EmployeeId
    WHERE
        OrgId = $OrgId
            AND favorite_table.EmployeeId = $EmployeeId UNION ALL SELECT 
        FavoriteTableId,
            FavoriteTableName,
            favorite_table.FavoriteTypeId,
            FavoriteTypeName,
            CASE IsShared
                WHEN '0' THEN '0'
                WHEN '1' THEN '1'
            END AS IsShared,
            CONCAT(e.FirstName, ' ', e.LastName) AS FullName,
            favorite_table.EmployeeId
    FROM
        favorite_table
    INNER JOIN favorite_type ON favorite_type.FavoriteTypeId = favorite_table.FavoriteTypeId
    INNER JOIN `group` tbl3 ON `tbl3`.OrgId = favorite_table.OrgId
    INNER JOIN emp_group tbl4 ON favorite_table.EmployeeId = tbl4.EmployeeId
    INNER JOIN employee e ON favorite_table.EmployeeId = e.EmployeeId
        AND tbl3.GroupId = tbl4.GroupId
    WHERE
        favorite_table.OrgId = $OrgId
            AND favorite_table.EmployeeId <> $EmployeeId
            AND IsShared = 1
            AND tbl4.GroupId = $GroupId) temp
ORDER BY FavoriteTableName ASC;
END;
