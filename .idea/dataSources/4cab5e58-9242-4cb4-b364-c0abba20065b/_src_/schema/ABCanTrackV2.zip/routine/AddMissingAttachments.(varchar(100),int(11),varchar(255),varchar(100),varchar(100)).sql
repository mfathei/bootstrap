CREATE PROCEDURE ABCanTrackV2.AddMissingAttachments(IN `$histIncidentId` VARCHAR(100), IN `$VersionNumber` INT,
                                                    IN `$filename`       VARCHAR(255), IN `$extension` VARCHAR(100),
                                                    IN `$file_size`      VARCHAR(100))
    my_proc : BEGIN
declare result int default 0;
set @count = (select COUNT(*)
from attachment where IncidentId = $histIncidentId and VersionNumber = $VersionNumber and AttachmentName = $filename);
if @count > 0 then
select result ;
	leave my_proc;
end if;
            
		INSERT INTO `attachment`
		(`IncidentId`, `VersionNumber`, `AttachmentName`, `AttachmentType`, `AttachmentSize`)
		VALUES
		($histIncidentId ,$VersionNumber ,$filename, $extension , $file_size);
		SET result = 1;
	   
select result;
END my_proc;
