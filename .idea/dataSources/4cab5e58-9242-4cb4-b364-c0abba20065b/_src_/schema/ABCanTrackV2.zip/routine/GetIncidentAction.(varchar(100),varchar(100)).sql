CREATE PROCEDURE ABCanTrackV2.GetIncidentAction(IN `$IncidentId` VARCHAR(100), IN `$HistIncidentId` VARCHAR(100))
  BEGIN
IF NOT EXISTS (SELECT * FROM hist_corrective_action WHERE HistIncidentId = $HistIncidentId)
THEN
	SET $HistIncidentId = (SELECT tbl1.HistIncidentId FROM hist_incident tbl1 
    INNER JOIN hist_corrective_action tbl2 ON tbl1.HistIncidentId = tbl2.HistIncidentId 
    WHERE tbl1.IncidentId = $IncidentId ORDER BY tbl1.VersionNumber DESC LIMIT 1);
END IF;
	SELECT corrective_action.CorrectiveActionId, OriginalCorrectiveActionId, corrective_action.IncidentId,   concat(empAssigned.FirstName, ' - ', empAssigned.LastName) as AssignedName ,   AssignedById,  (select             group_concat(concat(empNotified.FirstName, ' - ', empNotified.LastName) separator ' ; ')      
		from corrective_action_notified            
		left outer join  employee as empNotified ON empNotified.EmployeeId = corrective_action_notified.EmployeeId     
		where  corrective_action_notified.CorrectiveActionId = corrective_action.CorrectiveActionId) as NotifiedName ,
		corrective_action.CorrActStatusId,corr_act_status.CorrActStatusName,priority.PriorityName,   
		corrective_action.PriorityId,    AssignedToId,   DATE_FORMAT(corrective_action.StartDate, '%m/%d/%Y')  as  StartDate,   
		DATE_FORMAT(corrective_action.TargetEndDate, '%m/%d/%Y')  as  TargetEndDate,   DATE_FORMAT(corrective_action.ActualEndDate, '%m/%d/%Y')  as  ActualEndDate,    
		corrective_action.EstimatedCost,    corrective_action.TaskDescription,    corrective_action.OutComeFollowUp,
        
        CASE corrective_action.DesiredResults       
        WHEN '0' THEN  REPLACEYESNO(`ABCanTrackV2`.`corr_act_status`.`OrgId`, 'no')
        WHEN '1' THEN  REPLACEYESNO(`ABCanTrackV2`.`corr_act_status`.`OrgId`, 'yes') 
        END AS IsDesired, 
        
		CASE corrective_action.DesiredResults    WHEN '0' THEN '0'        WHEN '1' THEN '1'    END AS DesiredResults,    corrective_action.Comments 
	from     corrective_action        
		left outer join    corr_act_status ON corr_act_status.CorrActStatusId = corrective_action.CorrActStatusId        
		left outer join    priority ON priority.PriorityId = corrective_action.PriorityId        
		left outer join    employee as empAssigned ON empAssigned.EmployeeId = corrective_action.AssignedToId
		left outer join    hist_corrective_action on hist_corrective_action.CorrectiveActionId = corrective_action.CorrectiveActionId
	where corrective_action.IncidentId = $IncidentId  and HistIncidentId = $HistIncidentId;
END;
