CREATE FUNCTION ABCanTrackV2.MyUUID()
  RETURNS VARCHAR(100)
  if @@hostname like '%[.]%'
then
return concat(LEFT(@@hostname,LOCATE('.',@@hostname) - 1),'-',uuid());
else
return concat(@@hostname,'-',uuid());
end if;
