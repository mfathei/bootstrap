CREATE PROCEDURE ABCanTrackV2.GetOrgCharts(IN xmlData TEXT)
  BEGIN
SET @Orgid = extractvalue(xmlData, '//OrgId');
SET @page = extractvalue(xmlData, '//page');
SET @limit = extractvalue(xmlData, '//limit');
SET @sortOrder =  extractvalue(xmlData, '//sortOrder');
SET @index =  extractvalue(xmlData, '//index');
SET @Export =  extractvalue(xmlData, '//Export');
set @selectquery ='SELECT  SQL_CALC_FOUND_ROWS
     StatTableId,FieldId1, FieldId2, StatTableName, date_format(CreationDate,'%m/%d/%Y') AS  CreationDate, date_format(UpdatedDate,'%m/%d/%Y') AS  LastUpdatedDate, field1.FieldName as FieldName, org_field1.FieldLabel as  FieldLabel,
     field2.FieldName as FieldName2, field3.FieldName as FieldName3, org_field1.FieldLabel as Field2lable, OutputTypeName as ReportType
, OperationName, OutPutCode, OperationCode, TimeFrame ,HiddenParams     ';
                
 
set @queryFrom = ' FROM stat_table
     inner join field as field1 on field1.FieldId = stat_table.FieldId1
     left outer join field as field2 on field2.FieldId = stat_table.FieldId2
     left outer join field as field3 on field3.FieldId = stat_table.FieldId3   ';
                    
set @queryFrom =CONCAT(@queryFrom,' inner join org_field as org_field1 on org_field1.FieldId = field1.FieldId and org_field1.OrgId = "', @Orgid,'"');
set @queryFrom =CONCAT(@queryFrom,' left outer join org_field as org_field2 on org_field2.FieldId = field2.FieldId and org_field2.OrgId = "', @Orgid,'"');
set @queryFrom =CONCAT(@queryFrom,'  
  inner join operation on operation.OperationId = stat_table.OperationId
  inner join output_type on output_type.OutputTypeId = stat_table.OutputTypeId ');
SET @queryWhere = ' where 1= 1 ';
SET @queryWhere = CONCAT(@queryWhere,' and stat_table.OrgId  = "', @Orgid,'"');
SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );
SET @query = CONCAT(@query, ' order by ', @index,'  ', @sortOrder);
if( @Export ="false") then
SET @page = (@page - 1) * @limit;
SET @query = CONCAT(@query, ' LIMIT ', @limit ,' OFFSET ',  @page);
end if;
-- select  @query;
PREPARE stmt1 FROM @query;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
SELECT FOUND_ROWS();
END;
