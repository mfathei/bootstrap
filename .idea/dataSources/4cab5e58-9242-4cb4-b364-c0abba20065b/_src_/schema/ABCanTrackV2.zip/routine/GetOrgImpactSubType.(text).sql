CREATE PROCEDURE ABCanTrackV2.GetOrgImpactSubType(IN xmlData TEXT)
  BEGIN
SET @page = extractvalue(xmlData, '//page');
SET @limit = extractvalue(xmlData, '//limit');
SET @sortOrder =  extractvalue(xmlData, '//sortOrder');
SET @index =  extractvalue(xmlData, '//index');
SET @Mine =  extractvalue(xmlData, '//Mine');
SET @CreatorId = extractvalue(xmlData, '//CreatorId');
SET @Export =  extractvalue(xmlData, '//Export');
SET @OrgId =  extractvalue(xmlData, '//OrgId');
SET @checkOrg =  extractvalue(xmlData, '//check');
set @selectquery ="SELECT OrgName,impact_type.OrgId, ImpactTypeName, impact_sub_type.ImpactTypeId, ImpactSubTypeId ,  ImpactSubTypeName, impact_sub_type.`Order`";
                
set @queryFrom = " from  impact_sub_type
inner join impact_type on impact_type.ImpactTypeId = impact_sub_type.ImpactTypeId inner join organization on impact_type.OrgId = organization.OrgId";
SET @queryWhere = ' where 1= 1 ';
SET @queryWhere = CONCAT(@queryWhere,' and impact_sub_type.Hide = 0 ');
SET @queryWhere = CONCAT(@queryWhere,' and impact_type.Hide = 0 ');
if(@checkOrg  = 'false') then 
SET @queryWhere = CONCAT(@queryWhere,' and impact_type.OrgId =   "', @Orgid,'" ');
end if;
SET @myArrayOfValue = 'ImpactSubTypeId,ImpactSubTypeName,Order,ImpactTypeName,';
SET @Postition = LOCATE(',', @myArrayOfValue);
WHILE ( @Postition > 0 ) DO
 SET @STR = SUBSTRING(@myArrayOfValue, 1, @Postition-1);
 SET @myArrayOfValue = SUBSTRING(@myArrayOfValue, @Postition + 1);
 SET @Col =  extractvalue(xmlData, CONCAT('//',@STR));
 IF (@Col != '' AND @Col !='NULL') THEN
  SET @queryWhere = CONCAT(@queryWhere,CONCAT(' AND    ',@STR,' like '"'%", @Col ,"%'")); 
 END IF;
 
 SET @Postition = LOCATE(',', @myArrayOfValue);
END WHILE;
SET @querycount = CONCAT( 'SELECT count(*) into @cnt ', @queryFrom, @queryWhere );
PREPARE stmt1 FROM @querycount;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
	
SET @selectquery = CONCAT (@selectquery,', ', @cnt, ' as Count ');
SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );
if( @index = 'Order') then set  @index = '`Order`';  end if;
if( @index = 'ImpactTypeName,Order') then set  @index = 'ImpactTypeName,impact_sub_type.`Order` ';  end if;
SET @query = CONCAT(@query, ' order by ', @index,'  ', @sortOrder);
if( @Export ="false") then
SET @page = (@page - 1) * @limit;
SET @query = CONCAT(@query, ' LIMIT ', @limit ,' OFFSET ',  @page);
end if;
 -- select  @query;
PREPARE stmt1 FROM @query;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
END;
