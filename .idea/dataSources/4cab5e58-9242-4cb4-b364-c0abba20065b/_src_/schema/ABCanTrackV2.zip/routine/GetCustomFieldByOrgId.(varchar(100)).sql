CREATE PROCEDURE ABCanTrackV2.GetCustomFieldByOrgId(IN `$OrgId` VARCHAR(100))
  BEGIN
SELECT FieldId, FieldName,  trim(DefaultFieldLabel) as DefaultFieldLabel, SubTabName 
FROM field
JOIN sub_tab ON sub_tab.SubTabId = field.SubTabId
WHERE OrgId = $OrgId
ORDER BY sub_tab.`Order`, field.`Order` ;
END;
