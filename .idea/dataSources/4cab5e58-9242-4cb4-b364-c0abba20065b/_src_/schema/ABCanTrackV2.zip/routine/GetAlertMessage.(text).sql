CREATE PROCEDURE ABCanTrackV2.GetAlertMessage(IN xmlData TEXT)
  BEGIN
SET @Orgid = extractvalue(xmlData, '//OrgId');
SET @page = extractvalue(xmlData, '//page');
SET @limit = extractvalue(xmlData, '//limit');
SET @sortOrder =  extractvalue(xmlData, '//sortOrder');
SET @index =  extractvalue(xmlData, '//index');
SET @Export =  extractvalue(xmlData, '//Export');
set @selectquery ="SELECT AlertMessageId, AlertName, AlertDescription, AlertMessageDescription, AlertMessageCode    ";
set @queryFrom = " FROM  alert_message  ";
SET @queryWhere = 'where 1 = 1 ';
 
SET @myArrayOfValue = 'AlertName,AlertDescription,AlertMessageDescription,';
                    
SET @Postition = LOCATE(',', @myArrayOfValue);
WHILE ( @Postition > 0 ) DO
 SET @STR = SUBSTRING(@myArrayOfValue, 1, @Postition-1);
 SET @myArrayOfValue = SUBSTRING(@myArrayOfValue, @Postition + 1);
 SET @Col =  extractvalue(xmlData, CONCAT('//',@STR));
  IF (@Col != '' AND @Col !='NULL') THEN
	 
 if(@STR ='AlertMessageDescription') then
 set @STR = 'AlertMessageDescription';
 end if;
 
 
  SET @queryWhere = CONCAT(@queryWhere,CONCAT(' AND    ',@STR,'  like '"'%", @Col ,"%'")); 
 END IF;
 
 SET @Postition = LOCATE(',', @myArrayOfValue);
END WHILE;
 
SET @query = CONCAT( @selectquery, @queryFrom , @queryWhere);
SET @querycount =  CONCAT( 'SELECT count(*) into @cnt from  (', @query, ' ) t');
PREPARE stmt1 FROM @querycount;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
 SET @selectquery = CONCAT (@selectquery,', ', @cnt, ' as Count ');
SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );
SET @query = CONCAT(@query, ' order by ', @index,'  ', @sortOrder);
if( @Export ="false") then
SET @page = (@page - 1) * @limit;
SET @query = CONCAT(@query, ' LIMIT ', @limit ,' OFFSET ',  @page);
end if;
PREPARE stmt1 FROM @query;
EXECUTE stmt1;
-- select @query; 
END;
