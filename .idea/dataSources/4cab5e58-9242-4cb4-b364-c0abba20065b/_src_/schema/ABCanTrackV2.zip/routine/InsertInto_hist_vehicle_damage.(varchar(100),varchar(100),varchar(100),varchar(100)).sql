CREATE PROCEDURE ABCanTrackV2.InsertInto_hist_vehicle_damage(IN `$VehicleDamageId`         VARCHAR(100),
                                                             IN `$OldVehicleDamageId`      VARCHAR(100),
                                                             IN `$OriginalVehicleDamageId` VARCHAR(100),
                                                             IN `$UpdatedById`             VARCHAR(100))
  BEGIN
/*
DECLARE @IncidentId  varchar(100) ;
DECLARE @DriverName  varchar(255) ;
DECLARE @DriverLicence  varchar(255) ;
DECLARE @VehicleTypeName  varchar(255) ;
DECLARE @VehicleLicence  varchar(255) ;DECLARE @HowDidThatDone  TEXT ;
DECLARE @OldHowDidThatDone TEXT ;
DECLARE @DamageDescription  TEXT ;
DECLARE @OldDamageDescription TEXT ;
DECLARE @ImpactTypeName varchar(255);
DECLARE @ImpactSubTypeName  varchar(255) ;
DECLARE @ExtAgencyName  TEXT ;
DECLARE @IntEmployeeName1  varchar(255) ;
DECLARE @IntEmployeeDept1  varchar(255) ;
DECLARE @IntEmployeeName2  varchar(255) ;
DECLARE @IntEmployeeDept2  varchar(255) ;
DECLARE @IntEmployeeName3  varchar(255) ;
DECLARE @IntEmployeeDept3  varchar(255) ;
DECLARE @CustomOpenTxt  TEXT ;
DECLARE @OldCustomOpenTxt TEXT ;
DECLARE @PrimRespondName  varchar(255) ;
DECLARE @ImpactDescription TEXT;
DECLARE @OldImpactDescription TEXT ;
DECLARE @EstimatedCost  DECIMAL(10,2) ;
DECLARE @HistoryOperationId  varchar(100) ;
DECLARE @UpdatedDate  DATETIME;
DECLARE @UpdatedByName varchar(255);
DECLARE @HistIncidentId varchar(100);
DECLARE @VersionNumber INT;
*/
SET  @UpdatedByName = (  select concat(firstname ,' ', lastname) from employee where employeeid = $UpdatedById ) ;
SET @IncidentId = ( select incidentid from  vehicle_damage where VehicleDamageId = $VehicleDamageId );
SET @DriverName = ( select DriverName from  vehicle_damage where VehicleDamageId = $VehicleDamageId  );
SET @DriverLicence = ( select DriverLicence from  vehicle_damage where VehicleDamageId = $VehicleDamageId  );
SET @VehicleTypeName = ( select VehicleTypeName from  vehicle_type where VehicleTypeId = ( select VehicleTypeId from vehicle_damage where VehicleDamageId =  $VehicleDamageId)  );
SET @VehicleLicence = ( select VehicleLicence from  vehicle_damage where VehicleDamageId = $VehicleDamageId  );
SET @HowDidThatDone = ( select HowDidThatDone from  vehicle_damage where VehicleDamageId = $VehicleDamageId  );
IF($OldVehicleDamageId is null      or $OldVehicleDamageId = '') then
SET $OriginalVehicleDamageId = $VehicleDamageId ;
SET  @OldHowDidThatDone =( select concat(DATE_FORMAT(curdate(), '%b %d %Y'),' ', '(',@UpdatedByName,')',': ', ifnull((@HowDidThatDone), '') ));
ELSE
SET @OldHowDidThatDone =  ( select concat(DATE_FORMAT(curdate(), '%b %d %Y'),' ', '(',@UpdatedByName,')',': ', ifnull((@HowDidThatDone), '') ,' <br><br> ', ifnull((OldHowDidThatDone), '')) from hist_vehicle_damage where VehicleDamageId = $OldVehicleDamageId limit 1);
END IF;
SET @DamageDescription = ( select DamageDescription from  vehicle_damage where VehicleDamageId = $VehicleDamageId  );
IF($OldVehicleDamageId is null) then
SET  @OldDamageDescription =( select concat(DATE_FORMAT(curdate(), '%b %d %Y'),' ', '(',@UpdatedByName,')',': ', ifnull((@DamageDescription), '') ));
ELSE
SET @OldDamageDescription =  ( select concat(DATE_FORMAT(curdate(), '%b %d %Y'),' ', '(',@UpdatedByName,')',': ', ifnull((@DamageDescription), '') ,' <br><br> ', ifnull((OldDamageDescription), ''))  from hist_vehicle_damage where VehicleDamageId = $OldVehicleDamageId limit 1);
END IF;
SET @ImpactTypeName = (select ImpactTypeName from impact_type where impacttypeid = (select impacttypeid from impact_sub_type where impactsubTypeid = (select impactsubtypeid from  vehicle_damage where VehicleDamageId = $VehicleDamageId)));
SET @ImpactSubTypeName = (  select impactsubtypename from impact_sub_type where impactsubtypeid = (select ImpactSubTypeid from  vehicle_damage where VehicleDamageId = $VehicleDamageId) );
SET @ExtAgencyName = ( select group_concat(ExtAgencyName separator' ;| ') from external_agency where ExtAgencyId in (select ExtAgencyId from impacts_ext_agency where VehicleDamageId = $VehicleDamageId));
SET @IntEmployeeName1 = (  select IntEmployeeName1 from  vehicle_damage where VehicleDamageId = $VehicleDamageId );
SET @IntEmployeeDept1 = (  select IntEmployeeDept1 from  vehicle_damage where VehicleDamageId = $VehicleDamageId );
SET @IntEmployeeName2 = (  select IntEmployeeName2 from  vehicle_damage where VehicleDamageId = $VehicleDamageId );
SET @IntEmployeeDept2 = (  select IntEmployeeDept2 from  vehicle_damage where VehicleDamageId = $VehicleDamageId );
SET @IntEmployeeName3 = (  select IntEmployeeName3 from  vehicle_damage where VehicleDamageId = $VehicleDamageId );
SET @IntEmployeeDept3 = (  select IntEmployeeDept3 from  vehicle_damage where VehicleDamageId = $VehicleDamageId );
SET @PrimRespondName = ( select primrespondname from  vehicle_damage where VehicleDamageId = $VehicleDamageId  );
SET @ImpactDescription = (  select description from  vehicle_damage where VehicleDamageId = $VehicleDamageId );
IF($OldVehicleDamageId is null) then
SET  @OldImpactDescription =( select concat(DATE_FORMAT(curdate(), '%b %d %Y'),' ', '(',@UpdatedByName,')',': ', ifnull((@ImpactDescription), '') ));
ELSE
SET @OldImpactDescription = ( select concat(DATE_FORMAT(curdate(), '%b %d %Y'),' ', '(',@UpdatedByName,')',': ', ifnull((@ImpactDescription), '') ,' <br><br> ', ifnull((OldImpactDescription), '')) from hist_vehicle_damage where VehicleDamageId = $OldVehicleDamageId limit 1);
END IF;
SET @EstimatedCost = (  select estimatedcost from  vehicle_damage where VehicleDamageId = $VehicleDamageId );
SET @VersionNumber = (SELECT MAX(VersionNumber) FROM hist_incident WHERE IncidentId = @IncidentId);
SET @HistIncidentId = (SELECT HistIncidentId FROM hist_incident WHERE IncidentId = @IncidentId AND VersionNumber = @VersionNumber);
SET @HistoryOperationId = (SELECT HistoryOperationId FROM hist_incident WHERE HistIncidentId = @HistIncidentId);
if($OriginalVehicleDamageId is null or $OriginalVehicleDamageId = '') then
SET $OriginalVehicleDamageId = $VehicleDamageId ;
END IF;
SET @UpdatedDate = CURRENT_TIMESTAMP();
INSERT INTO `hist_vehicle_damage`
(
`HistVehicleDamageId`,
`VehicleDamageId`,
`IncidentId`,
`DriverName`,
`DriverLicence`,
`VehicleTypeName`,
`VehicleLicence`,
`HowDidThatDone`,
`OldHowDidThatDone`,
`DamageDescription`,
`OldDamageDescription`,
`ImpactTypeName`,
`ImpactSubTypeName`,
`ExtAgencyName`,
`IntEmployeeName1`,
`IntEmployeeDept1`,
`IntEmployeeName2`,
`IntEmployeeDept2`,
`IntEmployeeName3`,
`IntEmployeeDept3`,
`PrimRespondName`,
`ImpactDescription`,
`OldImpactDescription`,
`EstimatedCost`,
`HistoryOperationId`,
`UpdatedById`,
`UpdatedDate`,
`HistIncidentId`,
`OriginalVehicleDamageId`
)
VALUES
(
MyUUID(),
$VehicleDamageId,
@IncidentId,
@DriverName,
@DriverLicence,
@VehicleTypeName,
@VehicleLicence,
@HowDidThatDone,
@OldHowDidThatDone,
@DamageDescription,
@OldDamageDescription,
@ImpactTypeName,
@ImpactSubTypeName,
@ExtAgencyName,
@IntEmployeeName1,
@IntEmployeeDept1,
@IntEmployeeName2,
@IntEmployeeDept2,
@IntEmployeeName3,
@IntEmployeeDept3,
@PrimRespondName,
@ImpactDescription,
@OldImpactDescription,
@EstimatedCost,
@HistoryOperationId,
$UpdatedById,
@UpdatedDate,
@HistIncidentId,
$OriginalVehicleDamageId
);
END;
