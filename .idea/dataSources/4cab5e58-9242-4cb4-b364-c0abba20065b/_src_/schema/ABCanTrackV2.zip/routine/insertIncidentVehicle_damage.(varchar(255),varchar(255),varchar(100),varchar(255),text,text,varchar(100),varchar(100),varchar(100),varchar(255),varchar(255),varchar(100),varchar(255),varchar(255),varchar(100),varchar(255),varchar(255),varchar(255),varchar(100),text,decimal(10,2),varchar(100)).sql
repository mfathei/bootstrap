CREATE PROCEDURE ABCanTrackV2.insertIncidentVehicle_damage(IN `$DriverName`        VARCHAR(255),
                                                           IN `$DriverLicence`     VARCHAR(255),
                                                           IN `$VehicleTypeId`     VARCHAR(100),
                                                           IN `$VehicleLicence`    VARCHAR(255),
                                                           IN `$HowDidThatDone`    TEXT, IN `$DamageDescription` TEXT,
                                                           IN `$IncidentId`        VARCHAR(100),
                                                           IN `$ImpactSubTypeId`   VARCHAR(100),
                                                           IN `$IntEmployeeId1`    VARCHAR(100),
                                                           IN `$IntEmployeeName1`  VARCHAR(255),
                                                           IN `$IntEmployeeDept1`  VARCHAR(255),
                                                           IN `$IntEmployeeId2`    VARCHAR(100),
                                                           IN `$IntEmployeeName2`  VARCHAR(255),
                                                           IN `$IntEmployeeDept2`  VARCHAR(255),
                                                           IN `$IntEmployeeId3`    VARCHAR(100),
                                                           IN `$IntEmployeeName3`  VARCHAR(255),
                                                           IN `$IntEmployeeDept3`  VARCHAR(255),
                                                           IN `$PrimRespondName`   VARCHAR(255),
                                                           IN `$PrimRespondId`     VARCHAR(100), IN `$Description` TEXT,
                                                           IN `$EstimatedCost`     DECIMAL(10, 2),
                                                           IN `$DamageDriverId`    VARCHAR(100))
    my_proc :BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        SELECT 0 ;
        ROLLBACK ;
    END ;
    DECLARE EXIT HANDLER FOR SQLWARNING 
    BEGIN
        SELECT 0 ;
        ROLLBACK ;
    END ;
    
    SET $VehicleTypeId = 
    (SELECT 
        `VehicleTypeId` 
    FROM
        vehicle_type 
    WHERE `VehicleTypeId` = $VehicleTypeId) ;
    
    SET $DamageDriverId = 
    (SELECT 
        EmployeeId 
    FROM
        employee 
    WHERE EmployeeId = $DamageDriverId) ;
    
    
    SET $ImpactSubTypeId = 
    (SELECT 
        `ImpactSubTypeId` 
    FROM
        impact_sub_type 
    WHERE `ImpactSubTypeId` = $ImpactSubTypeId) ;
    
    SET $IntEmployeeId1 = 
    (SELECT 
        EmployeeId 
    FROM
        employee 
    WHERE EmployeeId = $IntEmployeeId1) ;
    SET $IntEmployeeId2 = 
    (SELECT 
        EmployeeId 
    FROM
        employee 
    WHERE EmployeeId = $IntEmployeeId2) ;
    SET $IntEmployeeId3 = 
    (SELECT 
        EmployeeId 
    FROM
        employee 
    WHERE EmployeeId = $IntEmployeeId3) ;
    SET $PrimRespondId = 
    (SELECT 
        EmployeeId 
    FROM
        employee 
    WHERE EmployeeId = $PrimRespondId) ;
    
    INSERT INTO vehicle_damage (
    DriverName,
    DriverLicence,
    VehicleTypeId,
    VehicleLicence,
    HowDidThatDone,
    DamageDescription,
    IncidentId,
    ImpactSubTypeId,
    IntEmployeeId1,
    IntEmployeeName1,
    IntEmployeeDept1,
    IntEmployeeId2,
    IntEmployeeName2,
    IntEmployeeDept2,
    IntEmployeeId3,
    IntEmployeeName3,
    IntEmployeeDept3,
    PrimRespondName,
    PrimRespondId,
    Description,
    EstimatedCost,
    DamageDriverId
    ) 
    VALUES
    (
        $DriverName,
        $DriverLicence,
        $VehicleTypeId,
        $VehicleLicence,
        $HowDidThatDone,
        $DamageDescription,
        $IncidentId,
        $ImpactSubTypeId,
        $IntEmployeeId1,
        $IntEmployeeName1,
        $IntEmployeeDept1,
        $IntEmployeeId2,
        $IntEmployeeName2,
        $IntEmployeeDept2,
        $IntEmployeeId3,
        $IntEmployeeName3,
        $IntEmployeeDept3,
        $PrimRespondName,
        $PrimRespondId,
        $Description,
        $EstimatedCost,
        $DamageDriverId
    );
    
    SELECT 1 ;
END;
