CREATE PROCEDURE ABCanTrackV2.DeleteOrgPeopleInvolved(IN `$OrgId` VARCHAR(100))
  BEGIN
	DECLARE $Count INT;
    
    
    -- Step1: have_certificate
	SET $Count = (SELECT COUNT(*) FROM have_certificate WHERE PeopleInvolvedId IN (SELECT PeopleInvolvedId FROM people_involved WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId)));
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgPeopleInvolved',  'have_certificate', NULL, $Count, 1);
    
	-- ************
	DELETE FROM have_certificate WHERE PeopleInvolvedId IN (SELECT PeopleInvolvedId FROM people_involved WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId));
    -- #
    
    
    -- Step2: people_involved
	SET $Count = (SELECT COUNT(*) FROM people_involved WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId));
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgPeopleInvolved',  'people_involved', NULL, $Count, 2);
    
	-- ************
	DELETE FROM people_involved WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE OrgId = $OrgId);
    -- #
    
    -- Step3: DONE
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgPeopleInvolved', 'DONE', NULL, NULL, 3);
    -- # 
END;
