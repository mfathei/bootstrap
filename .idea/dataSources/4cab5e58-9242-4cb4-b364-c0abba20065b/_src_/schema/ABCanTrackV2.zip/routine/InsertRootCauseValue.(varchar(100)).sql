CREATE PROCEDURE ABCanTrackV2.InsertRootCauseValue(IN `$IncidentId` VARCHAR(100))
  BEGIN
DECLARE $HistIncidentId VARCHAR(100);
-- DECLARE $RootCauseName, $OtherRootCause TEXT;
DECLARE $VersionNumber INT;
SET $VersionNumber = (SELECT MAX(VersionNumber) FROM hist_incident WHERE IncidentId = $IncidentId);
SET $HistIncidentId = (SELECT HistIncidentId FROM hist_incident WHERE IncidentId = $IncidentId AND VersionNumber = $VersionNumber);
SET @RootCauseName = (SELECT GROUP_CONCAT(RootCauseParamName SEPARATOR ' ;| ') FROM root_cause_param WHERE RootCauseParamId IN (SELECT RootCauseParamId FROM inc_root_cause WHERE IncidentId = $IncidentId));
SET @OtherRootCause = (SELECT GROUP_CONCAT(Other SEPARATOR ' ;| ') FROM inc_root_cause WHERE IncidentId = $IncidentId);
UPDATE hist_incident
SET RootCauseName = @RootCauseName,
    OtherRootCause = @OtherRootCause
WHERE HistIncidentId = $HistIncidentId;
END;
