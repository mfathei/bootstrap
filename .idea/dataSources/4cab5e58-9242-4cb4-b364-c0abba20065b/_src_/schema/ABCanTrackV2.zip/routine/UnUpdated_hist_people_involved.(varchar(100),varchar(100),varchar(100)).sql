CREATE PROCEDURE ABCanTrackV2.UnUpdated_hist_people_involved(IN `$NewHistIncidentId` VARCHAR(100),
                                                             IN `$OldHistIncidentId` VARCHAR(100),
                                                             IN `$UpdatedById`       VARCHAR(100))
  BEGIN
INSERT INTO `ABCanTrackV2`.`hist_people_involved`
(`HistPeopleInvolvedId`,
`PeopleInvolvedId`,
`OriginalPeopleInvolvedId`,
`IncidentId`,
`PeopleInvolvedName`,
`CertificateName`,
`Company`,
`Position`,
`Email`,   
`PrimaryPhone`,
`AlternatePhone`,
`ExpInCurrentPostion`,
`ExpOverAll`,
`HowHeInvolved`,
`RoleDescription`,
`OldRoleDescription`,
`HistoryOperationId`,
`UpdatedById`,
`UpdatedDate`,
`HistIncidentId`
)
select 
`HistPeopleInvolvedId`,
`PeopleInvolvedId`,
`OriginalPeopleInvolvedId`,
`IncidentId`,
`PeopleInvolvedName`,
`CertificateName`,
`Company`,
`Position`,
`Email`,
`PrimaryPhone`,
`AlternatePhone`,
`ExpInCurrentPostion`,
`ExpOverAll`,
`HowHeInvolved`,
`RoleDescription`,
`OldRoleDescription`,
`HistoryOperationId`,
$UpdatedById,
`UpdatedDate`,
$NewHistIncidentId
from hist_people_involved
WHERE HistIncidentId = $OldHistIncidentId;
INSERT INTO `ABCanTrackV2`.`hist_field_value`
(`HistFieldValueId`,
`FieldValueId`,
`IncidentId`,
`FieldId`,
`OptionName`,
`HistIncidentId`,
`FieldValue`,
`TableKeyValue`,
`TableKeyId`,
`HistoryOperationId`,
`UpdatedById`)
SELECT 
`HistFieldValueId`,
`FieldValueId`,
`IncidentId`,
`FieldId`,
`OptionName`,
$NewHistIncidentId,
`FieldValue`,
`TableKeyValue`,
`TableKeyId`,
`HistoryOperationId`,
$UpdatedById
FROM  hist_field_value
WHERE HistIncidentId = $OldHistIncidentId AND TableKeyValue = 'people_involved';
END;
