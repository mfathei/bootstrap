CREATE FUNCTION ABCanTrackV2.getDetails(`$TrafficViolationId` VARCHAR(100), `$OriginalTrafficViolationId` VARCHAR(100))
  RETURNS TEXT
  BEGIN
if $OriginalTrafficViolationId is null   or $OriginalTrafficViolationId  =''   then
	set $OriginalTrafficViolationId = $TrafficViolationId ;
end if;
set session group_concat_max_len = 10000;
select (group_concat(DATE_FORMAT(UpdatedDate, '%b %d %Y') ,' ', '(',  concat(firstname ,' ', lastname) ,')',': <pr>', Details separator '<br><br>' ) ) as Details   
 into @newDetails 
 from(
 select UpdatedDate, Details, firstname,lastname FROM hist_traffic_violation hi 
join employee e on e.EmployeeId = hi.UpdatedbyId
 where OriginalTrafficViolationId = $OriginalTrafficViolationId  
order by UpdatedDate asc  ) temp ; 
return @newDetails;
END;
