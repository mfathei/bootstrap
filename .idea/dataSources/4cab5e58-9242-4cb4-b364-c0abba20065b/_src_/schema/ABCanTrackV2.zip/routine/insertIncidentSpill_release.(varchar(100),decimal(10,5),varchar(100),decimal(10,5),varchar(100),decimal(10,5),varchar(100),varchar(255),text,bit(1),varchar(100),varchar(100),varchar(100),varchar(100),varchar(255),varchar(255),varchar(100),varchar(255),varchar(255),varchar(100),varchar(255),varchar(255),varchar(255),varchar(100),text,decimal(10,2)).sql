CREATE PROCEDURE ABCanTrackV2.insertIncidentSpill_release(IN `$SourceId`               VARCHAR(100),
                                                          IN `$DurationValue`          DECIMAL(10, 5),
                                                          IN `$DurationUnitId`         VARCHAR(100),
                                                          IN `$QuantityValue`          DECIMAL(10, 5),
                                                          IN `$QuantityUnitId`         VARCHAR(100),
                                                          IN `$QuantityRecoveredValue` DECIMAL(10, 5),
                                                          IN `$RecoveredUnitId`        VARCHAR(100),
                                                          IN `$WhatWasIt`              VARCHAR(255),
                                                          IN `$HowDidSROccur`          TEXT, IN `$IsReportable` BIT,
                                                          IN `$SpRelAgencyId`          VARCHAR(100),
                                                          IN `$IncidentId`             VARCHAR(100),
                                                          IN `$ImpactSubTypeId`        VARCHAR(100),
                                                          IN `$IntEmployeeId1`         VARCHAR(100),
                                                          IN `$IntEmployeeName1`       VARCHAR(255),
                                                          IN `$IntEmployeeDept1`       VARCHAR(255),
                                                          IN `$IntEmployeeId2`         VARCHAR(100),
                                                          IN `$IntEmployeeName2`       VARCHAR(255),
                                                          IN `$IntEmployeeDept2`       VARCHAR(255),
                                                          IN `$IntEmployeeId3`         VARCHAR(100),
                                                          IN `$IntEmployeeName3`       VARCHAR(255),
                                                          IN `$IntEmployeeDept3`       VARCHAR(255),
                                                          IN `$PrimRespondName`        VARCHAR(255),
                                                          IN `$PrimRespondId`          VARCHAR(100),
                                                          IN `$Description`            TEXT,
                                                          IN `$EstimatedCost`          DECIMAL(10, 2))
    my_proc :BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        SELECT 0 ;
        ROLLBACK ;
    END ;
    DECLARE EXIT HANDLER FOR SQLWARNING 
    BEGIN
        SELECT 0 ;
        ROLLBACK ;
    END ;
    
    SET $SourceId = 
    (SELECT 
        `SourceId` 
    FROM
        spill_release_source 
    WHERE `SourceId` = $SourceId) ;
    
    SET $DurationUnitId = 
    (SELECT 
        `DurationUnitId` 
    FROM
        duration_unit 
    WHERE `DurationUnitId` = $DurationUnitId) ;
    
    SET $QuantityUnitId = 
    (SELECT 
        `QuantityUnitId` 
    FROM
        quantity_unit 
    WHERE `QuantityUnitId` = $QuantityUnitId) ;
    
    SET $RecoveredUnitId = 
    (SELECT 
        `QuantityUnitId` 
    FROM
        quantity_unit 
    WHERE `QuantityUnitId` = $RecoveredUnitId) ;
    
    SET $SpRelAgencyId = 
    (SELECT 
        `SpRelAgencyId` 
    FROM
        sp_rel_agency 
    WHERE `SpRelAgencyId` = $SpRelAgencyId) ;
    
    
    SET $ImpactSubTypeId = 
    (SELECT 
        `ImpactSubTypeId` 
    FROM
        impact_sub_type 
    WHERE `ImpactSubTypeId` = $ImpactSubTypeId) ;
    
    SET $IntEmployeeId1 = 
    (SELECT 
        EmployeeId 
    FROM
        employee 
    WHERE EmployeeId = $IntEmployeeId1) ;
    SET $IntEmployeeId2 = 
    (SELECT 
        EmployeeId 
    FROM
        employee 
    WHERE EmployeeId = $IntEmployeeId2) ;
    SET $IntEmployeeId3 = 
    (SELECT 
        EmployeeId 
    FROM
        employee 
    WHERE EmployeeId = $IntEmployeeId3) ;
    SET $PrimRespondId = 
    (SELECT 
        EmployeeId 
    FROM
        employee 
    WHERE EmployeeId = $PrimRespondId) ;
    
    INSERT INTO spill_release (
    SourceId,
    DurationValue,
    DurationUnitId,
    QuantityValue,
    QuantityUnitId,
    QuantityRecoveredValue,
    RecoveredUnitId,
    WhatWasIt,
    HowDidSROccur,
    IsReportable,
    SpRelAgencyId,
    IncidentId,
    ImpactSubTypeId,
    IntEmployeeId1,
    IntEmployeeName1,
    IntEmployeeDept1,
    IntEmployeeId2,
    IntEmployeeName2,
    IntEmployeeDept2,
    IntEmployeeId3,
    IntEmployeeName3,
    IntEmployeeDept3,
    PrimRespondName,
    PrimRespondId,
    Description,
    EstimatedCost
) 
VALUES
    (
        $SourceId,
        $DurationValue,
        $DurationUnitId,
        $QuantityValue,
        $QuantityUnitId,
        $QuantityRecoveredValue,
        $RecoveredUnitId,
        $WhatWasIt,
        $HowDidSROccur,
        $IsReportable,
        $SpRelAgencyId,
        $IncidentId,
        $ImpactSubTypeId,
        $IntEmployeeId1,
        $IntEmployeeName1,
        $IntEmployeeDept1,
        $IntEmployeeId2,
        $IntEmployeeName2,
        $IntEmployeeDept2,
        $IntEmployeeId3,
        $IntEmployeeName3,
        $IntEmployeeDept3,
        $PrimRespondName,
        $PrimRespondId,
        $Description,
        $EstimatedCost
    );
    
    SELECT 1 ;
END;
