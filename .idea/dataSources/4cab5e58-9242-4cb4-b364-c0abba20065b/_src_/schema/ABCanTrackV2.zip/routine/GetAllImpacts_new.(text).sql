CREATE PROCEDURE ABCanTrackV2.GetAllImpacts_new(IN xmlData TEXT)
  BEGIN 
SET @OrgId = extractvalue(xmlData, '//OrgId');
SET @page = extractvalue(xmlData, '//page');
SET @limit = extractvalue(xmlData, '//limit');
SET @sortOrder =  extractvalue(xmlData, '//sortOrder');
SET @index =  extractvalue(xmlData, '//index');
SET @Mine =  extractvalue(xmlData, '//Mine');
SET @CreatorId = extractvalue(xmlData, '//CreatorId');
SET @Export =  extractvalue(xmlData, '//Export');
set @selectquery ="
SELECT  
incident.IncidentId, 
incident.IncidentNumber, 
date_format(incident.IncidentDate,'%m/%d/%Y') as IncidentDate,
incident.EditingBy, incident.EditingBy as LockedId,
incident.OtherLocation,
all_impact_types.ImpactId, 
all_impact_types.ImpactTypeName as ImpactTypeId,
all_impact_types.ImpactTypeCode ,
all_impact_types.ImpactSubTypeName as ImpactSubTypeId,
all_impact_types.IntEmployeeName1 ,
all_impact_types.IntEmployeeName2  ,
all_impact_types.IntEmployeeName3  ,
all_impact_types.IntEmployeeDept1 ,
all_impact_types.IntEmployeeDept2 ,
all_impact_types.IntEmployeeDept3  ,
all_impact_types.PrimRespondName,
all_impact_types.Description as ImpactDescription ,
all_impact_types.EstimatedCost as ImpactEstimatedCost,
all_impact_types.ExtAgencyName as ExtAgencyId, Identification ";
set @queryFrom = " from all_impact_types 
inner join incident  on incident.IncidentId = all_impact_types.IncidentId  ";
SET @queryWhere = ' where 1= 1 ';
IF (@OrgId != '' AND @OrgId !='0') THEN
	SET @queryWhere = CONCAT(@queryWhere,' and incident.OrgId =   "', @Orgid,'" ');
END IF;
IF (@Mine = 'true') THEN
	SET @queryWhere = CONCAT(@queryWhere,' AND incident.CreatorId =  "',@CreatorId,'" '  );
END IF;
SET @queryWhere = CONCAT(@queryWhere,' AND incident.Hide =  0');
IF( ExtractValue(xmlData, 'count(//EventTypeId)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', event_type.EventTypeName as EventTypeId ');
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join event_type on incident.EventTypeId = event_type.EventTypeId  ');
END IF;
IF( ExtractValue(xmlData, 'count(//OperationTypeId)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', operation_type.OperationTypeName as OperationTypeId ');
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join operation_type on incident.OperationTypeId = operation_type.OperationTypeId  ');
END IF;
IF( ExtractValue(xmlData, 'count(//Location1Id)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', location1.Location1Name as Location1Id ');
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join location1 on incident.Location1Id = location1.Location1Id  ');
END IF;
IF( ExtractValue(xmlData, 'count(//Location2Id)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', location2.Location2Name as Location2Id ');
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join location2 on incident.Location2Id = location2.Location2Id  ');
END IF;
IF( ExtractValue(xmlData, 'count(//Location3Id)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', location3.Location3Name as Location3Id ');
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join location3 on incident.Location3Id = location3.Location3Id  ');
END IF;
IF( ExtractValue(xmlData, 'count(//Location4Id)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', location4.Location4Name as Location4Id ');
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join location4 on incident.Location4Id = location4.Location4Id  ');
END IF;
IF( ExtractValue(xmlData, 'count(//UpdatedByName)') >0 OR ExtractValue(xmlData, 'count(//VersionNumber)') >0) THEN
		SET @selectquery = CONCAT(@selectquery,',  VersionNumber ');
		SET @queryFrom = CONCAT(@queryFrom,'   inner join hist_incident on hist_incident.Incidentid = incident.IncidentId  and  hist_incident.HistIncidentId =   hist_incident(incident.IncidentId)    ');
	
		IF( ExtractValue(xmlData, 'count(//UpdatedByName)') >0)THEN		
			SET @selectquery = CONCAT(@selectquery,', ', 'max( CONCAT',' (','empModifier.FirstName,',"'","  '" ,',empModifier.LastName',') ',') as UpdatedByName ');
			SET @queryFrom = CONCAT(@queryFrom,'  inner join employee as empModifier on hist_incident.UpdatedById = empModifier.EmployeeId  ');
		END IF;
END IF;
IF( ExtractValue(xmlData, 'count(//CreatorName)') >0 ) THEN
	SET @selectquery = CONCAT(@selectquery,', ', 'CONCAT',' (','empCreator.FirstName,',"'","  '" ,',empCreator.LastName',') ',' as CreatorName ');
	SET @queryFrom = CONCAT(@queryFrom,'    inner join employee as empCreator on incident.CreatorId = empCreator.EmployeeId  ');
END IF;
/* injury part   */
IF(ExtractValue(xmlData, 'count(//InjuryTypeId)') >0 OR ExtractValue(xmlData, 'count(//BodyPartId)') >0 
OR ExtractValue(xmlData, 'count(//BodyAreaId)') >0 OR ExtractValue(xmlData, 'count(//PersonalInjured)') >0 
OR ExtractValue(xmlData, 'count(//ContactCodeId)') >0 OR ExtractValue(xmlData, 'count(//RecordableId)') >0
OR ExtractValue(xmlData, 'count(//InitialTreatmentId)') >0 OR ExtractValue(xmlData, 'count(//InjuryExtAgencyId)') >0 
OR ExtractValue(xmlData, 'count(//LostTimeEnd)') >0 OR ExtractValue(xmlData, 'count(//TotalDaysOff)') >0 
OR ExtractValue(xmlData, 'count(//InjuryDescription)') >0 OR ExtractValue(xmlData, 'count(//AdjustmentDays)') >0
OR ExtractValue(xmlData, 'count(//LostTimeStart)') >0) THEN
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join incident_injury_view on incident_injury_view.InjuryId = all_impact_types.ImpactId  ');
	
	IF(ExtractValue(xmlData, 'count(//InjuryTypeId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(InjuryTypeId separator "; ") 
														from incident_injury_view
														where incident_injury_view.InjuryId = all_impact_types.ImpactId) as InjuryTypeId' );	
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//BodyPartId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(BodyPartId separator "; ") 
														from incident_injury_view
														where incident_injury_view.InjuryId = all_impact_types.ImpactId) as BodyPartId' );	
	END IF;
	
	
		IF(ExtractValue(xmlData, 'count(//BodyAreaId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(BodyAreaId separator "; ") 
														from incident_injury_view
														where incident_injury_view.InjuryId = all_impact_types.ImpactId) as BodyAreaId' );	
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//PersonalInjured)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(PersonalInjured separator "; ") 
														from incident_injury_view
														where incident_injury_view.InjuryId = all_impact_types.ImpactId) as PersonalInjured' );	
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//ContactCodeId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(ContactCodeId separator "; ") 
														from incident_injury_view
														where incident_injury_view.InjuryId = all_impact_types.ImpactId) as ContactCodeId' );	
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//RecordableId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(RecordableId separator "; ") 
														from incident_injury_view
														where incident_injury_view.InjuryId = all_impact_types.ImpactId) as RecordableId' );	
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//InitialTreatmentId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(InitialTreatmentId separator "; ") 
														from incident_injury_view
														where incident_injury_view.InjuryId = all_impact_types.ImpactId) as InitialTreatmentId' );	
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//InjuryExtAgencyId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(InjuryExtAgencyId separator "; ") 
														from incident_injury_view
														where incident_injury_view.InjuryId = all_impact_types.ImpactId) as InjuryExtAgencyId' );	
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//AdjustmentDays)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(AdjustmentDays separator "; ") 
														from incident_injury_view
														where incident_injury_view.InjuryId = all_impact_types.ImpactId) as AdjustmentDays' );	
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//TotalDaysOff)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(TotalDaysOff separator "; ") 
														from incident_injury_view
														where incident_injury_view.InjuryId = all_impact_types.ImpactId) as TotalDaysOff' );	
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//InjuryDescription)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(InjuryDescription separator "; ") 
														from incident_injury_view
														where incident_injury_view.InjuryId = all_impact_types.ImpactId) as InjuryDescription' );	
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//LostTimeEnd)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(date_format(LostTimeEnd,'%m/%d/%Y') separator "; ") 
														from incident_injury_view
														where incident_injury_view.InjuryId = all_impact_types.ImpactId) as LostTimeEnd' );	
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//LostTimeStart)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(date_format(LostTimeStart,'%m/%d/%Y') separator "; ") 
														from incident_injury_view
														where incident_injury_view.InjuryId = all_impact_types.ImpactId) as LostTimeStart' );	
	END IF;
	
END IF;
/* Illness part   */
IF(ExtractValue(xmlData, 'count(//IllnessDescription)') >0 OR ExtractValue(xmlData, 'count(//Illness_RestrictedWorkId)') >0 
OR ExtractValue(xmlData, 'count(//Illness_PersonalInjured)') >0 OR ExtractValue(xmlData, 'count(//Illness_InitialTreatmentId)') >0 
OR ExtractValue(xmlData, 'count(//ContactCodeId)') >0 OR ExtractValue(xmlData, 'count(//RecordableId)') >0
OR ExtractValue(xmlData, 'count(//Illness_AdjustmentDays)') >0 OR ExtractValue(xmlData, 'count(//Illness_AdjustmentDays)') >0 
OR ExtractValue(xmlData, 'count(//Illness_LostTimeEnd)') >0 OR ExtractValue(xmlData, 'count(//Illness_LostTimeStart)') >0 
OR ExtractValue(xmlData, 'count(//Illness_TotalDaysOff)') >0 OR ExtractValue(xmlData, 'count(//SymptomsId)') >0 ) THEN
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join incident_illness_view on incident_illness_view.IllnessId = all_impact_types.ImpactId  ');
	
	IF(ExtractValue(xmlData, 'count(//IllnessDescription)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(IllnessDescription separator "; ") 
														from incident_illness_view
														where incident_illness_view.IllnessId = all_impact_types.ImpactId) as IllnessDescription' );	
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//Illness_RestrictedWorkId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(Illness_RestrictedWorkId separator "; ") 
														from incident_illness_view
														where incident_illness_view.IllnessId = all_impact_types.ImpactId) as Illness_RestrictedWorkId' );	
	END IF;
	
	
		IF(ExtractValue(xmlData, 'count(//Illness_PersonalInjured)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(Illness_PersonalInjured separator "; ") 
														from incident_illness_view
														where incident_illness_view.IllnessId = all_impact_types.ImpactId) as Illness_PersonalInjured' );	
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//Illness_InitialTreatmentId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(Illness_InitialTreatmentId separator "; ") 
														from incident_illness_view
														where incident_illness_view.IllnessId = all_impact_types.ImpactId) as Illness_InitialTreatmentId' );	
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//Illness_AdjustmentDays)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(Illness_AdjustmentDays separator "; ") 
														from incident_illness_view
														where incident_illness_view.IllnessId = all_impact_types.ImpactId) as Illness_AdjustmentDays' );	
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//SymptomsId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(SymptomsId separator "; ") 
														from incident_illness_view
														where incident_illness_view.IllnessId = all_impact_types.ImpactId) as SymptomsId' );	
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//Illness_TotalDaysOff)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(Illness_TotalDaysOff separator "; ") 
														from incident_illness_view
														where incident_illness_view.IllnessId = all_impact_types.ImpactId) as Illness_TotalDaysOff' );	
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//Illness_LostTimeEnd)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(date_format(Illness_LostTimeEnd,'%m/%d/%Y') separator "; ") 
														from incident_illness_view
														where incident_illness_view.IllnessId = all_impact_types.ImpactId) as Illness_LostTimeEnd' );	
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//Illness_LostTimeStart)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(date_format(Illness_LostTimeStart,'%m/%d/%Y') separator "; ") 
														from incident_illness_view
														where incident_illness_view.IllnessId = all_impact_types.ImpactId) as Illness_LostTimeStart' );	
	END IF;
	
END IF;
/* traffic_damage part   */
IF(ExtractValue(xmlData, 'count(//TrafficDriverName)') >0 OR ExtractValue(xmlData, 'count(//TrafficDriverLicence)') >0 
OR ExtractValue(xmlData, 'count(//TrafficVehicleTypeId)') >0 OR ExtractValue(xmlData, 'count(//TrafficVehicleLicence)') >0 
OR ExtractValue(xmlData, 'count(//Details)') >0 OR ExtractValue(xmlData, 'count(//ValueOfFine)') >0
OR ExtractValue(xmlData, 'count(//TicketNumber)') >0 OR ExtractValue(xmlData, 'count(//HowDidThatOccur)') >0   ) THEN
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join incident_traffic_violation_view on incident_traffic_violation_view.TrafficViolationId = all_impact_types.ImpactId  ');
	
	IF(ExtractValue(xmlData, 'count(//TrafficDriverName)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(TrafficDriverName separator "; ") 
														from incident_traffic_violation_view
														where incident_traffic_violation_view.TrafficViolationId = all_impact_types.ImpactId) as TrafficDriverName' );	
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//TrafficDriverLicence)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(TrafficDriverLicence separator "; ") 
														from incident_traffic_violation_view
														where incident_traffic_violation_view.TrafficViolationId = all_impact_types.ImpactId) as TrafficDriverLicence' );	
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//TrafficVehicleTypeId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(TrafficVehicleTypeId separator "; ") 
														from incident_traffic_violation_view
														where incident_traffic_violation_view.TrafficViolationId = all_impact_types.ImpactId) as TrafficVehicleTypeId' );	
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//TrafficVehicleLicence)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(TrafficVehicleLicence separator "; ") 
														from incident_traffic_violation_view
														where incident_traffic_violation_view.TrafficViolationId = all_impact_types.ImpactId) as TrafficVehicleLicence' );	
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//Details)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(Details separator "; ") 
														from incident_traffic_violation_view
														where incident_traffic_violation_view.TrafficViolationId = all_impact_types.ImpactId) as Details' );	
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//ValueOfFine)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(ValueOfFine separator "; ") 
														from incident_traffic_violation_view
														where incident_traffic_violation_view.TrafficViolationId = all_impact_types.ImpactId) as ValueOfFine' );	
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//TicketNumber)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(TicketNumber separator "; ") 
														from incident_traffic_violation_view
														where incident_traffic_violation_view.TrafficViolationId = all_impact_types.ImpactId) as TicketNumber' );	
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//HowDidThatOccur)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(HowDidThatOccur separator "; ") 
														from incident_traffic_violation_view
														where incident_traffic_violation_view.TrafficViolationId = all_impact_types.ImpactId) as HowDidThatOccur' );	
	END IF;
	
END IF;
/* traffic_violation part   */
IF(ExtractValue(xmlData, 'count(//DamageDriverName)') >0 OR ExtractValue(xmlData, 'count(//DamageDriverLicence)') >0 
OR ExtractValue(xmlData, 'count(//DamageVehicleTypeId)') >0 OR ExtractValue(xmlData, 'count(//DamageVehicleLicence)') >0 
OR ExtractValue(xmlData, 'count(//HowDidThatDone)') >0 OR ExtractValue(xmlData, 'count(//DamageDescription)') >0 ) THEN
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join incident_vehicle_damage_view on incident_vehicle_damage_view.IncidentId = incident.IncidentId  ');
	
	IF(ExtractValue(xmlData, 'count(//DamageDriverName)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(DamageDriverName separator "; ") 
														from incident_vehicle_damage_view
														where incident_vehicle_damage_view.IncidentId = incident.IncidentId) as DamageDriverName' );	
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//DamageDriverLicence)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(DamageDriverLicence separator "; ") 
														from incident_vehicle_damage_view
														where incident_vehicle_damage_view.IncidentId = incident.IncidentId) as DamageDriverLicence' );	
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//DamageVehicleTypeId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(DamageVehicleTypeId separator "; ") 
														from incident_vehicle_damage_view
														where incident_vehicle_damage_view.IncidentId = incident.IncidentId) as DamageVehicleTypeId' );	
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//DamageVehicleLicence)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(DamageVehicleLicence separator "; ") 
														from incident_vehicle_damage_view
														where incident_vehicle_damage_view.IncidentId = incident.IncidentId) as DamageVehicleLicence' );	
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//HowDidThatDone)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(HowDidThatDone separator "; ") 
														from incident_vehicle_damage_view
														where incident_vehicle_damage_view.IncidentId = incident.IncidentId) as HowDidThatDone' );	
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//DamageDescription)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(DamageDescription separator "; ") 
														from incident_vehicle_damage_view
														where incident_vehicle_damage_view.IncidentId = incident.IncidentId) as DamageDescription' );	
	END IF;	
	
END IF;
/* spill_release part   */
IF(ExtractValue(xmlData, 'count(//SourceId)') >0 OR ExtractValue(xmlData, 'count(//DurationValue)') >0 
OR ExtractValue(xmlData, 'count(//DurationUnitId)') >0 OR ExtractValue(xmlData, 'count(//QuantityValue)') >0 
OR ExtractValue(xmlData, 'count(//QuantityUnitId)') >0 OR ExtractValue(xmlData, 'count(//QuantityRecoveredValue)') >0 
OR ExtractValue(xmlData, 'count(//RecoveredUnitId)') >0 OR ExtractValue(xmlData, 'count(//WhatWasIt)') >0 OR ExtractValue(xmlData, 'count(//HowDidSROccur)') >0 
OR ExtractValue(xmlData, 'count(//IsReportable)') >0 OR ExtractValue(xmlData, 'count(//ImpactsExtAgencyId)') >0 ) THEN
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join incident_spill_release_view on incident_spill_release_view.IncidentId = incident.IncidentId  ');
	
	IF(ExtractValue(xmlData, 'count(//SourceId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(SourceId separator "; ") 
														from incident_spill_release_view
														where incident_spill_release_view.IncidentId = incident.IncidentId) as SourceId' );	
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//DurationValue)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(DurationValue separator "; ") 
														from incident_spill_release_view
														where incident_spill_release_view.IncidentId = incident.IncidentId) as DurationValue' );	
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//DurationUnitId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(DurationUnitId separator "; ") 
														from incident_spill_release_view
														where incident_spill_release_view.IncidentId = incident.IncidentId) as DurationUnitId' );	
	END IF;
	
	
	IF(ExtractValue(xmlData, 'count(//QuantityValue)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(QuantityValue separator "; ") 
														from incident_spill_release_view
														where incident_spill_release_view.IncidentId = incident.IncidentId) as QuantityValue' );	
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//QuantityUnitId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(QuantityUnitId separator "; ") 
														from incident_spill_release_view
														where incident_spill_release_view.IncidentId = incident.IncidentId) as QuantityUnitId' );	
	END IF;
	
	IF(ExtractValue(xmlData, 'count(//QuantityRecoveredValue)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(QuantityRecoveredValue separator "; ") 
														from incident_spill_release_view
														where incident_spill_release_view.IncidentId = incident.IncidentId) as QuantityRecoveredValue' );	
	END IF;	
	
		IF(ExtractValue(xmlData, 'count(//RecoveredUnitId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(RecoveredUnitId separator "; ") 
														from incident_spill_release_view
														where incident_spill_release_view.IncidentId = incident.IncidentId) as RecoveredUnitId' );	
	END IF;
	
		IF(ExtractValue(xmlData, 'count(//WhatWasIt)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(WhatWasIt separator "; ") 
														from incident_spill_release_view
														where incident_spill_release_view.IncidentId = incident.IncidentId) as WhatWasIt' );	
	END IF;
	
		IF(ExtractValue(xmlData, 'count(//HowDidSROccur)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(HowDidSROccur separator "; ") 
														from incident_spill_release_view
														where incident_spill_release_view.IncidentId = incident.IncidentId) as HowDidSROccur' );	
	END IF;
	
		IF(ExtractValue(xmlData, 'count(//IsReportable)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(IsReportable separator "; ") 
														from incident_spill_release_view
														where incident_spill_release_view.IncidentId = incident.IncidentId) as IsReportable' );	
	END IF;
	
		IF(ExtractValue(xmlData, 'count(//ImpactsExtAgencyId)') >0 )then 	
		SET @selectquery = CONCAT(@selectquery,', (select group_concat(ImpactsExtAgencyId separator "; ") 
														from incident_spill_release_view
														where incident_spill_release_view.IncidentId = incident.IncidentId) as ImpactsExtAgencyId' );	
	END IF;
	
END IF;
/* search part*/
 SET@myArrayOfValue='VersionNumber,IncidentNumber,EventTypeId,CreatorName,UpdatedByName,Location1Id,Location2Id,Location3Id,Location4Id,OtherLocation,OperationTypeId,IncDescription,SourceId,DurationValue,DurationUnitId,QuantityValue,QuantityUnitId,QuantityRecoveredValue,RecoveredUnitId,WhatWasIt,HowDidSROccur,IsReportable,ImpactsExtAgencyId,DamageDriverName,DamageDriverLicence,DamageVehicleTypeId,DamageVehicleLicence,HowDidThatDone,DamageDescription,TrafficTrafficDriverName,TrafficTrafficDriverLicence,TrafficVehicleTypeId,TrafficVehicleLicence,Details,ValueOfFine,TicketNumber,HowDidThatOccur,SymptomsId,IllnessDescription,Illness_RestrictedWorkId,Illness_PersonalInjured,Illness_InitialTreatmentId,Illness_AdjustmentDays,Illness_TotalDaysOff,InjuryTypeId,BodyPartId,BodyAreaId,PersonalInjured,ContactCodeId,RecordableId,InitialTreatmentId,InjuryExtAgencyId,AdjustmentDays,TotalDaysOff,InjuryDescription,ImpactTypeId,ImpactSubTypeId,ImpactDescription,IntEmployeeName1,IntEmployeeDept1,IntEmployeeName2,IntEmployeeDept2,IntEmployeeName3,IntEmployeeDept3,CustomOpenTxt,PrimRespondName,';
 SET @Postition = LOCATE(',', @myArrayOfValue);
WHILE ( @Postition > 0 ) DO
 SET @STR = SUBSTRING(@myArrayOfValue, 1, @Postition-1);
 SET @myArrayOfValue = SUBSTRING(@myArrayOfValue, @Postition + 1);
 SET @Col =  extractvalue(xmlData, CONCAT('//',@STR));
 IF (@Col != '' AND @Col !='NULL') THEN
	
    IF (@STR  = 'CreatorName' ) then set @STR= 'concat (empCreator.FirstName," ",empCreator.LastName) '; END IF;
	IF (@STR  = 'IncidentId' ) then set @STR= 'incident.IncidentId';  END IF;
	IF (@STR  = 'Location1Id' ) then set @STR= 'location1.Location1Name'; END IF;
	IF (@STR  = 'Location2Id' ) then set @STR= 'location2.Location2Name';  END IF;
	IF (@STR  = 'Location3Id' ) then set @STR= 'location3.Location3Name'; END IF;
	IF (@STR  = 'Location4Id' ) then set @STR= 'location4.Location4Name';  END IF;
	IF (@STR  = 'OperationTypeId' ) then set @STR= 'operation_type.OperationTypeName';  END IF;	
	IF (@STR  = 'EventTypeId' ) then set @STR= 'event_type.EventTypeName';  END IF;	
	IF (@STR  = 'UpdatedByName' ) then set @STR= CONCAT('CONCAT',' (','empCreator.FirstName,',"'","  '" ,',empCreator.LastName',') '); END IF;	
	IF(@STR  = 'ImpactTypeId' )then 		SET @STR= 'all_impact_types.ImpactTypeName ';	END IF;
	IF(@STR  = 'ImpactSubTypeId' )then 		SET @STR= 'all_impact_types.ImpactSubTypeName';	END IF;
	IF(@STR  = 'IntEmployeeName1' )then 	SET @STR= 'all_impact_types.IntEmployeeName1 ';	END IF;
	IF(@STR  = 'IntEmployeeDept1' )then 	SET @STR= 'all_impact_types.IntEmployeeDept1 ';	END IF;
	IF(@STR  = 'IntEmployeeName2' )then 	SET @STR= 'all_impact_types.IntEmployeeName2 ';	END IF;
	IF(@STR  = 'IntEmployeeDept2' )then 	SET @STR= 'all_impact_types.IntEmployeeDept2 ';	END IF;
	IF(@STR  = 'IntEmployeeName3' )then 	SET @STR= 'all_impact_types.IntEmployeeName3 ';	END IF;
	IF(@STR  = 'IntEmployeeDept3' )then 	SET @STR= 'all_impact_types.IntEmployeeDept3 ';	END IF;
	IF(@STR  = 'CustomOpenTxt' )then 		SET @STR= 'all_impact_types.ustomOpenTxt ';		END IF;
	IF(@STR  = 'PrimRespondName' )then 		SET @STR= 'all_impact_types.PrimRespondName ';	END IF;
	IF(@STR  = 'ImpactDescription' )then 	SET @STR= 'all_impact_types.Description ';		END IF;
	IF(@STR  = 'ImpactEstimatedCost' )then 	SET @STR= 'all_impact_types.EstimatedCost as ImpactEstimatedCost ';	END IF;
	IF(@STR  = 'ExtAgencyId' )then 			SET @STR= 'all_impact_types.ExtAgencyName ';	END IF;
	SET @queryWhere = CONCAT(@queryWhere,CONCAT(' AND ',@STR,' like '"'%", @Col ,"%'" )); 
 END IF;
 
 SET @Postition = LOCATE(',', @myArrayOfValue);
END WHILE;
 
-- select @queryWhere;
-- select CONCAT( @selectquery, @queryFrom, @queryWhere );
SET @LostTimeStartFrom =  extractvalue(xmlData, '//LostTimeStartFrom');
SET @LostTimeStartTo =  extractvalue(xmlData, '//LostTimeStartTo');
IF(@LostTimeStartTo != '') THEN
	SET @LostTimeStartFrom  = STR_TO_DATE(@LostTimeStartFrom , '%m/%d/%Y');
	SET @LostTimeStartTo  = STR_TO_DATE(@LostTimeStartTo , '%m/%d/%Y');
	SET @LostTimeStartTo2 = DATE_ADD(@LostTimeStartTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_injury_view.LostTimeStart >  ', "'" , @LostTimeStartFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_injury_view.LostTimeStart <=  ', "'",  @LostTimeStartTo2  ,"'" );										
ELSE 
IF(@LostTimeStartTo = '' AND @LostTimeStartFrom !='' ) THEN
	SET @LostTimeStartFrom  = STR_TO_DATE(@LostTimeStartFrom , '%m/%d/%Y');
	SET @LostTimeStartFrom2 = DATE_ADD(@LostTimeStartFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_injury_view.LostTimeStart >=  ',  "'", @LostTimeStartFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_injury_view.LostTimeStart <  ', "'", @LostTimeStartFrom2  ,"'");	
END IF;
END IF;
SET @LostTimeEndFrom =  extractvalue(xmlData, '//LostTimeEndFrom');
SET @LostTimeEndTo =  extractvalue(xmlData, '//LostTimeEndTo');
IF(@LostTimeEndTo != '') THEN
	SET @LostTimeEndFrom  = STR_TO_DATE(@LostTimeEndFrom , '%m/%d/%Y');
	SET @LostTimeEndTo  = STR_TO_DATE(@LostTimeEndTo , '%m/%d/%Y');
	SET @LostTimeEndTo2 = DATE_ADD(@LostTimeEndTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_injury_view.LostTimeEnd >  ', "'" , @LostTimeEndFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_injury_view.LostTimeEnd <=  ', "'",  @LostTimeEndTo2  ,"'" );										
ELSE 
IF(@LostTimeEndTo = '' AND @LostTimeEndFrom !='' ) THEN
	SET @LostTimeEndFrom  = STR_TO_DATE(@LostTimeEndFrom , '%m/%d/%Y');
	SET @LostTimeEndFrom2 = DATE_ADD(@LostTimeEndFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_injury_view.LostTimeEnd >=  ',  "'", @LostTimeEndFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_injury_view.LostTimeEnd <  ', "'", @LostTimeEndFrom2  ,"'");	
END IF;
END IF;
SET @Illness_LostTimeStartFrom =  extractvalue(xmlData, '//Illness_LostTimeStartFrom');
SET @Illness_LostTimeStartTo =  extractvalue(xmlData, '//Illness_LostTimeStartTo');
IF(@Illness_LostTimeStartTo != '') THEN
	SET @Illness_LostTimeStartFrom  = STR_TO_DATE(@Illness_LostTimeStartFrom , '%m/%d/%Y');
	SET @Illness_LostTimeStartTo  = STR_TO_DATE(@Illness_LostTimeStartTo , '%m/%d/%Y');
	SET @Illness_LostTimeStartTo2 = DATE_ADD(@Illness_LostTimeStartTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_illness_view.Illness_LostTimeStart >  ', "'" , @Illness_LostTimeStartFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_illness_view.Illness_LostTimeStart <=  ', "'",  @Illness_LostTimeStartTo2  ,"'" );										
ELSE 
IF(@Illness_LostTimeStartTo = '' AND @Illness_LostTimeStartFrom !='' ) THEN
	SET @Illness_LostTimeStartFrom  = STR_TO_DATE(@Illness_LostTimeStartFrom , '%m/%d/%Y');
	SET @Illness_LostTimeStartFrom2 = DATE_ADD(@Illness_LostTimeStartFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_illness_view.Illness_LostTimeStart >=  ',  "'", @Illness_LostTimeStartFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_illness_view.Illness_LostTimeStart <  ', "'", @Illness_LostTimeStartFrom2  ,"'");	
END IF;
END IF;
SET @Illness_LostTimeEndFrom =  extractvalue(xmlData, '//Illness_LostTimeEndFrom');
SET @Illness_LostTimeEndTo =  extractvalue(xmlData, '//Illness_LostTimeEndTo');
IF(@Illness_LostTimeEndTo != '') THEN
	SET @Illness_LostTimeEndFrom  = STR_TO_DATE(@Illness_LostTimeEndFrom , '%m/%d/%Y');
	SET @Illness_LostTimeEndTo  = STR_TO_DATE(@Illness_LostTimeEndTo , '%m/%d/%Y');
	SET @Illness_LostTimeEndTo2 = DATE_ADD(@Illness_LostTimeEndTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_illness_view.Illness_LostTimeEnd >  ', "'" , @Illness_LostTimeEndFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_illness_view.Illness_LostTimeEnd <=  ', "'",  @Illness_LostTimeEndTo2  ,"'" );										
ELSE 
IF(@Illness_LostTimeEndTo = '' AND @Illness_LostTimeEndFrom !='' ) THEN
	SET @Illness_LostTimeEndFrom  = STR_TO_DATE(@Illness_LostTimeEndFrom , '%m/%d/%Y');
	SET @Illness_LostTimeEndFrom2 = DATE_ADD(@Illness_LostTimeEndFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_illness_view.Illness_LostTimeEnd >=  ',  "'", @Illness_LostTimeEndFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident_illness_view.Illness_LostTimeEnd <  ', "'", @Illness_LostTimeEndFrom2  ,"'");	
END IF;
END IF;
SET @IncidentDateFrom =  extractvalue(xmlData, '//IncidentDateFrom');
SET @IncidentDateTo =  extractvalue(xmlData, '//IncidentDateTo');
IF(@IncidentDateTo != '') THEN
	SET @IncidentDateFrom  = STR_TO_DATE(@IncidentDateFrom , '%m/%d/%Y');
	SET @IncidentDateTo  = STR_TO_DATE(@IncidentDateTo , '%m/%d/%Y');
	SET @IncidentDateTo2 = DATE_ADD(@IncidentDateTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident.IncidentDate >  ', "'" , @IncidentDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident.IncidentDate <=  ', "'",  @IncidentDateTo2  ,"'" );										
ELSE 
IF(@IncidentDateTo = '' AND @IncidentDateFrom !='' ) THEN
	SET @IncidentDateFrom  = STR_TO_DATE(@IncidentDateFrom , '%m/%d/%Y');
	SET @IncidentDateFrom2 = DATE_ADD(@IncidentDateFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident.IncidentDate >=  ',  "'", @IncidentDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident.IncidentDate <  ', "'", @IncidentDateFrom2  ,"'");	
END IF;
END IF;
SET @EstimatedCostTo =  extractvalue(xmlData, '//ImpactEstimatedCostTo');
SET @EstimatedCostFrom =  extractvalue(xmlData, '//ImpactEstimatedCostFrom');
IF( @EstimatedCostTo !='' ) THEN
	SET @queryWhere = CONCAT(@queryWhere,' AND  all_impact_types.EstimatedCost  BETWEEN ', @EstimatedCostFrom, ' and ', @EstimatedCostTo);
ELSE 
	IF( @EstimatedCostFrom !=''  and @EstimatedCostFrom != 'NULL')	 THEN
set  @EstimatedCostFrom  = (replace(@EstimatedCostFrom, '&lt;', '<'));
set  @EstimatedCostFrom  = (replace(@EstimatedCostFrom, '&gt;', '>'));
		SET @queryWhere = CONCAT(@queryWhere,' AND  all_impact_types.EstimatedCost  ', @EstimatedCostFrom);
	END IF;
END IF;
SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );
-- select @query;
SET @querycount =  CONCAT( 'SELECT count(*) into @cnt from  (', @query, ' ) t');
PREPARE stmt1 FROM @querycount;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
SET @selectquery = CONCAT (@selectquery,', ', @cnt, ' as Count ');
SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );
IF (@index  = 'incident.Location1Id' 		or @index  = 'Location1Id') 		then set @index= 'location1.Location1Name'; end if; 
IF (@index  = 'incident.Location2Id' 		or @index  = 'Location2Id') 		then set @index= 'location2.Location2Name'; end if;  
IF (@index  = 'incident.Location3Id' 		or @index  = 'Location3Id')		 	then set @index= 'location3.Location3Name'; end if; 
IF (@index  = 'incident.Location4Id' 		or @index  = 'Location4Id') 		then set @index= 'location4.Location4Name'; end if; 
IF (@index  = 'incident.OperationTypeId' 	or @index  = 'OperationTypeId') 	then set @index= 'operation_type.OperationTypeName'; end if;  
IF (@index  = 'incident.RiskOfRecurrenceId' or @index  = 'RiskOfRecurrenceId') 	then set @index= 'risk_of_recurrence.RiskOfRecurrenceName'; end if;  
IF (@index  = 'incident.IncidentSeverityId' or @index  = 'IncidentSeverityId') 	then set @index= 'incident_severity.IncidentSeverityName'; end if;  
IF (@index  = 'incident.InvStatusId' 		or @index  = 'InvStatusId') 		then set@index='inv_status.InvStatusName'; end if;
IF(@index  = 'IncidentId'  or @index  = 'IncidentDate'  or @index  = 'IncidentHour'  or @index  = 'IncidentMinute'  or @index  = 'IsEmerRP'  or @inde  = 'RepName'  or @index  = 'RepEmail'  or @index  = 'RepPosition'  or @index  = 'RepCompany'  or @index  = 'RepPrimaryPhone'  or @index  = 'RepAlternatePhone'  or @index  = 'OtherLocation'  or @index  = 'OperationTypeId'  or @index  = 'EventSequence'  or @index  = 'EnvConditionNote'  or @index  = 'IncDescription'  or @index  = 'EnergyFormNote'  or @index  = 'SubStorardActionNote'  or @index  = 'SubStorardConditionNote'  or @index  = 'UnderLyingCauseNote'  or @index  = 'InvestigationDate'  or @index  = 'InvestigatorName1'  or @index  = 'InvestigatorName2'  or @index  = 'InvestigatorName3'  or @index  = 'InvSummary'  or @index  = 'FollowUpNote'  or @index  = 'ResponseCost'  or @index  = 'RepairCost'  or @index  = 'InsuranceCost'  or @index  = 'WCBCost'  or @index  = 'OtherCost'  or @index  = 'TotalCost'  or @index  = 'SourceDetails'  or @index  = 'RootCauseNote'  or @index  = 'SignOffInvestigatorName'  or @index  = 'SignOffDate'  or @index  = 'IncidentNumber' ) then
	SET @index=  CONCAT('incident.' , @index);
END IF;
-- if(@index ='CreatorName') then	set @index ='CreatorId'; end if;
-- if(@index ='UpdatedByName') then	set @index ='UpdatedByName'; end if;
SET @query = CONCAT(@query, ' order by ', @index,'  ', @sortOrder);
if( @Export ="false") then
SET @page = (@page - 1) * @limit;
SET @query = CONCAT(@query, ' LIMIT ', @limit ,' OFFSET ',  @page);
end if;
-- select @query;
PREPARE stmt1 FROM @query;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
END;
