CREATE PROCEDURE ABCanTrackV2.`_EmailGrid`()
  BEGIN
SELECT 
*
FROM 
(    
	SELECT 
        `eto`.`EmailToId` AS `EmailToId`,
        `eto`.`GroupId` AS `GroupId`,
        `eto`.`EmployeeId` AS `EmployeeId`,
        CONCAT(`e`.`FirstName`, ' ', `e`.`LastName`) AS `EmployeeName`,
        `e`.`Position` AS `Position`,
        `g`.`GroupName` AS `GroupName`,
        GROUP_CONCAT(DISTINCT `et`.`EmailTypeName`
            SEPARATOR ', ') AS `EmailTypeName`,
        `eto`.`OrgId` AS `OrgId`,
        GETASSIGNNOTIFICATIONSFUN(`eto`.`EmployeeId`,
                `eto`.`GroupId`,
                `eto`.`TableName`,
                `eto`.`OrgId`) AS `AssignedNotifications`,
        NULL AS `DaysStart`,
        NULL AS `DaysFreq`
    FROM
        (((`email_to` `eto`
        LEFT JOIN `employee` `e` ON ((`eto`.`EmployeeId` = `e`.`EmployeeId`)))
        JOIN `email_type` `et` ON ((`et`.`EmailTypeId` = `eto`.`EmailTypeId`)))
        LEFT JOIN `group` `g` ON ((`g`.`GroupId` = `eto`.`GroupId`)))
    GROUP BY `eto`.`EmployeeId` , `eto`.`GroupId` 
    UNION ALL SELECT 
        `etoesc`.`EmailToEscId` AS `EmailToId`,
        `etoesc`.`GroupId` AS `GroupId`,
        `etoesc`.`EmployeeId` AS `EmployeeId`,
        CONCAT(`e`.`FirstName`, ' ', `e`.`LastName`) AS `EmployeeName`,
        `e`.`Position` AS `Position`,
        `g`.`GroupName` AS `GroupName`,
        NULL AS `EmailTypeName`,
        `etoesc`.`OrgId` AS `OrgId`,
        GETASSIGNNOTIFICATIONSFUN(`etoesc`.`EmployeeId`,
                `etoesc`.`GroupId`,
                `etoesc`.`TableName`,
                `etoesc`.`OrgId`) AS `AssignedNotifications`,
        GROUP_CONCAT(`etoesc`.`DaysStart`
            SEPARATOR ' ; ') AS `DaysStart`,
        GROUP_CONCAT(`etoesc`.`DaysFreq`
            SEPARATOR ' ; ') AS `DaysFreq`
    FROM
        ((`email_to_esc` `etoesc`
        LEFT JOIN `employee` `e` ON ((`etoesc`.`EmployeeId` = `e`.`EmployeeId`)))
        LEFT JOIN `group` `g` ON ((`g`.`GroupId` = `etoesc`.`GroupId`)))
    GROUP BY `etoesc`.`EmployeeId` , `etoesc`.`GroupId`
    ) EMAILT;
END;
