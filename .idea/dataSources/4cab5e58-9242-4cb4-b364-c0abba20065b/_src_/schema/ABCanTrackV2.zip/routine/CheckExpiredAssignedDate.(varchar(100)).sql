CREATE FUNCTION ABCanTrackV2.CheckExpiredAssignedDate(`$CorrectiveActionId` VARCHAR(100))
  RETURNS VARCHAR(255)
  BEGIN
DECLARE $ret varchar(255) ; 
	DECLARE $OriginalCorrectiveActionId varchar(100);    
    DECLARE $SentDate DATETIME;
 
	SET $OriginalCorrectiveActionId  = (SELECT OriginalCorrectiveActionId FROM hist_corrective_action hc
		join hist_incident hi on hi.HistIncidentId= hc.HistIncidentId 
        WHERE CorrectiveActionId = $CorrectiveActionId   order by VersionNumber desc limit 1);
        
        
    SET $SentDate = ( SELECT MAX(SentDate) From email_log el
	inner join corr_act_email cae	on el.EmailLogId = cae.EmailLogId
	where HistCorrectiveActionId in (SELECT HistCorrectiveActionId FROM hist_corrective_action WHERE OriginalCorrectiveActionId = $OriginalCorrectiveActionId)
	and el.EmailTypeId = (SELECT EmailTypeId FROM email_type 
     join organization o on o.LanguageId = email_type.LanguageId
     WHERE EmailTypeCode ='ExpiredCorrectiveActionAssignment' and OrgId= el.OrgId));
    
	IF $SentDate IS NULL
    THEN
		SET $ret = 'ToDay';
	ELSE
    
		SET $SentDate = DATE_ADD($SentDate, INTERVAL 7 DAY);
		IF $SentDate <= CURRENT_TIMESTAMP()
		THEN
			SET $ret = 'ToDay';
		ELSE
			SET $ret = 'NotToDay';
		END IF;
	END IF;
  RETURN $ret;
END;
