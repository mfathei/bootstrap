CREATE PROCEDURE ABCanTrackV2.DeleteFrom_people_involved_Tables(IN `$IncidentId` VARCHAR(100))
  BEGIN
DECLARE $OrgId varchar(100);
DECLARE fetch_status int default 0;
DECLARE $PeopleInvolvedId varchar(100);
DECLARE incident_cursor CURSOR FOR 
									select PeopleInvolvedId from people_involved where incidentid = $IncidentId;
DECLARE CONTINUE HANDLER FOR NOT FOUND SET fetch_status = 100;
Open Incident_cursor;
FETCH NEXT FROM incident_cursor 
		INTO $PeopleInvolvedId;
WHILE fetch_status = 0
			do
delete from have_certificate where PeopleInvolvedId = $PeopleInvolvedId;
FETCH NEXT FROM incident_cursor 
			INTO $PeopleInvolvedId;
		END while;
	CLOSE incident_cursor;
delete from people_involved  where IncidentId = $IncidentId;
END;
