CREATE PROCEDURE ABCanTrackV2.GetAssignNotifications_old(IN xmlData TEXT)
  BEGIN
SET @Orgid = extractvalue(xmlData, '//OrgId');
SET @page = extractvalue(xmlData, '//page');
SET @limit = extractvalue(xmlData, '//limit');
SET @sortOrder =  extractvalue(xmlData, '//sortOrder');
SET @index =  extractvalue(xmlData, '//index');
SET @Export =  extractvalue(xmlData, '//Export');
set @selectquery1 ='    select 
        `eto`.`EmailToId` AS `EmailToId`,
        `eto`.`GroupId` AS `GroupId`,
        `eto`.`EmployeeId` AS `EmployeeId`,
        concat(`e`.`FirstName`,  '  ' , `e`.`LastName`) AS `EmployeeName`,
        `e`.`Position` AS `Position`,
        `g`.`GroupName` AS `GroupName`,
        group_concat(distinct `et`.`EmailTypeName`
            separator ', ') AS `EmailTypeName`,
        `eto`.`OrgId` AS `OrgId`,
        GETASSIGNNOTIFICATIONSFUN(`eto`.`EmployeeId`,
                `eto`.`GroupId`,
                `eto`.`TableName`,
                `eto`.`OrgId`) AS `AssignedNotifications`,
        NULL AS `DaysStart`,
        NULL AS `DaysFreq`,
        NULL AS `DaysStartInc`,
        NULL AS `DaysFreqInc`
    ';
                
set @selectquery2 ='   UNION ALL SELECT
        `etoesc`.`EmailToEscId` AS `EmailToId`,
        `etoesc`.`GroupId` AS `GroupId`,
        `etoesc`.`EmployeeId` AS `EmployeeId`,
        concat(`e`.`FirstName`, '  ' , `e`.`LastName`) AS `EmployeeName`,
        `e`.`Position` AS `Position`,
        `g`.`GroupName` AS `GroupName`,
        NULL AS `EmailTypeName`,
        `etoesc`.`OrgId` AS `OrgId`,
        NULL AS `AssignedNotifications`,
        email_to_fun(`etoesc`.`OrgId`,
                `etoesc`.`GroupId`,
                `etoesc`.`EmployeeId`,
                1,
                'corrective_action') AS `DaysStart`,
        email_to_fun(`etoesc`.`OrgId`,
                `etoesc`.`GroupId`,
                `etoesc`.`EmployeeId`,
                2,
                'corrective_action') AS `DaysFreq`,
        email_to_fun(`etoesc`.`OrgId`,
                `etoesc`.`GroupId`,
                `etoesc`.`EmployeeId`,
                1,
                'incident') AS `DaysStartInc`,
        email_to_fun(`etoesc`.`OrgId`,
                `etoesc`.`GroupId`,
                `etoesc`.`EmployeeId`,
                2,
                'incident') AS `DaysFreqInc`
    ';
-- SELECT @selectquery1, @selectquery2;
set @queryFrom1 = CONCAT('    from
        ((((`email_to` `eto`
        left join `email_to_esc` `etoesc` ON (((`eto`.`OrgId` = `etoesc`.`OrgId`)
            and (`eto`.`EmployeeId` = `etoesc`.`EmployeeId`)
            and (`eto`.`GroupId` = `etoesc`.`GroupId`))))
        left join `employee` `e` ON ((`eto`.`EmployeeId` = `e`.`EmployeeId`)))
        join `email_type` `et` ON ((`et`.`EmailTypeId` = `eto`.`EmailTypeId`)))
        left join `group` `g` ON ((`g`.`GroupId` = `eto`.`GroupId`)))
where eto.orgid = "', @Orgid,'" 
GROUP BY `eto`.`EmployeeId` , `eto`.`GroupId`
');
-- select  @queryFrom1;
set @queryFrom2 = CONCAT('
 from
        (((`email_to_esc` `etoesc`
        left join `email_to` `eto` ON (((`eto`.`OrgId` = `etoesc`.`OrgId`)
            and (`eto`.`EmployeeId` = `etoesc`.`EmployeeId`)
            and (`eto`.`GroupId` = `etoesc`.`GroupId`))))
        left join `employee` `e` ON ((`etoesc`.`EmployeeId` = `e`.`EmployeeId`)))
        left join `group` `g` ON ((`g`.`GroupId` = `etoesc`.`GroupId`)))
where etoesc.orgid = "', @Orgid,'"
GROUP BY `etoesc`.`EmployeeId` , `etoesc`.`GroupId`');
-- select  @queryFrom2 ;
-- select @selectquery;
SET @queryWhere = ' where 1= 1 ';
-- SET @queryWhere = CONCAT(@queryWhere,' and email_to_view.OrgId =   "', @Orgid,'" ');
SET @queryFrom1 =  CONCAT(@queryFrom1,' having  1 = 1 ' );
SET @queryFrom2 = CONCAT(@queryFrom2,' having  1 = 1 ' );
SET @myArrayOfValue = 'EmailToId,EmployeeName,Position,GroupName,EmailTypeName,AssignedNotifications,LastNotificationSent,DaysStart,DaysFreq,DaysStartInc,DaysFreqInc,';
SET @Postition = LOCATE(',', @myArrayOfValue);
WHILE ( @Postition > 0 ) DO
 SET @STR = SUBSTRING(@myArrayOfValue, 1, @Postition-1);
 SET @myArrayOfValue = SUBSTRING(@myArrayOfValue, @Postition + 1);
 SET @Col =  extractvalue(xmlData, CONCAT('//',@STR));
 IF (@Col != '' AND @Col !='NULL') THEN
  -- SET @queryWhere = CONCAT(@queryWhere,CONCAT(' AND    ',@STR,' like '"'%", @Col ,"%'")); 
    SET @queryFrom2 = CONCAT(@queryFrom2,CONCAT(' AND    ',@STR,' like '"'%", @Col ,"%'")); 
      SET @queryFrom1 = CONCAT(@queryFrom1,CONCAT(' AND    ',@STR,' like '"'%", @Col ,"%'")); 
      
 END IF;
 
 SET @Postition = LOCATE(',', @myArrayOfValue);
END WHILE;
set  @selectquery=CONCAT(@selectquery1, @queryFrom1, @selectquery2, @queryFrom2);
SET @querygroup = " group by EmployeeId, GroupId ";
SET @query = CONCAT( @selectquery);
SET @querycount =  CONCAT( 'SELECT count(*) into @cnt from  (', @query, ' ) t');
PREPARE stmt1 FROM @querycount;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
	
-- SET @selectquery = CONCAT (@selectquery,', ', @cnt, ' as Count ');
SET @selectquery1 = CONCAT (@selectquery1,', ', @cnt, ' as Count ');
SET @selectquery2 = CONCAT (@selectquery2,', ', @cnt, ' as Count ');
set  @selectquery=CONCAT(@selectquery1, @queryFrom1, @selectquery2, @queryFrom2);
SET @query = CONCAT( @selectquery);
if( @index = 'Order') then set  @index = '`Order`';  end if;
SET @query = CONCAT(@query, ' order by ', @index,'  ', @sortOrder);
if( @Export ="false") then
SET @page = (@page - 1) * @limit;
SET @query = CONCAT(@query, ' LIMIT ', @limit ,' OFFSET ',  @page);
end if;
-- select  @query;
PREPARE stmt1 FROM @query;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
END;
