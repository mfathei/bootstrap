CREATE PROCEDURE ABCanTrackV2.AddLookupValuesToAllOrg()
  BEGIN
DECLARE $max, $min, $OrgId varchar(100);

set $min = (select min(orgid) from organization);
set $max = (select max(orgid) from organization);
OrgLoop: while $min <= $max
do
IF $min <> 'cs4sql-a592668d-dc76-11e4-b362-5254000a52fa'
THEN 
	INSERT INTO `ABCanTrackV2`.`sp_rel_agency`
	(
		`SpRelAgencyId`,
		`SpRelAgencyName`,
		`OrgId`,
		`Order`,
		`LastUpdateDate`,
		`EditingBy`,
		`Hide`
	)
	SELECT 
		`SpRelAgencyId`,
		`SpRelAgencyName`,
		$min,
		`Order`,
		`LastUpdateDate`,
		`EditingBy`,
		`Hide`
	FROM `ABCanTrackV2`.`sp_rel_agency`
	WHERE `OrgId` IS NULL
	;
END IF;

if 
$min = $max
then 
leave OrgLoop;
else
set $min = (select min(orgid) from organization where OrgId > $min);
End if;
end while;
END;
