CREATE FUNCTION ABCanTrackV2.getImpactDescription3(`$SpillReleaseId`         VARCHAR(100),
                                                   `$OriginalSpillReleaseId` VARCHAR(100))
  RETURNS TEXT
  BEGIN
IF $OriginalSpillReleaseId is null   or $OriginalSpillReleaseId  =''   then
	SET $OriginalSpillReleaseId = $SpillReleaseId ;
END IF;
SET SESSION group_concat_max_len = 10000;
SELECT (GROUP_CONCAT(DATE_FORMAT(UpdatedDate, '%b %d %Y') ,' ', '(',  CONCAT(firstname ,' ', lastname) ,')',': <pr>', ImpactDescription separator '<br><br>' ) ) AS ImpactDescription  
 INTO @newImpactDescription3 
 FROM(
 SELECT UpdatedDate, ImpactDescription, firstname,lastname FROM hist_spill_release hi 
JOIN employee e ON e.EmployeeId = hi.UpdatedbyId
 WHERE OriginalSpillReleaseId = $OriginalSpillReleaseId  
ORDER BY UpdatedDate asc  ) temp ; 
RETURN @newImpactDescription3;
END;
