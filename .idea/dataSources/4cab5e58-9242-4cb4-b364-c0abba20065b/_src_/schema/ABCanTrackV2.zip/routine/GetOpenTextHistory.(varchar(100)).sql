CREATE PROCEDURE ABCanTrackV2.GetOpenTextHistory(IN `$IncidentId` VARCHAR(100))
  BEGIN
SELECT  DATE_FORMAT(UpdatedDate, '%b %d %Y') as UpdatedDate, 
		concat (FirstName,'  ',LastName) as UpdatedBy,  UpdatedDate as UpdatedDate2,
		IncDescription,
		EventSequence,
		EnvConditionNote,
		EnergyFormNote,
		SubStandardActionNote ,
		SubStandardConditionNote,
		UnderLyingCauseNote,
		InvSummary,
		FollowUpNote,
		SourceDetails,
		RootCauseNote
	   from hist_incident
	   inner join employee on employee.EmployeeId = hist_incident.UpdatedById
	   where IncidentId = $IncidentId   order by UpdatedDate2 asc ;
END;
