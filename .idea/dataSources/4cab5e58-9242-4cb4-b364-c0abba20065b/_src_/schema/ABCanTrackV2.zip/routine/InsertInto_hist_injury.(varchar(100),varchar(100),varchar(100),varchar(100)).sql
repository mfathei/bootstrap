CREATE PROCEDURE ABCanTrackV2.InsertInto_hist_injury(IN `$InjuryId`         VARCHAR(100),
                                                     IN `$OldInjuryId`      VARCHAR(100),
                                                     IN `$OriginalInjuryId` VARCHAR(100),
                                                     IN `$UpdatedById`      VARCHAR(100))
  BEGIN
/*
DECLARE @BodyAreaName  TEXT ;
DECLARE @InjuryTypeName  TEXT ;
DECLARE @BodyPartName  TEXT ;
DECLARE @PersonalInjuredName  varchar(255) ;
DECLARE @IncidentId  varchar(100) ;
DECLARE @InitialTreatmentName  varchar(255) ;
DECLARE @ContactCodeName  varchar(255) ;
DECLARE @RecordableName  varchar(255) ;
DECLARE @RestrictedWorkName  varchar(255) ;
DECLARE @LostTimeStart  DATETIME ;
DECLARE @LostTimeEnd  DATETIME ;
DECLARE @AdjustmentDays  INT ;
DECLARE @TotalDaysOff  INT ;
DECLARE @InjuryDescription TEXT  ;
DECLARE @OldInjuryDescription TEXT ;
DECLARE @ImpactTypeName varchar(255);
DECLARE @ImpactSubTypeName  varchar(255) ;
DECLARE @ContactAgencyName  varchar(255) ;
DECLARE @ExtAgencyName  TEXT ;
DECLARE @IntEmployeeName1  varchar(255) ;
DECLARE @IntEmployeeDept1  varchar(255) ;
DECLARE @IntEmployeeName2  varchar(255) ;
DECLARE @IntEmployeeDept2  varchar(255) ;
DECLARE @IntEmployeeName3  varchar(255) ;
DECLARE @IntEmployeeDept3  varchar(255) ;
DECLARE @CustomOpenTxt  TEXT ;
DECLARE @OldCustomOpenTxt TEXT ; 
DECLARE @PrimRespondName  varchar(255) ;
DECLARE @ImpactDescription  TEXT ;
DECLARE @OldImpactDescription  TEXT ;
DECLARE @EstimatedCost  DECIMAL(10,2) ;
DECLARE @HistoryOperationId  varchar(100) ;
DECLARE @UpdatedDate  DATETIME ;
DECLARE @UpdatedByName varchar(255) ;
DECLARE @HistIncidentId varchar(100);
DECLARE @VersionNumber INT;
*/
SET @UpdatedByName = (  select concat(firstname ,' ', lastname) from employee where employeeid = $UpdatedById ) ;
SET @BodyAreaName  = ( select group_concat(BodyAreaName separator ' ;| ') from body_area where BodyAreaId in (select BodyAreaId from body_area_injury where injuryid = $InjuryId) );
SET @InjuryTypeName  = ( select group_concat(InjuryTypeName separator ' ;| ') from injury_type where injurytypeid in (select injurytypeid from injury_type_injury where injuryid = $InjuryId)  );
SET @BodyPartName  = ( select group_concat(BodyPartName separator ' ;| ') from  body_part where bodypartid in (select bodypartid from body_part_injury where injuryid = $InjuryId) );
SET @PersonalInjuredName  = ( select PersonalInjuredName from  injury where injuryid = $InjuryId );
SET @IncidentId  = ( select incidentid from injury where injuryid = $InjuryId  );
SET @InitialTreatmentName  = ( select InitialTreatmentName from initial_treatment where InitialTreatmentid = (select InitialTreatmentid from injury where injuryid = $InjuryId)  );
SET @ContactCodeName  = ( select ContactCodeName from contact_code where ContactCodeId = (select ContactCodeId from injury where injuryid = $InjuryId) );
SET @RecordableName  = ( select RecordableName from injury_recordable where RecordableId = (select RecordableId from injury where injuryid = $InjuryId) );
SET @RestrictedWorkName  = ( select RestrictedWorkName from restricted_work where RestrictedWorkid = (select RestrictedWorkid from injury where injuryid = $InjuryId)  );
SET @LostTimeStart  = ( select losttimestart from injury where injuryid = $InjuryId  );
SET @LostTimeEnd  = ( select LostTimeEnd from injury where injuryid = $InjuryId  );
SET @AdjustmentDays  = ( select AdjustmentDays from injury where injuryid = $InjuryId  );
SET @TotalDaysOff  = ( select TotalDaysOff from injury where injuryid = $InjuryId  );
SET @InjuryDescription  = ( select InjuryDescription from injury where injuryid = $InjuryId  );
if($OldInjuryId is null) then
SET  @OldInjuryDescription =( select concat(DATE_FORMAT(curdate(), '%b %d %Y'),' ', '(',@UpdatedByName,')',': ', ifnull((@InjuryDescription), '') ));
set $OriginalInjuryId = $InjuryId ;
Else
SET @OldInjuryDescription = ( select concat(DATE_FORMAT(curdate(), '%b %d %Y'),' ', '(',@UpdatedByName,')',': ', ifnull((@InjuryDescription), '') ,' <br><br> ', ifnull((OldInjuryDescription), '')) from hist_injury where InjuryId = $OldInjuryId limit 1);
END If;
if($OriginalInjuryId is null or $OriginalInjuryId = '') then
SET  $OriginalInjuryId=	$InjuryId ;
END IF;
SET @ImpactTypeName = (select ImpactTypeName from impact_type where impacttypeid = (select impacttypeid from impact_sub_type where impactsubTypeid = (select impactsubtypeid from injury where injuryid = $InjuryId)));
SET @ImpactSubTypeName  = ( select impactsubtypename from impact_sub_type where impactsubtypeid = (select impactsubtypeid from injury where injuryid = $InjuryId)  );
SET @ContactAgencyName  = ( select ContactAgencyName from contact_agency where ContactAgencyId = (select ContactAgencyId from injury where injuryid = $InjuryId)  );
SET @ExtAgencyName = ( select group_concat(ExtAgencyName separator' ;| ') from external_agency where ExtAgencyId in (select ExtAgencyId from impacts_ext_agency where injuryid = $InjuryId));
SET @IntEmployeeName1 = (  select IntEmployeeName1 from injury where injuryid = $InjuryId );
SET @IntEmployeeDept1 = (  select IntEmployeeDept1 from injury where injuryid = $InjuryId );
SET @IntEmployeeName2 = (  select IntEmployeeName2 from injury where injuryid = $InjuryId );
SET @IntEmployeeDept2 = (  select IntEmployeeDept2 from injury where injuryid = $InjuryId );
SET @IntEmployeeName3 = (  select IntEmployeeName3 from injury where injuryid = $InjuryId );
SET @IntEmployeeDept3 = (  select IntEmployeeDept3 from injury where injuryid = $InjuryId );
SET @PrimRespondName = ( select primrespondname from injury where injuryid = $InjuryId  );
SET @EstimatedCost = (  select estimatedcost from injury where injuryid = $InjuryId );
SET @ImpactDescription = (  select Description from injury where injuryid = $InjuryId );
if($OldInjuryId is null) then
SET  @OldImpactDescription =( select concat(DATE_FORMAT(curdate(), '%b %d %Y'),' ', '(',@UpdatedByName,')',': ', ifnull((@ImpactDescription), '') ));
Else
SET @OldImpactDescription = ( select concat(DATE_FORMAT(curdate(), '%b %d %Y'),' ', '(',@UpdatedByName,')',': ', ifnull((@ImpactDescription), '') ,' <br><br> ', ifnull((OldImpactDescription), ''))  from hist_injury where InjuryId = $OldInjuryId limit 1);
END IF;
SET @VersionNumber = (SELECT MAX(VersionNumber) FROM hist_incident WHERE IncidentId = @IncidentId);
SET @HistIncidentId = (SELECT HistIncidentId FROM hist_incident WHERE IncidentId = @IncidentId AND VersionNumber = @VersionNumber);
SET  @HistoryOperationId = (SELECT HistoryOperationId FROM hist_incident WHERE HistIncidentId = @HistIncidentId);
-- SET $UpdatedById = (SELECT UpdatedById FROM hist_incident WHERE HistIncidentId = @HistIncidentId);
SET @UpdatedDate = current_timestamp();
INSERT INTO `hist_injury`
(
`HistInjuryId`,
`InjuryId`,
`BodyAreaName`,
`InjuryTypeName`,
`BodyPartName`,
`PersonalInjuredName`,
`IncidentId`,
`InitialTreatmentName`,
`ContactCodeName`,
`RecordableName`,
`RestrictedWorkName`,
`LostTimeStart`,
`LostTimeEnd`,
`AdjustmentDays`,
`TotalDaysOff`,
`InjuryDescription`,
`OldInjuryDescription`,
`ImpactTypeName`,
`ImpactSubTypeName`,
`ContactAgencyName`,
`ExtAgencyName`,
`IntEmployeeName1`,
`IntEmployeeDept1`,
`IntEmployeeName2`,
`IntEmployeeDept2`,
`IntEmployeeName3`,
`IntEmployeeDept3`,
`PrimRespondName`,
`ImpactDescription`,
`OldImpactDescription`,
`EstimatedCost`,
`HistoryOperationId`,
`UpdatedById`,
`UpdatedDate`,
`HistIncidentId`,
`OriginalInjuryId`
)
VALUES
(
MyUUID(),
$InjuryId,
@BodyAreaName,
@InjuryTypeName,
@BodyPartName,
@PersonalInjuredName,
@IncidentId,
@InitialTreatmentName,
@ContactCodeName,
@RecordableName,
@RestrictedWorkName,
@LostTimeStart,
@LostTimeEnd,
@AdjustmentDays,
@TotalDaysOff,
@InjuryDescription,
@OldInjuryDescription,
@ImpactTypeName,
@ImpactSubTypeName,
@ContactAgencyName,
@ExtAgencyName,
@IntEmployeeName1,
@IntEmployeeDept1,
@IntEmployeeName2,
@IntEmployeeDept2,
@IntEmployeeName3,
@IntEmployeeDept3,
@PrimRespondName,
@ImpactDescription,
@OldImpactDescription,
@EstimatedCost,
@HistoryOperationId,
$UpdatedById,
@UpdatedDate,
@HistIncidentId,
$OriginalInjuryId 
);
END;
