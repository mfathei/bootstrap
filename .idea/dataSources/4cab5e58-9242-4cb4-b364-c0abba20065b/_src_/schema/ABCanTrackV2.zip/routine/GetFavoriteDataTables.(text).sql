CREATE PROCEDURE ABCanTrackV2.GetFavoriteDataTables(IN xmlData TEXT)
  BEGIN
SET @OrgId = extractvalue(xmlData, '//OrgId');
SET @page = extractvalue(xmlData, '//page');
SET @limit = extractvalue(xmlData, '//limit');
SET @sortOrder =  extractvalue(xmlData, '//sortOrder');
SET @index =  extractvalue(xmlData, '//index');
SET @CreatorId = extractvalue(xmlData, '//CreatorId');
SET @Export =  extractvalue(xmlData, '//Export');
set @selectquery ="SELECT
					FavoriteTableId,
					FavoriteTableName,
					FavoriteTypeName,
					StartDate,
					EndDate,
					FieldLabel,
					SortOrder,
					NoOfRows,
					IsShared  ";
set @queryFrom = " from favorite_table
inner join favorite_type on favorite_type.FavoriteTypeId = favorite_table.FavoriteTypeId
inner join  field on field.FieldId = favorite_table.OrderById
inner join org_field on org_field.FieldId = field.FieldId and org_field.OrgId = favorite_table.OrgId  ";
SET @queryWhere = ' where 1= 1 ';
IF (@OrgId != '' AND @OrgId !='0') THEN
	SET @queryWhere = CONCAT(@queryWhere,' and favorite_table.OrgId =   "', @Orgid,'" ');
END IF;
SET @queryWhere = CONCAT(@queryWhere,' AND IsDefault =  0');
SET @queryWhere = CONCAT(@queryWhere,' AND EmployeeId = "', @CreatorId,'"');
/* search part*/
 SET@myArrayOfValue='FavoriteTableName,FavoriteTypeName,StartDate,EndDate,FieldLabel,SortOrder,NoOfRows,IsShared,';
 SET @Postition = LOCATE(',', @myArrayOfValue);
WHILE ( @Postition > 0 ) DO
 SET @STR = SUBSTRING(@myArrayOfValue, 1, @Postition-1);
 SET @myArrayOfValue = SUBSTRING(@myArrayOfValue, @Postition + 1);
 SET @Col =  extractvalue(xmlData, CONCAT('//',@STR));
 IF (@Col != '' AND @Col !='NULL') THEN
 SET @queryWhere = CONCAT(@queryWhere,CONCAT(' AND ',@STR,' like '"'%", @Col ,"%'" )); 
 END IF;
 
 SET @Postition = LOCATE(',', @myArrayOfValue);
END WHILE;
SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );
-- select @query;
SET @querycount =  CONCAT( 'SELECT count(*) into @cnt from  (', @query, ' ) t');
PREPARE stmt1 FROM @querycount;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
SET @selectquery = CONCAT (@selectquery,', ', @cnt, ' as Count ');
SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );
SET @query = CONCAT(@query, ' order by ', @index,'  ', @sortOrder);
if( @Export ="false") then
SET @page = (@page - 1) * @limit;
SET @query = CONCAT(@query, ' LIMIT ', @limit ,' OFFSET ',  @page);
end if;
-- select @query;
PREPARE stmt1 FROM @query;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
END;
