CREATE PROCEDURE ABCanTrackV2.CheckExpDate(IN `$OrgId`     VARCHAR(100), IN `$EmployeeId` VARCHAR(100),
                                           IN `$TableName` VARCHAR(255))
  BEGIN
DECLARE $GroupId, $EmailToEscId varchar(100);
SET $GroupId = (select GroupId from emp_group where EmployeeId = $EmployeeId and GroupId in (select GroupId from `group` where OrgId = $OrgId));
SET $EmailToEscId = (Select EmailToEscId from email_to_esc where OrgId = $OrgId and GroupId = $GroupId);
-- SET $EmailToEscId = (Select EmailToEscId from email_to_esc where OrgId = $OrgId and GroupId = $GroupId and TableName = $TableName);
SET $EmailToEscId = (Select EmailToEscId from email_to_esc where OrgId = $OrgId and EmployeeId = $EmployeeId and TableName = $TableName);
IF $EmailToEscId is not null then 
Select * from email_to_esc where EmailToEscId = $EmailToEscId;
Else
Select * from email_to_esc where OrgId = $OrgId and GroupId = $GroupId and TableName = $TableName;
End If;
END;
