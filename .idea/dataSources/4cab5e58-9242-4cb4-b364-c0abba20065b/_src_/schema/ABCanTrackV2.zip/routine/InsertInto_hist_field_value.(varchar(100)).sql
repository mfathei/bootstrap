CREATE PROCEDURE ABCanTrackV2.InsertInto_hist_field_value(IN `$FieldValueId` VARCHAR(100))
  BEGIN
DECLARE $IncidentId, $UpdatedById, $HistIncidentId, $HistoryOperationId VARCHAR(100);
-- DECLARE @OptionName VARCHAR(255);
DECLARE $VersionNumber INT;
SET $IncidentId = (SELECT IncidentId FROM field_value WHERE FieldValueId = $FieldValueId);
SET $VersionNumber = (SELECT MAX(VersionNumber) FROM hist_incident WHERE IncidentId = $IncidentId);
SET $HistIncidentId = (SELECT HistIncidentId FROM hist_incident WHERE IncidentId = $IncidentId AND VersionNumber = $VersionNumber);
SET $HistoryOperationId = (SELECT HistoryOperationId FROM hist_incident WHERE HistIncidentId = $HistIncidentId);
SET $UpdatedById = (SELECT UpdatedById FROM hist_incident WHERE HistIncidentId = $HistIncidentId);
SET @OptionName = (SELECT OptionName FROM `option` WHERE OptionId = (SELECT OptionId FROM field_value WHERE FieldValueId = $FieldValueId));
INSERT INTO hist_field_value
	(
		`hist_field_value`.`FieldValueId`,
		`hist_field_value`.`FieldId`,
		`hist_field_value`.`IncidentId`,
		`hist_field_value`.`OptionName`,
		`hist_field_value`.`HistIncidentId`,
		`hist_field_value`.`FieldValue`,
		`hist_field_value`.`TableKeyValue`,
		`hist_field_value`.`TableKeyId`,
		`hist_field_value`.`HistoryOperationId`,
		`hist_field_value`.`UpdatedById`
	)
SELECT 
		`field_value`.`FieldValueId`,
		`field_value`.`FieldId`,
		`field_value`.`IncidentId`,
		@OptionName,
		$HistIncidentId,
		`field_value`.`FieldValue`,
		`field_value`.`TableKeyValue`,
		`field_value`.`TableKeyId`,
		$HistoryOperationId,
		$UpdatedById
FROM field_value WHERE FieldValueId = $FieldValueId;
END;
