CREATE PROCEDURE ABCanTrackV2.GetIncidents_Opti(IN xmlData TEXT)
  BEGIN
 DECLARE $ids TEXT;  
DECLARE $FieldId VARCHAR(100); 
SET @OrgId = EXTRACTVALUE(xmlData, '//OrgId');
SET @page = EXTRACTVALUE(xmlData, '//page');
SET @limit = EXTRACTVALUE(xmlData, '//limit');
SET @sortOrder =  EXTRACTVALUE(xmlData, '//sortOrder');
SET @index =  EXTRACTVALUE(xmlData, '//index');
SET @Mine =  EXTRACTVALUE(xmlData, '//Mine');
SET @CreatorId = EXTRACTVALUE(xmlData, '//CreatorId');
SET @Export =  EXTRACTVALUE(xmlData, '//Export');
SET @LanguageCode =  EXTRACTVALUE(xmlData, '//LanguageCode');
SET @lblYes = (SELECT GetItemLabel(@LanguageCode,'isreportableyes'));
SET @lblNo = (SELECT GetItemLabel(@LanguageCode,'isreportableno'));
SET @histinc_thirdparties_joined = NULL ;
SET  @injuryFound= FALSE;
SET  @illnessFound= FALSE;
SET  @spillFound= FALSE;
SET  @vehicleFound= FALSE; 
SET  @trafficFound= FALSE;
  -- set global max_allowed_packet=268435456; -- 256M,
  -- SET @@GLOBAL.wait_timeout=300; -- 5 MIN
SET @selectquery ='
SELECT  
		SQL_CALC_FOUND_ROWS
        `inc`.`IncidentId` AS `IncidentId`,
        `inc`.`IncidentNumber` AS `IncidentNumber`,
         date_format(`inc`.`IncidentDate`, '%m/%d/%Y') AS `IncidentDate`,
        `inc`.`IncidentHour` AS `IncidentHour`,
         `inc`.`IncidentMinute` AS `IncidentMinute`,
        `inc`.`EditingBy` AS `EditingBy`,
        `inc`.`EditingBy` AS `LockedId`   ';
SET @queryFrom = ' 
FROM incident inc 
INNER JOIN hist_incident_vw hinc ON inc.IncidentId = hinc.IncidentId ';
SET @queryWhere = ' where 1= 1 ';
IF (@OrgId != '' AND @OrgId !='0') THEN
	SET @queryWhere = CONCAT(@queryWhere," and inc.OrgId = '", @Orgid,"'");
END IF;
SET @querygroup = ' group by inc.IncidentId ';
SET @queryhave = ' HAVING 1 = 1    ';
SET $ids = EXTRACTVALUE(xmlData, '//FieldNamesIds');
SET @Postition = LOCATE(',', $ids);
WHILE ( @Postition > 0 ) DO
	SET @STR = SUBSTRING($ids, 1, @Postition-1);
	SET $ids  = SUBSTRING($ids, @Postition + 1);
	SET  @STR = TRIM(@STR);
    SET $FieldId = (SELECT FieldId FROM ABCanTrackV2.field WHERE FieldName = @STR AND Orgid=@OrgId );
       
   IF ((SELECT INSTR( @STR , 'calendar') > 0)) THEN 
		SET @selectquery = CONCAT(@selectquery , ', (select group_concat( distinct  FieldValue  separator ', ' ) from field_value tbl1
				where tbl1.incidentid = inc.incidentid and tbl1.FieldId ="', $FieldId,'"   limit 1) as `',@STR,'`');	
	ELSEIF ((SELECT INSTR( @STR , 'textbox') > 0)) THEN 
		SET @selectquery = CONCAT(@selectquery , ',    (select  group_concat( distinct  FieldValue  separator ', ' )  from field_value tbl1
			where tbl1.incidentid = inc.incidentid and tbl1.FieldId ="', $FieldId,'"   limit 1) as `',@STR,'`');	
            
	ELSEIF ((SELECT INSTR( @STR , 'textarea') > 0)) THEN 
		SET @selectquery = CONCAT(@selectquery , ',    (select  group_concat( distinct  FieldValue  separator ', ' )  from field_value tbl1
				where tbl1.incidentid = inc.incidentid and tbl1.FieldId ="', $FieldId,'"   limit 1) as `',@STR,'`');	
	ELSE    
		SET @selectquery = CONCAT(@selectquery , ',   (select group_concat(  distinct  trim(tbl3.OptionName) separator ', ') from field_value tbl1
		inner join `option` tbl3
		on tbl1.OptionId = tbl3.OptionId
		where tbl1.incidentid = inc.incidentid and tbl1.FieldId ="', $FieldId,'") as `',@STR,'`');	
	
    END IF;  
    
	SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//',@STR));
	IF (@Col != '' AND @Col !='NULL') THEN	 
	SET @queryhave = CONCAT(@queryhave,'  and  ', @STR ,' like '"'%", @Col ,"%'" );
	END IF; 	
        
	SET @Postition = LOCATE(',', $ids);
END WHILE;
IF (@Mine = 'true') THEN
	SET @queryWhere = CONCAT(@queryWhere," AND inc.CreatorId =  '",@CreatorId,"'"  );
END IF;
IF( EXTRACTVALUE(xmlData, 'count(//IncidentMinute)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', `inc`.`IncidentMinute` AS `IncidentMinute` ');
END IF;
IF( EXTRACTVALUE(xmlData, 'count(//IsEmerRP)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', CASE `inc`.`IsEmerRP`   WHEN '0' THEN '',@lblNo,'' WHEN '1' THEN '', @lblYes,'' END AS `IsEmerRP` ');
END IF;
IF( EXTRACTVALUE(xmlData, 'count(//RepName)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', `inc`.`RepName` AS `RepName` ');
END IF;
IF( EXTRACTVALUE(xmlData, 'count(//RepEmail)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', `inc`.`RepEmail` AS `RepEmail` ');
END IF;
IF( EXTRACTVALUE(xmlData, 'count(//RepPosition)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', `inc`.`RepPosition` AS `RepPosition` ');
END IF;
IF( EXTRACTVALUE(xmlData, 'count(//RepCompany)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', `inc`.`RepCompany` AS `RepCompany` ');
END IF;
IF( EXTRACTVALUE(xmlData, 'count(//RepPrimaryPhone)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', `inc`.`RepPrimaryPhone` AS `RepPrimaryPhone` ');
END IF;
IF( EXTRACTVALUE(xmlData, 'count(//RepAlternatePhone)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', `inc`.`RepAlternatePhone` AS `RepAlternatePhone` ');
END IF;
IF( EXTRACTVALUE(xmlData, 'count(//OtherLocation)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', `inc`.`OtherLocation` AS `OtherLocation` ');
END IF;
IF( EXTRACTVALUE(xmlData, 'count(//EventSequence)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', `inc`.`EventSequence` AS `EventSequence` ');
END IF;
IF( EXTRACTVALUE(xmlData, 'count(//EnvConditionNote)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', `inc`.`EnvConditionNote` AS `EnvConditionNote` ');
END IF;
IF( EXTRACTVALUE(xmlData, 'count(//IncDescription)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', `inc`.`IncDescription` AS `IncDescription` ');
END IF;
IF( EXTRACTVALUE(xmlData, 'count(//EnergyFormNote)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', `inc`.`EnergyFormNote` AS `EnergyFormNote` ');
END IF;
IF( EXTRACTVALUE(xmlData, 'count(//SubStandardActionNote)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', `inc`.`SubStandardActionNote` AS `SubStandardActionNote` ');
END IF;
IF( EXTRACTVALUE(xmlData, 'count(//SubStandardConditionNote)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', `inc`.`SubStandardConditionNote` AS `SubStandardConditionNote` ');
END IF;
IF( EXTRACTVALUE(xmlData, 'count(//FollowUpNote)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', `inc`.`FollowUpNote` AS `FollowUpNote` ');
END IF;
IF( EXTRACTVALUE(xmlData, 'count(//InvestigationDate)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', date_format(`inc`.`InvestigationDate`, '%m/%d/%Y') AS `InvestigationDate` ');
END IF;
IF( EXTRACTVALUE(xmlData, 'count(//InvestigatorName1)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', `inc`.`InvestigatorName1` AS `InvestigatorName1` ');
END IF;
IF( EXTRACTVALUE(xmlData, 'count(//InvestigatorName2)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', `inc`.`InvestigatorName2` AS `InvestigatorName2` ');
END IF;
IF( EXTRACTVALUE(xmlData, 'count(//InvestigatorName3)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', `inc`.`InvestigatorName3` AS `InvestigatorName3` ');
END IF;
IF( EXTRACTVALUE(xmlData, 'count(//InvSummary)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', `inc`.`InvSummary` AS `InvSummary` ');
END IF;
IF( EXTRACTVALUE(xmlData, 'count(//FollowUpNote)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', `inc`.`FollowUpNote` AS `FollowUpNote` ');
END IF;
IF( EXTRACTVALUE(xmlData, 'count(//ResponseCost)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', `inc`.`ResponseCost` AS `ResponseCost` ');
END IF;
IF( EXTRACTVALUE(xmlData, 'count(//RepairCost)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', `inc`.`RepairCost` AS `RepairCost` ');
END IF;
IF( EXTRACTVALUE(xmlData, 'count(//InsuranceCost)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', `inc`.`InsuranceCost` AS `InsuranceCost` ');
END IF;
IF( EXTRACTVALUE(xmlData, 'count(//WCBCost)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', `inc`.`WCBCost` AS `WCBCost` ');
END IF;
IF( EXTRACTVALUE(xmlData, 'count(//OtherCost)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', `inc`.`OtherCost` AS `OtherCost` ');
END IF;
IF( EXTRACTVALUE(xmlData, 'count(//TotalCost)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', `inc`.`TotalCost` AS `TotalCost` ');
END IF;
IF( EXTRACTVALUE(xmlData, 'count(//SourceDetails)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', `inc`.`SourceDetails` AS `SourceDetails` ');
END IF;
IF( EXTRACTVALUE(xmlData, 'count(//RootCauseNote)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', `inc`.`RootCauseNote` AS `RootCauseNote` ');
END IF;
IF( EXTRACTVALUE(xmlData, 'count(//SignOffInvestigatorName)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', `inc`.`SignOffInvestigatorName` AS `SignOffInvestigatorName` ');
END IF;
IF( EXTRACTVALUE(xmlData, 'count(//SignOffDate)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,',  date_format(`inc`.`SignOffDate`, '%m/%d/%Y') AS `SignOffDate` ');
END IF;
IF( EXTRACTVALUE(xmlData, 'count(//VersionNumber)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', `hinc`.`VersionNumber` AS `VersionNumber` ');
END IF;
IF( EXTRACTVALUE(xmlData, 'count(//UnderLyingCauseNote)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', `inc`.`UnderLyingCauseNote` AS `UnderLyingCauseNote` ');
END IF;
SET @queryWhere = CONCAT(@queryWhere,' AND inc.Hide =  0');
IF( EXTRACTVALUE(xmlData, 'count(//EventTypeId)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', event_type.EventTypeName as EventTypeId ');
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join event_type on inc.EventTypeId = event_type.EventTypeId  ');
END IF;
IF( EXTRACTVALUE(xmlData, 'count(//OperationTypeId)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', operation_type.OperationTypeName as OperationTypeId ');
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join operation_type on inc.OperationTypeId = operation_type.OperationTypeId  ');
END IF;
IF( EXTRACTVALUE(xmlData, 'count(//Location1Id)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', location1.Location1Name as Location1Id ');
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join location1 on inc.Location1Id = location1.Location1Id  ');
END IF;
IF( EXTRACTVALUE(xmlData, 'count(//Location2Id)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', location2.Location2Name as Location2Id ');
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join location2 on inc.Location2Id = location2.Location2Id  ');
END IF;
IF( EXTRACTVALUE(xmlData, 'count(//Location3Id)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', location3.Location3Name as Location3Id ');
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join location3 on inc.Location3Id = location3.Location3Id  ');
END IF;
IF( EXTRACTVALUE(xmlData, 'count(//Location4Id)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', location4.Location4Name as Location4Id ');
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join location4 on inc.Location4Id = location4.Location4Id  ');
END IF;
IF( EXTRACTVALUE(xmlData, 'count(//InvStatusId)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', inv_status.InvStatusName as InvStatusId ');
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join inv_status on inc.InvStatusId = inv_status.InvStatusId  ');
END IF;
IF( EXTRACTVALUE(xmlData, 'count(//RiskOfRecurrenceId)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', risk_of_recurrence.RiskOfRecurrenceName as RiskOfRecurrenceId ');
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join risk_of_recurrence on inc.RiskOfRecurrenceId = risk_of_recurrence.RiskOfRecurrenceId  ');
END IF;
IF( EXTRACTVALUE(xmlData, 'count(//IncidentSeverityId)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', incident_severity.IncidentSeverityName as IncidentSeverityId ');
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join incident_severity on inc.IncidentSeverityId = incident_severity.IncidentSeverityId  ');
END IF;
IF( EXTRACTVALUE(xmlData, 'count(//UpdatedByName)') >0 OR EXTRACTVALUE(xmlData, 'count(//VersionNumber)') >0) THEN
		IF( EXTRACTVALUE(xmlData, 'count(//UpdatedByName)') >0)THEN		
			SET @selectquery = CONCAT(@selectquery,', ', 'CONCAT',' (','empModifier.FirstName,',"'","  '" ,',empModifier.LastName',') ',' as UpdatedByName ');
			SET @queryFrom = CONCAT(@queryFrom,'  inner join employee as empModifier on hinc.UpdatedById = empModifier.EmployeeId  ');
		END IF;
END IF;
IF( EXTRACTVALUE(xmlData, 'count(//CreatorName)') >0 ) THEN
	SET @selectquery = CONCAT(@selectquery,', ', 'CONCAT',' (','empCreator.FirstName,',"'","  '" ,',empCreator.LastName',') ',' as CreatorName ');
	SET @queryFrom = CONCAT(@queryFrom,'    inner join employee as empCreator on inc.CreatorId = empCreator.EmployeeId  ');
END IF;
/*  incident_third_party */
IF( EXTRACTVALUE(xmlData, 'count(//CustomerId)') >0  OR EXTRACTVALUE(xmlData, 'count(//CustomerJobNumber)') >0 OR EXTRACTVALUE(xmlData, 'count(//CustName)') >0 ) THEN
    IF @histinc_thirdparties_joined IS NULL THEN
        SET @queryFrom = CONCAT(@queryFrom,'  
			left join histinc_thirdparties on(hinc.HistIncidentId = histinc_thirdparties.HistIncidentId) ');
	    SET @histinc_thirdparties_joined = 1;
    END IF;
	
	SET @selectquery = CONCAT(@selectquery,', replace(`histinc_thirdparties`.`CustomerName`, ';|',';')  AS `CustomerId`,replace(`histinc_thirdparties`.`CustName`, ';|',';')   AS `CustName`,  replace(`histinc_thirdparties`.`CustomerJobNumber`, ';|',';') AS `CustomerJobNumber`  ');
	
		
	SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','CustomerId'));
	IF (@Col != '' AND @Col !='NULL') THEN	 
		SET @queryWhere = CONCAT(@queryWhere,'  and histinc_thirdparties.`CustomerName`' ,' like '"'%", @Col ,"%'" );
	END IF;
	SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','CustName'));
	IF (@Col != '' AND @Col !='NULL') THEN	 
	SET @queryWhere = CONCAT(@queryWhere,'  and `histinc_thirdparties`.`CustName`' ,' like '"'%", @Col ,"%'" );
	END IF;
    
	SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','CustomerJobNumber'));
	IF (@Col != '' AND @Col !='NULL') THEN	 
		SET @queryWhere = CONCAT(@queryWhere,'  and histinc_thirdparties.`CustomerJobNumber`' ,' like '"'%", @Col ,"%'" );
	END IF; 
	
END IF;	
	
IF(EXTRACTVALUE(xmlData, 'count(//ContractorId)') >0  OR EXTRACTVALUE(xmlData, 'count(//ContractorJobNumber)') >0  OR EXTRACTVALUE(xmlData, 'count(//ContName)') >0) THEN		
    IF @histinc_thirdparties_joined IS NULL THEN
        SET @queryFrom = CONCAT(@queryFrom,'  
			left join histinc_thirdparties on(hinc.HistIncidentId = histinc_thirdparties.HistIncidentId) ');
	    SET @histinc_thirdparties_joined = 1;
    END IF;
	
			
	SET @selectquery = CONCAT(@selectquery,',replace(`histinc_thirdparties`.`ContractorName`, ';|',';')  AS `ContractorId`, replace(`histinc_thirdparties`.`ContName`, ';|',';')  AS `ContName`, replace(`histinc_thirdparties`.`ContractorJobNumber`, ';|',';')  AS  `ContractorJobNumber` ' );
	
	SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','ContractorId'));
	IF (@Col != '' AND @Col !='NULL') THEN	 
		SET @queryWhere = CONCAT(@queryWhere,'  and histinc_thirdparties.`ContractorName`' ,' like '"'%", @Col ,"%'" );
	END IF;
	SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','ContName'));
	IF (@Col != '' AND @Col !='NULL') THEN	 
		SET @queryWhere = CONCAT(@queryWhere,'  and `histinc_thirdparties`.`ContactName`' ,' like '"'%", @Col ,"%'" );
	END IF;
	SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','ContractorJobNumber'));
	IF (@Col != '' AND @Col !='NULL') THEN	 
		SET @queryWhere = CONCAT(@queryWhere,'  and histinc_thirdparties.`ContractorJobNumber`' ,' like '"'%", @Col ,"%'" );
	END IF;
	
END IF;
/*
IF( ExtractValue(xmlData, 'count(//CustomerId)') >0  or ExtractValue(xmlData, 'count(//CustomerJobNumber)') >0 or ExtractValue(xmlData, 'count(//CustName)') >0
or ExtractValue(xmlData, 'count(//ContractorId)') >0  or ExtractValue(xmlData, 'count(//ContractorJobNumber)') >0  or ExtractValue(xmlData, 'count(//ContName)') >0) THEN
	SET @selectquery = CONCAT(@selectquery,', `tpcust`.`ThirdPartyName` AS `CustomerId`, `tpcust`.`ContactName` AS `CustName`, `itpcust`.`JobNumber` AS `CustomerJobNumber`, `tpcont`.`ThirdPartyName` AS `ContractorId`, `tpcont`.`ContactName` AS `ContName`, `itpcont`.`JobNumber` AS `ContractorJobNumber` ' );
	SET @queryFrom = CONCAT(@queryFrom,'   
		left join (`inc_third_party` `itpcust`
        join `third_party` `tpcust` ON `itpcust`.`ThirdPartyId` = `tpcust`.`ThirdPartyId`
        join `third_party_type` `tptcust` ON `tpcust`.`ThirdPartyTypeId` = `tptcust`.`ThirdPartyTypeId`
            and `tptcust`.`ThirdPartyTypeCode` = \'Customer\') ON `inc`.`IncidentId` = `itpcust`.`IncidentId`
        left join (`inc_third_party` `itpcont`
        join `third_party` `tpcont` ON `itpcont`.`ThirdPartyId` = `tpcont`.`ThirdPartyId`
        join `third_party_type` `tptcont` ON `tpcont`.`ThirdPartyTypeId` = `tptcont`.`ThirdPartyTypeId`
            and `tptcont`.`ThirdPartyTypeCode` = \'Contractor\') ON `inc`.`IncidentId` = `itpcont`.`IncidentId` ');
 
	SET @Col =  ExtractValue(xmlData, CONCAT('//','ContractorId'));
	IF (@Col != '' AND @Col !='NULL') THEN	 
		SET @queryWhere = CONCAT(@queryWhere,'  and `tpcont`.`ThirdPartyName`' ,' like '"'%", @Col ,"%'" );
	END IF;
	SET @Col =  ExtractValue(xmlData, CONCAT('//','ContName'));
	IF (@Col != '' AND @Col !='NULL') THEN	 
		SET @queryWhere = CONCAT(@queryWhere,'  and `tpcont`.`ContactName`' ,' like '"'%", @Col ,"%'" );
	END IF;
	SET @Col =  ExtractValue(xmlData, CONCAT('//','ContractorJobNumber'));
	IF (@Col != '' AND @Col !='NULL') THEN	 
		SET @queryWhere = CONCAT(@queryWhere,'  and `itpcont`.`JobNumber`' ,' like '"'%", @Col ,"%'" );
	END IF;
	SET @Col =  ExtractValue(xmlData, CONCAT('//','CustomerId'));
	IF (@Col != '' AND @Col !='NULL') THEN	 
		SET @queryWhere = CONCAT(@queryWhere,'  and `tpcust`.`ThirdPartyName`' ,' like '"'%", @Col ,"%'" );
	END IF;
	SET @Col =  ExtractValue(xmlData, CONCAT('//','CustName'));
	IF (@Col != '' AND @Col !='NULL') THEN	 
	SET @queryWhere = CONCAT(@queryWhere,'  and `tpcust`.`ContactName`' ,' like '"'%", @Col ,"%'" );
	END IF;
    
	SET @Col =  ExtractValue(xmlData, CONCAT('//','CustomerJobNumber'));
	IF (@Col != '' AND @Col !='NULL') THEN	 
		SET @queryWhere = CONCAT(@queryWhere,'  and `itpcust`.`JobNumber`' ,' like '"'%", @Col ,"%'" );
	END IF; 
END IF;
*/
/*  OEDepartmentId  */
IF( EXTRACTVALUE(xmlData, 'count(//OEDepartmentId)') >0) THEN 
SET @selectquery = CONCAT(@selectquery,',  replace( hinc.`OEDepartmentName`, ';|',';')   AS OEDepartmentId');
	-- SET @queryFrom = CONCAT(@queryFrom,'   left join  ( inc_oe_department  join `oe_department` ON `oe_department`.`OEDepartmentId` = `inc_oe_department`.`OEDepartmentId` )  on inc.IncidentId = inc_oe_department.IncidentId   ');
    
	SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','OEDepartmentId'));
	IF (@Col != '' AND @Col !='NULL') THEN	 
		SET @queryWhere = CONCAT(@queryWhere,'  and   hinc.`OEDepartmentName`  ' ,' like '"'%", @Col ,"%'" );
	END IF;
END IF;
/*  EnvConditions  */
IF( EXTRACTVALUE(xmlData, 'count(//EnvConditions)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,',   replace( hinc.`EnvConditionName`, ';|',';')  as  EnvConditions ');
	-- SET @queryFrom = CONCAT(@queryFrom,'    
	-- left join ( `inc_env_cond` inner join `env_cond_parameter` ON `env_cond_parameter`.`EnvCondParameterId` = `inc_env_cond`.`EnvCondParameterId` ) on inc.IncidentId = inc_env_cond.IncidentId  ');
                                
    
	SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','EnvConditions'));
	IF (@Col != '' AND @Col !='NULL') THEN	 
		SET @queryWhere = CONCAT(@queryWhere,'  and hinc.EnvConditionName ' ,' like '"'%", @Col ,"%'" );
	END IF;                     
END IF;
/*  RootCauseParamId  */
IF( EXTRACTVALUE(xmlData, 'count(//RootCauseParamId)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,',   replace( hinc.`RootCauseName`, ';|',';')    AS RootCauseParamId');
	-- SET @queryFrom = CONCAT(@queryFrom,'     LEFT JOIN (`inc_root_cause` inner  join `root_cause_param` ON `root_cause_param`.`RootCauseParamId` = `inc_root_cause`.`RootCauseParamId`      ) ON inc.IncidentId = inc_root_cause.IncidentId  ');
    
    
     SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','RootCauseParamId'));
	IF (@Col != '' AND @Col !='NULL') THEN	 
		SET @queryWhere = CONCAT(@queryWhere,'  and hinc.RootCauseName' ,' like '"'%", @Col ,"%'" );
	END IF;
END IF;
/*  InvSourceId  */
IF( EXTRACTVALUE(xmlData, 'count(//InvSourceParamId)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,',  replace( hinc.`IncInvSourceName`, ';|',';')    as InvSourceParamId');
	-- SET @queryFrom = CONCAT(@queryFrom,'      LEFT JOIN  (`inc_inv_source` join `inv_source` ON `inv_source`.`InvSourceId` = `inc_inv_source`.`InvSourceId`    ) ON inc.IncidentId = inc_inv_source.IncidentId  ');	
                
	SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','InvSourceParamId'));
	IF (@Col != '' AND @Col !='NULL') THEN	 
		SET @queryWhere = CONCAT(@queryWhere,'  and  `hist`.`IncInvSourceName` ' ,' like '"'%", @Col ,"%'" );
	END IF; 
END IF;
IF  EXTRACTVALUE(xmlData, 'count(//EnergyForm)') >0  
THEN 
	IF @histinc_thirdparties_joined IS NULL THEN
        SET @queryFrom = CONCAT(@queryFrom,'  
			left join histinc_thirdparties on(hinc.HistIncidentId = histinc_thirdparties.HistIncidentId) ');
	    SET @histinc_thirdparties_joined = 1;
    END IF;
	SET @selectquery = CONCAT(@selectquery,',   replace(`histinc_thirdparties`.`EnergyForm`, ';|',';') AS EnergyForm ');
	--  SET @queryFrom = CONCAT(@queryFrom,'    left join (`inc_obser_ana` ioae inner join `observation_analysis_param` oape ON `oape`.`ObservationAndAnalysisParamId` = `ioae`.`ObservationAndAnalysisParamId`
	-- inner join `observation_analysis` oae ON `oae`.`ObservationAndAnalysisId` = `oape`.`ObservationAndAnalysisId` AND oae.ObservationAndAnalysisCode = \'EnergyForm\' )      on inc.IncidentId = ioae.IncidentId  ');
	SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','EnergyForm'));
	IF (@Col != '' AND @Col !='NULL') THEN	 
		SET @queryWhere = CONCAT(@queryWhere,'  and  histinc_thirdparties.EnergyForm ' ,' like '"'%", @Col ,"%'" );
	END IF; 
END IF;
IF EXTRACTVALUE(xmlData, 'count(//SubActions)') >0   THEN 
	IF @histinc_thirdparties_joined IS NULL THEN
        SET @queryFrom = CONCAT(@queryFrom,'  
			left join histinc_thirdparties on(hinc.HistIncidentId = histinc_thirdparties.HistIncidentId) ');
	    SET @histinc_thirdparties_joined = 1;
    END IF;
	SET @selectquery = CONCAT(@selectquery,',   replace(`histinc_thirdparties`.`SubActions`, ';|',';') AS SubActions ');
	-- SET @queryFrom = CONCAT(@queryFrom,'    left join (`inc_obser_ana` ioasa  inner join `observation_analysis_param` oapsa ON `oapsa`.`ObservationAndAnalysisParamId` = `ioasa`.`ObservationAndAnalysisParamId`
	SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','SubActions'));
	IF (@Col != '' AND @Col !='NULL') THEN	 
		SET @queryWhere = CONCAT(@queryWhere,'  and  histinc_thirdparties.SubActions ' ,' like '"'%", @Col ,"%'" );
	END IF; 
END IF;
IF EXTRACTVALUE(xmlData, 'count(//UnderLyingCauses)') >0	 THEN 
	IF @histinc_thirdparties_joined IS NULL THEN
        SET @queryFrom = CONCAT(@queryFrom,'  
			left join histinc_thirdparties on(hinc.HistIncidentId = histinc_thirdparties.HistIncidentId) ');
	    SET @histinc_thirdparties_joined = 1;
    END IF;
	SET @selectquery = CONCAT(@selectquery,',   replace(`histinc_thirdparties`.`UnderLyingCauses`, ';|',';') AS UnderLyingCauses ');
	-- SET @queryFrom = CONCAT(@queryFrom,'    left join (`inc_obser_ana` ioauc inner join `observation_analysis_param` oapuc ON `oapuc`.`ObservationAndAnalysisParamId` = `ioauc`.`ObservationAndAnalysisParamId`
	SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','UnderLyingCauses'));
	IF (@Col != '' AND @Col !='NULL') THEN	 
		SET @queryWhere = CONCAT(@queryWhere,'  and  `histinc_thirdparties`.UnderLyingCauses ' ,' like '"'%", @Col ,"%'" );
	END IF;
END IF;
IF EXTRACTVALUE(xmlData, 'count(//SubConditions)') >0 THEN 
	IF @histinc_thirdparties_joined IS NULL THEN
        SET @queryFrom = CONCAT(@queryFrom,'  
			left join histinc_thirdparties on(hinc.HistIncidentId = histinc_thirdparties.HistIncidentId) ');
	    SET @histinc_thirdparties_joined = 1;
    END IF;
	SET @selectquery = CONCAT(@selectquery,',   replace(`histinc_thirdparties`.`SubConditions`, ';|',';') AS SubConditions ');
	-- SET @queryFrom = CONCAT(@queryFrom,'    left join (`inc_obser_ana` ioasc inner join `observation_analysis_param` oapsc ON `oapsc`.`ObservationAndAnalysisParamId` = `ioasc`.`ObservationAndAnalysisParamId`
  
	SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','SubConditions'));
	IF (@Col != '' AND @Col !='NULL') THEN	 
		SET @queryWhere = CONCAT(@queryWhere,'  and  `histinc_thirdparties`.`SubConditions` ' ,' like '"'%", @Col ,"%'" );
	END IF;
END IF;
IF( EXTRACTVALUE(xmlData, 'count(//PeopleInvolvedName)') >0  OR EXTRACTVALUE(xmlData, 'count(//Company)') >0 OR EXTRACTVALUE(xmlData, 'count(//Position)') >0
OR EXTRACTVALUE(xmlData, 'count(//Email)') >0  OR EXTRACTVALUE(xmlData, 'count(//PrimaryPhone)') >0  OR EXTRACTVALUE(xmlData, 'count(//AlternatePhone)') >0
OR  EXTRACTVALUE(xmlData, 'count(//ExpInCurrentPostion)') >0  OR EXTRACTVALUE(xmlData, 'count(//ExpOverAll)') >0 OR EXTRACTVALUE(xmlData, 'count(//Age)') >0
OR EXTRACTVALUE(xmlData, 'count(//HowHeInvolved)') >0  OR EXTRACTVALUE(xmlData, 'count(//RoleDescription)') >0  OR EXTRACTVALUE(xmlData, 'count(//CertificateId)') >0
) THEN
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join people_involved pinv on pinv.IncidentId = inc.IncidentId  ');
	IF( EXTRACTVALUE(xmlData, 'count(//PeopleInvolvedName)') >0) THEN
		SET @selectquery = CONCAT(@selectquery,', ( GROUP_CONCAT(DISTINCT if(pinv.PeopleInvolvedName ='',null, pinv.PeopleInvolvedName) separator '; ')  ) as PeopleInvolvedName');
         
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','PeopleInvolvedName'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  pinv.`PeopleInvolvedName` ' ,' like '"'%", @Col ,"%'" );
		END IF; 
         
	END IF;
	IF( EXTRACTVALUE(xmlData, 'count(//Company)') >0) THEN
		SET @selectquery = CONCAT(@selectquery,', ( GROUP_CONCAT(DISTINCT if(pinv.Company = '', NULL, pinv.Company) SEPARATOR '; ' ) ) as Company');
         
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','Company'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  pinv.Company ' ,' like '"'%", @Col ,"%'" );
		END IF; 
         
	END IF;
	IF( EXTRACTVALUE(xmlData, 'count(//Position)') >0) THEN
		SET @selectquery = CONCAT(@selectquery,', (  GROUP_CONCAT(DISTINCT if( pinv.Position = '', NULL, pinv.Position) SEPARATOR '; ') ) as Position');
         
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','Position'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  pinv.Position ' ,' like '"'%", @Col ,"%'" );
		END IF; 
         
	END IF;
	IF( EXTRACTVALUE(xmlData, 'count(//Email)') >0) THEN
		SET @selectquery = CONCAT(@selectquery,', ( GROUP_CONCAT(DISTINCT if( pinv.Email = '' , NULL, pinv.Email) SEPARATOR '; ') ) as Email');
         
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','Email'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  pinv.Email ' ,' like '"'%", @Col ,"%'" );
		END IF; 
         
	END IF;
	IF( EXTRACTVALUE(xmlData, 'count(//PrimaryPhone)') >0) THEN
		SET @selectquery = CONCAT(@selectquery,', (  GROUP_CONCAT(DISTINCT if(pinv.PrimaryPhone= '', NULL, pinv.PrimaryPhone) SEPARATOR '; ') ) as PrimaryPhone');
         
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','PrimaryPhone'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  pinv.PrimaryPhone ' ,' like '"'%", @Col ,"%'" );
		END IF; 
         
	END IF;
	IF( EXTRACTVALUE(xmlData, 'count(//AlternatePhone)') >0) THEN
			SET @selectquery = CONCAT(@selectquery,', ( GROUP_CONCAT(DISTINCT if(pinv.AlternatePhone = '', NULL,  pinv.AlternatePhone) SEPARATOR '; ' ) ) as AlternatePhone');
         
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','AlternatePhone'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  pinv.AlternatePhone ' ,' like '"'%", @Col ,"%'" );
		END IF; 
         
	END IF;
	IF( EXTRACTVALUE(xmlData, 'count(//ExpInCurrentPostion)') >0) THEN
		SET @selectquery = CONCAT(@selectquery,', (  GROUP_CONCAT(DISTINCT if(pinv.ExpInCurrentPostion = '', NULL,  pinv.ExpInCurrentPostion) SEPARATOR '; ') ) as ExpInCurrentPostion');
         
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','ExpInCurrentPostion'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  pinv.ExpInCurrentPostion ' ,' like '"'%", @Col ,"%'" );
		END IF; 
         
	END IF;
	IF( EXTRACTVALUE(xmlData, 'count(//ExpOverAll)') >0) THEN
		SET @selectquery = CONCAT(@selectquery,', (  GROUP_CONCAT(DISTINCT if(pinv.ExpOverAll= '', NULL, pinv.ExpOverAll ) SEPARATOR '; ' ) ) as ExpOverAll');
         
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','ExpOverAll'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  pinv.ExpOverAll ' ,' like '"'%", @Col ,"%'" );
		END IF; 
         
	END IF;
	IF( EXTRACTVALUE(xmlData, 'count(//Age)') >0) THEN
		SET @selectquery = CONCAT(@selectquery,', ( GROUP_CONCAT(DISTINCT if(pinv.Age = '', NULL,  pinv.Age) SEPARATOR '; ' ) ) as Age');
         
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','Age'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  pinv.Age ' ,' like '"'%", @Col ,"%'" );
		END IF; 
         
	END IF;
	IF( EXTRACTVALUE(xmlData, 'count(//HowHeInvolved)') >0) THEN
		SET @selectquery = CONCAT(@selectquery,', ( GROUP_CONCAT(DISTINCT if(pinv.HowHeInvolved = '', NULL, pinv.HowHeInvolved ) SEPARATOR '; ' ) ) as HowHeInvolved');
         
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','HowHeInvolved'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  pinv.HowHeInvolved ' ,' like '"'%", @Col ,"%'" );
		END IF; 
         
	END IF;
	IF( EXTRACTVALUE(xmlData, 'count(//RoleDescription)') >0) THEN
		SET @selectquery = CONCAT(@selectquery,', (  GROUP_CONCAT(DISTINCT if(pinv.RoleDescription = '', NULL, pinv.RoleDescription ) SEPARATOR '; ' ) ) as RoleDescription');
         
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','RoleDescription'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  pinv.RoleDescription ' ,' like '"'%", @Col ,"%'" );
		END IF; 
         
	END IF;
	IF( EXTRACTVALUE(xmlData, 'count(//CertificateId)') >0) THEN
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(distinct  CertificateName separator '; ') ) as CertificateId');
        SET @queryFrom = CONCAT(@queryFrom,'      left outer join (have_certificate hv inner join  certificate  on certificate.CertificateId = hv.CertificateId
) on pinv.PeopleInvolvedId = hv.PeopleInvolvedId  ');
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','CertificateId'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `certificate`.`CertificateName` ' ,' like '"'%", @Col ,"%'" );
		END IF;
	END IF;
END IF;
IF( EXTRACTVALUE(xmlData, 'count(//AssignedToId)') >0  OR EXTRACTVALUE(xmlData, 'count(//EmployeeId)') >0 OR EXTRACTVALUE(xmlData, 'count(//TaskStatusId)') >0
OR EXTRACTVALUE(xmlData, 'count(//PriorityId)') >0  OR EXTRACTVALUE(xmlData, 'count(//StartDate)') >0  OR EXTRACTVALUE(xmlData, 'count(//TargetEndDate)') >0
OR  EXTRACTVALUE(xmlData, 'count(//ActualEndDate)') >0  OR EXTRACTVALUE(xmlData, 'count(//TaskEstimatedCost)') >0 OR EXTRACTVALUE(xmlData, 'count(//TaskDescription)') >0
OR EXTRACTVALUE(xmlData, 'count(//OutComeFollowUp)') >0  OR EXTRACTVALUE(xmlData, 'count(//DesiredResults)') >0  OR EXTRACTVALUE(xmlData, 'count(//Comments)') >0
) THEN
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join corrective_action ca on ca.IncidentId = inc.IncidentId  ');
	
    IF( EXTRACTVALUE(xmlData, 'count(//AssignedToId)') >0) THEN
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(  distinct CONCAT(`empAssigned`.`FirstName`, '  ', `empAssigned`.`LastName`) separator '; ') )as AssignedToId');
                                                        
		SET @queryFrom = CONCAT(@queryFrom,'    LEFT JOIN `employee` `empAssigned` ON `empAssigned`.`EmployeeId` = `ca`.`AssignedToId`  ');
        
        
        SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','AssignedToId'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
				SET @queryWhere = CONCAT(@queryWhere,'  and  CONCAT(`empAssigned`.`FirstName`, ' ',    `empAssigned`.`LastName` )  ' ,' like '"'%", @Col ,"%'" );
		END IF;         
	END IF;
	IF( EXTRACTVALUE(xmlData, 'count(//EmployeeId)') >0) THEN
		SET @selectquery = CONCAT(@selectquery,', ( group_concat( distinct  CONCAT(`empNotified`.`FirstName`, ' ',    `empNotified`.`LastName` ) separator '; ') ) as EmployeeId');
		SET @queryFrom = CONCAT(@queryFrom,'    LEFT JOIN ( `corrective_action_notified` `can`    JOIN `employee`  `empNotified` ON `empNotified`.`EmployeeId` = `can`.`EmployeeId`   ) ON `can`.`CorrectiveActionId` = `ca`.`CorrectiveActionId` ');
			    
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','EmployeeId'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  CONCAT(`empNotified`.`FirstName`, ' ',    `empNotified`.`LastName` )  ' ,' like '"'%", @Col ,"%'" );
		END IF;
	END IF;
	IF( EXTRACTVALUE(xmlData, 'count(//TaskStatusId)') >0) THEN
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(distinct  CorrActStatusName separator '; ') ) as TaskStatusId');
	
		SET @queryFrom = CONCAT(@queryFrom,'    LEFT JOIN `corr_act_status` ON `corr_act_status`.`CorrActStatusId` = `ca`.`CorrActStatusId`  '); 
        
        SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','TaskStatusId'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `corr_act_status`.`CorrActStatusName` ' ,' like '"'%", @Col ,"%'" );
		END IF;                                                        
    END IF;
	IF( EXTRACTVALUE(xmlData, 'count(//PriorityId)') >0) THEN
		SET @selectquery = CONCAT(@selectquery,',  group_concat(distinct  PriorityName separator '; ') as PriorityId');
        SET @queryFrom = CONCAT(@queryFrom,'    LEFT JOIN `priority` ON  `priority`.`PriorityId` = `ca`.`PriorityId`  ');  
        
        SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','PriorityId'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `priority`.`PriorityName` ' ,' like '"'%", @Col ,"%'" );
		END IF;  
        
	END IF;
	IF( EXTRACTVALUE(xmlData, 'count(//StartDate)') >0) THEN
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(distinct  date_format(StartDate,'%m/%d/%Y') separator '; ')  ) as StartDate');
        /* 
		SET @Col =  ExtractValue(xmlData, CONCAT('//','StartDate'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  ca.StartDate ' ,' = '"'%", @Col ,"%'" );
		END IF; 
        */ 
	END IF;
	IF( EXTRACTVALUE(xmlData, 'count(//TargetEndDate)') >0) THEN
		SET @selectquery = CONCAT(@selectquery,', ( group_concat( distinct  date_format(TargetEndDate,'%m/%d/%Y') separator '; ')  ) as TargetEndDate');
        /* 
		SET @Col =  ExtractValue(xmlData, CONCAT('//','TargetEndDate'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  ca.TargetEndDate ' ,' = '"'", @Col ,"'" );
		END IF; 
		*/
	END IF;
	
	IF( EXTRACTVALUE(xmlData, 'count(//ActualEndDate)') >0) THEN
		SET @selectquery = CONCAT(@selectquery,', ( group_concat( distinct  date_format(ActualEndDate,'%m/%d/%Y') separator '; ')  ) as ActualEndDate');
         
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','ActualEndDate'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  ca.ActualEndDate ' ,' = '"'", @Col ,"'" );
		END IF; 
         
	END IF;
	IF( EXTRACTVALUE(xmlData, 'count(//TaskEstimatedCost)') >0) THEN
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(distinct  ca.EstimatedCost separator '; ')  ) as TaskEstimatedCost');
        /* 
		SET @Col =  ExtractValue(xmlData, CONCAT('//','TaskEstimatedCost'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  ca.TaskEstimatedCost ' ,' = '"", @Col ,"" );
		END IF; 
        */ 
	END IF;
	IF( EXTRACTVALUE(xmlData, 'count(//TaskDescription)') >0) THEN
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(distinct  TaskDescription separator '; ')  ) as TaskDescription');
         
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','TaskDescription'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  ca.TaskDescription ' ,' like '"'%", @Col ,"%'" );
		END IF; 
         
	END IF;
	IF( EXTRACTVALUE(xmlData, 'count(//OutComeFollowUp)') >0) THEN
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(distinct  OutComeFollowUp separator '; ')  ) as OutComeFollowUp');
         
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','OutComeFollowUp'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  ca.OutComeFollowUp ' ,' like '"'%", @Col ,"%'" );
		END IF; 
         
	END IF;
	IF( EXTRACTVALUE(xmlData, 'count(//DesiredResults)') >0) THEN 
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(distinct  CASE `ca`.`DesiredResults`  WHEN '0' THEN '', @lblNo, '' WHEN '1' THEN '', @lblYes,''   END  separator '; ')  ) as DesiredResults');
         
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','DesiredResults'));
		IF (@Col != '' AND @Col !='NULL') THEN	
			IF( @Col  != '2' ) THEN  
				SET @queryWhere = CONCAT(@queryWhere,'  and  ca.DesiredResults = ' , @Col );
			END IF;
		END IF; 
         
	END IF;
	IF( EXTRACTVALUE(xmlData, 'count(//Comments)') >0) THEN
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(distinct  Comments separator '; ') ) as Comments');
         
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','Comments'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  ca.Comments ' ,' like '"'%", @Col ,"%'" );
		END IF; 
         
	END IF;
END IF;
/* impact type part   */
SET @impactWhere='  ';
IF(EXTRACTVALUE(xmlData, 'count(//ImpactTypeId)') >0 ) THEN
	-- SET @queryFrom = CONCAT(@queryFrom,'    left outer join inc_impact_type_view on inc_impact_type_view.IncidentId = inc.IncidentId  ');
	
	SET @selectquery = CONCAT(@selectquery,',    CONCAT_WS(', ',
                            (SELECT DISTINCT
                                    GROUP_CONCAT(`impact_type`.`ImpactTypeName`
                                            SEPARATOR ', ')
                                FROM
                                    ((`impact`
                                    JOIN `impact_sub_type` ON ((`impact_sub_type`.`ImpactSubTypeId` = `impact`.`ImpactSubTypeId`)))
                                    JOIN `impact_type` ON ((`impact_sub_type`.`ImpactTypeId` = `impact_type`.`ImpactTypeId`)))
                                WHERE
                                    (`impact`.`IncidentId` = `inc`.`IncidentId`)) ,
                            (SELECT DISTINCT
                                    GROUP_CONCAT(`impact_type`.`ImpactTypeName`
                                             SEPARATOR ', ')
                                FROM
                                    ((`injury`
                                    JOIN `impact_sub_type` ON ((`impact_sub_type`.`ImpactSubTypeId` = `injury`.`ImpactSubTypeId`)))
                                    JOIN `impact_type` ON ((`impact_sub_type`.`ImpactTypeId` = `impact_type`.`ImpactTypeId`)))
                                WHERE
                                    (`injury`.`IncidentId` = `inc`.`IncidentId`)) ,
                            (SELECT DISTINCT
                                    GROUP_CONCAT(`impact_type`.`ImpactTypeName`
                                             SEPARATOR ', ')
                                FROM
                                    ((`illness`
                                    JOIN `impact_sub_type` ON ((`impact_sub_type`.`ImpactSubTypeId` = `illness`.`ImpactSubTypeId`)))
                                    JOIN `impact_type` ON ((`impact_sub_type`.`ImpactTypeId` = `impact_type`.`ImpactTypeId`)))
                                WHERE
                                    (`illness`.`IncidentId` = `inc`.`IncidentId`)) ,
                            (SELECT DISTINCT
                                    GROUP_CONCAT(`impact_type`.`ImpactTypeName`
                                             SEPARATOR ', ')
                                FROM
                                    ((`spill_release`
                                    JOIN `impact_sub_type` ON ((`impact_sub_type`.`ImpactSubTypeId` = `spill_release`.`ImpactSubTypeId`)))
                                    JOIN `impact_type` ON ((`impact_sub_type`.`ImpactTypeId` = `impact_type`.`ImpactTypeId`)))
                                WHERE
                                    (`spill_release`.`IncidentId` = `inc`.`IncidentId`)) ,
                            (SELECT DISTINCT
                                    GROUP_CONCAT(`impact_type`.`ImpactTypeName`
                                             SEPARATOR ', ')
                                FROM
                                    ((`vehicle_damage`
                                    JOIN `impact_sub_type` ON ((`impact_sub_type`.`ImpactSubTypeId` = `vehicle_damage`.`ImpactSubTypeId`)))
                                    JOIN `impact_type` ON ((`impact_sub_type`.`ImpactTypeId` = `impact_type`.`ImpactTypeId`)))
                                WHERE
                                    (`vehicle_damage`.`IncidentId` = `inc`.`IncidentId`)) ,
                            (SELECT DISTINCT
                                    GROUP_CONCAT(`impact_type`.`ImpactTypeName`
                                             SEPARATOR ', ')
                                FROM
                                    ((`traffic_violation`
                                    JOIN `impact_sub_type` ON ((`impact_sub_type`.`ImpactSubTypeId` = `traffic_violation`.`ImpactSubTypeId`)))
                                    JOIN `impact_type` ON ((`impact_sub_type`.`ImpactTypeId` = `impact_type`.`ImpactTypeId`)))
                                WHERE
                                    (`traffic_violation`.`IncidentId` = `inc`.`IncidentId`)))
             AS `ImpactTypeId`');	
            
            
            
		
	
END IF;
/* impact sub type part   */
IF(EXTRACTVALUE(xmlData, 'count(//ImpactSubTypeId)') >0 ) THEN
SET @selectquery = CONCAT(@selectquery,',     (SELECT 
                CONCAT_WS(', ',
                            (SELECT DISTINCT
                                    GROUP_CONCAT(`impact_sub_type`.`ImpactSubTypeName`
                                            SEPARATOR ', ')
                                FROM
                                    (`impact`
                                    JOIN `impact_sub_type` ON ((`impact_sub_type`.`ImpactSubTypeId` = `impact`.`ImpactSubTypeId`)))
                                WHERE
                                    (`impact`.`IncidentId` = `inc`.`IncidentId`)),
                            (SELECT DISTINCT
                                    GROUP_CONCAT(`impact_sub_type`.`ImpactSubTypeName`
                                            SEPARATOR ', ')
                                FROM
                                    (`injury`
                                    JOIN `impact_sub_type` ON ((`impact_sub_type`.`ImpactSubTypeId` = `injury`.`ImpactSubTypeId`)))
                                WHERE
                                    (`injury`.`IncidentId` = `inc`.`IncidentId`)),
                            (SELECT DISTINCT
                                    GROUP_CONCAT(`impact_sub_type`.`ImpactSubTypeName`
                                             SEPARATOR ', ')
                                FROM
                                    (`illness`
                                    JOIN `impact_sub_type` ON ((`impact_sub_type`.`ImpactSubTypeId` = `illness`.`ImpactSubTypeId`)))
                                WHERE
                                    (`illness`.`IncidentId` = `inc`.`IncidentId`)),
                            (SELECT DISTINCT
                                    GROUP_CONCAT(`impact_sub_type`.`ImpactSubTypeName`
                                             SEPARATOR ', ')
                                FROM
                                    (`spill_release`
                                    JOIN `impact_sub_type` ON ((`impact_sub_type`.`ImpactSubTypeId` = `spill_release`.`ImpactSubTypeId`)))
                                WHERE
                                    (`spill_release`.`IncidentId` = `inc`.`IncidentId`)),
                            (SELECT DISTINCT
                                    GROUP_CONCAT(`impact_sub_type`.`ImpactSubTypeName`
                                             SEPARATOR ', ')
                                FROM
                                    (`vehicle_damage`
                                    JOIN `impact_sub_type` ON ((`impact_sub_type`.`ImpactSubTypeId` = `vehicle_damage`.`ImpactSubTypeId`)))
                                WHERE
                                    (`vehicle_damage`.`IncidentId` = `inc`.`IncidentId`)),
                            (SELECT DISTINCT
                                    GROUP_CONCAT(`impact_sub_type`.`ImpactSubTypeName`
                                             SEPARATOR ', ')
                                FROM
                                    (`traffic_violation`
                                    JOIN `impact_sub_type` ON ((`impact_sub_type`.`ImpactSubTypeId` = `traffic_violation`.`ImpactSubTypeId`)))
                                WHERE
                                    (`traffic_violation`.`IncidentId` = `inc`.`IncidentId`)))
            ) AS `ImpactSubTypeId`  ');	
	-- SET @queryFrom = CONCAT(@queryFrom,'    left outer join inc_impact_subtype_view on inc_impact_subtype_view.IncidentId = inc.IncidentId  ');	
 -- 	SET @selectquery = CONCAT(@selectquery,', inc_impact_subtype_view.ImpactSubTypeId ');	
	
END IF;
IF(EXTRACTVALUE(xmlData, 'count(//ExtAgencyId)') >0 ) THEN
	-- SET @queryFrom = CONCAT(@queryFrom,'    left outer join inc_impact_extagency_view on inc_impact_extagency_view.IncidentId = inc.IncidentId  ');	
	SET @selectquery = CONCAT(@selectquery,' ,         (SELECT CONCAT_WS(', ',
                (SELECT DISTINCT
                        GROUP_CONCAT(`external_agency`.`ExtAgencyName`
                                 SEPARATOR '; ')
                    FROM
                        ((`impact`
                        LEFT JOIN `impacts_ext_agency` ON ((`impacts_ext_agency`.`ImpactId` = `impact`.`ImpactId`)))
                        LEFT JOIN `external_agency` ON ((`external_agency`.`ExtAgencyId` = `impacts_ext_agency`.`ExtAgencyId`)))
                    WHERE
                        (`impact`.`IncidentId` = `inc`.`IncidentId`)),
                (SELECT DISTINCT
                        GROUP_CONCAT(`external_agency`.`ExtAgencyName`
                                 SEPARATOR '; ')
                    FROM
                        ((`injury`
                        LEFT JOIN `impacts_ext_agency` ON ((`impacts_ext_agency`.`InjuryId` = `injury`.`InjuryId`)))
                        LEFT JOIN `external_agency` ON ((`external_agency`.`ExtAgencyId` = `impacts_ext_agency`.`ExtAgencyId`)))
                    WHERE
                        (`injury`.`IncidentId` = `inc`.`IncidentId`)),
                (SELECT DISTINCT
                        GROUP_CONCAT(`external_agency`.`ExtAgencyName`
                                 SEPARATOR '; ')
                    FROM
                        ((`illness`
                        LEFT JOIN `impacts_ext_agency` ON ((`impacts_ext_agency`.`IllnessId` = `illness`.`IllnessId`)))
                        LEFT JOIN `external_agency` ON ((`external_agency`.`ExtAgencyId` = `impacts_ext_agency`.`ExtAgencyId`)))
                    WHERE
                        (`illness`.`IncidentId` = `inc`.`IncidentId`)),
                (SELECT DISTINCT
                        GROUP_CONCAT(`external_agency`.`ExtAgencyName`
                                 SEPARATOR '; ')
                    FROM
                        ((`spill_release`
                        LEFT JOIN `impacts_ext_agency` ON ((`impacts_ext_agency`.`SpillReleaseId` = `spill_release`.`SpillReleaseId`)))
                        LEFT JOIN `external_agency` ON ((`external_agency`.`ExtAgencyId` = `impacts_ext_agency`.`ExtAgencyId`)))
                    WHERE
                        (`spill_release`.`IncidentId` = `inc`.`IncidentId`)),
                (SELECT DISTINCT
                        GROUP_CONCAT(`external_agency`.`ExtAgencyName`
                                 SEPARATOR '; ')
                    FROM
                        ((`vehicle_damage`
                        LEFT JOIN `impacts_ext_agency` ON ((`impacts_ext_agency`.`VehicleDamageId` = `vehicle_damage`.`VehicleDamageId`)))
                        LEFT JOIN `external_agency` ON ((`external_agency`.`ExtAgencyId` = `impacts_ext_agency`.`ExtAgencyId`)))
                    WHERE
                        (`vehicle_damage`.`IncidentId` = `inc`.`IncidentId`)),
                (SELECT DISTINCT
                        GROUP_CONCAT(`external_agency`.`ExtAgencyName`
                                 SEPARATOR '; ')
                    FROM
                        ((`traffic_violation`
                        LEFT JOIN `impacts_ext_agency` ON ((`impacts_ext_agency`.`TrafficViolationId` = `traffic_violation`.`TrafficViolationId`)))
                        LEFT JOIN `external_agency` ON ((`external_agency`.`ExtAgencyId` = `impacts_ext_agency`.`ExtAgencyId`)))
                    WHERE
                        (`traffic_violation`.`IncidentId` = `inc`.`IncidentId`)))) AS `ExtAgencyId`   ');	
	
END IF;
 SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','ImpactTypeId'));
 IF (@Col != '' AND @Col !='NULL') THEN	 
	SET @impactWhere = CONCAT(@impactWhere,'  and  `ImpactTypeId` ' ,' like '"'%", @Col ,"%'" );
END IF;      
SET @queryhave = CONCAT(@queryhave, @impactWhere);
 SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','ImpactSubTypeId'));
 IF (@Col != '' AND @Col !='NULL') THEN	 
	SET @impactWhere = CONCAT(@impactWhere,'  and  `ImpactSubTypeId` ' ,' like '"'%", @Col ,"%'" );
END IF;      
SET @queryhave = CONCAT(@queryhave, @impactWhere);
 
 SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','ExtAgencyId'));
 IF (@Col != '' AND @Col !='NULL') THEN	 
	SET @impactWhere = CONCAT(@impactWhere,'  and  `ExtAgencyId` ' ,' like '"'%", @Col ,"%'" );
END IF;      
SET @queryhave = CONCAT(@queryhave, @impactWhere);
/* impact part   */
IF (   EXTRACTVALUE(xmlData, 'count(//ImpactDescription)')>0 OR EXTRACTVALUE(xmlData, 'count(//IntEmployeeName1)') >0 
	OR EXTRACTVALUE(xmlData, 'count(//IntEmployeeDept1)') >0 OR EXTRACTVALUE(xmlData, 'count(//IntEmployeeName2)') >0
	OR EXTRACTVALUE(xmlData, 'count(//IntEmployeeDept2)') >0 OR EXTRACTVALUE(xmlData, 'count(//IntEmployeeName3)') >0 
	OR EXTRACTVALUE(xmlData, 'count(//IntEmployeeDept3)') >0 OR EXTRACTVALUE(xmlData, 'count(//PrimRespondName)') >0 
    OR EXTRACTVALUE(xmlData, 'count(//ImpactEstimatedCost)')>0) THEN
	
	SET  @injuryFound= TRUE;
	SET  @illnessFound= TRUE;
	SET  @spillFound= TRUE;
	SET  @vehicleFound= TRUE;
	SET  @trafficFound= TRUE;
    
	-- SET @queryFrom = CONCAT(@queryFrom,'    left outer join  impact_common_view on impact_common_view.IncidentId = inc.IncidentId  ');
	SET @queryFrom = CONCAT(@queryFrom,'   LEFT JOIN `injury` `inj` ON `inc`.`IncidentId` = `inj`.`IncidentId`
										LEFT JOIN `impact` `imp` ON `inc`.`IncidentId` = `imp`.`IncidentId`
										LEFT JOIN `illness` `ill` ON `inc`.`IncidentId` = `ill`.`IncidentId`
										LEFT JOIN `spill_release` `sp` ON `inc`.`IncidentId` = `sp`.`IncidentId`
										LEFT JOIN `vehicle_damage` `vd` ON `inc`.`IncidentId` = `vd`.`IncidentId`
										LEFT JOIN `traffic_violation` `tv` ON `inc`.`IncidentId` = `tv`.`IncidentId`  ');
    
	
    IF(EXTRACTVALUE(xmlData, 'count(//IntEmployeeName1)') >0 )THEN 	SET @selectquery = CONCAT(@selectquery,', ( SELECT (   CONCAT_WS(', ',
											`inj`.`IntEmployeeName1`,
											`imp`.`IntEmployeeName1`,
											`ill`.`IntEmployeeName1`,
											`sp`.`IntEmployeeName1`,
											`vd`.`IntEmployeeName1`,
											`tv`.`IntEmployeeName1`) )) AS `IntEmployeeName1` ');	END IF;
                                            
	IF(EXTRACTVALUE(xmlData, 'count(//IntEmployeeDept1)') >0 )THEN 	SET @selectquery = CONCAT(@selectquery,',  ( SELECT (   CONCAT_WS(', ',
											`inj`.`IntEmployeeDept1`,
											`imp`.`IntEmployeeDept1`,
											`ill`.`IntEmployeeDept1`,
											`sp`.`IntEmployeeDept1`,
											`vd`.`IntEmployeeDept1`,
											`tv`.`IntEmployeeDept1`) )) AS `IntEmployeeDept1`  ');	END IF;
	IF(EXTRACTVALUE(xmlData, 'count(//IntEmployeeName2)') >0 )THEN 	SET @selectquery = CONCAT(@selectquery,',  ( SELECT (   CONCAT_WS(', ',
											`inj`.`IntEmployeeName2`,
											`imp`.`IntEmployeeName2`,
											`ill`.`IntEmployeeName2`,
											`sp`.`IntEmployeeName2`,
											`vd`.`IntEmployeeName2`,
											`tv`.`IntEmployeeName2`) )) AS `IntEmployeeName2`  ');	END IF;
	IF(EXTRACTVALUE(xmlData, 'count(//IntEmployeeDept2)') >0 )THEN 	SET @selectquery = CONCAT(@selectquery,',  ( SELECT (   CONCAT_WS(', ',
											`inj`.`IntEmployeeDept2`,
											`imp`.`IntEmployeeDept2`,
											`ill`.`IntEmployeeDept2`,
											`sp`.`IntEmployeeDept2`,
											`vd`.`IntEmployeeDept2`,
											`tv`.`IntEmployeeDept2`) )) AS `IntEmployeeDept2`  ');	END IF;
	IF(EXTRACTVALUE(xmlData, 'count(//IntEmployeeName3)') >0 )THEN 	SET @selectquery = CONCAT(@selectquery,',  ( SELECT (   CONCAT_WS(', ',
											`inj`.`IntEmployeeName3`,
											`imp`.`IntEmployeeName3`,
											`ill`.`IntEmployeeName3`,
											`sp`.`IntEmployeeName3`,
											`vd`.`IntEmployeeName3`,
											`tv`.`IntEmployeeName3`) )) AS `IntEmployeeName3` ');	END IF;
	IF(EXTRACTVALUE(xmlData, 'count(//IntEmployeeDept3)') >0 )THEN 	SET @selectquery = CONCAT(@selectquery,',  ( SELECT (   CONCAT_WS(', ',
											`inj`.`IntEmployeeDept3`,
											`imp`.`IntEmployeeDept3`,
											`ill`.`IntEmployeeDept3`,
											`sp`.`IntEmployeeDept3`,
											`vd`.`IntEmployeeDept3`,
											`tv`.`IntEmployeeDept3`) )) AS `IntEmployeeDept3`  ');	END IF;
	IF(EXTRACTVALUE(xmlData, 'count(//PrimRespondName)') >0 )THEN 	SET @selectquery = CONCAT(@selectquery,',  ( SELECT (   CONCAT_WS(', ',
											`inj`.`PrimRespondName`,
											`imp`.`PrimRespondName`,
											`ill`.`PrimRespondName`,
											`sp`.`PrimRespondName`,
											`vd`.`PrimRespondName`,
											`tv`.`PrimRespondName`) )) AS `PrimRespondName`  ');	END IF;
	IF(EXTRACTVALUE(xmlData, 'count(//ImpactDescription)') >0 )THEN 	SET @selectquery = CONCAT(@selectquery,',  ( SELECT (   CONCAT_WS(', ',
											`inj`.`Description`,
											`imp`.`Description`,
											`ill`.`Description`,
											`sp`.`Description`,
											`vd`.`Description`,
											`tv`.`Description`) )) AS `ImpactDescription`  ');	END IF;
	IF(EXTRACTVALUE(xmlData, 'count(//ImpactEstimatedCost)') >0 )THEN 	SET @selectquery = CONCAT(@selectquery,',  ( SELECT (   CONCAT_WS(', ',
											`inj`.`EstimatedCost`,
											`imp`.`EstimatedCost`,
											`ill`.`EstimatedCost`,
											`sp`.`EstimatedCost`,
											`vd`.`EstimatedCost`,
											`tv`.`EstimatedCost`) )) AS `ImpactEstimatedCost` ');	END IF;
 SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','ImpactDescription'));
 IF (@Col != '' AND @Col !='NULL') THEN	 
	SET @impactWhere = CONCAT(@impactWhere,'  and  `ImpactDescription` ' ,' like '"'%", @Col ,"%'" );
END IF;      
SET @queryhave = CONCAT(@queryhave, @impactWhere);
 SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','IntEmployeeName1'));
 IF (@Col != '' AND @Col !='NULL') THEN	 
	SET @impactWhere = CONCAT(@impactWhere,'  and  `IntEmployeeName1` ' ,' like '"'%", @Col ,"%'" );
END IF;      
SET @queryhave = CONCAT(@queryhave, @impactWhere);
 SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','IntEmployeeDept1'));
 IF (@Col != '' AND @Col !='NULL') THEN	 
	SET @impactWhere = CONCAT(@impactWhere,'  and  `IntEmployeeDept1` ' ,' like '"'%", @Col ,"%'" );
END IF;      
SET @queryhave = CONCAT(@queryhave, @impactWhere);
 SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','IntEmployeeName2'));
 IF (@Col != '' AND @Col !='NULL') THEN	 
	SET @impactWhere = CONCAT(@impactWhere,'  and  `IntEmployeeName2` ' ,' like '"'%", @Col ,"%'" );
END IF;      
SET @queryhave = CONCAT(@queryhave, @impactWhere);
 SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','IntEmployeeDept2'));
 IF (@Col != '' AND @Col !='NULL') THEN	 
	SET @impactWhere = CONCAT(@impactWhere,'  and  `IntEmployeeDept2` ' ,' like '"'%", @Col ,"%'" );
END IF;      
SET @queryhave = CONCAT(@queryhave, @impactWhere);
 SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','IntEmployeeName3'));
 IF (@Col != '' AND @Col !='NULL') THEN	 
	SET @impactWhere = CONCAT(@impactWhere,'  and  `IntEmployeeName3` ' ,' like '"'%", @Col ,"%'" );
END IF;      
SET @queryhave = CONCAT(@queryhave, @impactWhere);
 SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','IntEmployeeDept3'));
 IF (@Col != '' AND @Col !='NULL') THEN	 
	SET @impactWhere = CONCAT(@impactWhere,'  and  `IntEmployeeDept3` ' ,' like '"'%", @Col ,"%'" );
END IF;      
SET @queryhave = CONCAT(@queryhave, @impactWhere);
 SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','PrimRespondName'));
 IF (@Col != '' AND @Col !='NULL') THEN	 
	SET @impactWhere = CONCAT(@impactWhere,'  and  `PrimRespondName` ' ,' like '"'%", @Col ,"%'" );
END IF;      
SET @queryhave = CONCAT(@queryhave, @impactWhere);
SET @EstimatedCostTo =  EXTRACTVALUE(xmlData, '//ImpactEstimatedCostTo');
SET @EstimatedCostFrom =  EXTRACTVALUE(xmlData, '//ImpactEstimatedCostFrom');
IF( @EstimatedCostTo !='' ) THEN
	SET @queryhave = CONCAT(@queryhave,' AND  ImpactEstimatedCost  BETWEEN ', @EstimatedCostFrom, ' and ', @EstimatedCostTo);
ELSE 
	IF( @EstimatedCostFrom !=''  AND @EstimatedCostFrom != 'NULL')	 THEN
SET  @EstimatedCostFrom  = (REPLACE(@EstimatedCostFrom, '&lt;', '<'));
SET  @EstimatedCostFrom  = (REPLACE(@EstimatedCostFrom, '&gt;', '>'));
		SET @queryhave = CONCAT(@queryhave,' AND  ImpactEstimatedCost  ', @EstimatedCostFrom);
	END IF;
END IF;
END IF;
/* injury part   */
IF(EXTRACTVALUE(xmlData, 'count(//InjuryTypeId)') >0 OR EXTRACTVALUE(xmlData, 'count(//BodyPartId)') >0 
OR EXTRACTVALUE(xmlData, 'count(//BodyAreaId)') >0 OR EXTRACTVALUE(xmlData, 'count(//PersonalInjured)') >0 
OR EXTRACTVALUE(xmlData, 'count(//ContactCodeId)') >0 OR EXTRACTVALUE(xmlData, 'count(//RecordableId)') >0
OR EXTRACTVALUE(xmlData, 'count(//InitialTreatmentId)') >0 OR EXTRACTVALUE(xmlData, 'count(//InjuryExtAgencyId)') >0 
OR EXTRACTVALUE(xmlData, 'count(//LostTimeEnd)') >0 OR EXTRACTVALUE(xmlData, 'count(//TotalDaysOff)') >0 
OR EXTRACTVALUE(xmlData, 'count(//InjuryDescription)') >0 OR EXTRACTVALUE(xmlData, 'count(//AdjustmentDays)') >0
OR EXTRACTVALUE(xmlData, 'count(//LostTimeStart)') >0) THEN
	IF(@injuryFound = FALSE)  THEN
		SET @queryFrom = CONCAT(@queryFrom,'    LEFT JOIN `injury` `inj` ON `inc`.`IncidentId` = `inj`.`IncidentId` ');
	END IF;
	IF(EXTRACTVALUE(xmlData, 'count(//InjuryTypeId)') >0 )THEN 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(distinct  injury_type.InjuryTypeName separator '; ')  ) as InjuryTypeId' );
              SET @queryFrom = CONCAT(@queryFrom,'    left outer join ( `injury_type_injury` join  `injury_type` on  `injury_type`.`InjuryTypeId` = `injury_type_injury`.`InjuryTypeId`)  on  `injury_type_injury`.`InjuryId` = `inj`.`InjuryId`  ');
         
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','InjuryTypeId'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  injury_type.InjuryTypeName ' ,' like '"'%", @Col ,"%'" );
		END IF; 
         
	END IF;
	
	IF(EXTRACTVALUE(xmlData, 'count(//BodyPartId)') >0 )THEN 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(distinct  body_part.BodyPartName separator '; ')  ) as BodyPartId' );
		SET @queryFrom = CONCAT(@queryFrom,'     left outer join ( `body_part_injury` join  `body_part` on `body_part`.`BodyPartId` = `body_part_injury`.`BodyPartId` ) on `body_part_injury`.`InjuryId` = `inj`.`InjuryId` ');
         
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','BodyPartId'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  body_part.BodyPartName ' ,' like '"'%", @Col ,"%'" );
		END IF; 
       
	END IF;
	
	
	IF(EXTRACTVALUE(xmlData, 'count(//BodyAreaId)') >0 )THEN 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(distinct  body_area.BodyAreaName separator '; ')  ) as BodyAreaId' );	
        SET @queryFrom = CONCAT(@queryFrom,'    left outer join (  `body_area_injury` join `body_area` on `body_area`.`BodyAreaId` = `body_area_injury`.`BodyAreaId`) on `body_area_injury`.`InjuryId` = `inj`.`InjuryId`      ');
        
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','BodyAreaId'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  body_area.BodyAreaName ' ,' like '"'%", @Col ,"%'"  );
		END IF; 
        
	END IF;
	
	
	IF(EXTRACTVALUE(xmlData, 'count(//PersonalInjured)') >0 )THEN 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(distinct  `inj`.PersonalInjuredName separator '; ')  ) as PersonalInjured' );	
	
		
	 SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','PersonalInjured'));
	 IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `inj`.`PersonalInjuredName` ' ,' like '"'%", @Col ,"%'" );
	END IF; 
   
    
    END IF;
	
	
	IF(EXTRACTVALUE(xmlData, 'count(//ContactCodeId)') >0 )THEN 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(distinct  contact_code.ContactCodeName separator '; ')  ) as ContactCodeId' );	
        SET @queryFrom = CONCAT(@queryFrom,'    left outer join  `contact_code` on `contact_code`.`ContactCodeId` = `inj`.`ContactCodeId`  ');
         
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','ContactCodeId'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  contact_code.`ContactCodeName` ' ,' like '"'%", @Col ,"%'" );
		END IF; 
         
	END IF;
	
	
	IF(EXTRACTVALUE(xmlData, 'count(//RecordableId)') >0 )THEN 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(distinct  injury_recordable.RecordableName separator '; ')  ) as RecordableId' );	
        SET @queryFrom = CONCAT(@queryFrom,'    left outer join  `injury_recordable` on `injury_recordable`.`RecordableId` = `inj`.`RecordableId` ');        
         
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','RecordableId'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  injury_recordable.`RecordableName` ' ,' like '"'%", @Col ,"%'" );
		END IF; 
        
	END IF;
	
	
	IF(EXTRACTVALUE(xmlData, 'count(//InitialTreatmentId)') >0 )THEN 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(distinct  `initial_treatment`.InitialTreatmentName separator '; ')  ) as InitialTreatmentId' );	
        SET @queryFrom = CONCAT(@queryFrom,'    left outer join  `initial_treatment` on  `initial_treatment`.`InitialTreatmentId` = `inj`.`InitialTreatmentId` ');   
         
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','InitialTreatmentId'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  initial_treatment.`InitialTreatmentName` ' ,' like '"'%", @Col ,"%'" );
		END IF; 
                
	END IF;
	
	
	IF(EXTRACTVALUE(xmlData, 'count(//InjuryExtAgencyId)') >0 )THEN 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(distinct  contact_agency.ContactAgencyName separator '; ')  ) as InjuryExtAgencyId' );	
        SET @queryFrom = CONCAT(@queryFrom,'    left outer join  `contact_agency` on  `contact_agency`.`ContactAgencyId` = `inj`.`ContactAgencyId` ');   	
    
      SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','InjuryExtAgencyId'));
		 IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `contact_agency`.`ContactAgencyName` ' ,' like '"'%", @Col ,"%'" );
		END IF;
    
    END IF;
	
	
	IF(EXTRACTVALUE(xmlData, 'count(//AdjustmentDays)') >0 )THEN 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(`inj`.AdjustmentDays separator '; ')  ) as AdjustmentDays' );	
		
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','AdjustmentDays'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `inj`.`AdjustmentDays` ' ,' like '"'%", @Col ,"%'"   );
		END IF;
		
	END IF;
	
	
	IF(EXTRACTVALUE(xmlData, 'count(//TotalDaysOff)') >0 )THEN 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(`inj`.TotalDaysOff separator '; ')  ) as TotalDaysOff' );	
		
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','TotalDaysOff'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `inj`.`TotalDaysOff` ' ,' like '"'%", @Col ,"%'"  );
		END IF;
		
	END IF;
	
	
	IF(EXTRACTVALUE(xmlData, 'count(//InjuryDescription)') >0 )THEN 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(`inj`.InjuryDescription separator '; ')  ) as InjuryDescription' );	
		
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','InjuryDescription'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `inj`.`InjuryDescription` ' ,' like '"'%", @Col ,"%'" );
		END IF;
		
	END IF;
	
	
	IF(EXTRACTVALUE(xmlData, 'count(//LostTimeEnd)') >0 )THEN 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(date_format(`inj`.LostTimeEnd,'%m/%d/%Y') separator '; ')  ) as LostTimeEnd' );	
	END IF;
	
	
	IF(EXTRACTVALUE(xmlData, 'count(//LostTimeStart)') >0 )THEN 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(date_format(`inj`.LostTimeStart,'%m/%d/%Y') separator '; ')  ) as LostTimeStart' );	
	END IF;
	
END IF;
/* Illness part   */
IF(EXTRACTVALUE(xmlData, 'count(//IllnessDescription)') >0 OR EXTRACTVALUE(xmlData, 'count(//Illness_RestrictedWorkId)') >0 
OR EXTRACTVALUE(xmlData, 'count(//Illness_PersonalInjured)') >0 OR EXTRACTVALUE(xmlData, 'count(//Illness_InitialTreatmentId)') >0 
OR EXTRACTVALUE(xmlData, 'count(//ContactCodeId)') >0 OR EXTRACTVALUE(xmlData, 'count(//RecordableId)') >0
OR EXTRACTVALUE(xmlData, 'count(//Illness_AdjustmentDays)') >0 OR EXTRACTVALUE(xmlData, 'count(//Illness_AdjustmentDays)') >0 
OR EXTRACTVALUE(xmlData, 'count(//Illness_LostTimeEnd)') >0 OR EXTRACTVALUE(xmlData, 'count(//Illness_LostTimeStart)') >0 
OR EXTRACTVALUE(xmlData, 'count(//Illness_TotalDaysOff)') >0 OR EXTRACTVALUE(xmlData, 'count(//SymptomsId)') >0 ) THEN
	
	
	-- SET @queryFrom = CONCAT(@queryFrom,'    left outer join illness on illness.IncidentId = inc.IncidentId  ');
	IF(@illnessFound = FALSE)  THEN
		SET @queryFrom = CONCAT(@queryFrom,'    LEFT JOIN `illness` `ill` ON `inc`.`IncidentId` = `ill`.`IncidentId` ');
	END IF;
	
	
	IF(EXTRACTVALUE(xmlData, 'count(//IllnessDescription)') >0 )THEN 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(ill.IllnessDescription separator '; ') ) as IllnessDescription' );	
         
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','IllnessDescription'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  ill.IllnessDescription ' ,' like '"'%", @Col ,"%'" );
		END IF; 
         
	END IF;
	
	IF(EXTRACTVALUE(xmlData, 'count(//Illness_RestrictedWorkId)') >0 )THEN 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(distinct  `restricted_work`.RestrictedWorkName separator '; ') ) as Illness_RestrictedWorkId' );	
        SET @queryFrom = CONCAT(@queryFrom,'    left outer join restricted_work on `restricted_work`.`RestrictedWorkId` = `ill`.`RestrictedWorkId` ');
         
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','Illness_RestrictedWorkId'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `restricted_work`.`RestrictedWorkName` ' ,' like '"'%", @Col ,"%'" );
		END IF; 
         
	END IF;
	
	
	IF(EXTRACTVALUE(xmlData, 'count(//Illness_PersonalInjured)') >0 )THEN 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(distinct  ill.PersonalAfflictedName separator '; ') ) as Illness_PersonalInjured' );	
         
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','Illness_PersonalInjured'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `ill`.`PersonalAfflictedName` ' ,' like '"'%", @Col ,"%'" );
		END IF; 
         
	END IF;
	
	
	IF(EXTRACTVALUE(xmlData, 'count(//Illness_InitialTreatmentId)') >0 )THEN 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(distinct  `illt`.InitialTreatmentName separator '; '))  as Illness_InitialTreatmentId' );
        SET @queryFrom = CONCAT(@queryFrom,'    left outer join initial_treatment  illt on `illt`.`InitialTreatmentId` = `ill`.`InitialTreatmentId` ');
         
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','Illness_InitialTreatmentId'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `illt`.`InitialTreatmentName` ' ,' like '"'%", @Col ,"%'" );
		END IF; 
         
	END IF;
	
	IF(EXTRACTVALUE(xmlData, 'count(//Illness_AdjustmentDays)') >0 )THEN 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(`ill`.AdjustmentDays separator '; ') ) as Illness_AdjustmentDays' );	
         
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','Illness_AdjustmentDays'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `ill`.`AdjustmentDays` ' ,' like '"'%", @Col ,"%'" );
		END IF; 
         
	END IF;
	
	
	IF(EXTRACTVALUE(xmlData, 'count(//SymptomsId)') >0 )THEN 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(`symptoms`.`Description` separator '; ') ) as SymptomsId' );	
		SET @queryFrom = CONCAT(@queryFrom,'    left outer join ( illness_symptoms  join symptoms on symptoms.SymptomsId = illness_symptoms.SymptomsId) on `illness_symptoms`.`IllnessId` = `ill`.`IllnessId` ');
         
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','SymptomsId'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `symptoms`.`Description` ' ,' like '"'%", @Col ,"%'" );
		END IF; 
                  
	END IF;
	
	IF(EXTRACTVALUE(xmlData, 'count(//Illness_TotalDaysOff)') >0 )THEN 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(`ill`.TotalDaysOff separator '; ') ) as Illness_TotalDaysOff' );	
         
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','Illness_TotalDaysOff'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `ill`.`TotalDaysOff` ' ,' like '"'%", @Col ,"%'");
		END IF; 
                
	END IF;
	
	
	IF(EXTRACTVALUE(xmlData, 'count(//Illness_LostTimeEnd)') >0 )THEN 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(date_format(`ill`.LostTimeEnd,'%m/%d/%Y') separator '; ') ) as Illness_LostTimeEnd' );	
	END IF;
	
	
	IF(EXTRACTVALUE(xmlData, 'count(//Illness_LostTimeStart)') >0 )THEN 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(date_format(`ill`.LostTimeStart,'%m/%d/%Y') separator '; ') ) as Illness_LostTimeStart' );	
	END IF;
	
END IF;
/* traffic_violation part   */
IF(EXTRACTVALUE(xmlData, 'count(//TrafficDriverName)') >0 OR EXTRACTVALUE(xmlData, 'count(//TrafficDriverLicence)') >0 
OR EXTRACTVALUE(xmlData, 'count(//TrafficVehicleTypeId)') >0 OR EXTRACTVALUE(xmlData, 'count(//TrafficVehicleLicence)') >0 
OR EXTRACTVALUE(xmlData, 'count(//Details)') >0 OR EXTRACTVALUE(xmlData, 'count(//ValueOfFine)') >0
OR EXTRACTVALUE(xmlData, 'count(//TicketNumber)') >0 OR EXTRACTVALUE(xmlData, 'count(//HowDidThatOccur)') >0   ) THEN
	
	
	-- SET @queryFrom = CONCAT(@queryFrom,'    left outer join traffic_violation on traffic_violation.IncidentId = inc.IncidentId  ');
	IF(@trafficFound = FALSE)  THEN
		SET @queryFrom = CONCAT(@queryFrom,'    LEFT JOIN `traffic_violation` `tv` ON `inc`.`IncidentId` = `tv`.`IncidentId` ');
	END IF;
	
	IF(EXTRACTVALUE(xmlData, 'count(//TrafficDriverName)') >0 )THEN 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(distinct  `tv`.DriverName separator '; ')  ) as TrafficDriverName' );	
         
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','TrafficDriverName'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `tv`.`DriverName` ' ,' like '"'%", @Col ,"%'" );
		END IF; 
                  
	END IF;
	
	IF(EXTRACTVALUE(xmlData, 'count(//TrafficDriverLicence)') >0 )THEN 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(`tv`.DriverLicence separator '; ')  ) as TrafficDriverLicence' );	
         
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','TrafficDriverLicence'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `tv`.`DriverLicence` ' ,' like '"'%", @Col ,"%'" );
		END IF; 
            
	END IF;
	
	IF(EXTRACTVALUE(xmlData, 'count(//TrafficVehicleTypeId)') >0 )THEN 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(distinct  tvt.VehicleTypeName separator '; ')  ) as TrafficVehicleTypeId' );	
        SET @queryFrom = CONCAT(@queryFrom,'    left outer join vehicle_type tvt on `tvt`.`VehicleTypeId` = `tv`.`VehicleTypeId` ');	
         
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','TrafficVehicleTypeId'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `tvt`.`VehicleTypeName` ' ,' like '"'%", @Col ,"%'" );
		END IF; 
        
	END IF;
	
	
	IF(EXTRACTVALUE(xmlData, 'count(//TrafficVehicleLicence)') >0 )THEN 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(`tv`.VehicleLicence separator '; ')  ) as TrafficVehicleLicence' );	
         
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','TrafficVehicleLicence'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `tv`.`VehicleLicence` ' ,' like '"'%", @Col ,"%'" );
		END IF; 
        
	END IF;
	
	IF(EXTRACTVALUE(xmlData, 'count(//Details)') >0 )THEN 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(`tv`.Details separator '; ')  ) as Details' );	
         
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','Details'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `tv`.`Details` ' ,' like '"'%", @Col ,"%'" );
		END IF; 
        
	END IF;
	
	IF(EXTRACTVALUE(xmlData, 'count(//ValueOfFine)') >0 )THEN 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(`tv`.ValueOfFine separator '; ')  ) as ValueOfFine' );	
         
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','ValueOfFine'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `tv`.`ValueOfFine` ' ,' like '"'%", @Col ,"%'" );
		END IF; 
        
	END IF;
	
	IF(EXTRACTVALUE(xmlData, 'count(//TicketNumber)') >0 )THEN 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(`tv`.TicketNumber separator '; ')  ) as TicketNumber' );
         
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','TicketNumber'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `tv`.`TicketNumber` ' ,' like '"'%", @Col ,"%'" );
		END IF; 
        	
	END IF;
	
	IF(EXTRACTVALUE(xmlData, 'count(//HowDidThatOccur)') >0 )THEN 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(`tv`.HowDidThatOccur separator '; ')  ) as HowDidThatOccur' );	
         
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','HowDidThatOccur'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `tv`.`HowDidThatOccur` ' ,' like '"'%", @Col ,"%'" );
		END IF; 
        	
	END IF;
	
END IF;
/* vehicle_damage part   */
IF(EXTRACTVALUE(xmlData, 'count(//DamageDriverName)') >0 OR EXTRACTVALUE(xmlData, 'count(//DamageDriverLicence)') >0 
OR EXTRACTVALUE(xmlData, 'count(//DamageVehicleTypeId)') >0 OR EXTRACTVALUE(xmlData, 'count(//DamageVehicleLicence)') >0 
OR EXTRACTVALUE(xmlData, 'count(//HowDidThatDone)') >0 OR EXTRACTVALUE(xmlData, 'count(//DamageDescription)') >0 ) THEN
	-- SET @queryFrom = CONCAT(@queryFrom,'    left outer join vehicle_damage on `vd`.IncidentId = inc.IncidentId  ');
	
	IF(@vehicleFound = FALSE)  THEN
		SET @queryFrom = CONCAT(@queryFrom,'    LEFT JOIN `vehicle_damage` `vd` ON `inc`.`IncidentId` = `vd`.`IncidentId` ');
	END IF;
	
	IF(EXTRACTVALUE(xmlData, 'count(//DamageDriverName)') >0 )THEN 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(distinct  `vd`.DriverName separator '; ') ) as DamageDriverName' );	
	
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','DamageDriverName'));
		 IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `vd`.DriverName ' ,' like '"'%", @Col ,"%'" );
		END IF;   
    
    END IF;
	
	IF(EXTRACTVALUE(xmlData, 'count(//DamageDriverLicence)') >0 )THEN 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(`vd`.DriverLicence separator '; ') ) as DamageDriverLicence' );	
        
        SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','DamageDriverLicence'));
		 IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `vd`.DriverLicence  ' ,' like '"'%", @Col ,"%'" );
		END IF;   
       
        
	END IF;
	
	IF(EXTRACTVALUE(xmlData, 'count(//DamageVehicleTypeId)') >0 )THEN 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(distinct  dvt.VehicleTypeName separator '; ') ) as DamageVehicleTypeId' );	
		SET @queryFrom = CONCAT(@queryFrom,'    left outer join vehicle_type dvt on `dvt`.`VehicleTypeId` = `vd`.`VehicleTypeId` ');
        
        
		 SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','DamageVehicleTypeId'));
		 IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  dvt.VehicleTypeName  ' ,' like '"'%", @Col ,"%'" );
		END IF;   
       
       
         
	END IF;	
	
	IF(EXTRACTVALUE(xmlData, 'count(//DamageVehicleLicence)') >0 )THEN 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(`vd`.VehicleLicence separator '; ') ) as DamageVehicleLicence' );	
        
        SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','DamageVehicleLicence'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `vd`.VehicleLicence  ' ,' like '"'%", @Col ,"%'" );
		END IF;   
        
	END IF;
	
	IF(EXTRACTVALUE(xmlData, 'count(//HowDidThatDone)') >0 )THEN 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(`vd`.HowDidThatDone separator '; ') ) as HowDidThatDone' );	
	END IF;
	
	IF(EXTRACTVALUE(xmlData, 'count(//DamageDescription)') >0 )THEN 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat( `vd`.DamageDescription separator '; ') ) as DamageDescription' );	
          
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','DamageDescription'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `vd`.DamageDescription   ' ,' like '"'%", @Col ,"%'" );
		END IF; 
        
	END IF;	
	
END IF;
/* spill_release part   */
IF(EXTRACTVALUE(xmlData, 'count(//SourceId)') >0 OR EXTRACTVALUE(xmlData, 'count(//DurationValue)') >0 
OR EXTRACTVALUE(xmlData, 'count(//DurationUnitId)') >0 OR EXTRACTVALUE(xmlData, 'count(//QuantityValue)') >0 
OR EXTRACTVALUE(xmlData, 'count(//QuantityUnitId)') >0 OR EXTRACTVALUE(xmlData, 'count(//QuantityRecoveredValue)') >0 
OR EXTRACTVALUE(xmlData, 'count(//RecoveredUnitId)') >0 OR EXTRACTVALUE(xmlData, 'count(//WhatWasIt)') >0 OR EXTRACTVALUE(xmlData, 'count(//HowDidSROccur)') >0 
OR EXTRACTVALUE(xmlData, 'count(//IsReportable)') >0 OR EXTRACTVALUE(xmlData, 'count(//ImpactsExtAgencyId)') >0 ) THEN
	-- SET @queryFrom = CONCAT(@queryFrom,'    left outer join spill_release on `sp`.IncidentId = inc.IncidentId  ');
	
	IF(@spillFound = FALSE)  THEN
		SET @queryFrom = CONCAT(@queryFrom,'    LEFT JOIN `spill_release` `sp` ON `inc`.`IncidentId` = `sp`.`IncidentId` ');
	END IF;
	
	
	IF(EXTRACTVALUE(xmlData, 'count(//SourceId)') >0 )THEN 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(distinct  spill_release_source.`SourceName` separator '; ') ) as SourceId' );	
        SET @queryFrom = CONCAT(@queryFrom,'    left outer join spill_release_source on `spill_release_source`.`SourceId` = `sp`.`SourceId`  ');
          
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','SourceId'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  spill_release_source.SourceName   ' ,' like '"'%", 	@Col ,"%'" );
		END IF; 
        
	END IF;
	
	IF(EXTRACTVALUE(xmlData, 'count(//DurationValue)') >0 )THEN 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(`sp`.DurationValue separator '; ')  ) as DurationValue' );	
          
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','DurationValue'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `sp`.DurationValue   ' ,' like '"'%", @Col ,"%'" );
		END IF; 
        
	END IF;
	
	IF(EXTRACTVALUE(xmlData, 'count(//DurationUnitId)') >0 )THEN 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(distinct  `duration_unit`.`DurationUnitName` separator '; ')  ) as DurationUnitId' );	
        SET @queryFrom = CONCAT(@queryFrom,'    left outer join `duration_unit` ON  `duration_unit`.`DurationUnitId` = `sp`.`DurationUnitId`  ');
          
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','DurationUnitId'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  duration_unit.DurationUnitName   ' ,' like '"'%", @Col ,"%'" );
		END IF; 
        
	END IF;
	
	
	IF(EXTRACTVALUE(xmlData, 'count(//QuantityValue)') >0 )THEN 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(  DISTINCT  `sp`.QuantityValue separator '; ')  ) as QuantityValue' );	
          
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','QuantityValue'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `sp`.QuantityValue   ' ,' like '"'%", @Col ,"%'" );
		END IF; 
        
	END IF;
	
	IF(EXTRACTVALUE(xmlData, 'count(//QuantityUnitId)') >0 )THEN 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat( distinct  `quq`.`QuantityUnitName` separator '; ') )  as QuantityUnitId' );	
        SET @queryFrom = CONCAT(@queryFrom,'    left outer join `quantity_unit` quq ON  `quq`.`QuantityUnitId` = `sp`.`QuantityUnitId` ');
          
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','QuantityUnitId'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  quq.QuantityUnitName   ' ,' like '"'%", @Col ,"%'" );
		END IF; 
        
	END IF;
	
	IF(EXTRACTVALUE(xmlData, 'count(//QuantityRecoveredValue)') >0 )THEN 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat( DISTINCT  `sp`.QuantityRecoveredValue separator '; ')  ) as QuantityRecoveredValue' );
          
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','QuantityRecoveredValue'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `sp`.QuantityRecoveredValue   ' ,' like '"'%", @Col ,"%'" );
		END IF; 
        	
	END IF;	
	
	IF(EXTRACTVALUE(xmlData, 'count(//RecoveredUnitId)') >0 )THEN 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(distinct  `quantity_recovered`.`QuantityUnitName` separator '; ')  ) as RecoveredUnitId' );
        SET @queryFrom = CONCAT(@queryFrom,'    left outer join `quantity_unit` `quantity_recovered` ON `quantity_recovered`.`QuantityUnitId` = `sp`.`RecoveredUnitId` ');
          
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','RecoveredUnitId'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  quantity_recovered.QuantityUnitName   ' ,' like '"'%", @Col ,"%'" );
		END IF; 
        
	END IF;
	
	IF(EXTRACTVALUE(xmlData, 'count(//WhatWasIt)') >0 )THEN 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(  DISTINCT   `sp`.WhatWasIt separator '; '  )) as WhatWasIt' );	
          
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','WhatWasIt'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `sp`.WhatWasIt   ' ,' like '"'%", @Col ,"%'" );
		END IF; 
        
	END IF;
	
	IF(EXTRACTVALUE(xmlData, 'count(//HowDidSROccur)') >0 )THEN 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat( DISTINCT  `sp`.HowDidSROccur separator '; '  )) as HowDidSROccur' );	
          
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','HowDidSROccur'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `sp`.HowDidSROccur   ' ,' like '"'%", @Col ,"%'" );
		END IF; 
        
	END IF;
	
	IF(EXTRACTVALUE(xmlData, 'count(//IsReportable)') >0 )THEN 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(  DISTINCT  case `sp`.`IsReportable`  WHEN '0' THEN 'No'   WHEN '1' THEN 'Yes' END separator '; ') )  as IsReportable' );	
          
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','IsReportable'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryhave = CONCAT(@queryhave,'  and  IsReportable   ' ,' like '"'%", @Col ,"%'" );
		END IF; 
        
	END IF;
	
	IF(EXTRACTVALUE(xmlData, 'count(//ImpactsExtAgencyId)') >0 )THEN 	
		SET @selectquery = CONCAT(@selectquery,', ( group_concat(distinct  `sp_rel_agency`.`SpRelAgencyName` separator '; ') ) as ImpactsExtAgencyId' );	
        SET @queryFrom = CONCAT(@queryFrom,'    left outer join `sp_rel_agency` ON `sp_rel_agency`.`SpRelAgencyId` = `sp`.`SpRelAgencyId` ');
		
        
		SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//','ImpactsExtAgencyId'));
		IF (@Col != '' AND @Col !='NULL') THEN	 
			SET @queryWhere = CONCAT(@queryWhere,'  and  `sp_rel_agency`.`SpRelAgencyName`   ' ,' like '"'%", @Col ,"%'" );
		END IF; 
        
	END IF;
	
END IF;
 -- select @selectquery;
/* search part*/
  SET@myArrayOfValue='HowDidThatDone,DamageDescription,VersionNumber,IncidentNumber,EventTypeId,CreatorName,IncidentHour,IncidentMinute,RepName,RepEmail,RepPosition,RepCompany,RepPrimaryPhone,RepAlternatePhone,Location1Id,Location2Id,Location3Id,Location4Id,OtherLocation,EventSequence,EnvConditionNote,IncDescription,FilledByName,EnergyFormNote,SubStandardActionNote,SubStandardConditionNote,UnderLyingCauseNote,InvStatusId,InvestigatorName1,InvestigatorName2,InvestigatorName3,OtherRootCause,InvSummary,FollowUpNote,IncidentSeverityId,SourceDetails,RootCauseNote,UpdatedByName,RiskOfRecurrenceId,OperationTypeId,';
  
  
 SET @Postition = LOCATE(',', @myArrayOfValue);
WHILE ( @Postition > 0 ) DO
 SET @STR = SUBSTRING(@myArrayOfValue, 1, @Postition-1);
 SET @STR= TRIM(@STR);
 
 SET @myArrayOfValue = SUBSTRING(@myArrayOfValue, @Postition + 1);
 SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//',@STR));
	IF (@Col != '' AND @Col !='NULL') THEN
  
	
    IF (@STR  = 'CreatorName' ) THEN SET @STR= 'concat (empCreator.FirstName," ",empCreator.LastName) '; END IF;
	IF (@STR  = 'IncidentId' ) THEN SET @STR= 'inc.IncidentId';  END IF;
	IF (@STR  = 'Location1Id' ) THEN SET @STR= 'location1.Location1Name'; END IF;
	IF (@STR  = 'Location2Id' ) THEN SET @STR= 'location2.Location2Name';  END IF;
	IF (@STR  = 'Location3Id' ) THEN SET @STR= 'location3.Location3Name'; END IF;
	IF (@STR  = 'Location4Id' ) THEN SET @STR= 'location4.Location4Name'; END IF; 
	IF (@STR  = 'OperationTypeId' ) THEN SET @STR= 'operation_type.OperationTypeName';  END IF;
	IF (@STR  = 'RiskOfRecurrenceId' ) THEN SET @STR= 'risk_of_recurrence.RiskOfRecurrenceName';  END IF;
	IF (@STR  = 'IncidentSeverityId' ) THEN SET @STR= 'incident_severity.IncidentSeverityName';  END IF;
	IF (@STR  = 'InvStatusId') THEN SET@STR='inv_status.InvStatusName';  END IF;	
	IF (@STR  = 'EventTypeId' ) THEN SET @STR= 'event_type.EventTypeName';  END IF;	
	
    IF (@STR  = 'IncidentId'  OR @STR  = 'IncidentDate'  OR @STR  = 'IncidentHour'  OR @STR  = 'IncidentMinute'  
		OR @STR  = 'RepName'  OR @STR  = 'RepEmail'  OR @STR  = 'RepPosition'  OR @STR  = 'RepCompany'  OR @STR  = 'RepPrimaryPhone'  
        OR @STR  = 'RepAlternatePhone'  OR @STR  = 'OtherLocation'  OR @STR  = 'EventSequence'  OR @STR  = 'EnvConditionNote'  
        OR @STR  = 'IncDescription'  OR @STR  = 'EnergyFormNote'  OR @STR  = 'SubStorardActionNote'  OR @STR  = 'SubStorardConditionNote'  
        OR @STR  = 'UnderLyingCauseNote'  OR @STR  = 'InvestigationDate'  OR @STR  = 'InvestigatorName1'  OR @STR  = 'InvestigatorName2'  
        OR @STR  = 'InvestigatorName3'  OR @STR  = 'InvSummary'  OR @STR  = 'FollowUpNote'  OR @STR  = 'ResponseCost'  
        OR @STR  = 'RepairCost'  OR @STR  = 'InsuranceCost'  OR @STR  = 'WCBCost'  OR @STR  = 'OtherCost'  OR @STR  = 'TotalCost'  
        OR @STR  = 'SourceDetails'  OR @STR  = 'RootCauseNote'  OR @STR  = 'SignOffInvestigatorName'  OR @STR  = 'SignOffDate'  
        OR @STR  = 'IncidentNumber' )THEN 
   
	   SET @STR=  CONCAT('inc.' , @STR);
	END IF;	
	IF (@STR  = 'UpdatedByName' ) THEN 
		SET @STR= CONCAT('CONCAT',' (','empModifier.FirstName,',"'","  '" ,',empModifier.LastName',') '); 
    END IF;
	
    
	SET @queryWhere = CONCAT(@queryWhere,CONCAT(' AND ',@STR,' like '"'%", @Col ,"%'" )); 
 END IF;
 
	SET @Postition = LOCATE(',', @myArrayOfValue);
END WHILE;
 
SET @LostTimeStartFrom =  EXTRACTVALUE(xmlData, '//LostTimeStartFrom');
SET @LostTimeStartTo =  EXTRACTVALUE(xmlData, '//LostTimeStartTo');
IF(@LostTimeStartTo != '') THEN
	SET @LostTimeStartFrom  = STR_TO_DATE(@LostTimeStartFrom , '%m/%d/%Y');
	SET @LostTimeStartTo  = STR_TO_DATE(@LostTimeStartTo , '%m/%d/%Y');
	SET @LostTimeStartTo2 = DATE_ADD(@LostTimeStartTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND `inj`.LostTimeStart >= ', "'" , @LostTimeStartFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND `inj`.LostTimeStart < ', "'",  @LostTimeStartTo2  ,"'" );										
ELSE 
IF(@LostTimeStartTo = '' AND @LostTimeStartFrom !='' ) THEN
	SET @LostTimeStartFrom  = STR_TO_DATE(@LostTimeStartFrom , '%m/%d/%Y');
	SET @LostTimeStartFrom2 = DATE_ADD(@LostTimeStartFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND `inj`.LostTimeStart >=  ',  "'", @LostTimeStartFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND `inj`.LostTimeStart <  ', "'", @LostTimeStartFrom2  ,"'");	
END IF;
END IF;
SET @LostTimeEndFrom =  EXTRACTVALUE(xmlData, '//LostTimeEndFrom');
SET @LostTimeEndTo =  EXTRACTVALUE(xmlData, '//LostTimeEndTo');
IF(@LostTimeEndTo != '') THEN
	SET @LostTimeEndFrom  = STR_TO_DATE(@LostTimeEndFrom , '%m/%d/%Y');
	SET @LostTimeEndTo  = STR_TO_DATE(@LostTimeEndTo , '%m/%d/%Y');
	SET @LostTimeEndTo2 = DATE_ADD(@LostTimeEndTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND `inj`.LostTimeEnd >= ', "'" , @LostTimeEndFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND `inj`.LostTimeEnd < ', "'",  @LostTimeEndTo2  ,"'" );										
ELSE 
IF(@LostTimeEndTo = '' AND @LostTimeEndFrom !='' ) THEN
	SET @LostTimeEndFrom  = STR_TO_DATE(@LostTimeEndFrom , '%m/%d/%Y');
	SET @LostTimeEndFrom2 = DATE_ADD(@LostTimeEndFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND `inj`.LostTimeEnd >=  ',  "'", @LostTimeEndFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND `inj`.LostTimeEnd <  ', "'", @LostTimeEndFrom2  ,"'");	
END IF;
END IF;
SET @Illness_LostTimeStartFrom =  EXTRACTVALUE(xmlData, '//Illness_LostTimeStartFrom');
SET @Illness_LostTimeStartTo =  EXTRACTVALUE(xmlData, '//Illness_LostTimeStartTo');
IF(@Illness_LostTimeStartTo != '') THEN
	SET @Illness_LostTimeStartFrom  = STR_TO_DATE(@Illness_LostTimeStartFrom , '%m/%d/%Y');
	SET @Illness_LostTimeStartTo  = STR_TO_DATE(@Illness_LostTimeStartTo , '%m/%d/%Y');
	SET @Illness_LostTimeStartTo2 = DATE_ADD(@Illness_LostTimeStartTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND illness.LostTimeStart >= ', "'" , @Illness_LostTimeStartFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND illness.LostTimeStart < ', "'",  @Illness_LostTimeStartTo2  ,"'" );										
ELSE 
IF(@Illness_LostTimeStartTo = '' AND @Illness_LostTimeStartFrom !='' ) THEN
	SET @Illness_LostTimeStartFrom  = STR_TO_DATE(@Illness_LostTimeStartFrom , '%m/%d/%Y');
	SET @Illness_LostTimeStartFrom2 = DATE_ADD(@Illness_LostTimeStartFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND illness.LostTimeStart >=  ',  "'", @Illness_LostTimeStartFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND illness.LostTimeStart <  ', "'", @Illness_LostTimeStartFrom2  ,"'");	
END IF;
END IF;
SET @Illness_LostTimeEndFrom =  EXTRACTVALUE(xmlData, '//Illness_LostTimeEndFrom');
SET @Illness_LostTimeEndTo =  EXTRACTVALUE(xmlData, '//Illness_LostTimeEndTo');
IF(@Illness_LostTimeEndTo != '') THEN
	SET @Illness_LostTimeEndFrom  = STR_TO_DATE(@Illness_LostTimeEndFrom , '%m/%d/%Y');
	SET @Illness_LostTimeEndTo  = STR_TO_DATE(@Illness_LostTimeEndTo , '%m/%d/%Y');
	SET @Illness_LostTimeEndTo2 = DATE_ADD(@Illness_LostTimeEndTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND illness.LostTimeEnd >= ', "'" , @Illness_LostTimeEndFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND illness.LostTimeEnd < ', "'",  @Illness_LostTimeEndTo2  ,"'" );										
ELSE 
IF(@Illness_LostTimeEndTo = '' AND @Illness_LostTimeEndFrom !='' ) THEN
	SET @Illness_LostTimeEndFrom  = STR_TO_DATE(@Illness_LostTimeEndFrom , '%m/%d/%Y');
	SET @Illness_LostTimeEndFrom2 = DATE_ADD(@Illness_LostTimeEndFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND illness.LostTimeEnd >=  ',  "'", @Illness_LostTimeEndFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND illness.LostTimeEnd <  ', "'", @Illness_LostTimeEndFrom2  ,"'");	
END IF;
END IF;
SET @StartDateFrom =  EXTRACTVALUE(xmlData, '//StartDateFrom');
SET @StartDateTo =  EXTRACTVALUE(xmlData, '//StartDateTo');
IF(@StartDateTo != '') THEN
	SET @StartDateFrom  = STR_TO_DATE(@StartDateFrom , '%m/%d/%Y');
	SET @StartDateTo  = STR_TO_DATE(@StartDateTo , '%m/%d/%Y');
	SET @StartDateTo2 = DATE_ADD(@StartDateTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND ca.StartDate >= ', "'" , @StartDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND ca.StartDate < ', "'",  @StartDateTo2  ,"'" );										
ELSE 
IF(@StartDateTo = '' AND @StartDateFrom !='' ) THEN
	SET @StartDateFrom  = STR_TO_DATE(@StartDateFrom , '%m/%d/%Y');
	SET @StartDateFrom2 = DATE_ADD(@StartDateFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND ca.StartDate >=  ',  "'", @StartDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND ca.StartDate <  ', "'", @StartDateFrom2  ,"'");	
END IF;
END IF;
SET @TargetEndDateFrom =  EXTRACTVALUE(xmlData, '//TargetEndDateFrom');
SET @TargetEndDateTo =  EXTRACTVALUE(xmlData, '//TargetEndDateTo');
IF(@TargetEndDateTo != '') THEN
	SET @TargetEndDateFrom  = STR_TO_DATE(@TargetEndDateFrom , '%m/%d/%Y');
	SET @TargetEndDateTo  = STR_TO_DATE(@TargetEndDateTo , '%m/%d/%Y');
	SET @TargetEndDateTo2 = DATE_ADD(@TargetEndDateTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND ca.TargetEndDate >= ', "'" , @TargetEndDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND ca.TargetEndDate < ', "'",  @TargetEndDateTo2  ,"'" );										
ELSE 
IF(@TargetEndDateTo = '' AND @TargetEndDateFrom !='' ) THEN
	SET @TargetEndDateFrom  = STR_TO_DATE(@TargetEndDateFrom , '%m/%d/%Y');
	SET @TargetEndDateFrom2 = DATE_ADD(@TargetEndDateFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND ca.TargetEndDate >=  ',  "'", @TargetEndDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND ca.TargetEndDate <  ', "'", @TargetEndDateFrom2  ,"'");	
END IF;
END IF;
SET @ActualEndDateFrom =  EXTRACTVALUE(xmlData, '//ActualEndDateFrom');
SET @ActualEndDateTo =  EXTRACTVALUE(xmlData, '//ActualEndDateTo');
IF(@ActualEndDateTo != '') THEN
	SET @ActualEndDateFrom  = STR_TO_DATE(@ActualEndDateFrom , '%m/%d/%Y');
	SET @ActualEndDateTo  = STR_TO_DATE(@ActualEndDateTo , '%m/%d/%Y');
	SET @ActualEndDateTo2 = DATE_ADD(@ActualEndDateTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND ca.ActualEndDate >=  ', "'" , @ActualEndDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND ca.ActualEndDate <  ', "'",  @ActualEndDateTo2  ,"'" );										
ELSE 
IF(@ActualEndDateTo = '' AND @ActualEndDateFrom !='' ) THEN
	SET @ActualEndDateFrom  = STR_TO_DATE(@ActualEndDateFrom , '%m/%d/%Y');
	SET @ActualEndDateFrom2 = DATE_ADD(@ActualEndDateFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND ca.ActualEndDate >=  ',  "'", @ActualEndDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND ca.ActualEndDate <  ', "'", @ActualEndDateFrom2  ,"'");	
END IF;
END IF;
SET @IncidentDateFrom =  EXTRACTVALUE(xmlData, '//IncidentDateFrom');
SET @IncidentDateTo =  EXTRACTVALUE(xmlData, '//IncidentDateTo');
IF(@IncidentDateTo != '') THEN
	SET @IncidentDateFrom  = STR_TO_DATE(@IncidentDateFrom , '%m/%d/%Y');
	SET @IncidentDateTo  = STR_TO_DATE(@IncidentDateTo , '%m/%d/%Y');
	SET @IncidentDateTo2 = DATE_ADD(@IncidentDateTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND inc.IncidentDate >=  ', "'" , @IncidentDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND inc.IncidentDate <  ', "'",  @IncidentDateTo2  ,"'" );										
ELSE 
IF(@IncidentDateTo = '' AND @IncidentDateFrom !='' ) THEN
	SET @IncidentDateFrom  = STR_TO_DATE(@IncidentDateFrom , '%m/%d/%Y');
	SET @IncidentDateFrom2 = DATE_ADD(@IncidentDateFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND inc.IncidentDate >=  ',  "'", @IncidentDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND inc.IncidentDate <  ', "'", @IncidentDateFrom2  ,"'");	
END IF;
END IF;
SET @InvestigationDateFrom =  EXTRACTVALUE(xmlData, '//InvestigationDateFrom');
SET @InvestigationDateTo =  EXTRACTVALUE(xmlData, '//InvestigationDateTo');
IF(@InvestigationDateTo != '') THEN
	SET @InvestigationDateFrom  = STR_TO_DATE(@InvestigationDateFrom , '%m/%d/%Y');
	SET @InvestigationDateTo  = STR_TO_DATE(@InvestigationDateTo , '%m/%d/%Y');
	SET @InvestigationDateTo2 = DATE_ADD(@InvestigationDateTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND inc.InvestigationDate >=  ', "'" , @InvestigationDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND inc.InvestigationDate < ', "'",  @InvestigationDateTo2  ,"'" );										
ELSE 
IF(@InvestigationDateTo = '' AND @InvestigationDateFrom !='' ) THEN
	SET @InvestigationDateFrom  = STR_TO_DATE(@InvestigationDateFrom , '%m/%d/%Y');
	SET @InvestigationDateFrom2 = DATE_ADD(@InvestigationDateFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND inc.InvestigationDate >=  ',  "'", @InvestigationDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND inc.InvestigationDate <  ', "'", @InvestigationDateFrom2  ,"'");	
END IF;
END IF;
SET @SignOffDateFrom =  EXTRACTVALUE(xmlData, '//SignOffDateFrom');
SET @SignOffDateTo =  EXTRACTVALUE(xmlData, '//SignOffDateTo');
IF(@SignOffDateTo != '') THEN
	SET @SignOffDateFrom  = STR_TO_DATE(@SignOffDateFrom , '%m/%d/%Y');
	SET @SignOffDateTo  = STR_TO_DATE(@SignOffDateTo , '%m/%d/%Y');
	SET @SignOffDateTo2 = DATE_ADD(@SignOffDateTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND inc.SignOffDate >= ', "'" , @SignOffDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND inc.SignOffDate < ', "'",  @SignOffDateTo2  ,"'" );										
ELSE 
IF(@SignOffDateTo = '' AND @SignOffDateFrom !='' ) THEN
	SET @SignOffDateFrom  = STR_TO_DATE(@SignOffDateFrom , '%m/%d/%Y');
	SET @SignOffDateFrom2 = DATE_ADD(@SignOffDateFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND inc.SignOffDate >=  ',  "'", @SignOffDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND inc.SignOffDate <  ', "'", @SignOffDateFrom2  ,"'");	
END IF;
END IF;
SET @TaskEstimatedCostTo =  EXTRACTVALUE(xmlData, '//TaskEstimatedCostTo');
SET @TaskEstimatedCostFrom =  EXTRACTVALUE(xmlData, '//TaskEstimatedCostFrom');
IF( @TaskEstimatedCostTo !='' ) THEN
	SET @queryWhere = CONCAT(@queryWhere,' AND  ca.EstimatedCost  BETWEEN ', @TaskEstimatedCostFrom, ' and ', @TaskEstimatedCostTo);
ELSE 
	IF( @TaskEstimatedCostFrom !=''  AND @TaskEstimatedCostFrom != 'NULL')	 THEN
SET  @TaskEstimatedCostFrom  = (REPLACE(@TaskEstimatedCostFrom, '&lt;', '<'));
SET  @TaskEstimatedCostFrom  = (REPLACE(@TaskEstimatedCostFrom, '&gt;', '>'));
		SET @queryWhere = CONCAT(@queryWhere,' AND  ca.EstimatedCost  ', @TaskEstimatedCostFrom);
	END IF;
END IF;
SET @WCBCostTo =  EXTRACTVALUE(xmlData, '//WCBCostTo');
SET @WCBCostFrom =  EXTRACTVALUE(xmlData, '//WCBCostFrom');
IF( @WCBCostTo !='' ) THEN
	SET @queryWhere = CONCAT(@queryWhere,' AND  inc.WCBCost  BETWEEN ', @WCBCostFrom, ' and ', @WCBCostTo);
ELSE 
	IF( @WCBCostFrom !=''  AND @WCBCostFrom != 'NULL')	 THEN
SET  @WCBCostFrom  = (REPLACE(@WCBCostFrom, '&lt;', '<'));
SET  @WCBCostFrom  = (REPLACE(@WCBCostFrom, '&gt;', '>'));
		SET @queryWhere = CONCAT(@queryWhere,' AND  inc.WCBCost  ', @WCBCostFrom);
	END IF;
END IF;
SET @RepairCostTo =  EXTRACTVALUE(xmlData, '//RepairCostTo');
SET @RepairCostFrom =  EXTRACTVALUE(xmlData, '//RepairCostFrom');
IF( @RepairCostTo !='' ) THEN
	SET @queryWhere = CONCAT(@queryWhere,' AND  inc.RepairCost  BETWEEN ', @RepairCostFrom, ' and ', @RepairCostTo);
ELSE 
	IF( @RepairCostFrom !=''  AND @RepairCostFrom != 'NULL')	 THEN
SET  @RepairCostFrom  = (REPLACE(@RepairCostFrom, '&lt;', '<'));
SET  @RepairCostFrom  = (REPLACE(@RepairCostFrom, '&gt;', '>'));
		SET @queryWhere = CONCAT(@queryWhere,' AND  inc.RepairCost  ', @RepairCostFrom);
	END IF;
END IF;
SET @OtherCostTo =  EXTRACTVALUE(xmlData, '//OtherCostTo');
SET @OtherCostFrom =  EXTRACTVALUE(xmlData, '//OtherCostFrom');
IF( @OtherCostTo !='' ) THEN
	SET @queryWhere = CONCAT(@queryWhere,' AND  inc.OtherCost  BETWEEN ', @OtherCostFrom, ' and ', @OtherCostTo);
ELSE 
	IF( @OtherCostFrom !=''  AND @OtherCostFrom != 'NULL')	 THEN
SET  @OtherCostFrom  = (REPLACE(@OtherCostFrom, '&lt;', '<'));
SET  @OtherCostFrom  = (REPLACE(@OtherCostFrom, '&gt;', '>'));
		SET @queryWhere = CONCAT(@queryWhere,' AND  inc.OtherCost  ', @OtherCostFrom);
	END IF;
END IF;
SET @OtherCostTo =  EXTRACTVALUE(xmlData, '//OtherCostTo');
SET @OtherCostFrom =  EXTRACTVALUE(xmlData, '//OtherCostFrom');
IF( @OtherCostTo !='' ) THEN
	SET @queryWhere = CONCAT(@queryWhere,' AND  inc.OtherCost  BETWEEN ', @OtherCostFrom, ' and ', @OtherCostTo);
ELSE 
	IF( @OtherCostFrom !=''  AND @OtherCostFrom != 'NULL')	 THEN
SET  @OtherCostFrom  = (REPLACE(@OtherCostFrom, '&lt;', '<'));
SET  @OtherCostFrom  = (REPLACE(@OtherCostFrom, '&gt;', '>'));
		SET @queryWhere = CONCAT(@queryWhere,' AND  inc.OtherCost  ', @OtherCostFrom);
	END IF;
END IF;
SET @ResponseCostTo =  EXTRACTVALUE(xmlData, '//ResponseCostTo');
SET @ResponseCostFrom =  EXTRACTVALUE(xmlData, '//ResponseCostFrom');
IF( @ResponseCostTo !='' ) THEN
	SET @queryWhere = CONCAT(@queryWhere,' AND  inc.ResponseCost  BETWEEN ', @ResponseCostFrom, ' and ', @ResponseCostTo);
ELSE 
	IF( @ResponseCostFrom !=''  AND @ResponseCostFrom != 'NULL')	 THEN
SET  @ResponseCostFrom  = (REPLACE(@ResponseCostFrom, '&lt;', '<'));
SET  @ResponseCostFrom  = (REPLACE(@ResponseCostFrom, '&gt;', '>'));
		SET @queryWhere = CONCAT(@queryWhere,' AND  inc.ResponseCost  ', @ResponseCostFrom);
	END IF;
END IF;
SET @TotalCostTo =  EXTRACTVALUE(xmlData, '//TotalCostTo');
SET @TotalCostFrom =  EXTRACTVALUE(xmlData, '//TotalCostFrom');
IF( @TotalCostTo !='' ) THEN
	SET @queryWhere = CONCAT(@queryWhere,' AND  inc.TotalCost  BETWEEN ', @TotalCostFrom, ' and ', @TotalCostTo);
ELSE 
	IF( @TotalCostFrom !=''  AND @TotalCostFrom != 'NULL')	 THEN
SET  @TotalCostFrom  = (REPLACE(@TotalCostFrom, '&lt;', '<'));
SET  @TotalCostFrom  = (REPLACE(@TotalCostFrom, '&gt;', '>'));
		SET @queryWhere = CONCAT(@queryWhere,' AND  inc.TotalCost  ', @TotalCostFrom);
	END IF;
END IF;
SET @IsEmerRP =  EXTRACTVALUE(xmlData, '//IsEmerRP');
IF (@IsEmerRP != '' AND @IsEmerRP !='NULL') THEN
	IF( @IsEmerRP  != '2' ) THEN 
		SET @queryWhere = CONCAT(@queryWhere,'  AND  `inc`.IsEmerRP = ',  @IsEmerRP ); 
	END IF;	
END IF;
SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere, @querygroup, @queryhave );
 
SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere, @querygroup, @queryhave  );
IF(@index  = 'IncidentId'  OR @index  = 'IncidentDate'  OR @index  = 'IncidentHour'  OR @index  = 'IncidentMinute'  OR @index  = 'IsEmerRP'  OR @inde  = 'RepName'  OR @index  = 'RepEmail'  OR @index  = 'RepPosition'  OR @index  = 'RepCompany'  OR @index  = 'RepPrimaryPhone'  OR @index  = 'RepAlternatePhone'  OR @index  = 'OtherLocation'  OR @index  = 'OperationTypeId'  OR @index  = 'EventSequence'  OR @index  = 'EnvConditionNote'  OR @index  = 'IncDescription'  OR @index  = 'EnergyFormNote'  OR @index  = 'SubStorardActionNote'  OR @index  = 'SubStorardConditionNote'  OR @index  = 'UnderLyingCauseNote'  OR @index  = 'InvestigationDate'  OR @index  = 'InvestigatorName1'  OR @index  = 'InvestigatorName2'  OR @index  = 'InvestigatorName3'  OR @index  = 'InvSummary'  OR @index  = 'FollowUpNote'  OR @index  = 'ResponseCost'  OR @index  = 'RepairCost'  OR @index  = 'InsuranceCost'  OR @index  = 'WCBCost'  OR @index  = 'OtherCost'  OR @index  = 'TotalCost'  OR @index  = 'SourceDetails'  OR @index  = 'RootCauseNote'  OR @index  = 'SignOffInvestigatorName'  OR @index  = 'SignOffDate'  OR @index  = 'IncidentNumber' ) THEN
	SET @index=  CONCAT('inc.' , @index);
END IF;
 IF(@index ='Order') THEN	SET @index ='inc.IncidentDate'; END IF; 
IF (@index  = 'inc.Location1Id' ) THEN SET @index= 'location1.Location1Name'; END IF; 
IF (@index  = 'inc.Location2Id' ) THEN SET @index= 'location2.Location2Name'; END IF;  
IF (@index  = 'inc.Location3Id' ) THEN SET @index= 'location3.Location3Name'; END IF; 
IF (@index  = 'inc.Location4Id' ) THEN SET @index= 'location4.Location4Name'; END IF; 
IF (@index  = 'inc.OperationTypeId' ) THEN SET @index= 'operation_type.OperationTypeName'; END IF;  
IF (@index  = 'inc.RiskOfRecurrenceId' ) THEN SET @index= 'risk_of_recurrence.RiskOfRecurrenceName'; END IF;  
IF (@index  = 'inc.IncidentSeverityId' ) THEN SET @index= 'incident_severity.IncidentSeverityName'; END IF;  
IF (@index  = 'inc.InvStatusId') THEN SET@index='inv_status.InvStatusName'; END IF;
SET @query = CONCAT(@query, ' order by ', @index,'  ', @sortOrder);
IF( @Export ="false") THEN
SET @page = (@page - 1) * @limit;
SET @query = CONCAT(@query, ' LIMIT ', @limit ,' OFFSET ',  @page);
END IF;
PREPARE stmt1 FROM @query;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1;
 
SELECT FOUND_ROWS();
END
;
