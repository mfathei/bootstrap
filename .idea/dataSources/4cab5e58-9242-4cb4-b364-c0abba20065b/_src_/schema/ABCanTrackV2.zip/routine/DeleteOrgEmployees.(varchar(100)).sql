CREATE PROCEDURE ABCanTrackV2.DeleteOrgEmployees(IN `$OrgId` VARCHAR(100))
  BEGIN
	DECLARE $Max, $Min VARCHAR(100);
	DECLARE $Count, $CheckExistence INT;
    DECLARE $ExistsInTable TEXT;
    
    
    -- Step1: email_to
	SET $Count = (SELECT COUNT(*) FROM `ABCanTrackV2`.`email_to` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgEmployees',  'email_to', NULL, $Count, 1);
    
	-- ************
	DELETE FROM `ABCanTrackV2`.`email_to` WHERE OrgId = $OrgId;
    -- #
    
    
    -- Step2: email_to_esc
	SET $Count = (SELECT COUNT(*) FROM `ABCanTrackV2`.`email_to_esc` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgEmployees',  'email_to_esc', NULL, $Count, 2);
    
	-- ************
	DELETE FROM `ABCanTrackV2`.`email_to_esc` WHERE OrgId = $OrgId;
    -- #
	
    
    -- Step3: update CommonDB.organization
    UPDATE CommonDB.organization 
	SET SystemAdminId = NULL
	WHERE OrgId = $OrgId;
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgEmployees',  'update CommonDB.organization', NULL, $Count, 2);
    -- #
    
    
    -- Step4: inc_deletion_info
	SET $Count = (SELECT COUNT(*) FROM `ABCanTrackV2`.`inc_deletion_info` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgEmployees',  'inc_deletion_info', NULL, $Count, 4);
    
	-- ************
	DELETE FROM `ABCanTrackV2`.`inc_deletion_info` WHERE OrgId = $OrgId;
    -- #
    
    
    -- Step5: ABCanTrackV2.emp_group
	SET $Count = (SELECT COUNT(*) FROM `ABCanTrackV2`.`emp_group` WHERE GroupId IN (SELECT GroupId FROM ABCanTrackV2.`group` WHERE OrgId = $OrgId));
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgEmployees',  'ABCanTrackV2.emp_group', NULL, $Count, 5);
    
	-- ************
	DELETE FROM `ABCanTrackV2`.`emp_group` WHERE GroupId IN (SELECT GroupId FROM `ABCanTrackV2`.`group` WHERE OrgId = $OrgId);
    -- #
    
    
    -- Step6: CommonDB.emp_group
	SET $Count = (SELECT COUNT(*) FROM `CommonDB`.`emp_group` WHERE GroupId IN (SELECT GroupId FROM `ABCanTrackV2`.`group` WHERE OrgId = $OrgId));
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgEmployees',  'CommonDB.emp_group', NULL, $Count, 6);
    
	-- ************
	DELETE FROM `CommonDB`.`emp_group` WHERE GroupId IN (SELECT GroupId FROM `CommonDB`.`group` WHERE OrgId = $OrgId);
    -- #
    
    
    -- Step7: CommonDB.login_history
	SET $Count = (SELECT COUNT(*) FROM `CommonDB`.`login_history` WHERE EmployeeId NOT IN (SELECT EmployeeId FROM org_employee WHERE OrgId <> $OrgId));
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgEmployees',  'CommonDB.login_history', NULL, $Count, 7);
    
	-- ************
	DELETE FROM `CommonDB`.`login_history` WHERE EmployeeId NOT IN (SELECT EmployeeId FROM org_employee WHERE OrgId <> $OrgId);
    -- #
    
    -- Step8: CommonDB.email_log
		-- Step8.1: CommonDB.email_log.SendToEmployeeId
		SET $Count = (SELECT COUNT(*) FROM `CommonDB`.`email_log` WHERE SendToEmployeeId NOT IN (SELECT EmployeeId FROM org_employee WHERE OrgId <> $OrgId));
		-- ************
		INSERT INTO `ABCanTrackV2`.`delete_org_log`
			(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
		VALUES
			($OrgId, 'DeleteOrgEmployees',  'CommonDB.email_log.SendToEmployeeId 8.1', NULL, $Count, 8);
		
		-- ************
		DELETE FROM `CommonDB`.`email_log` WHERE SendToEmployeeId NOT IN (SELECT EmployeeId FROM org_employee WHERE OrgId <> $OrgId);
		-- #
		
		
		-- Step8.2: CommonDB.email_log.CcEmployeeId
		SET $Count = (SELECT COUNT(*) FROM `CommonDB`.`email_log` WHERE CcEmployeeId NOT IN (SELECT EmployeeId FROM org_employee WHERE OrgId <> $OrgId));
		-- ************
		INSERT INTO `ABCanTrackV2`.`delete_org_log`
			(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
		VALUES
			($OrgId, 'DeleteOrgEmployees',  'CommonDB.email_log.CcEmployeeId 8.2', NULL, $Count, 8);
		
		-- ************
		UPDATE `CommonDB`.`email_log` 
		SET CcEmployeeId = NULL
		WHERE CcEmployeeId NOT IN (SELECT EmployeeId FROM org_employee WHERE OrgId <> $OrgId);
		-- #
	-- #
    
    SET $Min = (SELECT MIN(EmployeeId) FROM `CommonDB`.`org_employee` WHERE EmployeeId NOT IN (SELECT EmployeeId FROM `CommonDB`.`org_employee` WHERE OrgId <> $OrgId));
    SET $Max = (SELECT MAX(EmployeeId) FROM `CommonDB`.`org_employee` WHERE EmployeeId NOT IN (SELECT EmployeeId FROM `CommonDB`.`org_employee` WHERE OrgId <> $OrgId));
	
	EmpLoop: WHILE $Min <= $Max 
    DO
		
        UPDATE `CommonDB`.`org_employee`
        SET SupervisorId = NULL
        WHERE SupervisorId = $Min;
        
		SET $Count = (SELECT COUNT(*) FROM `ABCanTrackV2`.`org_employee` WHERE EmployeeId NOT IN (SELECT EmployeeId FROM org_employee WHERE OrgId <> $OrgId));
		-- Step9: ABCanTrackV2.org_employee
		-- ************
		INSERT INTO `ABCanTrackV2`.`delete_org_log`
			(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
		VALUES
			($OrgId, 'DeleteOrgEmployees',  'ABCanTrackV2.org_employee', $Min, $Count, 9);
		
		-- ************
		DELETE FROM `ABCanTrackV2`.`org_employee` WHERE EmployeeId = $Min;
		-- #
		
		
		-- Step10: CommonDB.org_employee
		-- ************
		INSERT INTO `ABCanTrackV2`.`delete_org_log`
			(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
		VALUES
			($OrgId, 'DeleteOrgEmployees',  'CommonDB.org_employee', $Min, $Count, 10);
		
		-- ************
		DELETE FROM `CommonDB`.`org_employee` WHERE EmployeeId = $Min;
		-- #
		SET $CheckExistence = (SELECT CheckEmployeeExistence($OrgId, $Min));
        
        IF $CheckExistence > 0
        THEN
			
			SET $ExistsInTable = (SELECT EmployeeExistsInTable($Min));
            
			-- Step1001: ABCanTrackV2.employee
			-- ************
			INSERT INTO `ABCanTrackV2`.`delete_org_log`
				(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
			VALUES
				($OrgId, 'DeleteOrgEmployees Error',  CONCAT('ABCanTrackV2.employee : ', $ExistsInTable), $Min, $Count, 1001);
                
			IF $Min = $Max 
			THEN
				LEAVE EmpLoop;
			ELSE
				SET $Min = (SELECT Min(EmployeeId) FROM `CommonDB`.`org_employee` WHERE EmployeeId NOT IN (SELECT EmployeeId FROM org_employee WHERE OrgId <> $OrgId) AND EmployeeId > $Min);
			END IF;
		
        ELSE
			-- Step11: ABCanTrackV2.employee
			-- ************
			INSERT INTO `ABCanTrackV2`.`delete_org_log`
				(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
			VALUES
				($OrgId, 'DeleteOrgEmployees',  'ABCanTrackV2.employee', $Min, $Count, 11);
			
			-- ************
			DELETE FROM `ABCanTrackV2`.`employee` WHERE EmployeeId = $Min;
			-- #
			
			
			-- Step12: CommonDB.employee
			-- ************
			INSERT INTO `ABCanTrackV2`.`delete_org_log`
				(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
			VALUES
				($OrgId, 'DeleteOrgEmployees',  'CommonDB.employee', $Min, $Count, 12);
			
			-- ************
			DELETE FROM `CommonDB`.`employee` WHERE EmployeeId = $Min;
			-- #
			
			IF $Min = $Max 
			THEN
				LEAVE EmpLoop;
			ELSE
				SET $Min = (SELECT Min(EmployeeId) FROM `CommonDB`.`org_employee` WHERE EmployeeId NOT IN (SELECT EmployeeId FROM org_employee WHERE OrgId <> $OrgId) AND EmployeeId > $Min);
			END IF;
		END IF;
	End WHILE;
    -- #
    
    -- Step13: DONE
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgEmployees', 'DONE', NULL, NULL, 13);
    -- # 
    
END;
