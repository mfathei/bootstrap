CREATE PROCEDURE ABCanTrackV2.updateRestrictedWorkFieldCode()
  BEGIN
  DECLARE done INT DEFAULT FALSE;
  DECLARE indx INTEGER;
  DECLARE id VARCHAR(100);
  DECLARE txt VARCHAR(255);
  DECLARE ename VARCHAR(255);
  DECLARE cur1 CURSOR FOR SELECT r.RestrictedWorkId,LOWER(REPLACE(SUBSTR(IFNULL(r.RestrictedWorkName,''),1,99),' ','')) lname
  FROM `ABCanTrackV2`.restricted_work r
  ORDER BY lname;
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
  OPEN cur1;
    SET indx = 1;
    SET txt = '';
  READ_LOOP: LOOP
    FETCH cur1 INTO id,ename;
    
    IF done THEN
      LEAVE READ_LOOP;
    END IF;
    
    IF (ename = txt) THEN
        SET ename = CONCAT(ename,CONVERT(indx,CHAR(50)));
        SET indx = indx + 1;
    ELSE
        SET txt = ename;
    END IF;
    
    UPDATE `ABCanTrackV2`.restricted_work SET restricted_work.FieldCode=ename WHERE restricted_work.RestrictedWorkId=id;
    
  END LOOP;
  CLOSE cur1;
END;
