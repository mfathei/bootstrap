CREATE PROCEDURE ABCanTrackV2.DeleteFrom_traffic_violation_Tables(IN `$IncidentId` VARCHAR(100))
  BEGIN
DECLARE fetch_status int default 0;
DECLARE $TrafficViolationId varchar(100);
DECLARE incident_cursor CURSOR FOR 
select TrafficViolationId from traffic_violation where incidentid = $IncidentId;
DECLARE CONTINUE HANDLER FOR NOT FOUND SET fetch_status = 100;
Open Incident_cursor;
FETCH NEXT FROM incident_cursor 
		INTO $TrafficViolationId;
WHILE fetch_status = 0
			do
delete from impacts_ext_agency where TrafficViolationId = $TrafficViolationId;
FETCH NEXT FROM incident_cursor 
			INTO $TrafficViolationId;
		END while;
	CLOSE incident_cursor;
delete from traffic_violation where incidentid = $incidentid;
END;
