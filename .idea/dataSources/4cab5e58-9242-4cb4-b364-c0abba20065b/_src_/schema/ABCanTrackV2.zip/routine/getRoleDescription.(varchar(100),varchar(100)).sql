CREATE FUNCTION ABCanTrackV2.getRoleDescription(`$PeopleInvolvedId`         VARCHAR(100),
                                                `$OriginalPeopleInvolvedId` VARCHAR(100))
  RETURNS TEXT
  BEGIN
if $OriginalPeopleInvolvedId is null  or  $OriginalPeopleInvolvedId  = '' then
	set $OriginalPeopleInvolvedId = $PeopleInvolvedId;
end if;
set session group_concat_max_len = 10000;
select ( group_concat(DATE_FORMAT(UpdatedDate, '%b %d %Y') ,' ', '(',  concat(firstname ,' ', lastname) ,')',': <pr>', RoleDescription separator '<br><br>' ) ) as RoleDescription   
 into @newRoleDescription 
 from(
 select UpdatedDate, RoleDescription, firstname,lastname FROM hist_people_involved hi 
join employee e on e.EmployeeId = hi.UpdatedbyId
 where OriginalPeopleInvolvedId = $OriginalPeopleInvolvedId  
order by UpdatedDate asc  ) temp ; 
return @newRoleDescription;
END;
