CREATE PROCEDURE ABCanTrackV2.openTextVehicle_damage(IN `$IncidentId` VARCHAR(100))
  begin
    set session group_concat_max_len = 10000;
      SELECT distinct
        `vehicle_damage`.`VehicleDamageId`,
        `impact_type`.`ImpactTypeName` AS `ImpactTypeId`,
        `impact_type`.`ImpactTypeCode` AS `ImpactTypeCode`,
        `impact_sub_type`.`ImpactSubTypeName` AS `ImpactSubTypeId`,
        `vehicle_damage`.`IntEmployeeName1` AS `IntEmployeeName1`,
        `vehicle_damage`.`IntEmployeeName2` AS `IntEmployeeName2`,
        `vehicle_damage`.`IntEmployeeName3` AS `IntEmployeeName3`,
        `vehicle_damage`.`IntEmployeeDept1` AS `IntEmployeeDept1`,
        `vehicle_damage`.`IntEmployeeDept2` AS `IntEmployeeDept2`,
        `vehicle_damage`.`IntEmployeeDept3` AS `IntEmployeeDept3`,
        `vehicle_damage`.`PrimRespondName` AS `PrimRespondName`,
        `vehicle_damage`.`Description` AS `Description`,
        GETDAMAGEDESCRIPTION2(`hist_vehicle_damage`.`VehicleDamageId`,
                `hist_vehicle_damage`.`OriginalVehicleDamageId`) AS `OldImpactDescription`,
       -- `vehicle_damage`.`EstimatedCost` AS `ImpactEstimatedCost`,
        CASE `vehicle_damage`.`EstimatedCost` WHEN '0.00' THEN ''  END AS `ImpactEstimatedCost`,
        (SELECT 
                GROUP_CONCAT(DISTINCT `external_agency`.`ExtAgencyName`
                        SEPARATOR ', ')
            FROM
                (`impacts_ext_agency`
                JOIN `external_agency` ON ((`external_agency`.`ExtAgencyId` = `impacts_ext_agency`.`ExtAgencyId`)))
            WHERE
                (`impacts_ext_agency`.`VehicleDamageId` = `vehicle_damage`.`VehicleDamageId`)
            GROUP BY `impacts_ext_agency`.`VehicleDamageId`) AS `ExtAgencyId`,
        `vehicle_damage`.`DamageDescription` AS `ImpactTypeDescription`,
        GETDAMAGEDESCRIPTION(`hist_vehicle_damage`.`VehicleDamageId`,
                `hist_vehicle_damage`.`OriginalVehicleDamageId`) AS `OldImpactTypeDescription`,
        `vehicle_damage`.`DriverName` AS `DriverName`,
        `vehicle_damage`.`DriverLicence` AS `DriverLicence`,
        `vehicle_type`.`VehicleTypeName` AS `VehicleTypeId`,
        `vehicle_damage`.`VehicleLicence` AS `VehicleLicence`,
        `vehicle_damage`.`HowDidThatDone` AS `HowDidThatDone`,
        GETHOWDIDTHATDONE(`hist_vehicle_damage`.`VehicleDamageId`,
                `hist_vehicle_damage`.`OriginalVehicleDamageId`) AS `OldHowDidThatDone`,
        `hist_vehicle_damage`.`OldDamageDescription` AS `OldDamageDescription`
    FROM
        ((((`vehicle_damage`
        JOIN `impact_sub_type` ON ((`impact_sub_type`.`ImpactSubTypeId` = `vehicle_damage`.`ImpactSubTypeId`)))
        JOIN `impact_type` ON ((`impact_sub_type`.`ImpactTypeId` = `impact_type`.`ImpactTypeId`)))
        LEFT JOIN `vehicle_type` ON ((`vehicle_damage`.`VehicleTypeId` = `vehicle_type`.`VehicleTypeId`)))
        JOIN `hist_vehicle_damage` ON ((`hist_vehicle_damage`.`VehicleDamageId` = `vehicle_damage`.`VehicleDamageId`))) 
	where vehicle_damage.Incidentid = $IncidentId;
        end;
