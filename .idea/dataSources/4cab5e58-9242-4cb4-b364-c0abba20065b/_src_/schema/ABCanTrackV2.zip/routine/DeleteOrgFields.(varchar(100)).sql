CREATE PROCEDURE ABCanTrackV2.DeleteOrgFields(IN `$OrgId` VARCHAR(100))
  BEGIN
	DECLARE $Count INT;
    
    
    -- Step1: option
	SET $Count = (SELECT COUNT(*) FROM `ABCanTrackV2`.`option` WHERE FieldId IN (SELECT FieldId FROM field WHERE OrgId = $OrgId));
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgFields',  'option', NULL, $Count, 1);
    
	-- ************
	DELETE FROM `ABCanTrackV2`.`option` WHERE FieldId IN (Select FieldId FROM field WHERE OrgId = $OrgId);
    -- #
    
    
    -- Step2: favorite_field
	SET $Count = (SELECT COUNT(*) FROM `ABCanTrackV2`.`favorite_field` WHERE FavoriteTableId IN (SELECT FavoriteTableId FROM `ABCanTrackV2`.`favorite_table` WHERE OrgId = $OrgId));
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgFields',  'favorite_field', NULL, $Count, 2);
    
	-- ************
	DELETE FROM `ABCanTrackV2`.`favorite_field` WHERE FavoriteTableId IN (SELECT FavoriteTableId FROM `ABCanTrackV2`.`favorite_table` WHERE OrgId = $OrgId);
    -- #
    
    
    -- Step3: favorite_table
	SET $Count = (SELECT COUNT(*) FROM `ABCanTrackV2`.`favorite_table` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgFields',  'favorite_table', NULL, $Count, 3);
    
	-- ************
	DELETE FROM `ABCanTrackV2`.`favorite_table` WHERE OrgId = $OrgId;
    -- #
    
    
    -- Step4: stat_table_time_frame
	SET $Count = (SELECT COUNT(*) FROM `ABCanTrackV2`.`stat_table_time_frame` WHERE StatTableId IN (SELECT StatTableId FROM stat_table WHERE OrgId = $OrgId));
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgFields',  'stat_table_time_frame', NULL, $Count, 4);
    
	-- ************
	DELETE FROM `ABCanTrackV2`.`stat_table_time_frame` WHERE StatTableId IN (SELECT StatTableId FROM stat_table WHERE OrgId = $OrgId);
    -- #
    
    
    -- Step5: stat_table
	SET $Count = (SELECT COUNT(*) FROM `ABCanTrackV2`.`stat_table` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgFields',  'stat_table', NULL, $Count, 5);
    
	-- ************
	DELETE FROM `ABCanTrackV2`.`stat_table` WHERE OrgId = $OrgId;
    -- #
    
    
    -- Step6: org_field
	SET $Count = (SELECT COUNT(*) FROM `ABCanTrackV2`.`org_field` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgFields',  'org_field', NULL, $Count, 6);
    
	-- ************
	DELETE FROM `ABCanTrackV2`.`org_field` WHERE OrgId = $OrgId;
    -- #
    
    
    -- Step7: field
	SET $Count = (SELECT COUNT(*) FROM `ABCanTrackV2`.`field` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgFields',  'field', NULL, $Count, 7);
    
	-- ************
	DELETE FROM `ABCanTrackV2`.`field` WHERE OrgId = $OrgId;
    -- #
    
    
    -- Step8: CommonDB.org_field
	SET $Count = (SELECT COUNT(*) FROM `CommonDB`.`org_field` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgFields',  'CommonDB.org_field', NULL, $Count, 8);
    
	-- ************
	DELETE FROM `CommonDB`.`org_field` WHERE OrgId = $OrgId;
    -- #
    
    -- Step9: DONE
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgFields',  'DONE', NULL, $Count, 9);
END;
