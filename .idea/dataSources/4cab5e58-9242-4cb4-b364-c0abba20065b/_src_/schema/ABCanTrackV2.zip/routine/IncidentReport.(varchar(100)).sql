CREATE PROCEDURE ABCanTrackV2.IncidentReport(IN `$IncidentId` VARCHAR(100))
  BEGIN
 
CALL GetHistOpenText($IncidentId,'IncDescription');
SET @IncDescription = @newDescription;

CALL GetHistOpenText($IncidentId,'EnergyFormNote');
SET @EnergyFormNote = @newDescription;

CALL GetHistOpenText($IncidentId,'SubStandardActionNote');
SET  @SubStandardActionNote= @newDescription;

CALL GetHistOpenText($IncidentId,'SubStandardConditionNote');
SET  @SubStandardConditionNote= @newDescription;

CALL GetHistOpenText($IncidentId,'UnderLyingCauseNote');
SET  @UnderLyingCauseNote= @newDescription;

CALL GetHistOpenText($IncidentId,'InvSummary');
SET  @InvSummary= @newDescription;       

CALL GetHistOpenText($IncidentId,'EventSequence');
SET  @EventSequence= @newDescription;   

CALL GetHistOpenText($IncidentId,'RootCauseNote');
SET  @RootCauseNote= @newDescription;

CALL GetHistOpenText($IncidentId,'SourceDetails');
SET  @SourceDetails= @newDescription;

CALL GetHistOpenText($IncidentId,'FollowUpNote');
SET  @FollowUpNote= @newDescription;       

CALL GetHistOpenText($IncidentId,'EnvConditionNote');
SET  @EnvConditionNote= @newDescription;  


SELECT   HistIncidentId,
concat(empCreator.FirstName, " " , empCreator.LastName) as CreatorName,
 IncidentNumber,VersionNumber,
    EventTypeName,
    DATE_FORMAT(incident.IncidentDate, '%m/%d/%Y') AS IncidentDate,
    incident.IncidentHour,
    incident.IncidentMinute,
    CASE incident.IsEmerRP
        WHEN '0' THEN 'no'
        WHEN '1' THEN 'yes'
    END AS IsEmerRP,
    incident.RepName,
    incident.RepEmail,
    incident.RepPosition,
    incident.RepCompany,
    incident.RepPrimaryPhone,
    incident.RepAlternatePhone,
    Location1Name,
    Location2Name,
    Location3Name,
    Location4Name,
    incident.OtherLocation,
    OperationTypeName,
    RiskOfRecurrenceName,
    IncidentSeverityName,
    DATE_FORMAT(incident.SignOffDate, '%m/%d/%Y') AS SignOffDate,
    InvStatusName,
    DATE_FORMAT(incident.InvestigationDate, '%m/%d/%Y') AS InvestigationDate,
    incident.InvestigatorName1,
    incident.InvestigatorName2,
    incident.InvestigatorName3,
   
	@IncDescription  as IncDescription,
	@EnergyFormNote as EnergyFormNote,    
    @SubStandardActionNote    as SubStandardActionNote,
    @SubStandardConditionNote    as SubStandardConditionNote,
    @UnderLyingCauseNote    as UnderLyingCauseNote,
    @InvSummary    as InvSummary,       
    @EventSequence    as EventSequence,   	
	@EnvConditionNote as EnvConditionNote,
	@FollowUpNote as FollowUpNote,
	@SourceDetails as SourceDetails,
	@RootCauseNote as RootCauseNote,

   	EventTypeName as EventTypeId, 
	OperationTypeName as OperationTypeId,
	Location1Name as Location1Id, 
	Location2Name as Location2Id, 
	Location3Name as Location3Id,
	Location4Name as Location4Id,  
	(SELECT group_concat(ObservationAndAnalysisParamName separator '; ') from observation_analysis_param  inner join observation_analysis on observation_analysis.ObservationAndAnalysisId = observation_analysis_param.ObservationAndAnalysisId where ObservationAndAnalysisCode ='SubActions' and  ObservationAndAnalysisParamId in (SELECT ObservationAndAnalysisParamId  from inc_obser_ana where incidentid = $IncidentId)) as SubActions,
	(SELECT group_concat(ObservationAndAnalysisParamName separator '; ') from observation_analysis_param  inner join observation_analysis on observation_analysis.ObservationAndAnalysisId = observation_analysis_param.ObservationAndAnalysisId where ObservationAndAnalysisCode ='SubConditions' and  ObservationAndAnalysisParamId in (SELECT ObservationAndAnalysisParamId  from inc_obser_ana where incidentid = $IncidentId)) as SubConditions,
    OEDepartmentName as OEDepartmentId,
	RiskOfRecurrenceName as RiskOfRecurrenceId,
    IncidentSeverityName as IncidentSeverityId,    
    EnvConditionName as EnvConditions,
    RootCauseName as RootCauseParamId,    
	IncInvSourceName as InvSourceParamId,    
    InvStatusName as InvStatusId,
    incident.InvestigatorName1 as InvestigatorId1,
    incident.InvestigatorName2 as InvestigatorId2, 
    incident.InvestigatorName3 as InvestigatorId3,
    /* CASE incident.ResponseCost WHEN '0.00' THEN ''  END AS ResponseCost,
     CASE incident.RepairCost WHEN '0.00' THEN ''  END AS RepairCost,
     CASE incident.InsuranceCost WHEN '0.00' THEN ''  END AS InsuranceCost,
     CASE incident.WCBCost WHEN '0.00' THEN ''  END AS WCBCost,
     CASE incident.OtherCost WHEN '0.00' THEN ''  END AS OtherCost,
     CASE incident.TotalCost WHEN '0.00' THEN ''  END AS TotalCost,
     */
    incident.ResponseCost,
    incident.RepairCost,
    incident.InsuranceCost,
    incident.WCBCost,
    incident.OtherCost,
    incident.TotalCost,
    
    incident.SignOffInvestigatorName as SignOffInvestigatorId,
concat(updator.FirstName, " " , updator.LastName) as UpdatedByName

from  incident
INNER JOIN hist_incident hinc ON incident.IncidentId = hinc.IncidentId 
join employee as empCreator on empCreator.EmployeeId = incident.CreatorId
join employee as updator on updator.EmployeeId = hinc.UpdatedById
where incident.IncidentId=$IncidentId
order by VersionNumber desc limit 1;
END;
