CREATE PROCEDURE ABCanTrackV2.GetCustomFieldsIncidentData(IN xmlData TEXT)
  BEGIN
SET @OrgId = extractvalue(xmlData, '//OrgId');
SET @page = extractvalue(xmlData, '//page');
SET @limit = extractvalue(xmlData, '//limit');
SET @sortOrder =  extractvalue(xmlData, '//sortOrder');
SET @index =  extractvalue(xmlData, '//index');
SET @Mine =  extractvalue(xmlData, '//Mine');
SET @CreatorId = extractvalue(xmlData, '//CreatorId');
SET @Export =  extractvalue(xmlData, '//Export');
SET @SubTabName =  extractvalue(xmlData, '//SubTabName');
set @selectquery ="SELECT IncidentId,field_value.FieldValueId, field_value.FieldId,  field.FieldName,FieldTypeCode, field_value.FieldValue,
CASE FieldTypeCode 
WHEN 'calendar' THEN (select FieldValue  )
WHEN 'textarea' THEN (select FieldValue )
WHEN 'textbox' THEN (select FieldValue )
WHEN 'select' THEN (select OptionName from `option` where `option`.OptionId = field_value.OptionId  )  
WHEN 'checkbox' THEN (select  group_concat( OptionName separator ', ' ) from `option` where `option`.OptionId = field_value.OptionId )  
WHEN 'radiobutton' THEN (select  group_concat( OptionName separator ', ' ) from `option` where `option`.OptionId = field_value.OptionId )  
WHEN 'multiselect' THEN (select  group_concat( OptionName separator ', ' ) from `option` where `option`.OptionId = field_value.OptionId )  
END  as FieldValues ";
set @queryFrom = " FROM field_value
left outer join `option` on field_value.optionid = `option`.optionid
inner join field on field_value.FieldId = field.FieldId
inner join field_type on field_type.FieldTypeId = field.FieldTypeId
inner join sub_tab on field.SubTabId = sub_tab.SubTabId  ";
SET @queryWhere = ' where 1= 1 ';
SET @queryWhere = CONCAT(@queryWhere,' and field.OrgId  =   "', @Orgid,'" ');
SET @queryWhere = CONCAT(@queryWhere,' and SubTabName  like  '"'", @SubTabName,"'");
SET @querycount = CONCAT( 'SELECT count(*) into @cnt ', @queryFrom, @queryWhere );
PREPARE stmt1 FROM @querycount;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
SET @selectquery = CONCAT (@selectquery,', ', @cnt, ' as Count ');
SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );
SET @query = CONCAT(@query, ' order by ', @index,'  ', @sortOrder);
if( @Export ="false") then
SET @page = (@page - 1) * @limit;
SET @query = CONCAT(@query, ' LIMIT ', @limit ,' OFFSET ',  @page);
end if;
-- select CONCAT( @selectquery, @queryFrom, @queryWhere );
PREPARE stmt1 FROM @query;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
-- select @queryWhere;
END;
