CREATE PROCEDURE ABCanTrackV2.UnUpdated_hist_field_value(IN `$NewHistIncidentId` VARCHAR(100),
                                                         IN `$OldHistIncidentId` VARCHAR(100),
                                                         IN `$UpdatedById`       VARCHAR(100),
                                                         IN `$SubTabName`        VARCHAR(100))
  BEGIN
	INSERT INTO `ABCanTrackV2`.`hist_field_value`
	(`HistFieldValueId`,
	`FieldValueId`,
	`IncidentId`,
	`FieldId`,
	`OptionName`,
	`HistIncidentId`,
	`FieldValue`,
	`TableKeyValue`,
	`TableKeyId`,
	`HistoryOperationId`,
	`UpdatedById`)
	SELECT 
	`HistFieldValueId`,
	`FieldValueId`,
	`IncidentId`,
	`hist_field_value`.`FieldId`,
	`OptionName`,
	$NewHistIncidentId,
	`FieldValue`,
	`TableKeyValue`,
	`TableKeyId`,
	`HistoryOperationId`,
	$UpdatedById	
	FROM `ABCanTrackV2`.`hist_field_value`
	INNER JOIN field ON hist_field_value.FieldId = field.FieldId
	INNER JOIN sub_tab ON field.SubTabId = sub_tab.SubTabId
	where 
	hist_field_value.HistIncidentId = $OldHistIncidentId
	AND TableKeyValue = 'incident'
	AND SubTabName    = $SubTabName;
END;
