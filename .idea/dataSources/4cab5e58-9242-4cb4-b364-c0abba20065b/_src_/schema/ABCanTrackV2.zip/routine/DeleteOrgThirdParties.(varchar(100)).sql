CREATE PROCEDURE ABCanTrackV2.DeleteOrgThirdParties(IN `$OrgId` VARCHAR(100))
  BEGIN
	DECLARE $Count INT;
    
    
    -- Step1: ABCanTrackV2.third_party
	SET $Count = (SELECT COUNT(*) FROM `ABCanTrackV2`.`third_party` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgThirdParties',  'ABCanTrackV2.third_party', NULL, $Count, 1);
    
	-- ************
	DELETE FROM `ABCanTrackV2`.`third_party` WHERE OrgId = $OrgId;
    -- #
    
    
    -- Step2: CommonDB.third_party
	SET $Count = (SELECT COUNT(*) FROM `CommonDB`.`third_party` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgThirdParties',  'CommonDB.third_party', NULL, $Count, 2);
    
	-- ************
	DELETE FROM `CommonDB`.`third_party` WHERE OrgId = $OrgId;
    -- #
    
    
    -- Step3: ABCanTrackV2.third_party_type
	SET $Count = (SELECT COUNT(*) FROM `ABCanTrackV2`.`third_party_type` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgThirdParties',  'ABCanTrackV2.third_party_type', NULL, $Count, 3);
    
	-- ************
	DELETE FROM `ABCanTrackV2`.`third_party_type` WHERE OrgId = $OrgId;
    -- #
    
    
    -- Step4: CommonDB.third_party_type
	SET $Count = (SELECT COUNT(*) FROM `CommonDB`.`third_party_type` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgThirdParties',  'CommonDB.third_party_type', NULL, $Count, 4);
    
	-- ************
	DELETE FROM `CommonDB`.`third_party_type` WHERE OrgId = $OrgId;
    -- #
    -- Step5: DONE
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgThirdParties',  'DONE', NULL, $Count, 5);
    
END;
