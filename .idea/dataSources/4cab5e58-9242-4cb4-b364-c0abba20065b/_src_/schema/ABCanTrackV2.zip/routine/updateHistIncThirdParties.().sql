CREATE PROCEDURE ABCanTrackV2.updateHistIncThirdParties()
  BEGIN
    DECLARE finish INT DEFAULT 0 ;
    DECLARE custname TEXT ;
    DECLARE contname TEXT;
    DECLARE vThirdPartyName TEXT  ;
    DECLARE vcustJobNumber TEXT ;
  --  DECLARE vcontJobNumber TEXT;
	DECLARE vContactName TEXT;      
    DECLARE vJobNumber TEXT ; 
    
DECLARE newContactName	 TEXT DEFAULT '';
DECLARE	newJobNumber  TEXT DEFAULT '';

DECLARE vCustomerName TEXT DEFAULT '';
DECLARE vCustName TEXT DEFAULT '';
DECLARE vCustomerJobNumber TEXT DEFAULT '';

DECLARE vContractorName TEXT DEFAULT '';
DECLARE vContName TEXT DEFAULT '';
DECLARE vContractorJobNumber TEXT DEFAULT '';
    
    
    DECLARE vHistIncidentId VARCHAR (100) ;
    DECLARE vIncidentId VARCHAR (100) ;
     DECLARE vOrgId VARCHAR (100) ;
    
    DECLARE delim VARCHAR (10) DEFAULT ';| ' ;
    DECLARE std_name_sur CURSOR FOR 
    SELECT ThirdPartyName,JobNumber,ContactName, hist_incident.HistIncidentId,IncidentId , OrgId
    FROM hist_incident     WHERE ThirdPartyName IS NOT NULL;
        
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET finish = 1 ;
    SET @cnt = 0 ;
    SET @ThirdPartyNameOccur = 0 ;
    OPEN std_name_sur ;
    std_name_loop :
    LOOP
        FETCH std_name_sur INTO vThirdPartyName,
        vJobNumber,  
        vContactName,
        vHistIncidentId,
        vIncidentId,
        vOrgId;
        IF finish = 1 
        THEN LEAVE std_name_loop ;
        END IF ;
        SET @cnt = @cnt + 1 ;
		
		SET vCustomerName = '';
		SET vCustName = '';
		SET vCustomerJobNumber = '';
		SET vContractorName = '';
		SET vContName = '';
		SET vContractorJobNumber = '';		
		
        SET @ThirdPartyNameOccur = SPLITTER_COUNT (vThirdPartyName, delim) ;
        select @ThirdPartyNameOccur ;
        
        IF @ThirdPartyNameOccur > 0 
        THEN SET @ThirdPartyNameOccur = @ThirdPartyNameOccur + 1 ;
        SET @curr = 1 ;
        custname_loop :
        LOOP
            IF @curr > @ThirdPartyNameOccur 
            THEN LEAVE custname_loop ;
            END IF ;
          
            SET custname = SPLIT_STRING (vThirdPartyName, delim, @curr) ;
			SET newJobNumber = SPLIT_STRING (vJobNumber, delim, @curr) ;
            SET newContactName = SPLIT_STRING (vContactName, delim, @curr) ;
			
		-- 	select vJobNumber, vContactName;
			
			SET @ThirdPartyId = (SELECT ThirdPartyId FROM third_party  WHERE third_party.ThirdPartyName = custname and OrgId=vOrgId LIMIT 1) ;

				SET @ThirdPartyTypeCode = (SELECT  ThirdPartyTypeCode   FROM  third_party_type 
											JOIN third_party ON (  third_party_type.ThirdPartyTypeId = third_party.ThirdPartyTypeId) 
											WHERE third_party.ThirdPartyId = @ThirdPartyId  LIMIT 1) ;
             
    
            IF @ThirdPartyTypeCode = 'Customer'    THEN 
           
				IF vCustomerName = '' THEN
				SET vCustomerName = custname;
				ELSE
					SET vCustomerName = CONCAT(vCustomerName , ';| ', custname);
				END IF;							
			IF vCustomerJobNumber = '' THEN
				SET vCustomerJobNumber = newJobNumber;
            ELSE
				SET vCustomerJobNumber = CONCAT(vCustomerJobNumber , ';| ', newJobNumber);
		    END IF;
			
			IF vCustName = '' THEN
				SET vCustName = newContactName;
				ELSE
					SET vCustName = CONCAT(vCustName , ';| ', newContactName);
				END IF;
						
            ELSEIF @ThirdPartyTypeCode = 'Contractor' 
            THEN -- SET @jnumber = (SELECT JobNumber FROM inc_third_party WHERE IncidentId = vIncidentId AND ThirdPartyId = @ThirdPartyId);
			IF vContractorName = '' THEN
				SET vContractorName = custname;
			ELSE
				SET vContractorName = CONCAT(vContractorName , ';| ', custname);
			END IF;							
			IF vContractorJobNumber = '' THEN
				SET vContractorJobNumber = newJobNumber;
            ELSE
				SET vContractorJobNumber = CONCAT(vContractorJobNumber , ';| ', newJobNumber);
		    END IF;
			
			IF vContName = '' THEN
				SET vContName = newContactName;
				ELSE
					SET vContName = CONCAT(vContName , ';| ', newContactName);
				END IF;
          
          
            END IF ;
            SET @curr = @curr + 1 ;
        END LOOP custname_loop ;
        END IF ;
		
     --   select vHistIncidentId,  vCustomerName,   vCustName, vCustomerJobNumber, vHistIncidentId, vContractorName,  vContName,  vContractorJobNumber;
		  
           INSERT INTO histinc_thirdparties (  HistIncidentId, CustomerName, CustName, CustomerJobNumber  )   
				VALUES  ( vHistIncidentId,  vCustomerName,   vCustName, vCustomerJobNumber ) 
                ON DUPLICATE KEY   UPDATE   CustomerName = vCustomerName,    CustName =vCustName,  CustomerJobNumber = vCustomerJobNumber ;
		
		
		
          INSERT INTO histinc_thirdparties (  HistIncidentId, ContractorName, ContName,  ContractorJobNumber ) 
            VALUES ( vHistIncidentId, vContractorName,  vContName,  vContractorJobNumber) 
			ON DUPLICATE KEY  UPDATE  ContractorName = vContractorName, ContName = vContName, ContractorJobNumber = vContractorJobNumber ;
		
        --  SELECT @cnt as indx, custname, contname, vThirdPartyName, vcustJobNumber, vcontJobNumber, vJobNumber, vHistIncidentId, vIncidentId;
    END LOOP std_name_loop ;
    SELECT   @cnt AS counter ;
  --  select vThirdPartyName, ret1, ret2;
    
    
    CLOSE std_name_sur ;
END;
