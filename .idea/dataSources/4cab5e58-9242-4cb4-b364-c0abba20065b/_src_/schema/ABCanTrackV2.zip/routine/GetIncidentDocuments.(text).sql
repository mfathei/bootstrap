CREATE PROCEDURE ABCanTrackV2.GetIncidentDocuments(IN xmlData TEXT)
  BEGIN
 
SET @OrgId = extractvalue(xmlData, '//OrgId');
SET @page = extractvalue(xmlData, '//page');
SET @limit = extractvalue(xmlData, '//limit');
SET @sortOrder =  extractvalue(xmlData, '//sortOrder');
SET @index =  extractvalue(xmlData, '//index');
SET @Mine =  extractvalue(xmlData, '//Mine');
SET @CreatorId = extractvalue(xmlData, '//CreatorId');
SET @Export =  extractvalue(xmlData, '//Export');
set @selectquery ="select AttachmentId, incident.IncidentId, incident.IncidentNumber, date_format(incident.IncidentDate,'%m/%d/%Y') as IncidentDate,incident.IncidentDate as DateOrder,
					attachment.VersionNumber, AttachmentName, AttachmentType, AttachmentSize ";
set @queryFrom = "  from attachment
				  inner join hist_incident on hist_incident.HistIncidentId = attachment.IncidentId 
                  inner join incident on hist_incident.IncidentId = incident.IncidentId  ";
SET @queryWhere = ' where 1= 1 ';
SET @queryWhere = CONCAT(@queryWhere,' and  hist_incident.HistIncidentId = hist_incident(incident.IncidentId) ');
IF (@OrgId != '' AND @OrgId !='0') THEN
	SET @queryWhere = CONCAT(@queryWhere,' and incident.OrgId =   "', @Orgid,'" ');
END IF;
IF (@Mine = 'true') THEN
	SET @queryWhere = CONCAT(@queryWhere,' AND incident.CreatorId =  "',@CreatorId,'" '  );
END IF;
SET @queryWhere = CONCAT(@queryWhere,' AND incident.Hide =  0');
IF( ExtractValue(xmlData, 'count(//EventTypeId)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', event_type.EventTypeName as EventTypeId ');
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join event_type on incident.EventTypeId = event_type.EventTypeId  ');
END IF;
IF( ExtractValue(xmlData, 'count(//Location1Id)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', location1.Location1Name as Location1Id ');
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join location1 on incident.Location1Id = location1.Location1Id  ');
END IF;
IF( ExtractValue(xmlData, 'count(//Location2Id)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', location2.Location2Name as Location2Id ');
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join location2 on incident.Location2Id = location2.Location2Id  ');
END IF;
IF( ExtractValue(xmlData, 'count(//Location3Id)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', location3.Location3Name as Location3Id ');
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join location3 on incident.Location3Id = location3.Location3Id  ');
END IF;
IF( ExtractValue(xmlData, 'count(//Location4Id)') >0) THEN 
	SET @selectquery = CONCAT(@selectquery,', location4.Location4Name as Location4Id ');
	SET @queryFrom = CONCAT(@queryFrom,'    left outer join location4 on incident.Location4Id = location4.Location4Id  ');
END IF;
-- end select 
SET @IncidentDateFrom =  extractvalue(xmlData, '//IncidentDateFrom');
SET @IncidentDateTo =  extractvalue(xmlData, '//IncidentDateTo');
IF(@IncidentDateTo != '') THEN
	SET @IncidentDateFrom  = STR_TO_DATE(@IncidentDateFrom , '%m/%d/%Y');
	SET @IncidentDateTo  = STR_TO_DATE(@IncidentDateTo , '%m/%d/%Y');
	SET @IncidentDateTo2 = DATE_ADD(@IncidentDateTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident.IncidentDate >  ', "'" , @IncidentDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident.IncidentDate <=  ', "'",  @IncidentDateTo2  ,"'" );										
ELSE 
IF(@IncidentDateTo = '' AND @IncidentDateFrom !='' ) THEN
	SET @IncidentDateFrom  = STR_TO_DATE(@IncidentDateFrom , '%m/%d/%Y');
	SET @IncidentDateFrom2 = DATE_ADD(@IncidentDateFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident.IncidentDate >=  ',  "'", @IncidentDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND incident.IncidentDate <  ', "'", @IncidentDateFrom2  ,"'");	
END IF;
END IF;
/* search part*/
 SET@myArrayOfValue='IncidentNumber,AttachmentName,AttachmentType,AttachmentSize,EventTypeId,Location1Id,Location2Id,Location3Id,Location4Id,';
SET @Postition = LOCATE(',', @myArrayOfValue);
WHILE ( @Postition > 0 ) DO
 SET @STR = SUBSTRING(@myArrayOfValue, 1, @Postition-1);
 SET @myArrayOfValue = SUBSTRING(@myArrayOfValue, @Postition + 1);
 SET @Col =  extractvalue(xmlData, CONCAT('//',@STR));
 IF (@Col != '' AND @Col !='NULL') THEN
		IF (@STR  = 'EventTypeId') then set@STR='event_type.EventTypeName';  END IF;
		IF (@STR  = 'Location1Id' ) then set @STR= 'location1.Location1Name'; END IF;
		IF (@STR  = 'Location2Id' ) then set @STR= 'location2.Location2Name';  END IF;
		IF (@STR  = 'Location3Id' ) then set @STR= 'location3.Location3Name'; END IF;
		IF (@STR  = 'Location4Id' ) then set @STR= 'location4.Location4Name';  END IF;
		
	SET @queryWhere = CONCAT(@queryWhere,CONCAT(' AND ',@STR,' like '"'%", @Col ,"%'" )); 
	END IF;
 SET @Postition = LOCATE(',', @myArrayOfValue);
END WHILE;
 
 -- select @queryWhere;
SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );
 -- select @query;
SET @querycount =  CONCAT( 'SELECT count(*) into @cnt from  (', @query, ' ) t');
PREPARE stmt1 FROM @querycount;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
SET @selectquery = CONCAT (@selectquery,', ', @cnt, ' as Count ');
SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );
if(@index ='IncidentDate') then set @index = 'DateOrder'; end if;
SET @query = CONCAT(@query, ' order by ', @index,'  ', @sortOrder);
if( @Export ="false") then
SET @page = (@page - 1) * @limit;
SET @query = CONCAT(@query, ' LIMIT ', @limit ,' OFFSET ',  @page);
end if;
PREPARE stmt1 FROM @query;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
END;
