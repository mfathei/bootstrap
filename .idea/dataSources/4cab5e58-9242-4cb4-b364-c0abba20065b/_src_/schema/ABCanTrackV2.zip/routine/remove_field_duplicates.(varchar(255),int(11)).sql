CREATE PROCEDURE ABCanTrackV2.remove_field_duplicates(IN `$LangId` VARCHAR(255), IN `$IsCustom` INT)
  BEGIN
DECLARE finished INTEGER DEFAULT 0;
DECLARE $fname VARCHAR(255);
DECLARE $cnt int;
    DECLARE g_p_cursor CURSOR FOR
    SELECT t.FieldName,count(*) as cnt FROM ABCanTrackV2.field t
    where t.OrgId IS NULL AND t.IsCustom=$IsCustom and t.LanguageId=$LangId and t.FieldName <> 'root_cause'
    group by t.FieldName
    HAVING cnt > 1;
 -- declare NOT FOUND handler
	DECLARE CONTINUE HANDLER 
	FOR NOT FOUND SET finished = 1;
    
 open g_p_cursor;
-- FETCH g_p_cursor INTO $gid , $fcode, $pcode, $pid;
ex: LOOP
	
	IF finished = 1 THEN 
		LEAVE ex;
	END IF;
    
    FETCH g_p_cursor INTO $fname, $cnt;
    set @id = NULL;
-- select $fcode,$pcode;
    set @id = (select FieldId FROM ABCanTrackV2.`field` where FieldName=$fname and `field`.OrgId IS NULL AND `field`.IsCustom=$IsCustom and `field`.LanguageId=$LangId limit 1);
    DELETE FROM ABCanTrackV2.`org_field` WHERE FieldId=@id;
    delete from ABCanTrackV2.`field` WHERE FieldId=@id;
    
END LOOP ex;
CLOSE g_p_cursor;
END;
