CREATE PROCEDURE ABCanTrackV2.test(IN pOrgId VARCHAR(255))
  BEGIN
 SET @IncidentNumber=0;
       select @IncidentNumber ;
    SET @IncidentNumber=(SELECT max(IncidentNumber) AS IncidentNumber FROM incident WHERE OrgId= pOrgId);
       select @IncidentNumber ;
    SET @IncidentNumber = ifnull(@IncidentNumber, 0);
   
 SET @IncidentNumber =@IncidentNumber +1;
   
   select @IncidentNumber ;
END;
