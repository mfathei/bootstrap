CREATE PROCEDURE ABCanTrackV2.GetOrgDurationUnit(IN xmlData TEXT)
  BEGIN
SET @Orgid = extractvalue(xmlData, '//OrgId');
SET @page = extractvalue(xmlData, '//page');
SET @limit = extractvalue(xmlData, '//limit');
SET @sortOrder =  extractvalue(xmlData, '//sortOrder');
SET @index =  extractvalue(xmlData, '//index');
SET @Mine =  extractvalue(xmlData, '//Mine');
SET @CreatorId = extractvalue(xmlData, '//CreatorId');
SET @Export =  extractvalue(xmlData, '//Export');
SET @checkOrg =  extractvalue(xmlData, '//check');
set @selectquery ="SELECT OrgName, duration_unit.OrgId, DurationUnitId ,  DurationUnitName, `Order`";
                
set @queryFrom = " from  duration_unit  inner join organization on duration_unit.OrgId = organization.OrgId";
SET @queryWhere = ' where 1= 1 ';
if(@checkOrg  = 'false') then 
SET @queryWhere = CONCAT(@queryWhere,' and duration_unit.OrgId =   "', @Orgid,'" ');
end if;
SET @queryWhere = CONCAT(@queryWhere,' and duration_unit.Hide = 0 ');
SET @myArrayOfValue = ' DurationUnitId,  DurationUnitName, Order,';
SET @Postition = LOCATE(',', @myArrayOfValue);
WHILE ( @Postition > 0 ) DO
 SET @STR = SUBSTRING(@myArrayOfValue, 1, @Postition-1);
 SET @myArrayOfValue = SUBSTRING(@myArrayOfValue, @Postition + 1);
 SET @Col =  extractvalue(xmlData, CONCAT('//',@STR));
 IF (@Col != '' AND @Col !='NULL') THEN
  SET @queryWhere = CONCAT(@queryWhere,CONCAT(' AND    ',@STR,' like '"'%", @Col ,"%'")); 
 END IF;
 
 SET @Postition = LOCATE(',', @myArrayOfValue);
END WHILE;
SET @querycount = CONCAT( 'SELECT count(*) into @cnt ', @queryFrom, @queryWhere );
PREPARE stmt1 FROM @querycount;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
	
SET @selectquery = CONCAT (@selectquery,', ', @cnt, ' as Count ');
SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );
if( @index = 'Order') then set  @index = '`Order`';  end if;
if( @index = 'Order, DurationUnitName') then set  @index = '`Order`, DurationUnitName';  end if;
SET @query = CONCAT(@query, ' order by ', @index,'  ', @sortOrder);
if( @Export ="false") then
SET @page = (@page - 1) * @limit;
SET @query = CONCAT(@query, ' LIMIT ', @limit ,' OFFSET ',  @page);
end if;
--  select  @query;
PREPARE stmt1 FROM @query;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
END;
