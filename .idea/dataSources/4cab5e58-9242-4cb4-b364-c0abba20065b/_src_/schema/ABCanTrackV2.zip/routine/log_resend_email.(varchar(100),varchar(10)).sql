CREATE PROCEDURE ABCanTrackV2.log_resend_email(IN pEmailLogId VARCHAR(100), IN pClientTimeZone VARCHAR(10))
  BEGIN 
	select SendToEmployeeId,OrgId,`From`,CC,EmailTypeId,`Subject`
    into @SendToEmployeeId,@OrgId,@From,@CC,@EmailTypeId,@Subject
    from email_log  where EmailLogId=pEmailLogId; 
    
    SET @SentDate =  TIMESTAMPADD(HOUR, CAST(pClientTimeZone AS SIGNED),UTC_TIMESTAMP());
    set @IsSent = 1;
    set @IsManual = 1;
    
    if @SendToEmployeeId is not null and @SendToEmployeeId <> '' then
		set @To = (select Email from  employee  where EmployeeId = @SendToEmployeeId);
    end if;
    
    INSERT INTO `email_log`(`From`, `To`,CC, SendToEmployeeId, IsSent, IsManual, EmailTypeId, `Subject`,OrgId, SentDate)
                        VALUES (@From, @To,@CC,@SendToEmployeeId,@IsSent,@IsManual,@EmailTypeId,@Subject,@OrgId, @SentDate);
                        
	set @temp_id = @lst_uuid; -- last id inserted into table email_log
    
    -- select * from inc_email_log  where EmailLogId =:EmailLogId
    
    INSERT INTO `inc_email_log`(HistIncidentId, EmailLogId)
		select HistIncidentId,@temp_id from inc_email_log  where EmailLogId =pEmailLogId;
        
	-- select * from corr_act_email  where EmailLogId =:EmailLogId
    
    INSERT INTO `corr_act_email`(HistCorrectiveActionId, EmailLogId)
         select HistCorrectiveActionId,@temp_id from corr_act_email  where EmailLogId =pEmailLogId;
         
   SELECT @temp_id as EmailLogId, @To as `To`, @Subject as `Subject`;
                        
END;
