CREATE PROCEDURE ABCanTrackV2.cleanCorrectiveAction()
  BEGIN
	DECLARE vCorrectiveActionId VARCHAR(100); 
	DECLARE vIncidentId VARCHAR(100); 
	DECLARE vCorrActStatusId VARCHAR(100); 
	DECLARE vPriorityId VARCHAR(100); 
	DECLARE vAssignedToId VARCHAR(100); 
	DECLARE vStartDate DATETIME; 
	DECLARE vTargetEndDate DATETIME; 
	DECLARE vActualEndDate DATETIME; 
	DECLARE vEstimatedCost DECIMAL(10,2); 
	DECLARE vTaskDescription TEXT; 
	DECLARE vOutComeFollowUp TEXT; 
	DECLARE vDesiredResults BIT(1); 
	DECLARE vComments TEXT; 
	DECLARE vAssignedById VARCHAR(100); 

DECLARE finish INT DEFAULT 0;

DECLARE e_cursor CURSOR FOR
SELECT * FROM corrective_action WHERE IncidentId IN(
SELECT IncidentId FROM (
SELECT COUNT(*) AS c,TaskDescription,incident.IncidentId,incidentdate FROM ABCanTrackV2.corrective_action
JOIN incident ON(corrective_action.incidentId = incident.incidentid)
-- WHERE TaskDescription <> '' AND TaskDescription IS NOT NULL
GROUP BY TaskDescription,incident.IncidentId,AssignedToId, AssignedById,StartDate,TargetEndDate
HAVING c > 1 
) AS tmp
)
ORDER BY IncidentId, TaskDescription;
DECLARE CONTINUE HANDLER FOR NOT FOUND SET finish = 1;

OPEN e_cursor;

SET @counter = 0;

x_loop: LOOP

	FETCH e_cursor INTO vCorrectiveActionId,vIncidentId,vCorrActStatusId,vPriorityId,vAssignedToId,vStartDate,vTargetEndDate,
     vActualEndDate,vEstimatedCost,vTaskDescription,vOutComeFollowUp,
     vDesiredResults,vComments,vAssignedById;
     
     IF finish = 1 THEN
		LEAVE x_loop;
     END IF;

	DELETE FROM corrective_action WHERE 
    IncidentId=vIncidentId
    AND IFNULL(PriorityId, '') = IFNULL(vPriorityId, '')
    AND AssignedToId=vAssignedToId
    AND IFNULL(StartDate, '') = IFNULL(vStartDate, '')
    AND IFNULL(TargetEndDate,'') = IFNULL(vTargetEndDate,'')
	AND TaskDescription = vTaskDescription
    AND IFNULL(AssignedById, '') = IFNULL(vAssignedById, '')
     AND CorrectiveActionId <> vCorrectiveActionId;

	SET @counter = @counter + 1;

END LOOP x_loop;
CLOSE e_cursor;

SELECT @counter AS counter;

END;
