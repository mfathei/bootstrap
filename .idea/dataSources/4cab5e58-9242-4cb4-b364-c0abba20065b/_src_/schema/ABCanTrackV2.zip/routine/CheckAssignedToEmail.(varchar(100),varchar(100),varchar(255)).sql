CREATE FUNCTION ABCanTrackV2.CheckAssignedToEmail(`$OrgId`         VARCHAR(100), `$EmployeeId` VARCHAR(100),
                                                  `$EmailTypeCode` VARCHAR(255))
  RETURNS VARCHAR(255)
  BEGIN
IF $EmployeeId in (select employeeid from employee where employeeid in
		(select employeeid from email_to et inner join email_type emt  on et.EmailTypeId = emt.EmailTypeId where 
		et.orgid = $OrgId  
		and emailtypecode in ($EmailTypeCode, 'NewAndUpdatedAction'))
		or employeeid in 
		(select employeeid from emp_group where groupid in (select groupid from email_to et inner join email_type emt  on et.EmailTypeId = emt.EmailTypeId where 
		et.orgid = $OrgId 
		and emailtypecode in ($EmailTypeCode, 'NewAndUpdatedAction'))))
Then
		RETURN 'Found';
Else 
		Return 'NotFound';
End If;
END;
