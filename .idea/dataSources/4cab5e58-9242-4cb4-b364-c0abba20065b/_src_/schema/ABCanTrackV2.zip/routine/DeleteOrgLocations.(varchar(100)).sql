CREATE PROCEDURE ABCanTrackV2.DeleteOrgLocations(IN `$OrgId` VARCHAR(100))
  BEGIN
	DECLARE $Count INT;
    
    
    -- Step1: CommonDB.location_request
	SET $Count = (SELECT COUNT(*) FROM `CommonDB`.`location_request` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgLocations',  'CommonDB.location_request', NULL, $Count, 1);
    
	-- ************
	DELETE FROM `CommonDB`.`location_request` WHERE OrgId = $OrgId;
    -- #
    
    
    -- Step2: ABCanTrackV2.location4
	SET $Count = (SELECT COUNT(*) FROM `ABCanTrackV2`.`location4` WHERE Location3Id IN (SELECT Location3Id FROM `ABCanTrackV2`.`location3` WHERE Location2Id IN (SELECT location2Id FROM `ABCanTrackV2`.`location2` WHERE Location1Id IN (SELECT Location1Id FROM `ABCanTrackV2`.`location1` WHERE OrgId = $OrgId))));
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgLocations',  'ABCanTrackV2.location4', NULL, $Count,2);
    
	-- ************
	DELETE FROM `ABCanTrackV2`.`location4` WHERE Location3Id IN (SELECT Location3Id FROM `ABCanTrackV2`.`location3` WHERE Location2Id IN (SELECT location2Id FROM `ABCanTrackV2`.`location2` WHERE Location1Id IN (SELECT Location1Id FROM `ABCanTrackV2`.`location1` WHERE OrgId = $OrgId)));
    -- #
    
    
    -- Step3: CommonDB.location4
	SET $Count = (SELECT COUNT(*) FROM `CommonDB`.`location4` WHERE Location3Id IN (SELECT Location3Id FROM `CommonDB`.`location3` WHERE Location2Id IN (SELECT location2Id FROM `CommonDB`.`location2` WHERE Location1Id IN (SELECT Location1Id FROM `CommonDB`.`location1` WHERE OrgId = $OrgId))));
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgLocations',  'CommonDB.location4', NULL, $Count,3);
    
	-- ************
	DELETE FROM `CommonDB`.`location4` WHERE Location3Id IN (SELECT Location3Id FROM `CommonDB`.`location3` WHERE Location2Id IN (SELECT location2Id FROM `CommonDB`.`location2` WHERE Location1Id IN (SELECT Location1Id FROM `CommonDB`.`location1` WHERE OrgId = $OrgId)));
    -- #
    
    
    -- Step4: ABCanTrackV2.location3
	SET $Count = (SELECT COUNT(*) FROM `ABCanTrackV2`.`location3` WHERE Location2Id IN (SELECT location2Id FROM `ABCanTrackV2`.`location2` WHERE Location1Id IN (SELECT Location1Id FROM `ABCanTrackV2`.`location1` WHERE OrgId = $OrgId)));
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgLocations',  'ABCanTrackV2.location3', NULL, $Count,4);
    
	-- ************
	DELETE FROM `ABCanTrackV2`.`location3` WHERE Location2Id IN (SELECT location2Id FROM `ABCanTrackV2`.`location2` WHERE Location1Id IN (SELECT Location1Id FROM `ABCanTrackV2`.`location1` WHERE OrgId = $OrgId));
    -- #
    
    
    -- Step5: CommonDB.location3
	SET $Count = (SELECT COUNT(*) FROM `CommonDB`.`location3` WHERE Location2Id IN (SELECT location2Id FROM `CommonDB`.`location2` WHERE Location1Id IN (SELECT Location1Id FROM `CommonDB`.`location1` WHERE OrgId = $OrgId)));
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgLocations',  'CommonDB.location3', NULL, $Count,5);
    
	-- ************
	DELETE FROM `CommonDB`.`location3` WHERE Location2Id IN (SELECT location2Id FROM `CommonDB`.`location2` WHERE Location1Id IN (SELECT Location1Id FROM `CommonDB`.`location1` WHERE OrgId = $OrgId));
    -- #
    
    
    -- Step6: ABCanTrackV2.location2
	SET $Count = (SELECT COUNT(*) FROM `ABCanTrackV2`.`location2` WHERE Location1Id IN (SELECT Location1Id FROM `ABCanTrackV2`.`location1` WHERE OrgId = $OrgId));
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgLocations',  'ABCanTrackV2.location2', NULL, $Count,6);
    
	-- ************
	DELETE FROM `ABCanTrackV2`.`location2` WHERE Location1Id IN (SELECT Location1Id FROM `ABCanTrackV2`.`location1` WHERE OrgId = $OrgId);
    -- #
    
    
    -- Step7: CommonDB.location2
	SET $Count = (SELECT COUNT(*) FROM `CommonDB`.`location2` WHERE Location1Id IN (SELECT Location1Id FROM `CommonDB`.`location1` WHERE OrgId = $OrgId));
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgLocations',  'CommonDB.location2', NULL, $Count,7);
    
	-- ************
	DELETE FROM `CommonDB`.`location2` WHERE Location1Id IN (SELECT Location1Id FROM `CommonDB`.`location1` WHERE OrgId = $OrgId);
    -- #
    
    
    -- Step8: ABCanTrackV2.location1
	SET $Count = (SELECT COUNT(*) FROM `ABCanTrackV2`.`location1` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgLocations',  'ABCanTrackV2.location1', NULL, $Count,8);
    
	-- ************
	DELETE FROM `ABCanTrackV2`.`location1` WHERE OrgId = $OrgId;
    -- #
    
    
    -- Step9: CommonDB.location1
	SET $Count = (SELECT COUNT(*) FROM `CommonDB`.`location1` WHERE OrgId = $OrgId);
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgLocations',  'CommonDB.location1', NULL, $Count,9);
    
	-- ************
	DELETE FROM `CommonDB`.`location1` WHERE OrgId = $OrgId;
    -- #
    
    -- Step10: DONE
	-- ************
	INSERT INTO `ABCanTrackV2`.`delete_org_log`
		(`OrgId`, `ProcedureName`, `TableName`, `EmployeeId`, `Count`, `Step`) 
	VALUES
		($OrgId, 'DeleteOrgLocations',  'DONE', NULL, $Count,10);
	
END;
