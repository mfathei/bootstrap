CREATE PROCEDURE ABCanTrackV2.insert_Into_FieldValue(IN pFieldId       VARCHAR(100), IN pOptionId VARCHAR(100),
                                                     IN pIncidentId    VARCHAR(100), IN pFieldValue TEXT,
                                                     IN pTableKeyValue VARCHAR(100), IN pTablekeyId VARCHAR(100))
  BEGIN
IF LENGTH(pFieldValue) > 0 THEN
INSERT INTO `field_value`
		(FieldId, OptionId, IncidentId, FieldValue, TableKeyValue, TablekeyId)
	VALUES
		(pFieldId,pOptionId,pIncidentId,pFieldValue,pTableKeyValue,pTablekeyId);
                                                    
                                                    
	CALL InsertInto_hist_field_value(@NewFieldValueId);
ELSE 
	SET @ocount = (SELECT COUNT(OptionId) FROM `option`  WHERE FieldId = pFieldId AND OptionId = pOptionId);
	SET @NewFieldValueId = NULL;
	IF @ocount > 0 THEN
		INSERT INTO `field_value`
			(FieldId, OptionId, IncidentId, FieldValue, TableKeyValue, TablekeyId)
		VALUES
			(pFieldId,pOptionId,pIncidentId,pFieldValue,pTableKeyValue,pTablekeyId);
							    
							    
		CALL InsertInto_hist_field_value(@NewFieldValueId);
	END IF;
END IF;
SELECT @NewFieldValueId AS FieldValueId;
END;
