CREATE FUNCTION ABCanTrackV2.getHowDidThatDone(`$VehicleDamageId` VARCHAR(100), `$OriginalVehicleDamageId` VARCHAR(100))
  RETURNS TEXT
  BEGIN
IF $OriginalVehicleDamageId is null   or $OriginalVehicleDamageId  =''   then
	SET $OriginalVehicleDamageId = $VehicleDamageId ;
END IF;
SET SESSION group_concat_max_len = 10000;
SELECT (GROUP_CONCAT(DATE_FORMAT(UpdatedDate, '%b %d %Y') ,' ', '(',  CONCAT(firstname ,' ', lastname) ,')',': <pr>', HowDidThatDone separator '<br><br>' ) ) AS HowDidThatDone   
 INTO @newHowDidThatDone 
 FROM(
 SELECT UpdatedDate, HowDidThatDone, firstname,lastname FROM hist_vehicle_damage hi 
JOIN employee e ON e.EmployeeId = hi.UpdatedbyId
 WHERE OriginalVehicleDamageId = $OriginalVehicleDamageId  
ORDER BY UpdatedDate asc  ) temp ; 
RETURN @newHowDidThatDone;
END;
