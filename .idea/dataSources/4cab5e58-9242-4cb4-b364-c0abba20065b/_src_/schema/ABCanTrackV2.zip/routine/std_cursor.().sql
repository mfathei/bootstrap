CREATE PROCEDURE ABCanTrackV2.std_cursor()
  BEGIN
    DECLARE finish INT DEFAULT 0;
    DECLARE stdname VARCHAR(100);
    DECLARE std_name_sur CURSOR FOR SELECT FieldCode FROM body_area;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET finish=1;
    OPEN std_name_sur;
    std_name_loop: LOOP
        FETCH std_name_sur INTO stdname;
        IF finish=1 THEN
            LEAVE std_name_loop;
        END IF;
        SELECT stdname;
    END LOOP std_name_loop;
    CLOSE std_name_sur;
END;
