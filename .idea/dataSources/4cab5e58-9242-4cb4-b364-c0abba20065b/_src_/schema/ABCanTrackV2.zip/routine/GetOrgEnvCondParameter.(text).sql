CREATE PROCEDURE ABCanTrackV2.GetOrgEnvCondParameter(IN xmlData TEXT)
  BEGIN
SET @page = extractvalue(xmlData, '//page');
SET @limit = extractvalue(xmlData, '//limit');
SET @sortOrder =  extractvalue(xmlData, '//sortOrder');
SET @index =  extractvalue(xmlData, '//index');
SET @Mine =  extractvalue(xmlData, '//Mine');
SET @CreatorId = extractvalue(xmlData, '//CreatorId');
SET @Export =  extractvalue(xmlData, '//Export');
SET @OrgId =  extractvalue(xmlData, '//OrgId');
SET @checkOrg =  extractvalue(xmlData, '//check');
SET @EnvConditionId =  extractvalue(xmlData, '//EnvConditionId');
set @selectquery ="SELECT OrgName,env_condition.OrgId, EnvConditionName as ParentEnvConditionName, env_cond_parameter.EnvConditionId, EnvCondParameterId ,  EnvCondParameterName, env_cond_parameter.`Order`";
                
set @queryFrom = " from  env_cond_parameter
inner join env_condition on env_condition.EnvConditionId = env_cond_parameter.EnvConditionId inner join organization on env_condition.OrgId = organization.OrgId";
SET @queryWhere = ' where 1= 1 ';
SET @queryWhere = CONCAT(@queryWhere,' and env_cond_parameter.Hide = 0 ');
SET @queryWhere = CONCAT(@queryWhere,' and env_condition.Hide = 0 ');
if(@checkOrg  = 'false') then 
SET @queryWhere = CONCAT(@queryWhere,' and env_condition.OrgId = "', @Orgid,'"');
end if;
 
 
if(@EnvConditionId <> 'null') then 
SET @queryWhere = CONCAT(@queryWhere,' and env_condition.EnvConditionId = "', @EnvConditionId,'"');
end if;
SET @myArrayOfValue = 'EnvCondParameterId,EnvCondParameterName,Order,ParentEnvConditionName,';
SET @Postition = LOCATE(',', @myArrayOfValue);
WHILE ( @Postition > 0 ) DO
 SET @STR = SUBSTRING(@myArrayOfValue, 1, @Postition-1);
 SET @myArrayOfValue = SUBSTRING(@myArrayOfValue, @Postition + 1);
 SET @Col =  extractvalue(xmlData, CONCAT('//',@STR));
 IF (@Col != '' AND @Col !='NULL') THEN
 if( @STR = 'ParentEnvConditionName') then set  @STR = 'EnvConditionName';  end if;
 
 if( @STR = 'Order') then set  @STR = 'env_cond_parameter.`Order`';  end if;
  SET @queryWhere = CONCAT(@queryWhere,CONCAT(' AND    ',@STR,' like '"'%", @Col ,"%'")); 
 END IF;
 
 SET @Postition = LOCATE(',', @myArrayOfValue);
END WHILE;
SET @querycount = CONCAT( 'SELECT count(*) into @cnt ', @queryFrom, @queryWhere );
PREPARE stmt1 FROM @querycount;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
	
SET @selectquery = CONCAT (@selectquery,', ', @cnt, ' as Count ');
SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );
if( @index = 'Order') then set  @index = '`Order`';  end if;
if( @index = 'ParentOrder') then set  @index = '`Order`';  end if;
if( @index = 'ParentEnvConditionName') then set  @index = 'EnvConditionName';  end if;
if( @index = 'Order, EnvConditionName') then set  @index = 'EnvConditionName,`Order`';  end if;
SET @query = CONCAT(@query, ' order by ', @index,'  ', @sortOrder);
if( @Export ="false") then
SET @page = (@page - 1) * @limit;
SET @query = CONCAT(@query, ' LIMIT ', @limit ,' OFFSET ',  @page);
end if;
--  select  @query;
PREPARE stmt1 FROM @query;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
END;
