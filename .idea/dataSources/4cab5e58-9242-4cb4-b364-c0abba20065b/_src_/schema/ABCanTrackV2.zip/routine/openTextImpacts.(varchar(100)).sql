CREATE PROCEDURE ABCanTrackV2.openTextImpacts(IN `$IncidentId` VARCHAR(100))
  begin
   set session group_concat_max_len = 10000;
  SELECT distinct 
		`impact`.ImpactId,
        `impact_type`.`ImpactTypeName` AS `ImpactTypeId`,
        `impact_type`.`ImpactTypeCode` AS `ImpactTypeCode`,
        `impact_sub_type`.`ImpactSubTypeName` AS `ImpactSubTypeId`,
        `impact`.`IntEmployeeName1` AS `IntEmployeeName1`,
        `impact`.`IntEmployeeName2` AS `IntEmployeeName2`,
        `impact`.`IntEmployeeName3` AS `IntEmployeeName3`,
        `impact`.`IntEmployeeDept1` AS `IntEmployeeDept1`,
        `impact`.`IntEmployeeDept2` AS `IntEmployeeDept2`,
        `impact`.`IntEmployeeDept3` AS `IntEmployeeDept3`,
        `impact`.`PrimRespondName` AS `PrimRespondName`,
        `impact`.`Description` AS `Description`, 
        GETIMPACTDESCRIPTION2(`hist_impact`.`ImpactId`,
                `hist_impact`.`OriginalImpactId`) AS `OldImpactDescription`,
        -- `impact`.`EstimatedCost` AS `ImpactEstimatedCost`,
		CASE `impact`.`EstimatedCost` WHEN '0.00' THEN ''  END AS `ImpactEstimatedCost`,
        (SELECT 
                GROUP_CONCAT(DISTINCT `external_agency`.`ExtAgencyName`
                        SEPARATOR ', ')
            FROM
                (`impacts_ext_agency`
                JOIN `external_agency` ON ((`external_agency`.`ExtAgencyId` = `impacts_ext_agency`.`ExtAgencyId`)))
            WHERE
                (`impacts_ext_agency`.`ImpactId` = `impact`.`ImpactId`)
            GROUP BY `impacts_ext_agency`.`ImpactId`) AS `ExtAgencyId`
    FROM
        (((`impact`
        JOIN `impact_sub_type` ON ((`impact_sub_type`.`ImpactSubTypeId` = `impact`.`ImpactSubTypeId`)))
        JOIN `impact_type` ON ((`impact_sub_type`.`ImpactTypeId` = `impact_type`.`ImpactTypeId`)))
        JOIN `hist_impact` ON ((`hist_impact`.`ImpactId` = `impact`.`ImpactId`))) 
	where impact.Incidentid = $IncidentId;
        end;
