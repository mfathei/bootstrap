CREATE FUNCTION ABCanTrackV2.getWhatWasIt(`$SpillReleaseId` VARCHAR(100), `$OriginalSpillReleaseId` VARCHAR(100))
  RETURNS TEXT
  BEGIN
if $OriginalSpillReleaseId is null   or $OriginalSpillReleaseId  =''   then
	set $OriginalSpillReleaseId = $SpillReleaseId ;
end if;
set session group_concat_max_len = 10000;
select (group_concat(DATE_FORMAT(UpdatedDate, '%b %d %Y') ,' ', '(',  concat(firstname ,' ', lastname) ,')',': <pr>', WhatWasIt separator '<br><br>' ) ) as WhatWasIt   
 into @newWhatWasIt 
 from(
 select UpdatedDate, WhatWasIt, firstname,lastname FROM hist_spill_release hi 
join employee e on e.EmployeeId = hi.UpdatedbyId
 where OriginalSpillReleaseId = $OriginalSpillReleaseId  
order by UpdatedDate asc  ) temp ; 
return @newWhatWasIt;
END;
