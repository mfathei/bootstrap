CREATE PROCEDURE ABCanTrackV2.ins_org_env_conditions(IN `$NewOrgId` VARCHAR(100), IN `$LangId` VARCHAR(100))
  BEGIN
DECLARE p_finished INTEGER DEFAULT 0;
DECLARE $ocode, $oid, $NewId VARCHAR(255);
DECLARE p_cursor CURSOR FOR
 select o.EnvConditionId,o.FieldCode from `ABCanTrackV2`.env_condition o
 WHERE o.OrgId IS NULL AND o.LanguageId = $LangId;
 -- declare NOT FOUND handler
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET p_finished = 1;
    
 open p_cursor;
-- FETCH g_p_cursor INTO $gid , $fcode, $pcode, $pid;
ex: LOOP
	FETCH p_cursor INTO  $oid ,$ocode;
	IF p_finished = 1 THEN 
		LEAVE ex;
	END IF;
-- select $fcode,$pcode;
 INSERT INTO `ABCanTrackV2`.`env_condition`
(
    `env_condition`.`FieldCode`,
    `env_condition`.`LanguageId`,
    `env_condition`.`EnvConditionName`,
    `env_condition`.`OrgId`,
    `env_condition`.`IsMulti`,
    `env_condition`.`Order`,
    `env_condition`.`LastUpdateDate`,
    `env_condition`.`EditingBy`,
    `env_condition`.`Hide`
)
SELECT 
    `env_condition`.`FieldCode`,
    `env_condition`.`LanguageId`,
    `env_condition`.`EnvConditionName`,
    $NewOrgId,
    `env_condition`.`IsMulti`,
    `env_condition`.`Order`,
    Current_timestamp(),
    `env_condition`.`EditingBy`,
    `env_condition`.`Hide`
FROM `ABCanTrackV2`.`env_condition` where EnvConditionId = $oid AND LanguageId = $LangId;
 SET $NewId = (select o.EnvConditionId from `ABCanTrackV2`.env_condition o WHERE o.OrgId=$NewOrgId AND o.FieldCode=$ocode AND o.LanguageId = $LangId);
 CALL ins_org_env_cond_params($oid,$NewId,$LangId);
END LOOP ex;
CLOSE p_cursor;
END;
