CREATE PROCEDURE ABCanTrackV2.GetOrgCorrActStatus(IN xmlData TEXT)
  BEGIN
SET @Orgid = extractvalue(xmlData, '//OrgId');
SET @page = extractvalue(xmlData, '//page');
SET @limit = extractvalue(xmlData, '//limit');
SET @sortOrder =  extractvalue(xmlData, '//sortOrder');
SET @index =  extractvalue(xmlData, '//index');
SET @Mine =  extractvalue(xmlData, '//Mine');
SET @CreatorId = extractvalue(xmlData, '//CreatorId');
SET @Export =  extractvalue(xmlData, '//Export');
SET @checkOrg =  extractvalue(xmlData, '//check');
set @selectquery ="SELECT OrgName, corr_act_status.OrgId, CorrActStatusId ,  CorrActStatusName, `Order`";
                
set @queryFrom = " from  corr_act_status inner join organization on corr_act_status.OrgId = organization.OrgId";
SET @queryWhere = ' where 1= 1 ';
if(@checkOrg  = 'false') then 
SET @queryWhere = CONCAT(@queryWhere,' and corr_act_status.OrgId = "', @Orgid,'"');
end if;
SET @queryWhere = CONCAT(@queryWhere,' and corr_act_status.Hide = 0 ');
SET @myArrayOfValue = ' CorrActStatusId,CorrActStatusName,Order,';
SET @Postition = LOCATE(',', @myArrayOfValue);
WHILE ( @Postition > 0 ) DO 
 SET @STR = SUBSTRING(@myArrayOfValue, 1, @Postition-1);
 SET @myArrayOfValue = SUBSTRING(@myArrayOfValue, @Postition + 1);
 SET @Col =  extractvalue(xmlData, CONCAT('//',@STR));
 IF (@Col != '' AND @Col !='NULL') THEN
  SET @queryWhere = CONCAT(@queryWhere,CONCAT(' AND    `',@STR,'` like '"'%", @Col ,"%'")); 
 END IF;
 
 SET @Postition = LOCATE(',', @myArrayOfValue);
END WHILE;
SET @querycount = CONCAT( 'SELECT count(*) into @cnt ', @queryFrom, @queryWhere );
PREPARE stmt1 FROM @querycount;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
	
SET @selectquery = CONCAT (@selectquery,', ', @cnt, ' as Count ');
SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );
if( @index = 'Order') then set  @index = '`Order`';  end if;
if( @index = 'Order, CorrActStatusName') then set  @index = '`Order`,CorrActStatusName';  end if;
SET @query = CONCAT(@query, ' order by ', @index,'  ', @sortOrder);
if( @Export ="false") then
SET @page = (@page - 1) * @limit;
SET @query = CONCAT(@query, ' LIMIT ', @limit ,' OFFSET ',  @page);
end if;
-- select  @query;
PREPARE stmt1 FROM @query;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
END;
