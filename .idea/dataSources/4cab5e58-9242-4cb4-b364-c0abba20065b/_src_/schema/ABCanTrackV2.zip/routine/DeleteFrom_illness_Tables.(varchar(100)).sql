CREATE PROCEDURE ABCanTrackV2.DeleteFrom_illness_Tables(IN `$IncidentId` VARCHAR(100))
  BEGIN
DECLARE fetch_status int default 0;
DECLARE $IllnessId varchar(100);
DECLARE incident_cursor CURSOR FOR 
select IllnessId from illness where incidentid = $IncidentId;
DECLARE CONTINUE HANDLER FOR NOT FOUND SET fetch_status = 100;
Open Incident_cursor;
FETCH NEXT FROM incident_cursor 
		INTO $IllnessId;
WHILE fetch_status = 0
			do
delete from illness_symptoms where IllnessId = $IllnessId;
delete from impacts_ext_agency where IllnessId = $IllnessId;
FETCH NEXT FROM incident_cursor 
			INTO $IllnessId;
		END while;
	CLOSE incident_cursor;
delete from illness where incidentid = $incidentid;
END;
