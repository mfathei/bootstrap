CREATE PROCEDURE ABCanTrackV2.InsertOEDepartmentValue(IN `$IncidentId` VARCHAR(100))
  BEGIN
DECLARE $HistIncidentId VARCHAR(100);
-- DECLARE $OEDepartmentName TEXT;
DECLARE $VersionNumber INT;
SET $VersionNumber = (SELECT MAX(VersionNumber) FROM hist_incident WHERE IncidentId = $IncidentId);
SET $HistIncidentId = (SELECT HistIncidentId FROM hist_incident WHERE IncidentId = $IncidentId AND VersionNumber = $VersionNumber);
SET @OEDepartmentName = (SELECT GROUP_CONCAT(OEDepartmentName SEPARATOR ' ;| ') FROM oe_department WHERE OEDepartmentid IN (SELECT OEDepartmentid FROM inc_oe_department WHERE incidentid = $incidentid));
UPDATE hist_incident
SET OEDepartmentName = @OEDepartmentName
WHERE HistIncidentId = $HistIncidentId;
END;
