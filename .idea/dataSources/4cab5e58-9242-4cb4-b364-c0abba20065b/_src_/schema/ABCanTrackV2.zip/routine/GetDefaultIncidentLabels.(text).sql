CREATE PROCEDURE ABCanTrackV2.GetDefaultIncidentLabels(IN xmlData TEXT)
  BEGIN
SET @Orgid = extractvalue(xmlData, '//OrgId');
SET @page = extractvalue(xmlData, '//page');
SET @limit = extractvalue(xmlData, '//limit');
SET @sortOrder =  extractvalue(xmlData, '//sortOrder');
SET @index =  extractvalue(xmlData, '//index');
SET @Mine =  extractvalue(xmlData, '//Mine');
SET @CreatorId = extractvalue(xmlData, '//CreatorId');
SET @Export =  extractvalue(xmlData, '//Export'); 
SET @ShowDefaultFields =  extractvalue(xmlData, '//ShowDefaultFields');
SET @ShowCustomFields =  extractvalue(xmlData, '//ShowCustomFields');
SET @LanguageCode =  extractvalue(xmlData, '//LanguageCode');
SET @lblYes = (select GetItemLabel(@LanguageCode,'isreportableyes'));
SET @lblNo = (select GetItemLabel(@LanguageCode,'isreportableno'));


set @selectquery =concat('SELECT FieldName, FieldId, IsEditable,DefaultHelpMeName as HelpTitle, DefaultHelpMeDescription as HelpDesc, DefaultFieldLabel as FieldLabel, sub_tab.SubTabLabel ,sub_tab.SubTabName, CASE IsEditable WHEN '0' THEN '',@lblNo,'' WHEN '1' THEN '', @lblYes,'' END  as IsEditable, CASE field.IsMandatory WHEN '0' THEN '',@lblNo,'' WHEN '1' THEN '', @lblYes,'' END AS IsMandatory, FieldDescription ,field.`Order` , AdminNotes , CASE field.IsMandatory WHEN '0' THEN '0' WHEN '1' THEN '1' END AS DefaultMandatory, CASE field.IsEditable  WHEN '0' THEN '0' WHEN '1' THEN '1' END  as Editable ');

set @queryFrom = " from field
					inner join sub_tab on sub_tab.SubTabId = field.SubTabId
                    join `language` l on l.LanguageId= field.LanguageId
					";
SET @queryWhere = ' where 1= 1  ';
SET @queryWhere = CONCAT(@queryWhere,'  AND LanguageCode = "',  @LanguageCode,'"' ); 

SET @queryWhere = CONCAT(@queryWhere,'  and OrgId is null and field.Hide = 0   ');
SET @myArrayOfValue = 'FieldDescription,HelpTitle,HelpDesc,FieldLabel,SubTabLabel,FieldName,';
SET @Postition = LOCATE(',', @myArrayOfValue);
WHILE ( @Postition > 0 ) DO
 SET @STR = SUBSTRING(@myArrayOfValue, 1, @Postition-1);
 SET @myArrayOfValue = SUBSTRING(@myArrayOfValue, @Postition + 1);
 SET @Col =  extractvalue(xmlData, CONCAT('//',@STR));
 IF (@Col != '' AND @Col !='NULL') THEN
	IF (@STR  = 'HelpTitle' ) then set @STR= 'DefaultHelpMeName';  END IF;
    IF (@STR  = 'FieldLabel' ) then set @STR= 'DefaultFieldLabel';  END IF;
	IF (@STR  = 'HelpDesc' ) then set @STR= 'DefaultHelpMeDescription';  END IF;
	SET @queryWhere = CONCAT(@queryWhere,CONCAT(' AND ',@STR,' like('"'%", @Col ,"%'"') ')); 
 END IF;
 
 SET @Postition = LOCATE(',', @myArrayOfValue);
END WHILE; 
SET @IsMandatory =  extractvalue(xmlData, '//IsMandatory');
IF (@IsMandatory != '' AND @IsMandatory !='NULL') THEN
	IF( @IsMandatory  != '2' ) THEN 
		SET @queryWhere = CONCAT(@queryWhere,'  AND IsMandatory = ',  @IsMandatory ); 
	END IF;	
END IF;
SET @IsEditable =  extractvalue(xmlData, '//IsEditable');
IF (@IsEditable != '' AND @IsEditable !='NULL') THEN
	IF( @IsEditable  != '2' ) THEN 
		SET @queryWhere = CONCAT(@queryWhere,'  AND IsEditable = ',  @IsEditable ); 
	END IF;	
END IF;
-- select  @queryWhere;
SET @querycount = CONCAT( 'SELECT count(*) into @cnt ', @queryFrom, @queryWhere );
PREPARE stmt1 FROM @querycount;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
	
SET @selectquery = CONCAT (@selectquery,', ', @cnt, ' as Count ');
SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );
if( @index = 'Order') then set  @index = '`Order`';  end if;
SET @query = CONCAT(@query, ' order by ', @index,'  ', @sortOrder);
if( @Export ="false") then
SET @page = (@page - 1) * @limit;
SET @query = CONCAT(@query, ' LIMIT ', @limit ,' OFFSET ',  @page);
end if;
-- select  @query;
PREPARE stmt1 FROM @query;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
END;
