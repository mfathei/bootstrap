CREATE PROCEDURE ABCanTrackV2.GetRecentActivity(IN `$EmployeeId` VARCHAR(100), IN `$OrgId` VARCHAR(100))
  BEGIN
SELECT DISTINCT
    `HistIncidentId`,
    `IncidentId`,
	`EventTypeName` As EventTypeId,
    'Incident' As ReportType,
    `OrgId`,
    `EmployeeName`,
    `IncidentDate`,
    `IncidentHour`,
    `IncidentMinute`,
    `IsEmerRP`,
    `RepName`,
    `RepEmail`,
    `RepPosition`,
    `RepCompany`,
    `RepPrimaryPhone`,
    `RepAlternatePhone`,
    `Location1Name` AS Location1Id,
    `Location2Name` AS Location2Id,
    `Location3Name`  AS Location3Id,
    `Location4Name`  AS Location4Id,
    `OtherLocation`,
    `OperationTypeName`,
    `UpdatedById`,     
		CASE 
            WHEN `EditingBy` IS NULL
            THEN `UpdatedDate`
            ELSE `LastUpdateDate`
        END as orderDate,   
    `VersionNumber`,
	`EditingBy`,
	`IncidentNumber`,
    `IncDescription` AS Summary
   
 FROM 
(
SELECT * FROM
(
SELECT 
	`hi`.`HistIncidentId`, 
    `hi`.`IncidentId`,
    `hi`.`EventTypeName`,
    `hi`.`OrgId`,
    `hi`.`EmployeeName`,
    `hi`.`IncidentDate`,
    `hi`.`IncidentHour`,
    `hi`.`IncidentMinute`,
    `hi`.`IsEmerRP`,
    `hi`.`RepName`,
    `hi`.`RepEmail`,
    `hi`.`RepPosition`,
    `hi`.`RepCompany`,
    `hi`.`RepPrimaryPhone`,
    `hi`.`RepAlternatePhone`,
    `hi`.`Location1Name`,
    `hi`.`Location2Name`,
    `hi`.`Location3Name`,
    `hi`.`Location4Name`,
    `hi`.`OtherLocation`,
    `hi`.`OperationTypeName`,
    `hi`.`UpdatedById`,
   --  `hi`.`UpdatedDate`,
    `hi`.`VersionNumber`,
	`i`.`EditingBy`,
	`i`.`incidentnumber` ,
	-- `ho`.`HistoryOperationName`,
    `i`.`LastUpdateDate`,
	`hi`.`UpdatedDate`,
    `i`.`IncDescription`
   
	-- 'Firstqry' as qry
FROM hist_incident hi 
INNER JOIN incident i ON hi.IncidentId = i.IncidentId
-- INNER JOIN history_operation ho ON hi.HistoryOperationId = ho.HistoryOperationId
WHERE HistIncidentId = HIST_INCIDENT(`hi`.`IncidentId`)
-- IN (SELECT MAX(hi2.HistIncidentId) FROM hist_incident hi2  GROUP BY IncidentId)
-- and hi.IncidentId IN (SELECT IncidentId FROM hist_incident 
and UpdatedById = $EmployeeId AND  hi.OrgId = $OrgId
-- )
and (i.IsDeleted <> 1 and i.Hide <> 1)
order by `hi`.`UpdatedDate`  desc
LIMIT 10
) Fqry
UNION 
SELECT 
	`hi`.`HistIncidentId`,
    `hi`.`IncidentId`,
    `hi`.`EventTypeName`,
    `hi`.`OrgId`,
    `hi`.`EmployeeName`,
    `hi`.`IncidentDate`,
    `hi`.`IncidentHour`,
    `hi`.`IncidentMinute`,
    `hi`.`IsEmerRP`,
    `hi`.`RepName`,
    `hi`.`RepEmail`,
    `hi`.`RepPosition`,
    `hi`.`RepCompany`,
    `hi`.`RepPrimaryPhone`,
    `hi`.`RepAlternatePhone`,
    `hi`.`Location1Name`,
    `hi`.`Location2Name`,
    `hi`.`Location3Name`,
    `hi`.`Location4Name`,
    `hi`.`OtherLocation`,
    `hi`.`OperationTypeName`,
    `hi`.`UpdatedById`,
   -- `hi`.`UpdatedDate`,
    `hi`.`VersionNumber`,
	`i`.`EditingBy`,
	`i`.`incidentnumber`,
	-- 'Lock' as HistoryOperationName-- ,
	`i`.`LastUpdateDate` ,
    `hi`.`UpdatedDate`,
    `i`.`IncDescription`
	-- 'Secondqry' as qry
FROM hist_incident hi
 INNER JOIN incident i ON hi.IncidentId = i.IncidentId
WHERE HistIncidentId = HIST_INCIDENT(`hi`.`IncidentId`)
and hi.OrgId = $OrgId
--  IN (SELECT MAX(hi2.HistIncidentId) FROM hist_incident hi2 WHERE IncidentId IN (SELECT IncidentId FROM incident WHERE EditingBy = $EmployeeId AND  orgid = $OrgId) GROUP BY IncidentId)
and (i.IsDeleted <> 1 and i.Hide <> 1)
and EditingBy = $EmployeeId 
) allqry
ORDER BY orderDate DESC;
END;
