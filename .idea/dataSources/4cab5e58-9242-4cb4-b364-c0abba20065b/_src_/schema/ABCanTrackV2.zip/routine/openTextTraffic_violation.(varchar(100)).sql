CREATE PROCEDURE ABCanTrackV2.openTextTraffic_violation(IN `$IncidentId` VARCHAR(100))
  begin
    set session group_concat_max_len = 10000;
    
      SELECT distinct 
      `traffic_violation`.`TrafficViolationId`,
        `impact_type`.`ImpactTypeName` AS `ImpactTypeId`,
        `impact_type`.`ImpactTypeCode` AS `ImpactTypeCode`,
        `impact_sub_type`.`ImpactSubTypeName` AS `ImpactSubTypeId`,
        `traffic_violation`.`IntEmployeeName1` AS `IntEmployeeName1`,
        `traffic_violation`.`IntEmployeeName2` AS `IntEmployeeName2`,
        `traffic_violation`.`IntEmployeeName3` AS `IntEmployeeName3`,
        `traffic_violation`.`IntEmployeeDept1` AS `IntEmployeeDept1`,
        `traffic_violation`.`IntEmployeeDept2` AS `IntEmployeeDept2`,
        `traffic_violation`.`IntEmployeeDept3` AS `IntEmployeeDept3`,
        `traffic_violation`.`PrimRespondName` AS `PrimRespondName`,
        `traffic_violation`.`Description` AS `Description`,
        GETIMPACTDESCRIPTION(`hist_traffic_violation`.`TrafficViolationId`,
                `hist_traffic_violation`.`OriginalTrafficViolationId`) AS `OldImpactDescription`,
       -- `traffic_violation`.`EstimatedCost` AS `ImpactEstimatedCost`,
        CASE `traffic_violation`.`EstimatedCost` WHEN '0.00' THEN ''  END AS `ImpactEstimatedCost`,
        (SELECT 
                GROUP_CONCAT(DISTINCT `external_agency`.`ExtAgencyName`
                        SEPARATOR ', ')
            FROM
                (`impacts_ext_agency`
                JOIN `external_agency` ON ((`external_agency`.`ExtAgencyId` = `impacts_ext_agency`.`ExtAgencyId`)))
            WHERE
                (`impacts_ext_agency`.`TrafficViolationId` = `traffic_violation`.`TrafficViolationId`)
            GROUP BY `impacts_ext_agency`.`TrafficViolationId`) AS `ExtAgencyId`,
        
        `traffic_violation`.`DriverName` AS `DriverName`,
        `traffic_violation`.`DriverLicence` AS `DriverLicence`,
        `vehicle_type`.`VehicleTypeName` AS `VehicleTypeName`,
        `traffic_violation`.`VehicleLicence` AS `VehicleLicence`,
        `traffic_violation`.`Details` AS `Details`,
        `traffic_violation`.`ValueOfFine` AS `ValueOfFine`,
        `traffic_violation`.`TicketNumber` AS `TicketNumber`,
        `traffic_violation`.`HowDidThatOccur` AS `HowDidThatOccur`,
        `traffic_violation`.`VehicleTypeId` AS `VehicleTypeId`,
        GETHOWDIDTHATOCCUR(`hist_traffic_violation`.`TrafficViolationId`,
                `hist_traffic_violation`.`OriginalTrafficViolationId`) AS `OldHowDidThatOccur`,
        GETDETAILS(`hist_traffic_violation`.`TrafficViolationId`,
                `hist_traffic_violation`.`OriginalTrafficViolationId`) AS `OldDetails`
    FROM
        ((((`traffic_violation`
        JOIN `impact_sub_type` ON ((`impact_sub_type`.`ImpactSubTypeId` = `traffic_violation`.`ImpactSubTypeId`)))
        JOIN `impact_type` ON ((`impact_sub_type`.`ImpactTypeId` = `impact_type`.`ImpactTypeId`)))
        LEFT JOIN `vehicle_type` ON ((`traffic_violation`.`VehicleTypeId` = `vehicle_type`.`VehicleTypeId`)))
        JOIN `hist_traffic_violation` ON ((`hist_traffic_violation`.`TrafficViolationId` = `traffic_violation`.`TrafficViolationId`)))
	where traffic_violation.Incidentid = $IncidentId;
    
        end;
