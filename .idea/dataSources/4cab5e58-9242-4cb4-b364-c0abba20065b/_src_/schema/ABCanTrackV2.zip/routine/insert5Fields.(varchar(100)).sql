CREATE FUNCTION ABCanTrackV2.insert5Fields(pOrgId VARCHAR(100))
  RETURNS INT
  begin
INSERT INTO  `ABCanTrackV2`.`org_field`
(
	`org_field`.`OrgId`,
    `org_field`.`FieldId`,
    `org_field`.`FieldLabel`,
    `org_field`.`HelpMeName`,
    `org_field`.`HelpMeDescription`
)
select
	pOrgId,
	field.`FieldId`,
    field.`DefaultFieldLabel`,
    field.`DefaultHelpMeName`,
    field.`DefaultHelpMeDescription`
FROM ABCanTrackV2.`field` WHERE FieldName IN('VehicleTitle','IllnessTitle','TrafficTitle','InjuryTitle','SpillTitle')AND LanguageId = GetLanguageId('en') and OrgId is null ;
return 1;
end;
