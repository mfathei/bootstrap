CREATE VIEW ABCanTrackV2.inc_third_party_cust_vw AS
  SELECT
    `inc`.`IncidentId`        AS `IncidentId`,
    `tpcust`.`ThirdPartyName` AS `CustomerId`,
    `tpcust`.`ContactName`    AS `CustName`,
    `itpcust`.`JobNumber`     AS `CustomerJobNumber`
  FROM (`abcantrackv2`.`incident` `inc`
    JOIN ((`abcantrackv2`.`inc_third_party` `itpcust`
      JOIN `abcantrackv2`.`third_party` `tpcust` ON ((`itpcust`.`ThirdPartyId` = `tpcust`.`ThirdPartyId`))) JOIN
      `abcantrackv2`.`third_party_type` `tptcust` ON (((`tpcust`.`ThirdPartyTypeId` = `tptcust`.`ThirdPartyTypeId`) AND
                                                       (`tptcust`.`ThirdPartyTypeCode` = 'Customer'))))
      ON ((`inc`.`IncidentId` = `itpcust`.`IncidentId`)));
