CREATE VIEW ABCanTrackV2.country_view AS
  SELECT
    1 AS `id`,
    1 AS `country_name`,
    1 AS `abbrev`,
    1 AS `URL`,
    1 AS `phone_code`,
    1 AS `properties`,
    1 AS `currency_type`,
    1 AS `CompanyAbbrev`,
    1 AS `FedTaxRate`;
