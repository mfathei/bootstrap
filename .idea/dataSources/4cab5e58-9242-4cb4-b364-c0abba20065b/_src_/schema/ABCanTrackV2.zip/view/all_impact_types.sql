CREATE VIEW ABCanTrackV2.all_impact_types AS
  SELECT
    `abcantrackv2`.`impact`.`ImpactId`                        AS `ImpactId`,
    `abcantrackv2`.`impact`.`IncidentId`                      AS `IncidentId`,
    `abcantrackv2`.`impact_type`.`ImpactTypeName`             AS `ImpactTypeName`,
    `abcantrackv2`.`impact_type`.`ImpactTypeCode`             AS `ImpactTypeCode`,
    `abcantrackv2`.`impact_sub_type`.`ImpactSubTypeName`      AS `ImpactSubTypeName`,
    `abcantrackv2`.`impact`.`IntEmployeeName1`                AS `IntEmployeeName1`,
    `abcantrackv2`.`impact`.`IntEmployeeName2`                AS `IntEmployeeName2`,
    `abcantrackv2`.`impact`.`IntEmployeeName3`                AS `IntEmployeeName3`,
    `abcantrackv2`.`impact`.`IntEmployeeDept1`                AS `IntEmployeeDept1`,
    `abcantrackv2`.`impact`.`IntEmployeeDept2`                AS `IntEmployeeDept2`,
    `abcantrackv2`.`impact`.`IntEmployeeDept3`                AS `IntEmployeeDept3`,
    `abcantrackv2`.`impact`.`CustomOpenTxt`                   AS `CustomOpenTxt`,
    `abcantrackv2`.`impact`.`PrimRespondName`                 AS `PrimRespondName`,
    `abcantrackv2`.`impact`.`Description`                     AS `Description`,
    `abcantrackv2`.`impact`.`EstimatedCost`                   AS `EstimatedCost`,
    concat(`abcantrackv2`.`impact`.`ImpactId`, '_', `abcantrackv2`.`impact`.`IncidentId`, '_',
           `abcantrackv2`.`impact_type`.`ImpactTypeCode`)     AS `Identification`,
    (SELECT group_concat(DISTINCT `abcantrackv2`.`external_agency`.`ExtAgencyName` SEPARATOR ', ')
     FROM (`abcantrackv2`.`impacts_ext_agency`
       JOIN `abcantrackv2`.`external_agency`
         ON ((`abcantrackv2`.`external_agency`.`ExtAgencyId` = `abcantrackv2`.`impacts_ext_agency`.`ExtAgencyId`)))
     WHERE (`abcantrackv2`.`impacts_ext_agency`.`ImpactId` = `abcantrackv2`.`impact`.`ImpactId`)
     GROUP BY `abcantrackv2`.`impacts_ext_agency`.`ImpactId`) AS `ExtAgencyName`
  FROM ((`abcantrackv2`.`impact`
    JOIN `abcantrackv2`.`impact_sub_type`
      ON ((`abcantrackv2`.`impact_sub_type`.`ImpactSubTypeId` = `abcantrackv2`.`impact`.`ImpactSubTypeId`))) JOIN
    `abcantrackv2`.`impact_type`
      ON ((`abcantrackv2`.`impact_sub_type`.`ImpactTypeId` = `abcantrackv2`.`impact_type`.`ImpactTypeId`)))
  UNION SELECT
          `abcantrackv2`.`injury`.`InjuryId`                        AS `InjuryId`,
          `abcantrackv2`.`injury`.`IncidentId`                      AS `IncidentId`,
          `abcantrackv2`.`impact_type`.`ImpactTypeName`             AS `ImpactTypeName`,
          `abcantrackv2`.`impact_type`.`ImpactTypeCode`             AS `ImpactTypeCode`,
          `abcantrackv2`.`impact_sub_type`.`ImpactSubTypeName`      AS `ImpactSubTypeName`,
          `abcantrackv2`.`injury`.`IntEmployeeName1`                AS `IntEmployeeName1`,
          `abcantrackv2`.`injury`.`IntEmployeeName2`                AS `IntEmployeeName2`,
          `abcantrackv2`.`injury`.`IntEmployeeName3`                AS `IntEmployeeName3`,
          `abcantrackv2`.`injury`.`IntEmployeeDept1`                AS `IntEmployeeDept1`,
          `abcantrackv2`.`injury`.`IntEmployeeDept2`                AS `IntEmployeeDept2`,
          `abcantrackv2`.`injury`.`IntEmployeeDept3`                AS `IntEmployeeDept3`,
          `abcantrackv2`.`injury`.`CustomOpenTxt`                   AS `CustomOpenTxt`,
          `abcantrackv2`.`injury`.`PrimRespondName`                 AS `PrimRespondName`,
          `abcantrackv2`.`injury`.`Description`                     AS `Description`,
          `abcantrackv2`.`injury`.`EstimatedCost`                   AS `EstimatedCost`,
          concat(`abcantrackv2`.`injury`.`InjuryId`, '_', `abcantrackv2`.`injury`.`IncidentId`, '_',
                 `abcantrackv2`.`impact_type`.`ImpactTypeCode`)     AS `Identification`,
          (SELECT group_concat(DISTINCT `abcantrackv2`.`external_agency`.`ExtAgencyName` SEPARATOR ', ')
           FROM (`abcantrackv2`.`impacts_ext_agency`
             JOIN `abcantrackv2`.`external_agency` ON ((`abcantrackv2`.`external_agency`.`ExtAgencyId` =
                                                        `abcantrackv2`.`impacts_ext_agency`.`ExtAgencyId`)))
           WHERE (`abcantrackv2`.`impacts_ext_agency`.`InjuryId` = `abcantrackv2`.`injury`.`InjuryId`)
           GROUP BY `abcantrackv2`.`impacts_ext_agency`.`InjuryId`) AS `ExtAgencyName`
        FROM ((`abcantrackv2`.`injury`
          JOIN `abcantrackv2`.`impact_sub_type`
            ON ((`abcantrackv2`.`impact_sub_type`.`ImpactSubTypeId` = `abcantrackv2`.`injury`.`ImpactSubTypeId`))) JOIN
          `abcantrackv2`.`impact_type`
            ON ((`abcantrackv2`.`impact_sub_type`.`ImpactTypeId` = `abcantrackv2`.`impact_type`.`ImpactTypeId`)))
  UNION SELECT
          `abcantrackv2`.`illness`.`IllnessId`                       AS `IllnessId`,
          `abcantrackv2`.`illness`.`IncidentId`                      AS `IncidentId`,
          `abcantrackv2`.`impact_type`.`ImpactTypeName`              AS `ImpactTypeName`,
          `abcantrackv2`.`impact_type`.`ImpactTypeCode`              AS `ImpactTypeCode`,
          `abcantrackv2`.`impact_sub_type`.`ImpactSubTypeName`       AS `ImpactSubTypeName`,
          `abcantrackv2`.`illness`.`IntEmployeeName1`                AS `IntEmployeeName1`,
          `abcantrackv2`.`illness`.`IntEmployeeName2`                AS `IntEmployeeName2`,
          `abcantrackv2`.`illness`.`IntEmployeeName3`                AS `IntEmployeeName3`,
          `abcantrackv2`.`illness`.`IntEmployeeDept1`                AS `IntEmployeeDept1`,
          `abcantrackv2`.`illness`.`IntEmployeeDept2`                AS `IntEmployeeDept2`,
          `abcantrackv2`.`illness`.`IntEmployeeDept3`                AS `IntEmployeeDept3`,
          `abcantrackv2`.`illness`.`CustomOpenTxt`                   AS `CustomOpenTxt`,
          `abcantrackv2`.`illness`.`PrimRespondName`                 AS `PrimRespondName`,
          `abcantrackv2`.`illness`.`Description`                     AS `Description`,
          `abcantrackv2`.`illness`.`EstimatedCost`                   AS `EstimatedCost`,
          concat(`abcantrackv2`.`illness`.`IllnessId`, '_', `abcantrackv2`.`illness`.`IncidentId`, '_',
                 `abcantrackv2`.`impact_type`.`ImpactTypeCode`)      AS `Identification`,
          (SELECT group_concat(DISTINCT `abcantrackv2`.`external_agency`.`ExtAgencyName` SEPARATOR ', ')
           FROM (`abcantrackv2`.`impacts_ext_agency`
             JOIN `abcantrackv2`.`external_agency` ON ((`abcantrackv2`.`external_agency`.`ExtAgencyId` =
                                                        `abcantrackv2`.`impacts_ext_agency`.`ExtAgencyId`)))
           WHERE (`abcantrackv2`.`impacts_ext_agency`.`IllnessId` = `abcantrackv2`.`illness`.`IllnessId`)
           GROUP BY `abcantrackv2`.`impacts_ext_agency`.`IllnessId`) AS `ExtAgencyName`
        FROM ((`abcantrackv2`.`illness`
          JOIN `abcantrackv2`.`impact_sub_type`
            ON ((`abcantrackv2`.`impact_sub_type`.`ImpactSubTypeId` = `abcantrackv2`.`illness`.`ImpactSubTypeId`))) JOIN
          `abcantrackv2`.`impact_type`
            ON ((`abcantrackv2`.`impact_sub_type`.`ImpactTypeId` = `abcantrackv2`.`impact_type`.`ImpactTypeId`)))
  UNION SELECT
          `abcantrackv2`.`spill_release`.`SpillReleaseId`                 AS `SpillReleaseId`,
          `abcantrackv2`.`spill_release`.`IncidentId`                     AS `IncidentId`,
          `abcantrackv2`.`impact_type`.`ImpactTypeName`                   AS `ImpactTypeName`,
          `abcantrackv2`.`impact_type`.`ImpactTypeCode`                   AS `ImpactTypeCode`,
          `abcantrackv2`.`impact_sub_type`.`ImpactSubTypeName`            AS `ImpactSubTypeName`,
          `abcantrackv2`.`spill_release`.`IntEmployeeName1`               AS `IntEmployeeName1`,
          `abcantrackv2`.`spill_release`.`IntEmployeeName2`               AS `IntEmployeeName2`,
          `abcantrackv2`.`spill_release`.`IntEmployeeName3`               AS `IntEmployeeName3`,
          `abcantrackv2`.`spill_release`.`IntEmployeeDept1`               AS `IntEmployeeDept1`,
          `abcantrackv2`.`spill_release`.`IntEmployeeDept2`               AS `IntEmployeeDept2`,
          `abcantrackv2`.`spill_release`.`IntEmployeeDept3`               AS `IntEmployeeDept3`,
          `abcantrackv2`.`spill_release`.`CustomOpenTxt`                  AS `CustomOpenTxt`,
          `abcantrackv2`.`spill_release`.`PrimRespondName`                AS `PrimRespondName`,
          `abcantrackv2`.`spill_release`.`Description`                    AS `Description`,
          `abcantrackv2`.`spill_release`.`EstimatedCost`                  AS `EstimatedCost`,
          concat(`abcantrackv2`.`spill_release`.`SpillReleaseId`, '_', `abcantrackv2`.`spill_release`.`IncidentId`, '_',
                 `abcantrackv2`.`impact_type`.`ImpactTypeCode`)           AS `Identification`,
          (SELECT group_concat(DISTINCT `abcantrackv2`.`external_agency`.`ExtAgencyName` SEPARATOR ', ')
           FROM (`abcantrackv2`.`impacts_ext_agency`
             JOIN `abcantrackv2`.`external_agency` ON ((`abcantrackv2`.`external_agency`.`ExtAgencyId` =
                                                        `abcantrackv2`.`impacts_ext_agency`.`ExtAgencyId`)))
           WHERE
             (`abcantrackv2`.`impacts_ext_agency`.`SpillReleaseId` = `abcantrackv2`.`spill_release`.`SpillReleaseId`)
           GROUP BY `abcantrackv2`.`impacts_ext_agency`.`SpillReleaseId`) AS `ExtAgencyName`
        FROM ((`abcantrackv2`.`spill_release`
          JOIN `abcantrackv2`.`impact_sub_type` ON ((`abcantrackv2`.`impact_sub_type`.`ImpactSubTypeId` =
                                                     `abcantrackv2`.`spill_release`.`ImpactSubTypeId`))) JOIN
          `abcantrackv2`.`impact_type`
            ON ((`abcantrackv2`.`impact_sub_type`.`ImpactTypeId` = `abcantrackv2`.`impact_type`.`ImpactTypeId`)))
  UNION SELECT
          `abcantrackv2`.`vehicle_damage`.`VehicleDamageId`                AS `VehicleDamageId`,
          `abcantrackv2`.`vehicle_damage`.`IncidentId`                     AS `IncidentId`,
          `abcantrackv2`.`impact_type`.`ImpactTypeName`                    AS `ImpactTypeName`,
          `abcantrackv2`.`impact_type`.`ImpactTypeCode`                    AS `ImpactTypeCode`,
          `abcantrackv2`.`impact_sub_type`.`ImpactSubTypeName`             AS `ImpactSubTypeName`,
          `abcantrackv2`.`vehicle_damage`.`IntEmployeeName1`               AS `IntEmployeeName1`,
          `abcantrackv2`.`vehicle_damage`.`IntEmployeeName2`               AS `IntEmployeeName2`,
          `abcantrackv2`.`vehicle_damage`.`IntEmployeeName3`               AS `IntEmployeeName3`,
          `abcantrackv2`.`vehicle_damage`.`IntEmployeeDept1`               AS `IntEmployeeDept1`,
          `abcantrackv2`.`vehicle_damage`.`IntEmployeeDept2`               AS `IntEmployeeDept2`,
          `abcantrackv2`.`vehicle_damage`.`IntEmployeeDept3`               AS `IntEmployeeDept3`,
          `abcantrackv2`.`vehicle_damage`.`CustomOpenTxt`                  AS `CustomOpenTxt`,
          `abcantrackv2`.`vehicle_damage`.`PrimRespondName`                AS `PrimRespondName`,
          `abcantrackv2`.`vehicle_damage`.`Description`                    AS `Description`,
          `abcantrackv2`.`vehicle_damage`.`EstimatedCost`                  AS `EstimatedCost`,
          concat(`abcantrackv2`.`vehicle_damage`.`VehicleDamageId`, '_', `abcantrackv2`.`vehicle_damage`.`IncidentId`,
                 '_', `abcantrackv2`.`impact_type`.`ImpactTypeCode`)       AS `Identification`,
          (SELECT group_concat(DISTINCT `abcantrackv2`.`external_agency`.`ExtAgencyName` SEPARATOR ', ')
           FROM (`abcantrackv2`.`impacts_ext_agency`
             JOIN `abcantrackv2`.`external_agency` ON ((`abcantrackv2`.`external_agency`.`ExtAgencyId` =
                                                        `abcantrackv2`.`impacts_ext_agency`.`ExtAgencyId`)))
           WHERE
             (`abcantrackv2`.`impacts_ext_agency`.`VehicleDamageId` = `abcantrackv2`.`vehicle_damage`.`VehicleDamageId`)
           GROUP BY `abcantrackv2`.`impacts_ext_agency`.`VehicleDamageId`) AS `ExtAgencyName`
        FROM ((`abcantrackv2`.`vehicle_damage`
          JOIN `abcantrackv2`.`impact_sub_type` ON ((`abcantrackv2`.`impact_sub_type`.`ImpactSubTypeId` =
                                                     `abcantrackv2`.`vehicle_damage`.`ImpactSubTypeId`))) JOIN
          `abcantrackv2`.`impact_type`
            ON ((`abcantrackv2`.`impact_sub_type`.`ImpactTypeId` = `abcantrackv2`.`impact_type`.`ImpactTypeId`)))
  UNION SELECT
          `abcantrackv2`.`traffic_violation`.`TrafficViolationId`                                                     AS `TrafficViolationId`,
          `abcantrackv2`.`traffic_violation`.`IncidentId`                                                             AS `IncidentId`,
          `abcantrackv2`.`impact_type`.`ImpactTypeName`                                                               AS `ImpactTypeName`,
          `abcantrackv2`.`impact_type`.`ImpactTypeCode`                                                               AS `ImpactTypeCode`,
          `abcantrackv2`.`impact_sub_type`.`ImpactSubTypeName`                                                        AS `ImpactSubTypeName`,
          `abcantrackv2`.`traffic_violation`.`IntEmployeeName1`                                                       AS `IntEmployeeName1`,
          `abcantrackv2`.`traffic_violation`.`IntEmployeeName2`                                                       AS `IntEmployeeName2`,
          `abcantrackv2`.`traffic_violation`.`IntEmployeeName3`                                                       AS `IntEmployeeName3`,
          `abcantrackv2`.`traffic_violation`.`IntEmployeeDept1`                                                       AS `IntEmployeeDept1`,
          `abcantrackv2`.`traffic_violation`.`IntEmployeeDept2`                                                       AS `IntEmployeeDept2`,
          `abcantrackv2`.`traffic_violation`.`IntEmployeeDept3`                                                       AS `IntEmployeeDept3`,
          `abcantrackv2`.`traffic_violation`.`CustomOpenTxt`                                                          AS `CustomOpenTxt`,
          `abcantrackv2`.`traffic_violation`.`PrimRespondName`                                                        AS `PrimRespondName`,
          `abcantrackv2`.`traffic_violation`.`Description`                                                            AS `Description`,
          `abcantrackv2`.`traffic_violation`.`EstimatedCost`                                                          AS `EstimatedCost`,
          concat(`abcantrackv2`.`traffic_violation`.`TrafficViolationId`, '_',
                 `abcantrackv2`.`traffic_violation`.`IncidentId`, '_',
                 `abcantrackv2`.`impact_type`.`ImpactTypeCode`)                                                       AS `Identification`,
          (SELECT group_concat(DISTINCT `abcantrackv2`.`external_agency`.`ExtAgencyName` SEPARATOR ', ')
           FROM (`abcantrackv2`.`impacts_ext_agency`
             JOIN `abcantrackv2`.`external_agency` ON ((`abcantrackv2`.`external_agency`.`ExtAgencyId` =
                                                        `abcantrackv2`.`impacts_ext_agency`.`ExtAgencyId`)))
           WHERE (`abcantrackv2`.`impacts_ext_agency`.`TrafficViolationId` =
                  `abcantrackv2`.`traffic_violation`.`TrafficViolationId`)
           GROUP BY
             `abcantrackv2`.`impacts_ext_agency`.`TrafficViolationId`)                                                AS `ExtAgencyName`
        FROM ((`abcantrackv2`.`traffic_violation`
          JOIN `abcantrackv2`.`impact_sub_type` ON ((`abcantrackv2`.`impact_sub_type`.`ImpactSubTypeId` =
                                                     `abcantrackv2`.`traffic_violation`.`ImpactSubTypeId`))) JOIN
          `abcantrackv2`.`impact_type`
            ON ((`abcantrackv2`.`impact_sub_type`.`ImpactTypeId` = `abcantrackv2`.`impact_type`.`ImpactTypeId`)))
  ORDER BY `IncidentId`;
