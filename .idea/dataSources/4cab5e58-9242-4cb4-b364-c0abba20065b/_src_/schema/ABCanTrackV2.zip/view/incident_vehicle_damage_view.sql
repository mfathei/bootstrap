CREATE VIEW ABCanTrackV2.incident_vehicle_damage_view AS
  SELECT
    `abcantrackv2`.`vehicle_damage`.`VehicleDamageId`   AS `VehicleDamageId`,
    `abcantrackv2`.`vehicle_damage`.`IncidentId`        AS `IncidentId`,
    `abcantrackv2`.`vehicle_damage`.`DriverName`        AS `DamageDriverName`,
    `abcantrackv2`.`vehicle_damage`.`DriverLicence`     AS `DamageDriverLicence`,
    `abcantrackv2`.`vehicle_type`.`VehicleTypeName`     AS `DamageVehicleTypeId`,
    `abcantrackv2`.`vehicle_damage`.`VehicleLicence`    AS `DamageVehicleLicence`,
    `abcantrackv2`.`vehicle_damage`.`HowDidThatDone`    AS `HowDidThatDone`,
    `abcantrackv2`.`vehicle_damage`.`DamageDescription` AS `DamageDescription`
  FROM (`abcantrackv2`.`vehicle_damage`
    LEFT JOIN `abcantrackv2`.`vehicle_type`
      ON ((`abcantrackv2`.`vehicle_type`.`VehicleTypeId` = `abcantrackv2`.`vehicle_damage`.`VehicleTypeId`)));
