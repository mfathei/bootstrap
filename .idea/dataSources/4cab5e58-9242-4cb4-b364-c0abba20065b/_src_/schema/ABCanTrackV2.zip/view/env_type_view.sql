CREATE VIEW ABCanTrackV2.env_type_view AS
  SELECT
    `tbl1`.`EnvConditionId`       AS `EnvConditionId`,
    `tbl1`.`EnvConditionName`     AS `EnvConditionName`,
    `tbl1`.`OrgId`                AS `OrgId`,
    `tbl1`.`Hide`                 AS `Hide`,
    `tbl2`.`EnvCondParameterId`   AS `EnvCondParameterId`,
    `tbl2`.`EnvCondParameterName` AS `EnvCondParameterName`,
    `tbl2`.`Hide`                 AS `ParamHide`
  FROM (`abcantrackv2`.`env_condition` `tbl1`
    JOIN `abcantrackv2`.`env_cond_parameter` `tbl2` ON ((`tbl1`.`EnvConditionId` = `tbl2`.`EnvConditionId`)));
