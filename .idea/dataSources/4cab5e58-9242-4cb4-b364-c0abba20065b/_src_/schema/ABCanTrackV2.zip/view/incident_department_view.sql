CREATE VIEW ABCanTrackV2.incident_department_view AS
  SELECT
    `abcantrackv2`.`incident`.`IncidentId`                                                             AS `IncidentId`,
    (SELECT group_concat(`abcantrackv2`.`oe_department`.`OEDepartmentName` SEPARATOR '; ')
     FROM (`abcantrackv2`.`inc_oe_department`
       JOIN `abcantrackv2`.`oe_department`
         ON ((`abcantrackv2`.`oe_department`.`OEDepartmentId` = `abcantrackv2`.`inc_oe_department`.`OEDepartmentId`)))
     WHERE (`abcantrackv2`.`inc_oe_department`.`IncidentId` =
            `abcantrackv2`.`incident`.`IncidentId`))                                                   AS `OEDepartmentId`
  FROM `abcantrackv2`.`incident`
  ORDER BY `abcantrackv2`.`incident`.`IncidentId` DESC;
