CREATE VIEW ABCanTrackV2.email_to_view_old AS
  SELECT
    `eto`.`EmailToId`                                                                                  AS `EmailToId`,
    `eto`.`GroupId`                                                                                    AS `GroupId`,
    `eto`.`EmployeeId`                                                                                 AS `EmployeeId`,
    concat(`e`.`FirstName`, ' ',
           `e`.`LastName`)                                                                             AS `EmployeeName`,
    `e`.`Position`                                                                                     AS `Position`,
    `g`.`GroupName`                                                                                    AS `GroupName`,
    group_concat(DISTINCT `et`.`EmailTypeName` SEPARATOR
                 ', ')                                                                                 AS `EmailTypeName`,
    `eto`.`OrgId`                                                                                      AS `OrgId`,
    `GETASSIGNNOTIFICATIONSFUN`(`eto`.`EmployeeId`, `eto`.`GroupId`, `eto`.`TableName`,
                                `eto`.`OrgId`)                                                         AS `AssignedNotifications`,
    NULL                                                                                               AS `DaysStart`,
    NULL                                                                                               AS `DaysFreq`
  FROM (((`abcantrackv2`.`email_to` `eto` LEFT JOIN `abcantrackv2`.`employee` `e`
      ON ((`eto`.`EmployeeId` = `e`.`EmployeeId`))) JOIN `abcantrackv2`.`email_type` `et`
      ON ((`et`.`EmailTypeId` = `eto`.`EmailTypeId`))) LEFT JOIN `abcantrackv2`.`group` `g`
      ON ((`g`.`GroupId` = `eto`.`GroupId`)))
  GROUP BY `eto`.`EmployeeId`, `eto`.`GroupId`
  UNION ALL SELECT
              `etoesc`.`EmailToEscId`                            AS `EmailToId`,
              `etoesc`.`GroupId`                                 AS `GroupId`,
              `etoesc`.`EmployeeId`                              AS `EmployeeId`,
              concat(`e`.`FirstName`, ' ', `e`.`LastName`)       AS `EmployeeName`,
              `e`.`Position`                                     AS `Position`,
              `g`.`GroupName`                                    AS `GroupName`,
              NULL                                               AS `EmailTypeName`,
              `etoesc`.`OrgId`                                   AS `OrgId`,
              `GETASSIGNNOTIFICATIONSFUN`(`etoesc`.`EmployeeId`, `etoesc`.`GroupId`, `etoesc`.`TableName`,
                                          `etoesc`.`OrgId`)      AS `AssignedNotifications`,
              group_concat(`etoesc`.`DaysStart` SEPARATOR ' ; ') AS `DaysStart`,
              group_concat(`etoesc`.`DaysFreq` SEPARATOR ' ; ')  AS `DaysFreq`
            FROM ((`abcantrackv2`.`email_to_esc` `etoesc` LEFT JOIN `abcantrackv2`.`employee` `e`
                ON ((`etoesc`.`EmployeeId` = `e`.`EmployeeId`))) LEFT JOIN `abcantrackv2`.`group` `g`
                ON ((`g`.`GroupId` = `etoesc`.`GroupId`)))
            GROUP BY `etoesc`.`EmployeeId`, `etoesc`.`GroupId`;
