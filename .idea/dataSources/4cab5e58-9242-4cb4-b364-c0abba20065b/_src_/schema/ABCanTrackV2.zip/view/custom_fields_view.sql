CREATE VIEW ABCanTrackV2.custom_fields_view AS
  (SELECT
     `abcantrackv2`.`field_value`.`IncidentId`                          AS `IncidentId`,
     (CASE WHEN (`abcantrackv2`.`org_field`.`FieldLabel` = 'Impact-Description ')
       THEN (SELECT `abcantrackv2`.`field_value`.`FieldValue`
             FROM (`abcantrackv2`.`field_value`
               JOIN `abcantrackv2`.`org_field`
                 ON ((`abcantrackv2`.`org_field`.`FieldId` = `abcantrackv2`.`field_value`.`FieldId`)))
             WHERE ((`abcantrackv2`.`field_value`.`IncidentId` = 87) AND
                    (`abcantrackv2`.`org_field`.`FieldLabel` = 'Impact-Description ') AND
                    (`abcantrackv2`.`org_field`.`IsHidden` <> 1))) END) AS `Impact-Description`,
     (CASE WHEN (`abcantrackv2`.`org_field`.`FieldLabel` = 'Pre-job Preparations:          ')
       THEN (SELECT group_concat(`abcantrackv2`.`field_value`.`FieldValue` SEPARATOR ',')
             FROM (`abcantrackv2`.`field_value`
               JOIN `abcantrackv2`.`org_field`
                 ON ((`abcantrackv2`.`org_field`.`FieldId` = `abcantrackv2`.`field_value`.`FieldId`)))
             WHERE ((`abcantrackv2`.`field_value`.`IncidentId` = 87) AND
                    (`abcantrackv2`.`org_field`.`FieldLabel` = 'Pre-job Preparations:          ') AND
                    (`abcantrackv2`.`org_field`.`IsHidden` <> 1))) END) AS `Pre-job Preparations`,
     (CASE WHEN (`abcantrackv2`.`org_field`.`FieldLabel` = 'Change me ')
       THEN (SELECT group_concat(`abcantrackv2`.`field_value`.`FieldValue` SEPARATOR ',')
             FROM (`abcantrackv2`.`field_value`
               JOIN `abcantrackv2`.`org_field`
                 ON ((`abcantrackv2`.`org_field`.`FieldId` = `abcantrackv2`.`field_value`.`FieldId`)))
             WHERE ((`abcantrackv2`.`field_value`.`IncidentId` = 87) AND
                    (`abcantrackv2`.`org_field`.`FieldLabel` = 'Change me ') AND
                    (`abcantrackv2`.`org_field`.`IsHidden` <> 1))) END) AS `Change me`,
     (CASE WHEN (`abcantrackv2`.`org_field`.`FieldLabel` = 'Activity Type:    ')
       THEN (SELECT `abcantrackv2`.`field_value`.`FieldValue`
             FROM (`abcantrackv2`.`field_value`
               JOIN `abcantrackv2`.`org_field`
                 ON ((`abcantrackv2`.`org_field`.`FieldId` = `abcantrackv2`.`field_value`.`FieldId`)))
             WHERE ((`abcantrackv2`.`field_value`.`IncidentId` = 87) AND
                    (`abcantrackv2`.`org_field`.`FieldLabel` = 'Activity Type:    ') AND
                    (`abcantrackv2`.`org_field`.`IsHidden` <> 1))) END) AS `Activity Type`,
     (CASE WHEN (`abcantrackv2`.`org_field`.`FieldLabel` = 'Text 1      ')
       THEN (SELECT `abcantrackv2`.`field_value`.`FieldValue`
             FROM (`abcantrackv2`.`field_value`
               JOIN `abcantrackv2`.`org_field`
                 ON ((`abcantrackv2`.`org_field`.`FieldId` = `abcantrackv2`.`field_value`.`FieldId`)))
             WHERE ((`abcantrackv2`.`field_value`.`IncidentId` = 87) AND
                    (`abcantrackv2`.`org_field`.`FieldLabel` = 'Text 1      ') AND
                    (`abcantrackv2`.`org_field`.`IsHidden` <> 1))) END) AS `Text 1`,
     (CASE WHEN (`abcantrackv2`.`org_field`.`FieldLabel` = 'Text 3      ')
       THEN (SELECT `abcantrackv2`.`field_value`.`FieldValue`
             FROM (`abcantrackv2`.`field_value`
               JOIN `abcantrackv2`.`org_field`
                 ON ((`abcantrackv2`.`org_field`.`FieldId` = `abcantrackv2`.`field_value`.`FieldId`)))
             WHERE ((`abcantrackv2`.`field_value`.`IncidentId` = 87) AND
                    (`abcantrackv2`.`org_field`.`FieldLabel` = 'Text 3      ') AND
                    (`abcantrackv2`.`org_field`.`IsHidden` <> 1))) END) AS `Text 3`,
     (CASE WHEN (`abcantrackv2`.`org_field`.`FieldLabel` = 'First-hour response activities: ')
       THEN (SELECT `abcantrackv2`.`field_value`.`FieldValue`
             FROM (`abcantrackv2`.`field_value`
               JOIN `abcantrackv2`.`org_field`
                 ON ((`abcantrackv2`.`org_field`.`FieldId` = `abcantrackv2`.`field_value`.`FieldId`)))
             WHERE ((`abcantrackv2`.`field_value`.`IncidentId` = 87) AND
                    (`abcantrackv2`.`org_field`.`FieldLabel` = 'First-hour response activities: ') AND
                    (`abcantrackv2`.`org_field`.`IsHidden` <> 1))) END) AS `First-hour response activities`
   FROM (`abcantrackv2`.`field_value`
     JOIN `abcantrackv2`.`org_field`
       ON ((`abcantrackv2`.`org_field`.`FieldId` = `abcantrackv2`.`field_value`.`FieldId`)))
   WHERE ((`abcantrackv2`.`field_value`.`IncidentId` = 87) AND (`abcantrackv2`.`org_field`.`IsHidden` <> 1)));
