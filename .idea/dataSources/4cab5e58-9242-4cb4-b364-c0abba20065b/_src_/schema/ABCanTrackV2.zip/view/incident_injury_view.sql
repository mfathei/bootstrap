CREATE VIEW ABCanTrackV2.incident_injury_view AS
  SELECT
    `abcantrackv2`.`injury`.`IncidentId`                                                                AS `IncidentId`,
    `abcantrackv2`.`injury`.`InjuryId`                                                                  AS `InjuryId`,
    (SELECT group_concat(`abcantrackv2`.`injury_type`.`InjuryTypeName` SEPARATOR ' ; ')
     FROM `abcantrackv2`.`injury_type`
     WHERE `abcantrackv2`.`injury_type`.`InjuryTypeId` IN (SELECT `abcantrackv2`.`injury_type_injury`.`InjuryTypeId`
                                                           FROM `abcantrackv2`.`injury_type_injury`
                                                           WHERE (`abcantrackv2`.`injury_type_injury`.`InjuryId` =
                                                                  `abcantrackv2`.`injury`.`InjuryId`))) AS `InjuryTypeId`,
    (SELECT group_concat(`abcantrackv2`.`body_part`.`BodyPartName` SEPARATOR ' ; ')
     FROM `abcantrackv2`.`body_part`
     WHERE `abcantrackv2`.`body_part`.`BodyPartId` IN (SELECT `abcantrackv2`.`body_part_injury`.`BodyPartId`
                                                       FROM `abcantrackv2`.`body_part_injury`
                                                       WHERE (`abcantrackv2`.`body_part_injury`.`InjuryId` =
                                                              `abcantrackv2`.`injury`.`InjuryId`)))     AS `BodyPartId`,
    (SELECT group_concat(`abcantrackv2`.`body_area`.`BodyAreaName` SEPARATOR ' ; ')
     FROM `abcantrackv2`.`body_area`
     WHERE `abcantrackv2`.`body_area`.`BodyAreaId` IN (SELECT `abcantrackv2`.`body_area_injury`.`BodyAreaId`
                                                       FROM `abcantrackv2`.`body_area_injury`
                                                       WHERE (`abcantrackv2`.`body_area_injury`.`InjuryId` =
                                                              `abcantrackv2`.`injury`.`InjuryId`)))     AS `BodyAreaId`,
    `abcantrackv2`.`injury`.`PersonalInjuredName`                                                       AS `PersonalInjured`,
    `abcantrackv2`.`contact_code`.`ContactCodeName`                                                     AS `ContactCodeId`,
    `abcantrackv2`.`injury_recordable`.`RecordableName`                                                 AS `RecordableId`,
    `abcantrackv2`.`initial_treatment`.`InitialTreatmentName`                                           AS `InitialTreatmentId`,
    `abcantrackv2`.`contact_agency`.`ContactAgencyName`                                                 AS `InjuryExtAgencyId`,
    `abcantrackv2`.`injury`.`LostTimeEnd`                                                               AS `LostTimeEnd`,
    `abcantrackv2`.`injury`.`LostTimeStart`                                                             AS `LostTimeStart`,
    `abcantrackv2`.`injury`.`AdjustmentDays`                                                            AS `AdjustmentDays`,
    `abcantrackv2`.`injury`.`TotalDaysOff`                                                              AS `TotalDaysOff`,
    `abcantrackv2`.`injury`.`InjuryDescription`                                                         AS `InjuryDescription`
  FROM (((((`abcantrackv2`.`injury`
    LEFT JOIN `abcantrackv2`.`restricted_work`
      ON ((`abcantrackv2`.`restricted_work`.`RestrictedWorkId` = `abcantrackv2`.`injury`.`RestrictedWorkId`))) LEFT JOIN
    `abcantrackv2`.`initial_treatment` ON ((`abcantrackv2`.`initial_treatment`.`InitialTreatmentId` =
                                            `abcantrackv2`.`injury`.`InitialTreatmentId`))) LEFT JOIN
    `abcantrackv2`.`contact_code`
      ON ((`abcantrackv2`.`contact_code`.`ContactCodeId` = `abcantrackv2`.`injury`.`ContactCodeId`))) LEFT JOIN
    `abcantrackv2`.`contact_agency`
      ON ((`abcantrackv2`.`contact_agency`.`ContactAgencyId` = `abcantrackv2`.`injury`.`ContactAgencyId`))) LEFT JOIN
    `abcantrackv2`.`injury_recordable`
      ON ((`abcantrackv2`.`injury_recordable`.`RecordableId` = `abcantrackv2`.`injury`.`RecordableId`)))
  ORDER BY `abcantrackv2`.`injury`.`IncidentId` DESC;
