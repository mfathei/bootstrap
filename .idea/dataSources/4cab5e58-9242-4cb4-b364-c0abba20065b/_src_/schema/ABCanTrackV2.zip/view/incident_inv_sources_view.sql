CREATE VIEW ABCanTrackV2.incident_inv_sources_view AS
  SELECT
    `abcantrackv2`.`incident`.`IncidentId`                                                          AS `IncidentId`,
    (SELECT group_concat(`abcantrackv2`.`inv_source`.`InvSourceName` SEPARATOR '; ')
     FROM (`abcantrackv2`.`inc_inv_source`
       JOIN `abcantrackv2`.`inv_source`
         ON ((`abcantrackv2`.`inv_source`.`InvSourceId` = `abcantrackv2`.`inc_inv_source`.`InvSourceId`)))
     WHERE (`abcantrackv2`.`inc_inv_source`.`IncidentId` =
            `abcantrackv2`.`incident`.`IncidentId`))                                                AS `InvSourceParamId`
  FROM `abcantrackv2`.`incident`
  ORDER BY `abcantrackv2`.`incident`.`IncidentId` DESC;
