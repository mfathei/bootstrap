CREATE VIEW ABCanTrackV2.incidnet_root_causes_view AS
  SELECT
    `abcantrackv2`.`incident`.`IncidentId`                                                          AS `IncidentId`,
    (SELECT group_concat(`abcantrackv2`.`root_cause_param`.`RootCauseParamName` SEPARATOR '; ')
     FROM (`abcantrackv2`.`inc_root_cause`
       JOIN `abcantrackv2`.`root_cause_param` ON ((`abcantrackv2`.`root_cause_param`.`RootCauseParamId` =
                                                   `abcantrackv2`.`inc_root_cause`.`RootCauseParamId`)))
     WHERE (`abcantrackv2`.`inc_root_cause`.`IncidentId` =
            `abcantrackv2`.`incident`.`IncidentId`))                                                AS `RootCauseParamId`
  FROM `abcantrackv2`.`incident`
  ORDER BY `abcantrackv2`.`incident`.`IncidentId` DESC;
