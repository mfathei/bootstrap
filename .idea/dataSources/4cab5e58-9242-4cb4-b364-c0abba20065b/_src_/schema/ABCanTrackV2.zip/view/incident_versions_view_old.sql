CREATE VIEW ABCanTrackV2.incident_versions_view_old AS
  SELECT
    `hinc`.`HistIncidentId`                                                                    AS `HistIncidentId`,
    `hinc`.`IncidentId`                                                                        AS `IncidentId`,
    `hinc`.`EventTypeName`                                                                     AS `EventTypeName`,
    `hinc`.`OperationTypeName`                                                                 AS `OperationTypeName`,
    `hinc`.`OrgId`                                                                             AS `OrgId`,
    `hinc`.`EmployeeName`                                                                      AS `EmployeeName`,
    `hinc`.`IncidentDate`                                                                      AS `IncidentDate`,
    `hinc`.`IncidentHour`                                                                      AS `IncidentHour`,
    `hinc`.`IncidentMinute`                                                                    AS `IncidentMinute`,
    `hinc`.`IsEmerRP`                                                                          AS `IsEmerRP`,
    `hinc`.`RepName`                                                                           AS `RepName`,
    `hinc`.`RepEmail`                                                                          AS `RepEmail`,
    `hinc`.`RepPosition`                                                                       AS `RepPosition`,
    `hinc`.`RepCompany`                                                                        AS `RepCompany`,
    `hinc`.`RepPrimaryPhone`                                                                   AS `RepPrimaryPhone`,
    `hinc`.`RepAlternatePhone`                                                                 AS `RepAlternatePhone`,
    `hinc`.`Location1Name`                                                                     AS `Location1Name`,
    `hinc`.`Location2Name`                                                                     AS `Location2Name`,
    `hinc`.`Location3Name`                                                                     AS `Location3Name`,
    `hinc`.`Location4Name`                                                                     AS `Location4Name`,
    `hinc`.`OtherLocation`                                                                     AS `OtherLocation`,
    `hinc`.`OEDepartmentName`                                                                  AS `OEDepartmentName`,
    `hinc`.`EventSequence`                                                                     AS `EventSequence`,
    `hinc`.`EnvConditionNote`                                                                  AS `EnvConditionNote`,
    `hinc`.`EnvConditionName`                                                                  AS `EnvConditionName`,
    `hinc`.`IncDescription`                                                                    AS `IncDescription`,
    `hinc`.`ObserAnaName`                                                                      AS `ObserAnaName`,
    `hinc`.`IncInvSourceName`                                                                  AS `IncInvSourceName`,
    `hinc`.`EnergyFormNote`                                                                    AS `EnergyFormNote`,
    `hinc`.`SubStandardActionNote`                                                             AS `SubStandardActionNote`,
    `hinc`.`SubStandardConditionNote`                                                          AS `SubStandardConditionNote`,
    `hinc`.`UnderLyingCauseNote`                                                               AS `UnderLyingCauseNote`,
    `hinc`.`InvStatusName`                                                                     AS `InvStatusName`,
    `hinc`.`InvestigationDate`                                                                 AS `InvestigationDate`,
    `hinc`.`InvestigatorName1`                                                                 AS `InvestigatorName1`,
    `hinc`.`InvestigatorName2`                                                                 AS `InvestigatorName2`,
    `hinc`.`InvestigatorName3`                                                                 AS `InvestigatorName3`,
    `hinc`.`RootCauseName`                                                                     AS `RootCauseName`,
    `hinc`.`OtherRootCause`                                                                    AS `OtherRootCause`,
    `hinc`.`ThirdPartyName`                                                                    AS `ThirdPartyName`,
    `hinc`.`JobNumber`                                                                         AS `JobNumber`,
    `hinc`.`ContactName`                                                                       AS `ContactName`,
    `hinc`.`InvSummary`                                                                        AS `InvSummary`,
    `hinc`.`FollowUpNote`                                                                      AS `FollowUpNote`,
    `hinc`.`ResponseCost`                                                                      AS `ResponseCost`,
    `hinc`.`RepairCost`                                                                        AS `RepairCost`,
    `hinc`.`InsuranceCost`                                                                     AS `InsuranceCost`,
    `hinc`.`WCBCost`                                                                           AS `WCBCost`,
    `hinc`.`OtherCost`                                                                         AS `OtherCost`,
    `hinc`.`TotalCost`                                                                         AS `TotalCost`,
    `hinc`.`RiskOfRecurrenceName`                                                              AS `RiskOfRecurrenceName`,
    `hinc`.`IncidentSeverityName`                                                              AS `IncidentSeverityName`,
    `hinc`.`SourceDetails`                                                                     AS `SourceDetails`,
    `hinc`.`RootCauseNote`                                                                     AS `RootCauseNote`,
    `hinc`.`SignOffInvestigatorName`                                                           AS `SignOffInvestigatorName`,
    `hinc`.`SignOffDate`                                                                       AS `SignOffDate`,
    `hinc`.`UpdatedById`                                                                       AS `UpdatedById`,
    `hinc`.`UpdatedDate`                                                                       AS `UpdatedDate`,
    `hinc`.`VersionNumber`                                                                     AS `VersionNumber`,
    `inc`.`IncidentNumber`                                                                     AS `IncidentNumber`,
    `tpcust`.`ThirdPartyName`                                                                  AS `CustomerName`,
    `tpcust`.`ContactName`                                                                     AS `CustName`,
    `itpcust`.`JobNumber`                                                                      AS `CustomerJobNumber`,
    `tpcont`.`ThirdPartyName`                                                                  AS `ContractorName`,
    `tpcont`.`ContactName`                                                                     AS `ContName`,
    `itpcont`.`JobNumber`                                                                      AS `ContractorJobNumber`,
    concat(`abcantrackv2`.`employee`.`FirstName`, ' ', `abcantrackv2`.`employee`.`LastName`)   AS `UpdatedByName`,
    concat_ws(', ', `hinj`.`ImpactTypeName`, `himp`.`ImpactTypeName`, `hill`.`ImpactTypeName`, `hsp`.`ImpactTypeName`,
              `hvd`.`ImpactTypeName`, `htv`.`ImpactTypeName`)                                  AS `ImpactTypeName`,
    concat_ws(', ', `hinj`.`ImpactSubTypeName`, `himp`.`ImpactSubTypeName`, `hill`.`ImpactSubTypeName`,
              `hsp`.`ImpactSubTypeName`, `hvd`.`ImpactSubTypeName`, `htv`.`ImpactSubTypeName`) AS `ImpactSubTypeName`,
    concat_ws(', ', `hinj`.`IntEmployeeName1`, `himp`.`IntEmployeeName1`, `hill`.`IntEmployeeName1`,
              `hsp`.`IntEmployeeName1`, `hvd`.`IntEmployeeName1`, `htv`.`IntEmployeeName1`)    AS `IntEmployeeName1`,
    concat_ws(', ', `hinj`.`IntEmployeeName2`, `himp`.`IntEmployeeName2`, `hill`.`IntEmployeeName2`,
              `hsp`.`IntEmployeeName2`, `hvd`.`IntEmployeeName2`, `htv`.`IntEmployeeName2`)    AS `IntEmployeeName2`,
    concat_ws(', ', `hinj`.`IntEmployeeName3`, `himp`.`IntEmployeeName3`, `hill`.`IntEmployeeName3`,
              `hsp`.`IntEmployeeName3`, `hvd`.`IntEmployeeName3`, `htv`.`IntEmployeeName3`)    AS `IntEmployeeName3`,
    concat_ws(', ', `hinj`.`IntEmployeeDept1`, `himp`.`IntEmployeeDept1`, `hill`.`IntEmployeeDept1`,
              `hsp`.`IntEmployeeDept1`, `hvd`.`IntEmployeeDept1`, `htv`.`IntEmployeeDept1`)    AS `IntEmployeeDept1`,
    concat_ws(', ', `hinj`.`IntEmployeeDept2`, `himp`.`IntEmployeeDept2`, `hill`.`IntEmployeeDept2`,
              `hsp`.`IntEmployeeDept2`, `hvd`.`IntEmployeeDept2`, `htv`.`IntEmployeeDept2`)    AS `IntEmployeeDept2`,
    concat_ws(', ', `hinj`.`IntEmployeeDept3`, `himp`.`IntEmployeeDept3`, `hill`.`IntEmployeeDept3`,
              `hsp`.`IntEmployeeDept3`, `hvd`.`IntEmployeeDept3`, `htv`.`IntEmployeeDept3`)    AS `IntEmployeeDept3`,
    concat_ws(', ', `hinj`.`PrimRespondName`, `himp`.`PrimRespondName`, `hill`.`PrimRespondName`,
              `hsp`.`PrimRespondName`, `hvd`.`PrimRespondName`, `htv`.`PrimRespondName`)       AS `PrimRespondName`,
    concat_ws(', ', `hinj`.`ImpactDescription`, `himp`.`ImpactDescription`, `hill`.`ImpactDescription`,
              `hsp`.`ImpactDescription`, `hvd`.`ImpactDescription`, `htv`.`ImpactDescription`) AS `ImpactDescription`,
    concat_ws(', ', `hinj`.`EstimatedCost`, `himp`.`EstimatedCost`, `hill`.`EstimatedCost`, `hsp`.`EstimatedCost`,
              `hvd`.`EstimatedCost`, `htv`.`EstimatedCost`)                                    AS `EstimatedCost`
  FROM ((((((((((`abcantrackv2`.`hist_incident` `hinc`
    JOIN `abcantrackv2`.`employee` ON ((`abcantrackv2`.`employee`.`EmployeeId` = `hinc`.`UpdatedById`))) JOIN
    `abcantrackv2`.`incident` `inc` ON ((`inc`.`IncidentId` = `hinc`.`IncidentId`))) LEFT JOIN
    ((`abcantrackv2`.`inc_third_party` `itpcust`
      JOIN `abcantrackv2`.`third_party` `tpcust` ON ((`itpcust`.`ThirdPartyId` = `tpcust`.`ThirdPartyId`))) JOIN
      `abcantrackv2`.`third_party_type` `tptcust` ON (((`tpcust`.`ThirdPartyTypeId` = `tptcust`.`ThirdPartyTypeId`) AND
                                                       (`tptcust`.`ThirdPartyTypeCode` = 'Customer'))))
      ON ((`inc`.`IncidentId` = `itpcust`.`IncidentId`))) LEFT JOIN ((`abcantrackv2`.`inc_third_party` `itpcont`
    JOIN `abcantrackv2`.`third_party` `tpcont` ON ((`itpcont`.`ThirdPartyId` = `tpcont`.`ThirdPartyId`))) JOIN
    `abcantrackv2`.`third_party_type` `tptcont` ON (((`tpcont`.`ThirdPartyTypeId` = `tptcont`.`ThirdPartyTypeId`) AND
                                                     (`tptcont`.`ThirdPartyTypeCode` = 'Contractor'))))
      ON ((`inc`.`IncidentId` = `itpcont`.`IncidentId`))) LEFT JOIN `abcantrackv2`.`hist_injury` `hinj`
      ON ((`hinc`.`HistIncidentId` = `hinj`.`HistIncidentId`))) LEFT JOIN `abcantrackv2`.`hist_impact` `himp`
      ON ((`hinc`.`HistIncidentId` = `himp`.`HistIncidentId`))) LEFT JOIN `abcantrackv2`.`hist_illness` `hill`
      ON ((`hinc`.`HistIncidentId` = `hill`.`HistIncidentId`))) LEFT JOIN `abcantrackv2`.`hist_spill_release` `hsp`
      ON ((`hinc`.`HistIncidentId` = `hsp`.`HistIncidentId`))) LEFT JOIN `abcantrackv2`.`hist_vehicle_damage` `hvd`
      ON ((`hinc`.`HistIncidentId` = `hvd`.`HistIncidentId`))) LEFT JOIN `abcantrackv2`.`hist_traffic_violation` `htv`
      ON ((`hinc`.`HistIncidentId` = `htv`.`HistIncidentId`)))
  WHERE (`inc`.`IsDeleted` = 0);
