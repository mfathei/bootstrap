CREATE VIEW ABCanTrackV2.incident_envconditions_view AS
  SELECT
    `abcantrackv2`.`incident`.`IncidentId`                                                        AS `IncidentId`,
    (SELECT group_concat(`abcantrackv2`.`env_cond_parameter`.`EnvCondParameterName` SEPARATOR '; ')
     FROM (`abcantrackv2`.`inc_env_cond`
       JOIN `abcantrackv2`.`env_cond_parameter` ON ((`abcantrackv2`.`env_cond_parameter`.`EnvCondParameterId` =
                                                     `abcantrackv2`.`inc_env_cond`.`EnvCondParameterId`)))
     WHERE (`abcantrackv2`.`inc_env_cond`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)) AS `EnvConditions`
  FROM (`abcantrackv2`.`incident`
    LEFT JOIN `abcantrackv2`.`inc_env_cond`
      ON ((`abcantrackv2`.`inc_env_cond`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)))
  GROUP BY `abcantrackv2`.`incident`.`IncidentId`
  ORDER BY `abcantrackv2`.`incident`.`IncidentId` DESC;
