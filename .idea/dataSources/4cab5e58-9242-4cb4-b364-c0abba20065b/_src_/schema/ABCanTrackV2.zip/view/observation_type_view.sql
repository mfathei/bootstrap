CREATE VIEW ABCanTrackV2.observation_type_view AS
  SELECT
    `tbl1`.`ObservationAndAnalysisId`         AS `ObservationAndAnalysisId`,
    `tbl1`.`ObservationAndAnalysisCode`       AS `ObservationAndAnalysisCode`,
    `tbl1`.`ObservationAndAnalysisName`       AS `ObservationAndAnalysisName`,
    `tbl1`.`OrgId`                            AS `OrgId`,
    `tbl1`.`Hide`                             AS `Hide`,
    `tbl2p`.`ObservationAndAnalysisParamId`   AS `PObservationAndAnalysisParamId`,
    `tbl2p`.`ObservationAndAnalysisParamName` AS `PObservationAndAnalysisParamName`,
    `tbl2p`.`Hide`                            AS `PHide`,
    `tbl2c`.`ObservationAndAnalysisParamId`   AS `CObservationAndAnalysisParamId`,
    `tbl2c`.`ObservationAndAnalysisParamName` AS `CObservationAndAnalysisParamName`,
    `tbl2c`.`ParentId`                        AS `ParentId`,
    `tbl2c`.`Hide`                            AS `CHide`
  FROM ((`abcantrackv2`.`observation_analysis` `tbl1`
    JOIN `abcantrackv2`.`observation_analysis_param` `tbl2c`
      ON ((`tbl1`.`ObservationAndAnalysisId` = `tbl2c`.`ObservationAndAnalysisId`))) JOIN
    `abcantrackv2`.`observation_analysis_param` `tbl2p`
      ON ((`tbl2c`.`ParentId` = `tbl2p`.`ObservationAndAnalysisParamId`)));
