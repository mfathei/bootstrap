CREATE VIEW ABCanTrackV2.email_to_view AS
  SELECT
    `eto`.`EmailToId`                                                                                  AS `EmailToId`,
    `eto`.`GroupId`                                                                                    AS `GroupId`,
    `eto`.`EmployeeId`                                                                                 AS `EmployeeId`,
    concat(`e`.`FirstName`, ' ',
           `e`.`LastName`)                                                                             AS `EmployeeName`,
    `e`.`Position`                                                                                     AS `Position`,
    `g`.`GroupName`                                                                                    AS `GroupName`,
    group_concat(DISTINCT `et`.`EmailTypeName` SEPARATOR
                 ', ')                                                                                 AS `EmailTypeName`,
    `eto`.`OrgId`                                                                                      AS `OrgId`,
    `GETASSIGNNOTIFICATIONSFUN`(`eto`.`EmployeeId`, `eto`.`GroupId`, `eto`.`TableName`,
                                `eto`.`OrgId`)                                                         AS `AssignedNotifications`,
    NULL                                                                                               AS `DaysStart`,
    NULL                                                                                               AS `DaysFreq`,
    NULL                                                                                               AS `DaysStartInc`,
    NULL                                                                                               AS `DaysFreqInc`,
    group_concat(`eto`.`TableName` SEPARATOR
                 ',')                                                                                  AS `GROUP_CONCAT(``eto``.TableName)`
  FROM ((((`abcantrackv2`.`email_to` `eto` LEFT JOIN `abcantrackv2`.`email_to_esc` `etoesc`
      ON (((`eto`.`OrgId` = `etoesc`.`OrgId`) AND (`eto`.`EmployeeId` = `etoesc`.`EmployeeId`) AND
           (`eto`.`GroupId` = `etoesc`.`GroupId`)))) LEFT JOIN `abcantrackv2`.`employee` `e`
      ON ((`eto`.`EmployeeId` = `e`.`EmployeeId`))) JOIN `abcantrackv2`.`email_type` `et`
      ON ((`et`.`EmailTypeId` = `eto`.`EmailTypeId`))) LEFT JOIN `abcantrackv2`.`group` `g`
      ON ((`g`.`GroupId` = `eto`.`GroupId`)))
  UNION ALL SELECT
              `etoesc`.`EmailToEscId`                                                                             AS `EmailToId`,
              `etoesc`.`GroupId`                                                                                  AS `GroupId`,
              `etoesc`.`EmployeeId`                                                                               AS `EmployeeId`,
              concat(`e`.`FirstName`, ' ',
                     `e`.`LastName`)                                                                              AS `EmployeeName`,
              `e`.`Position`                                                                                      AS `Position`,
              `g`.`GroupName`                                                                                     AS `GroupName`,
              NULL                                                                                                AS `EmailTypeName`,
              `etoesc`.`OrgId`                                                                                    AS `OrgId`,
              `GETASSIGNNOTIFICATIONSFUN`(`etoesc`.`EmployeeId`, `etoesc`.`GroupId`, `etoesc`.`TableName`,
                                          `etoesc`.`OrgId`)                                                       AS `AssignedNotifications`,
              `EMAIL_TO_FUN`(`etoesc`.`OrgId`, `etoesc`.`GroupId`, `etoesc`.`EmployeeId`, 1,
                             'corrective_action')                                                                 AS `DaysStart`,
              `EMAIL_TO_FUN`(`etoesc`.`OrgId`, `etoesc`.`GroupId`, `etoesc`.`EmployeeId`, 2,
                             'corrective_action')                                                                 AS `DaysFreq`,
              `EMAIL_TO_FUN`(`etoesc`.`OrgId`, `etoesc`.`GroupId`, `etoesc`.`EmployeeId`, 1,
                             'incident')                                                                          AS `DaysStartInc`,
              `EMAIL_TO_FUN`(`etoesc`.`OrgId`, `etoesc`.`GroupId`, `etoesc`.`EmployeeId`, 2,
                             'incident')                                                                          AS `DaysFreqInc`,
              group_concat(`etoesc`.`TableName` SEPARATOR
                           ',')                                                                                   AS `GROUP_CONCAT(``etoesc``.TableName)`
            FROM (((`abcantrackv2`.`email_to_esc` `etoesc` LEFT JOIN `abcantrackv2`.`email_to` `eto`
                ON (((`eto`.`OrgId` = `etoesc`.`OrgId`) AND (`eto`.`EmployeeId` = `etoesc`.`EmployeeId`) AND
                     (`eto`.`GroupId` = `etoesc`.`GroupId`)))) LEFT JOIN `abcantrackv2`.`employee` `e`
                ON ((`etoesc`.`EmployeeId` = `e`.`EmployeeId`))) LEFT JOIN `abcantrackv2`.`group` `g`
                ON ((`g`.`GroupId` = `etoesc`.`GroupId`)));
