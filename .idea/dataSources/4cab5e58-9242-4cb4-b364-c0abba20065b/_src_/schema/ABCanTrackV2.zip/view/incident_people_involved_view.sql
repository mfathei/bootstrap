CREATE VIEW ABCanTrackV2.incident_people_involved_view AS
  SELECT
    `abcantrackv2`.`people_involved`.`IncidentId`                                                                          AS `IncidentId`,
    `abcantrackv2`.`people_involved`.`PeopleInvolvedId`                                                                    AS `PeopleInvolvedId`,
    `abcantrackv2`.`people_involved`.`PeopleInvolvedName`                                                                  AS `PeopleInvolvedName`,
    `abcantrackv2`.`people_involved`.`Company`                                                                             AS `Company`,
    `abcantrackv2`.`people_involved`.`Position`                                                                            AS `Position`,
    `abcantrackv2`.`people_involved`.`Email`                                                                               AS `Email`,
    `abcantrackv2`.`people_involved`.`PrimaryPhone`                                                                        AS `PrimaryPhone`,
    `abcantrackv2`.`people_involved`.`AlternatePhone`                                                                      AS `AlternatePhone`,
    `abcantrackv2`.`people_involved`.`ExpInCurrentPostion`                                                                 AS `ExpInCurrentPostion`,
    `abcantrackv2`.`people_involved`.`ExpOverAll`                                                                          AS `ExpOverAll`,
    `abcantrackv2`.`people_involved`.`Age`                                                                                 AS `Age`,
    `abcantrackv2`.`people_involved`.`HowHeInvolved`                                                                       AS `HowHeInvolved`,
    `abcantrackv2`.`people_involved`.`RoleDescription`                                                                     AS `RoleDescription`,
    (SELECT group_concat(`abcantrackv2`.`certificate`.`CertificateName` SEPARATOR '; ')
     FROM `abcantrackv2`.`certificate`
     WHERE `abcantrackv2`.`certificate`.`CertificateId` IN (SELECT `abcantrackv2`.`have_certificate`.`CertificateId`
                                                            FROM `abcantrackv2`.`have_certificate`
                                                            WHERE (`abcantrackv2`.`people_involved`.`PeopleInvolvedId` =
                                                                   `abcantrackv2`.`have_certificate`.`PeopleInvolvedId`))) AS `CertificateId`
  FROM (`abcantrackv2`.`people_involved`
    LEFT JOIN `abcantrackv2`.`third_party`
      ON ((`abcantrackv2`.`third_party`.`ThirdPartyId` = `abcantrackv2`.`people_involved`.`ThirdPartyId`)))
  ORDER BY `abcantrackv2`.`people_involved`.`IncidentId` DESC;
