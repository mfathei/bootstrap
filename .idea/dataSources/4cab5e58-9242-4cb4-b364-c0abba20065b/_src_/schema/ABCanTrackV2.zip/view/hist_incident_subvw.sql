CREATE VIEW ABCanTrackV2.hist_incident_subvw AS
  SELECT
    `hi`.`IncidentId`         AS `IncidentId`,
    max(`hi`.`VersionNumber`) AS `VersionNumber`
  FROM `abcantrackv2`.`hist_incident` `hi`
  GROUP BY `hi`.`IncidentId`;
