CREATE VIEW ABCanTrackV2.city_view AS
  SELECT
    1 AS `id`,
    1 AS `city_name`,
    1 AS `city_abbrev`,
    1 AS `timezone_offset`,
    1 AS `dayligtht_saving_time`,
    1 AS `country_name`,
    1 AS `country_id`,
    1 AS `prov_name`,
    1 AS `county_name`,
    1 AS `abbrev`,
    1 AS `CityProperties`,
    1 AS `CityTaxRate`;
