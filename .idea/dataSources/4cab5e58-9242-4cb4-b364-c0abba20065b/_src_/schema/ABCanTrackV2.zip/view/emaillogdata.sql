CREATE VIEW ABCanTrackV2.emaillogdata AS
  SELECT
    group_concat(`i`.`IncidentNumber` SEPARATOR ',')     AS `IncidentNumber`,
    group_concat(DISTINCT concat(`hi`.`IncidentDate`, ' ', `hi`.`IncidentHour`, ':', `hi`.`IncidentMinute`) SEPARATOR
                 ', ')                                   AS `IncidentDate`,
    group_concat(`hi`.`EventTypeName` SEPARATOR ',')     AS `EventTypeName`,
    group_concat(`hi`.`Location1Name` SEPARATOR ',')     AS `Location1Name`,
    group_concat(`hi`.`Location2Name` SEPARATOR ',')     AS `Location2Name`,
    group_concat(`hi`.`Location3Name` SEPARATOR ',')     AS `Location3Name`,
    group_concat(`hi`.`Location4Name` SEPARATOR ',')     AS `Location4Name`,
    group_concat(`hi`.`OperationTypeName` SEPARATOR ',') AS `OperationTypeName`,
    `el`.`EmailLogId`                                    AS `EmailLogId`,
    `hi`.`HistIncidentId`                                AS `HistIncidentId`,
    `hi`.`IncidentId`                                    AS `IncidentId`,
    `el`.`From`                                          AS `From`,
    `el`.`To`                                            AS `To`,
    `el`.`CC`                                            AS `CC`,
    `el`.`SendToEmployeeId`                              AS `SendToEmployeeId`,
    `el`.`CcEmployeeId`                                  AS `CcEmployeeId`,
    `el`.`IsSent`                                        AS `IsSent`,
    `el`.`Error`                                         AS `Error`,
    `el`.`IsManual`                                      AS `IsManual`,
    `el`.`Subject`                                       AS `Subject`,
    `el`.`SentDate`                                      AS `SentDate`,
    `el`.`OrgId`                                         AS `OrgId`,
    `i`.`IsDeleted`                                      AS `IsDeleted`
  FROM (((`abcantrackv2`.`email_log` `el` LEFT JOIN `abcantrackv2`.`inc_email_log` `ieg`
      ON ((`ieg`.`EmailLogId` = `el`.`EmailLogId`))) LEFT JOIN `abcantrackv2`.`hist_incident` `hi`
      ON ((`hi`.`HistIncidentId` = `ieg`.`HistIncidentId`))) LEFT JOIN `abcantrackv2`.`incident` `i`
      ON ((`hi`.`IncidentId` = `i`.`IncidentId`)))
  GROUP BY `el`.`EmailLogId`;
