CREATE VIEW ABCanTrackV2.incident_illness_view AS
  SELECT
    `abcantrackv2`.`illness`.`IncidentId`                                                            AS `IncidentId`,
    `abcantrackv2`.`illness`.`IllnessId`                                                             AS `IllnessId`,
    `abcantrackv2`.`illness`.`PersonalAfflictedName`                                                 AS `Illness_PersonalInjured`,
    `abcantrackv2`.`restricted_work`.`RestrictedWorkName`                                            AS `Illness_RestrictedWorkId`,
    `abcantrackv2`.`initial_treatment`.`InitialTreatmentName`                                        AS `Illness_InitialTreatmentId`,
    (SELECT group_concat(`abcantrackv2`.`symptoms`.`Description` SEPARATOR ' ; ')
     FROM `abcantrackv2`.`symptoms`
     WHERE `abcantrackv2`.`symptoms`.`SymptomsId` IN (SELECT `abcantrackv2`.`illness_symptoms`.`SymptomsId`
                                                      FROM `abcantrackv2`.`illness_symptoms`
                                                      WHERE (`abcantrackv2`.`illness_symptoms`.`IllnessId` =
                                                             `abcantrackv2`.`illness`.`IllnessId`))) AS `SymptomsId`,
    `abcantrackv2`.`illness`.`IllnessDescription`                                                    AS `IllnessDescription`,
    `abcantrackv2`.`illness`.`LostTimeStart`                                                         AS `Illness_LostTimeStart`,
    `abcantrackv2`.`illness`.`LostTimeEnd`                                                           AS `Illness_LostTimeEnd`,
    `abcantrackv2`.`illness`.`AdjustmentDays`                                                        AS `Illness_AdjustmentDays`,
    `abcantrackv2`.`illness`.`TotalDaysOff`                                                          AS `Illness_TotalDaysOff`
  FROM ((`abcantrackv2`.`illness`
    LEFT JOIN `abcantrackv2`.`restricted_work` ON ((`abcantrackv2`.`restricted_work`.`RestrictedWorkId` =
                                                    `abcantrackv2`.`illness`.`RestrictedWorkId`))) LEFT JOIN
    `abcantrackv2`.`initial_treatment`
      ON ((`abcantrackv2`.`initial_treatment`.`InitialTreatmentId` = `abcantrackv2`.`illness`.`InitialTreatmentId`)));
