CREATE VIEW ABCanTrackV2.inc_names AS
  SELECT
    `inc`.`IncidentId`                                                                                              AS `IncidentId`,
    group_concat(DISTINCT `abcantrackv2`.`oe_department`.`OEDepartmentName` SEPARATOR
                 '; ')                                                                                              AS `OEDepartmentId`,
    group_concat(DISTINCT `abcantrackv2`.`env_cond_parameter`.`EnvCondParameterName` SEPARATOR
                 '; ')                                                                                              AS `EnvConditions`,
    group_concat(DISTINCT `abcantrackv2`.`root_cause_param`.`RootCauseParamName` SEPARATOR
                 '; ')                                                                                              AS `RootCauseParamId`,
    group_concat(DISTINCT `oapsa`.`ObservationAndAnalysisParamName` SEPARATOR
                 '; ')                                                                                              AS `SubActions`,
    group_concat(DISTINCT `oapuc`.`ObservationAndAnalysisParamName` SEPARATOR
                 '; ')                                                                                              AS `UnderLyingCauses`,
    group_concat(DISTINCT `oapsc`.`ObservationAndAnalysisParamName` SEPARATOR
                 '; ')                                                                                              AS `SubConditions`,
    group_concat(DISTINCT if((`pinv`.`PeopleInvolvedName` = ''), NULL, `pinv`.`PeopleInvolvedName`) SEPARATOR
                 '; ')                                                                                              AS `PeopleInvolvedName`
  FROM (((((((`abcantrackv2`.`incident` `inc` LEFT JOIN (`abcantrackv2`.`inc_oe_department`
    JOIN `abcantrackv2`.`oe_department`
      ON ((`abcantrackv2`.`oe_department`.`OEDepartmentId` = `abcantrackv2`.`inc_oe_department`.`OEDepartmentId`)))
      ON ((`inc`.`IncidentId` = `abcantrackv2`.`inc_oe_department`.`IncidentId`))) LEFT JOIN
    (`abcantrackv2`.`inc_env_cond`
      JOIN `abcantrackv2`.`env_cond_parameter` ON ((`abcantrackv2`.`env_cond_parameter`.`EnvCondParameterId` =
                                                    `abcantrackv2`.`inc_env_cond`.`EnvCondParameterId`)))
      ON ((`inc`.`IncidentId` = `abcantrackv2`.`inc_env_cond`.`IncidentId`))) LEFT JOIN (`abcantrackv2`.`inc_root_cause`
    JOIN `abcantrackv2`.`root_cause_param`
      ON ((`abcantrackv2`.`root_cause_param`.`RootCauseParamId` = `abcantrackv2`.`inc_root_cause`.`RootCauseParamId`)))
      ON ((`inc`.`IncidentId` = `abcantrackv2`.`inc_root_cause`.`IncidentId`))) LEFT JOIN
    ((`abcantrackv2`.`inc_obser_ana` `ioasa`
      JOIN `abcantrackv2`.`observation_analysis_param` `oapsa`
        ON ((`oapsa`.`ObservationAndAnalysisParamId` = `ioasa`.`ObservationAndAnalysisParamId`))) JOIN
      `abcantrackv2`.`observation_analysis` `oasa`
        ON (((`oasa`.`ObservationAndAnalysisId` = `oapsa`.`ObservationAndAnalysisId`) AND
             (`oasa`.`ObservationAndAnalysisCode` = 'SubActions'))))
      ON ((`inc`.`IncidentId` = `ioasa`.`IncidentId`))) LEFT JOIN ((`abcantrackv2`.`inc_obser_ana` `ioauc`
    JOIN `abcantrackv2`.`observation_analysis_param` `oapuc`
      ON ((`oapuc`.`ObservationAndAnalysisParamId` = `ioauc`.`ObservationAndAnalysisParamId`))) JOIN
    `abcantrackv2`.`observation_analysis` `oauc`
      ON (((`oauc`.`ObservationAndAnalysisId` = `oapuc`.`ObservationAndAnalysisId`) AND
           (`oauc`.`ObservationAndAnalysisCode` = 'UnderLyingCauses'))))
      ON ((`inc`.`IncidentId` = `ioauc`.`IncidentId`))) LEFT JOIN ((`abcantrackv2`.`inc_obser_ana` `ioasc`
    JOIN `abcantrackv2`.`observation_analysis_param` `oapsc`
      ON ((`oapsc`.`ObservationAndAnalysisParamId` = `ioasc`.`ObservationAndAnalysisParamId`))) JOIN
    `abcantrackv2`.`observation_analysis` `oasc`
      ON (((`oasc`.`ObservationAndAnalysisId` = `oapsc`.`ObservationAndAnalysisId`) AND
           (`oasc`.`ObservationAndAnalysisCode` = 'SubConditions'))))
      ON ((`inc`.`IncidentId` = `ioasc`.`IncidentId`))) LEFT JOIN `abcantrackv2`.`people_involved` `pinv`
      ON ((`pinv`.`IncidentId` = `inc`.`IncidentId`)))
  GROUP BY `inc`.`IncidentId`;
