CREATE VIEW ABCanTrackV2.location_view AS
  SELECT
    `abcantrackv2`.`location1`.`Location1Id`   AS `Location1Id`,
    `abcantrackv2`.`location1`.`Location1Name` AS `Location1Name`,
    `abcantrackv2`.`location1`.`OrgId`         AS `OrgId`,
    `abcantrackv2`.`location1`.`Order`         AS `Location1Order`,
    `abcantrackv2`.`location1`.`Hide`          AS `Location1Hide`,
    `abcantrackv2`.`location2`.`Location2Id`   AS `Location2Id`,
    `abcantrackv2`.`location2`.`Location2Name` AS `Location2Name`,
    `abcantrackv2`.`location2`.`Order`         AS `Location2Order`,
    `abcantrackv2`.`location3`.`Location3Id`   AS `Location3Id`,
    `abcantrackv2`.`location3`.`Location3Name` AS `Location3Name`,
    `abcantrackv2`.`location3`.`Order`         AS `Location3Order`,
    `abcantrackv2`.`location4`.`Location4Id`   AS `Location4Id`,
    `abcantrackv2`.`location4`.`Location4Name` AS `Location4Name`,
    `abcantrackv2`.`location4`.`Order`         AS `Location4Order`,
    `abcantrackv2`.`location2`.`Hide`          AS `Location2Hide`,
    `abcantrackv2`.`location3`.`Hide`          AS `Location3Hide`,
    `abcantrackv2`.`location4`.`Hide`          AS `Location4Hide`
  FROM (((`abcantrackv2`.`location1`
    JOIN `abcantrackv2`.`location2`
      ON ((`abcantrackv2`.`location1`.`Location1Id` = `abcantrackv2`.`location2`.`Location1Id`))) LEFT JOIN
    `abcantrackv2`.`location3`
      ON ((`abcantrackv2`.`location2`.`Location2Id` = `abcantrackv2`.`location3`.`Location2Id`))) LEFT JOIN
    `abcantrackv2`.`location4`
      ON ((`abcantrackv2`.`location3`.`Location3Id` = `abcantrackv2`.`location4`.`Location3Id`)));
