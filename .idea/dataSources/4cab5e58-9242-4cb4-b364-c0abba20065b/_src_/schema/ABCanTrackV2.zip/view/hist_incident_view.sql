CREATE VIEW ABCanTrackV2.hist_incident_view AS
  SELECT
    `abcantrackv2`.`hist_incident`.`HistIncidentId`                                                                AS `HistIncidentId`,
    `abcantrackv2`.`hist_incident`.`IncidentId`                                                                    AS `IncidentId`,
    `abcantrackv2`.`hist_incident`.`EventTypeName`                                                                 AS `EventTypeName`,
    `abcantrackv2`.`hist_incident`.`OperationTypeName`                                                             AS `OperationTypeName`,
    `abcantrackv2`.`hist_incident`.`OrgId`                                                                         AS `OrgId`,
    `abcantrackv2`.`hist_incident`.`EmployeeName`                                                                  AS `EmployeeName`,
    `abcantrackv2`.`hist_incident`.`IncidentDate`                                                                  AS `IncidentDate`,
    `abcantrackv2`.`hist_incident`.`IncidentHour`                                                                  AS `IncidentHour`,
    `abcantrackv2`.`hist_incident`.`IncidentMinute`                                                                AS `IncidentMinute`,
    `abcantrackv2`.`hist_incident`.`IsEmerRP`                                                                      AS `IsEmerRP`,
    `abcantrackv2`.`hist_incident`.`RepName`                                                                       AS `RepName`,
    `abcantrackv2`.`hist_incident`.`RepEmail`                                                                      AS `RepEmail`,
    `abcantrackv2`.`hist_incident`.`RepPosition`                                                                   AS `RepPosition`,
    `abcantrackv2`.`hist_incident`.`RepCompany`                                                                    AS `RepCompany`,
    `abcantrackv2`.`hist_incident`.`RepPrimaryPhone`                                                               AS `RepPrimaryPhone`,
    `abcantrackv2`.`hist_incident`.`RepAlternatePhone`                                                             AS `RepAlternatePhone`,
    `abcantrackv2`.`hist_incident`.`Location1Name`                                                                 AS `Location1Name`,
    `abcantrackv2`.`hist_incident`.`Location2Name`                                                                 AS `Location2Name`,
    `abcantrackv2`.`hist_incident`.`Location3Name`                                                                 AS `Location3Name`,
    `abcantrackv2`.`hist_incident`.`Location4Name`                                                                 AS `Location4Name`,
    `abcantrackv2`.`hist_incident`.`OtherLocation`                                                                 AS `OtherLocation`,
    `abcantrackv2`.`hist_incident`.`OEDepartmentName`                                                              AS `OEDepartmentName`,
    `abcantrackv2`.`hist_incident`.`EventSequence`                                                                 AS `EventSequence`,
    `abcantrackv2`.`hist_incident`.`EnvConditionNote`                                                              AS `EnvConditionNote`,
    `abcantrackv2`.`hist_incident`.`EnvConditionName`                                                              AS `EnvConditionName`,
    `abcantrackv2`.`hist_incident`.`IncDescription`                                                                AS `IncDescription`,
    `abcantrackv2`.`hist_incident`.`ObserAnaName`                                                                  AS `ObserAnaName`,
    `abcantrackv2`.`hist_incident`.`IncInvSourceName`                                                              AS `IncInvSourceName`,
    `abcantrackv2`.`hist_incident`.`EnergyFormNote`                                                                AS `EnergyFormNote`,
    `abcantrackv2`.`hist_incident`.`SubStandardActionNote`                                                         AS `SubStandardActionNote`,
    `abcantrackv2`.`hist_incident`.`SubStandardConditionNote`                                                      AS `SubStandardConditionNote`,
    `abcantrackv2`.`hist_incident`.`UnderLyingCauseNote`                                                           AS `UnderLyingCauseNote`,
    `abcantrackv2`.`hist_incident`.`InvStatusName`                                                                 AS `InvStatusName`,
    `abcantrackv2`.`hist_incident`.`InvestigationDate`                                                             AS `InvestigationDate`,
    `abcantrackv2`.`hist_incident`.`InvestigatorName1`                                                             AS `InvestigatorName1`,
    `abcantrackv2`.`hist_incident`.`InvestigatorName2`                                                             AS `InvestigatorName2`,
    `abcantrackv2`.`hist_incident`.`InvestigatorName3`                                                             AS `InvestigatorName3`,
    `abcantrackv2`.`hist_incident`.`RootCauseName`                                                                 AS `RootCauseName`,
    `abcantrackv2`.`hist_incident`.`OtherRootCause`                                                                AS `OtherRootCause`,
    `abcantrackv2`.`hist_incident`.`ThirdPartyName`                                                                AS `ThirdPartyName`,
    `abcantrackv2`.`hist_incident`.`JobNumber`                                                                     AS `JobNumber`,
    `abcantrackv2`.`hist_incident`.`ContactName`                                                                   AS `ContactName`,
    `abcantrackv2`.`hist_incident`.`InvSummary`                                                                    AS `InvSummary`,
    `abcantrackv2`.`hist_incident`.`FollowUpNote`                                                                  AS `FollowUpNote`,
    `abcantrackv2`.`hist_incident`.`ResponseCost`                                                                  AS `ResponseCost`,
    `abcantrackv2`.`hist_incident`.`RepairCost`                                                                    AS `RepairCost`,
    `abcantrackv2`.`hist_incident`.`InsuranceCost`                                                                 AS `InsuranceCost`,
    `abcantrackv2`.`hist_incident`.`WCBCost`                                                                       AS `WCBCost`,
    `abcantrackv2`.`hist_incident`.`OtherCost`                                                                     AS `OtherCost`,
    `abcantrackv2`.`hist_incident`.`TotalCost`                                                                     AS `TotalCost`,
    `abcantrackv2`.`hist_incident`.`RiskOfRecurrenceName`                                                          AS `RiskOfRecurrenceName`,
    `abcantrackv2`.`hist_incident`.`IncidentSeverityName`                                                          AS `IncidentSeverityName`,
    `abcantrackv2`.`hist_incident`.`SourceDetails`                                                                 AS `SourceDetails`,
    `abcantrackv2`.`hist_incident`.`RootCauseNote`                                                                 AS `RootCauseNote`,
    `abcantrackv2`.`hist_incident`.`SignOffInvestigatorName`                                                       AS `SignOffInvestigatorName`,
    `abcantrackv2`.`hist_incident`.`SignOffDate`                                                                   AS `SignOffDate`,
    `abcantrackv2`.`hist_incident`.`UpdatedById`                                                                   AS `UpdatedById`,
    `abcantrackv2`.`hist_incident`.`UpdatedDate`                                                                   AS `UpdatedDate`,
    `abcantrackv2`.`hist_incident`.`VersionNumber`                                                                 AS `VersionNumber`,
    (SELECT `abcantrackv2`.`incident`.`IncidentNumber`
     FROM `abcantrackv2`.`incident`
     WHERE (`abcantrackv2`.`incident`.`IncidentId` =
            `abcantrackv2`.`hist_incident`.`IncidentId`))                                                          AS `IncidentNumber`,
    (SELECT group_concat(`abcantrackv2`.`third_party`.`ThirdPartyName` SEPARATOR ' ; ')
     FROM (`abcantrackv2`.`third_party`
       LEFT JOIN `abcantrackv2`.`third_party_type`
         ON ((`abcantrackv2`.`third_party_type`.`ThirdPartyTypeId` = `abcantrackv2`.`third_party`.`ThirdPartyTypeId`)))
     WHERE ((`abcantrackv2`.`third_party_type`.`ThirdPartyTypeName` = 'Customer') AND
            `abcantrackv2`.`third_party`.`ThirdPartyId` IN (SELECT `abcantrackv2`.`inc_third_party`.`ThirdPartyId`
                                                            FROM `abcantrackv2`.`inc_third_party`
                                                            WHERE (`abcantrackv2`.`inc_third_party`.`IncidentId` =
                                                                   `abcantrackv2`.`hist_incident`.`IncidentId`)))) AS `CustomerName`,
    (SELECT group_concat(`abcantrackv2`.`inc_third_party`.`ContactName` SEPARATOR ' ; ')
     FROM ((`abcantrackv2`.`inc_third_party`
       LEFT JOIN `abcantrackv2`.`third_party`
         ON ((`abcantrackv2`.`inc_third_party`.`ThirdPartyId` = `abcantrackv2`.`third_party`.`ThirdPartyId`))) LEFT JOIN
       `abcantrackv2`.`third_party_type`
         ON ((`abcantrackv2`.`third_party_type`.`ThirdPartyTypeId` = `abcantrackv2`.`third_party`.`ThirdPartyTypeId`)))
     WHERE ((`abcantrackv2`.`third_party_type`.`ThirdPartyTypeName` = 'Customer') AND
            (`abcantrackv2`.`inc_third_party`.`IncidentId` =
             `abcantrackv2`.`hist_incident`.`IncidentId`)))                                                        AS `CustName`,
    (SELECT group_concat(`abcantrackv2`.`inc_third_party`.`JobNumber` SEPARATOR ' ; ')
     FROM ((`abcantrackv2`.`inc_third_party`
       LEFT JOIN `abcantrackv2`.`third_party`
         ON ((`abcantrackv2`.`inc_third_party`.`ThirdPartyId` = `abcantrackv2`.`third_party`.`ThirdPartyId`))) LEFT JOIN
       `abcantrackv2`.`third_party_type`
         ON ((`abcantrackv2`.`third_party_type`.`ThirdPartyTypeId` = `abcantrackv2`.`third_party`.`ThirdPartyTypeId`)))
     WHERE ((`abcantrackv2`.`third_party_type`.`ThirdPartyTypeName` = 'Customer') AND
            (`abcantrackv2`.`inc_third_party`.`IncidentId` =
             `abcantrackv2`.`hist_incident`.`IncidentId`)))                                                        AS `CustomerJobNumber`,
    (SELECT group_concat(`abcantrackv2`.`third_party`.`ThirdPartyName` SEPARATOR ' ; ')
     FROM (`abcantrackv2`.`third_party`
       LEFT JOIN `abcantrackv2`.`third_party_type`
         ON ((`abcantrackv2`.`third_party_type`.`ThirdPartyTypeId` = `abcantrackv2`.`third_party`.`ThirdPartyTypeId`)))
     WHERE ((`abcantrackv2`.`third_party_type`.`ThirdPartyTypeName` = 'Contractor') AND
            `abcantrackv2`.`third_party`.`ThirdPartyId` IN (SELECT `abcantrackv2`.`inc_third_party`.`ThirdPartyId`
                                                            FROM `abcantrackv2`.`inc_third_party`
                                                            WHERE (`abcantrackv2`.`inc_third_party`.`IncidentId` =
                                                                   `abcantrackv2`.`hist_incident`.`IncidentId`)))) AS `ContractorName`,
    (SELECT group_concat(`abcantrackv2`.`inc_third_party`.`JobNumber` SEPARATOR ' ; ')
     FROM ((`abcantrackv2`.`inc_third_party`
       LEFT JOIN `abcantrackv2`.`third_party`
         ON ((`abcantrackv2`.`inc_third_party`.`ThirdPartyId` = `abcantrackv2`.`third_party`.`ThirdPartyId`))) LEFT JOIN
       `abcantrackv2`.`third_party_type`
         ON ((`abcantrackv2`.`third_party_type`.`ThirdPartyTypeId` = `abcantrackv2`.`third_party`.`ThirdPartyTypeId`)))
     WHERE ((`abcantrackv2`.`third_party_type`.`ThirdPartyTypeName` = 'Contractor') AND
            (`abcantrackv2`.`inc_third_party`.`IncidentId` =
             `abcantrackv2`.`hist_incident`.`IncidentId`)))                                                        AS `ContractorJobNumber`,
    (SELECT group_concat(`abcantrackv2`.`inc_third_party`.`ContactName` SEPARATOR ' ; ')
     FROM ((`abcantrackv2`.`inc_third_party`
       LEFT JOIN `abcantrackv2`.`third_party`
         ON ((`abcantrackv2`.`inc_third_party`.`ThirdPartyId` = `abcantrackv2`.`third_party`.`ThirdPartyId`))) LEFT JOIN
       `abcantrackv2`.`third_party_type`
         ON ((`abcantrackv2`.`third_party_type`.`ThirdPartyTypeId` = `abcantrackv2`.`third_party`.`ThirdPartyTypeId`)))
     WHERE ((`abcantrackv2`.`third_party_type`.`ThirdPartyTypeName` = 'Contractor') AND
            (`abcantrackv2`.`inc_third_party`.`IncidentId` =
             `abcantrackv2`.`hist_incident`.`IncidentId`)))                                                        AS `ContName`,
    (SELECT concat(`abcantrackv2`.`employee`.`FirstName`, ' ',
                   `abcantrackv2`.`employee`.`LastName`))                                                          AS `UpdatedByName`
  FROM ((`abcantrackv2`.`hist_incident`
    JOIN `abcantrackv2`.`employee`
      ON ((`abcantrackv2`.`employee`.`EmployeeId` = `abcantrackv2`.`hist_incident`.`UpdatedById`))) JOIN
    `abcantrackv2`.`incident`
      ON ((`abcantrackv2`.`incident`.`IncidentId` = `abcantrackv2`.`hist_incident`.`IncidentId`)))
  WHERE
    ((`abcantrackv2`.`hist_incident`.`HistIncidentId` = `hist_incident`(`abcantrackv2`.`hist_incident`.`IncidentId`))
     AND (`abcantrackv2`.`incident`.`IsDeleted` = 0))
  GROUP BY `abcantrackv2`.`hist_incident`.`IncidentId`;
