CREATE VIEW ABCanTrackV2.incident_observation_analysis_view AS
  SELECT
    `abcantrackv2`.`incident`.`IncidentId`                                                              AS `IncidentId`,
    (SELECT group_concat(`abcantrackv2`.`observation_analysis_param`.`ObservationAndAnalysisParamName` SEPARATOR '; ')
     FROM ((`abcantrackv2`.`inc_obser_ana`
       JOIN `abcantrackv2`.`observation_analysis_param`
         ON ((`abcantrackv2`.`observation_analysis_param`.`ObservationAndAnalysisParamId` =
              `abcantrackv2`.`inc_obser_ana`.`ObservationAndAnalysisParamId`))) JOIN
       `abcantrackv2`.`observation_analysis` ON ((`abcantrackv2`.`observation_analysis`.`ObservationAndAnalysisId` =
                                                  `abcantrackv2`.`observation_analysis_param`.`ObservationAndAnalysisId`)))
     WHERE ((`abcantrackv2`.`inc_obser_ana`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`) AND
            (`abcantrackv2`.`observation_analysis`.`ObservationAndAnalysisCode` = 'EnergyForm')))       AS `EnergyForm`,
    (SELECT group_concat(`abcantrackv2`.`observation_analysis_param`.`ObservationAndAnalysisParamName` SEPARATOR '; ')
     FROM ((`abcantrackv2`.`inc_obser_ana`
       JOIN `abcantrackv2`.`observation_analysis_param`
         ON ((`abcantrackv2`.`observation_analysis_param`.`ObservationAndAnalysisParamId` =
              `abcantrackv2`.`inc_obser_ana`.`ObservationAndAnalysisParamId`))) JOIN
       `abcantrackv2`.`observation_analysis` ON ((`abcantrackv2`.`observation_analysis`.`ObservationAndAnalysisId` =
                                                  `abcantrackv2`.`observation_analysis_param`.`ObservationAndAnalysisId`)))
     WHERE ((`abcantrackv2`.`inc_obser_ana`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`) AND
            (`abcantrackv2`.`observation_analysis`.`ObservationAndAnalysisCode` = 'SubActions')))       AS `SubActions`,
    (SELECT group_concat(`abcantrackv2`.`observation_analysis_param`.`ObservationAndAnalysisParamName` SEPARATOR '; ')
     FROM ((`abcantrackv2`.`inc_obser_ana`
       JOIN `abcantrackv2`.`observation_analysis_param`
         ON ((`abcantrackv2`.`observation_analysis_param`.`ObservationAndAnalysisParamId` =
              `abcantrackv2`.`inc_obser_ana`.`ObservationAndAnalysisParamId`))) JOIN
       `abcantrackv2`.`observation_analysis` ON ((`abcantrackv2`.`observation_analysis`.`ObservationAndAnalysisId` =
                                                  `abcantrackv2`.`observation_analysis_param`.`ObservationAndAnalysisId`)))
     WHERE ((`abcantrackv2`.`inc_obser_ana`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`) AND
            (`abcantrackv2`.`observation_analysis`.`ObservationAndAnalysisCode` =
             'SubConditions')))                                                                         AS `SubConditions`,
    (SELECT group_concat(`abcantrackv2`.`observation_analysis_param`.`ObservationAndAnalysisParamName` SEPARATOR '; ')
     FROM ((`abcantrackv2`.`inc_obser_ana`
       JOIN `abcantrackv2`.`observation_analysis_param`
         ON ((`abcantrackv2`.`observation_analysis_param`.`ObservationAndAnalysisParamId` =
              `abcantrackv2`.`inc_obser_ana`.`ObservationAndAnalysisParamId`))) JOIN
       `abcantrackv2`.`observation_analysis` ON ((`abcantrackv2`.`observation_analysis`.`ObservationAndAnalysisId` =
                                                  `abcantrackv2`.`observation_analysis_param`.`ObservationAndAnalysisId`)))
     WHERE ((`abcantrackv2`.`inc_obser_ana`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`) AND
            (`abcantrackv2`.`observation_analysis`.`ObservationAndAnalysisCode` =
             'UnderLyingCauses')))                                                                      AS `UnderLyingCauses`
  FROM `abcantrackv2`.`incident`
  ORDER BY `abcantrackv2`.`incident`.`IncidentId` DESC;
