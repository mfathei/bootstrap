CREATE VIEW ABCanTrackV2.business_rule_view AS
  SELECT
    1 AS `id`,
    1 AS `script`,
    1 AS `properties`,
    1 AS `partnerscript`;
