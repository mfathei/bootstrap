CREATE VIEW ABCanTrackV2.inc_custom_fields_view AS
  (SELECT
     `abcantrackv2`.`incident`.`IncidentId`       AS `IncidentId`,
     `abcantrackv2`.`incident`.`IncidentNumber`   AS `IncidentNumber`,
     `abcantrackv2`.`org_field`.`FieldLabel`      AS `FieldLabel`,
     `abcantrackv2`.`field_value`.`FieldValue`    AS `FieldValue`,
     `abcantrackv2`.`field_value`.`OptionId`      AS `OptionId`,
     `abcantrackv2`.`option`.`OptionName`         AS `OptionName`,
     `abcantrackv2`.`org_field`.`IsHidden`        AS `IsHidden`,
     `abcantrackv2`.`field_value`.`FieldId`       AS `FieldId`,
     `abcantrackv2`.`field_value`.`FieldValueId`  AS `FieldValueId`,
     `abcantrackv2`.`field_value`.`TableKeyValue` AS `TableName`
   FROM (((`abcantrackv2`.`incident`
     JOIN `abcantrackv2`.`field_value`
       ON ((`abcantrackv2`.`incident`.`IncidentId` = `abcantrackv2`.`field_value`.`IncidentId`))) LEFT JOIN
     `abcantrackv2`.`option` ON ((`abcantrackv2`.`field_value`.`OptionId` = `abcantrackv2`.`option`.`OptionId`))) JOIN
     `abcantrackv2`.`org_field` ON (((`abcantrackv2`.`field_value`.`FieldId` = `abcantrackv2`.`org_field`.`FieldId`) AND
                                     (`abcantrackv2`.`org_field`.`OrgId` = `abcantrackv2`.`incident`.`OrgId`)))));
