CREATE VIEW ABCanTrackV2.county_view AS
  SELECT
    1 AS `id`,
    1 AS `county_name`,
    1 AS `prov_name`,
    1 AS `country_name`,
    1 AS `CompanyAbbrev`,
    1 AS `Properties`,
    1 AS `CountyTaxRate`;
