CREATE VIEW ABCanTrackV2.sub_observ_ana_param_view AS
  SELECT
    `oa`.`ObservationAndAnalysisId`             AS `ObservationAndAnalysisId`,
    `oa`.`ObservationAndAnalysisCode`           AS `ObservationAndAnalysisCode`,
    `oa`.`ObservationAndAnalysisName`           AS `ObservationAndAnalysisName`,
    `oa`.`ObservationAndAnalysisDetails`        AS `ObservationAndAnalysisDetails`,
    `oa`.`OrgId`                                AS `OrgId`,
    `oapc`.`ObservationAndAnalysisParamId`      AS `ObservationAndAnalysisParamId`,
    `oapc`.`ObservationAndAnalysisParamName`    AS `ObservationAndAnalysisParamName`,
    `oapc`.`ObservationAndAnalysisParamDetails` AS `ObservationAndAnalysisParamDetails`,
    `oapc`.`Order`                              AS `Order`,
    `oapc`.`IsMulti`                            AS `IsMulti`,
    `oapc`.`ParentId`                           AS `ParentId`,
    `oapc`.`LastUpdateDate`                     AS `LastUpdateDate`,
    `oapc`.`EditingBy`                          AS `EditingBy`,
    `oapc`.`Hide`                               AS `Hide`,
    `oapp`.`ObservationAndAnalysisParamName`    AS `ParentObservationAndAnalysisParamName`,
    `oapp`.`Hide`                               AS `ParentHide`
  FROM ((`abcantrackv2`.`observation_analysis` `oa`
    JOIN `abcantrackv2`.`observation_analysis_param` `oapc`
      ON ((`oa`.`ObservationAndAnalysisId` = `oapc`.`ObservationAndAnalysisId`))) JOIN
    `abcantrackv2`.`observation_analysis_param` `oapp`
      ON ((`oapc`.`ParentId` = `oapp`.`ObservationAndAnalysisParamId`)));
