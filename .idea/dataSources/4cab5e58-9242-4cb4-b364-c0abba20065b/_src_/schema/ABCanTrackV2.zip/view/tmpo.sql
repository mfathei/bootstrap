CREATE VIEW ABCanTrackV2.tmpo AS
  SELECT
    `abcantrackv2`.`hist_incident`.`HistIncidentId` AS `HistIncidentId`,
    `abcantrackv2`.`hist_incident`.`IncidentId`     AS `IncidentId`,
    `abcantrackv2`.`hist_incident`.`VersionNumber`  AS `VersionNumber`
  FROM `abcantrackv2`.`hist_incident`
  WHERE isnull(`abcantrackv2`.`hist_incident`.`UpdatedDate`);
