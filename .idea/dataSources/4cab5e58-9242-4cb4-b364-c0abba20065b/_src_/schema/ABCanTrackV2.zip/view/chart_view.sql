CREATE VIEW ABCanTrackV2.chart_view AS
  SELECT
    `tbl31`.`IncidentId`            AS `IncidentId`,
    `tbl1`.`OrgId`                  AS `OrgId`,
    `tbl31`.`IsDeleted`             AS `IsDeleted`,
    `tbl31`.`IncidentDate`          AS `IncidentDate`,
    `tbl31`.`InsuranceCost`         AS `InsuranceCost`,
    `tbl31`.`OtherCost`             AS `OtherCost`,
    `tbl31`.`RepairCost`            AS `RepairCost`,
    `tbl31`.`ResponseCost`          AS `ResponseCost`,
    `tbl31`.`TotalCost`             AS `TotalCost`,
    `tbl31`.`WCBCost`               AS `WCBCost`,
    `tbl1`.`ImpactTypeId`           AS `ImpactTypeId`,
    `tbl1`.`ImpactTypeName`         AS `ImpactTypeName`,
    `tbl3`.`ImpactSubTypeId`        AS `ImpactSubTypeId`,
    `tbl2`.`ImpactSubTypeName`      AS `ImpactSubTypeName`,
    `tbl31r`.`RiskOfRecurrenceName` AS `RiskOfRecurrenceName`,
    `tbl31s`.`IncidentSeverityName` AS `IncidentSeverityName`,
    `tbl31e`.`EventTypeName`        AS `EventTypeName`,
    `tbl31o`.`OperationTypeName`    AS `OperationTypeName`,
    `tbl31loc1`.`Location1Name`     AS `Location1Name`,
    `tbl31loc2`.`Location2Name`     AS `Location2Name`,
    `tbl31loc3`.`Location3Name`     AS `Location3Name`,
    `tbl31loc4`.`Location4Name`     AS `Location4Name`,
    `tbl31inv`.`InvStatusName`      AS `InvStatusName`,
    `tbl31e`.`EventTypeId`          AS `EventTypeId`,
    `tbl31`.`IsEmerRP`              AS `IsEmerRP`,
    `tbl31loc1`.`Location1Id`       AS `Location1Id`,
    `tbl31loc2`.`Location2Id`       AS `Location2Id`,
    `tbl31loc3`.`Location3Id`       AS `Location3Id`,
    `tbl31loc4`.`Location4Id`       AS `Location4Id`,
    `tbl31o`.`OperationTypeId`      AS `OperationTypeId`,
    `tbl31r`.`RiskOfRecurrenceId`   AS `RiskOfRecurrenceId`,
    `tbl31inv`.`InvStatusId`        AS `InvStatusId`,
    `tbl31s`.`IncidentSeverityId`   AS `IncidentSeverityId`
  FROM ((`abcantrackv2`.`impact_type` `tbl1` LEFT JOIN `abcantrackv2`.`impact_sub_type` `tbl2`
      ON ((`tbl1`.`ImpactTypeId` = `tbl2`.`ImpactTypeId`))) LEFT JOIN (`abcantrackv2`.`impact` `tbl3`
    JOIN (((((((((`abcantrackv2`.`incident` `tbl31` LEFT JOIN `abcantrackv2`.`event_type` `tbl31e`
        ON ((`tbl31e`.`EventTypeId` = `tbl31`.`EventTypeId`))) LEFT JOIN `abcantrackv2`.`operation_type` `tbl31o`
        ON ((`tbl31o`.`OperationTypeId` = `tbl31`.`OperationTypeId`))) LEFT JOIN
      `abcantrackv2`.`incident_severity` `tbl31s`
        ON ((`tbl31s`.`IncidentSeverityId` = `tbl31`.`IncidentSeverityId`))) LEFT JOIN
      `abcantrackv2`.`risk_of_recurrence` `tbl31r`
        ON ((`tbl31r`.`RiskOfRecurrenceId` = `tbl31`.`RiskOfRecurrenceId`))) LEFT JOIN
      `abcantrackv2`.`inv_status` `tbl31inv` ON ((`tbl31inv`.`InvStatusId` = `tbl31`.`InvStatusId`))) LEFT JOIN
      `abcantrackv2`.`location1` `tbl31loc1` ON ((`tbl31loc1`.`Location1Id` = `tbl31`.`Location1Id`))) LEFT JOIN
      `abcantrackv2`.`location2` `tbl31loc2` ON ((`tbl31loc2`.`Location2Id` = `tbl31`.`Location2Id`))) LEFT JOIN
      `abcantrackv2`.`location3` `tbl31loc3` ON ((`tbl31loc3`.`Location3Id` = `tbl31`.`Location3Id`))) LEFT JOIN
      `abcantrackv2`.`location4` `tbl31loc4` ON ((`tbl31loc4`.`Location4Id` = `tbl31`.`Location4Id`)))
      ON (((`tbl3`.`IncidentId` = `tbl31`.`IncidentId`) AND
           ((`tbl31`.`IsDeleted` = 0) OR isnull(`tbl31`.`IsDeleted`)))))
      ON ((`tbl2`.`ImpactSubTypeId` = `tbl3`.`ImpactSubTypeId`)))
  UNION SELECT
          `tbl31`.`IncidentId`            AS `IncidentId`,
          `tbl1`.`OrgId`                  AS `OrgId`,
          `tbl31`.`IsDeleted`             AS `IsDeleted`,
          `tbl31`.`IncidentDate`          AS `IncidentDate`,
          `tbl31`.`InsuranceCost`         AS `InsuranceCost`,
          `tbl31`.`OtherCost`             AS `OtherCost`,
          `tbl31`.`RepairCost`            AS `RepairCost`,
          `tbl31`.`ResponseCost`          AS `ResponseCost`,
          `tbl31`.`TotalCost`             AS `TotalCost`,
          `tbl31`.`WCBCost`               AS `WCBCost`,
          `tbl1`.`ImpactTypeId`           AS `ImpactTypeId`,
          `tbl1`.`ImpactTypeName`         AS `ImpactTypeName`,
          `tbl3`.`ImpactSubTypeId`        AS `ImpactSubTypeId`,
          `tbl2`.`ImpactSubTypeName`      AS `ImpactSubTypeName`,
          `tbl31r`.`RiskOfRecurrenceName` AS `RiskOfRecurrenceName`,
          `tbl31s`.`IncidentSeverityName` AS `IncidentSeverityName`,
          `tbl31e`.`EventTypeName`        AS `EventTypeName`,
          `tbl31o`.`OperationTypeName`    AS `OperationTypeName`,
          `tbl31loc1`.`Location1Name`     AS `Location1Name`,
          `tbl31loc2`.`Location2Name`     AS `Location2Name`,
          `tbl31loc3`.`Location3Name`     AS `Location3Name`,
          `tbl31loc4`.`Location4Name`     AS `Location4Name`,
          `tbl31inv`.`InvStatusName`      AS `InvStatusName`,
          `tbl31e`.`EventTypeId`          AS `EventTypeId`,
          `tbl31`.`IsEmerRP`              AS `IsEmerRP`,
          `tbl31loc1`.`Location1Id`       AS `Location1Id`,
          `tbl31loc2`.`Location2Id`       AS `Location2Id`,
          `tbl31loc3`.`Location3Id`       AS `Location3Id`,
          `tbl31loc4`.`Location4Id`       AS `Location4Id`,
          `tbl31o`.`OperationTypeId`      AS `OperationTypeId`,
          `tbl31r`.`RiskOfRecurrenceId`   AS `RiskOfRecurrenceId`,
          `tbl31inv`.`InvStatusId`        AS `InvStatusId`,
          `tbl31s`.`IncidentSeverityId`   AS `IncidentSeverityId`
        FROM ((`abcantrackv2`.`impact_type` `tbl1` LEFT JOIN `abcantrackv2`.`impact_sub_type` `tbl2`
            ON ((`tbl1`.`ImpactTypeId` = `tbl2`.`ImpactTypeId`))) LEFT JOIN (`abcantrackv2`.`illness` `tbl3`
          JOIN (((((((((`abcantrackv2`.`incident` `tbl31` LEFT JOIN `abcantrackv2`.`event_type` `tbl31e`
              ON ((`tbl31e`.`EventTypeId` = `tbl31`.`EventTypeId`))) LEFT JOIN `abcantrackv2`.`operation_type` `tbl31o`
              ON ((`tbl31o`.`OperationTypeId` = `tbl31`.`OperationTypeId`))) LEFT JOIN
            `abcantrackv2`.`incident_severity` `tbl31s`
              ON ((`tbl31s`.`IncidentSeverityId` = `tbl31`.`IncidentSeverityId`))) LEFT JOIN
            `abcantrackv2`.`risk_of_recurrence` `tbl31r`
              ON ((`tbl31r`.`RiskOfRecurrenceId` = `tbl31`.`RiskOfRecurrenceId`))) LEFT JOIN
            `abcantrackv2`.`inv_status` `tbl31inv` ON ((`tbl31inv`.`InvStatusId` = `tbl31`.`InvStatusId`))) LEFT JOIN
            `abcantrackv2`.`location1` `tbl31loc1` ON ((`tbl31loc1`.`Location1Id` = `tbl31`.`Location1Id`))) LEFT JOIN
            `abcantrackv2`.`location2` `tbl31loc2` ON ((`tbl31loc2`.`Location2Id` = `tbl31`.`Location2Id`))) LEFT JOIN
            `abcantrackv2`.`location3` `tbl31loc3` ON ((`tbl31loc3`.`Location3Id` = `tbl31`.`Location3Id`))) LEFT JOIN
            `abcantrackv2`.`location4` `tbl31loc4` ON ((`tbl31loc4`.`Location4Id` = `tbl31`.`Location4Id`)))
            ON (((`tbl3`.`IncidentId` = `tbl31`.`IncidentId`) AND
                 ((`tbl31`.`IsDeleted` = 0) OR isnull(`tbl31`.`IsDeleted`)))))
            ON ((`tbl2`.`ImpactSubTypeId` = `tbl3`.`ImpactSubTypeId`)))
  UNION SELECT
          `tbl31`.`IncidentId`            AS `IncidentId`,
          `tbl1`.`OrgId`                  AS `OrgId`,
          `tbl31`.`IsDeleted`             AS `IsDeleted`,
          `tbl31`.`IncidentDate`          AS `IncidentDate`,
          `tbl31`.`InsuranceCost`         AS `InsuranceCost`,
          `tbl31`.`OtherCost`             AS `OtherCost`,
          `tbl31`.`RepairCost`            AS `RepairCost`,
          `tbl31`.`ResponseCost`          AS `ResponseCost`,
          `tbl31`.`TotalCost`             AS `TotalCost`,
          `tbl31`.`WCBCost`               AS `WCBCost`,
          `tbl1`.`ImpactTypeId`           AS `ImpactTypeId`,
          `tbl1`.`ImpactTypeName`         AS `ImpactTypeName`,
          `tbl3`.`ImpactSubTypeId`        AS `ImpactSubTypeId`,
          `tbl2`.`ImpactSubTypeName`      AS `ImpactSubTypeName`,
          `tbl31r`.`RiskOfRecurrenceName` AS `RiskOfRecurrenceName`,
          `tbl31s`.`IncidentSeverityName` AS `IncidentSeverityName`,
          `tbl31e`.`EventTypeName`        AS `EventTypeName`,
          `tbl31o`.`OperationTypeName`    AS `OperationTypeName`,
          `tbl31loc1`.`Location1Name`     AS `Location1Name`,
          `tbl31loc2`.`Location2Name`     AS `Location2Name`,
          `tbl31loc3`.`Location3Name`     AS `Location3Name`,
          `tbl31loc4`.`Location4Name`     AS `Location4Name`,
          `tbl31inv`.`InvStatusName`      AS `InvStatusName`,
          `tbl31e`.`EventTypeId`          AS `EventTypeId`,
          `tbl31`.`IsEmerRP`              AS `IsEmerRP`,
          `tbl31loc1`.`Location1Id`       AS `Location1Id`,
          `tbl31loc2`.`Location2Id`       AS `Location2Id`,
          `tbl31loc3`.`Location3Id`       AS `Location3Id`,
          `tbl31loc4`.`Location4Id`       AS `Location4Id`,
          `tbl31o`.`OperationTypeId`      AS `OperationTypeId`,
          `tbl31r`.`RiskOfRecurrenceId`   AS `RiskOfRecurrenceId`,
          `tbl31inv`.`InvStatusId`        AS `InvStatusId`,
          `tbl31s`.`IncidentSeverityId`   AS `IncidentSeverityId`
        FROM ((`abcantrackv2`.`impact_type` `tbl1` LEFT JOIN `abcantrackv2`.`impact_sub_type` `tbl2`
            ON ((`tbl1`.`ImpactTypeId` = `tbl2`.`ImpactTypeId`))) LEFT JOIN (`abcantrackv2`.`spill_release` `tbl3`
          JOIN (((((((((`abcantrackv2`.`incident` `tbl31` LEFT JOIN `abcantrackv2`.`event_type` `tbl31e`
              ON ((`tbl31e`.`EventTypeId` = `tbl31`.`EventTypeId`))) LEFT JOIN `abcantrackv2`.`operation_type` `tbl31o`
              ON ((`tbl31o`.`OperationTypeId` = `tbl31`.`OperationTypeId`))) LEFT JOIN
            `abcantrackv2`.`incident_severity` `tbl31s`
              ON ((`tbl31s`.`IncidentSeverityId` = `tbl31`.`IncidentSeverityId`))) LEFT JOIN
            `abcantrackv2`.`risk_of_recurrence` `tbl31r`
              ON ((`tbl31r`.`RiskOfRecurrenceId` = `tbl31`.`RiskOfRecurrenceId`))) LEFT JOIN
            `abcantrackv2`.`inv_status` `tbl31inv` ON ((`tbl31inv`.`InvStatusId` = `tbl31`.`InvStatusId`))) LEFT JOIN
            `abcantrackv2`.`location1` `tbl31loc1` ON ((`tbl31loc1`.`Location1Id` = `tbl31`.`Location1Id`))) LEFT JOIN
            `abcantrackv2`.`location2` `tbl31loc2` ON ((`tbl31loc2`.`Location2Id` = `tbl31`.`Location2Id`))) LEFT JOIN
            `abcantrackv2`.`location3` `tbl31loc3` ON ((`tbl31loc3`.`Location3Id` = `tbl31`.`Location3Id`))) LEFT JOIN
            `abcantrackv2`.`location4` `tbl31loc4` ON ((`tbl31loc4`.`Location4Id` = `tbl31`.`Location4Id`)))
            ON (((`tbl3`.`IncidentId` = `tbl31`.`IncidentId`) AND
                 ((`tbl31`.`IsDeleted` = 0) OR isnull(`tbl31`.`IsDeleted`)))))
            ON ((`tbl2`.`ImpactSubTypeId` = `tbl3`.`ImpactSubTypeId`)))
  UNION SELECT
          `tbl31`.`IncidentId`            AS `IncidentId`,
          `tbl1`.`OrgId`                  AS `OrgId`,
          `tbl31`.`IsDeleted`             AS `IsDeleted`,
          `tbl31`.`IncidentDate`          AS `IncidentDate`,
          `tbl31`.`InsuranceCost`         AS `InsuranceCost`,
          `tbl31`.`OtherCost`             AS `OtherCost`,
          `tbl31`.`RepairCost`            AS `RepairCost`,
          `tbl31`.`ResponseCost`          AS `ResponseCost`,
          `tbl31`.`TotalCost`             AS `TotalCost`,
          `tbl31`.`WCBCost`               AS `WCBCost`,
          `tbl1`.`ImpactTypeId`           AS `ImpactTypeId`,
          `tbl1`.`ImpactTypeName`         AS `ImpactTypeName`,
          `tbl3`.`ImpactSubTypeId`        AS `ImpactSubTypeId`,
          `tbl2`.`ImpactSubTypeName`      AS `ImpactSubTypeName`,
          `tbl31r`.`RiskOfRecurrenceName` AS `RiskOfRecurrenceName`,
          `tbl31s`.`IncidentSeverityName` AS `IncidentSeverityName`,
          `tbl31e`.`EventTypeName`        AS `EventTypeName`,
          `tbl31o`.`OperationTypeName`    AS `OperationTypeName`,
          `tbl31loc1`.`Location1Name`     AS `Location1Name`,
          `tbl31loc2`.`Location2Name`     AS `Location2Name`,
          `tbl31loc3`.`Location3Name`     AS `Location3Name`,
          `tbl31loc4`.`Location4Name`     AS `Location4Name`,
          `tbl31inv`.`InvStatusName`      AS `InvStatusName`,
          `tbl31e`.`EventTypeId`          AS `EventTypeId`,
          `tbl31`.`IsEmerRP`              AS `IsEmerRP`,
          `tbl31loc1`.`Location1Id`       AS `Location1Id`,
          `tbl31loc2`.`Location2Id`       AS `Location2Id`,
          `tbl31loc3`.`Location3Id`       AS `Location3Id`,
          `tbl31loc4`.`Location4Id`       AS `Location4Id`,
          `tbl31o`.`OperationTypeId`      AS `OperationTypeId`,
          `tbl31r`.`RiskOfRecurrenceId`   AS `RiskOfRecurrenceId`,
          `tbl31inv`.`InvStatusId`        AS `InvStatusId`,
          `tbl31s`.`IncidentSeverityId`   AS `IncidentSeverityId`
        FROM ((`abcantrackv2`.`impact_type` `tbl1` LEFT JOIN `abcantrackv2`.`impact_sub_type` `tbl2`
            ON ((`tbl1`.`ImpactTypeId` = `tbl2`.`ImpactTypeId`))) LEFT JOIN (`abcantrackv2`.`injury` `tbl3`
          JOIN (((((((((`abcantrackv2`.`incident` `tbl31` LEFT JOIN `abcantrackv2`.`event_type` `tbl31e`
              ON ((`tbl31e`.`EventTypeId` = `tbl31`.`EventTypeId`))) LEFT JOIN `abcantrackv2`.`operation_type` `tbl31o`
              ON ((`tbl31o`.`OperationTypeId` = `tbl31`.`OperationTypeId`))) LEFT JOIN
            `abcantrackv2`.`incident_severity` `tbl31s`
              ON ((`tbl31s`.`IncidentSeverityId` = `tbl31`.`IncidentSeverityId`))) LEFT JOIN
            `abcantrackv2`.`risk_of_recurrence` `tbl31r`
              ON ((`tbl31r`.`RiskOfRecurrenceId` = `tbl31`.`RiskOfRecurrenceId`))) LEFT JOIN
            `abcantrackv2`.`inv_status` `tbl31inv` ON ((`tbl31inv`.`InvStatusId` = `tbl31`.`InvStatusId`))) LEFT JOIN
            `abcantrackv2`.`location1` `tbl31loc1` ON ((`tbl31loc1`.`Location1Id` = `tbl31`.`Location1Id`))) LEFT JOIN
            `abcantrackv2`.`location2` `tbl31loc2` ON ((`tbl31loc2`.`Location2Id` = `tbl31`.`Location2Id`))) LEFT JOIN
            `abcantrackv2`.`location3` `tbl31loc3` ON ((`tbl31loc3`.`Location3Id` = `tbl31`.`Location3Id`))) LEFT JOIN
            `abcantrackv2`.`location4` `tbl31loc4` ON ((`tbl31loc4`.`Location4Id` = `tbl31`.`Location4Id`)))
            ON (((`tbl3`.`IncidentId` = `tbl31`.`IncidentId`) AND
                 ((`tbl31`.`IsDeleted` = 0) OR isnull(`tbl31`.`IsDeleted`)))))
            ON ((`tbl2`.`ImpactSubTypeId` = `tbl3`.`ImpactSubTypeId`)))
  UNION SELECT
          `tbl31`.`IncidentId`            AS `IncidentId`,
          `tbl1`.`OrgId`                  AS `OrgId`,
          `tbl31`.`IsDeleted`             AS `IsDeleted`,
          `tbl31`.`IncidentDate`          AS `IncidentDate`,
          `tbl31`.`InsuranceCost`         AS `InsuranceCost`,
          `tbl31`.`OtherCost`             AS `OtherCost`,
          `tbl31`.`RepairCost`            AS `RepairCost`,
          `tbl31`.`ResponseCost`          AS `ResponseCost`,
          `tbl31`.`TotalCost`             AS `TotalCost`,
          `tbl31`.`WCBCost`               AS `WCBCost`,
          `tbl1`.`ImpactTypeId`           AS `ImpactTypeId`,
          `tbl1`.`ImpactTypeName`         AS `ImpactTypeName`,
          `tbl3`.`ImpactSubTypeId`        AS `ImpactSubTypeId`,
          `tbl2`.`ImpactSubTypeName`      AS `ImpactSubTypeName`,
          `tbl31r`.`RiskOfRecurrenceName` AS `RiskOfRecurrenceName`,
          `tbl31s`.`IncidentSeverityName` AS `IncidentSeverityName`,
          `tbl31e`.`EventTypeName`        AS `EventTypeName`,
          `tbl31o`.`OperationTypeName`    AS `OperationTypeName`,
          `tbl31loc1`.`Location1Name`     AS `Location1Name`,
          `tbl31loc2`.`Location2Name`     AS `Location2Name`,
          `tbl31loc3`.`Location3Name`     AS `Location3Name`,
          `tbl31loc4`.`Location4Name`     AS `Location4Name`,
          `tbl31inv`.`InvStatusName`      AS `InvStatusName`,
          `tbl31e`.`EventTypeId`          AS `EventTypeId`,
          `tbl31`.`IsEmerRP`              AS `IsEmerRP`,
          `tbl31loc1`.`Location1Id`       AS `Location1Id`,
          `tbl31loc2`.`Location2Id`       AS `Location2Id`,
          `tbl31loc3`.`Location3Id`       AS `Location3Id`,
          `tbl31loc4`.`Location4Id`       AS `Location4Id`,
          `tbl31o`.`OperationTypeId`      AS `OperationTypeId`,
          `tbl31r`.`RiskOfRecurrenceId`   AS `RiskOfRecurrenceId`,
          `tbl31inv`.`InvStatusId`        AS `InvStatusId`,
          `tbl31s`.`IncidentSeverityId`   AS `IncidentSeverityId`
        FROM ((`abcantrackv2`.`impact_type` `tbl1` LEFT JOIN `abcantrackv2`.`impact_sub_type` `tbl2`
            ON ((`tbl1`.`ImpactTypeId` = `tbl2`.`ImpactTypeId`))) LEFT JOIN (`abcantrackv2`.`vehicle_damage` `tbl3`
          JOIN (((((((((`abcantrackv2`.`incident` `tbl31` LEFT JOIN `abcantrackv2`.`event_type` `tbl31e`
              ON ((`tbl31e`.`EventTypeId` = `tbl31`.`EventTypeId`))) LEFT JOIN `abcantrackv2`.`operation_type` `tbl31o`
              ON ((`tbl31o`.`OperationTypeId` = `tbl31`.`OperationTypeId`))) LEFT JOIN
            `abcantrackv2`.`incident_severity` `tbl31s`
              ON ((`tbl31s`.`IncidentSeverityId` = `tbl31`.`IncidentSeverityId`))) LEFT JOIN
            `abcantrackv2`.`risk_of_recurrence` `tbl31r`
              ON ((`tbl31r`.`RiskOfRecurrenceId` = `tbl31`.`RiskOfRecurrenceId`))) LEFT JOIN
            `abcantrackv2`.`inv_status` `tbl31inv` ON ((`tbl31inv`.`InvStatusId` = `tbl31`.`InvStatusId`))) LEFT JOIN
            `abcantrackv2`.`location1` `tbl31loc1` ON ((`tbl31loc1`.`Location1Id` = `tbl31`.`Location1Id`))) LEFT JOIN
            `abcantrackv2`.`location2` `tbl31loc2` ON ((`tbl31loc2`.`Location2Id` = `tbl31`.`Location2Id`))) LEFT JOIN
            `abcantrackv2`.`location3` `tbl31loc3` ON ((`tbl31loc3`.`Location3Id` = `tbl31`.`Location3Id`))) LEFT JOIN
            `abcantrackv2`.`location4` `tbl31loc4` ON ((`tbl31loc4`.`Location4Id` = `tbl31`.`Location4Id`)))
            ON (((`tbl3`.`IncidentId` = `tbl31`.`IncidentId`) AND
                 ((`tbl31`.`IsDeleted` = 0) OR isnull(`tbl31`.`IsDeleted`)))))
            ON ((`tbl2`.`ImpactSubTypeId` = `tbl3`.`ImpactSubTypeId`)))
  UNION SELECT
          `tbl31`.`IncidentId`            AS `IncidentId`,
          `tbl1`.`OrgId`                  AS `OrgId`,
          `tbl31`.`IsDeleted`             AS `IsDeleted`,
          `tbl31`.`IncidentDate`          AS `IncidentDate`,
          `tbl31`.`InsuranceCost`         AS `InsuranceCost`,
          `tbl31`.`OtherCost`             AS `OtherCost`,
          `tbl31`.`RepairCost`            AS `RepairCost`,
          `tbl31`.`ResponseCost`          AS `ResponseCost`,
          `tbl31`.`TotalCost`             AS `TotalCost`,
          `tbl31`.`WCBCost`               AS `WCBCost`,
          `tbl1`.`ImpactTypeId`           AS `ImpactTypeId`,
          `tbl1`.`ImpactTypeName`         AS `ImpactTypeName`,
          `tbl3`.`ImpactSubTypeId`        AS `ImpactSubTypeId`,
          `tbl2`.`ImpactSubTypeName`      AS `ImpactSubTypeName`,
          `tbl31r`.`RiskOfRecurrenceName` AS `RiskOfRecurrenceName`,
          `tbl31s`.`IncidentSeverityName` AS `IncidentSeverityName`,
          `tbl31e`.`EventTypeName`        AS `EventTypeName`,
          `tbl31o`.`OperationTypeName`    AS `OperationTypeName`,
          `tbl31loc1`.`Location1Name`     AS `Location1Name`,
          `tbl31loc2`.`Location2Name`     AS `Location2Name`,
          `tbl31loc3`.`Location3Name`     AS `Location3Name`,
          `tbl31loc4`.`Location4Name`     AS `Location4Name`,
          `tbl31inv`.`InvStatusName`      AS `InvStatusName`,
          `tbl31e`.`EventTypeId`          AS `EventTypeId`,
          `tbl31`.`IsEmerRP`              AS `IsEmerRP`,
          `tbl31loc1`.`Location1Id`       AS `Location1Id`,
          `tbl31loc2`.`Location2Id`       AS `Location2Id`,
          `tbl31loc3`.`Location3Id`       AS `Location3Id`,
          `tbl31loc4`.`Location4Id`       AS `Location4Id`,
          `tbl31o`.`OperationTypeId`      AS `OperationTypeId`,
          `tbl31r`.`RiskOfRecurrenceId`   AS `RiskOfRecurrenceId`,
          `tbl31inv`.`InvStatusId`        AS `InvStatusId`,
          `tbl31s`.`IncidentSeverityId`   AS `IncidentSeverityId`
        FROM ((`abcantrackv2`.`impact_type` `tbl1` LEFT JOIN `abcantrackv2`.`impact_sub_type` `tbl2`
            ON ((`tbl1`.`ImpactTypeId` = `tbl2`.`ImpactTypeId`))) LEFT JOIN (`abcantrackv2`.`traffic_violation` `tbl3`
          JOIN (((((((((`abcantrackv2`.`incident` `tbl31` LEFT JOIN `abcantrackv2`.`event_type` `tbl31e`
              ON ((`tbl31e`.`EventTypeId` = `tbl31`.`EventTypeId`))) LEFT JOIN `abcantrackv2`.`operation_type` `tbl31o`
              ON ((`tbl31o`.`OperationTypeId` = `tbl31`.`OperationTypeId`))) LEFT JOIN
            `abcantrackv2`.`incident_severity` `tbl31s`
              ON ((`tbl31s`.`IncidentSeverityId` = `tbl31`.`IncidentSeverityId`))) LEFT JOIN
            `abcantrackv2`.`risk_of_recurrence` `tbl31r`
              ON ((`tbl31r`.`RiskOfRecurrenceId` = `tbl31`.`RiskOfRecurrenceId`))) LEFT JOIN
            `abcantrackv2`.`inv_status` `tbl31inv` ON ((`tbl31inv`.`InvStatusId` = `tbl31`.`InvStatusId`))) LEFT JOIN
            `abcantrackv2`.`location1` `tbl31loc1` ON ((`tbl31loc1`.`Location1Id` = `tbl31`.`Location1Id`))) LEFT JOIN
            `abcantrackv2`.`location2` `tbl31loc2` ON ((`tbl31loc2`.`Location2Id` = `tbl31`.`Location2Id`))) LEFT JOIN
            `abcantrackv2`.`location3` `tbl31loc3` ON ((`tbl31loc3`.`Location3Id` = `tbl31`.`Location3Id`))) LEFT JOIN
            `abcantrackv2`.`location4` `tbl31loc4` ON ((`tbl31loc4`.`Location4Id` = `tbl31`.`Location4Id`)))
            ON (((`tbl3`.`IncidentId` = `tbl31`.`IncidentId`) AND
                 ((`tbl31`.`IsDeleted` = 0) OR isnull(`tbl31`.`IsDeleted`)))))
            ON ((`tbl2`.`ImpactSubTypeId` = `tbl3`.`ImpactSubTypeId`)));
