CREATE VIEW ABCanTrackV2.incident_traffic_violation_view AS
  SELECT
    `abcantrackv2`.`traffic_violation`.`TrafficViolationId` AS `TrafficViolationId`,
    `abcantrackv2`.`traffic_violation`.`IncidentId`         AS `IncidentId`,
    `abcantrackv2`.`traffic_violation`.`DriverName`         AS `TrafficDriverName`,
    `abcantrackv2`.`traffic_violation`.`DriverLicence`      AS `TrafficDriverLicence`,
    `abcantrackv2`.`vehicle_type`.`VehicleTypeName`         AS `TrafficVehicleTypeId`,
    `abcantrackv2`.`traffic_violation`.`VehicleLicence`     AS `TrafficVehicleLicence`,
    `abcantrackv2`.`traffic_violation`.`Details`            AS `Details`,
    `abcantrackv2`.`traffic_violation`.`ValueOfFine`        AS `ValueOfFine`,
    `abcantrackv2`.`traffic_violation`.`TicketNumber`       AS `TicketNumber`,
    `abcantrackv2`.`traffic_violation`.`HowDidThatOccur`    AS `HowDidThatOccur`
  FROM (`abcantrackv2`.`traffic_violation`
    LEFT JOIN `abcantrackv2`.`vehicle_type`
      ON ((`abcantrackv2`.`vehicle_type`.`VehicleTypeId` = `abcantrackv2`.`traffic_violation`.`VehicleTypeId`)));
