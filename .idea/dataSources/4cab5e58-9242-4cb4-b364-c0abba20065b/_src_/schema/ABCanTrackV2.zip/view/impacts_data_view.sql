CREATE VIEW ABCanTrackV2.impacts_data_view AS
  SELECT
    `abcantrackv2`.`impact`.`ImpactSubTypeId`                 AS `ImpactSubTypeId`,
    `abcantrackv2`.`impact_type`.`ImpactTypeId`               AS `ImpactTypeId`,
    `abcantrackv2`.`impact`.`IntEmployeeId1`                  AS `IntEmployeeId1`,
    `abcantrackv2`.`impact`.`IntEmployeeId2`                  AS `IntEmployeeId2`,
    `abcantrackv2`.`impact`.`IntEmployeeId3`                  AS `IntEmployeeId3`,
    `abcantrackv2`.`impact`.`PrimRespondId`                   AS `PrimRespondId`,
    `abcantrackv2`.`impact`.`ImpactId`                        AS `ImpactId`,
    `abcantrackv2`.`hist_impact`.`OriginalImpactId`           AS `OriginalId`,
    NULL                                                      AS `PersonalInjuredId`,
    NULL                                                      AS `ContactCodeId`,
    NULL                                                      AS `RecordableId`,
    NULL                                                      AS `RestrictedWorkId`,
    NULL                                                      AS `InitialTreatmentId`,
    NULL                                                      AS `ContactAgencyId`,
    NULL                                                      AS `PersonalAfflictedId`,
    NULL                                                      AS `SourceId`,
    NULL                                                      AS `DurationUnitId`,
    NULL                                                      AS `QuantityUnitId`,
    NULL                                                      AS `RecoveredUnitId`,
    NULL                                                      AS `Reportable`,
    `abcantrackv2`.`impact`.`IncidentId`                      AS `IncidentId`,
    `abcantrackv2`.`impact_type`.`ImpactTypeName`             AS `ImpactTypeName`,
    `abcantrackv2`.`impact_type`.`ImpactTypeCode`             AS `ImpactTypeCode`,
    `abcantrackv2`.`impact_sub_type`.`ImpactSubTypeName`      AS `ImpactSubTypeName`,
    `abcantrackv2`.`impact`.`IntEmployeeName1`                AS `IntEmployeeName1`,
    `abcantrackv2`.`impact`.`IntEmployeeName2`                AS `IntEmployeeName2`,
    `abcantrackv2`.`impact`.`IntEmployeeName3`                AS `IntEmployeeName3`,
    `abcantrackv2`.`impact`.`IntEmployeeDept1`                AS `IntEmployeeDept1`,
    `abcantrackv2`.`impact`.`IntEmployeeDept2`                AS `IntEmployeeDept2`,
    `abcantrackv2`.`impact`.`IntEmployeeDept3`                AS `IntEmployeeDept3`,
    `abcantrackv2`.`impact`.`PrimRespondName`                 AS `PrimRespondName`,
    `abcantrackv2`.`impact`.`Description`                     AS `Description`,
    `abcantrackv2`.`hist_impact`.`OldImpactDescription`       AS `OldImpactDescription`,
    `abcantrackv2`.`impact`.`EstimatedCost`                   AS `EstimatedCost`,
    concat(`abcantrackv2`.`impact`.`ImpactId`, '_', `abcantrackv2`.`impact`.`IncidentId`, '_',
           `abcantrackv2`.`impact_type`.`ImpactTypeCode`)     AS `Identification`,
    (SELECT group_concat(DISTINCT `abcantrackv2`.`external_agency`.`ExtAgencyName` SEPARATOR ', ')
     FROM (`abcantrackv2`.`impacts_ext_agency`
       JOIN `abcantrackv2`.`external_agency`
         ON ((`abcantrackv2`.`external_agency`.`ExtAgencyId` = `abcantrackv2`.`impacts_ext_agency`.`ExtAgencyId`)))
     WHERE (`abcantrackv2`.`impacts_ext_agency`.`ImpactId` = `abcantrackv2`.`impact`.`ImpactId`)
     GROUP BY `abcantrackv2`.`impacts_ext_agency`.`ImpactId`) AS `ExtAgencyName`,
    NULL                                                      AS `PersonalInjuredName`,
    NULL                                                      AS `InitialTreatmentName`,
    NULL                                                      AS `ContactCodeName`,
    NULL                                                      AS `RecordableName`,
    NULL                                                      AS `RestrictedWorkName`,
    NULL                                                      AS `LostTimeStart`,
    NULL                                                      AS `LostTimeEnd`,
    NULL                                                      AS `AdjustmentDays`,
    NULL                                                      AS `TotalDaysOff`,
    NULL                                                      AS `ImpactTypeDescription`,
    NULL                                                      AS `OldImpactTypeDescription`,
    NULL                                                      AS `ContactAgencyName`,
    NULL                                                      AS `PersonalAfflictedName`,
    NULL                                                      AS `SourceName`,
    NULL                                                      AS `DurationValue`,
    NULL                                                      AS `DurationUnitName`,
    NULL                                                      AS `QuantityValue`,
    NULL                                                      AS `QuantityUnitName`,
    NULL                                                      AS `QuantityRecoveredValue`,
    NULL                                                      AS `RecoveredUnitName`,
    NULL                                                      AS `WhatWasIt`,
    NULL                                                      AS `HowDidSROccur`,
    NULL                                                      AS `IsReportable`,
    NULL                                                      AS `SpRelAgencyName`,
    NULL                                                      AS `DriverName`,
    NULL                                                      AS `DriverLicence`,
    NULL                                                      AS `VehicleTypeName`,
    NULL                                                      AS `VehicleLicence`,
    NULL                                                      AS `HowDidThatDone`,
    NULL                                                      AS `Details`,
    NULL                                                      AS `ValueOfFine`,
    NULL                                                      AS `TicketNumber`,
    NULL                                                      AS `HowDidThatOccur`,
    NULL                                                      AS `InjuryTypeName`,
    NULL                                                      AS `BodyPartName`,
    NULL                                                      AS `BodyAreaName`,
    NULL                                                      AS `VehicleTypeId`,
    NULL                                                      AS `OldHowDidThatOccur`,
    NULL                                                      AS `OldDetails`,
    NULL                                                      AS `SymptomsName`,
    NULL                                                      AS `OldWhatWasIt`,
    NULL                                                      AS `OldHowDidSROccur`,
    NULL                                                      AS `OldHowDidThatDone`,
    NULL                                                      AS `OldDamageDescription`
  FROM (((`abcantrackv2`.`impact`
    JOIN `abcantrackv2`.`impact_sub_type`
      ON ((`abcantrackv2`.`impact_sub_type`.`ImpactSubTypeId` = `abcantrackv2`.`impact`.`ImpactSubTypeId`))) JOIN
    `abcantrackv2`.`impact_type`
      ON ((`abcantrackv2`.`impact_sub_type`.`ImpactTypeId` = `abcantrackv2`.`impact_type`.`ImpactTypeId`))) JOIN
    `abcantrackv2`.`hist_impact` ON ((`abcantrackv2`.`hist_impact`.`ImpactId` = `abcantrackv2`.`impact`.`ImpactId`)))
  UNION SELECT
          `abcantrackv2`.`injury`.`ImpactSubTypeId`                                                       AS `ImpactSubTypeId`,
          `abcantrackv2`.`impact_type`.`ImpactTypeId`                                                     AS `ImpactTypeId`,
          `abcantrackv2`.`injury`.`IntEmployeeId1`                                                        AS `IntEmployeeId1`,
          `abcantrackv2`.`injury`.`IntEmployeeId2`                                                        AS `IntEmployeeId2`,
          `abcantrackv2`.`injury`.`IntEmployeeId3`                                                        AS `IntEmployeeId3`,
          `abcantrackv2`.`injury`.`PrimRespondId`                                                         AS `PrimRespondId`,
          `abcantrackv2`.`injury`.`InjuryId`                                                              AS `ImpactId`,
          `abcantrackv2`.`hist_injury`.`OriginalInjuryId`                                                 AS `OriginalId`,
          `abcantrackv2`.`injury`.`PersonalInjuredId`                                                     AS `PersonalInjuredId`,
          `abcantrackv2`.`injury`.`ContactCodeId`                                                         AS `ContactCodeId`,
          `abcantrackv2`.`injury`.`RecordableId`                                                          AS `RecordableId`,
          `abcantrackv2`.`injury`.`RestrictedWorkId`                                                      AS `RestrictedWorkId`,
          `abcantrackv2`.`injury`.`InitialTreatmentId`                                                    AS `InitialTreatmentId`,
          `abcantrackv2`.`injury`.`ContactAgencyId`                                                       AS `ContactAgencyId`,
          NULL                                                                                            AS `PersonalAfflictedId`,
          NULL                                                                                            AS `SourceId`,
          NULL                                                                                            AS `DurationUnitId`,
          NULL                                                                                            AS `QuantityUnitId`,
          NULL                                                                                            AS `RecoveredUnitId`,
          NULL                                                                                            AS `Reportable`,
          `abcantrackv2`.`injury`.`IncidentId`                                                            AS `IncidentId`,
          `abcantrackv2`.`impact_type`.`ImpactTypeName`                                                   AS `ImpactTypeName`,
          `abcantrackv2`.`impact_type`.`ImpactTypeCode`                                                   AS `ImpactTypeCode`,
          `abcantrackv2`.`impact_sub_type`.`ImpactSubTypeName`                                            AS `ImpactSubTypeName`,
          `abcantrackv2`.`injury`.`IntEmployeeName1`                                                      AS `IntEmployeeName1`,
          `abcantrackv2`.`injury`.`IntEmployeeName2`                                                      AS `IntEmployeeName2`,
          `abcantrackv2`.`injury`.`IntEmployeeName3`                                                      AS `IntEmployeeName3`,
          `abcantrackv2`.`injury`.`IntEmployeeDept1`                                                      AS `IntEmployeeDept1`,
          `abcantrackv2`.`injury`.`IntEmployeeDept2`                                                      AS `IntEmployeeDept2`,
          `abcantrackv2`.`injury`.`IntEmployeeDept3`                                                      AS `IntEmployeeDept3`,
          `abcantrackv2`.`injury`.`PrimRespondName`                                                       AS `PrimRespondName`,
          `abcantrackv2`.`injury`.`Description`                                                           AS `Description`,
          `abcantrackv2`.`hist_injury`.`OldImpactDescription`                                             AS `OldImpactDescription`,
          `abcantrackv2`.`injury`.`EstimatedCost`                                                         AS `EstimatedCost`,
          concat(`abcantrackv2`.`injury`.`InjuryId`, '_', `abcantrackv2`.`injury`.`IncidentId`, '_',
                 `abcantrackv2`.`impact_type`.`ImpactTypeCode`)                                           AS `Identification`,
          (SELECT group_concat(DISTINCT `abcantrackv2`.`external_agency`.`ExtAgencyName` SEPARATOR ', ')
           FROM (`abcantrackv2`.`impacts_ext_agency`
             JOIN `abcantrackv2`.`external_agency` ON ((`abcantrackv2`.`external_agency`.`ExtAgencyId` =
                                                        `abcantrackv2`.`impacts_ext_agency`.`ExtAgencyId`)))
           WHERE (`abcantrackv2`.`impacts_ext_agency`.`InjuryId` = `abcantrackv2`.`injury`.`InjuryId`)
           GROUP BY
             `abcantrackv2`.`impacts_ext_agency`.`InjuryId`)                                              AS `ExtAgencyName`,
          `abcantrackv2`.`injury`.`PersonalInjuredName`                                                   AS `PersonalInjuredName`,
          `abcantrackv2`.`initial_treatment`.`InitialTreatmentName`                                       AS `InitialTreatmentName`,
          `abcantrackv2`.`contact_code`.`ContactCodeName`                                                 AS `ContactCodeName`,
          `abcantrackv2`.`injury_recordable`.`RecordableName`                                             AS `RecordableName`,
          `abcantrackv2`.`restricted_work`.`RestrictedWorkName`                                           AS `RestrictedWorkName`,
          date_format(`abcantrackv2`.`injury`.`LostTimeStart`,
                      '%m/%d/%Y')                                                                         AS `LostTimeStart`,
          date_format(`abcantrackv2`.`injury`.`LostTimeEnd`,
                      '%m/%d/%Y')                                                                         AS `LostTimeEnd`,
          `abcantrackv2`.`injury`.`AdjustmentDays`                                                        AS `AdjustmentDays`,
          `abcantrackv2`.`injury`.`TotalDaysOff`                                                          AS `TotalDaysOff`,
          `abcantrackv2`.`injury`.`InjuryDescription`                                                     AS `ImpactTypeDescription`,
          `abcantrackv2`.`hist_injury`.`OldInjuryDescription`                                             AS `OldImpactTypeDescription`,
          `abcantrackv2`.`contact_agency`.`ContactAgencyName`                                             AS `ContactAgencyName`,
          NULL                                                                                            AS `PersonalAfflictedName`,
          NULL                                                                                            AS `SourceName`,
          NULL                                                                                            AS `DurationValue`,
          NULL                                                                                            AS `DurationUnitName`,
          NULL                                                                                            AS `QuantityValue`,
          NULL                                                                                            AS `QuantityUnitName`,
          NULL                                                                                            AS `QuantityRecoveredValue`,
          NULL                                                                                            AS `RecoveredUnitName`,
          NULL                                                                                            AS `WhatWasIt`,
          NULL                                                                                            AS `HowDidSROccur`,
          NULL                                                                                            AS `IsReportable`,
          NULL                                                                                            AS `SpRelAgencyName`,
          NULL                                                                                            AS `DriverName`,
          NULL                                                                                            AS `DriverLicence`,
          NULL                                                                                            AS `VehicleTypeName`,
          NULL                                                                                            AS `VehicleLicence`,
          NULL                                                                                            AS `HowDidThatDone`,
          NULL                                                                                            AS `Details`,
          NULL                                                                                            AS `ValueOfFine`,
          NULL                                                                                            AS `TicketNumber`,
          NULL                                                                                            AS `HowDidThatOccur`,
          (SELECT group_concat(`abcantrackv2`.`injury_type`.`InjuryTypeName` SEPARATOR ' ; ')
           FROM `abcantrackv2`.`injury_type`
           WHERE
             `abcantrackv2`.`injury_type`.`InjuryTypeId` IN (SELECT `abcantrackv2`.`injury_type_injury`.`InjuryTypeId`
                                                             FROM `abcantrackv2`.`injury_type_injury`
                                                             WHERE (`abcantrackv2`.`injury_type_injury`.`InjuryId` =
                                                                    `abcantrackv2`.`injury`.`InjuryId`))) AS `InjuryTypeName`,
          (SELECT group_concat(`abcantrackv2`.`body_part`.`BodyPartName` SEPARATOR ' ; ')
           FROM `abcantrackv2`.`body_part`
           WHERE `abcantrackv2`.`body_part`.`BodyPartId` IN (SELECT `abcantrackv2`.`body_part_injury`.`BodyPartId`
                                                             FROM `abcantrackv2`.`body_part_injury`
                                                             WHERE (`abcantrackv2`.`body_part_injury`.`InjuryId` =
                                                                    `abcantrackv2`.`injury`.`InjuryId`))) AS `BodyPartName`,
          (SELECT group_concat(`abcantrackv2`.`body_area`.`BodyAreaName` SEPARATOR ' ; ')
           FROM `abcantrackv2`.`body_area`
           WHERE `abcantrackv2`.`body_area`.`BodyAreaId` IN (SELECT `abcantrackv2`.`body_area_injury`.`BodyAreaId`
                                                             FROM `abcantrackv2`.`body_area_injury`
                                                             WHERE (`abcantrackv2`.`body_area_injury`.`InjuryId` =
                                                                    `abcantrackv2`.`injury`.`InjuryId`))) AS `BodyAreaName`,
          NULL                                                                                            AS `VehicleTypeId`,
          NULL                                                                                            AS `OldHowDidThatOccur`,
          NULL                                                                                            AS `OldDetails`,
          NULL                                                                                            AS `SymptomsName`,
          NULL                                                                                            AS `OldWhatWasIt`,
          NULL                                                                                            AS `OldHowDidSROccur`,
          NULL                                                                                            AS `OldHowDidThatDone`,
          NULL                                                                                            AS `OldDamageDescription`
        FROM ((((((((`abcantrackv2`.`injury`
          JOIN `abcantrackv2`.`impact_sub_type`
            ON ((`abcantrackv2`.`impact_sub_type`.`ImpactSubTypeId` = `abcantrackv2`.`injury`.`ImpactSubTypeId`))) JOIN
          `abcantrackv2`.`impact_type` ON ((`abcantrackv2`.`impact_sub_type`.`ImpactTypeId` =
                                            `abcantrackv2`.`impact_type`.`ImpactTypeId`))) LEFT JOIN
          `abcantrackv2`.`initial_treatment` ON ((`abcantrackv2`.`injury`.`InitialTreatmentId` =
                                                  `abcantrackv2`.`initial_treatment`.`InitialTreatmentId`))) LEFT JOIN
          `abcantrackv2`.`contact_code`
            ON ((`abcantrackv2`.`injury`.`ContactCodeId` = `abcantrackv2`.`contact_code`.`ContactCodeId`))) LEFT JOIN
          `abcantrackv2`.`injury_recordable`
            ON ((`abcantrackv2`.`injury`.`RecordableId` = `abcantrackv2`.`injury_recordable`.`RecordableId`))) LEFT JOIN
          `abcantrackv2`.`restricted_work` ON ((`abcantrackv2`.`injury`.`RestrictedWorkId` =
                                                `abcantrackv2`.`restricted_work`.`RestrictedWorkId`))) LEFT JOIN
          `abcantrackv2`.`contact_agency`
            ON ((`abcantrackv2`.`injury`.`ContactAgencyId` = `abcantrackv2`.`contact_agency`.`ContactAgencyId`))) JOIN
          `abcantrackv2`.`hist_injury`
            ON ((`abcantrackv2`.`hist_injury`.`InjuryId` = `abcantrackv2`.`injury`.`InjuryId`)))
  UNION SELECT
          `abcantrackv2`.`illness`.`ImpactSubTypeId`                                                       AS `ImpactSubTypeId`,
          `abcantrackv2`.`impact_type`.`ImpactTypeId`                                                      AS `ImpactTypeId`,
          `abcantrackv2`.`illness`.`IntEmployeeId1`                                                        AS `IntEmployeeId1`,
          `abcantrackv2`.`illness`.`IntEmployeeId2`                                                        AS `IntEmployeeId2`,
          `abcantrackv2`.`illness`.`IntEmployeeId3`                                                        AS `IntEmployeeId3`,
          `abcantrackv2`.`illness`.`PrimRespondId`                                                         AS `PrimRespondId`,
          `abcantrackv2`.`illness`.`IllnessId`                                                             AS `ImpactId`,
          `abcantrackv2`.`hist_illness`.`OriginalIllnessId`                                                AS `OriginalId`,
          NULL                                                                                             AS `PersonalInjuredId`,
          NULL                                                                                             AS `ContactCodeId`,
          NULL                                                                                             AS `RecordableId`,
          `abcantrackv2`.`illness`.`RestrictedWorkId`                                                      AS `RestrictedWorkId`,
          `abcantrackv2`.`illness`.`InitialTreatmentId`                                                    AS `InitialTreatmentId`,
          NULL                                                                                             AS `ContactAgencyId`,
          `abcantrackv2`.`illness`.`PersonalAfflictedId`                                                   AS `PersonalAfflictedId`,
          NULL                                                                                             AS `SourceId`,
          NULL                                                                                             AS `DurationUnitId`,
          NULL                                                                                             AS `QuantityUnitId`,
          NULL                                                                                             AS `RecoveredUnitId`,
          NULL                                                                                             AS `Reportable`,
          `abcantrackv2`.`illness`.`IncidentId`                                                            AS `IncidentId`,
          `abcantrackv2`.`impact_type`.`ImpactTypeName`                                                    AS `ImpactTypeName`,
          `abcantrackv2`.`impact_type`.`ImpactTypeCode`                                                    AS `ImpactTypeCode`,
          `abcantrackv2`.`impact_sub_type`.`ImpactSubTypeName`                                             AS `ImpactSubTypeName`,
          `abcantrackv2`.`illness`.`IntEmployeeName1`                                                      AS `IntEmployeeName1`,
          `abcantrackv2`.`illness`.`IntEmployeeName2`                                                      AS `IntEmployeeName2`,
          `abcantrackv2`.`illness`.`IntEmployeeName3`                                                      AS `IntEmployeeName3`,
          `abcantrackv2`.`illness`.`IntEmployeeDept1`                                                      AS `IntEmployeeDept1`,
          `abcantrackv2`.`illness`.`IntEmployeeDept2`                                                      AS `IntEmployeeDept2`,
          `abcantrackv2`.`illness`.`IntEmployeeDept3`                                                      AS `IntEmployeeDept3`,
          `abcantrackv2`.`illness`.`PrimRespondName`                                                       AS `PrimRespondName`,
          `abcantrackv2`.`illness`.`Description`                                                           AS `Description`,
          `abcantrackv2`.`hist_illness`.`OldImpactDescription`                                             AS `OldImpactDescription`,
          `abcantrackv2`.`illness`.`EstimatedCost`                                                         AS `EstimatedCost`,
          concat(`abcantrackv2`.`illness`.`IllnessId`, '_', `abcantrackv2`.`illness`.`IncidentId`, '_',
                 `abcantrackv2`.`impact_type`.`ImpactTypeCode`)                                            AS `Identification`,
          (SELECT group_concat(DISTINCT `abcantrackv2`.`external_agency`.`ExtAgencyName` SEPARATOR ', ')
           FROM (`abcantrackv2`.`impacts_ext_agency`
             JOIN `abcantrackv2`.`external_agency` ON ((`abcantrackv2`.`external_agency`.`ExtAgencyId` =
                                                        `abcantrackv2`.`impacts_ext_agency`.`ExtAgencyId`)))
           WHERE (`abcantrackv2`.`impacts_ext_agency`.`IllnessId` = `abcantrackv2`.`illness`.`IllnessId`)
           GROUP BY
             `abcantrackv2`.`impacts_ext_agency`.`IllnessId`)                                              AS `ExtAgencyName`,
          NULL                                                                                             AS `PersonalInjuredName`,
          `abcantrackv2`.`initial_treatment`.`InitialTreatmentName`                                        AS `InitialTreatmentName`,
          NULL                                                                                             AS `ContactCodeName`,
          NULL                                                                                             AS `RecordableName`,
          `abcantrackv2`.`restricted_work`.`RestrictedWorkName`                                            AS `RestrictedWorkName`,
          date_format(`abcantrackv2`.`illness`.`LostTimeStart`,
                      '%m/%d/%Y')                                                                          AS `LostTimeStart`,
          date_format(`abcantrackv2`.`illness`.`LostTimeEnd`,
                      '%m/%d/%Y')                                                                          AS `LostTimeEnd`,
          `abcantrackv2`.`illness`.`AdjustmentDays`                                                        AS `AdjustmentDays`,
          `abcantrackv2`.`illness`.`TotalDaysOff`                                                          AS `TotalDaysOff`,
          `abcantrackv2`.`illness`.`IllnessDescription`                                                    AS `ImpactTypeDescription`,
          `abcantrackv2`.`hist_illness`.`OldIllnessDescription`                                            AS `OldImpactTypeDescription`,
          NULL                                                                                             AS `ContactAgencyName`,
          `abcantrackv2`.`illness`.`PersonalAfflictedName`                                                 AS `PersonalAfflictedName`,
          NULL                                                                                             AS `SourceName`,
          NULL                                                                                             AS `DurationValue`,
          NULL                                                                                             AS `DurationUnitName`,
          NULL                                                                                             AS `QuantityValue`,
          NULL                                                                                             AS `QuantityUnitName`,
          NULL                                                                                             AS `QuantityRecoveredValue`,
          NULL                                                                                             AS `RecoveredUnitName`,
          NULL                                                                                             AS `WhatWasIt`,
          NULL                                                                                             AS `HowDidSROccur`,
          NULL                                                                                             AS `IsReportable`,
          NULL                                                                                             AS `SpRelAgencyName`,
          NULL                                                                                             AS `DriverName`,
          NULL                                                                                             AS `DriverLicence`,
          NULL                                                                                             AS `VehicleTypeName`,
          NULL                                                                                             AS `VehicleLicence`,
          NULL                                                                                             AS `HowDidThatDone`,
          NULL                                                                                             AS `Details`,
          NULL                                                                                             AS `ValueOfFine`,
          NULL                                                                                             AS `TicketNumber`,
          NULL                                                                                             AS `HowDidThatOccur`,
          NULL                                                                                             AS `InjuryTypeName`,
          NULL                                                                                             AS `BodyPartName`,
          NULL                                                                                             AS `BodyAreaName`,
          NULL                                                                                             AS `VehicleTypeId`,
          NULL                                                                                             AS `OldHowDidThatOccur`,
          NULL                                                                                             AS `OldDetails`,
          (SELECT group_concat(`abcantrackv2`.`symptoms`.`Description` SEPARATOR ' ; ')
           FROM `abcantrackv2`.`symptoms`
           WHERE `abcantrackv2`.`symptoms`.`SymptomsId` IN (SELECT `abcantrackv2`.`illness_symptoms`.`SymptomsId`
                                                            FROM `abcantrackv2`.`illness_symptoms`
                                                            WHERE (`abcantrackv2`.`illness_symptoms`.`IllnessId` =
                                                                   `abcantrackv2`.`illness`.`IllnessId`))) AS `SymptomsName`,
          NULL                                                                                             AS `OldWhatWasIt`,
          NULL                                                                                             AS `OldHowDidSROccur`,
          NULL                                                                                             AS `OldHowDidThatDone`,
          NULL                                                                                             AS `OldDamageDescription`
        FROM (((((`abcantrackv2`.`illness`
          JOIN `abcantrackv2`.`impact_sub_type`
            ON ((`abcantrackv2`.`impact_sub_type`.`ImpactSubTypeId` = `abcantrackv2`.`illness`.`ImpactSubTypeId`))) JOIN
          `abcantrackv2`.`impact_type` ON ((`abcantrackv2`.`impact_sub_type`.`ImpactTypeId` =
                                            `abcantrackv2`.`impact_type`.`ImpactTypeId`))) LEFT JOIN
          `abcantrackv2`.`restricted_work` ON ((`abcantrackv2`.`illness`.`RestrictedWorkId` =
                                                `abcantrackv2`.`restricted_work`.`RestrictedWorkId`))) LEFT JOIN
          `abcantrackv2`.`initial_treatment` ON ((`abcantrackv2`.`illness`.`InitialTreatmentId` =
                                                  `abcantrackv2`.`initial_treatment`.`InitialTreatmentId`))) JOIN
          `abcantrackv2`.`hist_illness`
            ON ((`abcantrackv2`.`hist_illness`.`IllnessId` = `abcantrackv2`.`illness`.`IllnessId`)))
  UNION SELECT
          `abcantrackv2`.`spill_release`.`ImpactSubTypeId`                AS `ImpactSubTypeId`,
          `abcantrackv2`.`impact_type`.`ImpactTypeId`                     AS `ImpactTypeId`,
          `abcantrackv2`.`spill_release`.`IntEmployeeId1`                 AS `IntEmployeeId1`,
          `abcantrackv2`.`spill_release`.`IntEmployeeId2`                 AS `IntEmployeeId2`,
          `abcantrackv2`.`spill_release`.`IntEmployeeId3`                 AS `IntEmployeeId3`,
          `abcantrackv2`.`spill_release`.`PrimRespondId`                  AS `PrimRespondId`,
          `abcantrackv2`.`spill_release`.`SpillReleaseId`                 AS `ImpactId`,
          `abcantrackv2`.`hist_spill_release`.`OriginalSpillReleaseId`    AS `OriginalId`,
          NULL                                                            AS `PersonalInjuredId`,
          NULL                                                            AS `ContactCodeId`,
          NULL                                                            AS `RecordableId`,
          NULL                                                            AS `RestrictedWorkId`,
          NULL                                                            AS `InitialTreatmentId`,
          NULL                                                            AS `ContactAgencyId`,
          NULL                                                            AS `PersonalAfflictedId`,
          `abcantrackv2`.`spill_release`.`SourceId`                       AS `SourceId`,
          `abcantrackv2`.`spill_release`.`DurationUnitId`                 AS `DurationUnitId`,
          `abcantrackv2`.`spill_release`.`QuantityUnitId`                 AS `QuantityUnitId`,
          `abcantrackv2`.`spill_release`.`RecoveredUnitId`                AS `RecoveredUnitId`,
          (CASE `abcantrackv2`.`spill_release`.`IsReportable`
           WHEN '0'
             THEN 'false'
           WHEN '1'
             THEN 'true' END)                                             AS `Reportable`,
          `abcantrackv2`.`spill_release`.`IncidentId`                     AS `IncidentId`,
          `abcantrackv2`.`impact_type`.`ImpactTypeName`                   AS `ImpactTypeName`,
          `abcantrackv2`.`impact_type`.`ImpactTypeCode`                   AS `ImpactTypeCode`,
          `abcantrackv2`.`impact_sub_type`.`ImpactSubTypeName`            AS `ImpactSubTypeName`,
          `abcantrackv2`.`spill_release`.`IntEmployeeName1`               AS `IntEmployeeName1`,
          `abcantrackv2`.`spill_release`.`IntEmployeeName2`               AS `IntEmployeeName2`,
          `abcantrackv2`.`spill_release`.`IntEmployeeName3`               AS `IntEmployeeName3`,
          `abcantrackv2`.`spill_release`.`IntEmployeeDept1`               AS `IntEmployeeDept1`,
          `abcantrackv2`.`spill_release`.`IntEmployeeDept2`               AS `IntEmployeeDept2`,
          `abcantrackv2`.`spill_release`.`IntEmployeeDept3`               AS `IntEmployeeDept3`,
          `abcantrackv2`.`spill_release`.`PrimRespondName`                AS `PrimRespondName`,
          `abcantrackv2`.`spill_release`.`Description`                    AS `Description`,
          `abcantrackv2`.`hist_spill_release`.`OldImpactDescription`      AS `OldImpactDescription`,
          `abcantrackv2`.`spill_release`.`EstimatedCost`                  AS `EstimatedCost`,
          concat(`abcantrackv2`.`spill_release`.`SpillReleaseId`, '_', `abcantrackv2`.`spill_release`.`IncidentId`, '_',
                 `abcantrackv2`.`impact_type`.`ImpactTypeCode`)           AS `Identification`,
          (SELECT group_concat(DISTINCT `abcantrackv2`.`external_agency`.`ExtAgencyName` SEPARATOR ', ')
           FROM (`abcantrackv2`.`impacts_ext_agency`
             JOIN `abcantrackv2`.`external_agency` ON ((`abcantrackv2`.`external_agency`.`ExtAgencyId` =
                                                        `abcantrackv2`.`impacts_ext_agency`.`ExtAgencyId`)))
           WHERE
             (`abcantrackv2`.`impacts_ext_agency`.`SpillReleaseId` = `abcantrackv2`.`spill_release`.`SpillReleaseId`)
           GROUP BY `abcantrackv2`.`impacts_ext_agency`.`SpillReleaseId`) AS `ExtAgencyName`,
          NULL                                                            AS `PersonalInjuredName`,
          NULL                                                            AS `InitialTreatmentName`,
          NULL                                                            AS `ContactCodeName`,
          NULL                                                            AS `RecordableName`,
          NULL                                                            AS `RestrictedWorkName`,
          NULL                                                            AS `LostTimeStart`,
          NULL                                                            AS `LostTimeEnd`,
          NULL                                                            AS `AdjustmentDays`,
          NULL                                                            AS `TotalDaysOff`,
          NULL                                                            AS `ImpactTypeDescription`,
          NULL                                                            AS `OldImpactTypeDescription`,
          NULL                                                            AS `ContactAgencyName`,
          NULL                                                            AS `PersonalAfflictedName`,
          `abcantrackv2`.`spill_release_source`.`SourceName`              AS `SourceName`,
          `abcantrackv2`.`spill_release`.`DurationValue`                  AS `DurationValue`,
          `abcantrackv2`.`duration_unit`.`DurationUnitName`               AS `DurationUnitName`,
          `abcantrackv2`.`spill_release`.`QuantityValue`                  AS `QuantityValue`,
          `abcantrackv2`.`quantity_unit`.`QuantityUnitName`               AS `QuantityUnitName`,
          `abcantrackv2`.`spill_release`.`QuantityRecoveredValue`         AS `QuantityRecoveredValue`,
          `qtu1`.`QuantityUnitName`                                       AS `RecoveredUnitName`,
          `abcantrackv2`.`spill_release`.`WhatWasIt`                      AS `WhatWasIt`,
          `abcantrackv2`.`spill_release`.`HowDidSROccur`                  AS `HowDidSROccur`,
          (CASE `abcantrackv2`.`spill_release`.`IsReportable`
           WHEN '0'
             THEN '0'
           WHEN '1'
             THEN '1' END)                                                AS `IsReportable`,
          `abcantrackv2`.`sp_rel_agency`.`SpRelAgencyName`                AS `SpRelAgencyName`,
          NULL                                                            AS `DriverName`,
          NULL                                                            AS `DriverLicence`,
          NULL                                                            AS `VehicleTypeName`,
          NULL                                                            AS `VehicleLicence`,
          NULL                                                            AS `HowDidThatDone`,
          NULL                                                            AS `Details`,
          NULL                                                            AS `ValueOfFine`,
          NULL                                                            AS `TicketNumber`,
          NULL                                                            AS `HowDidThatOccur`,
          NULL                                                            AS `InjuryTypeName`,
          NULL                                                            AS `BodyPartName`,
          NULL                                                            AS `BodyAreaName`,
          NULL                                                            AS `VehicleTypeId`,
          NULL                                                            AS `OldHowDidThatOccur`,
          NULL                                                            AS `OldDetails`,
          NULL                                                            AS `SymptomsName`,
          `abcantrackv2`.`hist_spill_release`.`OldWhatWasIt`              AS `OldWhatWasIt`,
          `abcantrackv2`.`hist_spill_release`.`OldHowDidSROccur`          AS `OldHowDidSROccur`,
          NULL                                                            AS `OldHowDidThatDone`,
          NULL                                                            AS `OldDamageDescription`
        FROM ((((((((`abcantrackv2`.`spill_release`
          JOIN `abcantrackv2`.`impact_sub_type` ON ((`abcantrackv2`.`impact_sub_type`.`ImpactSubTypeId` =
                                                     `abcantrackv2`.`spill_release`.`ImpactSubTypeId`))) JOIN
          `abcantrackv2`.`impact_type` ON ((`abcantrackv2`.`impact_sub_type`.`ImpactTypeId` =
                                            `abcantrackv2`.`impact_type`.`ImpactTypeId`))) LEFT JOIN
          `abcantrackv2`.`spill_release_source` ON ((`abcantrackv2`.`spill_release`.`SourceId` =
                                                     `abcantrackv2`.`spill_release_source`.`SourceId`))) LEFT JOIN
          `abcantrackv2`.`duration_unit` ON ((`abcantrackv2`.`spill_release`.`DurationUnitId` =
                                              `abcantrackv2`.`duration_unit`.`DurationUnitId`))) LEFT JOIN
          `abcantrackv2`.`quantity_unit` ON ((`abcantrackv2`.`spill_release`.`QuantityUnitId` =
                                              `abcantrackv2`.`quantity_unit`.`QuantityUnitId`))) LEFT JOIN
          `abcantrackv2`.`quantity_unit` `qtu1`
            ON ((`abcantrackv2`.`spill_release`.`QuantityUnitId` = `qtu1`.`QuantityUnitId`))) LEFT JOIN
          `abcantrackv2`.`sp_rel_agency`
            ON ((`abcantrackv2`.`spill_release`.`SpRelAgencyId` = `abcantrackv2`.`sp_rel_agency`.`SpRelAgencyId`))) JOIN
          `abcantrackv2`.`hist_spill_release` ON ((`abcantrackv2`.`hist_spill_release`.`SpillReleaseId` =
                                                   `abcantrackv2`.`spill_release`.`SpillReleaseId`)))
  UNION SELECT
          `abcantrackv2`.`vehicle_damage`.`ImpactSubTypeId`                AS `ImpactSubTypeId`,
          `abcantrackv2`.`impact_type`.`ImpactTypeId`                      AS `ImpactTypeId`,
          `abcantrackv2`.`vehicle_damage`.`IntEmployeeId1`                 AS `IntEmployeeId1`,
          `abcantrackv2`.`vehicle_damage`.`IntEmployeeId2`                 AS `IntEmployeeId2`,
          `abcantrackv2`.`vehicle_damage`.`IntEmployeeId3`                 AS `IntEmployeeId3`,
          `abcantrackv2`.`vehicle_damage`.`PrimRespondId`                  AS `PrimRespondId`,
          `abcantrackv2`.`vehicle_damage`.`VehicleDamageId`                AS `ImpactId`,
          `abcantrackv2`.`hist_vehicle_damage`.`OriginalVehicleDamageId`   AS `OriginalId`,
          NULL                                                             AS `PersonalInjuredId`,
          NULL                                                             AS `ContactCodeId`,
          NULL                                                             AS `RecordableId`,
          NULL                                                             AS `RestrictedWorkId`,
          NULL                                                             AS `InitialTreatmentId`,
          NULL                                                             AS `ContactAgencyId`,
          NULL                                                             AS `PersonalAfflictedId`,
          NULL                                                             AS `SourceId`,
          NULL                                                             AS `DurationUnitId`,
          NULL                                                             AS `QuantityUnitId`,
          NULL                                                             AS `RecoveredUnitId`,
          NULL                                                             AS `Reportable`,
          `abcantrackv2`.`vehicle_damage`.`IncidentId`                     AS `IncidentId`,
          `abcantrackv2`.`impact_type`.`ImpactTypeName`                    AS `ImpactTypeName`,
          `abcantrackv2`.`impact_type`.`ImpactTypeCode`                    AS `ImpactTypeCode`,
          `abcantrackv2`.`impact_sub_type`.`ImpactSubTypeName`             AS `ImpactSubTypeName`,
          `abcantrackv2`.`vehicle_damage`.`IntEmployeeName1`               AS `IntEmployeeName1`,
          `abcantrackv2`.`vehicle_damage`.`IntEmployeeName2`               AS `IntEmployeeName2`,
          `abcantrackv2`.`vehicle_damage`.`IntEmployeeName3`               AS `IntEmployeeName3`,
          `abcantrackv2`.`vehicle_damage`.`IntEmployeeDept1`               AS `IntEmployeeDept1`,
          `abcantrackv2`.`vehicle_damage`.`IntEmployeeDept2`               AS `IntEmployeeDept2`,
          `abcantrackv2`.`vehicle_damage`.`IntEmployeeDept3`               AS `IntEmployeeDept3`,
          `abcantrackv2`.`vehicle_damage`.`PrimRespondName`                AS `PrimRespondName`,
          `abcantrackv2`.`vehicle_damage`.`Description`                    AS `Description`,
          `abcantrackv2`.`hist_vehicle_damage`.`OldImpactDescription`      AS `OldImpactDescription`,
          `abcantrackv2`.`vehicle_damage`.`EstimatedCost`                  AS `EstimatedCost`,
          concat(`abcantrackv2`.`vehicle_damage`.`VehicleDamageId`, '_', `abcantrackv2`.`vehicle_damage`.`IncidentId`,
                 '_', `abcantrackv2`.`impact_type`.`ImpactTypeCode`)       AS `Identification`,
          (SELECT group_concat(DISTINCT `abcantrackv2`.`external_agency`.`ExtAgencyName` SEPARATOR ', ')
           FROM (`abcantrackv2`.`impacts_ext_agency`
             JOIN `abcantrackv2`.`external_agency` ON ((`abcantrackv2`.`external_agency`.`ExtAgencyId` =
                                                        `abcantrackv2`.`impacts_ext_agency`.`ExtAgencyId`)))
           WHERE
             (`abcantrackv2`.`impacts_ext_agency`.`VehicleDamageId` = `abcantrackv2`.`vehicle_damage`.`VehicleDamageId`)
           GROUP BY `abcantrackv2`.`impacts_ext_agency`.`VehicleDamageId`) AS `ExtAgencyName`,
          NULL                                                             AS `PersonalInjuredName`,
          NULL                                                             AS `InitialTreatmentName`,
          NULL                                                             AS `ContactCodeName`,
          NULL                                                             AS `RecordableName`,
          NULL                                                             AS `RestrictedWorkName`,
          NULL                                                             AS `LostTimeStart`,
          NULL                                                             AS `LostTimeEnd`,
          NULL                                                             AS `AdjustmentDays`,
          NULL                                                             AS `TotalDaysOff`,
          `abcantrackv2`.`vehicle_damage`.`DamageDescription`              AS `ImpactTypeDescription`,
          `abcantrackv2`.`hist_vehicle_damage`.`OldDamageDescription`      AS `OldImpactTypeDescription`,
          NULL                                                             AS `ContactAgencyName`,
          NULL                                                             AS `PersonalAfflictedName`,
          NULL                                                             AS `SourceName`,
          NULL                                                             AS `DurationValue`,
          NULL                                                             AS `DurationUnitName`,
          NULL                                                             AS `QuantityValue`,
          NULL                                                             AS `QuantityUnitName`,
          NULL                                                             AS `QuantityRecoveredValue`,
          NULL                                                             AS `RecoveredUnitName`,
          NULL                                                             AS `WhatWasIt`,
          NULL                                                             AS `HowDidSROccur`,
          NULL                                                             AS `IsReportable`,
          NULL                                                             AS `SpRelAgencyName`,
          `abcantrackv2`.`vehicle_damage`.`DriverName`                     AS `DriverName`,
          `abcantrackv2`.`vehicle_damage`.`DriverLicence`                  AS `DriverLicence`,
          `abcantrackv2`.`vehicle_type`.`VehicleTypeName`                  AS `VehicleTypeName`,
          `abcantrackv2`.`vehicle_damage`.`VehicleLicence`                 AS `VehicleLicence`,
          `abcantrackv2`.`vehicle_damage`.`HowDidThatDone`                 AS `HowDidThatDone`,
          NULL                                                             AS `Details`,
          NULL                                                             AS `ValueOfFine`,
          NULL                                                             AS `TicketNumber`,
          NULL                                                             AS `HowDidThatOccur`,
          NULL                                                             AS `InjuryTypeName`,
          NULL                                                             AS `BodyPartName`,
          NULL                                                             AS `BodyAreaName`,
          `abcantrackv2`.`vehicle_damage`.`VehicleTypeId`                  AS `VehicleTypeId`,
          NULL                                                             AS `OldHowDidThatOccur`,
          NULL                                                             AS `OldDetails`,
          NULL                                                             AS `SymptomsName`,
          NULL                                                             AS `OldWhatWasIt`,
          NULL                                                             AS `OldHowDidSROccur`,
          `abcantrackv2`.`hist_vehicle_damage`.`OldHowDidThatDone`         AS `OldHowDidThatDone`,
          `abcantrackv2`.`hist_vehicle_damage`.`OldDamageDescription`      AS `OldDamageDescription`
        FROM ((((`abcantrackv2`.`vehicle_damage`
          JOIN `abcantrackv2`.`impact_sub_type` ON ((`abcantrackv2`.`impact_sub_type`.`ImpactSubTypeId` =
                                                     `abcantrackv2`.`vehicle_damage`.`ImpactSubTypeId`))) JOIN
          `abcantrackv2`.`impact_type` ON ((`abcantrackv2`.`impact_sub_type`.`ImpactTypeId` =
                                            `abcantrackv2`.`impact_type`.`ImpactTypeId`))) LEFT JOIN
          `abcantrackv2`.`vehicle_type`
            ON ((`abcantrackv2`.`vehicle_damage`.`VehicleTypeId` = `abcantrackv2`.`vehicle_type`.`VehicleTypeId`))) JOIN
          `abcantrackv2`.`hist_vehicle_damage` ON ((`abcantrackv2`.`hist_vehicle_damage`.`VehicleDamageId` =
                                                    `abcantrackv2`.`vehicle_damage`.`VehicleDamageId`)))
  UNION SELECT
          `abcantrackv2`.`traffic_violation`.`ImpactSubTypeId`                                                        AS `ImpactSubTypeId`,
          `abcantrackv2`.`impact_type`.`ImpactTypeId`                                                                 AS `ImpactTypeId`,
          `abcantrackv2`.`traffic_violation`.`IntEmployeeId1`                                                         AS `IntEmployeeId1`,
          `abcantrackv2`.`traffic_violation`.`IntEmployeeId2`                                                         AS `IntEmployeeId2`,
          `abcantrackv2`.`traffic_violation`.`IntEmployeeId3`                                                         AS `IntEmployeeId3`,
          `abcantrackv2`.`traffic_violation`.`PrimRespondId`                                                          AS `PrimRespondId`,
          `abcantrackv2`.`traffic_violation`.`TrafficViolationId`                                                     AS `ImpactId`,
          `abcantrackv2`.`hist_traffic_violation`.`OriginalTrafficViolationId`                                        AS `OriginalId`,
          NULL                                                                                                        AS `PersonalInjuredId`,
          NULL                                                                                                        AS `ContactCodeId`,
          NULL                                                                                                        AS `RecordableId`,
          NULL                                                                                                        AS `RestrictedWorkId`,
          NULL                                                                                                        AS `InitialTreatmentId`,
          NULL                                                                                                        AS `ContactAgencyId`,
          NULL                                                                                                        AS `PersonalAfflictedId`,
          NULL                                                                                                        AS `SourceId`,
          NULL                                                                                                        AS `DurationUnitId`,
          NULL                                                                                                        AS `QuantityUnitId`,
          NULL                                                                                                        AS `RecoveredUnitId`,
          NULL                                                                                                        AS `Reportable`,
          `abcantrackv2`.`traffic_violation`.`IncidentId`                                                             AS `IncidentId`,
          `abcantrackv2`.`impact_type`.`ImpactTypeName`                                                               AS `ImpactTypeName`,
          `abcantrackv2`.`impact_type`.`ImpactTypeCode`                                                               AS `ImpactTypeCode`,
          `abcantrackv2`.`impact_sub_type`.`ImpactSubTypeName`                                                        AS `ImpactSubTypeName`,
          `abcantrackv2`.`traffic_violation`.`IntEmployeeName1`                                                       AS `IntEmployeeName1`,
          `abcantrackv2`.`traffic_violation`.`IntEmployeeName2`                                                       AS `IntEmployeeName2`,
          `abcantrackv2`.`traffic_violation`.`IntEmployeeName3`                                                       AS `IntEmployeeName3`,
          `abcantrackv2`.`traffic_violation`.`IntEmployeeDept1`                                                       AS `IntEmployeeDept1`,
          `abcantrackv2`.`traffic_violation`.`IntEmployeeDept2`                                                       AS `IntEmployeeDept2`,
          `abcantrackv2`.`traffic_violation`.`IntEmployeeDept3`                                                       AS `IntEmployeeDept3`,
          `abcantrackv2`.`traffic_violation`.`PrimRespondName`                                                        AS `PrimRespondName`,
          `abcantrackv2`.`traffic_violation`.`Description`                                                            AS `Description`,
          `abcantrackv2`.`hist_traffic_violation`.`OldImpactDescription`                                              AS `OldImpactDescription`,
          `abcantrackv2`.`traffic_violation`.`EstimatedCost`                                                          AS `EstimatedCost`,
          concat(`abcantrackv2`.`traffic_violation`.`TrafficViolationId`, '_',
                 `abcantrackv2`.`traffic_violation`.`IncidentId`, '_',
                 `abcantrackv2`.`impact_type`.`ImpactTypeCode`)                                                       AS `Identification`,
          (SELECT group_concat(DISTINCT `abcantrackv2`.`external_agency`.`ExtAgencyName` SEPARATOR ', ')
           FROM (`abcantrackv2`.`impacts_ext_agency`
             JOIN `abcantrackv2`.`external_agency` ON ((`abcantrackv2`.`external_agency`.`ExtAgencyId` =
                                                        `abcantrackv2`.`impacts_ext_agency`.`ExtAgencyId`)))
           WHERE (`abcantrackv2`.`impacts_ext_agency`.`TrafficViolationId` =
                  `abcantrackv2`.`traffic_violation`.`TrafficViolationId`)
           GROUP BY
             `abcantrackv2`.`impacts_ext_agency`.`TrafficViolationId`)                                                AS `ExtAgencyName`,
          NULL                                                                                                        AS `PersonalInjuredName`,
          NULL                                                                                                        AS `InitialTreatmentName`,
          NULL                                                                                                        AS `ContactCodeName`,
          NULL                                                                                                        AS `RecordableName`,
          NULL                                                                                                        AS `RestrictedWorkName`,
          NULL                                                                                                        AS `LostTimeStart`,
          NULL                                                                                                        AS `LostTimeEnd`,
          NULL                                                                                                        AS `AdjustmentDays`,
          NULL                                                                                                        AS `TotalDaysOff`,
          NULL                                                                                                        AS `ImpactTypeDescription`,
          NULL                                                                                                        AS `OldImpactTypeDescription`,
          NULL                                                                                                        AS `ContactAgencyName`,
          NULL                                                                                                        AS `PersonalAfflictedName`,
          NULL                                                                                                        AS `SourceName`,
          NULL                                                                                                        AS `DurationValue`,
          NULL                                                                                                        AS `DurationUnitName`,
          NULL                                                                                                        AS `QuantityValue`,
          NULL                                                                                                        AS `QuantityUnitName`,
          NULL                                                                                                        AS `QuantityRecoveredValue`,
          NULL                                                                                                        AS `RecoveredUnitName`,
          NULL                                                                                                        AS `WhatWasIt`,
          NULL                                                                                                        AS `HowDidSROccur`,
          NULL                                                                                                        AS `IsReportable`,
          NULL                                                                                                        AS `SpRelAgencyName`,
          `abcantrackv2`.`traffic_violation`.`DriverName`                                                             AS `DriverName`,
          `abcantrackv2`.`traffic_violation`.`DriverLicence`                                                          AS `DriverLicence`,
          `abcantrackv2`.`vehicle_type`.`VehicleTypeName`                                                             AS `VehicleTypeName`,
          `abcantrackv2`.`traffic_violation`.`VehicleLicence`                                                         AS `VehicleLicence`,
          NULL                                                                                                        AS `HowDidThatDone`,
          `abcantrackv2`.`traffic_violation`.`Details`                                                                AS `Details`,
          `abcantrackv2`.`traffic_violation`.`ValueOfFine`                                                            AS `ValueOfFine`,
          `abcantrackv2`.`traffic_violation`.`TicketNumber`                                                           AS `TicketNumber`,
          `abcantrackv2`.`traffic_violation`.`HowDidThatOccur`                                                        AS `HowDidThatOccur`,
          NULL                                                                                                        AS `InjuryTypeName`,
          NULL                                                                                                        AS `BodyPartName`,
          NULL                                                                                                        AS `BodyAreaName`,
          `abcantrackv2`.`traffic_violation`.`VehicleTypeId`                                                          AS `VehicleTypeId`,
          `abcantrackv2`.`hist_traffic_violation`.`OldHowDidThatOccur`                                                AS `OldHowDidThatOccur`,
          `abcantrackv2`.`hist_traffic_violation`.`OldDetails`                                                        AS `OldDetails`,
          NULL                                                                                                        AS `SymptomsName`,
          NULL                                                                                                        AS `OldWhatWasIt`,
          NULL                                                                                                        AS `OldHowDidSROccur`,
          NULL                                                                                                        AS `OldHowDidThatDone`,
          NULL                                                                                                        AS `OldDamageDescription`
        FROM ((((`abcantrackv2`.`traffic_violation`
          JOIN `abcantrackv2`.`impact_sub_type` ON ((`abcantrackv2`.`impact_sub_type`.`ImpactSubTypeId` =
                                                     `abcantrackv2`.`traffic_violation`.`ImpactSubTypeId`))) JOIN
          `abcantrackv2`.`impact_type` ON ((`abcantrackv2`.`impact_sub_type`.`ImpactTypeId` =
                                            `abcantrackv2`.`impact_type`.`ImpactTypeId`))) LEFT JOIN
          `abcantrackv2`.`vehicle_type` ON ((`abcantrackv2`.`traffic_violation`.`VehicleTypeId` =
                                             `abcantrackv2`.`vehicle_type`.`VehicleTypeId`))) JOIN
          `abcantrackv2`.`hist_traffic_violation` ON ((`abcantrackv2`.`hist_traffic_violation`.`TrafficViolationId` =
                                                       `abcantrackv2`.`traffic_violation`.`TrafficViolationId`)))
  ORDER BY `IncidentId`;
