CREATE VIEW ABCanTrackV2.incident_corrective_action_view AS
  SELECT
    `abcantrackv2`.`corrective_action`.`CorrectiveActionId`                      AS `CorrectiveActionId`,
    `abcantrackv2`.`corrective_action`.`IncidentId`                              AS `IncidentId`,
    concat(`empAssigned`.`FirstName`, ' ', `empAssigned`.`LastName`)             AS `AssignedToId`,
    (SELECT group_concat(concat(`empNotified`.`FirstName`, ' ', `empNotified`.`LastName`) SEPARATOR '; ')
     FROM (`abcantrackv2`.`corrective_action_notified`
       JOIN `abcantrackv2`.`employee` `empNotified`
         ON ((`empNotified`.`EmployeeId` = `abcantrackv2`.`corrective_action_notified`.`EmployeeId`)))
     WHERE (`abcantrackv2`.`corrective_action_notified`.`CorrectiveActionId` =
            `abcantrackv2`.`corrective_action`.`CorrectiveActionId`))            AS `EmployeeId`,
    `abcantrackv2`.`corr_act_status`.`CorrActStatusName`                         AS `TaskStatusId`,
    `abcantrackv2`.`priority`.`PriorityName`                                     AS `PriorityId`,
    `abcantrackv2`.`corrective_action`.`StartDate`                               AS `StartDate`,
    `abcantrackv2`.`corrective_action`.`TargetEndDate`                           AS `TargetEndDate`,
    `abcantrackv2`.`corrective_action`.`ActualEndDate`                           AS `ActualEndDate`,
    `abcantrackv2`.`corrective_action`.`EstimatedCost`                           AS `TaskEstimatedCost`,
    `abcantrackv2`.`corrective_action`.`TaskDescription`                         AS `TaskDescription`,
    `abcantrackv2`.`corrective_action`.`OutComeFollowUp`                         AS `OutComeFollowUp`,
    (CASE `abcantrackv2`.`corrective_action`.`DesiredResults`
     WHEN '0'
       THEN `REPLACEYESNO`(`abcantrackv2`.`corr_act_status`.`OrgId`, 'no')
     WHEN '1'
       THEN `REPLACEYESNO`(`abcantrackv2`.`corr_act_status`.`OrgId`, 'yes') END) AS `DesiredResults`,
    `abcantrackv2`.`corrective_action`.`Comments`                                AS `Comments`
  FROM (((`abcantrackv2`.`corrective_action`
    LEFT JOIN `abcantrackv2`.`corr_act_status` ON ((`abcantrackv2`.`corr_act_status`.`CorrActStatusId` =
                                                    `abcantrackv2`.`corrective_action`.`CorrActStatusId`))) LEFT JOIN
    `abcantrackv2`.`priority`
      ON ((`abcantrackv2`.`priority`.`PriorityId` = `abcantrackv2`.`corrective_action`.`PriorityId`))) LEFT JOIN
    `abcantrackv2`.`employee` `empAssigned`
      ON ((`empAssigned`.`EmployeeId` = `abcantrackv2`.`corrective_action`.`AssignedToId`)))
  ORDER BY `abcantrackv2`.`corrective_action`.`IncidentId` DESC;
