CREATE VIEW ABCanTrackV2.corrective_action_view AS
  SELECT
    `abcantrackv2`.`hist_corrective_action`.`OriginalCorrectiveActionId`                          AS `OriginalCorrectiveActionId`,
    `abcantrackv2`.`corrective_action`.`CorrectiveActionId`                                       AS `CorrectiveActionId`,
    `abcantrackv2`.`incident`.`IncidentNumber`                                                    AS `IncidentNumber`,
    `abcantrackv2`.`corrective_action`.`IncidentId`                                               AS `IncidentId`,
    `abcantrackv2`.`incident`.`IncidentDate`                                                      AS `IncidentDate`,
    `abcantrackv2`.`incident`.`IncidentHour`                                                      AS `IncidentHour`,
    `abcantrackv2`.`incident`.`IncidentMinute`                                                    AS `IncidentMinute`,
    `abcantrackv2`.`corr_act_status`.`CorrActStatusName`                                          AS `CorrActStatusName`,
    `abcantrackv2`.`priority`.`PriorityName`                                                      AS `priorityName`,
    `abcantrackv2`.`incident`.`EditingBy`                                                         AS `EditingBy`,
    `abcantrackv2`.`incident`.`EditingBy`                                                         AS `LockedId`,
    concat(`assignedemp`.`FirstName`, ' ', `assignedemp`.`LastName`)                              AS `AssignedToName`,
    `abcantrackv2`.`corrective_action`.`StartDate`                                                AS `StartDate`,
    `abcantrackv2`.`corrective_action`.`ActualEndDate`                                            AS `ActualEndDate`,
    `abcantrackv2`.`corrective_action`.`TargetEndDate`                                            AS `TargetEndDate`,
    `abcantrackv2`.`corrective_action`.`EstimatedCost`                                            AS `TaskEstimatedCost`,
    `abcantrackv2`.`corrective_action`.`TaskDescription`                                          AS `TaskDescription`,
    `abcantrackv2`.`corrective_action`.`OutComeFollowUp`                                          AS `OutComeFollowUp`,
    `abcantrackv2`.`corrective_action`.`DesiredResults`                                           AS `DesiredResults`,
    `abcantrackv2`.`corrective_action`.`Comments`                                                 AS `Comments`,
    `abcantrackv2`.`incident`.`OrgId`                                                             AS `OrgId`,
    `abcantrackv2`.`corrective_action`.`AssignedToId`                                             AS `AssignedToId`,
    (SELECT group_concat(concat(`notifiedemp`.`FirstName`, ' ', `notifiedemp`.`LastName`) SEPARATOR ', ')
     FROM (`abcantrackv2`.`corrective_action_notified`
       JOIN `abcantrackv2`.`employee` `notifiedemp`
         ON ((`notifiedemp`.`EmployeeId` = `abcantrackv2`.`corrective_action_notified`.`EmployeeId`)))
     WHERE (`abcantrackv2`.`corrective_action_notified`.`CorrectiveActionId` =
            `abcantrackv2`.`corrective_action`.`CorrectiveActionId`))                             AS `NotifiedNames`,
    `abcantrackv2`.`hist_corrective_action`.`HistCorrectiveActionId`                              AS `HistCorrectiveActionId`,
    `CORRECTIVE_ACTION_FUN`(`abcantrackv2`.`hist_corrective_action`.`OriginalCorrectiveActionId`) AS `SentDate`
  FROM (((((`abcantrackv2`.`corrective_action`
    JOIN `abcantrackv2`.`incident`
      ON ((`abcantrackv2`.`incident`.`IncidentId` = `abcantrackv2`.`corrective_action`.`IncidentId`))) LEFT JOIN
    `abcantrackv2`.`hist_corrective_action` ON ((`abcantrackv2`.`hist_corrective_action`.`CorrectiveActionId` =
                                                 `abcantrackv2`.`corrective_action`.`CorrectiveActionId`))) LEFT JOIN
    `abcantrackv2`.`corr_act_status` ON ((`abcantrackv2`.`corr_act_status`.`CorrActStatusId` =
                                          `abcantrackv2`.`corrective_action`.`CorrActStatusId`))) LEFT JOIN
    `abcantrackv2`.`priority`
      ON ((`abcantrackv2`.`priority`.`PriorityId` = `abcantrackv2`.`corrective_action`.`PriorityId`))) JOIN
    `abcantrackv2`.`employee` `assignedemp`
      ON ((`assignedemp`.`EmployeeId` = `abcantrackv2`.`corrective_action`.`AssignedToId`)))
  WHERE (`abcantrackv2`.`incident`.`IsDeleted` = 0)
  GROUP BY `abcantrackv2`.`corrective_action`.`CorrectiveActionId`;
