CREATE VIEW ABCanTrackV2.inc_impact_extagency_view AS
  SELECT
    `abcantrackv2`.`incident`.`IncidentId`                                                                        AS `IncidentId`,
    concat_ws(', ', (SELECT group_concat(`abcantrackv2`.`external_agency`.`ExtAgencyName` SEPARATOR '; ')
                     FROM ((`abcantrackv2`.`impact`
                       LEFT JOIN `abcantrackv2`.`impacts_ext_agency`
                         ON ((`abcantrackv2`.`impacts_ext_agency`.`ImpactId` =
                              `abcantrackv2`.`impact`.`ImpactId`))) LEFT JOIN `abcantrackv2`.`external_agency`
                         ON ((`abcantrackv2`.`external_agency`.`ExtAgencyId` =
                              `abcantrackv2`.`impacts_ext_agency`.`ExtAgencyId`)))
                     WHERE (`abcantrackv2`.`impact`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
              (SELECT group_concat(`abcantrackv2`.`external_agency`.`ExtAgencyName` SEPARATOR '; ')
               FROM ((`abcantrackv2`.`injury`
                 LEFT JOIN `abcantrackv2`.`impacts_ext_agency`
                   ON ((`abcantrackv2`.`impacts_ext_agency`.`InjuryId` = `abcantrackv2`.`injury`.`InjuryId`))) LEFT JOIN
                 `abcantrackv2`.`external_agency` ON ((`abcantrackv2`.`external_agency`.`ExtAgencyId` =
                                                       `abcantrackv2`.`impacts_ext_agency`.`ExtAgencyId`)))
               WHERE (`abcantrackv2`.`injury`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
              (SELECT group_concat(`abcantrackv2`.`external_agency`.`ExtAgencyName` SEPARATOR '; ')
               FROM ((`abcantrackv2`.`illness`
                 LEFT JOIN `abcantrackv2`.`impacts_ext_agency` ON ((`abcantrackv2`.`impacts_ext_agency`.`IllnessId` =
                                                                    `abcantrackv2`.`illness`.`IllnessId`))) LEFT JOIN
                 `abcantrackv2`.`external_agency` ON ((`abcantrackv2`.`external_agency`.`ExtAgencyId` =
                                                       `abcantrackv2`.`impacts_ext_agency`.`ExtAgencyId`)))
               WHERE (`abcantrackv2`.`illness`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
              (SELECT group_concat(`abcantrackv2`.`external_agency`.`ExtAgencyName` SEPARATOR '; ')
               FROM ((`abcantrackv2`.`spill_release`
                 LEFT JOIN `abcantrackv2`.`impacts_ext_agency`
                   ON ((`abcantrackv2`.`impacts_ext_agency`.`SpillReleaseId` =
                        `abcantrackv2`.`spill_release`.`SpillReleaseId`))) LEFT JOIN `abcantrackv2`.`external_agency`
                   ON ((`abcantrackv2`.`external_agency`.`ExtAgencyId` =
                        `abcantrackv2`.`impacts_ext_agency`.`ExtAgencyId`)))
               WHERE (`abcantrackv2`.`spill_release`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
              (SELECT group_concat(`abcantrackv2`.`external_agency`.`ExtAgencyName` SEPARATOR '; ')
               FROM ((`abcantrackv2`.`vehicle_damage`
                 LEFT JOIN `abcantrackv2`.`impacts_ext_agency`
                   ON ((`abcantrackv2`.`impacts_ext_agency`.`VehicleDamageId` =
                        `abcantrackv2`.`vehicle_damage`.`VehicleDamageId`))) LEFT JOIN `abcantrackv2`.`external_agency`
                   ON ((`abcantrackv2`.`external_agency`.`ExtAgencyId` =
                        `abcantrackv2`.`impacts_ext_agency`.`ExtAgencyId`)))
               WHERE (`abcantrackv2`.`vehicle_damage`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
              (SELECT group_concat(`abcantrackv2`.`external_agency`.`ExtAgencyName` SEPARATOR '; ')
               FROM ((`abcantrackv2`.`traffic_violation`
                 LEFT JOIN `abcantrackv2`.`impacts_ext_agency`
                   ON ((`abcantrackv2`.`impacts_ext_agency`.`TrafficViolationId` =
                        `abcantrackv2`.`traffic_violation`.`TrafficViolationId`))) LEFT JOIN
                 `abcantrackv2`.`external_agency` ON ((`abcantrackv2`.`external_agency`.`ExtAgencyId` =
                                                       `abcantrackv2`.`impacts_ext_agency`.`ExtAgencyId`)))
               WHERE (`abcantrackv2`.`traffic_violation`.`IncidentId` =
                      `abcantrackv2`.`incident`.`IncidentId`)))                                                   AS `ExtAgencyId`
  FROM `abcantrackv2`.`incident`;
