CREATE VIEW ABCanTrackV2.incident_third_party AS
  SELECT
    `abcantrackv2`.`incident`.`IncidentId`                                                                           AS `IncidentId`,
    (SELECT group_concat(`abcantrackv2`.`third_party`.`ThirdPartyName` SEPARATOR ' ; ')
     FROM (`abcantrackv2`.`third_party`
       LEFT JOIN `abcantrackv2`.`third_party_type`
         ON ((`abcantrackv2`.`third_party_type`.`ThirdPartyTypeId` = `abcantrackv2`.`third_party`.`ThirdPartyTypeId`)))
     WHERE ((`abcantrackv2`.`third_party_type`.`ThirdPartyTypeName` = 'Customer') AND
            `abcantrackv2`.`third_party`.`ThirdPartyId` IN (SELECT `abcantrackv2`.`inc_third_party`.`ThirdPartyId`
                                                            FROM `abcantrackv2`.`inc_third_party`
                                                            WHERE (`abcantrackv2`.`incident`.`IncidentId` =
                                                                   `abcantrackv2`.`inc_third_party`.`IncidentId`)))) AS `CustomerId`,
    (SELECT group_concat(`abcantrackv2`.`inc_third_party`.`ContactName` SEPARATOR ' ; ')
     FROM ((`abcantrackv2`.`inc_third_party`
       LEFT JOIN `abcantrackv2`.`third_party`
         ON ((`abcantrackv2`.`inc_third_party`.`ThirdPartyId` = `abcantrackv2`.`third_party`.`ThirdPartyId`))) LEFT JOIN
       `abcantrackv2`.`third_party_type`
         ON ((`abcantrackv2`.`third_party_type`.`ThirdPartyTypeId` = `abcantrackv2`.`third_party`.`ThirdPartyTypeId`)))
     WHERE ((`abcantrackv2`.`third_party_type`.`ThirdPartyTypeName` = 'Customer') AND
            (`abcantrackv2`.`incident`.`IncidentId` =
             `abcantrackv2`.`inc_third_party`.`IncidentId`)))                                                        AS `CustName`,
    (SELECT group_concat(`abcantrackv2`.`inc_third_party`.`JobNumber` SEPARATOR ' ; ')
     FROM ((`abcantrackv2`.`inc_third_party`
       LEFT JOIN `abcantrackv2`.`third_party`
         ON ((`abcantrackv2`.`inc_third_party`.`ThirdPartyId` = `abcantrackv2`.`third_party`.`ThirdPartyId`))) LEFT JOIN
       `abcantrackv2`.`third_party_type`
         ON ((`abcantrackv2`.`third_party_type`.`ThirdPartyTypeId` = `abcantrackv2`.`third_party`.`ThirdPartyTypeId`)))
     WHERE ((`abcantrackv2`.`third_party_type`.`ThirdPartyTypeName` = 'Customer') AND
            (`abcantrackv2`.`incident`.`IncidentId` =
             `abcantrackv2`.`inc_third_party`.`IncidentId`)))                                                        AS `CustomerJobNumber`,
    (SELECT group_concat(`abcantrackv2`.`third_party`.`ThirdPartyName` SEPARATOR ' ; ')
     FROM (`abcantrackv2`.`third_party`
       LEFT JOIN `abcantrackv2`.`third_party_type`
         ON ((`abcantrackv2`.`third_party_type`.`ThirdPartyTypeId` = `abcantrackv2`.`third_party`.`ThirdPartyTypeId`)))
     WHERE ((`abcantrackv2`.`third_party_type`.`ThirdPartyTypeName` = 'Contractor') AND
            `abcantrackv2`.`third_party`.`ThirdPartyId` IN (SELECT `abcantrackv2`.`inc_third_party`.`ThirdPartyId`
                                                            FROM `abcantrackv2`.`inc_third_party`
                                                            WHERE (`abcantrackv2`.`incident`.`IncidentId` =
                                                                   `abcantrackv2`.`inc_third_party`.`IncidentId`)))) AS `ContractorId`,
    (SELECT group_concat(`abcantrackv2`.`inc_third_party`.`JobNumber` SEPARATOR ' ; ')
     FROM ((`abcantrackv2`.`inc_third_party`
       LEFT JOIN `abcantrackv2`.`third_party`
         ON ((`abcantrackv2`.`inc_third_party`.`ThirdPartyId` = `abcantrackv2`.`third_party`.`ThirdPartyId`))) LEFT JOIN
       `abcantrackv2`.`third_party_type`
         ON ((`abcantrackv2`.`third_party_type`.`ThirdPartyTypeId` = `abcantrackv2`.`third_party`.`ThirdPartyTypeId`)))
     WHERE ((`abcantrackv2`.`third_party_type`.`ThirdPartyTypeName` = 'Contractor') AND
            (`abcantrackv2`.`incident`.`IncidentId` =
             `abcantrackv2`.`inc_third_party`.`IncidentId`)))                                                        AS `ContractorJobNumber`,
    (SELECT group_concat(`abcantrackv2`.`inc_third_party`.`ContactName` SEPARATOR ' ; ')
     FROM ((`abcantrackv2`.`inc_third_party`
       LEFT JOIN `abcantrackv2`.`third_party`
         ON ((`abcantrackv2`.`inc_third_party`.`ThirdPartyId` = `abcantrackv2`.`third_party`.`ThirdPartyId`))) LEFT JOIN
       `abcantrackv2`.`third_party_type`
         ON ((`abcantrackv2`.`third_party_type`.`ThirdPartyTypeId` = `abcantrackv2`.`third_party`.`ThirdPartyTypeId`)))
     WHERE ((`abcantrackv2`.`third_party_type`.`ThirdPartyTypeName` = 'Contractor') AND
            (`abcantrackv2`.`incident`.`IncidentId` =
             `abcantrackv2`.`inc_third_party`.`IncidentId`)))                                                        AS `ContName`
  FROM (`abcantrackv2`.`inc_third_party`
    JOIN `abcantrackv2`.`incident`
      ON ((`abcantrackv2`.`incident`.`IncidentId` = `abcantrackv2`.`inc_third_party`.`IncidentId`)))
  GROUP BY `abcantrackv2`.`inc_third_party`.`IncidentId`;
