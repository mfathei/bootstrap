CREATE VIEW ABCanTrackV2.inc_impact_type_view AS
  SELECT
    `abcantrackv2`.`incident`.`IncidentId`                               AS `IncidentId`,
    (SELECT concat_ws(', ', (SELECT group_concat(`abcantrackv2`.`impact_type`.`ImpactTypeName` SEPARATOR ', ')
                             FROM ((`abcantrackv2`.`impact`
                               JOIN `abcantrackv2`.`impact_sub_type`
                                 ON ((`abcantrackv2`.`impact_sub_type`.`ImpactSubTypeId` =
                                      `abcantrackv2`.`impact`.`ImpactSubTypeId`))) JOIN `abcantrackv2`.`impact_type`
                                 ON ((`abcantrackv2`.`impact_sub_type`.`ImpactTypeId` =
                                      `abcantrackv2`.`impact_type`.`ImpactTypeId`)))
                             WHERE (`abcantrackv2`.`impact`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`impact_type`.`ImpactTypeName` SEPARATOR ', ')
                       FROM ((`abcantrackv2`.`injury`
                         JOIN `abcantrackv2`.`impact_sub_type` ON ((`abcantrackv2`.`impact_sub_type`.`ImpactSubTypeId` =
                                                                    `abcantrackv2`.`injury`.`ImpactSubTypeId`))) JOIN
                         `abcantrackv2`.`impact_type` ON ((`abcantrackv2`.`impact_sub_type`.`ImpactTypeId` =
                                                           `abcantrackv2`.`impact_type`.`ImpactTypeId`)))
                       WHERE (`abcantrackv2`.`injury`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`impact_type`.`ImpactTypeName` SEPARATOR ', ')
                       FROM ((`abcantrackv2`.`illness`
                         JOIN `abcantrackv2`.`impact_sub_type` ON ((`abcantrackv2`.`impact_sub_type`.`ImpactSubTypeId` =
                                                                    `abcantrackv2`.`illness`.`ImpactSubTypeId`))) JOIN
                         `abcantrackv2`.`impact_type` ON ((`abcantrackv2`.`impact_sub_type`.`ImpactTypeId` =
                                                           `abcantrackv2`.`impact_type`.`ImpactTypeId`)))
                       WHERE (`abcantrackv2`.`illness`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`impact_type`.`ImpactTypeName` SEPARATOR ', ')
                       FROM ((`abcantrackv2`.`spill_release`
                         JOIN `abcantrackv2`.`impact_sub_type` ON ((`abcantrackv2`.`impact_sub_type`.`ImpactSubTypeId` =
                                                                    `abcantrackv2`.`spill_release`.`ImpactSubTypeId`))) JOIN
                         `abcantrackv2`.`impact_type` ON ((`abcantrackv2`.`impact_sub_type`.`ImpactTypeId` =
                                                           `abcantrackv2`.`impact_type`.`ImpactTypeId`)))
                       WHERE (`abcantrackv2`.`spill_release`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`impact_type`.`ImpactTypeName` SEPARATOR ', ')
                       FROM ((`abcantrackv2`.`vehicle_damage`
                         JOIN `abcantrackv2`.`impact_sub_type` ON ((`abcantrackv2`.`impact_sub_type`.`ImpactSubTypeId` =
                                                                    `abcantrackv2`.`vehicle_damage`.`ImpactSubTypeId`))) JOIN
                         `abcantrackv2`.`impact_type` ON ((`abcantrackv2`.`impact_sub_type`.`ImpactTypeId` =
                                                           `abcantrackv2`.`impact_type`.`ImpactTypeId`)))
                       WHERE (`abcantrackv2`.`vehicle_damage`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`impact_type`.`ImpactTypeName` SEPARATOR ', ')
                       FROM ((`abcantrackv2`.`traffic_violation`
                         JOIN `abcantrackv2`.`impact_sub_type` ON ((`abcantrackv2`.`impact_sub_type`.`ImpactSubTypeId` =
                                                                    `abcantrackv2`.`traffic_violation`.`ImpactSubTypeId`))) JOIN
                         `abcantrackv2`.`impact_type` ON ((`abcantrackv2`.`impact_sub_type`.`ImpactTypeId` =
                                                           `abcantrackv2`.`impact_type`.`ImpactTypeId`)))
                       WHERE (`abcantrackv2`.`traffic_violation`.`IncidentId` =
                              `abcantrackv2`.`incident`.`IncidentId`)))) AS `ImpactTypeId`
  FROM `abcantrackv2`.`incident`;
