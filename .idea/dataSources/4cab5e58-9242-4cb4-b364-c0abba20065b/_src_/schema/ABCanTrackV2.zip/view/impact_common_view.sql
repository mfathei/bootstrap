CREATE VIEW ABCanTrackV2.impact_common_view AS
  SELECT
    `inc`.`IncidentId`                                                                   AS `IncidentId`,
    concat_ws(', ', `inj`.`IntEmployeeName1`, `imp`.`IntEmployeeName1`, `ill`.`IntEmployeeName1`,
              `sp`.`IntEmployeeName1`, `vd`.`IntEmployeeName1`, `tv`.`IntEmployeeName1`) AS `IntEmployeeName1`,
    concat_ws(', ', `inj`.`IntEmployeeName2`, `imp`.`IntEmployeeName2`, `ill`.`IntEmployeeName2`,
              `sp`.`IntEmployeeName2`, `vd`.`IntEmployeeName2`, `tv`.`IntEmployeeName2`) AS `IntEmployeeName2`,
    concat_ws(', ', `inj`.`IntEmployeeName3`, `imp`.`IntEmployeeName3`, `ill`.`IntEmployeeName3`,
              `sp`.`IntEmployeeName3`, `vd`.`IntEmployeeName3`, `tv`.`IntEmployeeName3`) AS `IntEmployeeName3`,
    concat_ws(', ', `inj`.`IntEmployeeDept1`, `imp`.`IntEmployeeDept1`, `ill`.`IntEmployeeDept1`,
              `sp`.`IntEmployeeDept1`, `vd`.`IntEmployeeDept1`, `tv`.`IntEmployeeDept1`) AS `IntEmployeeDept1`,
    concat_ws(', ', `inj`.`IntEmployeeDept2`, `imp`.`IntEmployeeDept2`, `ill`.`IntEmployeeDept2`,
              `sp`.`IntEmployeeDept2`, `vd`.`IntEmployeeDept2`, `tv`.`IntEmployeeDept2`) AS `IntEmployeeDept2`,
    concat_ws(', ', `inj`.`IntEmployeeDept3`, `imp`.`IntEmployeeDept3`, `ill`.`IntEmployeeDept3`,
              `sp`.`IntEmployeeDept3`, `vd`.`IntEmployeeDept3`, `tv`.`IntEmployeeDept3`) AS `IntEmployeeDept3`,
    concat_ws(', ', `inj`.`PrimRespondName`, `imp`.`PrimRespondName`, `ill`.`PrimRespondName`, `sp`.`PrimRespondName`,
              `vd`.`PrimRespondName`, `tv`.`PrimRespondName`)                            AS `PrimRespondName`,
    concat_ws(', ', `inj`.`Description`, `imp`.`Description`, `ill`.`Description`, `sp`.`Description`,
              `vd`.`Description`, `tv`.`Description`)                                    AS `ImpactDescription`,
    concat_ws(', ', `inj`.`EstimatedCost`, `imp`.`EstimatedCost`, `ill`.`EstimatedCost`, `sp`.`EstimatedCost`,
              `vd`.`EstimatedCost`, `tv`.`EstimatedCost`)                                AS `EstimatedCost`
  FROM ((((((`abcantrackv2`.`incident` `inc` LEFT JOIN `abcantrackv2`.`injury` `inj`
      ON ((`inc`.`IncidentId` = `inj`.`IncidentId`))) LEFT JOIN `abcantrackv2`.`impact` `imp`
      ON ((`inc`.`IncidentId` = `imp`.`IncidentId`))) LEFT JOIN `abcantrackv2`.`illness` `ill`
      ON ((`inc`.`IncidentId` = `ill`.`IncidentId`))) LEFT JOIN `abcantrackv2`.`spill_release` `sp`
      ON ((`inc`.`IncidentId` = `sp`.`IncidentId`))) LEFT JOIN `abcantrackv2`.`vehicle_damage` `vd`
      ON ((`inc`.`IncidentId` = `vd`.`IncidentId`))) LEFT JOIN `abcantrackv2`.`traffic_violation` `tv`
      ON ((`inc`.`IncidentId` = `tv`.`IncidentId`)))
  GROUP BY `inc`.`IncidentId`;
