CREATE VIEW ABCanTrackV2.new_view_vw AS
  SELECT
    `a`.`AttachmentId`   AS `AttachmentId`,
    `h`.`IncidentId`     AS `IncidentId`,
    `a`.`VersionNumber`  AS `VersionNumber`,
    `a`.`AttachmentName` AS `AttachmentName`,
    `a`.`AttachmentType` AS `AttachmentType`,
    `a`.`AttachmentSize` AS `AttachmentSize`
  FROM (`abcantrackv2`.`attachment` `a`
    JOIN `abcantrackv2`.`hist_incident` `h` ON ((`a`.`IncidentId` = `h`.`HistIncidentId`)));
