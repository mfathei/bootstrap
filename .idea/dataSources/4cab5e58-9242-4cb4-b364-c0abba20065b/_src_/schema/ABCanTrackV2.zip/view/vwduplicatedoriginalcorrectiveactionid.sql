CREATE VIEW ABCanTrackV2.vwduplicatedoriginalcorrectiveactionid AS
  SELECT
    `hc`.`OriginalCorrectiveActionId`        AS `OriginalCorrectiveActionId`,
    `hc`.`IncidentId`                        AS `IncidentId`,
    count(`hc`.`OriginalCorrectiveActionId`) AS `cnt`
  FROM `abcantrackv2`.`hist_corrective_action` `hc`
  WHERE (`hc`.`OriginalCorrectiveActionId` <> '')
  GROUP BY `hc`.`OriginalCorrectiveActionId`, `hc`.`IncidentId`
  HAVING (`cnt` > 1);
