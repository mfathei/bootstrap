CREATE VIEW ABCanTrackV2.tempo_two AS
  SELECT
    `hi`.`IncidentId`         AS `IncidentId`,
    max(`hi`.`VersionNumber`) AS `v`
  FROM (`abcantrackv2`.`hist_incident` `hi`
    JOIN `abcantrackv2`.`tmpo` ON ((`hi`.`IncidentId` = `tmpo`.`IncidentId`)))
  WHERE (`hi`.`VersionNumber` < `tmpo`.`VersionNumber`)
  GROUP BY `hi`.`IncidentId`;
