CREATE VIEW ABCanTrackV2.emaillogdata1 AS
  SELECT
    group_concat(DISTINCT `i`.`IncidentNumber` SEPARATOR ',')     AS `IncidentNumber`,
    group_concat(DISTINCT concat(`hi`.`IncidentDate`, ' ', `hi`.`IncidentHour`, ':', `hi`.`IncidentMinute`) SEPARATOR
                 ', ')                                            AS `IncidentDate`,
    group_concat(DISTINCT `hi`.`EventTypeName` SEPARATOR ',')     AS `EventTypeName`,
    group_concat(DISTINCT `hi`.`Location1Name` SEPARATOR ',')     AS `Location1Name`,
    group_concat(DISTINCT `hi`.`Location2Name` SEPARATOR ',')     AS `Location2Name`,
    group_concat(DISTINCT `hi`.`Location3Name` SEPARATOR ',')     AS `Location3Name`,
    group_concat(DISTINCT `hi`.`Location4Name` SEPARATOR ',')     AS `Location4Name`,
    group_concat(DISTINCT `hi`.`OperationTypeName` SEPARATOR ',') AS `OperationTypeName`,
    `el`.`EmailLogId`                                             AS `EmailLogId`,
    `hi`.`HistIncidentId`                                         AS `HistIncidentId`,
    `hi`.`IncidentId`                                             AS `IncidentId`,
    `el`.`From`                                                   AS `From`,
    `el`.`To`                                                     AS `To`,
    `el`.`CC`                                                     AS `CC`,
    `el`.`SendToEmployeeId`                                       AS `SendToEmployeeId`,
    `el`.`CcEmployeeId`                                           AS `CcEmployeeId`,
    `el`.`IsSent`                                                 AS `IsSent`,
    `el`.`Error`                                                  AS `Error`,
    `el`.`IsManual`                                               AS `IsManual`,
    `el`.`Subject`                                                AS `Subject`,
    `el`.`SentDate`                                               AS `SentDate`,
    `el`.`OrgId`                                                  AS `OrgId`,
    `hc`.`OriginalCorrectiveActionId`                             AS `OriginalCorrectiveActionId`,
    `hc`.`CorrectiveActionId`                                     AS `CorrectiveActionId`,
    `ce`.`EmailLogId`                                             AS `ceid`,
    `hc`.`HistCorrectiveActionId`                                 AS `HistCorrectiveActionId`
  FROM ((((`abcantrackv2`.`email_log` `el` LEFT JOIN (`abcantrackv2`.`inc_email_log` `ieg`
    JOIN `abcantrackv2`.`hist_incident` `hi` ON ((`hi`.`HistIncidentId` = `ieg`.`HistIncidentId`)))
      ON ((`ieg`.`EmailLogId` = `el`.`EmailLogId`))) LEFT JOIN (`abcantrackv2`.`hist_corrective_action` `hc`
    JOIN `abcantrackv2`.`corr_act_email` `ce` ON ((`ce`.`HistCorrectiveActionId` = `hc`.`HistCorrectiveActionId`)))
      ON (((`hi`.`HistIncidentId` = `hc`.`HistIncidentId`) AND (`ce`.`EmailLogId` = `el`.`EmailLogId`)))) LEFT JOIN
    `abcantrackv2`.`inc_deletion_info` `i_d` ON ((`hi`.`IncidentId` = `i_d`.`IncidentId`))) LEFT JOIN
    `abcantrackv2`.`incident` `i` ON ((`hi`.`IncidentId` = `i`.`IncidentId`)))
  WHERE isnull(`i_d`.`IncDeletionInfoId`)
  GROUP BY `el`.`EmailLogId`;
