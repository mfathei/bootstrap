CREATE VIEW ABCanTrackV2.impacts_all_view AS
  SELECT
    `abcantrackv2`.`incident`.`IncidentId`                     AS `IncidentId`,
    `abcantrackv2`.`incident`.`OrgId`                          AS `OrgId`,
    `abcantrackv2`.`incident`.`IsDeleted`                      AS `IsDeleted`,
    `abcantrackv2`.`incident`.`IncidentDate`                   AS `IncidentDate`,
    `abcantrackv2`.`incident`.`EventTypeId`                    AS `EventTypeId`,
    `abcantrackv2`.`incident`.`IsEmerRP`                       AS `IsEmerRP`,
    `abcantrackv2`.`incident`.`Location1Id`                    AS `Location1Id`,
    `abcantrackv2`.`incident`.`Location2Id`                    AS `Location2Id`,
    `abcantrackv2`.`incident`.`Location3Id`                    AS `Location3Id`,
    `abcantrackv2`.`incident`.`Location4Id`                    AS `Location4Id`,
    `abcantrackv2`.`incident`.`OperationTypeId`                AS `OperationTypeId`,
    `abcantrackv2`.`incident`.`RiskOfRecurrenceId`             AS `RiskOfRecurrenceId`,
    `abcantrackv2`.`incident`.`InvStatusId`                    AS `InvStatusId`,
    `abcantrackv2`.`incident`.`IncidentSeverityId`             AS `IncidentSeverityId`,
    `abcantrackv2`.`incident`.`InsuranceCost`                  AS `InsuranceCost`,
    `abcantrackv2`.`incident`.`OtherCost`                      AS `OtherCost`,
    `abcantrackv2`.`incident`.`RepairCost`                     AS `RepairCost`,
    `abcantrackv2`.`incident`.`ResponseCost`                   AS `ResponseCost`,
    `abcantrackv2`.`incident`.`TotalCost`                      AS `TotalCost`,
    `abcantrackv2`.`incident`.`WCBCost`                        AS `WCBCost`,
    `abcantrackv2`.`impact_type`.`ImpactTypeId`                AS `ImpactTypeId`,
    `abcantrackv2`.`impact_type`.`ImpactTypeName`              AS `ImpactTypeName`,
    `abcantrackv2`.`illness`.`ImpactSubTypeId`                 AS `ImpactSubTypeId`,
    `abcantrackv2`.`impact_sub_type`.`ImpactSubTypeName`       AS `ImpactSubTypeName`,
    NULL                                                       AS `ImpactId`,
    NULL                                                       AS `InjuryId`,
    NULL                                                       AS `PersonalInjuredName`,
    NULL                                                       AS `PersonalInjuredId`,
    NULL                                                       AS `InitialTreatmentId`,
    NULL                                                       AS `ContactCodeId`,
    NULL                                                       AS `RecordableId`,
    NULL                                                       AS `RestrictedWorkId`,
    NULL                                                       AS `LostTimeStart`,
    NULL                                                       AS `LostTimeEnd`,
    NULL                                                       AS `AdjustmentDays`,
    NULL                                                       AS `TotalDaysOff`,
    NULL                                                       AS `InjuryDescription`,
    NULL                                                       AS `ContactAgencyId`,
    NULL                                                       AS `SpillReleaseId`,
    NULL                                                       AS `SourceId`,
    NULL                                                       AS `DurationValue`,
    NULL                                                       AS `DurationUnitId`,
    NULL                                                       AS `QuantityValue`,
    NULL                                                       AS `QuantityUnitId`,
    NULL                                                       AS `QuantityRecoveredValue`,
    NULL                                                       AS `RecoveredUnitId`,
    NULL                                                       AS `WhatWasIt`,
    NULL                                                       AS `HowDidSROccur`,
    NULL                                                       AS `IsReportable`,
    NULL                                                       AS `SpRelAgencyId`,
    NULL                                                       AS `TrafficViolationId`,
    NULL                                                       AS `TVDriverName`,
    NULL                                                       AS `TVDriverLicence`,
    NULL                                                       AS `TVVehicleTypeId`,
    NULL                                                       AS `TVVehicleLicence`,
    NULL                                                       AS `Details`,
    NULL                                                       AS `ValueOfFine`,
    NULL                                                       AS `TicketNumber`,
    NULL                                                       AS `HowDidThatOccur`,
    NULL                                                       AS `VehicleDamageId`,
    NULL                                                       AS `DriverName`,
    NULL                                                       AS `DriverLicence`,
    NULL                                                       AS `VehicleTypeId`,
    NULL                                                       AS `VehicleLicence`,
    NULL                                                       AS `HowDidThatDone`,
    NULL                                                       AS `DamageDescription`,
    `abcantrackv2`.`illness`.`IllnessId`                       AS `IllnessId`,
    `abcantrackv2`.`illness`.`PersonalAfflictedName`           AS `PersonalAfflictedName`,
    `abcantrackv2`.`illness`.`PersonalAfflictedId`             AS `PersonalAfflictedId`,
    `abcantrackv2`.`illness`.`RestrictedWorkId`                AS `IllRestrictedWorkId`,
    `abcantrackv2`.`illness`.`InitialTreatmentId`              AS `IllInitialTreatmentId`,
    `abcantrackv2`.`illness`.`LostTimeStart`                   AS `IllLostTimeStart`,
    `abcantrackv2`.`illness`.`LostTimeEnd`                     AS `IllLostTimeEnd`,
    `abcantrackv2`.`illness`.`AdjustmentDays`                  AS `IllAdjustmentDays`,
    `abcantrackv2`.`illness`.`TotalDaysOff`                    AS `IllTotalDaysOff`,
    `abcantrackv2`.`illness`.`IllnessDescription`              AS `IllnessDescription`,
    `abcantrackv2`.`illness`.`IntEmployeeId1`                  AS `IntEmployeeId1`,
    `abcantrackv2`.`illness`.`IntEmployeeName1`                AS `IntEmployeeName1`,
    `abcantrackv2`.`illness`.`IntEmployeeDept1`                AS `IntEmployeeDept1`,
    `abcantrackv2`.`illness`.`IntEmployeeId2`                  AS `IntEmployeeId2`,
    `abcantrackv2`.`illness`.`IntEmployeeName2`                AS `IntEmployeeName2`,
    `abcantrackv2`.`illness`.`IntEmployeeDept2`                AS `IntEmployeeDept2`,
    `abcantrackv2`.`illness`.`IntEmployeeId3`                  AS `IntEmployeeId3`,
    `abcantrackv2`.`illness`.`IntEmployeeName3`                AS `IntEmployeeName3`,
    `abcantrackv2`.`illness`.`IntEmployeeDept3`                AS `IntEmployeeDept3`,
    `abcantrackv2`.`illness`.`CustomOpenTxt`                   AS `CustomOpenTxt`,
    `abcantrackv2`.`illness`.`PrimRespondName`                 AS `PrimRespondName`,
    `abcantrackv2`.`illness`.`PrimRespondId`                   AS `PrimRespondId`,
    `abcantrackv2`.`illness`.`Description`                     AS `Description`,
    `abcantrackv2`.`illness`.`EstimatedCost`                   AS `EstimatedCost`,
    `abcantrackv2`.`risk_of_recurrence`.`RiskOfRecurrenceName` AS `RiskOfRecurrenceName`,
    `abcantrackv2`.`incident_severity`.`IncidentSeverityName`  AS `IncidentSeverityName`,
    `abcantrackv2`.`event_type`.`EventTypeName`                AS `EventTypeName`,
    `abcantrackv2`.`operation_type`.`OperationTypeName`        AS `OperationTypeName`,
    `abcantrackv2`.`location1`.`Location1Name`                 AS `Location1Name`,
    `abcantrackv2`.`location2`.`Location2Name`                 AS `Location2Name`,
    `abcantrackv2`.`location3`.`Location3Name`                 AS `Location3Name`,
    `abcantrackv2`.`location4`.`Location4Name`                 AS `Location4Name`,
    `abcantrackv2`.`inv_status`.`InvStatusName`                AS `InvStatusName`
  FROM ((((((((((((`abcantrackv2`.`illness`
    JOIN `abcantrackv2`.`incident`
      ON ((`abcantrackv2`.`illness`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`))) JOIN
    `abcantrackv2`.`impact_sub_type`
      ON ((`abcantrackv2`.`illness`.`ImpactSubTypeId` = `abcantrackv2`.`impact_sub_type`.`ImpactSubTypeId`))) JOIN
    `abcantrackv2`.`impact_type`
      ON ((`abcantrackv2`.`impact_sub_type`.`ImpactTypeId` = `abcantrackv2`.`impact_type`.`ImpactTypeId`))) LEFT JOIN
    `abcantrackv2`.`event_type`
      ON ((`abcantrackv2`.`event_type`.`EventTypeId` = `abcantrackv2`.`incident`.`EventTypeId`))) LEFT JOIN
    `abcantrackv2`.`operation_type`
      ON ((`abcantrackv2`.`operation_type`.`OperationTypeId` = `abcantrackv2`.`incident`.`OperationTypeId`))) LEFT JOIN
    `abcantrackv2`.`incident_severity` ON ((`abcantrackv2`.`incident_severity`.`IncidentSeverityId` =
                                            `abcantrackv2`.`incident`.`IncidentSeverityId`))) LEFT JOIN
    `abcantrackv2`.`risk_of_recurrence` ON ((`abcantrackv2`.`risk_of_recurrence`.`RiskOfRecurrenceId` =
                                             `abcantrackv2`.`incident`.`RiskOfRecurrenceId`))) LEFT JOIN
    `abcantrackv2`.`inv_status`
      ON ((`abcantrackv2`.`inv_status`.`InvStatusId` = `abcantrackv2`.`incident`.`InvStatusId`))) LEFT JOIN
    `abcantrackv2`.`location1`
      ON ((`abcantrackv2`.`location1`.`Location1Id` = `abcantrackv2`.`incident`.`Location1Id`))) LEFT JOIN
    `abcantrackv2`.`location2`
      ON ((`abcantrackv2`.`location2`.`Location2Id` = `abcantrackv2`.`incident`.`Location2Id`))) LEFT JOIN
    `abcantrackv2`.`location3`
      ON ((`abcantrackv2`.`location3`.`Location3Id` = `abcantrackv2`.`incident`.`Location3Id`))) LEFT JOIN
    `abcantrackv2`.`location4`
      ON ((`abcantrackv2`.`location4`.`Location4Id` = `abcantrackv2`.`incident`.`Location4Id`)))
  UNION ALL SELECT
              `abcantrackv2`.`incident`.`IncidentId`                     AS `IncidentId`,
              `abcantrackv2`.`incident`.`OrgId`                          AS `OrgId`,
              `abcantrackv2`.`incident`.`IsDeleted`                      AS `IsDeleted`,
              `abcantrackv2`.`incident`.`IncidentDate`                   AS `IncidentDate`,
              `abcantrackv2`.`incident`.`EventTypeId`                    AS `EventTypeId`,
              `abcantrackv2`.`incident`.`IsEmerRP`                       AS `IsEmerRP`,
              `abcantrackv2`.`incident`.`Location1Id`                    AS `Location1Id`,
              `abcantrackv2`.`incident`.`Location2Id`                    AS `Location2Id`,
              `abcantrackv2`.`incident`.`Location3Id`                    AS `Location3Id`,
              `abcantrackv2`.`incident`.`Location4Id`                    AS `Location4Id`,
              `abcantrackv2`.`incident`.`OperationTypeId`                AS `OperationTypeId`,
              `abcantrackv2`.`incident`.`RiskOfRecurrenceId`             AS `RiskOfRecurrenceId`,
              `abcantrackv2`.`incident`.`InvStatusId`                    AS `InvStatusId`,
              `abcantrackv2`.`incident`.`IncidentSeverityId`             AS `IncidentSeverityId`,
              `abcantrackv2`.`incident`.`InsuranceCost`                  AS `InsuranceCost`,
              `abcantrackv2`.`incident`.`OtherCost`                      AS `OtherCost`,
              `abcantrackv2`.`incident`.`RepairCost`                     AS `RepairCost`,
              `abcantrackv2`.`incident`.`ResponseCost`                   AS `ResponseCost`,
              `abcantrackv2`.`incident`.`TotalCost`                      AS `TotalCost`,
              `abcantrackv2`.`incident`.`WCBCost`                        AS `WCBCost`,
              `abcantrackv2`.`impact_type`.`ImpactTypeId`                AS `ImpactTypeId`,
              `abcantrackv2`.`impact_type`.`ImpactTypeName`              AS `ImpactTypeName`,
              `abcantrackv2`.`impact`.`ImpactSubTypeId`                  AS `ImpactSubTypeId`,
              `abcantrackv2`.`impact_sub_type`.`ImpactSubTypeName`       AS `ImpactSubTypeName`,
              `abcantrackv2`.`impact`.`ImpactId`                         AS `ImpactId`,
              NULL                                                       AS `InjuryId`,
              NULL                                                       AS `PersonalInjuredName`,
              NULL                                                       AS `PersonalInjuredId`,
              NULL                                                       AS `InitialTreatmentId`,
              NULL                                                       AS `ContactCodeId`,
              NULL                                                       AS `RecordableId`,
              NULL                                                       AS `RestrictedWorkId`,
              NULL                                                       AS `LostTimeStart`,
              NULL                                                       AS `LostTimeEnd`,
              NULL                                                       AS `AdjustmentDays`,
              NULL                                                       AS `TotalDaysOff`,
              NULL                                                       AS `InjuryDescription`,
              NULL                                                       AS `ContactAgencyId`,
              NULL                                                       AS `SpillReleaseId`,
              NULL                                                       AS `SourceId`,
              NULL                                                       AS `DurationValue`,
              NULL                                                       AS `DurationUnitId`,
              NULL                                                       AS `QuantityValue`,
              NULL                                                       AS `QuantityUnitId`,
              NULL                                                       AS `QuantityRecoveredValue`,
              NULL                                                       AS `RecoveredUnitId`,
              NULL                                                       AS `WhatWasIt`,
              NULL                                                       AS `HowDidSROccur`,
              NULL                                                       AS `IsReportable`,
              NULL                                                       AS `SpRelAgencyId`,
              NULL                                                       AS `TrafficViolationId`,
              NULL                                                       AS `TVDriverName`,
              NULL                                                       AS `TVDriverLicence`,
              NULL                                                       AS `TVVehicleTypeId`,
              NULL                                                       AS `TVVehicleLicence`,
              NULL                                                       AS `Details`,
              NULL                                                       AS `ValueOfFine`,
              NULL                                                       AS `TicketNumber`,
              NULL                                                       AS `HowDidThatOccur`,
              NULL                                                       AS `VehicleDamageId`,
              NULL                                                       AS `DriverName`,
              NULL                                                       AS `DriverLicence`,
              NULL                                                       AS `VehicleTypeId`,
              NULL                                                       AS `VehicleLicence`,
              NULL                                                       AS `HowDidThatDone`,
              NULL                                                       AS `DamageDescription`,
              NULL                                                       AS `IllnessId`,
              NULL                                                       AS `PersonalAfflictedName`,
              NULL                                                       AS `PersonalAfflictedId`,
              NULL                                                       AS `IllRestrictedWorkId`,
              NULL                                                       AS `IllInitialTreatmentId`,
              NULL                                                       AS `IllLostTimeStart`,
              NULL                                                       AS `IllLostTimeEnd`,
              NULL                                                       AS `IllAdjustmentDays`,
              NULL                                                       AS `IllTotalDaysOff`,
              NULL                                                       AS `IllnessDescription`,
              `abcantrackv2`.`impact`.`IntEmployeeId1`                   AS `IntEmployeeId1`,
              `abcantrackv2`.`impact`.`IntEmployeeName1`                 AS `IntEmployeeName1`,
              `abcantrackv2`.`impact`.`IntEmployeeDept1`                 AS `IntEmployeeDept1`,
              `abcantrackv2`.`impact`.`IntEmployeeId2`                   AS `IntEmployeeId2`,
              `abcantrackv2`.`impact`.`IntEmployeeName2`                 AS `IntEmployeeName2`,
              `abcantrackv2`.`impact`.`IntEmployeeDept2`                 AS `IntEmployeeDept2`,
              `abcantrackv2`.`impact`.`IntEmployeeId3`                   AS `IntEmployeeId3`,
              `abcantrackv2`.`impact`.`IntEmployeeName3`                 AS `IntEmployeeName3`,
              `abcantrackv2`.`impact`.`IntEmployeeDept3`                 AS `IntEmployeeDept3`,
              `abcantrackv2`.`impact`.`CustomOpenTxt`                    AS `CustomOpenTxt`,
              `abcantrackv2`.`impact`.`PrimRespondName`                  AS `PrimRespondName`,
              `abcantrackv2`.`impact`.`PrimRespondId`                    AS `PrimRespondId`,
              `abcantrackv2`.`impact`.`Description`                      AS `Description`,
              `abcantrackv2`.`impact`.`EstimatedCost`                    AS `EstimatedCost`,
              `abcantrackv2`.`risk_of_recurrence`.`RiskOfRecurrenceName` AS `RiskOfRecurrenceName`,
              `abcantrackv2`.`incident_severity`.`IncidentSeverityName`  AS `IncidentSeverityName`,
              `abcantrackv2`.`event_type`.`EventTypeName`                AS `EventTypeName`,
              `abcantrackv2`.`operation_type`.`OperationTypeName`        AS `OperationTypeName`,
              `abcantrackv2`.`location1`.`Location1Name`                 AS `Location1Name`,
              `abcantrackv2`.`location2`.`Location2Name`                 AS `Location2Name`,
              `abcantrackv2`.`location3`.`Location3Name`                 AS `Location3Name`,
              `abcantrackv2`.`location4`.`Location4Name`                 AS `Location4Name`,
              `abcantrackv2`.`inv_status`.`InvStatusName`                AS `InvStatusName`
            FROM ((((((((((((`abcantrackv2`.`impact`
              JOIN `abcantrackv2`.`incident`
                ON ((`abcantrackv2`.`impact`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`))) JOIN
              `abcantrackv2`.`impact_sub_type` ON ((`abcantrackv2`.`impact`.`ImpactSubTypeId` =
                                                    `abcantrackv2`.`impact_sub_type`.`ImpactSubTypeId`))) JOIN
              `abcantrackv2`.`impact_type` ON ((`abcantrackv2`.`impact_sub_type`.`ImpactTypeId` =
                                                `abcantrackv2`.`impact_type`.`ImpactTypeId`))) LEFT JOIN
              `abcantrackv2`.`event_type`
                ON ((`abcantrackv2`.`event_type`.`EventTypeId` = `abcantrackv2`.`incident`.`EventTypeId`))) LEFT JOIN
              `abcantrackv2`.`operation_type` ON ((`abcantrackv2`.`operation_type`.`OperationTypeId` =
                                                   `abcantrackv2`.`incident`.`OperationTypeId`))) LEFT JOIN
              `abcantrackv2`.`incident_severity` ON ((`abcantrackv2`.`incident_severity`.`IncidentSeverityId` =
                                                      `abcantrackv2`.`incident`.`IncidentSeverityId`))) LEFT JOIN
              `abcantrackv2`.`risk_of_recurrence` ON ((`abcantrackv2`.`risk_of_recurrence`.`RiskOfRecurrenceId` =
                                                       `abcantrackv2`.`incident`.`RiskOfRecurrenceId`))) LEFT JOIN
              `abcantrackv2`.`inv_status`
                ON ((`abcantrackv2`.`inv_status`.`InvStatusId` = `abcantrackv2`.`incident`.`InvStatusId`))) LEFT JOIN
              `abcantrackv2`.`location1`
                ON ((`abcantrackv2`.`location1`.`Location1Id` = `abcantrackv2`.`incident`.`Location1Id`))) LEFT JOIN
              `abcantrackv2`.`location2`
                ON ((`abcantrackv2`.`location2`.`Location2Id` = `abcantrackv2`.`incident`.`Location2Id`))) LEFT JOIN
              `abcantrackv2`.`location3`
                ON ((`abcantrackv2`.`location3`.`Location3Id` = `abcantrackv2`.`incident`.`Location3Id`))) LEFT JOIN
              `abcantrackv2`.`location4`
                ON ((`abcantrackv2`.`location4`.`Location4Id` = `abcantrackv2`.`incident`.`Location4Id`)))
  UNION ALL SELECT
              `abcantrackv2`.`incident`.`IncidentId`                     AS `IncidentId`,
              `abcantrackv2`.`incident`.`OrgId`                          AS `OrgId`,
              `abcantrackv2`.`incident`.`IsDeleted`                      AS `IsDeleted`,
              `abcantrackv2`.`incident`.`IncidentDate`                   AS `IncidentDate`,
              `abcantrackv2`.`incident`.`EventTypeId`                    AS `EventTypeId`,
              `abcantrackv2`.`incident`.`IsEmerRP`                       AS `IsEmerRP`,
              `abcantrackv2`.`incident`.`Location1Id`                    AS `Location1Id`,
              `abcantrackv2`.`incident`.`Location2Id`                    AS `Location2Id`,
              `abcantrackv2`.`incident`.`Location3Id`                    AS `Location3Id`,
              `abcantrackv2`.`incident`.`Location4Id`                    AS `Location4Id`,
              `abcantrackv2`.`incident`.`OperationTypeId`                AS `OperationTypeId`,
              `abcantrackv2`.`incident`.`RiskOfRecurrenceId`             AS `RiskOfRecurrenceId`,
              `abcantrackv2`.`incident`.`InvStatusId`                    AS `InvStatusId`,
              `abcantrackv2`.`incident`.`IncidentSeverityId`             AS `IncidentSeverityId`,
              `abcantrackv2`.`incident`.`InsuranceCost`                  AS `InsuranceCost`,
              `abcantrackv2`.`incident`.`OtherCost`                      AS `OtherCost`,
              `abcantrackv2`.`incident`.`RepairCost`                     AS `RepairCost`,
              `abcantrackv2`.`incident`.`ResponseCost`                   AS `ResponseCost`,
              `abcantrackv2`.`incident`.`TotalCost`                      AS `TotalCost`,
              `abcantrackv2`.`incident`.`WCBCost`                        AS `WCBCost`,
              `abcantrackv2`.`impact_type`.`ImpactTypeId`                AS `ImpactTypeId`,
              `abcantrackv2`.`impact_type`.`ImpactTypeName`              AS `ImpactTypeName`,
              `abcantrackv2`.`injury`.`ImpactSubTypeId`                  AS `ImpactSubTypeId`,
              `abcantrackv2`.`impact_sub_type`.`ImpactSubTypeName`       AS `ImpactSubTypeName`,
              NULL                                                       AS `ImpactId`,
              `abcantrackv2`.`injury`.`InjuryId`                         AS `InjuryId`,
              `abcantrackv2`.`injury`.`PersonalInjuredName`              AS `PersonalInjuredName`,
              `abcantrackv2`.`injury`.`PersonalInjuredId`                AS `PersonalInjuredId`,
              `abcantrackv2`.`injury`.`InitialTreatmentId`               AS `InitialTreatmentId`,
              `abcantrackv2`.`injury`.`ContactCodeId`                    AS `ContactCodeId`,
              `abcantrackv2`.`injury`.`RecordableId`                     AS `RecordableId`,
              `abcantrackv2`.`injury`.`RestrictedWorkId`                 AS `RestrictedWorkId`,
              `abcantrackv2`.`injury`.`LostTimeStart`                    AS `LostTimeStart`,
              `abcantrackv2`.`injury`.`LostTimeEnd`                      AS `LostTimeEnd`,
              `abcantrackv2`.`injury`.`AdjustmentDays`                   AS `AdjustmentDays`,
              `abcantrackv2`.`injury`.`TotalDaysOff`                     AS `TotalDaysOff`,
              `abcantrackv2`.`injury`.`InjuryDescription`                AS `InjuryDescription`,
              `abcantrackv2`.`injury`.`ContactAgencyId`                  AS `ContactAgencyId`,
              NULL                                                       AS `SpillReleaseId`,
              NULL                                                       AS `SourceId`,
              NULL                                                       AS `DurationValue`,
              NULL                                                       AS `DurationUnitId`,
              NULL                                                       AS `QuantityValue`,
              NULL                                                       AS `QuantityUnitId`,
              NULL                                                       AS `QuantityRecoveredValue`,
              NULL                                                       AS `RecoveredUnitId`,
              NULL                                                       AS `WhatWasIt`,
              NULL                                                       AS `HowDidSROccur`,
              NULL                                                       AS `IsReportable`,
              NULL                                                       AS `SpRelAgencyId`,
              NULL                                                       AS `TrafficViolationId`,
              NULL                                                       AS `TVDriverName`,
              NULL                                                       AS `TVDriverLicence`,
              NULL                                                       AS `TVVehicleTypeId`,
              NULL                                                       AS `TVVehicleLicence`,
              NULL                                                       AS `Details`,
              NULL                                                       AS `ValueOfFine`,
              NULL                                                       AS `TicketNumber`,
              NULL                                                       AS `HowDidThatOccur`,
              NULL                                                       AS `VehicleDamageId`,
              NULL                                                       AS `DriverName`,
              NULL                                                       AS `DriverLicence`,
              NULL                                                       AS `VehicleTypeId`,
              NULL                                                       AS `VehicleLicence`,
              NULL                                                       AS `HowDidThatDone`,
              NULL                                                       AS `DamageDescription`,
              NULL                                                       AS `IllnessId`,
              NULL                                                       AS `PersonalAfflictedName`,
              NULL                                                       AS `PersonalAfflictedId`,
              NULL                                                       AS `IllRestrictedWorkId`,
              NULL                                                       AS `IllInitialTreatmentId`,
              NULL                                                       AS `IllLostTimeStart`,
              NULL                                                       AS `IllLostTimeEnd`,
              NULL                                                       AS `IllAdjustmentDays`,
              NULL                                                       AS `IllTotalDaysOff`,
              NULL                                                       AS `IllnessDescription`,
              `abcantrackv2`.`injury`.`IntEmployeeId1`                   AS `IntEmployeeId1`,
              `abcantrackv2`.`injury`.`IntEmployeeName1`                 AS `IntEmployeeName1`,
              `abcantrackv2`.`injury`.`IntEmployeeDept1`                 AS `IntEmployeeDept1`,
              `abcantrackv2`.`injury`.`IntEmployeeId2`                   AS `IntEmployeeId2`,
              `abcantrackv2`.`injury`.`IntEmployeeName2`                 AS `IntEmployeeName2`,
              `abcantrackv2`.`injury`.`IntEmployeeDept2`                 AS `IntEmployeeDept2`,
              `abcantrackv2`.`injury`.`IntEmployeeId3`                   AS `IntEmployeeId3`,
              `abcantrackv2`.`injury`.`IntEmployeeName3`                 AS `IntEmployeeName3`,
              `abcantrackv2`.`injury`.`IntEmployeeDept3`                 AS `IntEmployeeDept3`,
              `abcantrackv2`.`injury`.`CustomOpenTxt`                    AS `CustomOpenTxt`,
              `abcantrackv2`.`injury`.`PrimRespondName`                  AS `PrimRespondName`,
              `abcantrackv2`.`injury`.`PrimRespondId`                    AS `PrimRespondId`,
              `abcantrackv2`.`injury`.`Description`                      AS `Description`,
              `abcantrackv2`.`injury`.`EstimatedCost`                    AS `EstimatedCost`,
              `abcantrackv2`.`risk_of_recurrence`.`RiskOfRecurrenceName` AS `RiskOfRecurrenceName`,
              `abcantrackv2`.`incident_severity`.`IncidentSeverityName`  AS `IncidentSeverityName`,
              `abcantrackv2`.`event_type`.`EventTypeName`                AS `EventTypeName`,
              `abcantrackv2`.`operation_type`.`OperationTypeName`        AS `OperationTypeName`,
              `abcantrackv2`.`location1`.`Location1Name`                 AS `Location1Name`,
              `abcantrackv2`.`location2`.`Location2Name`                 AS `Location2Name`,
              `abcantrackv2`.`location3`.`Location3Name`                 AS `Location3Name`,
              `abcantrackv2`.`location4`.`Location4Name`                 AS `Location4Name`,
              `abcantrackv2`.`inv_status`.`InvStatusName`                AS `InvStatusName`
            FROM ((((((((((((`abcantrackv2`.`injury`
              JOIN `abcantrackv2`.`incident`
                ON ((`abcantrackv2`.`injury`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`))) JOIN
              `abcantrackv2`.`impact_sub_type` ON ((`abcantrackv2`.`injury`.`ImpactSubTypeId` =
                                                    `abcantrackv2`.`impact_sub_type`.`ImpactSubTypeId`))) JOIN
              `abcantrackv2`.`impact_type` ON ((`abcantrackv2`.`impact_sub_type`.`ImpactTypeId` =
                                                `abcantrackv2`.`impact_type`.`ImpactTypeId`))) LEFT JOIN
              `abcantrackv2`.`event_type`
                ON ((`abcantrackv2`.`event_type`.`EventTypeId` = `abcantrackv2`.`incident`.`EventTypeId`))) LEFT JOIN
              `abcantrackv2`.`operation_type` ON ((`abcantrackv2`.`operation_type`.`OperationTypeId` =
                                                   `abcantrackv2`.`incident`.`OperationTypeId`))) LEFT JOIN
              `abcantrackv2`.`incident_severity` ON ((`abcantrackv2`.`incident_severity`.`IncidentSeverityId` =
                                                      `abcantrackv2`.`incident`.`IncidentSeverityId`))) LEFT JOIN
              `abcantrackv2`.`risk_of_recurrence` ON ((`abcantrackv2`.`risk_of_recurrence`.`RiskOfRecurrenceId` =
                                                       `abcantrackv2`.`incident`.`RiskOfRecurrenceId`))) LEFT JOIN
              `abcantrackv2`.`inv_status`
                ON ((`abcantrackv2`.`inv_status`.`InvStatusId` = `abcantrackv2`.`incident`.`InvStatusId`))) LEFT JOIN
              `abcantrackv2`.`location1`
                ON ((`abcantrackv2`.`location1`.`Location1Id` = `abcantrackv2`.`incident`.`Location1Id`))) LEFT JOIN
              `abcantrackv2`.`location2`
                ON ((`abcantrackv2`.`location2`.`Location2Id` = `abcantrackv2`.`incident`.`Location2Id`))) LEFT JOIN
              `abcantrackv2`.`location3`
                ON ((`abcantrackv2`.`location3`.`Location3Id` = `abcantrackv2`.`incident`.`Location3Id`))) LEFT JOIN
              `abcantrackv2`.`location4`
                ON ((`abcantrackv2`.`location4`.`Location4Id` = `abcantrackv2`.`incident`.`Location4Id`)))
  UNION ALL SELECT
              `abcantrackv2`.`incident`.`IncidentId`                     AS `IncidentId`,
              `abcantrackv2`.`incident`.`OrgId`                          AS `OrgId`,
              `abcantrackv2`.`incident`.`IsDeleted`                      AS `IsDeleted`,
              `abcantrackv2`.`incident`.`IncidentDate`                   AS `IncidentDate`,
              `abcantrackv2`.`incident`.`EventTypeId`                    AS `EventTypeId`,
              `abcantrackv2`.`incident`.`IsEmerRP`                       AS `IsEmerRP`,
              `abcantrackv2`.`incident`.`Location1Id`                    AS `Location1Id`,
              `abcantrackv2`.`incident`.`Location2Id`                    AS `Location2Id`,
              `abcantrackv2`.`incident`.`Location3Id`                    AS `Location3Id`,
              `abcantrackv2`.`incident`.`Location4Id`                    AS `Location4Id`,
              `abcantrackv2`.`incident`.`OperationTypeId`                AS `OperationTypeId`,
              `abcantrackv2`.`incident`.`RiskOfRecurrenceId`             AS `RiskOfRecurrenceId`,
              `abcantrackv2`.`incident`.`InvStatusId`                    AS `InvStatusId`,
              `abcantrackv2`.`incident`.`IncidentSeverityId`             AS `IncidentSeverityId`,
              `abcantrackv2`.`incident`.`InsuranceCost`                  AS `InsuranceCost`,
              `abcantrackv2`.`incident`.`OtherCost`                      AS `OtherCost`,
              `abcantrackv2`.`incident`.`RepairCost`                     AS `RepairCost`,
              `abcantrackv2`.`incident`.`ResponseCost`                   AS `ResponseCost`,
              `abcantrackv2`.`incident`.`TotalCost`                      AS `TotalCost`,
              `abcantrackv2`.`incident`.`WCBCost`                        AS `WCBCost`,
              `abcantrackv2`.`impact_type`.`ImpactTypeId`                AS `ImpactTypeId`,
              `abcantrackv2`.`impact_type`.`ImpactTypeName`              AS `ImpactTypeName`,
              `abcantrackv2`.`spill_release`.`ImpactSubTypeId`           AS `ImpactSubTypeId`,
              `abcantrackv2`.`impact_sub_type`.`ImpactSubTypeName`       AS `ImpactSubTypeName`,
              NULL                                                       AS `ImpactId`,
              NULL                                                       AS `InjuryId`,
              NULL                                                       AS `PersonalInjuredName`,
              NULL                                                       AS `PersonalInjuredId`,
              NULL                                                       AS `InitialTreatmentId`,
              NULL                                                       AS `ContactCodeId`,
              NULL                                                       AS `RecordableId`,
              NULL                                                       AS `RestrictedWorkId`,
              NULL                                                       AS `LostTimeStart`,
              NULL                                                       AS `LostTimeEnd`,
              NULL                                                       AS `AdjustmentDays`,
              NULL                                                       AS `TotalDaysOff`,
              NULL                                                       AS `InjuryDescription`,
              NULL                                                       AS `ContactAgencyId`,
              `abcantrackv2`.`spill_release`.`SpillReleaseId`            AS `SpillReleaseId`,
              `abcantrackv2`.`spill_release`.`SourceId`                  AS `SourceId`,
              `abcantrackv2`.`spill_release`.`DurationValue`             AS `DurationValue`,
              `abcantrackv2`.`spill_release`.`DurationUnitId`            AS `DurationUnitId`,
              `abcantrackv2`.`spill_release`.`QuantityValue`             AS `QuantityValue`,
              `abcantrackv2`.`spill_release`.`QuantityUnitId`            AS `QuantityUnitId`,
              `abcantrackv2`.`spill_release`.`QuantityRecoveredValue`    AS `QuantityRecoveredValue`,
              `abcantrackv2`.`spill_release`.`RecoveredUnitId`           AS `RecoveredUnitId`,
              `abcantrackv2`.`spill_release`.`WhatWasIt`                 AS `WhatWasIt`,
              `abcantrackv2`.`spill_release`.`HowDidSROccur`             AS `HowDidSROccur`,
              `abcantrackv2`.`spill_release`.`IsReportable`              AS `IsReportable`,
              `abcantrackv2`.`spill_release`.`SpRelAgencyId`             AS `SpRelAgencyId`,
              NULL                                                       AS `TrafficViolationId`,
              NULL                                                       AS `TVDriverName`,
              NULL                                                       AS `TVDriverLicence`,
              NULL                                                       AS `TVVehicleTypeId`,
              NULL                                                       AS `TVVehicleLicence`,
              NULL                                                       AS `Details`,
              NULL                                                       AS `ValueOfFine`,
              NULL                                                       AS `TicketNumber`,
              NULL                                                       AS `HowDidThatOccur`,
              NULL                                                       AS `VehicleDamageId`,
              NULL                                                       AS `DriverName`,
              NULL                                                       AS `DriverLicence`,
              NULL                                                       AS `VehicleTypeId`,
              NULL                                                       AS `VehicleLicence`,
              NULL                                                       AS `HowDidThatDone`,
              NULL                                                       AS `DamageDescription`,
              NULL                                                       AS `IllnessId`,
              NULL                                                       AS `PersonalAfflictedName`,
              NULL                                                       AS `PersonalAfflictedId`,
              NULL                                                       AS `IllRestrictedWorkId`,
              NULL                                                       AS `IllInitialTreatmentId`,
              NULL                                                       AS `IllLostTimeStart`,
              NULL                                                       AS `IllLostTimeEnd`,
              NULL                                                       AS `IllAdjustmentDays`,
              NULL                                                       AS `IllTotalDaysOff`,
              NULL                                                       AS `IllnessDescription`,
              `abcantrackv2`.`spill_release`.`IntEmployeeId1`            AS `IntEmployeeId1`,
              `abcantrackv2`.`spill_release`.`IntEmployeeName1`          AS `IntEmployeeName1`,
              `abcantrackv2`.`spill_release`.`IntEmployeeDept1`          AS `IntEmployeeDept1`,
              `abcantrackv2`.`spill_release`.`IntEmployeeId2`            AS `IntEmployeeId2`,
              `abcantrackv2`.`spill_release`.`IntEmployeeName2`          AS `IntEmployeeName2`,
              `abcantrackv2`.`spill_release`.`IntEmployeeDept2`          AS `IntEmployeeDept2`,
              `abcantrackv2`.`spill_release`.`IntEmployeeId3`            AS `IntEmployeeId3`,
              `abcantrackv2`.`spill_release`.`IntEmployeeName3`          AS `IntEmployeeName3`,
              `abcantrackv2`.`spill_release`.`IntEmployeeDept3`          AS `IntEmployeeDept3`,
              `abcantrackv2`.`spill_release`.`CustomOpenTxt`             AS `CustomOpenTxt`,
              `abcantrackv2`.`spill_release`.`PrimRespondName`           AS `PrimRespondName`,
              `abcantrackv2`.`spill_release`.`PrimRespondId`             AS `PrimRespondId`,
              `abcantrackv2`.`spill_release`.`Description`               AS `Description`,
              `abcantrackv2`.`spill_release`.`EstimatedCost`             AS `EstimatedCost`,
              `abcantrackv2`.`risk_of_recurrence`.`RiskOfRecurrenceName` AS `RiskOfRecurrenceName`,
              `abcantrackv2`.`incident_severity`.`IncidentSeverityName`  AS `IncidentSeverityName`,
              `abcantrackv2`.`event_type`.`EventTypeName`                AS `EventTypeName`,
              `abcantrackv2`.`operation_type`.`OperationTypeName`        AS `OperationTypeName`,
              `abcantrackv2`.`location1`.`Location1Name`                 AS `Location1Name`,
              `abcantrackv2`.`location2`.`Location2Name`                 AS `Location2Name`,
              `abcantrackv2`.`location3`.`Location3Name`                 AS `Location3Name`,
              `abcantrackv2`.`location4`.`Location4Name`                 AS `Location4Name`,
              `abcantrackv2`.`inv_status`.`InvStatusName`                AS `InvStatusName`
            FROM ((((((((((((`abcantrackv2`.`spill_release`
              JOIN `abcantrackv2`.`incident`
                ON ((`abcantrackv2`.`spill_release`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`))) JOIN
              `abcantrackv2`.`impact_sub_type` ON ((`abcantrackv2`.`spill_release`.`ImpactSubTypeId` =
                                                    `abcantrackv2`.`impact_sub_type`.`ImpactSubTypeId`))) JOIN
              `abcantrackv2`.`impact_type` ON ((`abcantrackv2`.`impact_sub_type`.`ImpactTypeId` =
                                                `abcantrackv2`.`impact_type`.`ImpactTypeId`))) LEFT JOIN
              `abcantrackv2`.`event_type`
                ON ((`abcantrackv2`.`event_type`.`EventTypeId` = `abcantrackv2`.`incident`.`EventTypeId`))) LEFT JOIN
              `abcantrackv2`.`operation_type` ON ((`abcantrackv2`.`operation_type`.`OperationTypeId` =
                                                   `abcantrackv2`.`incident`.`OperationTypeId`))) LEFT JOIN
              `abcantrackv2`.`incident_severity` ON ((`abcantrackv2`.`incident_severity`.`IncidentSeverityId` =
                                                      `abcantrackv2`.`incident`.`IncidentSeverityId`))) LEFT JOIN
              `abcantrackv2`.`risk_of_recurrence` ON ((`abcantrackv2`.`risk_of_recurrence`.`RiskOfRecurrenceId` =
                                                       `abcantrackv2`.`incident`.`RiskOfRecurrenceId`))) LEFT JOIN
              `abcantrackv2`.`inv_status`
                ON ((`abcantrackv2`.`inv_status`.`InvStatusId` = `abcantrackv2`.`incident`.`InvStatusId`))) LEFT JOIN
              `abcantrackv2`.`location1`
                ON ((`abcantrackv2`.`location1`.`Location1Id` = `abcantrackv2`.`incident`.`Location1Id`))) LEFT JOIN
              `abcantrackv2`.`location2`
                ON ((`abcantrackv2`.`location2`.`Location2Id` = `abcantrackv2`.`incident`.`Location2Id`))) LEFT JOIN
              `abcantrackv2`.`location3`
                ON ((`abcantrackv2`.`location3`.`Location3Id` = `abcantrackv2`.`incident`.`Location3Id`))) LEFT JOIN
              `abcantrackv2`.`location4`
                ON ((`abcantrackv2`.`location4`.`Location4Id` = `abcantrackv2`.`incident`.`Location4Id`)))
  UNION ALL SELECT
              `abcantrackv2`.`incident`.`IncidentId`                     AS `IncidentId`,
              `abcantrackv2`.`incident`.`OrgId`                          AS `OrgId`,
              `abcantrackv2`.`incident`.`IsDeleted`                      AS `IsDeleted`,
              `abcantrackv2`.`incident`.`IncidentDate`                   AS `IncidentDate`,
              `abcantrackv2`.`incident`.`EventTypeId`                    AS `EventTypeId`,
              `abcantrackv2`.`incident`.`IsEmerRP`                       AS `IsEmerRP`,
              `abcantrackv2`.`incident`.`Location1Id`                    AS `Location1Id`,
              `abcantrackv2`.`incident`.`Location2Id`                    AS `Location2Id`,
              `abcantrackv2`.`incident`.`Location3Id`                    AS `Location3Id`,
              `abcantrackv2`.`incident`.`Location4Id`                    AS `Location4Id`,
              `abcantrackv2`.`incident`.`OperationTypeId`                AS `OperationTypeId`,
              `abcantrackv2`.`incident`.`RiskOfRecurrenceId`             AS `RiskOfRecurrenceId`,
              `abcantrackv2`.`incident`.`InvStatusId`                    AS `InvStatusId`,
              `abcantrackv2`.`incident`.`IncidentSeverityId`             AS `IncidentSeverityId`,
              `abcantrackv2`.`incident`.`InsuranceCost`                  AS `InsuranceCost`,
              `abcantrackv2`.`incident`.`OtherCost`                      AS `OtherCost`,
              `abcantrackv2`.`incident`.`RepairCost`                     AS `RepairCost`,
              `abcantrackv2`.`incident`.`ResponseCost`                   AS `ResponseCost`,
              `abcantrackv2`.`incident`.`TotalCost`                      AS `TotalCost`,
              `abcantrackv2`.`incident`.`WCBCost`                        AS `WCBCost`,
              `abcantrackv2`.`impact_type`.`ImpactTypeId`                AS `ImpactTypeId`,
              `abcantrackv2`.`impact_type`.`ImpactTypeName`              AS `ImpactTypeName`,
              `abcantrackv2`.`traffic_violation`.`ImpactSubTypeId`       AS `ImpactSubTypeId`,
              `abcantrackv2`.`impact_sub_type`.`ImpactSubTypeName`       AS `ImpactSubTypeName`,
              NULL                                                       AS `ImpactId`,
              NULL                                                       AS `InjuryId`,
              NULL                                                       AS `PersonalInjuredName`,
              NULL                                                       AS `PersonalInjuredId`,
              NULL                                                       AS `InitialTreatmentId`,
              NULL                                                       AS `ContactCodeId`,
              NULL                                                       AS `RecordableId`,
              NULL                                                       AS `RestrictedWorkId`,
              NULL                                                       AS `LostTimeStart`,
              NULL                                                       AS `LostTimeEnd`,
              NULL                                                       AS `AdjustmentDays`,
              NULL                                                       AS `TotalDaysOff`,
              NULL                                                       AS `InjuryDescription`,
              NULL                                                       AS `ContactAgencyId`,
              NULL                                                       AS `SpillReleaseId`,
              NULL                                                       AS `SourceId`,
              NULL                                                       AS `DurationValue`,
              NULL                                                       AS `DurationUnitId`,
              NULL                                                       AS `QuantityValue`,
              NULL                                                       AS `QuantityUnitId`,
              NULL                                                       AS `QuantityRecoveredValue`,
              NULL                                                       AS `RecoveredUnitId`,
              NULL                                                       AS `WhatWasIt`,
              NULL                                                       AS `HowDidSROccur`,
              NULL                                                       AS `IsReportable`,
              NULL                                                       AS `SpRelAgencyId`,
              `abcantrackv2`.`traffic_violation`.`TrafficViolationId`    AS `TrafficViolationId`,
              `abcantrackv2`.`traffic_violation`.`DriverName`            AS `TVDriverName`,
              `abcantrackv2`.`traffic_violation`.`DriverLicence`         AS `TVDriverLicence`,
              `abcantrackv2`.`traffic_violation`.`VehicleTypeId`         AS `TVVehicleTypeId`,
              `abcantrackv2`.`traffic_violation`.`VehicleLicence`        AS `TVVehicleLicence`,
              `abcantrackv2`.`traffic_violation`.`Details`               AS `Details`,
              `abcantrackv2`.`traffic_violation`.`ValueOfFine`           AS `ValueOfFine`,
              `abcantrackv2`.`traffic_violation`.`TicketNumber`          AS `TicketNumber`,
              `abcantrackv2`.`traffic_violation`.`HowDidThatOccur`       AS `HowDidThatOccur`,
              NULL                                                       AS `VehicleDamageId`,
              NULL                                                       AS `DriverName`,
              NULL                                                       AS `DriverLicence`,
              NULL                                                       AS `VehicleTypeId`,
              NULL                                                       AS `VehicleLicence`,
              NULL                                                       AS `HowDidThatDone`,
              NULL                                                       AS `DamageDescription`,
              NULL                                                       AS `IllnessId`,
              NULL                                                       AS `PersonalAfflictedName`,
              NULL                                                       AS `PersonalAfflictedId`,
              NULL                                                       AS `IllRestrictedWorkId`,
              NULL                                                       AS `IllInitialTreatmentId`,
              NULL                                                       AS `IllLostTimeStart`,
              NULL                                                       AS `IllLostTimeEnd`,
              NULL                                                       AS `IllAdjustmentDays`,
              NULL                                                       AS `IllTotalDaysOff`,
              NULL                                                       AS `IllnessDescription`,
              `abcantrackv2`.`traffic_violation`.`IntEmployeeId1`        AS `IntEmployeeId1`,
              `abcantrackv2`.`traffic_violation`.`IntEmployeeName1`      AS `IntEmployeeName1`,
              `abcantrackv2`.`traffic_violation`.`IntEmployeeDept1`      AS `IntEmployeeDept1`,
              `abcantrackv2`.`traffic_violation`.`IntEmployeeId2`        AS `IntEmployeeId2`,
              `abcantrackv2`.`traffic_violation`.`IntEmployeeName2`      AS `IntEmployeeName2`,
              `abcantrackv2`.`traffic_violation`.`IntEmployeeDept2`      AS `IntEmployeeDept2`,
              `abcantrackv2`.`traffic_violation`.`IntEmployeeId3`        AS `IntEmployeeId3`,
              `abcantrackv2`.`traffic_violation`.`IntEmployeeName3`      AS `IntEmployeeName3`,
              `abcantrackv2`.`traffic_violation`.`IntEmployeeDept3`      AS `IntEmployeeDept3`,
              `abcantrackv2`.`traffic_violation`.`CustomOpenTxt`         AS `CustomOpenTxt`,
              `abcantrackv2`.`traffic_violation`.`PrimRespondName`       AS `PrimRespondName`,
              `abcantrackv2`.`traffic_violation`.`PrimRespondId`         AS `PrimRespondId`,
              `abcantrackv2`.`traffic_violation`.`Description`           AS `Description`,
              `abcantrackv2`.`traffic_violation`.`EstimatedCost`         AS `EstimatedCost`,
              `abcantrackv2`.`risk_of_recurrence`.`RiskOfRecurrenceName` AS `RiskOfRecurrenceName`,
              `abcantrackv2`.`incident_severity`.`IncidentSeverityName`  AS `IncidentSeverityName`,
              `abcantrackv2`.`event_type`.`EventTypeName`                AS `EventTypeName`,
              `abcantrackv2`.`operation_type`.`OperationTypeName`        AS `OperationTypeName`,
              `abcantrackv2`.`location1`.`Location1Name`                 AS `Location1Name`,
              `abcantrackv2`.`location2`.`Location2Name`                 AS `Location2Name`,
              `abcantrackv2`.`location3`.`Location3Name`                 AS `Location3Name`,
              `abcantrackv2`.`location4`.`Location4Name`                 AS `Location4Name`,
              `abcantrackv2`.`inv_status`.`InvStatusName`                AS `InvStatusName`
            FROM ((((((((((((`abcantrackv2`.`traffic_violation`
              JOIN `abcantrackv2`.`incident`
                ON ((`abcantrackv2`.`traffic_violation`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`))) JOIN
              `abcantrackv2`.`impact_sub_type` ON ((`abcantrackv2`.`traffic_violation`.`ImpactSubTypeId` =
                                                    `abcantrackv2`.`impact_sub_type`.`ImpactSubTypeId`))) JOIN
              `abcantrackv2`.`impact_type` ON ((`abcantrackv2`.`impact_sub_type`.`ImpactTypeId` =
                                                `abcantrackv2`.`impact_type`.`ImpactTypeId`))) LEFT JOIN
              `abcantrackv2`.`event_type`
                ON ((`abcantrackv2`.`event_type`.`EventTypeId` = `abcantrackv2`.`incident`.`EventTypeId`))) LEFT JOIN
              `abcantrackv2`.`operation_type` ON ((`abcantrackv2`.`operation_type`.`OperationTypeId` =
                                                   `abcantrackv2`.`incident`.`OperationTypeId`))) LEFT JOIN
              `abcantrackv2`.`incident_severity` ON ((`abcantrackv2`.`incident_severity`.`IncidentSeverityId` =
                                                      `abcantrackv2`.`incident`.`IncidentSeverityId`))) LEFT JOIN
              `abcantrackv2`.`risk_of_recurrence` ON ((`abcantrackv2`.`risk_of_recurrence`.`RiskOfRecurrenceId` =
                                                       `abcantrackv2`.`incident`.`RiskOfRecurrenceId`))) LEFT JOIN
              `abcantrackv2`.`inv_status`
                ON ((`abcantrackv2`.`inv_status`.`InvStatusId` = `abcantrackv2`.`incident`.`InvStatusId`))) LEFT JOIN
              `abcantrackv2`.`location1`
                ON ((`abcantrackv2`.`location1`.`Location1Id` = `abcantrackv2`.`incident`.`Location1Id`))) LEFT JOIN
              `abcantrackv2`.`location2`
                ON ((`abcantrackv2`.`location2`.`Location2Id` = `abcantrackv2`.`incident`.`Location2Id`))) LEFT JOIN
              `abcantrackv2`.`location3`
                ON ((`abcantrackv2`.`location3`.`Location3Id` = `abcantrackv2`.`incident`.`Location3Id`))) LEFT JOIN
              `abcantrackv2`.`location4`
                ON ((`abcantrackv2`.`location4`.`Location4Id` = `abcantrackv2`.`incident`.`Location4Id`)))
  UNION ALL SELECT
              `abcantrackv2`.`incident`.`IncidentId`                     AS `IncidentId`,
              `abcantrackv2`.`incident`.`OrgId`                          AS `OrgId`,
              `abcantrackv2`.`incident`.`IsDeleted`                      AS `IsDeleted`,
              `abcantrackv2`.`incident`.`IncidentDate`                   AS `IncidentDate`,
              `abcantrackv2`.`incident`.`EventTypeId`                    AS `EventTypeId`,
              `abcantrackv2`.`incident`.`IsEmerRP`                       AS `IsEmerRP`,
              `abcantrackv2`.`incident`.`Location1Id`                    AS `Location1Id`,
              `abcantrackv2`.`incident`.`Location2Id`                    AS `Location2Id`,
              `abcantrackv2`.`incident`.`Location3Id`                    AS `Location3Id`,
              `abcantrackv2`.`incident`.`Location4Id`                    AS `Location4Id`,
              `abcantrackv2`.`incident`.`OperationTypeId`                AS `OperationTypeId`,
              `abcantrackv2`.`incident`.`RiskOfRecurrenceId`             AS `RiskOfRecurrenceId`,
              `abcantrackv2`.`incident`.`InvStatusId`                    AS `InvStatusId`,
              `abcantrackv2`.`incident`.`IncidentSeverityId`             AS `IncidentSeverityId`,
              `abcantrackv2`.`incident`.`InsuranceCost`                  AS `InsuranceCost`,
              `abcantrackv2`.`incident`.`OtherCost`                      AS `OtherCost`,
              `abcantrackv2`.`incident`.`RepairCost`                     AS `RepairCost`,
              `abcantrackv2`.`incident`.`ResponseCost`                   AS `ResponseCost`,
              `abcantrackv2`.`incident`.`TotalCost`                      AS `TotalCost`,
              `abcantrackv2`.`incident`.`WCBCost`                        AS `WCBCost`,
              `abcantrackv2`.`impact_type`.`ImpactTypeId`                AS `ImpactTypeId`,
              `abcantrackv2`.`impact_type`.`ImpactTypeName`              AS `ImpactTypeName`,
              `abcantrackv2`.`vehicle_damage`.`ImpactSubTypeId`          AS `ImpactSubTypeId`,
              `abcantrackv2`.`impact_sub_type`.`ImpactSubTypeName`       AS `ImpactSubTypeName`,
              NULL                                                       AS `ImpactId`,
              NULL                                                       AS `InjuryId`,
              NULL                                                       AS `PersonalInjuredName`,
              NULL                                                       AS `PersonalInjuredId`,
              NULL                                                       AS `InitialTreatmentId`,
              NULL                                                       AS `ContactCodeId`,
              NULL                                                       AS `RecordableId`,
              NULL                                                       AS `RestrictedWorkId`,
              NULL                                                       AS `LostTimeStart`,
              NULL                                                       AS `LostTimeEnd`,
              NULL                                                       AS `AdjustmentDays`,
              NULL                                                       AS `TotalDaysOff`,
              NULL                                                       AS `InjuryDescription`,
              NULL                                                       AS `ContactAgencyId`,
              NULL                                                       AS `SpillReleaseId`,
              NULL                                                       AS `SourceId`,
              NULL                                                       AS `DurationValue`,
              NULL                                                       AS `DurationUnitId`,
              NULL                                                       AS `QuantityValue`,
              NULL                                                       AS `QuantityUnitId`,
              NULL                                                       AS `QuantityRecoveredValue`,
              NULL                                                       AS `RecoveredUnitId`,
              NULL                                                       AS `WhatWasIt`,
              NULL                                                       AS `HowDidSROccur`,
              NULL                                                       AS `IsReportable`,
              NULL                                                       AS `SpRelAgencyId`,
              NULL                                                       AS `TrafficViolationId`,
              NULL                                                       AS `TVDriverName`,
              NULL                                                       AS `TVDriverLicence`,
              NULL                                                       AS `TVVehicleTypeId`,
              NULL                                                       AS `TVVehicleLicence`,
              NULL                                                       AS `Details`,
              NULL                                                       AS `ValueOfFine`,
              NULL                                                       AS `TicketNumber`,
              NULL                                                       AS `HowDidThatOccur`,
              `abcantrackv2`.`vehicle_damage`.`VehicleDamageId`          AS `VehicleDamageId`,
              `abcantrackv2`.`vehicle_damage`.`DriverName`               AS `DriverName`,
              `abcantrackv2`.`vehicle_damage`.`DriverLicence`            AS `DriverLicence`,
              `abcantrackv2`.`vehicle_damage`.`VehicleTypeId`            AS `VehicleTypeId`,
              `abcantrackv2`.`vehicle_damage`.`VehicleLicence`           AS `VehicleLicence`,
              `abcantrackv2`.`vehicle_damage`.`HowDidThatDone`           AS `HowDidThatDone`,
              `abcantrackv2`.`vehicle_damage`.`DamageDescription`        AS `DamageDescription`,
              NULL                                                       AS `IllnessId`,
              NULL                                                       AS `PersonalAfflictedName`,
              NULL                                                       AS `PersonalAfflictedId`,
              NULL                                                       AS `IllRestrictedWorkId`,
              NULL                                                       AS `IllInitialTreatmentId`,
              NULL                                                       AS `IllLostTimeStart`,
              NULL                                                       AS `IllLostTimeEnd`,
              NULL                                                       AS `IllAdjustmentDays`,
              NULL                                                       AS `IllTotalDaysOff`,
              NULL                                                       AS `IllnessDescription`,
              `abcantrackv2`.`vehicle_damage`.`IntEmployeeId1`           AS `IntEmployeeId1`,
              `abcantrackv2`.`vehicle_damage`.`IntEmployeeName1`         AS `IntEmployeeName1`,
              `abcantrackv2`.`vehicle_damage`.`IntEmployeeDept1`         AS `IntEmployeeDept1`,
              `abcantrackv2`.`vehicle_damage`.`IntEmployeeId2`           AS `IntEmployeeId2`,
              `abcantrackv2`.`vehicle_damage`.`IntEmployeeName2`         AS `IntEmployeeName2`,
              `abcantrackv2`.`vehicle_damage`.`IntEmployeeDept2`         AS `IntEmployeeDept2`,
              `abcantrackv2`.`vehicle_damage`.`IntEmployeeId3`           AS `IntEmployeeId3`,
              `abcantrackv2`.`vehicle_damage`.`IntEmployeeName3`         AS `IntEmployeeName3`,
              `abcantrackv2`.`vehicle_damage`.`IntEmployeeDept3`         AS `IntEmployeeDept3`,
              `abcantrackv2`.`vehicle_damage`.`CustomOpenTxt`            AS `CustomOpenTxt`,
              `abcantrackv2`.`vehicle_damage`.`PrimRespondName`          AS `PrimRespondName`,
              `abcantrackv2`.`vehicle_damage`.`PrimRespondId`            AS `PrimRespondId`,
              `abcantrackv2`.`vehicle_damage`.`Description`              AS `Description`,
              `abcantrackv2`.`vehicle_damage`.`EstimatedCost`            AS `EstimatedCost`,
              `abcantrackv2`.`risk_of_recurrence`.`RiskOfRecurrenceName` AS `RiskOfRecurrenceName`,
              `abcantrackv2`.`incident_severity`.`IncidentSeverityName`  AS `IncidentSeverityName`,
              `abcantrackv2`.`event_type`.`EventTypeName`                AS `EventTypeName`,
              `abcantrackv2`.`operation_type`.`OperationTypeName`        AS `OperationTypeName`,
              `abcantrackv2`.`location1`.`Location1Name`                 AS `Location1Name`,
              `abcantrackv2`.`location2`.`Location2Name`                 AS `Location2Name`,
              `abcantrackv2`.`location3`.`Location3Name`                 AS `Location3Name`,
              `abcantrackv2`.`location4`.`Location4Name`                 AS `Location4Name`,
              `abcantrackv2`.`inv_status`.`InvStatusName`                AS `InvStatusName`
            FROM ((((((((((((`abcantrackv2`.`vehicle_damage`
              JOIN `abcantrackv2`.`incident`
                ON ((`abcantrackv2`.`vehicle_damage`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`))) JOIN
              `abcantrackv2`.`impact_sub_type` ON ((`abcantrackv2`.`vehicle_damage`.`ImpactSubTypeId` =
                                                    `abcantrackv2`.`impact_sub_type`.`ImpactSubTypeId`))) JOIN
              `abcantrackv2`.`impact_type` ON ((`abcantrackv2`.`impact_sub_type`.`ImpactTypeId` =
                                                `abcantrackv2`.`impact_type`.`ImpactTypeId`))) LEFT JOIN
              `abcantrackv2`.`event_type`
                ON ((`abcantrackv2`.`event_type`.`EventTypeId` = `abcantrackv2`.`incident`.`EventTypeId`))) LEFT JOIN
              `abcantrackv2`.`operation_type` ON ((`abcantrackv2`.`operation_type`.`OperationTypeId` =
                                                   `abcantrackv2`.`incident`.`OperationTypeId`))) LEFT JOIN
              `abcantrackv2`.`incident_severity` ON ((`abcantrackv2`.`incident_severity`.`IncidentSeverityId` =
                                                      `abcantrackv2`.`incident`.`IncidentSeverityId`))) LEFT JOIN
              `abcantrackv2`.`risk_of_recurrence` ON ((`abcantrackv2`.`risk_of_recurrence`.`RiskOfRecurrenceId` =
                                                       `abcantrackv2`.`incident`.`RiskOfRecurrenceId`))) LEFT JOIN
              `abcantrackv2`.`inv_status`
                ON ((`abcantrackv2`.`inv_status`.`InvStatusId` = `abcantrackv2`.`incident`.`InvStatusId`))) LEFT JOIN
              `abcantrackv2`.`location1`
                ON ((`abcantrackv2`.`location1`.`Location1Id` = `abcantrackv2`.`incident`.`Location1Id`))) LEFT JOIN
              `abcantrackv2`.`location2`
                ON ((`abcantrackv2`.`location2`.`Location2Id` = `abcantrackv2`.`incident`.`Location2Id`))) LEFT JOIN
              `abcantrackv2`.`location3`
                ON ((`abcantrackv2`.`location3`.`Location3Id` = `abcantrackv2`.`incident`.`Location3Id`))) LEFT JOIN
              `abcantrackv2`.`location4`
                ON ((`abcantrackv2`.`location4`.`Location4Id` = `abcantrackv2`.`incident`.`Location4Id`)));
