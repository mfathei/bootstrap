CREATE VIEW ABCanTrackV2.test AS
  SELECT
    `tbl1`.`EmailToId`                                                                            AS `EmailToId`,
    `tbl1`.`TableKeyValue`                                                                        AS `TableKeyValue`,
    `tbl1`.`EmailTypeId`                                                                          AS `EmailTypeId`,
    `tbl1`.`EmployeeId`                                                                           AS `EmployeeId`,
    `tbl1`.`OrgId`                                                                                AS `OrgId`,
    `tbl1`.`GroupId`                                                                              AS `GroupId`,
    `tbl1`.`TableName`                                                                            AS `TableName`,
    `tbl2`.`EmailToEscId`                                                                         AS `EmailToEscId`,
    `tbl2`.`OrgId`                                                                                AS `EscOrgid`,
    `tbl2`.`EmployeeId`                                                                           AS `EscEmployeeId`,
    `tbl2`.`GroupId`                                                                              AS `EscGroupId`,
    `email_to_fun`(`tbl2`.`OrgId`, `tbl2`.`GroupId`, `tbl2`.`EmployeeId`, 1, 'corrective_action') AS `DaysStart`,
    `email_to_fun`(`tbl2`.`OrgId`, `tbl2`.`GroupId`, `tbl2`.`EmployeeId`, 2, 'corrective_action') AS `DaysFreq`,
    `email_to_fun`(`tbl2`.`OrgId`, `tbl2`.`GroupId`, `tbl2`.`EmployeeId`, 1, 'incident')          AS `DaysStartInc`,
    `email_to_fun`(`tbl2`.`OrgId`, `tbl2`.`GroupId`, `tbl2`.`EmployeeId`, 2, 'incident')          AS `DaysFreqInc`,
    `tbl2`.`LastSentDate`                                                                         AS `LastSentDate`,
    `tbl2`.`TableName`                                                                            AS `EscTableName`
  FROM (`abcantrackv2`.`email_to` `tbl1` LEFT JOIN `abcantrackv2`.`email_to_esc` `tbl2`
      ON (((`tbl1`.`OrgId` = `tbl2`.`OrgId`) AND (`tbl1`.`GroupId` = `tbl2`.`GroupId`) AND
           (`tbl1`.`EmployeeId` = `tbl2`.`EmployeeId`))))
  UNION ALL SELECT
              `tbl3`.`EmailToId`                                                                            AS `EmailToId`,
              `tbl3`.`TableKeyValue`                                                                        AS `TableKeyValue`,
              `tbl3`.`EmailTypeId`                                                                          AS `EmailTypeId`,
              `tbl3`.`EmployeeId`                                                                           AS `EmployeeId`,
              `tbl3`.`OrgId`                                                                                AS `OrgId`,
              `tbl3`.`GroupId`                                                                              AS `GroupId`,
              `tbl3`.`TableName`                                                                            AS `TableName`,
              `tbl4`.`EmailToEscId`                                                                         AS `EmailToEscId`,
              `tbl4`.`OrgId`                                                                                AS `EscOrgId`,
              `tbl4`.`EmployeeId`                                                                           AS `EscEmployeeId`,
              `tbl4`.`GroupId`                                                                              AS `EscGroupId`,
              `email_to_fun`(`tbl4`.`OrgId`, `tbl4`.`GroupId`, `tbl4`.`EmployeeId`, 1,
                             'corrective_action')                                                           AS `DaysStart`,
              `email_to_fun`(`tbl4`.`OrgId`, `tbl4`.`GroupId`, `tbl4`.`EmployeeId`, 2,
                             'corrective_action')                                                           AS `DaysFreq`,
              `email_to_fun`(`tbl4`.`OrgId`, `tbl4`.`GroupId`, `tbl4`.`EmployeeId`, 1,
                             'incident')                                                                    AS `DaysStartInc`,
              `email_to_fun`(`tbl4`.`OrgId`, `tbl4`.`GroupId`, `tbl4`.`EmployeeId`, 2,
                             'incident')                                                                    AS `DaysFreqInc`,
              `tbl4`.`LastSentDate`                                                                         AS `LastSentDate`,
              `tbl4`.`TableName`                                                                            AS `EscTableName`
            FROM (`abcantrackv2`.`email_to_esc` `tbl4` LEFT JOIN `abcantrackv2`.`email_to` `tbl3`
                ON (((`tbl3`.`OrgId` = `tbl4`.`OrgId`) AND (`tbl3`.`GroupId` = `tbl4`.`GroupId`) AND
                     (`tbl3`.`EmployeeId` = `tbl4`.`EmployeeId`))));
