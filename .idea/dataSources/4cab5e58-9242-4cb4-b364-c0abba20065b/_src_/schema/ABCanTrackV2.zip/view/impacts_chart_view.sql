CREATE VIEW ABCanTrackV2.impacts_chart_view AS
  SELECT
    `abcantrackv2`.`incident`.`IncidentId`                     AS `IncidentId`,
    `abcantrackv2`.`impact_type`.`OrgId`                       AS `OrgId`,
    `abcantrackv2`.`incident`.`IsDeleted`                      AS `IsDeleted`,
    `abcantrackv2`.`incident`.`IncidentDate`                   AS `IncidentDate`,
    `abcantrackv2`.`incident`.`EventTypeId`                    AS `EventTypeId`,
    `abcantrackv2`.`incident`.`IsEmerRP`                       AS `IsEmerRP`,
    `abcantrackv2`.`incident`.`Location1Id`                    AS `Location1Id`,
    `abcantrackv2`.`incident`.`Location2Id`                    AS `Location2Id`,
    `abcantrackv2`.`incident`.`Location3Id`                    AS `Location3Id`,
    `abcantrackv2`.`incident`.`Location4Id`                    AS `Location4Id`,
    `abcantrackv2`.`incident`.`OperationTypeId`                AS `OperationTypeId`,
    `abcantrackv2`.`incident`.`RiskOfRecurrenceId`             AS `RiskOfRecurrenceId`,
    `abcantrackv2`.`incident`.`InvStatusId`                    AS `InvStatusId`,
    `abcantrackv2`.`incident`.`IncidentSeverityId`             AS `IncidentSeverityId`,
    `abcantrackv2`.`incident`.`InsuranceCost`                  AS `InsuranceCost`,
    `abcantrackv2`.`incident`.`OtherCost`                      AS `OtherCost`,
    `abcantrackv2`.`incident`.`RepairCost`                     AS `RepairCost`,
    `abcantrackv2`.`incident`.`ResponseCost`                   AS `ResponseCost`,
    `abcantrackv2`.`incident`.`TotalCost`                      AS `TotalCost`,
    `abcantrackv2`.`incident`.`WCBCost`                        AS `WCBCost`,
    `abcantrackv2`.`impact_type`.`ImpactTypeId`                AS `ImpactTypeId`,
    `abcantrackv2`.`impact_type`.`ImpactTypeName`              AS `ImpactTypeName`,
    `abcantrackv2`.`illness`.`ImpactSubTypeId`                 AS `ImpactSubTypeId`,
    `abcantrackv2`.`impact_sub_type`.`ImpactSubTypeName`       AS `ImpactSubTypeName`,
    `abcantrackv2`.`risk_of_recurrence`.`RiskOfRecurrenceName` AS `RiskOfRecurrenceName`,
    `abcantrackv2`.`incident_severity`.`IncidentSeverityName`  AS `IncidentSeverityName`,
    `abcantrackv2`.`event_type`.`EventTypeName`                AS `EventTypeName`,
    `abcantrackv2`.`operation_type`.`OperationTypeName`        AS `OperationTypeName`,
    `abcantrackv2`.`location1`.`Location1Name`                 AS `Location1Name`,
    `abcantrackv2`.`location2`.`Location2Name`                 AS `Location2Name`,
    `abcantrackv2`.`location3`.`Location3Name`                 AS `Location3Name`,
    `abcantrackv2`.`location4`.`Location4Name`                 AS `Location4Name`,
    `abcantrackv2`.`inv_status`.`InvStatusName`                AS `InvStatusName`
  FROM (((`abcantrackv2`.`illness`
    JOIN `abcantrackv2`.`impact_sub_type`
      ON ((`abcantrackv2`.`illness`.`ImpactSubTypeId` = `abcantrackv2`.`impact_sub_type`.`ImpactSubTypeId`))) JOIN
    `abcantrackv2`.`impact_type`
      ON ((`abcantrackv2`.`impact_sub_type`.`ImpactTypeId` = `abcantrackv2`.`impact_type`.`ImpactTypeId`))) JOIN
    (((((((((`abcantrackv2`.`incident`
      LEFT JOIN `abcantrackv2`.`event_type`
        ON ((`abcantrackv2`.`event_type`.`EventTypeId` = `abcantrackv2`.`incident`.`EventTypeId`))) LEFT JOIN
      `abcantrackv2`.`operation_type` ON ((`abcantrackv2`.`operation_type`.`OperationTypeId` =
                                           `abcantrackv2`.`incident`.`OperationTypeId`))) LEFT JOIN
      `abcantrackv2`.`incident_severity` ON ((`abcantrackv2`.`incident_severity`.`IncidentSeverityId` =
                                              `abcantrackv2`.`incident`.`IncidentSeverityId`))) LEFT JOIN
      `abcantrackv2`.`risk_of_recurrence` ON ((`abcantrackv2`.`risk_of_recurrence`.`RiskOfRecurrenceId` =
                                               `abcantrackv2`.`incident`.`RiskOfRecurrenceId`))) LEFT JOIN
      `abcantrackv2`.`inv_status`
        ON ((`abcantrackv2`.`inv_status`.`InvStatusId` = `abcantrackv2`.`incident`.`InvStatusId`))) LEFT JOIN
      `abcantrackv2`.`location1`
        ON ((`abcantrackv2`.`location1`.`Location1Id` = `abcantrackv2`.`incident`.`Location1Id`))) LEFT JOIN
      `abcantrackv2`.`location2`
        ON ((`abcantrackv2`.`location2`.`Location2Id` = `abcantrackv2`.`incident`.`Location2Id`))) LEFT JOIN
      `abcantrackv2`.`location3`
        ON ((`abcantrackv2`.`location3`.`Location3Id` = `abcantrackv2`.`incident`.`Location3Id`))) LEFT JOIN
      `abcantrackv2`.`location4`
        ON ((`abcantrackv2`.`location4`.`Location4Id` = `abcantrackv2`.`incident`.`Location4Id`)))
      ON ((`abcantrackv2`.`illness`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)))
  UNION ALL SELECT
              `abcantrackv2`.`incident`.`IncidentId`                     AS `IncidentId`,
              `abcantrackv2`.`incident`.`OrgId`                          AS `OrgId`,
              `abcantrackv2`.`incident`.`IsDeleted`                      AS `IsDeleted`,
              `abcantrackv2`.`incident`.`IncidentDate`                   AS `IncidentDate`,
              `abcantrackv2`.`incident`.`EventTypeId`                    AS `EventTypeId`,
              `abcantrackv2`.`incident`.`IsEmerRP`                       AS `IsEmerRP`,
              `abcantrackv2`.`incident`.`Location1Id`                    AS `Location1Id`,
              `abcantrackv2`.`incident`.`Location2Id`                    AS `Location2Id`,
              `abcantrackv2`.`incident`.`Location3Id`                    AS `Location3Id`,
              `abcantrackv2`.`incident`.`Location4Id`                    AS `Location4Id`,
              `abcantrackv2`.`incident`.`OperationTypeId`                AS `OperationTypeId`,
              `abcantrackv2`.`incident`.`RiskOfRecurrenceId`             AS `RiskOfRecurrenceId`,
              `abcantrackv2`.`incident`.`InvStatusId`                    AS `InvStatusId`,
              `abcantrackv2`.`incident`.`IncidentSeverityId`             AS `IncidentSeverityId`,
              `abcantrackv2`.`incident`.`InsuranceCost`                  AS `InsuranceCost`,
              `abcantrackv2`.`incident`.`OtherCost`                      AS `OtherCost`,
              `abcantrackv2`.`incident`.`RepairCost`                     AS `RepairCost`,
              `abcantrackv2`.`incident`.`ResponseCost`                   AS `ResponseCost`,
              `abcantrackv2`.`incident`.`TotalCost`                      AS `TotalCost`,
              `abcantrackv2`.`incident`.`WCBCost`                        AS `WCBCost`,
              `abcantrackv2`.`impact_type`.`ImpactTypeId`                AS `ImpactTypeId`,
              `abcantrackv2`.`impact_type`.`ImpactTypeName`              AS `ImpactTypeName`,
              `abcantrackv2`.`impact`.`ImpactSubTypeId`                  AS `ImpactSubTypeId`,
              `abcantrackv2`.`impact_sub_type`.`ImpactSubTypeName`       AS `ImpactSubTypeName`,
              `abcantrackv2`.`risk_of_recurrence`.`RiskOfRecurrenceName` AS `RiskOfRecurrenceName`,
              `abcantrackv2`.`incident_severity`.`IncidentSeverityName`  AS `IncidentSeverityName`,
              `abcantrackv2`.`event_type`.`EventTypeName`                AS `EventTypeName`,
              `abcantrackv2`.`operation_type`.`OperationTypeName`        AS `OperationTypeName`,
              `abcantrackv2`.`location1`.`Location1Name`                 AS `Location1Name`,
              `abcantrackv2`.`location2`.`Location2Name`                 AS `Location2Name`,
              `abcantrackv2`.`location3`.`Location3Name`                 AS `Location3Name`,
              `abcantrackv2`.`location4`.`Location4Name`                 AS `Location4Name`,
              `abcantrackv2`.`inv_status`.`InvStatusName`                AS `InvStatusName`
            FROM (((`abcantrackv2`.`impact`
              JOIN `abcantrackv2`.`impact_sub_type` ON ((`abcantrackv2`.`impact`.`ImpactSubTypeId` =
                                                         `abcantrackv2`.`impact_sub_type`.`ImpactSubTypeId`))) JOIN
              `abcantrackv2`.`impact_type` ON ((`abcantrackv2`.`impact_sub_type`.`ImpactTypeId` =
                                                `abcantrackv2`.`impact_type`.`ImpactTypeId`))) JOIN
              (((((((((`abcantrackv2`.`incident`
                LEFT JOIN `abcantrackv2`.`event_type`
                  ON ((`abcantrackv2`.`event_type`.`EventTypeId` = `abcantrackv2`.`incident`.`EventTypeId`))) LEFT JOIN
                `abcantrackv2`.`operation_type` ON ((`abcantrackv2`.`operation_type`.`OperationTypeId` =
                                                     `abcantrackv2`.`incident`.`OperationTypeId`))) LEFT JOIN
                `abcantrackv2`.`incident_severity` ON ((`abcantrackv2`.`incident_severity`.`IncidentSeverityId` =
                                                        `abcantrackv2`.`incident`.`IncidentSeverityId`))) LEFT JOIN
                `abcantrackv2`.`risk_of_recurrence` ON ((`abcantrackv2`.`risk_of_recurrence`.`RiskOfRecurrenceId` =
                                                         `abcantrackv2`.`incident`.`RiskOfRecurrenceId`))) LEFT JOIN
                `abcantrackv2`.`inv_status`
                  ON ((`abcantrackv2`.`inv_status`.`InvStatusId` = `abcantrackv2`.`incident`.`InvStatusId`))) LEFT JOIN
                `abcantrackv2`.`location1`
                  ON ((`abcantrackv2`.`location1`.`Location1Id` = `abcantrackv2`.`incident`.`Location1Id`))) LEFT JOIN
                `abcantrackv2`.`location2`
                  ON ((`abcantrackv2`.`location2`.`Location2Id` = `abcantrackv2`.`incident`.`Location2Id`))) LEFT JOIN
                `abcantrackv2`.`location3`
                  ON ((`abcantrackv2`.`location3`.`Location3Id` = `abcantrackv2`.`incident`.`Location3Id`))) LEFT JOIN
                `abcantrackv2`.`location4`
                  ON ((`abcantrackv2`.`location4`.`Location4Id` = `abcantrackv2`.`incident`.`Location4Id`)))
                ON ((`abcantrackv2`.`impact`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)))
  UNION ALL SELECT
              `abcantrackv2`.`incident`.`IncidentId`                     AS `IncidentId`,
              `abcantrackv2`.`incident`.`OrgId`                          AS `OrgId`,
              `abcantrackv2`.`incident`.`IsDeleted`                      AS `IsDeleted`,
              `abcantrackv2`.`incident`.`IncidentDate`                   AS `IncidentDate`,
              `abcantrackv2`.`incident`.`EventTypeId`                    AS `EventTypeId`,
              `abcantrackv2`.`incident`.`IsEmerRP`                       AS `IsEmerRP`,
              `abcantrackv2`.`incident`.`Location1Id`                    AS `Location1Id`,
              `abcantrackv2`.`incident`.`Location2Id`                    AS `Location2Id`,
              `abcantrackv2`.`incident`.`Location3Id`                    AS `Location3Id`,
              `abcantrackv2`.`incident`.`Location4Id`                    AS `Location4Id`,
              `abcantrackv2`.`incident`.`OperationTypeId`                AS `OperationTypeId`,
              `abcantrackv2`.`incident`.`RiskOfRecurrenceId`             AS `RiskOfRecurrenceId`,
              `abcantrackv2`.`incident`.`InvStatusId`                    AS `InvStatusId`,
              `abcantrackv2`.`incident`.`IncidentSeverityId`             AS `IncidentSeverityId`,
              `abcantrackv2`.`incident`.`InsuranceCost`                  AS `InsuranceCost`,
              `abcantrackv2`.`incident`.`OtherCost`                      AS `OtherCost`,
              `abcantrackv2`.`incident`.`RepairCost`                     AS `RepairCost`,
              `abcantrackv2`.`incident`.`ResponseCost`                   AS `ResponseCost`,
              `abcantrackv2`.`incident`.`TotalCost`                      AS `TotalCost`,
              `abcantrackv2`.`incident`.`WCBCost`                        AS `WCBCost`,
              `abcantrackv2`.`impact_type`.`ImpactTypeId`                AS `ImpactTypeId`,
              `abcantrackv2`.`impact_type`.`ImpactTypeName`              AS `ImpactTypeName`,
              `abcantrackv2`.`injury`.`ImpactSubTypeId`                  AS `ImpactSubTypeId`,
              `abcantrackv2`.`impact_sub_type`.`ImpactSubTypeName`       AS `ImpactSubTypeName`,
              `abcantrackv2`.`risk_of_recurrence`.`RiskOfRecurrenceName` AS `RiskOfRecurrenceName`,
              `abcantrackv2`.`incident_severity`.`IncidentSeverityName`  AS `IncidentSeverityName`,
              `abcantrackv2`.`event_type`.`EventTypeName`                AS `EventTypeName`,
              `abcantrackv2`.`operation_type`.`OperationTypeName`        AS `OperationTypeName`,
              `abcantrackv2`.`location1`.`Location1Name`                 AS `Location1Name`,
              `abcantrackv2`.`location2`.`Location2Name`                 AS `Location2Name`,
              `abcantrackv2`.`location3`.`Location3Name`                 AS `Location3Name`,
              `abcantrackv2`.`location4`.`Location4Name`                 AS `Location4Name`,
              `abcantrackv2`.`inv_status`.`InvStatusName`                AS `InvStatusName`
            FROM (((`abcantrackv2`.`injury`
              JOIN `abcantrackv2`.`impact_sub_type` ON ((`abcantrackv2`.`injury`.`ImpactSubTypeId` =
                                                         `abcantrackv2`.`impact_sub_type`.`ImpactSubTypeId`))) JOIN
              `abcantrackv2`.`impact_type` ON ((`abcantrackv2`.`impact_sub_type`.`ImpactTypeId` =
                                                `abcantrackv2`.`impact_type`.`ImpactTypeId`))) JOIN
              (((((((((`abcantrackv2`.`incident`
                LEFT JOIN `abcantrackv2`.`event_type`
                  ON ((`abcantrackv2`.`event_type`.`EventTypeId` = `abcantrackv2`.`incident`.`EventTypeId`))) LEFT JOIN
                `abcantrackv2`.`operation_type` ON ((`abcantrackv2`.`operation_type`.`OperationTypeId` =
                                                     `abcantrackv2`.`incident`.`OperationTypeId`))) LEFT JOIN
                `abcantrackv2`.`incident_severity` ON ((`abcantrackv2`.`incident_severity`.`IncidentSeverityId` =
                                                        `abcantrackv2`.`incident`.`IncidentSeverityId`))) LEFT JOIN
                `abcantrackv2`.`risk_of_recurrence` ON ((`abcantrackv2`.`risk_of_recurrence`.`RiskOfRecurrenceId` =
                                                         `abcantrackv2`.`incident`.`RiskOfRecurrenceId`))) LEFT JOIN
                `abcantrackv2`.`inv_status`
                  ON ((`abcantrackv2`.`inv_status`.`InvStatusId` = `abcantrackv2`.`incident`.`InvStatusId`))) LEFT JOIN
                `abcantrackv2`.`location1`
                  ON ((`abcantrackv2`.`location1`.`Location1Id` = `abcantrackv2`.`incident`.`Location1Id`))) LEFT JOIN
                `abcantrackv2`.`location2`
                  ON ((`abcantrackv2`.`location2`.`Location2Id` = `abcantrackv2`.`incident`.`Location2Id`))) LEFT JOIN
                `abcantrackv2`.`location3`
                  ON ((`abcantrackv2`.`location3`.`Location3Id` = `abcantrackv2`.`incident`.`Location3Id`))) LEFT JOIN
                `abcantrackv2`.`location4`
                  ON ((`abcantrackv2`.`location4`.`Location4Id` = `abcantrackv2`.`incident`.`Location4Id`)))
                ON ((`abcantrackv2`.`injury`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)))
  UNION ALL SELECT
              `abcantrackv2`.`incident`.`IncidentId`                     AS `IncidentId`,
              `abcantrackv2`.`incident`.`OrgId`                          AS `OrgId`,
              `abcantrackv2`.`incident`.`IsDeleted`                      AS `IsDeleted`,
              `abcantrackv2`.`incident`.`IncidentDate`                   AS `IncidentDate`,
              `abcantrackv2`.`incident`.`EventTypeId`                    AS `EventTypeId`,
              `abcantrackv2`.`incident`.`IsEmerRP`                       AS `IsEmerRP`,
              `abcantrackv2`.`incident`.`Location1Id`                    AS `Location1Id`,
              `abcantrackv2`.`incident`.`Location2Id`                    AS `Location2Id`,
              `abcantrackv2`.`incident`.`Location3Id`                    AS `Location3Id`,
              `abcantrackv2`.`incident`.`Location4Id`                    AS `Location4Id`,
              `abcantrackv2`.`incident`.`OperationTypeId`                AS `OperationTypeId`,
              `abcantrackv2`.`incident`.`RiskOfRecurrenceId`             AS `RiskOfRecurrenceId`,
              `abcantrackv2`.`incident`.`InvStatusId`                    AS `InvStatusId`,
              `abcantrackv2`.`incident`.`IncidentSeverityId`             AS `IncidentSeverityId`,
              `abcantrackv2`.`incident`.`InsuranceCost`                  AS `InsuranceCost`,
              `abcantrackv2`.`incident`.`OtherCost`                      AS `OtherCost`,
              `abcantrackv2`.`incident`.`RepairCost`                     AS `RepairCost`,
              `abcantrackv2`.`incident`.`ResponseCost`                   AS `ResponseCost`,
              `abcantrackv2`.`incident`.`TotalCost`                      AS `TotalCost`,
              `abcantrackv2`.`incident`.`WCBCost`                        AS `WCBCost`,
              `abcantrackv2`.`impact_type`.`ImpactTypeId`                AS `ImpactTypeId`,
              `abcantrackv2`.`impact_type`.`ImpactTypeName`              AS `ImpactTypeName`,
              `abcantrackv2`.`spill_release`.`ImpactSubTypeId`           AS `ImpactSubTypeId`,
              `abcantrackv2`.`impact_sub_type`.`ImpactSubTypeName`       AS `ImpactSubTypeName`,
              `abcantrackv2`.`risk_of_recurrence`.`RiskOfRecurrenceName` AS `RiskOfRecurrenceName`,
              `abcantrackv2`.`incident_severity`.`IncidentSeverityName`  AS `IncidentSeverityName`,
              `abcantrackv2`.`event_type`.`EventTypeName`                AS `EventTypeName`,
              `abcantrackv2`.`operation_type`.`OperationTypeName`        AS `OperationTypeName`,
              `abcantrackv2`.`location1`.`Location1Name`                 AS `Location1Name`,
              `abcantrackv2`.`location2`.`Location2Name`                 AS `Location2Name`,
              `abcantrackv2`.`location3`.`Location3Name`                 AS `Location3Name`,
              `abcantrackv2`.`location4`.`Location4Name`                 AS `Location4Name`,
              `abcantrackv2`.`inv_status`.`InvStatusName`                AS `InvStatusName`
            FROM (((`abcantrackv2`.`spill_release`
              JOIN `abcantrackv2`.`impact_sub_type` ON ((`abcantrackv2`.`spill_release`.`ImpactSubTypeId` =
                                                         `abcantrackv2`.`impact_sub_type`.`ImpactSubTypeId`))) JOIN
              `abcantrackv2`.`impact_type` ON ((`abcantrackv2`.`impact_sub_type`.`ImpactTypeId` =
                                                `abcantrackv2`.`impact_type`.`ImpactTypeId`))) JOIN
              (((((((((`abcantrackv2`.`incident`
                LEFT JOIN `abcantrackv2`.`event_type`
                  ON ((`abcantrackv2`.`event_type`.`EventTypeId` = `abcantrackv2`.`incident`.`EventTypeId`))) LEFT JOIN
                `abcantrackv2`.`operation_type` ON ((`abcantrackv2`.`operation_type`.`OperationTypeId` =
                                                     `abcantrackv2`.`incident`.`OperationTypeId`))) LEFT JOIN
                `abcantrackv2`.`incident_severity` ON ((`abcantrackv2`.`incident_severity`.`IncidentSeverityId` =
                                                        `abcantrackv2`.`incident`.`IncidentSeverityId`))) LEFT JOIN
                `abcantrackv2`.`risk_of_recurrence` ON ((`abcantrackv2`.`risk_of_recurrence`.`RiskOfRecurrenceId` =
                                                         `abcantrackv2`.`incident`.`RiskOfRecurrenceId`))) LEFT JOIN
                `abcantrackv2`.`inv_status`
                  ON ((`abcantrackv2`.`inv_status`.`InvStatusId` = `abcantrackv2`.`incident`.`InvStatusId`))) LEFT JOIN
                `abcantrackv2`.`location1`
                  ON ((`abcantrackv2`.`location1`.`Location1Id` = `abcantrackv2`.`incident`.`Location1Id`))) LEFT JOIN
                `abcantrackv2`.`location2`
                  ON ((`abcantrackv2`.`location2`.`Location2Id` = `abcantrackv2`.`incident`.`Location2Id`))) LEFT JOIN
                `abcantrackv2`.`location3`
                  ON ((`abcantrackv2`.`location3`.`Location3Id` = `abcantrackv2`.`incident`.`Location3Id`))) LEFT JOIN
                `abcantrackv2`.`location4`
                  ON ((`abcantrackv2`.`location4`.`Location4Id` = `abcantrackv2`.`incident`.`Location4Id`)))
                ON ((`abcantrackv2`.`spill_release`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)))
  UNION ALL SELECT
              `abcantrackv2`.`incident`.`IncidentId`                     AS `IncidentId`,
              `abcantrackv2`.`incident`.`OrgId`                          AS `OrgId`,
              `abcantrackv2`.`incident`.`IsDeleted`                      AS `IsDeleted`,
              `abcantrackv2`.`incident`.`IncidentDate`                   AS `IncidentDate`,
              `abcantrackv2`.`incident`.`EventTypeId`                    AS `EventTypeId`,
              `abcantrackv2`.`incident`.`IsEmerRP`                       AS `IsEmerRP`,
              `abcantrackv2`.`incident`.`Location1Id`                    AS `Location1Id`,
              `abcantrackv2`.`incident`.`Location2Id`                    AS `Location2Id`,
              `abcantrackv2`.`incident`.`Location3Id`                    AS `Location3Id`,
              `abcantrackv2`.`incident`.`Location4Id`                    AS `Location4Id`,
              `abcantrackv2`.`incident`.`OperationTypeId`                AS `OperationTypeId`,
              `abcantrackv2`.`incident`.`RiskOfRecurrenceId`             AS `RiskOfRecurrenceId`,
              `abcantrackv2`.`incident`.`InvStatusId`                    AS `InvStatusId`,
              `abcantrackv2`.`incident`.`IncidentSeverityId`             AS `IncidentSeverityId`,
              `abcantrackv2`.`incident`.`InsuranceCost`                  AS `InsuranceCost`,
              `abcantrackv2`.`incident`.`OtherCost`                      AS `OtherCost`,
              `abcantrackv2`.`incident`.`RepairCost`                     AS `RepairCost`,
              `abcantrackv2`.`incident`.`ResponseCost`                   AS `ResponseCost`,
              `abcantrackv2`.`incident`.`TotalCost`                      AS `TotalCost`,
              `abcantrackv2`.`incident`.`WCBCost`                        AS `WCBCost`,
              `abcantrackv2`.`impact_type`.`ImpactTypeId`                AS `ImpactTypeId`,
              `abcantrackv2`.`impact_type`.`ImpactTypeName`              AS `ImpactTypeName`,
              `abcantrackv2`.`traffic_violation`.`ImpactSubTypeId`       AS `ImpactSubTypeId`,
              `abcantrackv2`.`impact_sub_type`.`ImpactSubTypeName`       AS `ImpactSubTypeName`,
              `abcantrackv2`.`risk_of_recurrence`.`RiskOfRecurrenceName` AS `RiskOfRecurrenceName`,
              `abcantrackv2`.`incident_severity`.`IncidentSeverityName`  AS `IncidentSeverityName`,
              `abcantrackv2`.`event_type`.`EventTypeName`                AS `EventTypeName`,
              `abcantrackv2`.`operation_type`.`OperationTypeName`        AS `OperationTypeName`,
              `abcantrackv2`.`location1`.`Location1Name`                 AS `Location1Name`,
              `abcantrackv2`.`location2`.`Location2Name`                 AS `Location2Name`,
              `abcantrackv2`.`location3`.`Location3Name`                 AS `Location3Name`,
              `abcantrackv2`.`location4`.`Location4Name`                 AS `Location4Name`,
              `abcantrackv2`.`inv_status`.`InvStatusName`                AS `InvStatusName`
            FROM (((`abcantrackv2`.`traffic_violation`
              JOIN `abcantrackv2`.`impact_sub_type` ON ((`abcantrackv2`.`traffic_violation`.`ImpactSubTypeId` =
                                                         `abcantrackv2`.`impact_sub_type`.`ImpactSubTypeId`))) JOIN
              `abcantrackv2`.`impact_type` ON ((`abcantrackv2`.`impact_sub_type`.`ImpactTypeId` =
                                                `abcantrackv2`.`impact_type`.`ImpactTypeId`))) JOIN
              (((((((((`abcantrackv2`.`incident`
                LEFT JOIN `abcantrackv2`.`event_type`
                  ON ((`abcantrackv2`.`event_type`.`EventTypeId` = `abcantrackv2`.`incident`.`EventTypeId`))) LEFT JOIN
                `abcantrackv2`.`operation_type` ON ((`abcantrackv2`.`operation_type`.`OperationTypeId` =
                                                     `abcantrackv2`.`incident`.`OperationTypeId`))) LEFT JOIN
                `abcantrackv2`.`incident_severity` ON ((`abcantrackv2`.`incident_severity`.`IncidentSeverityId` =
                                                        `abcantrackv2`.`incident`.`IncidentSeverityId`))) LEFT JOIN
                `abcantrackv2`.`risk_of_recurrence` ON ((`abcantrackv2`.`risk_of_recurrence`.`RiskOfRecurrenceId` =
                                                         `abcantrackv2`.`incident`.`RiskOfRecurrenceId`))) LEFT JOIN
                `abcantrackv2`.`inv_status`
                  ON ((`abcantrackv2`.`inv_status`.`InvStatusId` = `abcantrackv2`.`incident`.`InvStatusId`))) LEFT JOIN
                `abcantrackv2`.`location1`
                  ON ((`abcantrackv2`.`location1`.`Location1Id` = `abcantrackv2`.`incident`.`Location1Id`))) LEFT JOIN
                `abcantrackv2`.`location2`
                  ON ((`abcantrackv2`.`location2`.`Location2Id` = `abcantrackv2`.`incident`.`Location2Id`))) LEFT JOIN
                `abcantrackv2`.`location3`
                  ON ((`abcantrackv2`.`location3`.`Location3Id` = `abcantrackv2`.`incident`.`Location3Id`))) LEFT JOIN
                `abcantrackv2`.`location4`
                  ON ((`abcantrackv2`.`location4`.`Location4Id` = `abcantrackv2`.`incident`.`Location4Id`)))
                ON ((`abcantrackv2`.`traffic_violation`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)))
  UNION ALL SELECT
              `abcantrackv2`.`incident`.`IncidentId`                     AS `IncidentId`,
              `abcantrackv2`.`incident`.`OrgId`                          AS `OrgId`,
              `abcantrackv2`.`incident`.`IsDeleted`                      AS `IsDeleted`,
              `abcantrackv2`.`incident`.`IncidentDate`                   AS `IncidentDate`,
              `abcantrackv2`.`incident`.`EventTypeId`                    AS `EventTypeId`,
              `abcantrackv2`.`incident`.`IsEmerRP`                       AS `IsEmerRP`,
              `abcantrackv2`.`incident`.`Location1Id`                    AS `Location1Id`,
              `abcantrackv2`.`incident`.`Location2Id`                    AS `Location2Id`,
              `abcantrackv2`.`incident`.`Location3Id`                    AS `Location3Id`,
              `abcantrackv2`.`incident`.`Location4Id`                    AS `Location4Id`,
              `abcantrackv2`.`incident`.`OperationTypeId`                AS `OperationTypeId`,
              `abcantrackv2`.`incident`.`RiskOfRecurrenceId`             AS `RiskOfRecurrenceId`,
              `abcantrackv2`.`incident`.`InvStatusId`                    AS `InvStatusId`,
              `abcantrackv2`.`incident`.`IncidentSeverityId`             AS `IncidentSeverityId`,
              `abcantrackv2`.`incident`.`InsuranceCost`                  AS `InsuranceCost`,
              `abcantrackv2`.`incident`.`OtherCost`                      AS `OtherCost`,
              `abcantrackv2`.`incident`.`RepairCost`                     AS `RepairCost`,
              `abcantrackv2`.`incident`.`ResponseCost`                   AS `ResponseCost`,
              `abcantrackv2`.`incident`.`TotalCost`                      AS `TotalCost`,
              `abcantrackv2`.`incident`.`WCBCost`                        AS `WCBCost`,
              `abcantrackv2`.`impact_type`.`ImpactTypeId`                AS `ImpactTypeId`,
              `abcantrackv2`.`impact_type`.`ImpactTypeName`              AS `ImpactTypeName`,
              `abcantrackv2`.`vehicle_damage`.`ImpactSubTypeId`          AS `ImpactSubTypeId`,
              `abcantrackv2`.`impact_sub_type`.`ImpactSubTypeName`       AS `ImpactSubTypeName`,
              `abcantrackv2`.`risk_of_recurrence`.`RiskOfRecurrenceName` AS `RiskOfRecurrenceName`,
              `abcantrackv2`.`incident_severity`.`IncidentSeverityName`  AS `IncidentSeverityName`,
              `abcantrackv2`.`event_type`.`EventTypeName`                AS `EventTypeName`,
              `abcantrackv2`.`operation_type`.`OperationTypeName`        AS `OperationTypeName`,
              `abcantrackv2`.`location1`.`Location1Name`                 AS `Location1Name`,
              `abcantrackv2`.`location2`.`Location2Name`                 AS `Location2Name`,
              `abcantrackv2`.`location3`.`Location3Name`                 AS `Location3Name`,
              `abcantrackv2`.`location4`.`Location4Name`                 AS `Location4Name`,
              `abcantrackv2`.`inv_status`.`InvStatusName`                AS `InvStatusName`
            FROM (((`abcantrackv2`.`vehicle_damage`
              JOIN `abcantrackv2`.`impact_sub_type` ON ((`abcantrackv2`.`vehicle_damage`.`ImpactSubTypeId` =
                                                         `abcantrackv2`.`impact_sub_type`.`ImpactSubTypeId`))) JOIN
              `abcantrackv2`.`impact_type` ON ((`abcantrackv2`.`impact_sub_type`.`ImpactTypeId` =
                                                `abcantrackv2`.`impact_type`.`ImpactTypeId`))) JOIN
              (((((((((`abcantrackv2`.`incident`
                LEFT JOIN `abcantrackv2`.`event_type`
                  ON ((`abcantrackv2`.`event_type`.`EventTypeId` = `abcantrackv2`.`incident`.`EventTypeId`))) LEFT JOIN
                `abcantrackv2`.`operation_type` ON ((`abcantrackv2`.`operation_type`.`OperationTypeId` =
                                                     `abcantrackv2`.`incident`.`OperationTypeId`))) LEFT JOIN
                `abcantrackv2`.`incident_severity` ON ((`abcantrackv2`.`incident_severity`.`IncidentSeverityId` =
                                                        `abcantrackv2`.`incident`.`IncidentSeverityId`))) LEFT JOIN
                `abcantrackv2`.`risk_of_recurrence` ON ((`abcantrackv2`.`risk_of_recurrence`.`RiskOfRecurrenceId` =
                                                         `abcantrackv2`.`incident`.`RiskOfRecurrenceId`))) LEFT JOIN
                `abcantrackv2`.`inv_status`
                  ON ((`abcantrackv2`.`inv_status`.`InvStatusId` = `abcantrackv2`.`incident`.`InvStatusId`))) LEFT JOIN
                `abcantrackv2`.`location1`
                  ON ((`abcantrackv2`.`location1`.`Location1Id` = `abcantrackv2`.`incident`.`Location1Id`))) LEFT JOIN
                `abcantrackv2`.`location2`
                  ON ((`abcantrackv2`.`location2`.`Location2Id` = `abcantrackv2`.`incident`.`Location2Id`))) LEFT JOIN
                `abcantrackv2`.`location3`
                  ON ((`abcantrackv2`.`location3`.`Location3Id` = `abcantrackv2`.`incident`.`Location3Id`))) LEFT JOIN
                `abcantrackv2`.`location4`
                  ON ((`abcantrackv2`.`location4`.`Location4Id` = `abcantrackv2`.`incident`.`Location4Id`)))
                ON ((`abcantrackv2`.`vehicle_damage`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)));
