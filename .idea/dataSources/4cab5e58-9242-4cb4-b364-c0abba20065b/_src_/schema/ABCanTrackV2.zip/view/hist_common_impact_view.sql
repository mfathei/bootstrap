CREATE VIEW ABCanTrackV2.hist_common_impact_view AS
  SELECT
    max(`hinc`.`VersionNumber`)                                                                AS `MAXVN`,
    `hinc`.`HistIncidentId`                                                                    AS `HistIncidentId`,
    `hinc`.`IncidentId`                                                                        AS `IncidentId`,
    concat_ws(', ', `hinj`.`ImpactTypeName`, `himp`.`ImpactTypeName`, `hill`.`ImpactTypeName`, `hsp`.`ImpactTypeName`,
              `hvd`.`ImpactTypeName`, `htv`.`ImpactTypeName`)                                  AS `ImpactTypeName`,
    concat_ws(', ', `hinj`.`ImpactSubTypeName`, `himp`.`ImpactSubTypeName`, `hill`.`ImpactSubTypeName`,
              `hsp`.`ImpactSubTypeName`, `hvd`.`ImpactSubTypeName`, `htv`.`ImpactSubTypeName`) AS `ImpactSubTypeName`,
    concat_ws(', ', `hinj`.`IntEmployeeName1`, `himp`.`IntEmployeeName1`, `hill`.`IntEmployeeName1`,
              `hsp`.`IntEmployeeName1`, `hvd`.`IntEmployeeName1`, `htv`.`IntEmployeeName1`)    AS `IntEmployeeName1`,
    concat_ws(', ', `hinj`.`IntEmployeeName2`, `himp`.`IntEmployeeName2`, `hill`.`IntEmployeeName2`,
              `hsp`.`IntEmployeeName2`, `hvd`.`IntEmployeeName2`, `htv`.`IntEmployeeName2`)    AS `IntEmployeeName2`,
    concat_ws(', ', `hinj`.`IntEmployeeName3`, `himp`.`IntEmployeeName3`, `hill`.`IntEmployeeName3`,
              `hsp`.`IntEmployeeName3`, `hvd`.`IntEmployeeName3`, `htv`.`IntEmployeeName3`)    AS `IntEmployeeName3`,
    concat_ws(', ', `hinj`.`IntEmployeeDept1`, `himp`.`IntEmployeeDept1`, `hill`.`IntEmployeeDept1`,
              `hsp`.`IntEmployeeDept1`, `hvd`.`IntEmployeeDept1`, `htv`.`IntEmployeeDept1`)    AS `IntEmployeeDept1`,
    concat_ws(', ', `hinj`.`IntEmployeeDept2`, `himp`.`IntEmployeeDept2`, `hill`.`IntEmployeeDept2`,
              `hsp`.`IntEmployeeDept2`, `hvd`.`IntEmployeeDept2`, `htv`.`IntEmployeeDept2`)    AS `IntEmployeeDept2`,
    concat_ws(', ', `hinj`.`IntEmployeeDept3`, `himp`.`IntEmployeeDept3`, `hill`.`IntEmployeeDept3`,
              `hsp`.`IntEmployeeDept3`, `hvd`.`IntEmployeeDept3`, `htv`.`IntEmployeeDept3`)    AS `IntEmployeeDept3`,
    concat_ws(', ', `hinj`.`PrimRespondName`, `himp`.`PrimRespondName`, `hill`.`PrimRespondName`,
              `hsp`.`PrimRespondName`, `hvd`.`PrimRespondName`, `htv`.`PrimRespondName`)       AS `PrimRespondName`,
    concat_ws(', ', `hinj`.`ImpactDescription`, `himp`.`ImpactDescription`, `hill`.`ImpactDescription`,
              `hsp`.`ImpactDescription`, `hvd`.`ImpactDescription`, `htv`.`ImpactDescription`) AS `ImpactDescription`,
    concat_ws(', ', `hinj`.`EstimatedCost`, `himp`.`EstimatedCost`, `hill`.`EstimatedCost`, `hsp`.`EstimatedCost`,
              `hvd`.`EstimatedCost`, `htv`.`EstimatedCost`)                                    AS `EstimatedCost`
  FROM ((((((`abcantrackv2`.`hist_incident` `hinc` LEFT JOIN `abcantrackv2`.`hist_injury` `hinj`
      ON ((`hinc`.`HistIncidentId` = `hinj`.`HistIncidentId`))) LEFT JOIN `abcantrackv2`.`hist_impact` `himp`
      ON ((`hinc`.`HistIncidentId` = `himp`.`HistIncidentId`))) LEFT JOIN `abcantrackv2`.`hist_illness` `hill`
      ON ((`hinc`.`HistIncidentId` = `hill`.`HistIncidentId`))) LEFT JOIN `abcantrackv2`.`hist_spill_release` `hsp`
      ON ((`hinc`.`HistIncidentId` = `hsp`.`HistIncidentId`))) LEFT JOIN `abcantrackv2`.`hist_vehicle_damage` `hvd`
      ON ((`hinc`.`HistIncidentId` = `hvd`.`HistIncidentId`))) LEFT JOIN `abcantrackv2`.`hist_traffic_violation` `htv`
      ON ((`hinc`.`HistIncidentId` = `htv`.`HistIncidentId`)))
  GROUP BY `hinc`.`IncidentId`
  HAVING (`MAXVN` = max(`hinc`.`VersionNumber`));
