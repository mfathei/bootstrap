CREATE VIEW ABCanTrackV2.location3_view AS
  SELECT
    `abcantrackv2`.`location3`.`Location3Id`    AS `Location3Id`,
    `abcantrackv2`.`location3`.`Location3Name`  AS `Location3Name`,
    `abcantrackv2`.`location2`.`Location2Id`    AS `Location2Id`,
    `abcantrackv2`.`location2`.`Location2Name`  AS `Location2Name`,
    `abcantrackv2`.`location1`.`Location1Id`    AS `Location1Id`,
    `abcantrackv2`.`location1`.`Location1Name`  AS `Location1Name`,
    `abcantrackv2`.`location3`.`EditingBy`      AS `EditingBy`,
    `abcantrackv2`.`location3`.`LastUpdateDate` AS `LastUpdateDate`,
    `abcantrackv2`.`location3`.`Order`          AS `Order`,
    `abcantrackv2`.`location3`.`Hide`           AS `Hide`,
    `abcantrackv2`.`location1`.`OrgId`          AS `OrgId`
  FROM ((`abcantrackv2`.`location3`
    JOIN `abcantrackv2`.`location2`
      ON ((`abcantrackv2`.`location2`.`Location2Id` = `abcantrackv2`.`location3`.`Location2Id`))) JOIN
    `abcantrackv2`.`location1`
      ON ((`abcantrackv2`.`location1`.`Location1Id` = `abcantrackv2`.`location2`.`Location1Id`)))
  WHERE ((`abcantrackv2`.`location3`.`Hide` = 0) AND (`abcantrackv2`.`location2`.`Hide` = 0) AND
         (`abcantrackv2`.`location1`.`Hide` = 0) AND (`abcantrackv2`.`location3`.`Location3Name` <> '') AND
         (`abcantrackv2`.`location2`.`Location2Name` <> '') AND (`abcantrackv2`.`location1`.`Location1Name` <> ''))
  ORDER BY `abcantrackv2`.`location3`.`Order`;
