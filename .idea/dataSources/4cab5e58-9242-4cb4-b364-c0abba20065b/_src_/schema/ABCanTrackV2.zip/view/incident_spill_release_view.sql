CREATE VIEW ABCanTrackV2.incident_spill_release_view AS
  SELECT
    `abcantrackv2`.`spill_release`.`SpillReleaseId`         AS `SpillReleaseId`,
    `abcantrackv2`.`spill_release`.`IncidentId`             AS `IncidentId`,
    `abcantrackv2`.`spill_release_source`.`SourceName`      AS `SourceId`,
    `abcantrackv2`.`spill_release`.`DurationValue`          AS `DurationValue`,
    `abcantrackv2`.`duration_unit`.`DurationUnitName`       AS `DurationUnitId`,
    `abcantrackv2`.`spill_release`.`QuantityValue`          AS `QuantityValue`,
    `abcantrackv2`.`quantity_unit`.`QuantityUnitName`       AS `QuantityUnitId`,
    `abcantrackv2`.`spill_release`.`QuantityRecoveredValue` AS `QuantityRecoveredValue`,
    `quantity_recovered`.`QuantityUnitName`                 AS `RecoveredUnitId`,
    `abcantrackv2`.`spill_release`.`WhatWasIt`              AS `WhatWasIt`,
    `abcantrackv2`.`spill_release`.`HowDidSROccur`          AS `HowDidSROccur`,
    (CASE `abcantrackv2`.`spill_release`.`IsReportable`
     WHEN '0'
       THEN 'No'
     WHEN '1'
       THEN 'Yes' END)                                      AS `IsReportable`,
    `abcantrackv2`.`sp_rel_agency`.`SpRelAgencyName`        AS `ImpactsExtAgencyId`
  FROM (((((`abcantrackv2`.`spill_release`
    LEFT JOIN `abcantrackv2`.`duration_unit` ON ((`abcantrackv2`.`duration_unit`.`DurationUnitId` =
                                                  `abcantrackv2`.`spill_release`.`DurationUnitId`))) LEFT JOIN
    `abcantrackv2`.`quantity_unit` ON ((`abcantrackv2`.`quantity_unit`.`QuantityUnitId` =
                                        `abcantrackv2`.`spill_release`.`QuantityUnitId`))) LEFT JOIN
    `abcantrackv2`.`quantity_unit` `quantity_recovered`
      ON ((`quantity_recovered`.`QuantityUnitId` = `abcantrackv2`.`spill_release`.`RecoveredUnitId`))) LEFT JOIN
    `abcantrackv2`.`spill_release_source`
      ON ((`abcantrackv2`.`spill_release_source`.`SourceId` = `abcantrackv2`.`spill_release`.`SourceId`))) LEFT JOIN
    `abcantrackv2`.`sp_rel_agency`
      ON ((`abcantrackv2`.`sp_rel_agency`.`SpRelAgencyId` = `abcantrackv2`.`spill_release`.`SpRelAgencyId`)))
  ORDER BY `abcantrackv2`.`spill_release`.`IncidentId` DESC;
