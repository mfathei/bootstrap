CREATE VIEW ABCanTrackV2.impact_view AS
  SELECT
    `abcantrackv2`.`incident`.`IncidentId`                               AS `IncidentId`,
    (SELECT concat_ws(', ', (SELECT group_concat(`abcantrackv2`.`impact_type`.`ImpactTypeName` SEPARATOR ', ')
                             FROM ((`abcantrackv2`.`impact`
                               JOIN `abcantrackv2`.`impact_sub_type`
                                 ON ((`abcantrackv2`.`impact_sub_type`.`ImpactSubTypeId` =
                                      `abcantrackv2`.`impact`.`ImpactSubTypeId`))) JOIN `abcantrackv2`.`impact_type`
                                 ON ((`abcantrackv2`.`impact_sub_type`.`ImpactTypeId` =
                                      `abcantrackv2`.`impact_type`.`ImpactTypeId`)))
                             WHERE (`abcantrackv2`.`impact`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`impact_type`.`ImpactTypeName` SEPARATOR ', ')
                       FROM ((`abcantrackv2`.`injury`
                         JOIN `abcantrackv2`.`impact_sub_type` ON ((`abcantrackv2`.`impact_sub_type`.`ImpactSubTypeId` =
                                                                    `abcantrackv2`.`injury`.`ImpactSubTypeId`))) JOIN
                         `abcantrackv2`.`impact_type` ON ((`abcantrackv2`.`impact_sub_type`.`ImpactTypeId` =
                                                           `abcantrackv2`.`impact_type`.`ImpactTypeId`)))
                       WHERE (`abcantrackv2`.`injury`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`impact_type`.`ImpactTypeName` SEPARATOR ', ')
                       FROM ((`abcantrackv2`.`illness`
                         JOIN `abcantrackv2`.`impact_sub_type` ON ((`abcantrackv2`.`impact_sub_type`.`ImpactSubTypeId` =
                                                                    `abcantrackv2`.`illness`.`ImpactSubTypeId`))) JOIN
                         `abcantrackv2`.`impact_type` ON ((`abcantrackv2`.`impact_sub_type`.`ImpactTypeId` =
                                                           `abcantrackv2`.`impact_type`.`ImpactTypeId`)))
                       WHERE (`abcantrackv2`.`illness`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`impact_type`.`ImpactTypeName` SEPARATOR ', ')
                       FROM ((`abcantrackv2`.`spill_release`
                         JOIN `abcantrackv2`.`impact_sub_type` ON ((`abcantrackv2`.`impact_sub_type`.`ImpactSubTypeId` =
                                                                    `abcantrackv2`.`spill_release`.`ImpactSubTypeId`))) JOIN
                         `abcantrackv2`.`impact_type` ON ((`abcantrackv2`.`impact_sub_type`.`ImpactTypeId` =
                                                           `abcantrackv2`.`impact_type`.`ImpactTypeId`)))
                       WHERE (`abcantrackv2`.`spill_release`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`impact_type`.`ImpactTypeName` SEPARATOR ', ')
                       FROM ((`abcantrackv2`.`vehicle_damage`
                         JOIN `abcantrackv2`.`impact_sub_type` ON ((`abcantrackv2`.`impact_sub_type`.`ImpactSubTypeId` =
                                                                    `abcantrackv2`.`vehicle_damage`.`ImpactSubTypeId`))) JOIN
                         `abcantrackv2`.`impact_type` ON ((`abcantrackv2`.`impact_sub_type`.`ImpactTypeId` =
                                                           `abcantrackv2`.`impact_type`.`ImpactTypeId`)))
                       WHERE (`abcantrackv2`.`vehicle_damage`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`impact_type`.`ImpactTypeName` SEPARATOR ', ')
                       FROM ((`abcantrackv2`.`traffic_violation`
                         JOIN `abcantrackv2`.`impact_sub_type` ON ((`abcantrackv2`.`impact_sub_type`.`ImpactSubTypeId` =
                                                                    `abcantrackv2`.`traffic_violation`.`ImpactSubTypeId`))) JOIN
                         `abcantrackv2`.`impact_type` ON ((`abcantrackv2`.`impact_sub_type`.`ImpactTypeId` =
                                                           `abcantrackv2`.`impact_type`.`ImpactTypeId`)))
                       WHERE (`abcantrackv2`.`traffic_violation`.`IncidentId` =
                              `abcantrackv2`.`incident`.`IncidentId`)))) AS `ImpactTypeId`,
    (SELECT concat_ws(', ', (SELECT group_concat(`abcantrackv2`.`impact_sub_type`.`ImpactSubTypeName` SEPARATOR ', ')
                             FROM (`abcantrackv2`.`impact`
                               JOIN `abcantrackv2`.`impact_sub_type`
                                 ON ((`abcantrackv2`.`impact_sub_type`.`ImpactSubTypeId` =
                                      `abcantrackv2`.`impact`.`ImpactSubTypeId`)))
                             WHERE (`abcantrackv2`.`impact`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`impact_sub_type`.`ImpactSubTypeName` SEPARATOR ', ')
                       FROM (`abcantrackv2`.`injury`
                         JOIN `abcantrackv2`.`impact_sub_type` ON ((`abcantrackv2`.`impact_sub_type`.`ImpactSubTypeId` =
                                                                    `abcantrackv2`.`injury`.`ImpactSubTypeId`)))
                       WHERE (`abcantrackv2`.`injury`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`impact_sub_type`.`ImpactSubTypeName` SEPARATOR ', ')
                       FROM (`abcantrackv2`.`illness`
                         JOIN `abcantrackv2`.`impact_sub_type` ON ((`abcantrackv2`.`impact_sub_type`.`ImpactSubTypeId` =
                                                                    `abcantrackv2`.`illness`.`ImpactSubTypeId`)))
                       WHERE (`abcantrackv2`.`illness`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`impact_sub_type`.`ImpactSubTypeName` SEPARATOR ', ')
                       FROM (`abcantrackv2`.`spill_release`
                         JOIN `abcantrackv2`.`impact_sub_type` ON ((`abcantrackv2`.`impact_sub_type`.`ImpactSubTypeId` =
                                                                    `abcantrackv2`.`spill_release`.`ImpactSubTypeId`)))
                       WHERE (`abcantrackv2`.`spill_release`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`impact_sub_type`.`ImpactSubTypeName` SEPARATOR ', ')
                       FROM (`abcantrackv2`.`vehicle_damage`
                         JOIN `abcantrackv2`.`impact_sub_type` ON ((`abcantrackv2`.`impact_sub_type`.`ImpactSubTypeId` =
                                                                    `abcantrackv2`.`vehicle_damage`.`ImpactSubTypeId`)))
                       WHERE (`abcantrackv2`.`vehicle_damage`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`impact_sub_type`.`ImpactSubTypeName` SEPARATOR ', ')
                       FROM (`abcantrackv2`.`traffic_violation`
                         JOIN `abcantrackv2`.`impact_sub_type` ON ((`abcantrackv2`.`impact_sub_type`.`ImpactSubTypeId` =
                                                                    `abcantrackv2`.`traffic_violation`.`ImpactSubTypeId`)))
                       WHERE (`abcantrackv2`.`traffic_violation`.`IncidentId` =
                              `abcantrackv2`.`incident`.`IncidentId`)))) AS `ImpactSubTypeId`,
    (SELECT concat_ws(', ', (SELECT group_concat(`abcantrackv2`.`impact`.`IntEmployeeName1` SEPARATOR ', ')
                             FROM `abcantrackv2`.`impact`
                             WHERE (`abcantrackv2`.`impact`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`injury`.`IntEmployeeName1` SEPARATOR ', ')
                       FROM `abcantrackv2`.`injury`
                       WHERE (`abcantrackv2`.`injury`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`illness`.`IntEmployeeName1` SEPARATOR ', ')
                       FROM `abcantrackv2`.`illness`
                       WHERE (`abcantrackv2`.`illness`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`spill_release`.`IntEmployeeName1` SEPARATOR ', ')
                       FROM `abcantrackv2`.`spill_release`
                       WHERE (`abcantrackv2`.`spill_release`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`vehicle_damage`.`IntEmployeeName1` SEPARATOR ', ')
                       FROM `abcantrackv2`.`vehicle_damage`
                       WHERE (`abcantrackv2`.`vehicle_damage`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`traffic_violation`.`IntEmployeeName1` SEPARATOR ', ')
                       FROM `abcantrackv2`.`traffic_violation`
                       WHERE (`abcantrackv2`.`traffic_violation`.`IncidentId` =
                              `abcantrackv2`.`incident`.`IncidentId`)))) AS `IntEmployeeName1`,
    (SELECT concat_ws(', ', (SELECT group_concat(`abcantrackv2`.`impact`.`IntEmployeeName2` SEPARATOR ', ')
                             FROM `abcantrackv2`.`impact`
                             WHERE (`abcantrackv2`.`impact`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`injury`.`IntEmployeeName2` SEPARATOR ', ')
                       FROM `abcantrackv2`.`injury`
                       WHERE (`abcantrackv2`.`injury`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`illness`.`IntEmployeeName2` SEPARATOR ', ')
                       FROM `abcantrackv2`.`illness`
                       WHERE (`abcantrackv2`.`illness`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`spill_release`.`IntEmployeeName2` SEPARATOR ', ')
                       FROM `abcantrackv2`.`spill_release`
                       WHERE (`abcantrackv2`.`spill_release`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`vehicle_damage`.`IntEmployeeName2` SEPARATOR ', ')
                       FROM `abcantrackv2`.`vehicle_damage`
                       WHERE (`abcantrackv2`.`vehicle_damage`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`traffic_violation`.`IntEmployeeName2` SEPARATOR ', ')
                       FROM `abcantrackv2`.`traffic_violation`
                       WHERE (`abcantrackv2`.`traffic_violation`.`IncidentId` =
                              `abcantrackv2`.`incident`.`IncidentId`)))) AS `IntEmployeeName2`,
    (SELECT concat_ws(', ', (SELECT group_concat(`abcantrackv2`.`impact`.`IntEmployeeName3` SEPARATOR ', ')
                             FROM `abcantrackv2`.`impact`
                             WHERE (`abcantrackv2`.`impact`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`injury`.`IntEmployeeName3` SEPARATOR ', ')
                       FROM `abcantrackv2`.`injury`
                       WHERE (`abcantrackv2`.`injury`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`illness`.`IntEmployeeName3` SEPARATOR ', ')
                       FROM `abcantrackv2`.`illness`
                       WHERE (`abcantrackv2`.`illness`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`spill_release`.`IntEmployeeName3` SEPARATOR ', ')
                       FROM `abcantrackv2`.`spill_release`
                       WHERE (`abcantrackv2`.`spill_release`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`vehicle_damage`.`IntEmployeeName3` SEPARATOR ', ')
                       FROM `abcantrackv2`.`vehicle_damage`
                       WHERE (`abcantrackv2`.`vehicle_damage`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`traffic_violation`.`IntEmployeeName3` SEPARATOR ', ')
                       FROM `abcantrackv2`.`traffic_violation`
                       WHERE (`abcantrackv2`.`traffic_violation`.`IncidentId` =
                              `abcantrackv2`.`incident`.`IncidentId`)))) AS `IntEmployeeName3`,
    (SELECT concat_ws(', ', (SELECT group_concat(`abcantrackv2`.`impact`.`IntEmployeeDept1` SEPARATOR ', ')
                             FROM `abcantrackv2`.`impact`
                             WHERE (`abcantrackv2`.`impact`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`injury`.`IntEmployeeDept1` SEPARATOR ', ')
                       FROM `abcantrackv2`.`injury`
                       WHERE (`abcantrackv2`.`injury`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`illness`.`IntEmployeeDept1` SEPARATOR ', ')
                       FROM `abcantrackv2`.`illness`
                       WHERE (`abcantrackv2`.`illness`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`spill_release`.`IntEmployeeDept1` SEPARATOR ', ')
                       FROM `abcantrackv2`.`spill_release`
                       WHERE (`abcantrackv2`.`spill_release`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`vehicle_damage`.`IntEmployeeDept1` SEPARATOR ', ')
                       FROM `abcantrackv2`.`vehicle_damage`
                       WHERE (`abcantrackv2`.`vehicle_damage`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`traffic_violation`.`IntEmployeeDept1` SEPARATOR ', ')
                       FROM `abcantrackv2`.`traffic_violation`
                       WHERE (`abcantrackv2`.`traffic_violation`.`IncidentId` =
                              `abcantrackv2`.`incident`.`IncidentId`)))) AS `IntEmployeeDept1`,
    (SELECT concat_ws(', ', (SELECT group_concat(`abcantrackv2`.`impact`.`IntEmployeeDept2` SEPARATOR ', ')
                             FROM `abcantrackv2`.`impact`
                             WHERE (`abcantrackv2`.`impact`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`injury`.`IntEmployeeDept2` SEPARATOR ', ')
                       FROM `abcantrackv2`.`injury`
                       WHERE (`abcantrackv2`.`injury`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`illness`.`IntEmployeeDept2` SEPARATOR ', ')
                       FROM `abcantrackv2`.`illness`
                       WHERE (`abcantrackv2`.`illness`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`spill_release`.`IntEmployeeDept2` SEPARATOR ', ')
                       FROM `abcantrackv2`.`spill_release`
                       WHERE (`abcantrackv2`.`spill_release`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`vehicle_damage`.`IntEmployeeDept2` SEPARATOR ', ')
                       FROM `abcantrackv2`.`vehicle_damage`
                       WHERE (`abcantrackv2`.`vehicle_damage`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`traffic_violation`.`IntEmployeeDept2` SEPARATOR ', ')
                       FROM `abcantrackv2`.`traffic_violation`
                       WHERE (`abcantrackv2`.`traffic_violation`.`IncidentId` =
                              `abcantrackv2`.`incident`.`IncidentId`)))) AS `IntEmployeeDept2`,
    (SELECT concat_ws(', ', (SELECT group_concat(`abcantrackv2`.`impact`.`IntEmployeeDept3` SEPARATOR ', ')
                             FROM `abcantrackv2`.`impact`
                             WHERE (`abcantrackv2`.`impact`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`injury`.`IntEmployeeDept3` SEPARATOR ', ')
                       FROM `abcantrackv2`.`injury`
                       WHERE (`abcantrackv2`.`injury`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`illness`.`IntEmployeeDept3` SEPARATOR ', ')
                       FROM `abcantrackv2`.`illness`
                       WHERE (`abcantrackv2`.`illness`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`spill_release`.`IntEmployeeDept3` SEPARATOR ', ')
                       FROM `abcantrackv2`.`spill_release`
                       WHERE (`abcantrackv2`.`spill_release`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`vehicle_damage`.`IntEmployeeDept3` SEPARATOR ', ')
                       FROM `abcantrackv2`.`vehicle_damage`
                       WHERE (`abcantrackv2`.`vehicle_damage`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`traffic_violation`.`IntEmployeeDept3` SEPARATOR ', ')
                       FROM `abcantrackv2`.`traffic_violation`
                       WHERE (`abcantrackv2`.`traffic_violation`.`IncidentId` =
                              `abcantrackv2`.`incident`.`IncidentId`)))) AS `IntEmployeeDept3`,
    (SELECT concat_ws(', ', (SELECT group_concat(`abcantrackv2`.`impact`.`CustomOpenTxt` SEPARATOR ', ')
                             FROM `abcantrackv2`.`impact`
                             WHERE (`abcantrackv2`.`impact`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`injury`.`CustomOpenTxt` SEPARATOR ', ')
                       FROM `abcantrackv2`.`injury`
                       WHERE (`abcantrackv2`.`injury`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`illness`.`CustomOpenTxt` SEPARATOR ', ')
                       FROM `abcantrackv2`.`illness`
                       WHERE (`abcantrackv2`.`illness`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`spill_release`.`CustomOpenTxt` SEPARATOR ', ')
                       FROM `abcantrackv2`.`spill_release`
                       WHERE (`abcantrackv2`.`spill_release`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`vehicle_damage`.`CustomOpenTxt` SEPARATOR ', ')
                       FROM `abcantrackv2`.`vehicle_damage`
                       WHERE (`abcantrackv2`.`vehicle_damage`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`traffic_violation`.`CustomOpenTxt` SEPARATOR ', ')
                       FROM `abcantrackv2`.`traffic_violation`
                       WHERE (`abcantrackv2`.`traffic_violation`.`IncidentId` =
                              `abcantrackv2`.`incident`.`IncidentId`)))) AS `CustomOpenTxt`,
    (SELECT concat_ws(', ', (SELECT group_concat(`abcantrackv2`.`impact`.`PrimRespondName` SEPARATOR ', ')
                             FROM `abcantrackv2`.`impact`
                             WHERE (`abcantrackv2`.`impact`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`injury`.`PrimRespondName` SEPARATOR ', ')
                       FROM `abcantrackv2`.`injury`
                       WHERE (`abcantrackv2`.`injury`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`illness`.`PrimRespondName` SEPARATOR ', ')
                       FROM `abcantrackv2`.`illness`
                       WHERE (`abcantrackv2`.`illness`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`spill_release`.`PrimRespondName` SEPARATOR ', ')
                       FROM `abcantrackv2`.`spill_release`
                       WHERE (`abcantrackv2`.`spill_release`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`vehicle_damage`.`PrimRespondName` SEPARATOR ', ')
                       FROM `abcantrackv2`.`vehicle_damage`
                       WHERE (`abcantrackv2`.`vehicle_damage`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`traffic_violation`.`PrimRespondName` SEPARATOR ', ')
                       FROM `abcantrackv2`.`traffic_violation`
                       WHERE (`abcantrackv2`.`traffic_violation`.`IncidentId` =
                              `abcantrackv2`.`incident`.`IncidentId`)))) AS `PrimRespondName`,
    (SELECT concat_ws(', ', (SELECT group_concat(`abcantrackv2`.`impact`.`Description` SEPARATOR ', ')
                             FROM `abcantrackv2`.`impact`
                             WHERE (`abcantrackv2`.`impact`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`injury`.`Description` SEPARATOR ', ')
                       FROM `abcantrackv2`.`injury`
                       WHERE (`abcantrackv2`.`injury`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`illness`.`Description` SEPARATOR ', ')
                       FROM `abcantrackv2`.`illness`
                       WHERE (`abcantrackv2`.`illness`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`spill_release`.`Description` SEPARATOR ', ')
                       FROM `abcantrackv2`.`spill_release`
                       WHERE (`abcantrackv2`.`spill_release`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`vehicle_damage`.`Description` SEPARATOR ', ')
                       FROM `abcantrackv2`.`vehicle_damage`
                       WHERE (`abcantrackv2`.`vehicle_damage`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`traffic_violation`.`Description` SEPARATOR ', ')
                       FROM `abcantrackv2`.`traffic_violation`
                       WHERE (`abcantrackv2`.`traffic_violation`.`IncidentId` =
                              `abcantrackv2`.`incident`.`IncidentId`)))) AS `ImpactDescription`,
    (SELECT concat_ws(', ', (SELECT group_concat(`abcantrackv2`.`impact`.`EstimatedCost` SEPARATOR ', ')
                             FROM `abcantrackv2`.`impact`
                             WHERE (`abcantrackv2`.`impact`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`injury`.`EstimatedCost` SEPARATOR ', ')
                       FROM `abcantrackv2`.`injury`
                       WHERE (`abcantrackv2`.`injury`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`illness`.`EstimatedCost` SEPARATOR ', ')
                       FROM `abcantrackv2`.`illness`
                       WHERE (`abcantrackv2`.`illness`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`spill_release`.`EstimatedCost` SEPARATOR ', ')
                       FROM `abcantrackv2`.`spill_release`
                       WHERE (`abcantrackv2`.`spill_release`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`vehicle_damage`.`EstimatedCost` SEPARATOR ', ')
                       FROM `abcantrackv2`.`vehicle_damage`
                       WHERE (`abcantrackv2`.`vehicle_damage`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`traffic_violation`.`EstimatedCost` SEPARATOR ', ')
                       FROM `abcantrackv2`.`traffic_violation`
                       WHERE (`abcantrackv2`.`traffic_violation`.`IncidentId` =
                              `abcantrackv2`.`incident`.`IncidentId`)))) AS `EstimatedCost`,
    (SELECT concat_ws(', ', (SELECT group_concat(`abcantrackv2`.`external_agency`.`ExtAgencyName` SEPARATOR '; ')
                             FROM ((`abcantrackv2`.`impact`
                               LEFT JOIN `abcantrackv2`.`impacts_ext_agency`
                                 ON ((`abcantrackv2`.`impacts_ext_agency`.`ImpactId` =
                                      `abcantrackv2`.`impact`.`ImpactId`))) LEFT JOIN `abcantrackv2`.`external_agency`
                                 ON ((`abcantrackv2`.`external_agency`.`ExtAgencyId` =
                                      `abcantrackv2`.`impacts_ext_agency`.`ExtAgencyId`)))
                             WHERE (`abcantrackv2`.`impact`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`external_agency`.`ExtAgencyName` SEPARATOR '; ')
                       FROM ((`abcantrackv2`.`injury`
                         LEFT JOIN `abcantrackv2`.`impacts_ext_agency`
                           ON ((`abcantrackv2`.`impacts_ext_agency`.`InjuryId` =
                                `abcantrackv2`.`injury`.`InjuryId`))) LEFT JOIN `abcantrackv2`.`external_agency`
                           ON ((`abcantrackv2`.`external_agency`.`ExtAgencyId` =
                                `abcantrackv2`.`impacts_ext_agency`.`ExtAgencyId`)))
                       WHERE (`abcantrackv2`.`injury`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`external_agency`.`ExtAgencyName` SEPARATOR '; ')
                       FROM ((`abcantrackv2`.`illness`
                         LEFT JOIN `abcantrackv2`.`impacts_ext_agency`
                           ON ((`abcantrackv2`.`impacts_ext_agency`.`IllnessId` =
                                `abcantrackv2`.`illness`.`IllnessId`))) LEFT JOIN `abcantrackv2`.`external_agency`
                           ON ((`abcantrackv2`.`external_agency`.`ExtAgencyId` =
                                `abcantrackv2`.`impacts_ext_agency`.`ExtAgencyId`)))
                       WHERE (`abcantrackv2`.`illness`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`external_agency`.`ExtAgencyName` SEPARATOR '; ')
                       FROM ((`abcantrackv2`.`spill_release`
                         LEFT JOIN `abcantrackv2`.`impacts_ext_agency`
                           ON ((`abcantrackv2`.`impacts_ext_agency`.`SpillReleaseId` =
                                `abcantrackv2`.`spill_release`.`SpillReleaseId`))) LEFT JOIN
                         `abcantrackv2`.`external_agency` ON ((`abcantrackv2`.`external_agency`.`ExtAgencyId` =
                                                               `abcantrackv2`.`impacts_ext_agency`.`ExtAgencyId`)))
                       WHERE (`abcantrackv2`.`spill_release`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`external_agency`.`ExtAgencyName` SEPARATOR '; ')
                       FROM ((`abcantrackv2`.`vehicle_damage`
                         LEFT JOIN `abcantrackv2`.`impacts_ext_agency`
                           ON ((`abcantrackv2`.`impacts_ext_agency`.`VehicleDamageId` =
                                `abcantrackv2`.`vehicle_damage`.`VehicleDamageId`))) LEFT JOIN
                         `abcantrackv2`.`external_agency` ON ((`abcantrackv2`.`external_agency`.`ExtAgencyId` =
                                                               `abcantrackv2`.`impacts_ext_agency`.`ExtAgencyId`)))
                       WHERE (`abcantrackv2`.`vehicle_damage`.`IncidentId` = `abcantrackv2`.`incident`.`IncidentId`)),
                      (SELECT group_concat(`abcantrackv2`.`external_agency`.`ExtAgencyName` SEPARATOR '; ')
                       FROM ((`abcantrackv2`.`traffic_violation`
                         LEFT JOIN `abcantrackv2`.`impacts_ext_agency`
                           ON ((`abcantrackv2`.`impacts_ext_agency`.`TrafficViolationId` =
                                `abcantrackv2`.`traffic_violation`.`TrafficViolationId`))) LEFT JOIN
                         `abcantrackv2`.`external_agency` ON ((`abcantrackv2`.`external_agency`.`ExtAgencyId` =
                                                               `abcantrackv2`.`impacts_ext_agency`.`ExtAgencyId`)))
                       WHERE (`abcantrackv2`.`traffic_violation`.`IncidentId` =
                              `abcantrackv2`.`incident`.`IncidentId`)))) AS `ExtAgencyId`
  FROM `abcantrackv2`.`incident`;
