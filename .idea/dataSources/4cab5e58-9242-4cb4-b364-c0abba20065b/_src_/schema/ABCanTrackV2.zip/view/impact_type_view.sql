CREATE VIEW ABCanTrackV2.impact_type_view AS
  SELECT
    `abcantrackv2`.`impact_type`.`ImpactTypeId`          AS `ImpactTypeId`,
    `abcantrackv2`.`impact_type`.`ImpactTypeName`        AS `ImpactTypeName`,
    `abcantrackv2`.`impact_type`.`OrgId`                 AS `OrgId`,
    `abcantrackv2`.`impact_sub_type`.`ImpactSubTypeId`   AS `ImpactSubTypeId`,
    `abcantrackv2`.`impact_sub_type`.`ImpactSubTypeName` AS `ImpactSubTypeName`
  FROM (`abcantrackv2`.`impact_type`
    JOIN `abcantrackv2`.`impact_sub_type`
      ON ((`abcantrackv2`.`impact_sub_type`.`ImpactTypeId` = `abcantrackv2`.`impact_type`.`ImpactTypeId`)))
  WHERE (`abcantrackv2`.`impact_type`.`OrgId` IS NOT NULL);
