CREATE VIEW ABCanTrackV2.impacts_typeid_vw AS
  SELECT
    `inc`.`IncidentId`                                                                   AS `IncidentId`,
    concat_ws(', ', (SELECT DISTINCT group_concat(`imt`.`ImpactTypeName` SEPARATOR ', ')),
              (SELECT DISTINCT group_concat(`imj`.`ImpactTypeName` SEPARATOR ', ')),
              (SELECT DISTINCT group_concat(`it`.`ImpactTypeName` SEPARATOR ', ')),
              (SELECT DISTINCT group_concat(`it2`.`ImpactTypeName` SEPARATOR ', ')),
              (SELECT DISTINCT group_concat(`it4`.`ImpactTypeName` SEPARATOR ', ')),
              (SELECT DISTINCT group_concat(`it5`.`ImpactTypeName` SEPARATOR ', ')))     AS `ImpactTypeId`,
    concat_ws(', ', (SELECT DISTINCT group_concat(`abcantrackv2`.`impact_sub_type`.`ImpactSubTypeName` SEPARATOR ', ')),
              (SELECT DISTINCT group_concat(`imps`.`ImpactSubTypeName` SEPARATOR ', ')),
              (SELECT DISTINCT group_concat(`imp2`.`ImpactSubTypeName` SEPARATOR ', ')),
              (SELECT DISTINCT group_concat(`imp3`.`ImpactSubTypeName` SEPARATOR ', ')),
              (SELECT DISTINCT group_concat(`imp4`.`ImpactSubTypeName` SEPARATOR ', ')),
              (SELECT DISTINCT group_concat(`imp5`.`ImpactSubTypeName` SEPARATOR ', '))) AS `ImpactSubTypeId`
  FROM ((((((`abcantrackv2`.`incident` `inc` LEFT JOIN ((`abcantrackv2`.`impact` `im`
    JOIN `abcantrackv2`.`impact_sub_type`
      ON ((`abcantrackv2`.`impact_sub_type`.`ImpactSubTypeId` = `im`.`ImpactSubTypeId`))) JOIN
    `abcantrackv2`.`impact_type` `imt` ON ((`abcantrackv2`.`impact_sub_type`.`ImpactTypeId` = `imt`.`ImpactTypeId`)))
      ON ((`im`.`IncidentId` = `inc`.`IncidentId`))) LEFT JOIN ((`abcantrackv2`.`injury` `inj`
    JOIN `abcantrackv2`.`impact_sub_type` `imps` ON ((`imps`.`ImpactSubTypeId` = `inj`.`ImpactSubTypeId`))) JOIN
    `abcantrackv2`.`impact_type` `imj` ON ((`imps`.`ImpactTypeId` = `imj`.`ImpactTypeId`)))
      ON ((`inj`.`IncidentId` = `inc`.`IncidentId`))) LEFT JOIN ((`abcantrackv2`.`illness` `inl`
    JOIN `abcantrackv2`.`impact_sub_type` `imp2` ON ((`imp2`.`ImpactSubTypeId` = `inl`.`ImpactSubTypeId`))) JOIN
    `abcantrackv2`.`impact_type` `it` ON ((`imp2`.`ImpactTypeId` = `it`.`ImpactTypeId`)))
      ON ((`inl`.`IncidentId` = `inc`.`IncidentId`))) LEFT JOIN ((`abcantrackv2`.`spill_release` `spl`
    JOIN `abcantrackv2`.`impact_sub_type` `imp3` ON ((`imp3`.`ImpactSubTypeId` = `spl`.`ImpactSubTypeId`))) JOIN
    `abcantrackv2`.`impact_type` `it2` ON ((`imp3`.`ImpactTypeId` = `it2`.`ImpactTypeId`)))
      ON ((`spl`.`IncidentId` = `inc`.`IncidentId`))) LEFT JOIN ((`abcantrackv2`.`vehicle_damage` `vcl`
    JOIN `abcantrackv2`.`impact_sub_type` `imp4` ON ((`imp4`.`ImpactSubTypeId` = `vcl`.`ImpactSubTypeId`))) JOIN
    `abcantrackv2`.`impact_type` `it4` ON ((`imp4`.`ImpactTypeId` = `it4`.`ImpactTypeId`)))
      ON ((`vcl`.`IncidentId` = `inc`.`IncidentId`))) LEFT JOIN ((`abcantrackv2`.`traffic_violation` `tv`
    JOIN `abcantrackv2`.`impact_sub_type` `imp5` ON ((`imp5`.`ImpactSubTypeId` = `tv`.`ImpactSubTypeId`))) JOIN
    `abcantrackv2`.`impact_type` `it5` ON ((`imp5`.`ImpactTypeId` = `it5`.`ImpactTypeId`)))
      ON ((`tv`.`IncidentId` = `inc`.`IncidentId`)))
  GROUP BY `inc`.`IncidentId`;
