CREATE VIEW ABCanTrackV2.hist_incident_subview AS
  SELECT
    `hc`.`IncidentId`         AS `IncidentId`,
    max(`hc`.`VersionNumber`) AS `VersionNumber`
  FROM `abcantrackv2`.`hist_incident` `hc`
  GROUP BY `hc`.`IncidentId`;
