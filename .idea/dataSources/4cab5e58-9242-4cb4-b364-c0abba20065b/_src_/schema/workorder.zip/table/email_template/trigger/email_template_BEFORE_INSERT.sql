CREATE TRIGGER workorder.email_template_BEFORE_INSERT
BEFORE INSERT ON workorder.email_template
FOR EACH ROW
  BEGIN
   SET new.email_template_id = UUID();
   END;
