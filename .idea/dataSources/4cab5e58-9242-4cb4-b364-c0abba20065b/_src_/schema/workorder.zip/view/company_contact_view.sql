CREATE VIEW workorder.company_contact_view AS
  SELECT
    `cot`.`id`                AS `company_id`,
    `cot`.`id`                AS `abbrev`,
    `relt`.`rel_type_name`    AS `rel_type_name`,
    `relt`.`id`               AS `rel_type_id`,
    `bo`.`bo_name`            AS `bo_name`,
    `bo`.`object_type_id`     AS `object_type_id`,
    `ct`.`id`                 AS `contact_id`,
    `ct`.`country_id`         AS `country_id`,
    `ct`.`area_code1`         AS `area_code1`,
    `lookup1`.`lookup_name`   AS `phone_type_name1`,
    `ct`.`phone_number1`      AS `phone_number1`,
    `ct`.`extension1`         AS `extension1`,
    `ct`.`area_code2`         AS `area_code2`,
    `lookup2`.`lookup_name`   AS `phone_type_name2`,
    `ct`.`phone_number2`      AS `phone_number2`,
    `ct`.`extension2`         AS `extension2`,
    `ct`.`area_code3`         AS `area_code3`,
    `lookup3`.`lookup_name`   AS `phone_type_name3`,
    `ct`.`phone_number3`      AS `phone_number3`,
    `ct`.`extension3`         AS `extension3`,
    `ct`.`phone`              AS `phone`,
    `ct`.`phone_ext`          AS `phone_ext`,
    `ct`.`mobile`             AS `mobile`,
    `ct`.`fax`                AS `fax`,
    `ct`.`email`              AS `email`,
    `ct`.`verified_date`      AS `verified_date`,
    `ct`.`verified_source_id` AS `verified_source_id`,
    `ct`.`website`            AS `website`,
    `ct`.`properties`         AS `contact_properties`,
    `ct`.`shipto_address_id`  AS `shipto_address_id`,
    `ct`.`billto_address_id`  AS `billto_address_id`,
    `ct`.`billto_space_id`    AS `billto_space_id`,
    `ct`.`shipto_space_id`    AS `shipto_space_id`,
    `ct`.`sms`                AS `sms`,
    `rel`.`id`                AS `relationship_id`,
    `rel`.`object_role`       AS `object_role`,
    `rel`.`subject_role`      AS `subject_role`,
    `cntry`.`phone_code`      AS `phone_code`
  FROM ((((((((`workorder`.`company_tbl` `cot`
    JOIN `workorder`.`contact_tbl` `ct` ON ((`cot`.`contact_id` = `ct`.`id`))) JOIN
    `workorder`.`business_object_tbl` `bo` ON ((`cot`.`id` = `bo`.`id`))) LEFT JOIN `workorder`.`country_tbl` `cntry`
      ON ((`cntry`.`id` = `ct`.`country_id`))) LEFT JOIN `workorder`.`relationship_tbl` `rel`
      ON ((`cot`.`id` = `rel`.`subject_id`))) LEFT JOIN `workorder`.`rel_type_tbl` `relt`
      ON ((`rel`.`rel_type_id` = `relt`.`id`))) LEFT JOIN `workorder`.`lookup_tbl` `lookup1`
      ON ((`lookup1`.`id` = `ct`.`phone_type_id1`))) LEFT JOIN `workorder`.`lookup_tbl` `lookup2`
      ON ((`lookup2`.`id` = `ct`.`phone_type_id2`))) LEFT JOIN `workorder`.`lookup_tbl` `lookup3`
      ON ((`lookup3`.`id` = `ct`.`phone_type_id3`)));
