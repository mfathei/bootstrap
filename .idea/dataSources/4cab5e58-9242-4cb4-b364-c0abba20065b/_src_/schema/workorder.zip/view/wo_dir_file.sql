CREATE VIEW workorder.wo_dir_file AS
  SELECT
    `f`.`file_id`                                           AS `file_id`,
    `f`.`file_filename`                                     AS `filename`,
    `f`.`file_dirname_id`                                   AS `file_dirname_id`,
    `f`.`file_workorder`                                    AS `file_workorder`,
    (SELECT concat(`auth`.`user`.`first_name`, ' ', `auth`.`user`.`last_name`)
     FROM `auth`.`user`
     WHERE (`auth`.`user`.`user_id` = `f`.`file_uploadby`)) AS `file_uploadby`,
    `f`.`file_datelastmodified`                             AS `file_lastupdated`,
    `f`.`file_parent_id`                                    AS `file_parent_id`
  FROM `workorder`.`file` `f`;
