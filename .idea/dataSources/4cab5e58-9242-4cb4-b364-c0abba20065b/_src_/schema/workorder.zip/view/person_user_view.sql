CREATE VIEW workorder.person_user_view AS
  SELECT DISTINCT
    `u_t`.`id`                                             AS `ID`,
    `u_t`.`username`                                       AS `UserName`,
    `u_t`.`password`                                       AS `Password`,
    `l_u`.`lookup_name`                                    AS `Title`,
    `p_t`.`title_id`                                       AS `title_id`,
    `p_t`.`id`                                             AS `PersonID`,
    `p_t`.`first_name`                                     AS `FirstName`,
    `p_t`.`middle_names`                                   AS `MiddleName`,
    `p_t`.`last_name`                                      AS `LastName`,
    `p_t`.`goes_by_name`                                   AS `GoesBy`,
    `p_t`.`initials`                                       AS `Initials`,
    `p_t`.`prof_status`                                    AS `prof_status`,
    `p_t`.`contact_id`                                     AS `contact_id`,
    `p_t`.`properties`                                     AS `person_properties`,
    `f_t`.`file_path`                                      AS `ProfilePicture`,
    `co_t`.`mobile`                                        AS `Mobile`,
    `co_t`.`phone`                                         AS `Phone`,
    `co_t`.`email`                                         AS `email`,
    `co_t`.`country_id`                                    AS `country_id`,
    `co_t`.`work_number`                                   AS `work_number`,
    `co_t`.`area_code1`                                    AS `area_code1`,
    `co_t`.`area_code2`                                    AS `area_code2`,
    `co_t`.`area_code3`                                    AS `area_code3`,
    `co_t`.`phone_number1`                                 AS `phone_number1`,
    `co_t`.`extension1`                                    AS `extension1`,
    `co_t`.`phone_type_id1`                                AS `phone_type_id1`,
    `pht1`.`lookup_name`                                   AS `phone_type_name1`,
    `co_t`.`phone_number2`                                 AS `phone_number2`,
    `co_t`.`extension2`                                    AS `extension2`,
    `co_t`.`phone_type_id2`                                AS `phone_type_id2`,
    `pht2`.`lookup_name`                                   AS `phone_type_name2`,
    `co_t`.`phone_number3`                                 AS `phone_number3`,
    `co_t`.`extension3`                                    AS `extension3`,
    `co_t`.`phone_type_id3`                                AS `phone_type_id3`,
    `pht3`.`lookup_name`                                   AS `phone_type_name3`,
    `sad_t`.`address1`                                     AS `ShipToLine1`,
    `bad_t`.`address1`                                     AS `BillToLine1`,
    `sad_t`.`address2`                                     AS `ShipToLine2`,
    `bad_t`.`address2`                                     AS `BillToLine2`,
    `sc_t`.`id`                                            AS `ShipToCityID`,
    `sc_t`.`city_name`                                     AS `ShipToCity`,
    `sc_t`.`abbrev`                                        AS `ShipToCityAbbrev`,
    `bc_t`.`id`                                            AS `BillToCityID`,
    `bc_t`.`city_name`                                     AS `BillToCity`,
    `bc_t`.`abbrev`                                        AS `BillToCityAbbrev`,
    `pbo`.`bo_name`                                        AS `BoName`,
    `cbo`.`bo_name`                                        AS `ContactBoName`,
    `cbo`.`fullname`                                       AS `ContactFullName`,
    `sbo`.`bo_name`                                        AS `ShipToBoName`,
    `sbo`.`fullname`                                       AS `ShipToFullName`,
    `bbo`.`bo_name`                                        AS `BillToBoName`,
    `bbo`.`fullname`                                       AS `BillToFullName`,
    `pbo`.`status`                                         AS `PboStatus`,
    `cbo`.`status`                                         AS `CboStatus`,
    `sbo`.`status`                                         AS `SboStatus`,
    `bbo`.`status`                                         AS `BboStatus`,
    `co_t`.`phone_ext`                                     AS `PhoneExt`,
    `co_t`.`fax`                                           AS `Fax`,
    `co_t`.`sms`                                           AS `sms`,
    `co_t`.`dialing_code`                                  AS `dialing_code`,
    `sad_t`.`postal_code`                                  AS `SadPostalCode`,
    `bad_t`.`postal_code`                                  AS `BadPostalCode`,
    `sad_t`.`lattitude`                                    AS `Sadlattitude`,
    `bad_t`.`lattitude`                                    AS `Badlattitude`,
    `sad_t`.`longitude`                                    AS `Sadlongitude`,
    `bad_t`.`longitude`                                    AS `Badlongitude`,
    `sad_t`.`street_number`                                AS `SadStreetNumber`,
    `sad_t`.`street_name`                                  AS `SadStreetName`,
    `sad_t`.`street_type_id`                               AS `SadStreetType`,
    `shipst`.`lookup_name`                                 AS `SadStreetTypeName`,
    `sad_t`.`street_direction_id`                          AS `SadStreetDirection`,
    `shipdir`.`lookup_name`                                AS `SadStreetDirectionName`,
    `sspace`.`area_number`                                 AS `ShipAreaNumber`,
    `bad_t`.`street_number`                                AS `BadStreetNumber`,
    `bad_t`.`street_name`                                  AS `BadStreetName`,
    `bad_t`.`street_type_id`                               AS `BadStreetType`,
    `billst`.`lookup_name`                                 AS `BadStreetTypeName`,
    `bad_t`.`street_direction_id`                          AS `BadStreetDirection`,
    `billdir`.`lookup_name`                                AS `BadStreetDirectionName`,
    `bspace`.`area_number`                                 AS `BillAreaNumber`,
    `sp_t`.`id`                                            AS `SpProvID`,
    `sp_t`.`prov_name`                                     AS `SpProvName`,
    `bp_t`.`id`                                            AS `BpProvID`,
    `bp_t`.`prov_name`                                     AS `BpProvName`,
    `sp_t`.`prov_tax_rate`                                 AS `SadTaxRate`,
    `bp_t`.`prov_tax_rate`                                 AS `BadTaxRate`,
    `sp_t`.`tax_type`                                      AS `SadTaxType`,
    `bp_t`.`tax_type`                                      AS `BadTaxType`,
    `sco_t`.`id`                                           AS `ScoCountryID`,
    `sco_t`.`country_name`                                 AS `ScoCountryName`,
    `bco_t`.`id`                                           AS `BcoCountryID`,
    `bco_t`.`country_name`                                 AS `BcoCountryName`,
    `USER_FUNCTION`(`workorder`.`ugu_tbl`.`user_group_id`) AS `UserGroup`,
    `cbo`.`id`                                             AS `ContactId`,
    `sbo`.`id`                                             AS `ShipToId`,
    `bbo`.`id`                                             AS `BillToId`,
    `cntry`.`country_name`                                 AS `country_name`,
    `cntry`.`abbrev`                                       AS `abbrev`,
    `cntry`.`url`                                          AS `url`,
    `cntry`.`phone_code`                                   AS `phone_code`,
    `cntry`.`properties`                                   AS `country_properties`,
    `cntry`.`currency_type_id`                             AS `currency_type_id`,
    `cntry`.`company_id`                                   AS `company_id`,
    `cntry`.`fed_tax_rate`                                 AS `fed_tax_rate`,
    `i_t`.`id`                                             AS `identitiy_id`
  FROM ((((((((((((((((((((((((((`workorder`.`person_tbl` `p_t` LEFT JOIN (`workorder`.`identity_tbl` `i_t`
    JOIN `workorder`.`file_tbl` `f_t`
      ON (((`i_t`.`picture_id` = `f_t`.`id`) AND (`i_t`.`properties` = '<Id><Identifier>profile</Identifier></Id>'))))
      ON ((`p_t`.`id` = `i_t`.`person_id`))) LEFT JOIN (`workorder`.`user_tbl` `u_t`
    JOIN `workorder`.`ugu_tbl` ON ((`workorder`.`ugu_tbl`.`user_id` = `u_t`.`id`)))
      ON ((`p_t`.`id` = `u_t`.`person_id`))) LEFT JOIN `workorder`.`lookup_tbl` `l_u`
      ON ((`p_t`.`title_id` = `l_u`.`id`))) JOIN `workorder`.`contact_tbl` `co_t`
      ON ((`p_t`.`contact_id` = `co_t`.`id`))) LEFT JOIN `workorder`.`lookup_tbl` `pht1`
      ON ((`co_t`.`phone_type_id1` = `pht1`.`id`))) LEFT JOIN `workorder`.`lookup_tbl` `pht2`
      ON ((`co_t`.`phone_type_id2` = `pht2`.`id`))) LEFT JOIN `workorder`.`lookup_tbl` `pht3`
      ON ((`co_t`.`phone_type_id3` = `pht3`.`id`))) JOIN `workorder`.`address_tbl` `sad_t`
      ON ((`co_t`.`shipto_address_id` = `sad_t`.`id`))) LEFT JOIN `workorder`.`lookup_tbl` `shipst`
      ON ((`sad_t`.`street_type_id` = `shipst`.`id`))) LEFT JOIN `workorder`.`lookup_tbl` `shipdir`
      ON ((`sad_t`.`street_direction_id` = `shipdir`.`id`))) LEFT JOIN `workorder`.`space_tbl` `sspace`
      ON ((`sad_t`.`id` = `sspace`.`address_id`))) JOIN `workorder`.`address_tbl` `bad_t`
      ON ((`co_t`.`billto_address_id` = `bad_t`.`id`))) LEFT JOIN `workorder`.`lookup_tbl` `billst`
      ON ((`bad_t`.`street_type_id` = `billst`.`id`))) LEFT JOIN `workorder`.`lookup_tbl` `billdir`
      ON ((`bad_t`.`street_direction_id` = `billdir`.`id`))) LEFT JOIN `workorder`.`space_tbl` `bspace`
      ON ((`bad_t`.`id` = `bspace`.`address_id`))) JOIN `workorder`.`city_tbl` `sc_t`
      ON ((`sad_t`.`city_id` = `sc_t`.`id`))) JOIN `workorder`.`city_tbl` `bc_t`
      ON ((`bad_t`.`city_id` = `bc_t`.`id`))) LEFT JOIN `workorder`.`province_tbl` `sp_t`
      ON ((`sc_t`.`province_tbl_id` = `sp_t`.`id`))) LEFT JOIN `workorder`.`province_tbl` `bp_t`
      ON ((`bc_t`.`province_tbl_id` = `bp_t`.`id`))) JOIN `workorder`.`country_tbl` `sco_t`
      ON ((`sp_t`.`country_tbl_id` = `sco_t`.`id`))) JOIN `workorder`.`country_tbl` `bco_t`
      ON ((`bp_t`.`country_tbl_id` = `bco_t`.`id`))) JOIN `workorder`.`business_object_tbl` `pbo`
      ON ((`pbo`.`id` = `p_t`.`id`))) JOIN `workorder`.`business_object_tbl` `cbo` ON ((`cbo`.`id` = `co_t`.`id`))) JOIN
    `workorder`.`business_object_tbl` `sbo` ON ((`sbo`.`id` = `sad_t`.`id`))) JOIN
    `workorder`.`business_object_tbl` `bbo` ON ((`bbo`.`id` = `bad_t`.`id`))) LEFT JOIN
    `workorder`.`country_tbl` `cntry` ON ((`co_t`.`country_id` = `cntry`.`id`)));
