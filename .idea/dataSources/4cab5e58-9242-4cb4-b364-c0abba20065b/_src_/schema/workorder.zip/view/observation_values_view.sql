CREATE VIEW workorder.observation_values_view AS
  SELECT
    `workorder`.`observation_template_tbl`.`id` AS `id`,
    `o_lookup`.`id`                             AS `TestId`,
    `o_lookup`.`MedicalObservation`             AS `TestName`,
    `o_lookup`.`SI_Units_abbrev`                AS `TestUnit`,
    `o_lookup1`.`id`                            AS `Value1Id`,
    `o_lookup1`.`MedicalObservation`            AS `Value1Name`,
    `o_lookup1`.`SI_Units_abbrev`               AS `Value1Unit`,
    `o_lookup2`.`id`                            AS `Value2Id`,
    `o_lookup2`.`MedicalObservation`            AS `Value2Name`,
    `o_lookup2`.`SI_Units_abbrev`               AS `Value2Unit`,
    `o_lookup3`.`id`                            AS `Value3Id`,
    `o_lookup3`.`MedicalObservation`            AS `Value3Name`,
    `o_lookup3`.`SI_Units_abbrev`               AS `Value3Unit`
  FROM ((((`workorder`.`observation_template_tbl`
    JOIN `workorder`.`observation_lookup_tbl` `o_lookup`
      ON ((`workorder`.`observation_template_tbl`.`test_type_id` = `o_lookup`.`id`))) JOIN
    `workorder`.`observation_lookup_tbl` `o_lookup1`
      ON ((`workorder`.`observation_template_tbl`.`value1_type_id` = `o_lookup1`.`id`))) LEFT JOIN
    `workorder`.`observation_lookup_tbl` `o_lookup2`
      ON ((`workorder`.`observation_template_tbl`.`value2_type_id` = `o_lookup2`.`id`))) LEFT JOIN
    `workorder`.`observation_lookup_tbl` `o_lookup3`
      ON ((`workorder`.`observation_template_tbl`.`value3_type_id` = `o_lookup3`.`id`)));
