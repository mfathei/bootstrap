CREATE VIEW workorder.rel_type_view AS
  SELECT
    `workorder`.`rel_type_tbl`.`id`              AS `id`,
    `workorder`.`rel_type_tbl`.`rel_type_name`   AS `rel_type_name`,
    concat(`workorder`.`rel_type_tbl`.`rel_type_name`, ' (', `subject_t`.`object_type_name`, ' to ',
           `object_t`.`object_type_name`, ')')   AS `rel_type_fullname`,
    `subject_t`.`object_type_name`               AS `subject_bo_type`,
    `object_t`.`object_type_name`                AS `object_bo_type`,
    `workorder`.`rel_type_tbl`.`rel_type_abbrev` AS `rel_type_abbrev`
  FROM ((`workorder`.`rel_type_tbl`
    JOIN `workorder`.`object_type_tbl` `subject_t`
      ON ((`workorder`.`rel_type_tbl`.`subject_bo_type` = `subject_t`.`id`))) JOIN
    `workorder`.`object_type_tbl` `object_t` ON ((`workorder`.`rel_type_tbl`.`object_bo_type` = `object_t`.`id`)));
