CREATE VIEW workorder.look_up_view AS
  SELECT
    `workorder`.`lookup_tbl`.`id`                    AS `id`,
    `workorder`.`lookup_tbl`.`lookup_name`           AS `lookup_name`,
    `workorder`.`lookup_tbl`.`list_index`            AS `list_index`,
    `workorder`.`lookup_type_tbl`.`lookup_type_name` AS `lookup_type`,
    `workorder`.`lookup_tbl`.`translation_id`        AS `translation_id`,
    `workorder`.`lookup_tbl`.`level`                 AS `level`,
    `workorder`.`file_tbl`.`file_name`               AS `FileName`,
    `workorder`.`lookup_tbl`.`taxonomy`              AS `taxonomy`,
    `workorder`.`lookup_tbl`.`level_type`            AS `level_type`,
    `workorder`.`lookup_tbl`.`concept_type`          AS `concept_type`,
    `workorder`.`lookup_tbl`.`mnemonic`              AS `mnemonic`,
    `workorder`.`lookup_tbl`.`description`           AS `description`,
    `workorder`.`business_rule_tbl`.`script`         AS `Script`,
    `l_t`.`lookup_name`                              AS `NextLookupName`,
    `workorder`.`lookup_tbl`.`common_bo_name`        AS `common_bo_name`,
    `workorder`.`lookup_tbl`.`common_fullname`       AS `common_fullname`,
    `workorder`.`lookup_tbl`.`common_description`    AS `common_description`,
    `workorder`.`lookup_tbl`.`concept_company_id`    AS `concept_company_id`,
    `workorder`.`lookup_tbl`.`concept_external_id`   AS `concept_external_id`,
    `workorder`.`lookup_tbl`.`reference_link`        AS `reference_link`,
    `workorder`.`lookup_tbl`.`reference_company_id`  AS `reference_company_id`,
    `workorder`.`lookup_tbl`.`parent_id`             AS `parent_id`,
    `parent`.`lookup_name`                           AS `parent_name`
  FROM (((((`workorder`.`lookup_tbl`
    JOIN `workorder`.`lookup_type_tbl`
      ON ((`workorder`.`lookup_tbl`.`lookup_type_id` = `workorder`.`lookup_type_tbl`.`id`))) LEFT JOIN
    `workorder`.`file_tbl` ON ((`workorder`.`lookup_tbl`.`file_id` = `workorder`.`file_tbl`.`id`))) LEFT JOIN
    `workorder`.`business_rule_tbl`
      ON ((`workorder`.`lookup_tbl`.`business_rule_id` = `workorder`.`business_rule_tbl`.`id`))) LEFT JOIN
    `workorder`.`lookup_tbl` `l_t` ON ((`workorder`.`lookup_tbl`.`next_id` = `l_t`.`id`))) LEFT JOIN
    `workorder`.`lookup_tbl` `parent` ON ((`workorder`.`lookup_tbl`.`parent_id` = `parent`.`id`)));
