CREATE VIEW workorder.province_view AS
  SELECT
    `workorder`.`province_tbl`.`id`            AS `id`,
    `workorder`.`province_tbl`.`prov_name`     AS `prov_name`,
    `workorder`.`province_tbl`.`abbrev`        AS `abbrev`,
    `workorder`.`province_tbl`.`tax_type`      AS `tax_type`,
    `workorder`.`province_tbl`.`prov_tax_rate` AS `prov_tax_rate`,
    `workorder`.`province_tbl`.`prov_tax_rate` AS `fed_tax_rate`,
    `workorder`.`province_tbl`.`company_id`    AS `ProvinceCompany`,
    `workorder`.`country_tbl`.`country_name`   AS `country_name`,
    `workorder`.`company_tbl`.`abbrev`         AS `CompanyAbbrev`,
    `workorder`.`province_tbl`.`properties`    AS `Properties`,
    `workorder`.`province_tbl`.`url`           AS `Url`
  FROM ((`workorder`.`province_tbl`
    JOIN `workorder`.`country_tbl`
      ON ((`workorder`.`province_tbl`.`country_tbl_id` = `workorder`.`country_tbl`.`id`))) LEFT JOIN
    `workorder`.`company_tbl` ON ((`workorder`.`province_tbl`.`company_id` = `workorder`.`company_tbl`.`id`)));
