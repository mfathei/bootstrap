CREATE VIEW workorder.user_basic_groups AS
  SELECT
    `workorder`.`business_object_tbl`.`id`             AS `id`,
    `workorder`.`business_object_tbl`.`bo_name`        AS `bo_name`,
    `workorder`.`business_object_tbl`.`properties`     AS `properties`,
    `workorder`.`business_object_tbl`.`participant_id` AS `participant_id`
  FROM `workorder`.`business_object_tbl`
  WHERE (`workorder`.`business_object_tbl`.`properties` IN
         ('<bo><Identifier>present_health_concerns</Identifier></bo>', '<bo><Identifier>symptoms</Identifier></bo>', '<bo><Identifier>pain_observations</Identifier></bo>', '<bo><Identifier>personal_medical_history</Identifier></bo>', '<bo><Identifier>medical_(diagnostic)_history</Identifier></bo>', '<bo><Identifier>injury_&_poisoning_+_external_cuase</Identifier></bo>', '<bo><Identifier>sugrical_&_other_procedure_history</Identifier></bo>', '<bo><Identifier>other_treatments</Identifier></bo>', '<bo><Identifier>adverse_effects_(allergies_,_reactions_or_treatment)</Identifier></bo>'));
