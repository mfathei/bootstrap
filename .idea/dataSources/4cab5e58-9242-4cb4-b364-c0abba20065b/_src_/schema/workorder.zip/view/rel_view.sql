CREATE VIEW workorder.rel_view AS
  SELECT
    `tbl1`.`id`                AS `id`,
    `rtbl1`.`bo_name`          AS `relationship_name`,
    `rtbl1`.`participant_id`   AS `participant_id`,
    `rtbl1`.`created_date`     AS `created_date`,
    `tbl1`.`subject_id`        AS `subject_id`,
    `stbl1`.`bo_name`          AS `subject_name`,
    `stbl2`.`object_type_name` AS `subject_type`,
    `tbl1`.`object_id`         AS `object_id`,
    `otbl1`.`bo_name`          AS `object_name`,
    `otbl2`.`object_type_name` AS `object_type`,
    `tbl1`.`start_date`        AS `start_date`,
    `tbl1`.`end_date`          AS `end_date`,
    `tbl1`.`list_index`        AS `list_index`,
    `tbl1`.`properties`        AS `properties`,
    `tbl1`.`rel_type_id`       AS `rel_type_id`,
    `tbl2`.`rel_type_name`     AS `rel_type_name`,
    `tbl1`.`contact_id`        AS `contact_id`,
    `tbl1`.`subject_role`      AS `subject_role`,
    `tbl1`.`object_role`       AS `object_role`,
    `tbl1`.`act`               AS `act`
  FROM ((((((`workorder`.`relationship_tbl` `tbl1`
    JOIN `workorder`.`business_object_tbl` `rtbl1` ON ((`tbl1`.`id` = `rtbl1`.`id`))) JOIN
    `workorder`.`business_object_tbl` `stbl1` ON ((`tbl1`.`subject_id` = `stbl1`.`id`))) JOIN
    `workorder`.`object_type_tbl` `stbl2` ON ((`stbl1`.`object_type_id` = `stbl2`.`id`))) JOIN
    `workorder`.`business_object_tbl` `otbl1` ON ((`tbl1`.`object_id` = `otbl1`.`id`))) JOIN
    `workorder`.`object_type_tbl` `otbl2` ON ((`otbl1`.`object_type_id` = `otbl2`.`id`))) JOIN
    `workorder`.`rel_type_tbl` `tbl2` ON ((`tbl1`.`rel_type_id` = `tbl2`.`id`)));
