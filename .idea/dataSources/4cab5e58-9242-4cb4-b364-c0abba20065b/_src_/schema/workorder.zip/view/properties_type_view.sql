CREATE VIEW workorder.properties_type_view AS
  SELECT
    `workorder`.`properties_type_tbl`.`id`           AS `id`,
    `workorder`.`properties_type_tbl`.`name`         AS `name`,
    `workorder`.`properties_type_tbl`.`template`     AS `template`,
    `workorder`.`object_type_tbl`.`object_type_name` AS `object_type_name`
  FROM (`workorder`.`properties_type_tbl`
    JOIN `workorder`.`object_type_tbl`
      ON ((`workorder`.`properties_type_tbl`.`object_type_id` = `workorder`.`object_type_tbl`.`id`)));
