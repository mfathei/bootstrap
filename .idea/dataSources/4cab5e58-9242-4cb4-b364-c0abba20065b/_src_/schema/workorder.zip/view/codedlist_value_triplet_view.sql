CREATE VIEW workorder.codedlist_value_triplet_view AS
  SELECT
    `vt`.`id`                    AS `id`,
    `vt`.`utc_create_time`       AS `utc_create_time`,
    `vt`.`test_type`             AS `test_type`,
    `vt`.`qualifier_type_id`     AS `qualifier_type_id`,
    `vt`.`approach_site_id`      AS `approach_site_id`,
    `vt`.`target_site_id`        AS `target_site_id`,
    `vt`.`value1_type`           AS `value1_type`,
    `vt`.`notation1_type`        AS `notation1_type`,
    `vt`.`notation1`             AS `notation1`,
    `vt`.`value1`                AS `value1`,
    `vt`.`value1_units`          AS `value1_units`,
    `vt`.`value2_type`           AS `value2_type`,
    `vt`.`notation2_type`        AS `notation2_type`,
    `vt`.`notation2`             AS `notation2`,
    `vt`.`value2`                AS `value2`,
    `vt`.`value2_units`          AS `value2_units`,
    `vt`.`value3_type`           AS `value3_type`,
    `vt`.`notation3_type`        AS `notation3_type`,
    `vt`.`notation3`             AS `notation3`,
    `vt`.`value3`                AS `value3`,
    `vt`.`value3_units`          AS `value3_units`,
    `vt`.`device_id`             AS `device_id`,
    `vt`.`next_id`               AS `next_id`,
    `vt`.`comment`               AS `comment`,
    `vt`.`file_id`               AS `file_id`,
    `vt`.`business_object_id`    AS `business_object_id`,
    `vt`.`ephr_section`          AS `ephr_section`,
    `vt`.`effective_date`        AS `effective_date`,
    `ct`.`codedlist_lookup_id`   AS `codedlist_lookup_id`,
    `cltc`.`common_name`         AS `child_common_name`,
    `cltc`.`parent_id`           AS `parent_id`,
    `cltc`.`concept_external_id` AS `concept_external_id`,
    `cltp`.`common_name`         AS `parent_common_name`,
    `bo`.`participant_id`        AS `participant_id`,
    `vt2`.`notation2`            AS `notation4`,
    `vt`.`triplet_updated_date`  AS `updated_date`
  FROM (((((`workorder`.`value_triplet_tbl` `vt`
    JOIN `workorder`.`codedlist_tbl` `ct` ON ((`vt`.`business_object_id` = `ct`.`id`))) JOIN
    `workorder`.`business_object_tbl` `bo` ON ((`bo`.`id` = `ct`.`id`))) JOIN `workorder`.`codedlist_lookup_tbl` `cltc`
      ON ((`cltc`.`id` = `ct`.`codedlist_lookup_id`))) JOIN `workorder`.`codedlist_lookup_tbl` `cltp`
      ON ((`cltp`.`id` = `cltc`.`parent_id`))) LEFT JOIN `workorder`.`value_triplet_tbl` `vt2`
      ON ((`vt`.`next_id` = `vt2`.`id`)));
