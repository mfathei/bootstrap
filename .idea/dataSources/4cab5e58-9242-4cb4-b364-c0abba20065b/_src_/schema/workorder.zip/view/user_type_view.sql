CREATE VIEW workorder.user_type_view AS
  (SELECT
     `workorder`.`user_tbl`.`id`                 AS `id`,
     `workorder`.`user_tbl`.`username`           AS `username`,
     `workorder`.`user_tbl`.`password`           AS `password`,
     `workorder`.`user_tbl`.`status`             AS `status`,
     `workorder`.`user_tbl`.`salt`               AS `salt`,
     `workorder`.`user_tbl`.`properties`         AS `properties`,
     `workorder`.`user_tbl`.`person_id`          AS `person_id`,
     `workorder`.`user_tbl`.`relationship_id`    AS `relationship_id`,
     `workorder`.`business_object_tbl`.`bo_name` AS `bo_name`,
     `workorder`.`user_group_tbl`.`group_name`   AS `group_name`
   FROM ((((`workorder`.`user_tbl`
     JOIN `workorder`.`person_tbl` ON ((`workorder`.`user_tbl`.`person_id` = `workorder`.`person_tbl`.`id`))) JOIN
     `workorder`.`business_object_tbl`
       ON ((`workorder`.`person_tbl`.`id` = `workorder`.`business_object_tbl`.`id`))) JOIN `workorder`.`ugu_tbl`
       ON ((`workorder`.`ugu_tbl`.`user_id` = `workorder`.`user_tbl`.`id`))) JOIN `workorder`.`user_group_tbl`
       ON ((`workorder`.`ugu_tbl`.`user_group_id` = `workorder`.`user_group_tbl`.`id`))));
