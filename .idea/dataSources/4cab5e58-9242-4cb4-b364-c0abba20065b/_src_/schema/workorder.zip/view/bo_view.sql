CREATE VIEW workorder.bo_view AS
  SELECT
    `bot`.`id`                 AS `id`,
    `bot`.`object_type_id`     AS `object_type_id`,
    `obt`.`object_type_name`   AS `object_type_name`,
    `obt`.`icon`               AS `object_type_icon`,
    `lookup`.`lookup_name`     AS `lookup_name`,
    `bot`.`list_index`         AS `list_index`,
    `bot`.`bo_name`            AS `bo_name`,
    `bot`.`fullname`           AS `fullname`,
    `bot`.`description`        AS `description`,
    `bot`.`properties`         AS `properties`,
    `bot`.`next_bo_id`         AS `next_bo_id`,
    `bot`.`value_id`           AS `value_id`,
    `bot`.`template_id`        AS `template_id`,
    `bot`.`business_rule_id`   AS `business_rule_id`,
    `bot`.`status`             AS `status`,
    `bot`.`hidden`             AS `hidden`,
    `bot`.`mobile_sync`        AS `mobile_sync`,
    `bot`.`last_accessed_date` AS `last_accessed_date`,
    `bot`.`update_type`        AS `update_type`,
    `bot`.`updated_date`       AS `updated_date`,
    `bot`.`created_date`       AS `created_date`,
    `bot`.`effective_date`     AS `effective_date`,
    `bot`.`expiry_date`        AS `expiry_date`,
    `bot`.`participant_id`     AS `participant_id`,
    `Ppt`.`first_name`         AS `participant_first_name`,
    `bot`.`owner_id`           AS `owner_id`,
    `ownerU`.`username`        AS `owner_name`,
    `bot`.`owner_group_id`     AS `owner_group_id`,
    `bot`.`last_accessor_id`   AS `last_accessor_id`,
    `bot`.`updator_id`         AS `updator_id`,
    `updatorU`.`username`      AS `updator_name`,
    `bot`.`creator_id`         AS `creator_id`,
    `creatorU`.`username`      AS `creator_name`,
    `bot`.`external_id`        AS `external_id`,
    `bot`.`external_source_id` AS `external_source_id`,
    `bot`.`file_id`            AS `file_id`,
    `bof`.`bo_name`            AS `file_name`,
    `bot`.`image_id`           AS `image_id`,
    `boi`.`bo_name`            AS `image_name`
  FROM (((((((((`workorder`.`business_object_tbl` `bot` LEFT JOIN `workorder`.`object_type_tbl` `obt`
      ON ((`bot`.`object_type_id` = `obt`.`id`))) LEFT JOIN `workorder`.`person_tbl` `Ppt`
      ON ((`bot`.`participant_id` = `Ppt`.`id`))) LEFT JOIN `workorder`.`user_tbl` `ownerU`
      ON ((`bot`.`owner_id` = `ownerU`.`id`))) LEFT JOIN `workorder`.`user_tbl` `updatorU`
      ON ((`bot`.`updator_id` = `updatorU`.`id`))) LEFT JOIN `workorder`.`user_tbl` `creatorU`
      ON ((`bot`.`creator_id` = `creatorU`.`id`))) LEFT JOIN `workorder`.`enterprise_tbl` `ent`
      ON ((`bot`.`id` = `ent`.`id`))) LEFT JOIN `workorder`.`lookup_tbl` `lookup`
      ON ((`ent`.`enterprise_type_id` = `lookup`.`id`))) LEFT JOIN `workorder`.`business_object_tbl` `bof`
      ON ((`bof`.`id` = `bot`.`id`))) LEFT JOIN `workorder`.`business_object_tbl` `boi` ON ((`boi`.`id` = `bot`.`id`)));
