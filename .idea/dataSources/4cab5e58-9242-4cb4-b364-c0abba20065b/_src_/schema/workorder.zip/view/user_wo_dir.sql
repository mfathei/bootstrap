CREATE VIEW workorder.user_wo_dir AS
  SELECT DISTINCT
    `d`.`dirname_id`    AS `dirname_id`,
    `d`.`dirname`       AS `dirname`,
    `d`.`dirname_index` AS `dirname_index`,
    `u`.`user_id`       AS `user_id`
  FROM (((`workorder`.`dir_name` `d`
    JOIN `workorder`.`dirname_group` `dg` ON ((`d`.`dirname_id` = `dg`.`dirname_id`))) JOIN `auth`.`user_group` `ug`
      ON ((`dg`.`group_id` = `ug`.`group_id`))) JOIN `auth`.`user` `u` ON ((`ug`.`user_id` = `u`.`user_id`)))
  ORDER BY `d`.`dirname_index`, `d`.`dirname`;
