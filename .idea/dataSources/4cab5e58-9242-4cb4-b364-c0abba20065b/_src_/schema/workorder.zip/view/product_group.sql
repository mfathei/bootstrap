CREATE VIEW workorder.product_group AS
  SELECT
    `workorder`.`relationship_tbl`.`id`           AS `id`,
    `workorder`.`relationship_tbl`.`subject_id`   AS `subject_id`,
    `workorder`.`relationship_tbl`.`object_id`    AS `object_id`,
    `workorder`.`relationship_tbl`.`start_date`   AS `start_date`,
    `workorder`.`relationship_tbl`.`end_date`     AS `end_date`,
    `workorder`.`relationship_tbl`.`list_index`   AS `list_index`,
    `workorder`.`relationship_tbl`.`properties`   AS `properties`,
    `workorder`.`relationship_tbl`.`rel_type_id`  AS `rel_type_id`,
    `workorder`.`relationship_tbl`.`contact_id`   AS `contact_id`,
    `workorder`.`relationship_tbl`.`subject_role` AS `subject_role`,
    `workorder`.`relationship_tbl`.`object_role`  AS `object_role`,
    `workorder`.`relationship_tbl`.`act`          AS `act`
  FROM `workorder`.`relationship_tbl`
  WHERE `workorder`.`relationship_tbl`.`object_id` IN (SELECT `workorder`.`business_object_tbl`.`id`
                                                       FROM `workorder`.`business_object_tbl`
                                                       WHERE `workorder`.`business_object_tbl`.`object_type_id` IN
                                                             (SELECT `workorder`.`object_type_tbl`.`id`
                                                              FROM `workorder`.`object_type_tbl`
                                                              WHERE (`workorder`.`object_type_tbl`.`object_type_name` =
                                                                     'product')));
