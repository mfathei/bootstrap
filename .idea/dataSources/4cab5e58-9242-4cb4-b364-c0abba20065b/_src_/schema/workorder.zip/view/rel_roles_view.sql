CREATE VIEW workorder.rel_roles_view AS
  SELECT
    `workorder`.`rel_roles_tbl`.`id`                  AS `id`,
    `workorder`.`rel_roles_tbl`.`object_role`         AS `object_role`,
    `workorder`.`rel_roles_tbl`.`subject_role`        AS `subject_role`,
    `workorder`.`rel_roles_tbl`.`object_role_abbrev`  AS `object_role_abbrev`,
    `workorder`.`rel_roles_tbl`.`subject_role_abbrev` AS `subject_role_abbrev`,
    `workorder`.`rel_type_tbl`.`rel_type_name`        AS `rel_type_name`
  FROM (`workorder`.`rel_roles_tbl`
    JOIN `workorder`.`rel_type_tbl` ON ((`workorder`.`rel_roles_tbl`.`rel_type_id` = `workorder`.`rel_type_tbl`.`id`)));
