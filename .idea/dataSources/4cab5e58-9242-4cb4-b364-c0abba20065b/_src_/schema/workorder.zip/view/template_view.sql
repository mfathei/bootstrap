CREATE VIEW workorder.template_view AS
  SELECT
    `workorder`.`template_tbl`.`id`                  AS `id`,
    `workorder`.`template_tbl`.`script`              AS `script`,
    `workorder`.`object_type_tbl`.`object_type_name` AS `object_type_name`,
    `workorder`.`template_tbl`.`template_name`       AS `template_name`,
    `workorder`.`template_tbl`.`properties`          AS `properties`
  FROM (`workorder`.`template_tbl`
    JOIN `workorder`.`object_type_tbl`
      ON ((`workorder`.`template_tbl`.`object_type_id` = `workorder`.`object_type_tbl`.`id`)));
