CREATE VIEW workorder.user_permission_view AS
  SELECT
    `workorder`.`user_permission_tbl`.`id`         AS `id`,
    `workorder`.`user_permission_tbl`.`permission` AS `permission`,
    `workorder`.`enterprise_tbl`.`enterprise_name` AS `enterprise_name`,
    `workorder`.`user_tbl`.`username`              AS `username`
  FROM ((`workorder`.`user_permission_tbl`
    JOIN `workorder`.`user_tbl` ON ((`workorder`.`user_permission_tbl`.`user_id` = `workorder`.`user_tbl`.`id`))) JOIN
    `workorder`.`enterprise_tbl`
      ON ((`workorder`.`user_permission_tbl`.`enterprise_id` = `workorder`.`enterprise_tbl`.`id`)));
