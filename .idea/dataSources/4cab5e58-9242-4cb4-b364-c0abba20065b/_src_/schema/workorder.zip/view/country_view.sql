CREATE VIEW workorder.country_view AS
  SELECT
    `workorder`.`country_tbl`.`id`           AS `id`,
    `workorder`.`country_tbl`.`country_name` AS `country_name`,
    `workorder`.`country_tbl`.`abbrev`       AS `abbrev`,
    `workorder`.`country_tbl`.`url`          AS `URL`,
    `workorder`.`country_tbl`.`phone_code`   AS `phone_code`,
    `workorder`.`country_tbl`.`properties`   AS `properties`,
    `workorder`.`currency_type_tbl`.`code`   AS `currency_type`,
    `workorder`.`company_tbl`.`abbrev`       AS `CompanyAbbrev`,
    `workorder`.`country_tbl`.`fed_tax_rate` AS `FedTaxRate`
  FROM ((`workorder`.`country_tbl`
    JOIN `workorder`.`currency_type_tbl`
      ON ((`workorder`.`country_tbl`.`currency_type_id` = `workorder`.`currency_type_tbl`.`id`))) LEFT JOIN
    `workorder`.`company_tbl` ON ((`workorder`.`company_tbl`.`id` = `workorder`.`country_tbl`.`company_id`)));
