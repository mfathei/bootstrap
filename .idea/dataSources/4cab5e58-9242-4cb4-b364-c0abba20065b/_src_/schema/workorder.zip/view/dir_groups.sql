CREATE VIEW workorder.dir_groups AS
  SELECT
    `a`.`group_id`    AS `group_id`,
    `a`.`group_name`  AS `group_name`,
    `a`.`is_primary`  AS `is_primary`,
    `dn`.`dirname_id` AS `dirname_id`
  FROM ((`auth`.`group` `a`
    JOIN `workorder`.`dirname_group` `dg` ON ((`a`.`group_id` = `dg`.`group_id`))) JOIN `workorder`.`dir_name` `dn`
      ON ((`dn`.`dirname_id` = `dg`.`dirname_id`)))
  ORDER BY `a`.`is_primary` DESC;
