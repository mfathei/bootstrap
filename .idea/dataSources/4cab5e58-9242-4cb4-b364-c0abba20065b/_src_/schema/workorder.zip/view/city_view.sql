CREATE VIEW workorder.city_view AS
  SELECT
    `workorder`.`city_tbl`.`id`                    AS `id`,
    `workorder`.`city_tbl`.`city_name`             AS `city_name`,
    `workorder`.`city_tbl`.`abbrev`                AS `city_abbrev`,
    `workorder`.`city_tbl`.`timezone_offset`       AS `timezone_offset`,
    `workorder`.`city_tbl`.`dayligtht_saving_time` AS `dayligtht_saving_time`,
    `workorder`.`country_tbl`.`country_name`       AS `country_name`,
    `workorder`.`country_tbl`.`id`                 AS `country_id`,
    `workorder`.`province_tbl`.`prov_name`         AS `prov_name`,
    `workorder`.`county_tbl`.`county_name`         AS `county_name`,
    `workorder`.`company_tbl`.`abbrev`             AS `abbrev`,
    `workorder`.`city_tbl`.`properties`            AS `CityProperties`,
    `workorder`.`city_tbl`.`city_tax_rate`         AS `CityTaxRate`
  FROM ((((`workorder`.`city_tbl`
    LEFT JOIN `workorder`.`province_tbl`
      ON ((`workorder`.`city_tbl`.`province_tbl_id` = `workorder`.`province_tbl`.`id`))) LEFT JOIN
    `workorder`.`country_tbl`
      ON ((`workorder`.`province_tbl`.`country_tbl_id` = `workorder`.`country_tbl`.`id`))) LEFT JOIN
    `workorder`.`county_tbl` ON ((`workorder`.`city_tbl`.`county_tbl_id` = `workorder`.`county_tbl`.`id`))) LEFT JOIN
    `workorder`.`company_tbl` ON ((`workorder`.`company_tbl`.`id` = `workorder`.`city_tbl`.`company_id`)));
