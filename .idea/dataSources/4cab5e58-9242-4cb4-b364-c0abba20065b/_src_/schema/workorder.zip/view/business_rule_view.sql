CREATE VIEW workorder.business_rule_view AS
  SELECT
    `workorder`.`business_rule_tbl`.`id`         AS `id`,
    `workorder`.`business_rule_tbl`.`script`     AS `script`,
    `workorder`.`business_rule_tbl`.`properties` AS `properties`,
    `bpname`.`script`                            AS `partnerscript`
  FROM (`workorder`.`business_rule_tbl`
    JOIN `workorder`.`business_rule_tbl` `bpname` ON ((`workorder`.`business_rule_tbl`.`next_id` = `bpname`.`id`)));
