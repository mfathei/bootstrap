CREATE VIEW workorder.county_view AS
  SELECT
    `workorder`.`county_tbl`.`id`              AS `id`,
    `workorder`.`county_tbl`.`county_name`     AS `county_name`,
    `workorder`.`province_tbl`.`prov_name`     AS `prov_name`,
    `workorder`.`country_tbl`.`country_name`   AS `country_name`,
    `workorder`.`company_tbl`.`abbrev`         AS `CompanyAbbrev`,
    `workorder`.`county_tbl`.`properties`      AS `Properties`,
    `workorder`.`county_tbl`.`county_tax_rate` AS `CountyTaxRate`
  FROM (((`workorder`.`county_tbl`
    JOIN `workorder`.`province_tbl`
      ON ((`workorder`.`county_tbl`.`province_tbl_id` = `workorder`.`province_tbl`.`id`))) LEFT JOIN
    `workorder`.`country_tbl`
      ON ((`workorder`.`province_tbl`.`country_tbl_id` = `workorder`.`country_tbl`.`id`))) LEFT JOIN
    `workorder`.`company_tbl` ON ((`workorder`.`county_tbl`.`company_id` = `workorder`.`company_tbl`.`id`)));
