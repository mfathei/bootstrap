CREATE VIEW workorder.user_role_view AS
  SELECT
    `workorder`.`user_role_tbl`.`id`   AS `id`,
    `workorder`.`user_role_tbl`.`role` AS `role`,
    `workorder`.`user_tbl`.`username`  AS `username`
  FROM (`workorder`.`user_role_tbl`
    JOIN `workorder`.`user_tbl` ON ((`workorder`.`user_role_tbl`.`user_id` = `workorder`.`user_tbl`.`id`)));
