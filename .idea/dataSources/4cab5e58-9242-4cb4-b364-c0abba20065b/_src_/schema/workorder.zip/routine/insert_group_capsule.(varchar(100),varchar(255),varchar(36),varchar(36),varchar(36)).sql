CREATE PROCEDURE workorder.insert_group_capsule(IN `$bo_name`        VARCHAR(100), IN `$fullname` VARCHAR(255),
                                                IN `$participant_id` VARCHAR(36), IN `$owner_id` VARCHAR(36),
                                                IN `$group_type`     VARCHAR(36))
  BEGIN 
    -- declare $relationship_id VARCHAR(36);
    -- declare $subject_id VARCHAR(36);
     DECLARE $contact_group_id VARCHAR(36);
    DECLARE $rel_type_id VARCHAR(36);
  --  set @c = checkRelationCapsule($relationship_id);
   -- if @c is null or @c = 0 then
      -- ------------------------
  
IF $group_type = 'emergency'  THEN
	SET $group_type= 'contacts_emergency_contacts';
    
ELSEIF $group_type = 'care'  THEN
	SET $group_type= 'care_team';
	
ELSEIF $group_type = 'fGeneric'  THEN
	SET $group_type= 'family(Genetic)';
	
ELSEIF $group_type = 'fLivingArrang' THEN
 SET $group_type= 'family(living_arrangement)';
ELSEIF $group_type = 'caregiver'  THEN
  SET $group_type= 'caregiver_clients';
  
ELSEIF $group_type = 'addressbook'  THEN
SET $group_type= 'address_book';
END IF;
SET $contact_group_id = ephr_intake_fun(  $participant_id ,$group_type);
    UPDATE business_object_tbl 
    SET trusted =1
    WHERE id=$contact_group_id ;
    
    
    -- -----------------------
    SET $bo_name = (SELECT CONCAT($bo_name,' ', bo_name, ' Capsule') FROM business_object_tbl WHERE id = $contact_group_id);
    
    -- ------------------------
    
		SET @mmid = UUID();-- uniqid
		SET @ginboxid = UUID();-- uniqid
        SET @gfillingid = UUID();-- uniqid
    SET @otype = (SELECT id FROM object_type_tbl WHERE object_type_name = 'Capsule');
    SET @inboxotype = (SELECT id FROM object_type_tbl WHERE object_type_name = 'Group');
    SELECT id INTO $rel_type_id FROM rel_type_tbl WHERE rel_type_name='Group to Relationship' AND rel_type_abbrev = 'g2rel' LIMIT 1;
    SET @rel_t = (SELECT id FROM rel_type_tbl WHERE rel_type_name = 'Contains' AND rel_type_abbrev = 'g2g' LIMIT 1);
    INSERT INTO `business_object_tbl`
    (`id`,
    `object_type_id`,
    `bo_name`,
    `fullname`,
    `hidden`,
    `last_accessed_date`,
    `updated_date`,
    `created_date`,
    `effective_date`,
    `participant_id`,
    `owner_id`,
    `owner_group_id`,
    `updator_id`,
    `creator_id`)
    VALUES
    (@mmid,
    @otype ,
    $bo_name,
    $fullname,
    0,
    CURRENT_TIMESTAMP(),
    CURRENT_TIMESTAMP(),
    CURRENT_TIMESTAMP(),
    NULL,
    $participant_id,
    $owner_id,
    NULL,
    $owner_id,
    $owner_id);
    
    -- Inbox
    INSERT INTO `business_object_tbl`
    (`id`,
    `object_type_id`,
    `bo_name`,
    `fullname`,
    `hidden`,
    `last_accessed_date`,
    `updated_date`,
    `created_date`,
    `effective_date`,
    `participant_id`,
    `owner_id`,
    `owner_group_id`,
    `updator_id`,
    `creator_id`)
    VALUES
    (@ginboxid,
     @inboxotype ,
    'Inbox',
    'Inbox',
    0,
    CURRENT_TIMESTAMP(),
    CURRENT_TIMESTAMP(),
    CURRENT_TIMESTAMP(),
    NULL,
    $participant_id,
    $owner_id,
    NULL,
    $owner_id,
    $owner_id);
    
    -- Filing System
        INSERT INTO `business_object_tbl`
    (`id`,
    `object_type_id`,
    `bo_name`,
    `fullname`,
    `hidden`,
    `last_accessed_date`,
    `updated_date`,
    `created_date`,
    `effective_date`,
    `participant_id`,
    `owner_id`,
    `owner_group_id`,
    `updator_id`,
    `creator_id`)
    VALUES
    (@gfillingid,
     @inboxotype ,
    'Filing System',
    'Filing System',
    0,
    CURRENT_TIMESTAMP(),
    CURRENT_TIMESTAMP(),
    CURRENT_TIMESTAMP(),
    NULL,
    $participant_id,
    $owner_id,
    NULL,
    $owner_id,
    $owner_id);
    -- --------------------------------------------------------------------------------------------
    INSERT INTO `relationship_tbl`
    (`id`,
    `subject_id`,
    `object_id`,
    `start_date`,
    `end_date`,
    `list_index`,
    `properties`,
    `rel_type_id`,
    `rel_type_name`,
    `contact_id`,
    `rel_roles_id`,
    `subject_role`,
    `object_role`,
    `act`)
    VALUES
    (@mmid,
   $contact_group_id,
    @mmid,
    CURRENT_TIMESTAMP(),
    NULL,
    NULL,
    NULL,
    $rel_type_id,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL);
    
    
     -- inbox
    INSERT INTO `relationship_tbl`
    (`id`,
    `subject_id`,
    `object_id`,
    `start_date`,
    `end_date`,
    `list_index`,
    `properties`,
    `rel_type_id`,
    `rel_type_name`,
    `contact_id`,
    `rel_roles_id`,
    `subject_role`,
    `object_role`,
    `act`)
    VALUES
    (@ginboxid,
    @mmid,
    @ginboxid,
    CURRENT_TIMESTAMP(),
    NULL,
    NULL,
    NULL,
    @rel_t,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL);
    
    -- Filing System
    INSERT INTO `relationship_tbl`
    (`id`,
    `subject_id`,
    `object_id`,
    `start_date`,
    `end_date`,
    `list_index`,
    `properties`,
    `rel_type_id`,
    `rel_type_name`,
    `contact_id`,
    `rel_roles_id`,
    `subject_role`,
    `object_role`,
    `act`)
    VALUES
    (@gfillingid,
    @mmid,
    @gfillingid,
    CURRENT_TIMESTAMP(),
    NULL,
    NULL,
    NULL,
    @rel_t,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL,
    NULL);
    
    
    
 --   end if;
   
    
END;
