CREATE FUNCTION workorder.getObservationIDByOrigin(`$original_id` VARCHAR(45))
  RETURNS VARCHAR(50)
  BEGIN
RETURN (select id from observation_lookup_tbl where original_id = $original_id);
END;
