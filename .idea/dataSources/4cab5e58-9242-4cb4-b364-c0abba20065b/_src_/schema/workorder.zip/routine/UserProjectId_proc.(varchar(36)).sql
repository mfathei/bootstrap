CREATE PROCEDURE workorder.UserProjectId_proc(IN `$UserId` VARCHAR(36))
  BEGIN
DECLARE $ePHRecordId VARCHAR(36);
DECLARE $WellnessPlansId VARCHAR(36);
SET $ePHRecordId = (SELECT id FROM enterprise_tbl WHERE user_id = $UserId AND enterprise_name = 'ePHRecord');
SET $WellnessPlansId = (SELECT id FROM business_object_tbl WHERE id IN (SELECT object_id FROM relationship_tbl WHERE subject_id = $ePHRecordId AND object_id IN (SELECT id FROM business_object_tbl WHERE object_type_id = (SELECT id FROM object_type_tbl WHERE object_type_name = 'group' AND fullname = 'Wellness Plans'))));
SELECT id FROM business_object_tbl WHERE hidden = 0 AND id IN (SELECT object_id FROM relationship_tbl WHERE subject_id = $WellnessPlansId);
END;
