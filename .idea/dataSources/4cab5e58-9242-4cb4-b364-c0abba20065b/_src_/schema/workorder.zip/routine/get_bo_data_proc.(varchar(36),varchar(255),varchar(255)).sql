CREATE PROCEDURE workorder.get_bo_data_proc(IN `$person_id` VARCHAR(36), IN `$identifier` VARCHAR(255),
                                            IN `$view_name` VARCHAR(255))
  BEGIN
DECLARE $db_name, $col_name VARCHAR(255);
DECLARE $id VARCHAR(36);
SET $db_name = (SELECT DATABASE());
SET $col_name = (SELECT `COLUMN_NAME` FROM information_schema.`COLUMNS` WHERE `TABLE_SCHEMA` = $db_name AND `TABLE_NAME` = $view_name AND ORDINAL_POSITION = 1);
SET $id = (SELECT ephr_intake_fun($person_id, $identifier));
SET @qry = (SELECT CONCAT('SELECT * FROM ',`TABLE_NAME`,' WHERE ',$col_name,' = '',$id,'';') FROM information_schema.`TABLES` WHERE `TABLE_SCHEMA` = $db_name AND `TABLE_NAME` = $view_name);
PREPARE stmt FROM @qry;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END;
