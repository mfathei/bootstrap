CREATE PROCEDURE workorder.project_bo_proc(IN xmlData TEXT)
  BEGIN
DECLARE $ePHRecordId VARCHAR(36);
DECLARE $WellnessPlansId VARCHAR(36);
DECLARE $UserId VARCHAR(36);
SET @page = EXTRACTVALUE(xmlData, '//page');
SET @LIMIT = EXTRACTVALUE(xmlData, '//limit');
SET @sortOrder =  EXTRACTVALUE(xmlData, '//sortOrder');
SET @INDEX =  EXTRACTVALUE(xmlData, '//index');
SET @Export =  EXTRACTVALUE(xmlData, '//Export');
SET @Opeartion =  EXTRACTVALUE(xmlData, '//Opeartion');
SET @UserId =  EXTRACTVALUE(xmlData, '//UserId');
/*if @UserId <> 'test' then
set @ePHRecord = 'ePHRecord';
set @ePHRecordId =  concat( 'select id from enterprise_tbl where user_id = ',"'",@UserId,"'", ' and enterprise_name = ',"'",@ePHRecord,"'");
select @ePHRecordId;
SET @query1 =  CONCAT( 'SELECT id into @id from  (', @ePHRecordId, ' ) t');
PREPARE stmt1 FROM @query1;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
set @WellnessPlansId = concat('select id from business_object_tbl where id in (select object_id from relationship_tbl where subject_id =',"'", @id,"'",' and object_id in (select id from business_object_tbl where object_type_id = (select id from object_type_tbl where object_type_name =',"'",'group',"'",' and fullname = ',"'",'Wellness Plans',"'",')))');
SET @query2 =  CONCAT( 'SELECT id into @Wid from  (', @WellnessPlansId, ' ) t');
PREPARE stmt1 FROM @query2;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
end if;*/
SET @selectquery ="SELECT *	";
SET @queryFrom = " FROM project_bo_view ";
SET @queryWhere = ' where bo_properties != "<bo><Identifier>service_request</Identifier></bo>" ';
SET @queryWhere = CONCAT(@queryWhere,' and hidden = 0 ');
SET @myArrayOfValue = 'bo_id,object_type_id,list_index,bo_name,fullname,description,bo_properties,next_bo_id,value_id,template_id,business_rule_id,status,hidden,mobile_sync,last_accessed_date,update_type,updated_date,created_date,effective_date,expiry_date,participant_id,owner_id,last_accessor_id,updator_id,creator_id,external_id,external_key_id,external_source_id,file_id,image_id,ProjectId,task_type_id,task_number,book_date,date_accuracy_type,priority_type,qualitative_type,planned_start_date,planned_end_date,planned_effort,planned_duration,actual_start_date,actual_end_date,actual_effort,actual_duration,percent_complete,active,properties,effort_units_id,duration_units_id,recurring_freqency,recurring_units_id,recurring_term,recurring_term_units_id,itemlist_id,action_list_id,';
SET @Postition = LOCATE(',', @myArrayOfValue);
WHILE ( @Postition > 0 ) DO
	SET @STR = SUBSTRING(@myArrayOfValue, 1, @Postition-1);
	SET @myArrayOfValue = SUBSTRING(@myArrayOfValue, @Postition + 1);
	SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//',@STR));
	IF (@Col != '' AND @Col !='NULL') THEN
		IF (@Opeartion = 'like' OR @Opeartion = '' ) THEN	
			SET @queryWhere = CONCAT(@queryWhere,CONCAT(' AND ',@STR,' like('"'%", @Col ,"%'"') '));	
		ELSE
			IF (@Opeartion = '!=') THEN
				SET @Opeartion = '<>';
			END IF;
			SET @queryWhere = CONCAT(@queryWhere,CONCAT(' AND BINARY ',@STR, @Opeartion ,"'", @Col ,"'"' '));
		END IF;
		-- SET @queryWhere = CONCAT(@queryWhere,CONCAT(' AND ',@STR,' like('"'%", @Col ,"%'"') '));	
	END IF;
	
	SET @Postition = LOCATE(',', @myArrayOfValue);
END WHILE;
IF @UserId <> 'test' THEN
SET @queryWhere = CONCAT(@queryWhere, ' and participant_id = ( select person_id from user_tbl where id  = ',"'",@UserId,"'",' )');
END IF;
SET @querycount = CONCAT( 'SELECT count(*) into @cnt ', @queryFrom, @queryWhere );
PREPARE stmt1 FROM @querycount;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
	
SET @selectquery = CONCAT (@selectquery,', ', @cnt, ' as Count ');
SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );
 IF(@index ='id') THEN	SET @index ='ProjectId'; END IF;
IF( @index = 'Order') THEN SET  @index = '`Order`';  END IF;
SET @query = CONCAT(@query, ' order by ', @index,'  ', @sortOrder);
IF( @Export ="false") THEN
SET @page = (@page - 1) * @limit;
 SET @query = CONCAT(@query, ' LIMIT ', @limit ,' OFFSET ',  @page);
END IF;
PREPARE stmt1 FROM @query;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
END;
