CREATE PROCEDURE workorder.get_parent_level_proc(IN `$ephr_section` VARCHAR(24))
  BEGIN
SELECT id, lookup_name, common_name FROM codedlist_lookup_tbl 
WHERE parent_id IN (SELECT id FROM codedlist_lookup_tbl WHERE ephr_section = $ephr_section AND active = 1 AND `level` = 2);
END;
