CREATE FUNCTION workorder.intake_statistics_fun(`$test_type` VARCHAR(24), `$notation1_type` VARCHAR(45),
                                                `$notation1` VARCHAR(100), `$notation_type` VARCHAR(45),
                                                `$bo_id`     VARCHAR(36), `$notation` VARCHAR(100), `$notation_no` INT)
  RETURNS INT
  BEGIN
DECLARE $count int;
if $notation_no = 2 then
set $count = (select count(notation2) from value_triplet_tbl where test_type = $test_type and business_object_id = $bo_id and notation1_type = $notation1_type and notation1 = $notation1 and notation2_type= $notation_type and notation2 = $notation);
end if; 
if $notation_no = 3 then 
set $count = (select count(notation3) from value_triplet_tbl where test_type = $test_type and business_object_id = $bo_id and notation1_type = $notation1_type and notation1 = $notation1 and notation3_type= $notation_type and notation3 = $notation);
end if;
RETURN $count;
END;
