CREATE FUNCTION workorder.checkPersonQuestionBin(`$person_id` VARCHAR(36), `$question` TEXT, `$binNumber` VARCHAR(64))
  RETURNS INT(2)
  BEGIN
    SET @bin = 
    (SELECT 
        person_id 
    FROM
        user_tbl 
        JOIN account_tbl 
            ON account_tbl.cust_vend_id = user_tbl.person_id 
            AND user_tbl.person_id = $person_id 
            AND account_tbl.vend_access_code = $binNumber 
    LIMIT 1) ;
    
    IF @bin IS NULL 
    THEN 
        RETURN 0 ;
    END IF ;
    
    SET @q = 
    (SELECT 
        id 
    FROM
        security_qna_tbl 
    WHERE person_id = $person_id 
        AND question = $question 
    LIMIT 1) ;
    
    IF @q IS NULL 
    THEN 
        RETURN 0 ;
    END IF ;
    
    RETURN 1 ;
END;
