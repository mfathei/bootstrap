CREATE FUNCTION workorder.checkPersonPassword(`$person_id` VARCHAR(36), `$passwrd` TEXT)
  RETURNS INT(2)
  BEGIN
    SET @bin = 
    (SELECT 
        person_id 
    FROM
        user_tbl 
            WHERE user_tbl.person_id = $person_id 
            AND user_tbl.password = $passwrd
    LIMIT 1) ;
    
    IF @bin IS NOT NULL 
    THEN 
        RETURN 1;
    END IF ;
    
    RETURN 0;
END;
