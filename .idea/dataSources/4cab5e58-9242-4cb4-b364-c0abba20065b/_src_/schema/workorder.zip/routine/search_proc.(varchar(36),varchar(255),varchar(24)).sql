CREATE PROCEDURE workorder.search_proc(IN `$user_id`          VARCHAR(36), IN `$bo_name` VARCHAR(255),
                                       IN `$object_type_name` VARCHAR(24))
  BEGIN
DECLARE $object_type_id VARCHAR(36);
DECLARE $person_id VARCHAR(36);
IF $user_id  = '' THEN 
	SET $user_id = NULL;
END IF; 
IF $bo_name  = '' THEN 
	SET $bo_name = NULL;
END IF; 
IF $object_type_name  = '' THEN 
	SET $object_type_name = NULL;
END IF; 
	
SET $object_type_id = (SELECT id FROM object_type_tbl WHERE object_type_name = $object_type_name);
SET $person_id = (SELECT person_id FROM user_tbl WHERE id = $user_id);
SET $bo_name = CONCAT('%',$bo_name,'%');
	IF $user_id IS NOT NULL AND $bo_name IS NOT NULL AND $object_type_id IS NOT NULL THEN 
			SELECT id, bo_name FROM business_object_tbl WHERE (owner_id = $user_id OR id IN (SELECT subject_id FROM 			relationship_tbl
			WHERE object_id = $person_id) OR id IN (SELECT object_id FROM relationship_tbl WHERE subject_id = 			$person_id)) AND bo_name LIKE $bo_name AND object_type_id = $object_type_id
			ORDER BY object_type_id, bo_name ;
	END IF;
	IF $user_id IS NOT NULL AND $bo_name IS NOT NULL AND $object_type_id IS  NULL THEN 
			SELECT id, bo_name FROM business_object_tbl WHERE (owner_id = $user_id OR id IN (SELECT subject_id FROM 			relationship_tbl
			WHERE object_id = $person_id) OR id IN (SELECT object_id FROM relationship_tbl WHERE subject_id = 			$person_id)) AND bo_name LIKE $bo_name 
			ORDER BY object_type_id, bo_name ;
	END IF;
	IF $user_id IS NOT NULL AND $bo_name IS  NULL AND $object_type_id IS  NULL THEN 
			SELECT id, bo_name FROM business_object_tbl WHERE (owner_id = $user_id OR id IN (SELECT subject_id FROM 			relationship_tbl
			WHERE object_id = $person_id) OR id IN (SELECT object_id FROM relationship_tbl WHERE subject_id = 				$person_id))
			ORDER BY object_type_id, bo_name ;
	END IF;
	IF $user_id IS NOT NULL AND $bo_name IS  NULL AND $object_type_id IS NOT NULL THEN 
			SELECT id, bo_name FROM business_object_tbl WHERE (owner_id = $user_id OR id IN (SELECT subject_id FROM relationship_tbl
			WHERE object_id = $person_id) OR id IN (SELECT object_id FROM relationship_tbl WHERE subject_id = $person_id)) AND object_type_id = $object_type_id
			ORDER BY object_type_id, bo_name ;
	END IF;
	IF $user_id IS  NULL AND $bo_name IS NOT NULL AND $object_type_id IS  NULL THEN 
			SELECT id, bo_name FROM business_object_tbl WHERE bo_name LIKE $bo_name 
			ORDER BY object_type_id, bo_name ;
	END IF;
	IF $user_id IS  NULL AND $bo_name IS NOT NULL AND $object_type_id IS NOT NULL THEN 
			SELECT id, bo_name FROM business_object_tbl WHERE  bo_name LIKE $bo_name AND object_type_id = 				$object_type_id
			ORDER BY object_type_id, bo_name ;
	END IF;
	IF $user_id IS  NULL AND $bo_name IS  NULL AND $object_type_id IS NOT NULL THEN 
			SELECT id, bo_name FROM business_object_tbl WHERE  object_type_id = $object_type_id
			ORDER BY object_type_id, bo_name ;
	END IF;
	IF $user_id IS  NULL AND $bo_name IS  NULL AND $object_type_id IS NOT NULL THEN 
			SELECT id, bo_name FROM business_object_tbl /*where  object_type_id = $object_type_id*/
			ORDER BY object_type_id, bo_name ;
	END IF;
END;
