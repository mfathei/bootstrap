CREATE PROCEDURE workorder.insert_capsule(IN `$bo_name`         VARCHAR(100), IN `$fullname` VARCHAR(255),
                                          IN `$participant_id`  VARCHAR(36), IN `$owner_id` VARCHAR(36),
                                          IN `$relationship_id` VARCHAR(36))
  BEGIN 
    DECLARE $subject_id VARCHAR(36);
    DECLARE $rel_type_id VARCHAR(36);
    DECLARE $rel_fulname TEXT DEFAULT '';
    DECLARE $bi_rel_id VARCHAR(36);
    
    SET @c = checkRelationCapsule($relationship_id);
    IF @c IS NULL OR @c = 0 THEN
		SET @mid = UUID();-- uniqid
        SET @inboxid = UUID();-- uniqid
        SET @fillingid = UUID();-- uniqid
        SET @otype = (SELECT id FROM object_type_tbl WHERE object_type_name = 'Capsule');
        SET @inboxotype = (SELECT id FROM object_type_tbl WHERE object_type_name = 'Group');
        SELECT subject_id,rel_type_id,fullname INTO $subject_id, $rel_type_id, $rel_fulname FROM relationships_bo_view WHERE rel_id=$relationship_id;
        SET @rel_t = (SELECT id FROM rel_type_tbl WHERE rel_type_name = 'Contains' AND rel_type_abbrev = 'g2g' LIMIT 1);
        INSERT INTO `business_object_tbl`
        (`id`,
        `object_type_id`,
        `bo_name`,
        `fullname`,
        `hidden`,
        `last_accessed_date`,
        `updated_date`,
        `created_date`,
        `effective_date`,
        `participant_id`,
        `owner_id`,
        `owner_group_id`,
        `updator_id`,
        `creator_id`)
        VALUES
        (@mid,
        @otype ,
        $bo_name,
        $fullname,
        0,
        CURRENT_TIMESTAMP(),
        CURRENT_TIMESTAMP(),
        CURRENT_TIMESTAMP(),
        NULL,
        $participant_id,
        $owner_id,
        NULL,
        $owner_id,
        $owner_id);
        -- Inbox
        INSERT INTO `business_object_tbl`
        (`id`,
        `object_type_id`,
        `bo_name`,
        `fullname`,
        `hidden`,
        `last_accessed_date`,
        `updated_date`,
        `created_date`,
        `effective_date`,
        `participant_id`,
        `owner_id`,
        `owner_group_id`,
        `updator_id`,
        `creator_id`)
        VALUES
        (@inboxid,
         @inboxotype ,
        'Inbox',
        'Inbox',
        0,
        CURRENT_TIMESTAMP(),
        CURRENT_TIMESTAMP(),
        CURRENT_TIMESTAMP(),
        NULL,
        $participant_id,
        $owner_id,
        NULL,
        $owner_id,
        $owner_id);
        -- Filing System
            INSERT INTO `business_object_tbl`
        (`id`,
        `object_type_id`,
        `bo_name`,
        `fullname`,
        `hidden`,
        `last_accessed_date`,
        `updated_date`,
        `created_date`,
        `effective_date`,
        `participant_id`,
        `owner_id`,
        `owner_group_id`,
        `updator_id`,
        `creator_id`)
        VALUES
        (@fillingid,
         @inboxotype ,
        'Filing System',
        'Filing System',
        0,
        CURRENT_TIMESTAMP(),
        CURRENT_TIMESTAMP(),
        CURRENT_TIMESTAMP(),
        NULL,
        $participant_id,
        $owner_id,
        NULL,
        $owner_id,
        $owner_id);
        -- --------------------------------------------------------------------------------------------
        INSERT INTO `relationship_tbl`
        (`id`,
        `subject_id`,
        `object_id`,
        `start_date`,
        `end_date`,
        `list_index`,
        `properties`,
        `rel_type_id`,
        `rel_type_name`,
        `contact_id`,
        `rel_roles_id`,
        `subject_role`,
        `object_role`,
        `act`)
        VALUES
        (@mid,
        $relationship_id,
        @mid,
        CURRENT_TIMESTAMP(),
        NULL,
        NULL,
        NULL,
        $rel_type_id,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL);
        -- inbox
        INSERT INTO `relationship_tbl`
        (`id`,
        `subject_id`,
        `object_id`,
        `start_date`,
        `end_date`,
        `list_index`,
        `properties`,
        `rel_type_id`,
        `rel_type_name`,
        `contact_id`,
        `rel_roles_id`,
        `subject_role`,
        `object_role`,
        `act`)
        VALUES
        (@inboxid,
        @mid,
        @inboxid,
        CURRENT_TIMESTAMP(),
        NULL,
        NULL,
        NULL,
        @rel_t,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL);
        
        -- Filing System
        INSERT INTO `relationship_tbl` 
        (`id`,
        `subject_id`,
        `object_id`,
        `start_date`,
        `end_date`,
        `list_index`,
        `properties`,
        `rel_type_id`,
        `rel_type_name`,
        `contact_id`,
        `rel_roles_id`,
        `subject_role`,
        `object_role`,
        `act`)
        VALUES
        (@fillingid,
        @mid,
        @fillingid,
        CURRENT_TIMESTAMP(),
        NULL,
        NULL,
        NULL,
        @rel_t,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL);
        
        
    END IF;
   /**
    -- ---------------------------------------------------------------- bidirection ------------------------------------------
    -- SET $rel_fulname = pattern_exchange($rel_fulname, ':', 1, 5);
    
    SELECT subject_id,rel_type_id,rel_id, rel_participant, object_id INTO $subject_id, $rel_type_id, $bi_rel_id, @part_id, @obj_id FROM relationships_bo_view WHERE hidden = 0 and fullname = $rel_fulname and rel_id <> $relationship_id LIMIT 1;
    SET @c = checkRelationCapsule($bi_rel_id);
    IF @c IS NULL OR @c = 0 THEN
        set @o_id  = (select owner_id from business_object_tbl where id = @obj_id);
		SET @mid = UUID();-- uniqid
        SET @inboxid = UUID();-- uniqid
        SET @fillingid = UUID();-- uniqid
        -- SET @otype = (SELECT id FROM object_type_tbl WHERE object_type_name = 'Capsule');
        -- SET @inboxotype = (SELECT id FROM object_type_tbl WHERE object_type_name = 'Group');
        -- SELECT subject_id,rel_type_id INTO $subject_id, $rel_type_id FROM relationships_bo_view WHERE rel_id=$bi_rel_id;
        -- SET @rel_t = (SELECT id FROM rel_type_tbl WHERE rel_type_name = 'Contains' AND rel_type_abbrev = 'g2g' LIMIT 1);
        INSERT INTO `business_object_tbl`
        (`id`,
        `object_type_id`,
        `bo_name`,
        `fullname`,
        `hidden`,
        `last_accessed_date`,
        `updated_date`,
        `created_date`,
        `effective_date`,
        `participant_id`,
        `owner_id`,
        `owner_group_id`,
        `updator_id`,
        `creator_id`)
        VALUES
        (@mid,
        @otype ,
        $bo_name,
        $fullname,
        0,
        CURRENT_TIMESTAMP(),
        CURRENT_TIMESTAMP(),
        CURRENT_TIMESTAMP(),
        NULL,
        @part_id,
        @o_id,
        NULL,
        @o_id,
        @o_id);
        -- Inbox
        INSERT INTO `business_object_tbl`
        (`id`,
        `object_type_id`,
        `bo_name`,
        `fullname`,
        `hidden`,
        `last_accessed_date`,
        `updated_date`,
        `created_date`,
        `effective_date`,
        `participant_id`,
        `owner_id`,
        `owner_group_id`,
        `updator_id`,
        `creator_id`)
        VALUES
        (@inboxid,
         @inboxotype ,
        'Inbox',
        'Inbox',
        0,
        CURRENT_TIMESTAMP(),
        CURRENT_TIMESTAMP(),
        CURRENT_TIMESTAMP(),
        NULL,
        @part_id,
        @o_id,
        NULL,
        @o_id,
        @o_id);
        -- Filing System
            INSERT INTO `business_object_tbl`
        (`id`,
        `object_type_id`,
        `bo_name`,
        `fullname`,
        `hidden`,
        `last_accessed_date`,
        `updated_date`,
        `created_date`,
        `effective_date`,
        `participant_id`,
        `owner_id`,
        `owner_group_id`,
        `updator_id`,
        `creator_id`)
        VALUES
        (@fillingid,
         @inboxotype ,
        'Filing System',
        'Filing System',
        0,
        CURRENT_TIMESTAMP(),
        CURRENT_TIMESTAMP(),
        CURRENT_TIMESTAMP(),
        NULL,
        @part_id,
        @o_id,
        NULL,
        @o_id,
        @o_id);
        -- --------------------------------------------------------------------------------------------
        INSERT INTO `relationship_tbl`
        (`id`,
        `subject_id`,
        `object_id`,
        `start_date`,
        `end_date`,
        `list_index`,
        `properties`,
        `rel_type_id`,
        `rel_type_name`,
        `contact_id`,
        `rel_roles_id`,
        `subject_role`,
        `object_role`,
        `act`)
        VALUES
        (@mid,
        $bi_rel_id,
        @mid,
        CURRENT_TIMESTAMP(),
        NULL,
        NULL,
        NULL,
        $rel_type_id,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL);
        -- inbox
        INSERT INTO `relationship_tbl`
        (`id`,
        `subject_id`,
        `object_id`,
        `start_date`,
        `end_date`,
        `list_index`,
        `properties`,
        `rel_type_id`,
        `rel_type_name`,
        `contact_id`,
        `rel_roles_id`,
        `subject_role`,
        `object_role`,
        `act`)
        VALUES
        (@inboxid,
        @mid,
        @inboxid,
        CURRENT_TIMESTAMP(),
        NULL,
        NULL,
        NULL,
        @rel_t,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL);
        
        -- Filing System
        INSERT INTO `relationship_tbl` 
        (`id`,
        `subject_id`,
        `object_id`,
        `start_date`,
        `end_date`,
        `list_index`,
        `properties`,
        `rel_type_id`,
        `rel_type_name`,
        `contact_id`,
        `rel_roles_id`,
        `subject_role`,
        `object_role`,
        `act`)
        VALUES
        (@fillingid,
        @mid,
        @fillingid,
        CURRENT_TIMESTAMP(),
        NULL,
        NULL,
        NULL,
        @rel_t,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL,
        NULL);
        
        
    END IF;
   */
END;
