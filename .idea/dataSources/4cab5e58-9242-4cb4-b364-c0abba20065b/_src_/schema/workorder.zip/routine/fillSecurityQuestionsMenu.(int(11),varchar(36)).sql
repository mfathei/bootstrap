CREATE PROCEDURE workorder.fillSecurityQuestionsMenu(IN `$questionNumber` INT, IN `$person_id` VARCHAR(36))
  BEGIN
    DROP TEMPORARY TABLE IF EXISTS seq_questions;
    CREATE TEMPORARY TABLE seq_questions(question TEXT, id VARCHAR(36));
    
    SET @lookup_type = (SELECT (CASE $questionNumber WHEN 1 THEN 'SecurityQuestion1' WHEN 2 THEN 'SecurityQuestion2' WHEN 3 THEN 'SecurityQuestion3' ELSE NULL END));
    IF @lookup_type IS NOT NULL THEN
        INSERT INTO seq_questions 
        SELECT lookup_tbl.lookup_name,lookup_tbl.id
        FROM lookup_tbl
        INNER JOIN lookup_type_tbl
        ON lookup_tbl.lookup_type_id = lookup_type_tbl.id
        WHERE lookup_type_tbl.lookup_type_name = @lookup_type
        ORDER BY lookup_tbl.lookup_name ASC;
    END IF;
    
    SET @q = NULL;
    SELECT getCleanQuestion(question) ,id INTO @q,@i FROM security_qna_tbl
    WHERE question_num = $questionNumber AND person_id = $person_id LIMIT 1;
    
    SET @already = (
        SELECT question FROM seq_questions WHERE question = @q LIMIT 1
    );
    
    IF @already IS NULL AND @q IS NOT NULL THEN
        INSERT INTO seq_questions VALUES(@q, @i);
    END IF;
    
    SELECT question AS lookup_name, id FROM seq_questions;
    
END;
