CREATE PROCEDURE workorder.insertMyListAndDocsInGroups()
  BEGIN
    DECLARE finish INT DEFAULT 0 ;
    DECLARE uid VARCHAR (100) ;
    DECLARE pid VARCHAR (100) ;
    DECLARE std_name_sur CURSOR FOR 
    SELECT 
        id,
        person_id 
    FROM
        user_tbl 
    ;-- where person_id = "2c9a1efa-863b-11e4-a123-5254000a52fa"; -- pauldavis -- id = '5362cfb9-1f13-11e5-9d99-5254000a52fa' ; -- sarah
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET finish = 1 ;
    
    DECLARE EXIT HANDLER FOR sqlexception
    BEGIN
        rollback;
    END;
    
    DECLARE EXIT HANDLER FOR sqlwarning
    BEGIN
        rollback;
    END;
    
    SET @c = 0 ;
    OPEN std_name_sur ;
    
    START transaction;
    
    std_name_loop :
    LOOP
        FETCH std_name_sur INTO uid,
        pid ;
        IF finish = 1 
        THEN LEAVE std_name_loop ;
        END IF ;
        -- select uid,pid;
        -- ------------------------------------------------------------------------------------------
        -- get two subgroups ids
        -- set @mylist_id = (select id from business_object_tbl where properties = "<bo><Identifier>mylist_group</Identifier></bo>" and participant_id = pid);
        -- set @docs_id = (select id from business_object_tbl where properties = "<bo><Identifier>mylist_documents</Identifier></bo>" and participant_id = pid);
        
        set @reltype_id = '7b93f40d-d6d7-11e3-b867-1c6f65f2b147'; -- contains g2g
        
        set @PresentHealthConcerns = (select id from business_object_tbl where properties = "<bo><Identifier>present_health_concerns</Identifier></bo>" and participant_id = pid);
        set @PresentHealthConcernsName = (select bo_name from business_object_tbl where properties = "<bo><Identifier>present_health_concerns</Identifier></bo>" and participant_id = pid);
        set @Symptoms = (select id from business_object_tbl where properties = "<bo><Identifier>symptoms</Identifier></bo>" and participant_id = pid);
        set @SymptomsName = (select bo_name from business_object_tbl where properties = "<bo><Identifier>symptoms</Identifier></bo>" and participant_id = pid);
        set @PainObservations =(select id from business_object_tbl where properties = "<bo><Identifier>pain_observations</Identifier></bo>" and participant_id = pid);
        set @PainObservationsName =(select bo_name from business_object_tbl where properties = "<bo><Identifier>pain_observations</Identifier></bo>" and participant_id = pid);
        set @PersonalMedicalHistory = (select id from business_object_tbl where properties = "<bo><Identifier>personal_medical_history</Identifier></bo>" and participant_id = pid);
        set @PersonalMedicalHistoryName = (select bo_name from business_object_tbl where properties = "<bo><Identifier>personal_medical_history</Identifier></bo>" and participant_id = pid);
        set @MedicalDiagnosticHistory =(select id from business_object_tbl where properties = "<bo><Identifier>medical_(diagnostic)_history</Identifier></bo>" and participant_id = pid);
        set @MedicalDiagnosticHistoryName =(select bo_name from business_object_tbl where properties = "<bo><Identifier>medical_(diagnostic)_history</Identifier></bo>" and participant_id = pid);
        set @InjuryPoisoningExternalCause = (select id from business_object_tbl where properties = "<bo><Identifier>injury_&_poisoning_+_external_cuase</Identifier></bo>" and participant_id = pid);
        set @InjuryPoisoningExternalCauseName = (select bo_name from business_object_tbl where properties = "<bo><Identifier>injury_&_poisoning_+_external_cuase</Identifier></bo>" and participant_id = pid);
        set @SurgicalotherProcedureHistory =(select id from business_object_tbl where properties = "<bo><Identifier>sugrical_&_other_procedure_history</Identifier></bo>" and participant_id = pid);
        set @SurgicalotherProcedureHistoryName =(select bo_name from business_object_tbl where properties = "<bo><Identifier>sugrical_&_other_procedure_history</Identifier></bo>" and participant_id = pid);
        set @OtherTreatments = (select id from business_object_tbl where properties = "<bo><Identifier>other_treatments</Identifier></bo>" and participant_id = pid);
        set @OtherTreatmentsName = (select bo_name  from business_object_tbl where properties = "<bo><Identifier>other_treatments</Identifier></bo>" and participant_id = pid);
        set @AdverseEffects = (select id from business_object_tbl where properties = "<bo><Identifier>adverse_effects_(allergies_,_reactions_or_treatment)</Identifier></bo>" and participant_id = pid);
        set @AdverseEffectsName = (select bo_name from business_object_tbl where properties = "<bo><Identifier>adverse_effects_(allergies_,_reactions_or_treatment)</Identifier></bo>" and participant_id = pid);
        
        SET @objtypeid = (SELECT id FROM object_type_tbl WHERE object_type_name = 'Group' AND abbrev = 'g' LIMIT 1);
        -- SET @objtypeiddoc = (SELECT id FROM object_type_tbl WHERE object_type_name = 'MyList docs' AND abbrev = 'mld' LIMIT 1);
        -- ----------------------------  MyList  -------------------------------
        if @objtypeid is not null then
            if @PresentHealthConcerns is not null then
                
                SET @objid = UUID();
                IF @objtypeid IS NOT NULL THEN
                    
                    INSERT INTO business_object_tbl VALUES(@objid, @objtypeid, NULL, 'MyList', 'MyList',NULL,"<bo><Identifier>mylist_group</Identifier></bo>", NULL,NULL,NULL,NULL, 'Active',
                        0, b'1',NULL,NULL,CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),NULL,pid, uid,NULL,NULL,
                        uid,uid, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0);
                END IF;
                
                SET @objrel = UUID() ;
                INSERT INTO business_object_tbl 
                VALUES
                (
                    @objrel,
                    '3a98f0dd-d5e1-11e3-a67e-1c6f65f2b147',
                    NULL,
                    'PresentHealthConcerns:contains:g2g:Coll:MyList Group',
                    'PresentHealthConcerns:contains:g2g:Coll:MyList Group',
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    'Active',
                    0,
                    b'1',
                    NULL,
                    NULL,
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    NULL,
                    pid,
                    uid,
                    NULL,
                    NULL,
                    uid,
                    uid,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    0,
                    0
                ) ;
                INSERT INTO relationship_tbl 
                VALUES
                (
                    @objrel,
                    @PresentHealthConcerns,
                    @objid,
                    CURRENT_TIMESTAMP(),
                    NULL,
                    NULL,
                    NULL,
                    @reltype_id,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL
                ) ;  
            end if;
               
            if @Symptoms is not null then
                SET @objid = UUID();
                IF @objtypeid IS NOT NULL THEN
                    
                    INSERT INTO business_object_tbl VALUES(@objid, @objtypeid, NULL, 'MyList', 'MyList',NULL,"<bo><Identifier>mylist_group</Identifier></bo>", NULL,NULL,NULL,NULL, 'Active',
                        0, b'1',NULL,NULL,CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),NULL,pid, uid,NULL,NULL,
                        uid,uid, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0);
                END IF;
                
                SET @objrel = UUID() ;
                INSERT INTO business_object_tbl 
                VALUES
                (
                    @objrel,
                    '3a98f0dd-d5e1-11e3-a67e-1c6f65f2b147',
                    NULL,
                    'Symptoms:contains:g2g:Coll:MyList Group',
                    'Symptoms:contains:g2g:Coll:MyList Group',
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    'Active',
                    0,
                    b'1',
                    NULL,
                    NULL,
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    NULL,
                    pid,
                    uid,
                    NULL,
                    NULL,
                    uid,
                    uid,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    0,
                    0
                ) ;
                INSERT INTO relationship_tbl 
                VALUES
                (
                    @objrel,
                    @Symptoms,
                    @objid,
                    CURRENT_TIMESTAMP(),
                    NULL,
                    NULL,
                    NULL,
                    @reltype_id,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL
                ) ;  
            end if;
            
            if @PainObservations is not null then
                SET @objid = UUID();
                IF @objtypeid IS NOT NULL THEN
                    
                    INSERT INTO business_object_tbl VALUES(@objid, @objtypeid, NULL, 'MyList', 'MyList',NULL,"<bo><Identifier>mylist_group</Identifier></bo>", NULL,NULL,NULL,NULL, 'Active',
                        0, b'1',NULL,NULL,CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),NULL,pid, uid,NULL,NULL,
                        uid,uid, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0);
                END IF;
                
                SET @objrel = UUID() ;
                INSERT INTO business_object_tbl 
                VALUES
                (
                    @objrel,
                    '3a98f0dd-d5e1-11e3-a67e-1c6f65f2b147',
                    NULL,
                    'PainObservations:contains:g2g:Coll:MyList Group',
                    'PainObservations:contains:g2g:Coll:MyList Group',
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    'Active',
                    0,
                    b'1',
                    NULL,
                    NULL,
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    NULL,
                    pid,
                    uid,
                    NULL,
                    NULL,
                    uid,
                    uid,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    0,
                    0
                ) ;
                INSERT INTO relationship_tbl 
                VALUES
                (
                    @objrel,
                    @PainObservations,
                    @objid,
                    CURRENT_TIMESTAMP(),
                    NULL,
                    NULL,
                    NULL,
                    @reltype_id,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL
                ) ;  
            end if;
            
            if @PersonalMedicalHistory is not null then
                SET @objid = UUID();
                IF @objtypeid IS NOT NULL THEN
                    
                    INSERT INTO business_object_tbl VALUES(@objid, @objtypeid, NULL, 'MyList', 'MyList',NULL,"<bo><Identifier>mylist_group</Identifier></bo>", NULL,NULL,NULL,NULL, 'Active',
                        0, b'1',NULL,NULL,CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),NULL,pid, uid,NULL,NULL,
                        uid,uid, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0);
                END IF;
                
                SET @objrel = UUID() ;
                INSERT INTO business_object_tbl 
                VALUES
                (
                    @objrel,
                    '3a98f0dd-d5e1-11e3-a67e-1c6f65f2b147',
                    NULL,
                    'PersonalMedicalHistory:contains:g2g:Coll:MyList Group',
                    'PersonalMedicalHistory:contains:g2g:Coll:MyList Group',
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    'Active',
                    0,
                    b'1',
                    NULL,
                    NULL,
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    NULL,
                    pid,
                    uid,
                    NULL,
                    NULL,
                    uid,
                    uid,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    0,
                    0
                ) ;
                INSERT INTO relationship_tbl 
                VALUES
                (
                    @objrel,
                    @PersonalMedicalHistory,
                    @objid,
                    CURRENT_TIMESTAMP(),
                    NULL,
                    NULL,
                    NULL,
                    @reltype_id,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL
                ) ;  
            end if;
            
            if @MedicalDiagnosticHistory is not null then
                SET @objid = UUID();
                IF @objtypeid IS NOT NULL THEN
                    
                    INSERT INTO business_object_tbl VALUES(@objid, @objtypeid, NULL, 'MyList', 'MyList',NULL,"<bo><Identifier>mylist_group</Identifier></bo>", NULL,NULL,NULL,NULL, 'Active',
                        0, b'1',NULL,NULL,CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),NULL,pid, uid,NULL,NULL,
                        uid,uid, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0);
                END IF;
                
                SET @objrel = UUID() ;
                INSERT INTO business_object_tbl 
                VALUES
                (
                    @objrel,
                    '3a98f0dd-d5e1-11e3-a67e-1c6f65f2b147',
                    NULL,
                    'MedicalDiagnosticHistory:contains:g2g:Coll:MyList Group',
                    'MedicalDiagnosticHistory:contains:g2g:Coll:MyList Group',
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    'Active',
                    0,
                    b'1',
                    NULL,
                    NULL,
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    NULL,
                    pid,
                    uid,
                    NULL,
                    NULL,
                    uid,
                    uid,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    0,
                    0
                ) ;
                INSERT INTO relationship_tbl 
                VALUES
                (
                    @objrel,
                    @MedicalDiagnosticHistory,
                    @objid,
                    CURRENT_TIMESTAMP(),
                    NULL,
                    NULL,
                    NULL,
                    @reltype_id,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL
                ) ;  
            end if;
            
            if @InjuryPoisoningExternalCause is not null then
                SET @objid = UUID();
                IF @objtypeid IS NOT NULL THEN
                    
                    INSERT INTO business_object_tbl VALUES(@objid, @objtypeid, NULL, 'MyList', 'MyList',NULL,"<bo><Identifier>mylist_group</Identifier></bo>", NULL,NULL,NULL,NULL, 'Active',
                        0, b'1',NULL,NULL,CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),NULL,pid, uid,NULL,NULL,
                        uid,uid, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0);
                END IF;
                
                SET @objrel = UUID() ;
                INSERT INTO business_object_tbl 
                VALUES
                (
                    @objrel,
                    '3a98f0dd-d5e1-11e3-a67e-1c6f65f2b147',
                    NULL,
                    'InjuryPoisoningExternalCause:contains:g2g:Coll:MyList Group',
                    'InjuryPoisoningExternalCause:contains:g2g:Coll:MyList Group',
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    'Active',
                    0,
                    b'1',
                    NULL,
                    NULL,
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    NULL,
                    pid,
                    uid,
                    NULL,
                    NULL,
                    uid,
                    uid,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    0,
                    0
                ) ;
                INSERT INTO relationship_tbl 
                VALUES
                (
                    @objrel,
                    @InjuryPoisoningExternalCause,
                    @objid,
                    CURRENT_TIMESTAMP(),
                    NULL,
                    NULL,
                    NULL,
                    @reltype_id,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL
                ) ;  
            end if;
            
            if @SurgicalotherProcedureHistory is not null then
                SET @objid = UUID();
                IF @objtypeid IS NOT NULL THEN
                    
                    INSERT INTO business_object_tbl VALUES(@objid, @objtypeid, NULL, 'MyList', 'MyList',NULL,"<bo><Identifier>mylist_group</Identifier></bo>", NULL,NULL,NULL,NULL, 'Active',
                        0, b'1',NULL,NULL,CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),NULL,pid, uid,NULL,NULL,
                        uid,uid, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0);
                END IF;
                SET @objrel = UUID() ;
                INSERT INTO business_object_tbl 
                VALUES
                (
                    @objrel,
                    '3a98f0dd-d5e1-11e3-a67e-1c6f65f2b147',
                    NULL,
                    'SurgicalotherProcedureHistory:contains:g2g:Coll:MyList Group',
                    'SurgicalotherProcedureHistory:contains:g2g:Coll:MyList Group',
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    'Active',
                    0,
                    b'1',
                    NULL,
                    NULL,
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    NULL,
                    pid,
                    uid,
                    NULL,
                    NULL,
                    uid,
                    uid,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    0,
                    0
                ) ;
                INSERT INTO relationship_tbl 
                VALUES
                (
                    @objrel,
                    @SurgicalotherProcedureHistory,
                    @objid,
                    CURRENT_TIMESTAMP(),
                    NULL,
                    NULL,
                    NULL,
                    @reltype_id,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL
                ) ;  
            end if;
            
            if @OtherTreatments is not null then
                SET @objid = UUID();
                IF @objtypeid IS NOT NULL THEN
                    
                    INSERT INTO business_object_tbl VALUES(@objid, @objtypeid, NULL, 'MyList', 'MyList',NULL,"<bo><Identifier>mylist_group</Identifier></bo>", NULL,NULL,NULL,NULL, 'Active',
                        0, b'1',NULL,NULL,CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),NULL,pid, uid,NULL,NULL,
                        uid,uid, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0);
                END IF;
                SET @objrel = UUID() ;
                INSERT INTO business_object_tbl 
                VALUES
                (
                    @objrel,
                    '3a98f0dd-d5e1-11e3-a67e-1c6f65f2b147',
                    NULL,
                    'OtherTreatments:contains:g2g:Coll:MyList Group',
                    'OtherTreatments:contains:g2g:Coll:MyList Group',
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    'Active',
                    0,
                    b'1',
                    NULL,
                    NULL,
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    NULL,
                    pid,
                    uid,
                    NULL,
                    NULL,
                    uid,
                    uid,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    0,
                    0
                ) ;
                INSERT INTO relationship_tbl 
                VALUES
                (
                    @objrel,
                    @OtherTreatments,
                    @objid,
                    CURRENT_TIMESTAMP(),
                    NULL,
                    NULL,
                    NULL,
                    @reltype_id,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL
                ) ;  
            end if;
            
            if @AdverseEffects is not null then
                SET @objid = UUID();
                IF @objtypeid IS NOT NULL THEN
                    
                    INSERT INTO business_object_tbl VALUES(@objid, @objtypeid, NULL, 'MyList', 'MyList',NULL,"<bo><Identifier>mylist_group</Identifier></bo>", NULL,NULL,NULL,NULL, 'Active',
                        0, b'1',NULL,NULL,CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),NULL,pid, uid,NULL,NULL,
                        uid,uid, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0);
                END IF;
                SET @objrel = UUID() ;
                INSERT INTO business_object_tbl 
                VALUES
                (
                    @objrel,
                    '3a98f0dd-d5e1-11e3-a67e-1c6f65f2b147',
                    NULL,
                    'AdverseEffects:contains:g2g:Coll:MyList Group',
                    'AdverseEffects:contains:g2g:Coll:MyList Group',
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    'Active',
                    0,
                    b'1',
                    NULL,
                    NULL,
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    NULL,
                    pid,
                    uid,
                    NULL,
                    NULL,
                    uid,
                    uid,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    0,
                    0
                ) ;
                INSERT INTO relationship_tbl 
                VALUES
                (
                    @objrel,
                    @AdverseEffects,
                    @objid,
                    CURRENT_TIMESTAMP(),
                    NULL,
                    NULL,
                    NULL,
                    @reltype_id,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL
                ) ;  
            end if;
            
            SET @c = @c + 1 ;
        end if;
        -- ----------------------------  Docs  -------------------------------
        if @objtypeid is not null then
            if @PresentHealthConcerns is not null then
                
                SET @objid = UUID();
                IF @objtypeid IS NOT NULL THEN
                
                    INSERT INTO business_object_tbl VALUES(@objid, @objtypeid, NULL,concat(@PresentHealthConcernsName, ' Documents'), concat(@PresentHealthConcernsName, ' Documents'),NULL,"<bo><Identifier>mylist_documents</Identifier></bo>", NULL,NULL,NULL,NULL, 'Active',
                        0, b'1',NULL,NULL,CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),NULL,pid, uid,NULL,NULL,
                        uid,uid, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0);
          
                END IF;
                
                SET @objrel = UUID() ;
                INSERT INTO business_object_tbl 
                VALUES
                (
                    @objrel,
                    '3a98f0dd-d5e1-11e3-a67e-1c6f65f2b147',
                    NULL,
                    'PresentHealthConcerns:contains:g2g:Coll:Documents Group',
                    'PresentHealthConcerns:contains:g2g:Coll:Documents Group',
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    'Active',
                    0,
                    b'1',
                    NULL,
                    NULL,
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    NULL,
                    pid,
                    uid,
                    NULL,
                    NULL,
                    uid,
                    uid,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    0,
                    0
                ) ;
                INSERT INTO relationship_tbl 
                VALUES
                (
                    @objrel,
                    @PresentHealthConcerns,
                    @objid,
                    CURRENT_TIMESTAMP(),
                    NULL,
                    NULL,
                    NULL,
                    @reltype_id,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL
                ) ;  
            end if;
               
            if @Symptoms is not null then
                
                SET @objid = UUID();
                IF @objtypeid IS NOT NULL THEN
                
                    INSERT INTO business_object_tbl VALUES(@objid, @objtypeid, NULL,concat(@SymptomsName, ' Documents'), concat(@SymptomsName, ' Documents'),NULL,"<bo><Identifier>mylist_documents</Identifier></bo>", NULL,NULL,NULL,NULL, 'Active',
                        0, b'1',NULL,NULL,CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),NULL,pid, uid,NULL,NULL,
                        uid,uid, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0);
          
                END IF;
                SET @objrel = UUID() ;
                INSERT INTO business_object_tbl 
                VALUES
                (
                    @objrel,
                    '3a98f0dd-d5e1-11e3-a67e-1c6f65f2b147',
                    NULL,
                    'Symptoms:contains:g2g:Coll:Documents Group',
                    'Symptoms:contains:g2g:Coll:Documents Group',
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    'Active',
                    0,
                    b'1',
                    NULL,
                    NULL,
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    NULL,
                    pid,
                    uid,
                    NULL,
                    NULL,
                    uid,
                    uid,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    0,
                    0
                ) ;
                INSERT INTO relationship_tbl 
                VALUES
                (
                    @objrel,
                    @Symptoms,
                    @objid,
                    CURRENT_TIMESTAMP(),
                    NULL,
                    NULL,
                    NULL,
                    @reltype_id,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL
                ) ;  
            end if;
            
            if @PainObservations is not null then
                SET @objid = UUID();
                IF @objtypeid IS NOT NULL THEN
                
                    INSERT INTO business_object_tbl VALUES(@objid, @objtypeid, NULL,concat(@PainObservationsName, ' Documents'), concat(@PainObservationsName, ' Documents'),NULL,"<bo><Identifier>mylist_documents</Identifier></bo>", NULL,NULL,NULL,NULL, 'Active',
                        0, b'1',NULL,NULL,CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),NULL,pid, uid,NULL,NULL,
                        uid,uid, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0);
          
                END IF;
                SET @objrel = UUID() ;
                INSERT INTO business_object_tbl 
                VALUES
                (
                    @objrel,
                    '3a98f0dd-d5e1-11e3-a67e-1c6f65f2b147',
                    NULL,
                    'PainObservations:contains:g2g:Coll:Documents Group',
                    'PainObservations:contains:g2g:Coll:Documents Group',
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    'Active',
                    0,
                    b'1',
                    NULL,
                    NULL,
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    NULL,
                    pid,
                    uid,
                    NULL,
                    NULL,
                    uid,
                    uid,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    0,
                    0
                ) ;
                INSERT INTO relationship_tbl 
                VALUES
                (
                    @objrel,
                    @PainObservations,
                    @objid,
                    CURRENT_TIMESTAMP(),
                    NULL,
                    NULL,
                    NULL,
                    @reltype_id,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL
                ) ;  
            end if;
            
            if @PersonalMedicalHistory is not null then
                SET @objid = UUID();
                IF @objtypeid IS NOT NULL THEN
                
                    INSERT INTO business_object_tbl VALUES(@objid, @objtypeid, NULL,concat(@PersonalMedicalHistoryName, ' Documents'), concat(@PersonalMedicalHistoryName, ' Documents'),NULL,"<bo><Identifier>mylist_documents</Identifier></bo>", NULL,NULL,NULL,NULL, 'Active',
                        0, b'1',NULL,NULL,CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),NULL,pid, uid,NULL,NULL,
                        uid,uid, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0);
          
                END IF;
                SET @objrel = UUID() ;
                INSERT INTO business_object_tbl 
                VALUES
                (
                    @objrel,
                    '3a98f0dd-d5e1-11e3-a67e-1c6f65f2b147',
                    NULL,
                    'PersonalMedicalHistory:contains:g2g:Coll:Documents Group',
                    'PersonalMedicalHistory:contains:g2g:Coll:Documents Group',
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    'Active',
                    0,
                    b'1',
                    NULL,
                    NULL,
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    NULL,
                    pid,
                    uid,
                    NULL,
                    NULL,
                    uid,
                    uid,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    0,
                    0
                ) ;
                INSERT INTO relationship_tbl 
                VALUES
                (
                    @objrel,
                    @PersonalMedicalHistory,
                    @objid,
                    CURRENT_TIMESTAMP(),
                    NULL,
                    NULL,
                    NULL,
                    @reltype_id,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL
                ) ;  
            end if;
            
            if @MedicalDiagnosticHistory is not null then
                SET @objid = UUID();
                IF @objtypeid IS NOT NULL THEN
                
                    INSERT INTO business_object_tbl VALUES(@objid, @objtypeid, NULL,concat(@MedicalDiagnosticHistoryName, ' Documents'), concat(@MedicalDiagnosticHistoryName, ' Documents'),NULL,"<bo><Identifier>mylist_documents</Identifier></bo>", NULL,NULL,NULL,NULL, 'Active',
                        0, b'1',NULL,NULL,CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),NULL,pid, uid,NULL,NULL,
                        uid,uid, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0);
          
                END IF;
                SET @objrel = UUID() ;
                INSERT INTO business_object_tbl 
                VALUES
                (
                    @objrel,
                    '3a98f0dd-d5e1-11e3-a67e-1c6f65f2b147',
                    NULL,
                    'MedicalDiagnosticHistory:contains:g2g:Coll:Documents Group',
                    'MedicalDiagnosticHistory:contains:g2g:Coll:Documents Group',
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    'Active',
                    0,
                    b'1',
                    NULL,
                    NULL,
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    NULL,
                    pid,
                    uid,
                    NULL,
                    NULL,
                    uid,
                    uid,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    0,
                    0
                ) ;
                INSERT INTO relationship_tbl 
                VALUES
                (
                    @objrel,
                    @MedicalDiagnosticHistory,
                    @objid,
                    CURRENT_TIMESTAMP(),
                    NULL,
                    NULL,
                    NULL,
                    @reltype_id,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL
                ) ;  
            end if;
            
            if @InjuryPoisoningExternalCause is not null then
                SET @objid = UUID();
                IF @objtypeid IS NOT NULL THEN
                
                    INSERT INTO business_object_tbl VALUES(@objid, @objtypeid, NULL,concat(@InjuryPoisoningExternalCauseName, ' Documents'), concat(@InjuryPoisoningExternalCauseName, ' Documents'),NULL,"<bo><Identifier>mylist_documents</Identifier></bo>", NULL,NULL,NULL,NULL, 'Active',
                        0, b'1',NULL,NULL,CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),NULL,pid, uid,NULL,NULL,
                        uid,uid, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0);
          
                END IF;
                SET @objrel = UUID() ;
                INSERT INTO business_object_tbl 
                VALUES
                (
                    @objrel,
                    '3a98f0dd-d5e1-11e3-a67e-1c6f65f2b147',
                    NULL,
                    'InjuryPoisoningExternalCause:contains:g2g:Coll:Documents Group',
                    'InjuryPoisoningExternalCause:contains:g2g:Coll:Documents Group',
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    'Active',
                    0,
                    b'1',
                    NULL,
                    NULL,
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    NULL,
                    pid,
                    uid,
                    NULL,
                    NULL,
                    uid,
                    uid,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    0,
                    0
                ) ;
                INSERT INTO relationship_tbl 
                VALUES
                (
                    @objrel,
                    @InjuryPoisoningExternalCause,
                    @objid,
                    CURRENT_TIMESTAMP(),
                    NULL,
                    NULL,
                    NULL,
                    @reltype_id,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL
                ) ;  
            end if;
            
            if @SurgicalotherProcedureHistory is not null then
                SET @objid = UUID();
                IF @objtypeid IS NOT NULL THEN
                
                    INSERT INTO business_object_tbl VALUES(@objid, @objtypeid, NULL,concat(@SurgicalotherProcedureHistoryName, ' Documents'), concat(@SurgicalotherProcedureHistoryName, ' Documents'),NULL,"<bo><Identifier>mylist_documents</Identifier></bo>", NULL,NULL,NULL,NULL, 'Active',
                        0, b'1',NULL,NULL,CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),NULL,pid, uid,NULL,NULL,
                        uid,uid, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0);
          
                END IF;
                SET @objrel = UUID() ;
                INSERT INTO business_object_tbl 
                VALUES
                (
                    @objrel,
                    '3a98f0dd-d5e1-11e3-a67e-1c6f65f2b147',
                    NULL,
                    'SurgicalotherProcedureHistory:contains:g2g:Coll:Documents Group',
                    'SurgicalotherProcedureHistory:contains:g2g:Coll:Documents Group',
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    'Active',
                    0,
                    b'1',
                    NULL,
                    NULL,
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    NULL,
                    pid,
                    uid,
                    NULL,
                    NULL,
                    uid,
                    uid,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    0,
                    0
                ) ;
                INSERT INTO relationship_tbl 
                VALUES
                (
                    @objrel,
                    @SurgicalotherProcedureHistory,
                    @objid,
                    CURRENT_TIMESTAMP(),
                    NULL,
                    NULL,
                    NULL,
                    @reltype_id,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL
                ) ;  
            end if;
            
            if @OtherTreatments is not null then
                SET @objid = UUID();
                IF @objtypeid IS NOT NULL THEN
                
                    INSERT INTO business_object_tbl VALUES(@objid, @objtypeid, NULL,concat(@OtherTreatmentsName, ' Documents'), concat(@OtherTreatmentsName, ' Documents'),NULL,"<bo><Identifier>mylist_documents</Identifier></bo>", NULL,NULL,NULL,NULL, 'Active',
                        0, b'1',NULL,NULL,CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),NULL,pid, uid,NULL,NULL,
                        uid,uid, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0);
          
                END IF;
                SET @objrel = UUID() ;
                INSERT INTO business_object_tbl 
                VALUES
                (
                    @objrel,
                    '3a98f0dd-d5e1-11e3-a67e-1c6f65f2b147',
                    NULL,
                    'OtherTreatments:contains:g2g:Coll:Documents Group',
                    'OtherTreatments:contains:g2g:Coll:Documents Group',
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    'Active',
                    0,
                    b'1',
                    NULL,
                    NULL,
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    NULL,
                    pid,
                    uid,
                    NULL,
                    NULL,
                    uid,
                    uid,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    0,
                    0
                ) ;
                INSERT INTO relationship_tbl 
                VALUES
                (
                    @objrel,
                    @OtherTreatments,
                    @objid,
                    CURRENT_TIMESTAMP(),
                    NULL,
                    NULL,
                    NULL,
                    @reltype_id,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL
                ) ;  
            end if;
            
            if @AdverseEffects is not null then
                SET @objid = UUID();
                IF @objtypeid IS NOT NULL THEN
                
                    INSERT INTO business_object_tbl VALUES(@objid, @objtypeid, NULL,concat(@AdverseEffectsName, ' Documents'), concat(@AdverseEffectsName, ' Documents'),NULL,"<bo><Identifier>mylist_documents</Identifier></bo>", NULL,NULL,NULL,NULL, 'Active',
                        0, b'1',NULL,NULL,CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),NULL,pid, uid,NULL,NULL,
                        uid,uid, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0);
          
                END IF;
                SET @objrel = UUID() ;
                INSERT INTO business_object_tbl 
                VALUES
                (
                    @objrel,
                    '3a98f0dd-d5e1-11e3-a67e-1c6f65f2b147',
                    NULL,
                    'AdverseEffects:contains:g2g:Coll:Documents Group',
                    'AdverseEffects:contains:g2g:Coll:Documents Group',
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    'Active',
                    0,
                    b'1',
                    NULL,
                    NULL,
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    NULL,
                    pid,
                    uid,
                    NULL,
                    NULL,
                    uid,
                    uid,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    0,
                    0
                ) ;
                INSERT INTO relationship_tbl 
                VALUES
                (
                    @objrel,
                    @AdverseEffects,
                    @objid,
                    CURRENT_TIMESTAMP(),
                    NULL,
                    NULL,
                    NULL,
                    @reltype_id,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL
                ) ;  
            end if;
            
            SET @c = @c + 1 ;
        end if;
        
    END LOOP std_name_loop ;
    
    COMMIT;
    
    CLOSE std_name_sur ;
    SELECT @c AS counter ;
END;
