CREATE PROCEDURE workorder.add_directory(IN dirname VARCHAR(255), IN idx INT)
  begin
	declare myid varchar(50);
	select myuuid() into myid;
	update dir_name set dirname_index = (@cur_value := dirname_index)+1 where dirname_index >= idx;
	insert into dir_name values (myid,dirname,idx);
	select myid;
end;
