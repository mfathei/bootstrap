CREATE PROCEDURE workorder.account_bo_proc(IN xmlData TEXT)
  BEGIN
SET @page = EXTRACTVALUE(xmlData, '//page');
SET @LIMIT = EXTRACTVALUE(xmlData, '//limit');
SET @sortOrder =  EXTRACTVALUE(xmlData, '//sortOrder');
SET @INDEX =  EXTRACTVALUE(xmlData, '//index');
SET @Export =  EXTRACTVALUE(xmlData, '//Export');
SET @CustVend =   EXTRACTVALUE(xmlData, '//cust_vend');
SET @CustVend2 =   EXTRACTVALUE(xmlData, '//cust_vend2');  
SET @VendCust =   EXTRACTVALUE(xmlData, '//vend_cust');
SET @AccType =   EXTRACTVALUE(xmlData, '//AccType');
SET @selectquery ="SELECT *	";
SET @queryFrom = " FROM account_bo_view   ";
SET @queryWhere = ' where 1 <> 0  and hidden = 0';
SET @queryWhere = CONCAT(@queryWhere,' and cust_vend_id in ( ',"'", @CustVend,"'",',',"'", @CustVend2,"'",')');
IF @VendCust <> 'All'  
THEN
SET @queryWhere = CONCAT(@queryWhere,' and vend_cust_id = ',"'", @VendCust,"'");
END IF;
IF @AccType <> 'All'  
THEN
SET @queryWhere = CONCAT(@queryWhere,' and acct_type_id = ',"'", @AccType,"'");
END IF;
SET @myArrayOfValue = 'id,cust_vend_acct_num,cust_vend_acct_name,cust_acct_sys_name,cust_acct_sys_ver,cust_vend_acct_status,cust_vend_acct_security,cust_vend_acct_status_name,cust_vend_id,cust_vend_name,cust_vend_type_id,cust_vend_type_name,rel_acct_balance,vend_cust_acct_num,vend_cust_client_id,vend_cust_acct_name,vend_acct_sys_name,vend_acct_sys_ver,vend_cust_id,vend_cust_name,vend_cust_type_id,vend_cust_type_name,rel_acct_days_overdue,vend_cust_username,vend_cust_password,vend_access_code,acct_type_id,asset_id,asset_name,acct_type_name,properties,currency_type_id,name,monitory_total,monitory_unit,unit_total,total_unit,object_type_id,list_index,bo_name,fullname,description,bo_properties,next_bo_id,value_id,template_id,business_rule_id,status,hidden,mobile_sync,last_accessed_date,update_type,updated_date,created_date,effective_date,expiry_date,participant_id,owner_id,owner_group_id,last_accessor_id,updator_id,creator_id,external_id,external_key_id,external_source_id,file_id,image_id,vend_dept_id,cust_vend_acct_status,vend_dept_name';
SET @Postition = LOCATE(',', @myArrayOfValue);
WHILE ( @Postition > 0 ) DO
	SET @STR = SUBSTRING(@myArrayOfValue, 1, @Postition-1);
	SET @myArrayOfValue = SUBSTRING(@myArrayOfValue, @Postition + 1);
	SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//',@STR));
	IF (@Col != '' AND @Col !='NULL') THEN
		SET @queryWhere = CONCAT(@queryWhere,CONCAT(' AND ',@STR,' like('"'%", @Col ,"%'"') '));	
	END IF;
	
	SET @Postition = LOCATE(',', @myArrayOfValue);
END WHILE;
SET @querycount = CONCAT( 'SELECT count(*) into @cnt ', @queryFrom, @queryWhere );
PREPARE stmt1 FROM @querycount;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
SET @selectquery = CONCAT (@selectquery,', ', @cnt, ' as Count ');
SET @QUERY = CONCAT( @selectquery, @queryFrom, @queryWhere );
SET @QUERY = CONCAT(@QUERY, ' order by ', @INDEX,'  ', @sortOrder);
IF( @Export ="false") THEN
SET @page = (@page - 1) * @LIMIT;
SET @QUERY = CONCAT(@QUERY, ' LIMIT ', @LIMIT ,' OFFSET ',  @page);
 
END IF;
PREPARE stmt1 FROM @QUERY;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
END;
