CREATE FUNCTION workorder.message_receivers_fun(`$msg_id` VARCHAR(36))
  RETURNS VARCHAR(500)
  BEGIN
        
DECLARE $result VARCHAR(500);
SET $result = (SELECT GROUP_CONCAT(bo_name SEPARATOR '; ') as receivers FROM sender_receiver_tbl 
INNER JOIN user_tbl ON user_tbl.id=sender_receiver_tbl.receiver_id INNER JOIN business_object_tbl ON  user_tbl.person_id=business_object_tbl.id WHERE msg_id=$msg_id);
RETURN  $result;
 END;
