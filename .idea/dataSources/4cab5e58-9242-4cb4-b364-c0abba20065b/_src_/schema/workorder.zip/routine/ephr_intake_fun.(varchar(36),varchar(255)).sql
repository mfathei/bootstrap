CREATE FUNCTION workorder.ephr_intake_fun(`$person_id` VARCHAR(36), `$identifier` VARCHAR(255))
  RETURNS VARCHAR(36)
  BEGIN
DECLARE $id VARCHAR(36);
SET $identifier = CONCAT('%<Identifier>',$identifier,'</Identifier>%');
SET $id = (SELECT id FROM business_object_tbl WHERE participant_id = $person_id AND properties LIKE $identifier AND Hidden <> 1 LIMIT 1);
RETURN  $id;
END;
