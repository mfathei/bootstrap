CREATE FUNCTION workorder.loginAttemptExpired(`$user_tbl_id` VARCHAR(36), `$hours` INT)
  RETURNS INT
  BEGIN
    SET @diff = 0;
    -- SET $hours = $hours * 60;       
    SELECT TIMESTAMPDIFF(Hour , last_updated_date, CURRENT_TIMESTAMP()) INTO @diff
    FROM user_tbl WHERE id = $user_tbl_id;
    
    IF @diff >= $hours THEN
        RETURN 1;
    END IF;    
    RETURN 0;
END;
