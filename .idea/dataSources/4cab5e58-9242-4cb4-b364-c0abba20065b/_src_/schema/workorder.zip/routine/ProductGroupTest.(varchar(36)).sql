CREATE PROCEDURE workorder.ProductGroupTest(IN `$CompanyId` VARCHAR(36))
  BEGIN
DECLARE $GroupId VARCHAR(36);
DECLARE $TestId VARCHAR(36);
DECLARE $LastOne VARCHAR(36);
DECLARE $ObjectId VARCHAR(36);
DECLARE $SubjectId VARCHAR(36);
DECLARE $BoName VARCHAR(255);
DECLARE $GroupName VARCHAR(255);
DECLARE fetch_status INT DEFAULT 0;
DECLARE Company_Cursor CURSOR FOR 
	SELECT  subject_id FROM  relationship_tbl
	WHERE object_id  IN  (SELECT id FROM business_object_tbl WHERE id IN (SELECT 
            product_tbl.id
        FROM
            product_tbl
                INNER JOIN
            lookup_tbl ON product_tbl.category_type = lookup_tbl.id
WHERE lookup_name <> ('subscription')
    ));
 DECLARE CONTINUE HANDLER FOR NOT FOUND SET fetch_status = 100;
CREATE TEMPORARY TABLE IF NOT EXISTS _TempGroupName
(
id VARCHAR(36), group_name VARCHAR(255), bo_name VARCHAR(255),PRIMARY KEY (`id`)
);
  OPEN Company_Cursor;
 
 	WHILE fetch_status = 0
					DO
    FETCH Company_Cursor INTO $GroupId;
SET $ObjectId = $GroupId;
SET $TestId = $GroupId;
SET $SubjectId = (SELECT subject_id FROM relationship_tbl WHERE object_id = $ObjectId);
IF $TestId = $LastOne THEN
SET $TestId = '0';
ELSE
loop1: WHILE $SubjectId <> $CompanyId
DO
IF $SubjectId IN (SELECT id FROM business_object_tbl WHERE object_type_id = (SELECT id FROM object_type_tbl WHERE object_type_name = 'company'))
THEN
SET $TestId = '0';
LEAVE loop1;
ELSE 
SET $ObjectId = $SubjectId;
SET $SubjectId = (SELECT subject_id FROM relationship_tbl WHERE object_id = $ObjectId);
END IF;
END WHILE;
SET $GroupName = (SELECT fullname FROM business_object_tbl WHERE id = $TestId AND $TestId <> '0');
SET $BoName = (SELECT bo_name FROM business_object_tbl WHERE id = $TestId AND $TestId <> '0');
IF $TestId NOT IN (SELECT id FROM _TempGroupName) THEN
INSERT INTO _TempGroupName VALUES ($TestId, $GroupName, $BoName);
SET $LastOne = $TestId;
ELSE 
SET $LastOne = $GroupId;
END IF;
END IF;
FETCH Company_Cursor INTO $GroupId;
  END WHILE;
  
  CLOSE Company_Cursor;
SELECT * FROM _TempGroupName WHERE id <> '0';
DROP TABLE _TempGroupName;
END;
