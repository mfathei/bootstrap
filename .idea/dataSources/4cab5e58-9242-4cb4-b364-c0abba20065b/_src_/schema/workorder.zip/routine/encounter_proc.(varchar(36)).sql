CREATE PROCEDURE workorder.encounter_proc(IN `$person_id` VARCHAR(36))
  BEGIN
DECLARE $intake_id VARCHAR(36);
DECLARE $action_type_id VARCHAR(36);
SET $intake_id = (SELECT `ephr_intake_fun`($person_id, 'ephr_intake'));
SET $action_type_id = (SELECT id FROM action_type_tbl WHERE action_noun_type = 'encounter');
/*select act.id from action_tbl act inner join business_object_tbl bot on act.id = bot.id 
where bot.participant_id = $person_id and act.id <> $intake_id and act.action_type = $action_type_id;*/
SELECT * FROM action_bo_view INNER JOIN action_tbl act ON action_bo_view.bo_id = act.id INNER JOIN business_object_tbl bot ON act.id = bot.id 
WHERE bot.participant_id = $person_id AND act.id <> $intake_id AND act.action_type = $action_type_id;
END;
