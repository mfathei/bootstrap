CREATE PROCEDURE workorder.hide_business_family(IN `$codedlist_id` VARCHAR(50), IN `$person_id` VARCHAR(50))
  begin
set @statment=( select concat(group_concat(id),',',object_id)  from relationship_tbl where object_id=(
select id from business_object_tbl where id in(select id  from codedlist_tbl where codedlist_lookup_id =$codedlist_id) and participant_id=$person_id));
set  @Position = LOCATE(',',@statment);
if @Position > 0
then 
theloop:loop
SET @Position = LOCATE(',',@statment);
set @restofstr=substring(@statment,@Position+1);
set @accessrole=substring(@statment,1,@Position-1);
if exists(select * from business_object_tbl where id=@accessrole and bo_name like'dfd%')
then
update business_object_tbl set hidden=1 where id=@accessrole;
end if;
set @statment=@restofstr;
SET @Position = LOCATE(',',@statment);
if @Position=0 then leave theloop ; end if;
end loop;
if exists(select * from business_object_tbl where id=@statment and bo_name like'dfd%')
then
update business_object_tbl set hidden=1 where id=@statment;
end if;end if;
if @Position is null then set @x=1; end if;
end;
