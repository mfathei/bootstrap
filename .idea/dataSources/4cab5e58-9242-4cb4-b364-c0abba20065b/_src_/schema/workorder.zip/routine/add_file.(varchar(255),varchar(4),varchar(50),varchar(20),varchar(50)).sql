CREATE PROCEDURE workorder.add_file(IN filename  VARCHAR(255), IN extension VARCHAR(4), IN dirname_id VARCHAR(50),
                                    IN workorder VARCHAR(20), IN user_id VARCHAR(50))
  begin
declare cnt int;
declare parentid varchar(50);
declare fileid varchar(50);
set @debug = 0;
set parentid = '';
select count(`file_id`) into cnt from `file` 
			where `file_filename` = filename
            and `file_extension` = extension
            and `file_dirname_id` = dirname_id
            and `file_workorder` = workorder;
call debug_msg(@debug,(select cnt));
if (cnt > 0) then
	select `file_id` into parentid from `file`
					where `file_filename` = filename
					and `file_extension` = extension
					and `file_dirname_id` = dirname_id
					and `file_workorder` = workorder
                    and `file_parent_id` = '';
end if;
call debug_msg(@debug,(select parentid));
select myuuid() into fileid;
insert into `file` values (fileid,dirname_id,filename,extension,workorder,user_id,NOW(),parentid);
select fileid;
end;
