CREATE FUNCTION workorder.getDocumentsGroupID(`$subject_id` VARCHAR(100))
  RETURNS VARCHAR(100)
  BEGIN
 declare result varchar(100);
 
 set @isBasic = (select id from user_basic_groups where id = $subject_id);
 
 if @isBasic is not null then
    set result = (select object_id from relationship_tbl r join business_object_tbl b
on(r.object_id = b.id and r.subject_id = @isBasic and b.properties = '<bo><Identifier>mylist_documents</Identifier></bo>'));
 else
    set result = $subject_id;
 end if;
 
RETURN result;
END;
