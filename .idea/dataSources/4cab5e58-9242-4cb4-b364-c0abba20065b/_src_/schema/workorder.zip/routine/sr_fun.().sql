CREATE FUNCTION workorder.sr_fun()
  RETURNS VARCHAR(100)
  BEGIN
DECLARE $task_number, $p_task_number VARCHAR(100);
DECLARE $created_date DATETIME;
SET $task_number = CONCAT('SR', REPLACE(CURDATE(), '-',''));
SET $created_date = (SELECT MAX(created_date) FROM business_object_tbl WHERE properties LIKE '%<Identifier>service_request</Identifier>%');
IF $created_date IS NOT NULL
THEN 
	SET $p_task_number = (SELECT task_number FROM project_bo_view WHERE bo_properties LIKE '%<Identifier>service_request</Identifier>%' AND created_date = $created_date);
	SET $task_number = CONCAT($task_number, '-', HOUR(CURTIME()), MINUTE(CURTIME()), SECOND(CURTIME()), RIGHT($p_task_number, 1) + 1);
ELSE
	SET $task_number = CONCAT($task_number, '-', HOUR(CURTIME()), MINUTE(CURTIME()), SECOND(CURTIME()), 1);
END IF;
RETURN $task_number;
END;
