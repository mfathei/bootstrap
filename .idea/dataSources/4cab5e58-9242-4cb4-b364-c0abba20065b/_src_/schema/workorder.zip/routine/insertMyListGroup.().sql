CREATE PROCEDURE workorder.insertMyListGroup()
  BEGIN
    DECLARE finish INT DEFAULT 0;
    DECLARE uid VARCHAR(100); 
    DECLARE pid VARCHAR(100);
    DECLARE std_name_sur CURSOR FOR SELECT u.id,u.person_id 
        FROM user_tbl u join business_object_tbl ob on(u.person_id = ob.id);
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET finish=1;
     
    SET @c = 0;
    
    OPEN std_name_sur;
    std_name_loop: LOOP
        FETCH std_name_sur INTO uid,pid;
        IF finish=1 THEN
            LEAVE std_name_loop;
        END IF;
        -- select uid,pid;
        SET @objid = UUID();
        
        SET @objtypeid = (SELECT id FROM object_type_tbl WHERE object_type_name = 'MyList Group' AND abbrev = 'mlg' LIMIT 1);
        
        IF @objtypeid IS NOT NULL THEN
        
        INSERT INTO business_object_tbl VALUES(@objid, @objtypeid, NULL, 'MyList', 'MyList',NULL,"<bo><Identifier>mylist_group</Identifier></bo>", NULL,NULL,NULL,NULL, 'Active',
  0, b'1',NULL,NULL,CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),NULL,pid, uid,NULL,NULL,
  uid,uid, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0);
	SET @c = @c + 1;
        END IF;
    END LOOP std_name_loop;
    CLOSE std_name_sur;
SELECT @c AS counter;
END;
