CREATE PROCEDURE workorder.debug_msg(IN enabled INT, IN msg VARCHAR(255))
  BEGIN
  IF enabled THEN 
	BEGIN
		select concat("** ", msg) AS '** DEBUG:';
	END; 
  END IF;
END;
