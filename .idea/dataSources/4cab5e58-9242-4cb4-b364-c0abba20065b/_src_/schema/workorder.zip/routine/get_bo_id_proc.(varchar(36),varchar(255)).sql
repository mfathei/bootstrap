CREATE PROCEDURE workorder.get_bo_id_proc(IN `$person_id` VARCHAR(36), IN `$identifier` VARCHAR(255))
  BEGIN
SET $identifier = CONCAT('%<Identifier>',$identifier,'</Identifier>%');
SELECT id FROM business_object_tbl WHERE participant_id = $person_id AND properties LIKE $identifier;
END;
