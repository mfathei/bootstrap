CREATE PROCEDURE workorder.GroupProject_proc(IN `$UserId` VARCHAR(36))
  BEGIN
DECLARE $person_id VARCHAR(36);
SET $person_id = (SELECT person_id FROM user_tbl WHERE id = $UserId);
SELECT * FROM business_object_tbl WHERE participant_id = $person_id AND object_type_id = '3a998af2-d5e1-11e3-a67e-1c6f65f2b147' AND fullname = 'Life Plans';
/*
DECLARE $ePHRecordId VARCHAR(36);
set $ePHRecordId = (select id from enterprise_tbl where user_id = $UserId and enterprise_name = 'ePHRecord');
select * from business_object_tbl where id in (select object_id from relationship_tbl where subject_id = $ePHRecordId) and fullname = 'Life Plans'/*and object_id not in (select subject_id from relationship_tbl where (select id from business_object_tbl where object_type_id in (select id from object_type_tbl where object_type_name = 'project'))));*/
END;
