CREATE PROCEDURE workorder.rename_directory(IN dirnameid VARCHAR(50), IN dir VARCHAR(255), IN idx INT)
  begin
	
	declare oldidx int;
	
	select dirname_index into oldidx from dir_name where dirname_id = dirnameid;
	if oldidx = idx then
		update dir_name set dirname = dir where dirname_id = dirnameid;
	else
		update dir_name set dirname_index = oldidx where dirname_index = idx;
		update dir_name set dirname = dir,dirname_index = idx where dirname_id = dirnameid;
	end if;
	select 1;
end;
