CREATE PROCEDURE workorder.get_files(IN woname VARCHAR(20), IN dirnameid VARCHAR(50))
  begin
	
	
	drop temporary table if exists tbl_files;
	create temporary table tbl_files (
		file_id varchar(50),
		file_name varchar(255),
        file_workorder varchar(20),
        file_dirname_id varchar(50),
		file_extension varchar(5),
		file_uploadby varchar(255),
		file_lastupdated datetime,
		file_version int,
		file_parent_id varchar(50)
	);
	
	
		insert into tbl_files select f.file_id,
	case
				when f.file_filename not like 'LTD%' and f.file_filename not like 'INC%'
					then
						concat(substring(f.file_workorder,1,3),' ',substring(f.file_workorder from 4),' ',
						case
							when f.file_filename like '%pdf' or f.file_filename like '%dwfx'
								then cap_first(f.file_filename)
							else
								concat(cap_first(f.file_filename),'.',f.file_extension)
						end
						)
				else
					case
						when f.file_filename like '%pdf' or f.file_filename like '%dwfx'
							then cap_first(f.file_filename)
						else
							concat(cap_first(f.file_filename),'.',f.file_extension)
						end
			end
            ,f.file_workorder
            ,f.file_dirname_id
			,f.file_extension
			,concat(a.first_name,' ',a.last_name)
			,f.file_datelastmodified
			,(select count(file_id) from `workorder`.`file` where file_filename = f.file_filename and file_workorder = f.file_workorder and file_dirname_id = f.file_dirname_id)
			,f.file_parent_id
			from `file` f 
			inner join dir_name dn on f.file_dirname_id = dn.dirname_id
			inner join `auth`.`user` a on f.file_uploadby = a.user_id
			where f.file_workorder = woname 
            and f.file_dirname_id = dirnameid 
			order by f.file_filename desc;
	
    drop temporary table if exists tmp_files;
    create temporary table tmp_files(
    file_id varchar(50),
		file_name varchar(255),
        file_workorder varchar(20),
        file_dirname_id varchar(50),
		file_extension varchar(5),
		file_uploadby varchar(255),
		file_lastupdated datetime,
		file_version int,
		file_parent_id varchar(50)
    );
    insert into tmp_files select * from tbl_files;
    SELECT t1.*
	FROM tbl_files t1
	WHERE t1.file_lastupdated = (SELECT t2.file_lastupdated
                 FROM tmp_files t2
                 WHERE t2.file_name = t1.file_name and t2.file_dirname_id = t1.file_dirname_id and t2.file_workorder = t1.file_workorder          
                 ORDER BY t2.file_lastupdated DESC
                 LIMIT 1)
	order by t1.file_name;
	drop temporary table if exists tbl_files;
    drop temporary table if exists tmp_files;
end;
