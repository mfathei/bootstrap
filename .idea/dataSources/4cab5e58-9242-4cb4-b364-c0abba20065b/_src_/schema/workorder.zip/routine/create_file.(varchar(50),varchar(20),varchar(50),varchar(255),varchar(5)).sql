CREATE PROCEDURE workorder.create_file(IN userid VARCHAR(50), IN woname VARCHAR(20), IN filenameid VARCHAR(50),
                                       IN append VARCHAR(255), IN ext VARCHAR(5))
  begin
	declare cnt int;
	declare id varchar(50);
	declare file_name varchar(255);
	declare dirnameid varchar(50);
	select dn.dirname_id into dirnameid from dir_name dn inner join file_name fn on dn.dirname_id = fn.dirname_id where fn.filename_id = filenameid;
	select filename into file_name from file_name where filename_id = filenameid;
	select count(file_version) into cnt from `file` where file_workorder = woname and file_dirname_id = dirnameid 
	and file_filename = (concat(file_name,if (append <> '',concat(' ',append),''))); 
	select myuuid() into id;
	insert into `file` values (id,dirnameid,concat(file_name,if (append <> '',concat(' ',append),'')),concat('.',ext),woname,userid,NULl,cnt+1);
	select id;
end;
