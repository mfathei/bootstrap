CREATE FUNCTION workorder.retName()
  RETURNS VARCHAR(255)
  BEGIN
	return "test";
    END;
