CREATE PROCEDURE workorder.insertMedicalDocumentsGroup()
  BEGIN
    DECLARE finish INT DEFAULT 0;
    DECLARE uid VARCHAR(100); 
    DECLARE pid VARCHAR(100);
    DECLARE std_name_sur CURSOR FOR SELECT u.id,u.person_id 
        FROM user_tbl u join business_object_tbl ob on(u.person_id = ob.id) 
        ;-- where u.person_id = "2c9a1efa-863b-11e4-a123-5254000a52fa"; -- pauldavis -- '42b02324-1f13-11e5-9d99-5254000a52fa'; -- sarah
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET finish=1;
    
    DECLARE EXIT HANDLER FOR sqlexception
    BEGIN
        rollback;
    END;
    
    DECLARE EXIT HANDLER FOR sqlwarning
    BEGIN
        rollback;
    END;
    
    SET @reltype_id = (SELECT id FROM rel_type_tbl WHERE rel_type_name = 'Contains' AND rel_type_abbrev = 'g2g' LIMIT 1);
    SET @c = 0;
    
    OPEN std_name_sur;
    
    START transaction;
    
    std_name_loop: LOOP
        FETCH std_name_sur INTO uid,pid;
        IF finish=1 THEN
            LEAVE std_name_loop;
        END IF;
        -- select uid,pid;
        SET @objid = UUID();
        
        SET @objtypeid = (SELECT id FROM object_type_tbl WHERE object_type_name = 'Group' AND abbrev = 'g' LIMIT 1);
        
        IF @objtypeid IS NOT NULL THEN
        
            INSERT INTO business_object_tbl VALUES(@objid, @objtypeid, NULL, 'Medical Documents', 'Medical Documents',NULL,"<bo><Identifier>medical_documents</Identifier></bo>", NULL,NULL,NULL,NULL, 'Active',
                0, b'1',NULL,NULL,CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),NULL,pid, uid,NULL,NULL,
                uid,uid, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0);
                
            -- participant_identification
            set @gid = ephr_intake_fun(pid, 'participant_identification');
            
            if @gid is not null then
                SET @objrel = UUID() ;
                INSERT INTO business_object_tbl 
                VALUES
                (
                    @objrel,
                    '3a98f0dd-d5e1-11e3-a67e-1c6f65f2b147',
                    NULL,
                    'Medical Documents:contains:g2g:Coll:participant_identification',
                    'Medical Documents:contains:g2g:Coll:participant_identification',
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    'Active',
                    0,
                    b'1',
                    NULL,
                    NULL,
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    NULL,
                    pid,
                    uid,
                    NULL,
                    NULL,
                    uid,
                    uid,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    0,
                    0
                ) ;
                INSERT INTO relationship_tbl 
                VALUES
                (
                    @objrel,
                    @objid,
                    @gid,
                    CURRENT_TIMESTAMP(),
                    NULL,
                    NULL,
                    NULL,
                    @reltype_id,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL
                ) ; 
                SET @c = @c + 1;
            end if;
            
            -- demographics
            set @gid = ephr_intake_fun(pid, 'demographics');
            
            if @gid is not null then
                SET @objrel = UUID() ;
                INSERT INTO business_object_tbl 
                VALUES
                (
                    @objrel,
                    '3a98f0dd-d5e1-11e3-a67e-1c6f65f2b147',
                    NULL,
                    'Medical Documents:contains:g2g:Coll:demographics',
                    'Medical Documents:contains:g2g:Coll:demographics',
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    'Active',
                    0,
                    b'1',
                    NULL,
                    NULL,
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    NULL,
                    pid,
                    uid,
                    NULL,
                    NULL,
                    uid,
                    uid,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    0,
                    0
                ) ;
                INSERT INTO relationship_tbl 
                VALUES
                (
                    @objrel,
                    @objid,
                    @gid,
                    CURRENT_TIMESTAMP(),
                    NULL,
                    NULL,
                    NULL,
                    @reltype_id,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL
                ) ; 
                SET @c = @c + 1;
            end if;
            
            -- quick_links_emergency_contacts
            set @gid = ephr_intake_fun(pid, 'quick_links_emergency_contacts');
            
            if @gid is not null then
                SET @objrel = UUID() ;
                INSERT INTO business_object_tbl 
                VALUES
                (
                    @objrel,
                    '3a98f0dd-d5e1-11e3-a67e-1c6f65f2b147',
                    NULL,
                    'Medical Documents:contains:g2g:Coll:quick_links_emergency_contacts',
                    'Medical Documents:contains:g2g:Coll:quick_links_emergency_contacts',
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    'Active',
                    0,
                    b'1',
                    NULL,
                    NULL,
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    NULL,
                    pid,
                    uid,
                    NULL,
                    NULL,
                    uid,
                    uid,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    0,
                    0
                ) ;
                INSERT INTO relationship_tbl 
                VALUES
                (
                    @objrel,
                    @objid,
                    @gid,
                    CURRENT_TIMESTAMP(),
                    NULL,
                    NULL,
                    NULL,
                    @reltype_id,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL
                ) ; 
                SET @c = @c + 1;
            end if;
            
            -- medical_other_insurance_accounts
            set @gid = ephr_intake_fun(pid, 'medical_other_insurance_accounts');
            
            if @gid is not null then
                SET @objrel = UUID() ;
                INSERT INTO business_object_tbl 
                VALUES
                (
                    @objrel,
                    '3a98f0dd-d5e1-11e3-a67e-1c6f65f2b147',
                    NULL,
                    'Medical Documents:contains:g2g:Coll:medical_other_insurance_accounts',
                    'Medical Documents:contains:g2g:Coll:medical_other_insurance_accounts',
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    'Active',
                    0,
                    b'1',
                    NULL,
                    NULL,
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    NULL,
                    pid,
                    uid,
                    NULL,
                    NULL,
                    uid,
                    uid,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    0,
                    0
                ) ;
                INSERT INTO relationship_tbl 
                VALUES
                (
                    @objrel,
                    @objid,
                    @gid,
                    CURRENT_TIMESTAMP(),
                    NULL,
                    NULL,
                    NULL,
                    @reltype_id,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL
                ) ; 
                SET @c = @c + 1;
            end if;
            
            -- present_health_concerns
            set @gid = ephr_intake_fun(pid, 'present_health_concerns');
            
            if @gid is not null then
                SET @objrel = UUID() ;
                INSERT INTO business_object_tbl 
                VALUES
                (
                    @objrel,
                    '3a98f0dd-d5e1-11e3-a67e-1c6f65f2b147',
                    NULL,
                    'Medical Documents:contains:g2g:Coll:present_health_concerns',
                    'Medical Documents:contains:g2g:Coll:present_health_concerns',
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    'Active',
                    0,
                    b'1',
                    NULL,
                    NULL,
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    NULL,
                    pid,
                    uid,
                    NULL,
                    NULL,
                    uid,
                    uid,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    0,
                    0
                ) ;
                INSERT INTO relationship_tbl 
                VALUES
                (
                    @objrel,
                    @objid,
                    @gid,
                    CURRENT_TIMESTAMP(),
                    NULL,
                    NULL,
                    NULL,
                    @reltype_id,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL
                ) ; 
                SET @c = @c + 1;
            end if;
            
            -- symptoms
            set @gid = ephr_intake_fun(pid, 'symptoms');
            
            if @gid is not null then
                SET @objrel = UUID() ;
                INSERT INTO business_object_tbl 
                VALUES
                (
                    @objrel,
                    '3a98f0dd-d5e1-11e3-a67e-1c6f65f2b147',
                    NULL,
                    'Medical Documents:contains:g2g:Coll:symptoms',
                    'Medical Documents:contains:g2g:Coll:symptoms',
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    'Active',
                    0,
                    b'1',
                    NULL,
                    NULL,
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    NULL,
                    pid,
                    uid,
                    NULL,
                    NULL,
                    uid,
                    uid,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    0,
                    0
                ) ;
                INSERT INTO relationship_tbl 
                VALUES
                (
                    @objrel,
                    @objid,
                    @gid,
                    CURRENT_TIMESTAMP(),
                    NULL,
                    NULL,
                    NULL,
                    @reltype_id,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL
                ) ; 
                SET @c = @c + 1;
            end if;
            
            -- pain_observations
            set @gid = ephr_intake_fun(pid, 'pain_observations');
            
            if @gid is not null then
                SET @objrel = UUID() ;
                INSERT INTO business_object_tbl 
                VALUES
                (
                    @objrel,
                    '3a98f0dd-d5e1-11e3-a67e-1c6f65f2b147',
                    NULL,
                    'Medical Documents:contains:g2g:Coll:pain_observations',
                    'Medical Documents:contains:g2g:Coll:pain_observations',
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    'Active',
                    0,
                    b'1',
                    NULL,
                    NULL,
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    NULL,
                    pid,
                    uid,
                    NULL,
                    NULL,
                    uid,
                    uid,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    0,
                    0
                ) ;
                INSERT INTO relationship_tbl 
                VALUES
                (
                    @objrel,
                    @objid,
                    @gid,
                    CURRENT_TIMESTAMP(),
                    NULL,
                    NULL,
                    NULL,
                    @reltype_id,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL
                ) ; 
                SET @c = @c + 1;
            end if;
            
            -- personal_observations
            set @gid = ephr_intake_fun(pid, 'personal_observations');
            
            if @gid is not null then
                SET @objrel = UUID() ;
                INSERT INTO business_object_tbl 
                VALUES
                (
                    @objrel,
                    '3a98f0dd-d5e1-11e3-a67e-1c6f65f2b147',
                    NULL,
                    'Medical Documents:contains:g2g:Coll:personal_observations',
                    'Medical Documents:contains:g2g:Coll:personal_observations',
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    'Active',
                    0,
                    b'1',
                    NULL,
                    NULL,
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    NULL,
                    pid,
                    uid,
                    NULL,
                    NULL,
                    uid,
                    uid,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    0,
                    0
                ) ;
                INSERT INTO relationship_tbl 
                VALUES
                (
                    @objrel,
                    @objid,
                    @gid,
                    CURRENT_TIMESTAMP(),
                    NULL,
                    NULL,
                    NULL,
                    @reltype_id,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL
                ) ; 
                SET @c = @c + 1;
            end if;
            
            
            -- medical_products
            set @gid = ephr_intake_fun(pid, 'medical_products');
            
            if @gid is not null then
                SET @objrel = UUID() ;
                INSERT INTO business_object_tbl 
                VALUES
                (
                    @objrel,
                    '3a98f0dd-d5e1-11e3-a67e-1c6f65f2b147',
                    NULL,
                    'Medical Documents:contains:g2g:Coll:medical_products',
                    'Medical Documents:contains:g2g:Coll:medical_products',
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    'Active',
                    0,
                    b'1',
                    NULL,
                    NULL,
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    NULL,
                    pid,
                    uid,
                    NULL,
                    NULL,
                    uid,
                    uid,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    0,
                    0
                ) ;
                INSERT INTO relationship_tbl 
                VALUES
                (
                    @objrel,
                    @objid,
                    @gid,
                    CURRENT_TIMESTAMP(),
                    NULL,
                    NULL,
                    NULL,
                    @reltype_id,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL
                ) ; 
                SET @c = @c + 1;
            end if;
            
            -- immunization_&_travel_history
            set @gid = ephr_intake_fun(pid, 'immunization_&_travel_history');
            
            if @gid is not null then
                SET @objrel = UUID() ;
                INSERT INTO business_object_tbl 
                VALUES
                (
                    @objrel,
                    '3a98f0dd-d5e1-11e3-a67e-1c6f65f2b147',
                    NULL,
                    'Medical Documents:contains:g2g:Coll:immunization_&_travel_history',
                    'Medical Documents:contains:g2g:Coll:immunization_&_travel_history',
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    'Active',
                    0,
                    b'1',
                    NULL,
                    NULL,
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    NULL,
                    pid,
                    uid,
                    NULL,
                    NULL,
                    uid,
                    uid,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    0,
                    0
                ) ;
                INSERT INTO relationship_tbl 
                VALUES
                (
                    @objrel,
                    @objid,
                    @gid,
                    CURRENT_TIMESTAMP(),
                    NULL,
                    NULL,
                    NULL,
                    @reltype_id,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL
                ) ; 
                SET @c = @c + 1;
            end if;
            
            -- personal_medical_history
            set @gid = ephr_intake_fun(pid, 'personal_medical_history');
            
            if @gid is not null then
                SET @objrel = UUID() ;
                INSERT INTO business_object_tbl 
                VALUES
                (
                    @objrel,
                    '3a98f0dd-d5e1-11e3-a67e-1c6f65f2b147',
                    NULL,
                    'Medical Documents:contains:g2g:Coll:personal_medical_history',
                    'Medical Documents:contains:g2g:Coll:personal_medical_history',
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    'Active',
                    0,
                    b'1',
                    NULL,
                    NULL,
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    NULL,
                    pid,
                    uid,
                    NULL,
                    NULL,
                    uid,
                    uid,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    0,
                    0
                ) ;
                INSERT INTO relationship_tbl 
                VALUES
                (
                    @objrel,
                    @objid,
                    @gid,
                    CURRENT_TIMESTAMP(),
                    NULL,
                    NULL,
                    NULL,
                    @reltype_id,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL
                ) ; 
                SET @c = @c + 1;
            end if;
            
            -- family_medical_history
            set @gid = ephr_intake_fun(pid, 'family_medical_history');
            
            if @gid is not null then
                SET @objrel = UUID() ;
                INSERT INTO business_object_tbl 
                VALUES
                (
                    @objrel,
                    '3a98f0dd-d5e1-11e3-a67e-1c6f65f2b147',
                    NULL,
                    'Medical Documents:contains:g2g:Coll:family_medical_history',
                    'Medical Documents:contains:g2g:Coll:family_medical_history',
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    'Active',
                    0,
                    b'1',
                    NULL,
                    NULL,
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    NULL,
                    pid,
                    uid,
                    NULL,
                    NULL,
                    uid,
                    uid,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    0,
                    0
                ) ;
                INSERT INTO relationship_tbl 
                VALUES
                (
                    @objrel,
                    @objid,
                    @gid,
                    CURRENT_TIMESTAMP(),
                    NULL,
                    NULL,
                    NULL,
                    @reltype_id,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL
                ) ; 
                SET @c = @c + 1;
            end if;
            
            -- medical_(diagnostic)_history
            set @gid = ephr_intake_fun(pid, 'medical_(diagnostic)_history');
            
            if @gid is not null then
                SET @objrel = UUID() ;
                INSERT INTO business_object_tbl 
                VALUES
                (
                    @objrel,
                    '3a98f0dd-d5e1-11e3-a67e-1c6f65f2b147',
                    NULL,
                    'Medical Documents:contains:g2g:Coll:medical_(diagnostic)_history',
                    'Medical Documents:contains:g2g:Coll:medical_(diagnostic)_history',
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    'Active',
                    0,
                    b'1',
                    NULL,
                    NULL,
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    NULL,
                    pid,
                    uid,
                    NULL,
                    NULL,
                    uid,
                    uid,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    0,
                    0
                ) ;
                INSERT INTO relationship_tbl 
                VALUES
                (
                    @objrel,
                    @objid,
                    @gid,
                    CURRENT_TIMESTAMP(),
                    NULL,
                    NULL,
                    NULL,
                    @reltype_id,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL
                ) ; 
                SET @c = @c + 1;
            end if;
            
            -- injury_&_poisoning_+_external_cuase
            set @gid = ephr_intake_fun(pid, 'injury_&_poisoning_+_external_cuase');
            
            if @gid is not null then
                SET @objrel = UUID() ;
                INSERT INTO business_object_tbl 
                VALUES
                (
                    @objrel,
                    '3a98f0dd-d5e1-11e3-a67e-1c6f65f2b147',
                    NULL,
                    'Medical Documents:contains:g2g:Coll:injury_&_poisoning_+_external_cuase',
                    'Medical Documents:contains:g2g:Coll:injury_&_poisoning_+_external_cuase',
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    'Active',
                    0,
                    b'1',
                    NULL,
                    NULL,
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    NULL,
                    pid,
                    uid,
                    NULL,
                    NULL,
                    uid,
                    uid,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    0,
                    0
                ) ;
                INSERT INTO relationship_tbl 
                VALUES
                (
                    @objrel,
                    @objid,
                    @gid,
                    CURRENT_TIMESTAMP(),
                    NULL,
                    NULL,
                    NULL,
                    @reltype_id,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL
                ) ; 
                SET @c = @c + 1;
            end if;
            
            -- sugrical_&_other_procedure_history
            set @gid = ephr_intake_fun(pid, 'sugrical_&_other_procedure_history');
            
            if @gid is not null then
                SET @objrel = UUID() ;
                INSERT INTO business_object_tbl 
                VALUES
                (
                    @objrel,
                    '3a98f0dd-d5e1-11e3-a67e-1c6f65f2b147',
                    NULL,
                    'Medical Documents:contains:g2g:Coll:sugrical_&_other_procedure_history',
                    'Medical Documents:contains:g2g:Coll:sugrical_&_other_procedure_history',
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    'Active',
                    0,
                    b'1',
                    NULL,
                    NULL,
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    NULL,
                    pid,
                    uid,
                    NULL,
                    NULL,
                    uid,
                    uid,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    0,
                    0
                ) ;
                INSERT INTO relationship_tbl 
                VALUES
                (
                    @objrel,
                    @objid,
                    @gid,
                    CURRENT_TIMESTAMP(),
                    NULL,
                    NULL,
                    NULL,
                    @reltype_id,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL
                ) ; 
                SET @c = @c + 1;
            end if;
            
            -- adverse_effects_(allergies_,_reactions_or_treatment)
            set @gid = ephr_intake_fun(pid, 'adverse_effects_(allergies_,_reactions_or_treatment)');
            
            if @gid is not null then
                SET @objrel = UUID() ;
                INSERT INTO business_object_tbl 
                VALUES
                (
                    @objrel,
                    '3a98f0dd-d5e1-11e3-a67e-1c6f65f2b147',
                    NULL,
                    'Medical Documents:contains:g2g:Coll:adverse_effects_(allergies_,_reactions_or_treatment)',
                    'Medical Documents:contains:g2g:Coll:adverse_effects_(allergies_,_reactions_or_treatment)',
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    'Active',
                    0,
                    b'1',
                    NULL,
                    NULL,
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    NULL,
                    pid,
                    uid,
                    NULL,
                    NULL,
                    uid,
                    uid,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    0,
                    0
                ) ;
                INSERT INTO relationship_tbl 
                VALUES
                (
                    @objrel,
                    @objid,
                    @gid,
                    CURRENT_TIMESTAMP(),
                    NULL,
                    NULL,
                    NULL,
                    @reltype_id,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL
                ) ; 
                SET @c = @c + 1;
            end if;
            
            -- lab_results
            set @gid = ephr_intake_fun(pid, 'lab_results');
            
            if @gid is not null then
                SET @objrel = UUID() ;
                INSERT INTO business_object_tbl 
                VALUES
                (
                    @objrel,
                    '3a98f0dd-d5e1-11e3-a67e-1c6f65f2b147',
                    NULL,
                    'Medical Documents:contains:g2g:Coll:lab_results',
                    'Medical Documents:contains:g2g:Coll:lab_results',
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    'Active',
                    0,
                    b'1',
                    NULL,
                    NULL,
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    NULL,
                    pid,
                    uid,
                    NULL,
                    NULL,
                    uid,
                    uid,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    0,
                    0
                ) ;
                INSERT INTO relationship_tbl 
                VALUES
                (
                    @objrel,
                    @objid,
                    @gid,
                    CURRENT_TIMESTAMP(),
                    NULL,
                    NULL,
                    NULL,
                    @reltype_id,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL
                ) ; 
                SET @c = @c + 1;
            end if;
            
            -- medical_imaging_files
            set @gid = ephr_intake_fun(pid, 'medical_imaging_files');
            
            if @gid is not null then
                SET @objrel = UUID() ;
                INSERT INTO business_object_tbl 
                VALUES
                (
                    @objrel,
                    '3a98f0dd-d5e1-11e3-a67e-1c6f65f2b147',
                    NULL,
                    'Medical Documents:contains:g2g:Coll:medical_imaging_files',
                    'Medical Documents:contains:g2g:Coll:medical_imaging_files',
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    'Active',
                    0,
                    b'1',
                    NULL,
                    NULL,
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    NULL,
                    pid,
                    uid,
                    NULL,
                    NULL,
                    uid,
                    uid,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    0,
                    0
                ) ;
                INSERT INTO relationship_tbl 
                VALUES
                (
                    @objrel,
                    @objid,
                    @gid,
                    CURRENT_TIMESTAMP(),
                    NULL,
                    NULL,
                    NULL,
                    @reltype_id,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL
                ) ; 
                SET @c = @c + 1;
            end if;
            
            -- patient_medical_summaries
            set @gid = ephr_intake_fun(pid, 'patient_medical_summaries');
            
            if @gid is not null then
                SET @objrel = UUID() ;
                INSERT INTO business_object_tbl 
                VALUES
                (
                    @objrel,
                    '3a98f0dd-d5e1-11e3-a67e-1c6f65f2b147',
                    NULL,
                    'Medical Documents:contains:g2g:Coll:patient_medical_summaries',
                    'Medical Documents:contains:g2g:Coll:patient_medical_summaries',
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    'Active',
                    0,
                    b'1',
                    NULL,
                    NULL,
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    NULL,
                    pid,
                    uid,
                    NULL,
                    NULL,
                    uid,
                    uid,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    0,
                    0
                ) ;
                INSERT INTO relationship_tbl 
                VALUES
                (
                    @objrel,
                    @objid,
                    @gid,
                    CURRENT_TIMESTAMP(),
                    NULL,
                    NULL,
                    NULL,
                    @reltype_id,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL
                ) ; 
                SET @c = @c + 1;
            end if;
            
            -- health_directives
            set @gid = ephr_intake_fun(pid, 'health_directives');
            
            if @gid is not null then
                SET @objrel = UUID() ;
                INSERT INTO business_object_tbl 
                VALUES
                (
                    @objrel,
                    '3a98f0dd-d5e1-11e3-a67e-1c6f65f2b147',
                    NULL,
                    'Medical Documents:contains:g2g:Coll:health_directives',
                    'Medical Documents:contains:g2g:Coll:health_directives',
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    'Active',
                    0,
                    b'1',
                    NULL,
                    NULL,
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    CURRENT_TIMESTAMP(),
                    NULL,
                    pid,
                    uid,
                    NULL,
                    NULL,
                    uid,
                    uid,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    0,
                    0
                ) ;
                INSERT INTO relationship_tbl 
                VALUES
                (
                    @objrel,
                    @objid,
                    @gid,
                    CURRENT_TIMESTAMP(),
                    NULL,
                    NULL,
                    NULL,
                    @reltype_id,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    NULL
                ) ; 
                SET @c = @c + 1;
            end if;
        END IF;
    END LOOP std_name_loop;
    
    commit;
    
    CLOSE std_name_sur;
SELECT @c AS counter;
END;
