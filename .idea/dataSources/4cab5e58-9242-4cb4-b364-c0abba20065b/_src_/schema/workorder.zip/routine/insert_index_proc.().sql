CREATE PROCEDURE workorder.insert_index_proc()
  BEGIN
DECLARE $p_autoincrement, $c_autoincrement, $p_min, $p_max, $c_min, $c_max INT;
DECLARE $parent_id VARCHAR(36);
SET $p_autoincrement = 1;
SET $p_min = (SELECT MIN(OrderAI) FROM codedlist_lookup_tbl WHERE parent_id IS NULL);
SET $p_max = (SELECT MAX(OrderAI) FROM codedlist_lookup_tbl WHERE parent_id IS NULL);
Parent: WHILE $p_min <= $p_max
DO
	UPDATE codedlist_lookup_tbl 
	SET list_index = $p_autoincrement WHERE OrderAI = $p_min;
	SET $parent_id = (SELECT id FROM codedlist_lookup_tbl WHERE OrderAI = $p_min);
	SET $c_autoincrement = 1;
	SET $c_min = (SELECT MIN(OrderAI) FROM codedlist_lookup_tbl WHERE parent_id = $parent_id);
	SET $c_max = (SELECT MAX(OrderAI) FROM codedlist_lookup_tbl WHERE parent_id = $parent_id);
	Children: WHILE $c_min <= $c_max 
	DO
		UPDATE codedlist_lookup_tbl 
		SET list_index = $p_autoincrement WHERE OrderAI = $c_min;		
		
		IF $c_min = $c_max 
		THEN
			LEAVE Children;
		ELSE
			SET $c_min = (SELECT MIN(OrderAI) FROM codedlist_lookup_tbl WHERE parent_id = $parent_id AND OrderAI > $c_min);
			SET $c_autoincrement = $c_autoincrement + 1;
		END IF;		
	END WHILE;
	IF $p_min = $p_max 
	THEN
		LEAVE Parent;
	ELSE
		SET $p_min = (SELECT MIN(OrderAI) FROM codedlist_lookup_tbl WHERE parent_id IS NULL AND OrderAI > $p_min);
		SET $p_autoincrement = $p_autoincrement + 1;
	END IF;
END WHILE;
END;
