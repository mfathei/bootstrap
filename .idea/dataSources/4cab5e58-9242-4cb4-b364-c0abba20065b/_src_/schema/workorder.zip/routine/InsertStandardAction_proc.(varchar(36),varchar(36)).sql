CREATE PROCEDURE workorder.InsertStandardAction_proc(IN `$action_list_id` VARCHAR(36), IN `$project_id` VARCHAR(36))
  BEGIN
DECLARE $action_list_group_id, $participant_id, $admin_id, $user_id, $aid, $id, $rel_id, $bo_type_id, $rel_type_id, $personal_observation, $action_type_id VARCHAR(36);
DECLARE $bo_name, $group_bo_name, $action_bo_name, $project_name VARCHAR(100);
DECLARE fetch_status INT DEFAULT 0;
DECLARE Action_Cur CURSOR  FOR
SELECT id 
FROM action_tbl 
WHERE action_list_id = $action_list_id;
DECLARE CONTINUE HANDLER FOR NOT FOUND SET fetch_status = 100;
SET $participant_id = (SELECT participant_id FROM business_object_tbl WHERE id = $project_id);
SET $personal_observation = ephr_intake_fun($participant_id,'personal_observations');
SET $action_list_group_id = (SELECT ephr_intake_fun($participant_id, 'action_list'));
SET $project_name = (SELECT bo_name FROM business_object_tbl WHERE id = $project_id);
SET $admin_id = (SELECT participant_id FROM business_object_tbl WHERE id = (SELECT id FROM action_tbl WHERE action_list_id = $action_list_id LIMIT 1));
SET $user_id = (SELECT owner_id FROM business_object_tbl WHERE id = $project_id);
SET $bo_type_id = (SELECT id FROM object_type_tbl WHERE abbrev = 'rel');
SET $rel_type_id = '9347dcf0-0a94-11e4-ada0-52540002e01a';
OPEN Action_Cur;
FETCH  Action_Cur INTO $aid ;
WHILE fetch_status = 0 
DO 
	SET $id = (SELECT generate_uuid());
	SET $rel_id = (SELECT generate_uuid());
INSERT INTO business_object_tbl
(
    `business_object_tbl`.`id`,
    `business_object_tbl`.`object_type_id`,
    `business_object_tbl`.`list_index`,
    `business_object_tbl`.`bo_name`,
    `business_object_tbl`.`fullname`,
    `business_object_tbl`.`description`,
    `business_object_tbl`.`properties`,
    `business_object_tbl`.`next_bo_id`,
    `business_object_tbl`.`value_id`,
    `business_object_tbl`.`template_id`,
    `business_object_tbl`.`business_rule_id`,
    `business_object_tbl`.`status`,
    `business_object_tbl`.`hidden`,
    `business_object_tbl`.`mobile_sync`,
    `business_object_tbl`.`last_accessed_date`,
    `business_object_tbl`.`update_type`,
    `business_object_tbl`.`updated_date`,
    `business_object_tbl`.`created_date`,
    `business_object_tbl`.`effective_date`,
    `business_object_tbl`.`expiry_date`,
    `business_object_tbl`.`participant_id`,
    `business_object_tbl`.`owner_id`,
    `business_object_tbl`.`owner_group_id`,
    `business_object_tbl`.`last_accessor_id`,
    `business_object_tbl`.`updator_id`,
    `business_object_tbl`.`creator_id`,
    `business_object_tbl`.`external_id`,
	`business_object_tbl`.`external_key_id`,
    `business_object_tbl`.`external_source_id`,
	`business_object_tbl`.`file_id`,
    `business_object_tbl`.`image_id`
)
SELECT
    $id,
    `business_object_tbl`.`object_type_id`,
    `business_object_tbl`.`list_index`,
    `business_object_tbl`.`bo_name`,
    `business_object_tbl`.`fullname`,
    `business_object_tbl`.`description`,
    `business_object_tbl`.`properties`,
    `business_object_tbl`.`next_bo_id`,
    `business_object_tbl`.`value_id`,
    `business_object_tbl`.`template_id`,
    `business_object_tbl`.`business_rule_id`,
    `business_object_tbl`.`status`,
    `business_object_tbl`.`hidden`,
    `business_object_tbl`.`mobile_sync`,
    `business_object_tbl`.`last_accessed_date`,
    `business_object_tbl`.`update_type`,
    CURRENT_TIMESTAMP(),
    CURRENT_TIMESTAMP(),
    CURRENT_TIMESTAMP(),
    `business_object_tbl`.`expiry_date`,
    $participant_id,
    $user_id,
    `business_object_tbl`.`owner_group_id`,
    `business_object_tbl`.`last_accessor_id`,
    $user_id,
    $user_id,
    `business_object_tbl`.`external_id`,
	`business_object_tbl`.`external_key_id`,
    `business_object_tbl`.`external_source_id`,
	`business_object_tbl`.`file_id`,
    `business_object_tbl`.`image_id`
FROM business_object_tbl
WHERE id = $aid;
INSERT INTO action_tbl
(
	`action_tbl`.`id`,
    `action_tbl`.`action_type`,
    `action_tbl`.`participant_subject_id`,
    `action_tbl`.`participant_object_id`,
    `action_tbl`.`participant_authority_id`,
    `action_tbl`.`participant_device_id`,
    `action_tbl`.`utc_time_start`,
    `action_tbl`.`utc_time_end`,
    `action_tbl`.`utc_time_offest`,
    `action_tbl`.`local_time_start`,
    `action_tbl`.`local_time_end`,
    `action_tbl`.`status_type_id`,
    `action_tbl`.`action_list_id`,
    `action_tbl`.`Alarm`,
    `action_tbl`.`AlarmSign`,
    `action_tbl`.`AlarmValue`,
    `action_tbl`.`AlarmTerm`,
    `action_tbl`.`start_time`,
    `action_tbl`.`duration`,
    `action_tbl`.`recurring_frequency`,
    `action_tbl`.`recurring_units_id`,
    `action_tbl`.`recurring_term`,
    `action_tbl`.`recurring_term_units_id`,
    `action_tbl`.`Dependancy_id`,
    `action_tbl`.`project_id`
)
SELECT 
	$id,
    `action_tbl`.`action_type`,
    $participant_id,
    $participant_id,
    $participant_id,
    `action_tbl`.`participant_device_id`,
    CURRENT_TIMESTAMP(),
    NULL,
    `action_tbl`.`utc_time_offest`,
    `action_tbl`.`local_time_start`,
    `action_tbl`.`local_time_end`,
    `action_tbl`.`status_type_id`,
     NULL,
    `action_tbl`.`Alarm`,
    `action_tbl`.`AlarmSign`,
    `action_tbl`.`AlarmValue`,
    `action_tbl`.`AlarmTerm`,
    `action_tbl`.`start_time`,
    `action_tbl`.`duration`,
    `action_tbl`.`recurring_frequency`,
    `action_tbl`.`recurring_units_id`,
    `action_tbl`.`recurring_term`,
    `action_tbl`.`recurring_term_units_id`,
    `action_tbl`.`Dependancy_id`,
     $project_id
FROM action_tbl
WHERE id = $aid;
SET $action_type_id = (SELECT action_type FROM action_tbl WHERE id = $id);
IF $action_type_id = '0a19cafc-fc4c-11e3-92fe-52540002e01a'
THEN
	SET $group_bo_name = (SELECT bo_name FROM business_object_tbl WHERE id = $personal_observation);
	SET $action_bo_name = (SELECT bo_name FROM business_object_tbl WHERE id = $id);
	SET $bo_name = CONCAT($group_bo_name, ':contains:g2act:coll:', $action_bo_name);
	SET $rel_id = (SELECT generate_uuid());
INSERT INTO business_object_tbl
(
    `business_object_tbl`.`id`,
    `business_object_tbl`.`object_type_id`,
    `business_object_tbl`.`bo_name`,
    `business_object_tbl`.`fullname`,
    `business_object_tbl`.`status`,
    `business_object_tbl`.`hidden`,
    `business_object_tbl`.`updated_date`,
    `business_object_tbl`.`created_date`,
    `business_object_tbl`.`participant_id`,
    `business_object_tbl`.`owner_id`,
    `business_object_tbl`.`updator_id`,
    `business_object_tbl`.`creator_id`
)
VALUES
(
	$rel_id,
	$bo_type_id,
	$bo_name,
	$bo_name,
	'Active',
	0,
	CURRENT_TIMESTAMP(),
	CURRENT_TIMESTAMP(),
	$participant_id,
    $user_id,
    $user_id,
    $user_id
	
);
INSERT INTO relationship_tbl
(
	`relationship_tbl`.`id`,
    `relationship_tbl`.`subject_id`,
    `relationship_tbl`.`object_id`,
    `relationship_tbl`.`rel_type_id`
)
VALUES
(
	$rel_id,
	$personal_observation,
	$id,
	$rel_type_id
);
INSERT INTO `WhoKnozMe`.`observation_tbl`
(
	`id`,
	`observation_properties_id`,
	`action_id`,
	`status_type_id`,
	`value_id`,
	`workflow_id`,
	`list_id`,
	`observation_template_id`,
	`test_type_id`
)
SELECT
	Generate_uuid(),
	`observation_properties_id`,
	$id,
	`status_type_id`,
	`value_id`,
	`workflow_id`,
	`list_id`,
	`observation_template_id`,
	`test_type_id`
FROM observation_tbl 
WHERE action_id = $aid LIMIT 1;
END IF;
SET $group_bo_name = (SELECT bo_name FROM business_object_tbl WHERE id = $action_list_group_id);
  SET $action_bo_name = (SELECT bo_name FROM business_object_tbl WHERE id = $id);
  SET $bo_name = CONCAT($group_bo_name, ':contains:g2act:coll:', $action_bo_name);
  SET $rel_id = (SELECT generate_uuid());
INSERT INTO business_object_tbl
(
    `business_object_tbl`.`id`,
    `business_object_tbl`.`object_type_id`,
    `business_object_tbl`.`bo_name`,
    `business_object_tbl`.`fullname`,
    `business_object_tbl`.`status`,
    `business_object_tbl`.`hidden`,
    `business_object_tbl`.`updated_date`,
    `business_object_tbl`.`created_date`,
    `business_object_tbl`.`participant_id`,
    `business_object_tbl`.`owner_id`,
    `business_object_tbl`.`updator_id`,
    `business_object_tbl`.`creator_id`
)
VALUES
(
	$rel_id,
	$bo_type_id,
	$bo_name,
	$bo_name,
	'Active',
	0,
	CURRENT_TIMESTAMP(),
	CURRENT_TIMESTAMP(),
	$participant_id,
    $user_id,
    $user_id,
    $user_id
	
);
INSERT INTO relationship_tbl
(
	`relationship_tbl`.`id`,
    `relationship_tbl`.`subject_id`,
    `relationship_tbl`.`object_id`,
    `relationship_tbl`.`rel_type_id`
)
VALUES
(
	$rel_id,
	$action_list_group_id,
	$id,
	$rel_type_id
);
IF (SELECT properties FROM business_object_tbl WHERE id = $project_id) = '<bo><Identifier>daily_routine</Identifier></bo>'
THEN
SET $bo_name = CONCAT($project_name, ':contains:pj2act:coll:', $action_bo_name);
SET $rel_id = (SELECT generate_uuid());
SET $rel_type_id = '118833b2-c25a-11e4-8c9e-52540002e01a';
INSERT INTO business_object_tbl
(
    `business_object_tbl`.`id`,
    `business_object_tbl`.`object_type_id`,
    `business_object_tbl`.`bo_name`,
    `business_object_tbl`.`fullname`,
    `business_object_tbl`.`status`,
    `business_object_tbl`.`hidden`,
    `business_object_tbl`.`updated_date`,
    `business_object_tbl`.`created_date`,
    `business_object_tbl`.`participant_id`,
    `business_object_tbl`.`owner_id`,
    `business_object_tbl`.`updator_id`,
    `business_object_tbl`.`creator_id`
)
VALUES
(
	$rel_id,
	$bo_type_id,
	$bo_name,
	$bo_name,
	'Active',
	0,
	CURRENT_TIMESTAMP(),
	CURRENT_TIMESTAMP(),
	$participant_id,
    $user_id,
    $user_id,
    $user_id
	
);
INSERT INTO relationship_tbl
(
	`relationship_tbl`.`id`,
    `relationship_tbl`.`subject_id`,
    `relationship_tbl`.`object_id`,
    `relationship_tbl`.`rel_type_id`
)
VALUES
(
	$rel_id,
	$project_id,
	$id,
	$rel_type_id
);
END IF;
FETCH Action_Cur INTO $aid;
END WHILE;
CLOSE Action_Cur;
END;
