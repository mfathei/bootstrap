CREATE PROCEDURE workorder.insertOthersTrustsMeChildGroups()
  BEGIN
    DECLARE finish INT DEFAULT 0 ;
    DECLARE uid VARCHAR (100) ;
    DECLARE pid VARCHAR (100) ;
    DECLARE std_name_sur CURSOR FOR 
    SELECT 
        id,
        person_id 
    FROM
        user_tbl 
    ;-- where id = '07943496-7e19-11e5-850e-5254000a52fa' ;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET finish = 1 ;
    SET @c = 0 ;
    OPEN std_name_sur ;
    std_name_loop :
    LOOP
        FETCH std_name_sur INTO uid,
        pid ;
        IF finish = 1 
        THEN LEAVE std_name_loop ;
        END IF ;
        -- select uid,pid;
        -- ----------------------------------- Family (Genetic) -------------------------------------------------------------------------------------
        SET @objid = UUID() ;
        SET @subid = 
        (SELECT 
            id 
        FROM
            business_object_tbl 
        WHERE bo_name = 'Others Know or Trust Me' 
            AND owner_id = uid 
            AND participant_id = pid 
        LIMIT 1) ;
        IF @subid IS NOT NULL 
        THEN 
        INSERT INTO business_object_tbl 
        VALUES
            (
                @objid,
                '3a998af2-d5e1-11e3-a67e-1c6f65f2b147',
                NULL,
                'Family (Genetic)',
                'Family (Genetic)',
                NULL,
                "<bo><Identifier>others_family(Genetic)</Identifier></bo>",
                NULL,
                NULL,
                NULL,
                NULL,
                'Active',
                0,
                b'1',
                NULL,
                NULL,
                CURRENT_TIMESTAMP(),
                CURRENT_TIMESTAMP(),
                CURRENT_TIMESTAMP(),
                NULL,
                pid,
                uid,
                NULL,
                NULL,
                uid,
                uid,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                0,
                0
            ) ;
        SET @objrel = UUID() ;
        INSERT INTO business_object_tbl 
        VALUES
            (
                @objrel,
                '3a98f0dd-d5e1-11e3-a67e-1c6f65f2b147',
                NULL,
                'Others-vSDBox:contains:g2g:Coll:Family (Genetic)',
                'Others-vSDBox:contains:g2g:Coll:Family (Genetic)',
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                'Active',
                0,
                b'1',
                NULL,
                NULL,
                CURRENT_TIMESTAMP(),
                CURRENT_TIMESTAMP(),
                CURRENT_TIMESTAMP(),
                NULL,
                pid,
                uid,
                NULL,
                NULL,
                uid,
                uid,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                0,
                0
            ) ;
        INSERT INTO relationship_tbl 
        VALUES
            (
                @objrel,
                @subid,
                @objid,
                CURRENT_TIMESTAMP(),
                NULL,
                NULL,
                NULL,
                '7b93f40d-d6d7-11e3-b867-1c6f65f2b147',
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL
            ) ;
        -- ----------------------------------- Family (Living Arrangement) -------------------------------------------------------------------------------------
        SET @objid = UUID() ;
        INSERT INTO business_object_tbl 
        VALUES
            (
                @objid,
                '3a998af2-d5e1-11e3-a67e-1c6f65f2b147',
                NULL,
                'Family (Living Arrangement)',
                'Family (Living Arrangement)',
                NULL,
                "<bo><Identifier>others_family(living_arrangement)</Identifier></bo>",
                NULL,
                NULL,
                NULL,
                NULL,
                'Active',
                0,
                b'1',
                NULL,
                NULL,
                CURRENT_TIMESTAMP(),
                CURRENT_TIMESTAMP(),
                CURRENT_TIMESTAMP(),
                NULL,
                pid,
                uid,
                NULL,
                NULL,
                uid,
                uid,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                0,
                0
            ) ;
        SET @objrel = UUID() ;
        INSERT INTO business_object_tbl 
        VALUES
            (
                @objrel,
                '3a98f0dd-d5e1-11e3-a67e-1c6f65f2b147',
                NULL,
                'Others-vSDBox:contains:g2g:Coll:Family (Living Arrangement)',
                'Others-vSDBox:contains:g2g:Coll:Family (Living Arrangement)',
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                'Active',
                0,
                b'1',
                NULL,
                NULL,
                CURRENT_TIMESTAMP(),
                CURRENT_TIMESTAMP(),
                CURRENT_TIMESTAMP(),
                NULL,
                pid,
                uid,
                NULL,
                NULL,
                uid,
                uid,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                0,
                0
            ) ;
        INSERT INTO relationship_tbl 
        VALUES
            (
                @objrel,
                @subid,
                @objid,
                CURRENT_TIMESTAMP(),
                NULL,
                NULL,
                NULL,
                '7b93f40d-d6d7-11e3-b867-1c6f65f2b147',
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL
            ) ;
            
        SET @objid = UUID() ;
        INSERT INTO business_object_tbl 
        VALUES
            (
                @objid,
                '3a998af2-d5e1-11e3-a67e-1c6f65f2b147',
                NULL,
                'emerg contacts',
                'Emergency Contacts',
                NULL,
                "<bo><Identifier>others_contacts_emergency_contacts</Identifier></bo>",
                NULL,
                NULL,
                NULL,
                NULL,
                'Active',
                0,
                b'1',
                NULL,
                NULL,
                CURRENT_TIMESTAMP(),
                CURRENT_TIMESTAMP(),
                CURRENT_TIMESTAMP(),
                NULL,
                pid,
                uid,
                NULL,
                NULL,
                uid,
                uid,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                0,
                0
            ) ;
        SET @objrel = UUID() ;
        INSERT INTO business_object_tbl 
        VALUES
            (
                @objrel,
                '3a98f0dd-d5e1-11e3-a67e-1c6f65f2b147',
                NULL,
                'Others-vSDBox:contains:g2g:Coll:emerg contacts',
                'Others-vSDBox:contains:g2g:Coll:emerg contacts',
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                'Active',
                0,
                b'1',
                NULL,
                NULL,
                CURRENT_TIMESTAMP(),
                CURRENT_TIMESTAMP(),
                CURRENT_TIMESTAMP(),
                NULL,
                pid,
                uid,
                NULL,
                NULL,
                uid,
                uid,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                0,
                0
            ) ;
        INSERT INTO relationship_tbl 
        VALUES
            (
                @objrel,
                @subid,
                @objid,
                CURRENT_TIMESTAMP(),
                NULL,
                NULL,
                NULL,
                '7b93f40d-d6d7-11e3-b867-1c6f65f2b147',
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL
            ) ;            
            
            -- ----------------------------------- Care Team -------------------------------------------------------------------------------------
        SET @objid = UUID() ;
        INSERT INTO business_object_tbl 
        VALUES
            (
                @objid,
                '3a998af2-d5e1-11e3-a67e-1c6f65f2b147',
                NULL,
                'Care Team',
                'Care Team',
                NULL,
                "<bo><Identifier>others_care_team</Identifier></bo>",
                NULL,
                NULL,
                NULL,
                NULL,
                'Active',
                0,
                b'1',
                NULL,
                NULL,
                CURRENT_TIMESTAMP(),
                CURRENT_TIMESTAMP(),
                CURRENT_TIMESTAMP(),
                NULL,
                pid,
                uid,
                NULL,
                NULL,
                uid,
                uid,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                0,
                0
            ) ;
        SET @objrel = UUID() ;
        INSERT INTO business_object_tbl 
        VALUES
            (
                @objrel,
                '3a98f0dd-d5e1-11e3-a67e-1c6f65f2b147',
                NULL,
                'Others-vSDBox:contains:g2g:Coll:Care Team',
                'Others-vSDBox:contains:g2g:Coll:Care Team',
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                'Active',
                0,
                b'1',
                NULL,
                NULL,
                CURRENT_TIMESTAMP(),
                CURRENT_TIMESTAMP(),
                CURRENT_TIMESTAMP(),
                NULL,
                pid,
                uid,
                NULL,
                NULL,
                uid,
                uid,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                0,
                0
            ) ;
        INSERT INTO relationship_tbl 
        VALUES
            (
                @objrel,
                @subid,
                @objid,
                CURRENT_TIMESTAMP(),
                NULL,
                NULL,
                NULL,
                '7b93f40d-d6d7-11e3-b867-1c6f65f2b147',
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL
            ) ;            
            
            -- ----------------------------------- Caregiver (Provider) Clients -------------------------------------------------------------------------------------
        SET @objid = UUID() ;
        INSERT INTO business_object_tbl 
        VALUES
            (
                @objid,
                '3a998af2-d5e1-11e3-a67e-1c6f65f2b147',
                NULL,
                'Caregiver (Provider) Clients',
                'Caregiver (Provider) Clients',
                NULL,
                "<bo><Identifier>others_caregiver_clients</Identifier></bo>",
                NULL,
                NULL,
                NULL,
                NULL,
                'Active',
                0,
                b'1',
                NULL,
                NULL,
                CURRENT_TIMESTAMP(),
                CURRENT_TIMESTAMP(),
                CURRENT_TIMESTAMP(),
                NULL,
                pid,
                uid,
                NULL,
                NULL,
                uid,
                uid,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                0,
                0
            ) ;
        SET @objrel = UUID() ;
        INSERT INTO business_object_tbl 
        VALUES
            (
                @objrel,
                '3a98f0dd-d5e1-11e3-a67e-1c6f65f2b147',
                NULL,
                'Others-vSDBox:contains:g2g:Coll:Caregiver (Provider) Clients',
                'Others-vSDBox:contains:g2g:Coll:Caregiver (Provider) Clients',
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                'Active',
                0,
                b'1',
                NULL,
                NULL,
                CURRENT_TIMESTAMP(),
                CURRENT_TIMESTAMP(),
                CURRENT_TIMESTAMP(),
                NULL,
                pid,
                uid,
                NULL,
                NULL,
                uid,
                uid,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                0,
                0
            ) ;
        INSERT INTO relationship_tbl 
        VALUES
            (
                @objrel,
                @subid,
                @objid,
                CURRENT_TIMESTAMP(),
                NULL,
                NULL,
                NULL,
                '7b93f40d-d6d7-11e3-b867-1c6f65f2b147',
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL
            ) ;               
            
            -- ----------------------------------- Contacts (Address Book) -------------------------------------------------------------------------------------
        SET @objid = UUID() ;
        INSERT INTO business_object_tbl 
        VALUES
            (
                @objid,
                '3a998af2-d5e1-11e3-a67e-1c6f65f2b147',
                NULL,
                'Contacts (Address Book)',
                'Contacts (Address Book)',
                NULL,
                "<bo><Identifier>others_address_book</Identifier></bo>",
                NULL,
                NULL,
                NULL,
                NULL,
                'Active',
                0,
                b'1',
                NULL,
                NULL,
                CURRENT_TIMESTAMP(),
                CURRENT_TIMESTAMP(),
                CURRENT_TIMESTAMP(),
                NULL,
                pid,
                uid,
                NULL,
                NULL,
                uid,
                uid,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                0,
                0
            ) ;
        SET @objrel = UUID() ;
        INSERT INTO business_object_tbl 
        VALUES
            (
                @objrel,
                '3a98f0dd-d5e1-11e3-a67e-1c6f65f2b147',
                NULL,
                'Others-vSDBox:contains:g2g:Coll:Contacts (Address Book)',
                'Others-vSDBox:contains:g2g:Coll:Contacts (Address Book)',
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                'Active',
                0,
                b'1',
                NULL,
                NULL,
                CURRENT_TIMESTAMP(),
                CURRENT_TIMESTAMP(),
                CURRENT_TIMESTAMP(),
                NULL,
                pid,
                uid,
                NULL,
                NULL,
                uid,
                uid,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                0,
                0
            ) ;
        INSERT INTO relationship_tbl 
        VALUES
            (
                @objrel,
                @subid,
                @objid,
                CURRENT_TIMESTAMP(),
                NULL,
                NULL,
                NULL,
                '7b93f40d-d6d7-11e3-b867-1c6f65f2b147',
                NULL,
                NULL,
                NULL,
                NULL,
                NULL,
                NULL
            ) ;               
            
        SET @c = @c + 1 ;
        END IF ;
    END LOOP std_name_loop ;
    CLOSE std_name_sur ;
    SELECT 
        @c AS counter ;
END;
