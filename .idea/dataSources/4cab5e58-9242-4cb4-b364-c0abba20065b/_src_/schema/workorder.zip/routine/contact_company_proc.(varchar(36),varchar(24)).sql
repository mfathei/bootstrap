CREATE PROCEDURE workorder.contact_company_proc(IN `$person_id` VARCHAR(36), IN `$group_type` VARCHAR(24))
  BEGIN
DECLARE $contact_group_id, $relationship_id VARCHAR(36);
IF $group_type = 'emergency'
THEN
SET $contact_group_id = ephr_intake_fun( $person_id,'contacts_emergency_contacts');
SET $relationship_id = (SELECT id FROM relationship_tbl WHERE id IN (SELECT object_id FROM relationship_tbl WHERE id IN (SELECT object_id FROM relationship_tbl WHERE subject_id = $contact_group_id)) AND rel_type_id = '5d7df21c-48a1-11e4-9cf6-52540002e01a');
SELECT bo_name, rel_type_name, phone_number1, phone_type_name1, area_code1, phone_number2, phone_type_name2, area_code2, phone_number3, phone_type_name3,  area_code3, phone_code, sms, object_role, contact_id FROM company_contact_view WHERE company_id = (SELECT subject_id FROM relationship_tbl WHERE id = $relationship_id);
ELSEIF $group_type = 'care'
THEN
SET $contact_group_id = ephr_intake_fun( $person_id,'care_team');
SET $relationship_id = (SELECT id FROM relationship_tbl WHERE id IN (SELECT object_id FROM relationship_tbl WHERE id IN (SELECT object_id FROM relationship_tbl WHERE subject_id = $contact_group_id)) AND rel_type_id = '5d7df21c-48a1-11e4-9cf6-52540002e01a');
SELECT bo_name, rel_type_name, phone_number1, phone_type_name1, area_code1, phone_number2, phone_type_name2, area_code2, phone_number3, phone_type_name3,  area_code3, phone_code, sms, object_role, contact_id  FROM company_contact_view WHERE company_id = (SELECT subject_id FROM relationship_tbl WHERE id = $relationship_id);
END IF;
END;
