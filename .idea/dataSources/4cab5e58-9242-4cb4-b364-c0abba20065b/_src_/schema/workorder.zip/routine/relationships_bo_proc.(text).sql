CREATE PROCEDURE workorder.relationships_bo_proc(IN xmlData TEXT)
  BEGIN
SET @page = EXTRACTVALUE(xmlData, '//page');
SET @LIMIT = EXTRACTVALUE(xmlData, '//limit');
SET @sortOrder =  EXTRACTVALUE(xmlData, '//sortOrder');
SET @INDEX =  EXTRACTVALUE(xmlData, '//index');
SET @Export =  EXTRACTVALUE(xmlData, '//Export');
SET @person =  EXTRACTVALUE(xmlData, '//person');
SET @selectquery ="SELECT *	";
SET @queryFrom = " from  relationships_bo_view";
SET @queryWhere = CONCAT(' where subject_id = "', @person ,'"');
SET @myArrayOfValue = ' bo_id, bo_name, fullname, description, subject_role, object_role, rel_type_id, rel_id, rel_type_name, start_date, end_date, groups,';
SET @Postition = LOCATE(',', @myArrayOfValue);
WHILE ( @Postition > 0 ) DO
	SET  @STR = TRIM(@STR);
	SET @STR = SUBSTRING(@myArrayOfValue, 1, @Postition-1);
	SET @myArrayOfValue = SUBSTRING(@myArrayOfValue, @Postition + 1);
	SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//',@STR));
	IF (@Col != '' AND @Col !='NULL') THEN
		SET  @STR = TRIM(@STR);
		SET @queryWhere = CONCAT(@queryWhere,CONCAT(' AND ',@STR,' like('"'%", @Col ,"%'"') '));	
	END IF;
	
	SET @Postition = LOCATE(',', @myArrayOfValue);
END WHILE;
SET @querycount = CONCAT( 'SELECT count(*) into @cnt ', @queryFrom, @queryWhere );
PREPARE stmt1 FROM @querycount;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
SET @selectquery = CONCAT (@selectquery,', ', @cnt, ' as Count ');
SET @QUERY = CONCAT( @selectquery, @queryFrom, @queryWhere );
SET @QUERY = CONCAT(@QUERY, ' order by ', @INDEX,'  ', @sortOrder);
IF( @Export ="false") THEN
SET @page = (@page - 1) * @LIMIT;
SET @QUERY = CONCAT(@QUERY, ' LIMIT ', @LIMIT ,' OFFSET ',  @page);
 
END IF;
PREPARE stmt1 FROM @QUERY;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
END;
