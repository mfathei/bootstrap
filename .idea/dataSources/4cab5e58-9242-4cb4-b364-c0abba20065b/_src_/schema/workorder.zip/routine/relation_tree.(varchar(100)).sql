CREATE PROCEDURE workorder.relation_tree(IN `$subject_id` VARCHAR(100))
  begin
set @qry=concat('select * from relationships_bo_view where subject_id=getDocumentsGroupID('',$subject_id,'') and (object_type_name='File' or object_type_name='Group') ');
PREPARE stmt1 FROM @qry;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1;
end;
