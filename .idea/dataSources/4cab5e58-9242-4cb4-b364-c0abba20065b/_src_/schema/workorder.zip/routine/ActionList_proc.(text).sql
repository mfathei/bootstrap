CREATE PROCEDURE workorder.ActionList_proc(IN xmlData TEXT)
  BEGIN
SET @page = EXTRACTVALUE(xmlData, '//page');
SET @LIMIT = EXTRACTVALUE(xmlData, '//limit');
SET @sortOrder =  EXTRACTVALUE(xmlData, '//sortOrder');
SET @INDEX =  EXTRACTVALUE(xmlData, '//index');
SET @Export =  EXTRACTVALUE(xmlData, '//Export');
SET @project_id =   EXTRACTVALUE(xmlData, '//project_id');
SET @action_list_id =   EXTRACTVALUE(xmlData, '//action_list_id');
SET @participant_id =   EXTRACTVALUE(xmlData, '//participant_id');
SET @look_id =   EXTRACTVALUE(xmlData, '//look_id');
SET @selectquery ="SELECT *	";
SET @queryFrom = " FROM action_bo_view ";
SET @queryWhere = ' where 1 = 1  ';
SET @queryWhere = CONCAT(@queryWhere,' and hidden = 0 ');
IF @project_id != "" THEN
	SET @queryWhere = CONCAT(@queryWhere,' and project_id = ',"'", @project_id,"'");
END IF;
IF @action_list_id != "" THEN
	SET @queryWhere = CONCAT(@queryWhere,' and action_list_id = ',"'", @action_list_id,"'");
END IF;
IF @participant_id != "" THEN
	SET @queryWhere = CONCAT(@queryWhere,' and participant_id = ',"'", @participant_id,"'");
END IF;
IF @look_id != "" THEN
	SET @queryWhere = CONCAT(@queryWhere,' and properties is null and look_id = ',"'", @look_id,"'");
END IF;
SET @myArrayOfValue ='bo_id,object_type_id,list_index,bo_name,fullname,description,properties,next_bo_id,value_id,template_id,business_rule_id,status,hidden,mobile_sync,last_accessed_date,update_type,updated_date,created_date,effective_date,expiry_date,participant_id,owner_id,owner_group_id,last_accessor_id,updator_id,creator_id,external_id,external_key_id,external_source_id,file_id,image_id,ActionId,action_type,action_noun_type,participant_subject_id,participant_subject_name,participant_object_id,participant_object_name,participant_authority_id,participant_authority_name,participant_device_id,utc_time_start,utc_time_end,utc_time_offest,local_time_start,local_time_end,status_type_id,status_type_name,action_list_id,start_time,duration,action_list_name,Alarm,AlarmSign,AlarmValue,AlarmTerm,recurring_frequency,recurring_units_id,recurring_term,recurring_term_units_id,Dependancy_id,project_id,test_type_id,test_type_name,look_id,project_name,';
SET @Postition = LOCATE(',', @myArrayOfValue);
WHILE ( @Postition > 0 ) DO
	SET @STR = SUBSTRING(@myArrayOfValue, 1, @Postition-1);
	SET @myArrayOfValue = SUBSTRING(@myArrayOfValue, @Postition + 1);
	SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//',@STR));
	IF (@Col != '' AND @Col !='NULL') THEN
		SET @queryWhere = CONCAT(@queryWhere,CONCAT(' AND ',@STR,' like('"'%", @Col ,"%'"') '));	
	END IF;
	
	SET @Postition = LOCATE(',', @myArrayOfValue);
END WHILE;
SET @querycount = CONCAT( 'SELECT count(*) into @cnt ', @queryFrom, @queryWhere );
PREPARE stmt1 FROM @querycount;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
SET @selectquery = CONCAT (@selectquery,', ', @cnt, ' as Count ');
SET @QUERY = CONCAT( @selectquery, @queryFrom, @queryWhere );
SET @QUERY = CONCAT(@QUERY, ' order by ', @INDEX,'  ', @sortOrder);
SET @page = (@page - 1) * @LIMIT;
SET @QUERY = CONCAT(@QUERY, ' LIMIT ', @LIMIT ,' OFFSET ',  @page);
 
PREPARE stmt1 FROM @QUERY;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
END;
