CREATE FUNCTION workorder.cap_first(input VARCHAR(255))
  RETURNS VARCHAR(255)
  BEGIN 
DECLARE len INT; 
DECLARE i INT; 
DECLARE charnum INT; 
declare SortedName varchar(255);
SET len   = CHAR_LENGTH(input);
SET input = LOWER(input);
SET i = 1;
set charnum = 1;
set SortedName = '';
WHILE (i <= len) DO
    if charnum = 1 then
        set SortedName = concat(SortedName,upper(mid(input,i,1)));
        set charnum = charnum + 1;
    else
        if mid(input,i,1) = ' ' then
            set SortedName = concat(SortedName,' ');
            set charnum = 1;
        else
            set SortedName = concat(SortedName,mid(input,i,1));
            set charnum = charnum + 1;
        end if;
    end if;
    SET i = i + 1;
END WHILE;
RETURN SortedName;
END;
