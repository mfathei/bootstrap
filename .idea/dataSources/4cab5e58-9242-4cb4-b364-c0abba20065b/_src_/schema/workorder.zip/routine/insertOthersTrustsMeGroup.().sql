CREATE PROCEDURE workorder.insertOthersTrustsMeGroup()
  BEGIN
    DECLARE finish INT DEFAULT 0;
    DECLARE uid VARCHAR(100); 
    DECLARE pid VARCHAR(100);
    DECLARE std_name_sur CURSOR FOR SELECT id,person_id FROM user_tbl;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET finish=1;
    
    SET @c = 0;
    
    OPEN std_name_sur;
    std_name_loop: LOOP
        FETCH std_name_sur INTO uid,pid;
        IF finish=1 THEN
            LEAVE std_name_loop;
        END IF;
        -- select uid,pid;
        SET @objid = UUID();
        
        SET @subid = (SELECT id FROM business_object_tbl WHERE bo_name = 'Relationships' AND owner_id = uid AND participant_id = pid LIMIT 1);
        
        IF @subid IS NOT NULL THEN
        
        INSERT INTO business_object_tbl VALUES(@objid, '3a998af2-d5e1-11e3-a67e-1c6f65f2b147', NULL, 'Others Know or Trust Me', 'Others Know or Trust Me',NULL,"<bo><Identifier>others_know_or_trust_me</Identifier></bo>", NULL,NULL,NULL,NULL, 'Active',
  0, b'1',NULL,NULL,CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),NULL,pid, uid,NULL,NULL,
  uid,uid, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0);
        
        SET @objrel = UUID();
        
        
        INSERT INTO business_object_tbl VALUES(@objrel, '3a98f0dd-d5e1-11e3-a67e-1c6f65f2b147', NULL, 'Relationships-vSDBox:contains:e2g:Coll:Others Know or Trust Me', 'Relationships-vSDBox:contains:e2g:Coll:Others Know or Trust Me',NULL,NULL, NULL,NULL,NULL,NULL, 'Active',
  0, b'1',NULL,NULL,CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP(),NULL,pid, uid,NULL,NULL,
  uid,uid, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0);
        
	INSERT INTO relationship_tbl VALUES(@objrel, @subid, @objid, CURRENT_TIMESTAMP(), NULL,NULL,NULL,'7140cfb6-e727-11e3-94ba-1c6f65f2b147',
NULL,NULL,NULL,NULL,NULL,NULL);
	SET @c = @c + 1;
        END IF;
    END LOOP std_name_loop;
    CLOSE std_name_sur;
SELECT @c AS counter;
END;
