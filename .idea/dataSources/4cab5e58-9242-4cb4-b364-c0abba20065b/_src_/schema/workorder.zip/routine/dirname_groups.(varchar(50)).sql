CREATE PROCEDURE workorder.dirname_groups(IN dirnameid VARCHAR(50))
  begin
drop temporary table if exists tbl_dgroups;
create temporary table tbl_dgroups(
	group_id varchar(50),
	dirname_id varchar(50),
	group_name varchar(255),
	is_primary tinyint default 0,
	checked tinyint default 0
);
insert into tbl_dgroups select `d`.`group_id`,`d`.`dirname_id`,`a`.`group_name`,`a`.`is_primary`,'0'
from `dirname_group` `d` inner join `auth`.`group` `a` 
on `d`.`group_id` = `a`.`group_id`;
update tbl_dgroups set checked = 1 where dirname_id = dirnameid;
select group_id,group_name,is_primary,checked from tbl_dgroups group by group_id order by group_name,checked desc;
drop table if exists tbl_dgroups;
	
end;
