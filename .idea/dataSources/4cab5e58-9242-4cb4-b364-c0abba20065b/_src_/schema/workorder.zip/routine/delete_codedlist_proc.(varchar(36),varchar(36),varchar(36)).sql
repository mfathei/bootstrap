CREATE PROCEDURE workorder.delete_codedlist_proc(IN `$participant_id`      VARCHAR(36),
                                                 IN `$codedlist_lookup_id` VARCHAR(36), IN `$quicklink` VARCHAR(36))
  BEGIN
DECLARE $codedlist_group, $quicklink_group, $codedlist_id, $relationship_id, $relationship_id2, $file_relationship_id, $min_file_id, $max_file_id VARCHAR(36);
SET $codedlist_group = ephr_intake_fun($participant_id, 'coded_list');
SET $quicklink_group = ephr_intake_fun($participant_id, $quicklink);
SET $codedlist_id = (SELECT id FROM codedlist_tbl WHERE id IN (SELECT id FROM business_object_tbl WHERE participant_id = $participant_id) AND codedlist_lookup_id = $codedlist_lookup_id);
SET $relationship_id = (SELECT id FROM relationship_tbl WHERE subject_id = $codedlist_group AND object_id = $codedlist_id);
IF $quicklink_group IS NOT NULL
THEN
SET $relationship_id2 = (SELECT id FROM relationship_tbl WHERE subject_id = $quicklink_group AND object_id = $codedlist_id);
END IF;
SET $min_file_id = (SELECT MIN(object_id) FROM relationship_tbl WHERE subject_id = $codedlist_id);
SET $max_file_id = (SELECT MAX(object_id) FROM relationship_tbl WHERE subject_id = $codedlist_id);
DELETE FROM value_triplet_tbl WHERE business_object_id = $codedlist_id;
DELETE FROM codedlist_tbl WHERE id = $codedlist_id;
DELETE FROM relationship_tbl WHERE id = $relationship_id;
DELETE FROM business_object_tbl WHERE id = $relationship_id;
IF $relationship_id2 IS NOT NULL
THEN
DELETE FROM relationship_tbl WHERE id = $relationship_id2;
DELETE FROM business_object_tbl WHERE id = $relationship_id2;
END IF;
IF $min_file_id IS NOT NULL
THEN
deletfiles: WHILE $min_file_id <= $max_file_id
	DO
		SET $file_relationship_id = (SELECT id FROM relationship_tbl WHERE subject_id = $codedlist_id AND object_id = $min_file_id);
		DELETE FROM file_tbl WHERE id = $min_file_id;
		DELETE FROM relationship_tbl WHERE id = $file_relationship_id;
		DELETE FROM business_object_tbl WHERE id = $file_relationship_id;
		DELETE FROM business_object_tbl WHERE id = $min_file_id;
	IF $min_file_id = $max_file_id
		THEN 
		LEAVE deletfiles;
	ELSE
		SET $min_file_id = (SELECT MIN(object_id) FROM relationship_tbl WHERE subject_id = $codedlist_id AND object_id > $min_file_id);
	END IF;
END WHILE;
END IF;
	DELETE FROM business_object_tbl WHERE id = $codedlist_id;
END;
