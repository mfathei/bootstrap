CREATE PROCEDURE workorder.tmp_proc()
  BEGIN
	declare groupid varchar(50);
	declare dirnameid varchar(50);
	declare dirnm varchar(255);
	declare finished integer default 0;
	declare cur_dir cursor for select dirname_id,dirname from dir_name;
	
	declare continue handler for not found set finished = 1;
	open cur_dir;
	dir: loop
		fetch cur_dir into dirnameid,dirnm;
		if finished = 1 then
			leave dir;
		end if;
		case lower(trim(dirnm))
			when 'hidden' then 
				insert into dirname_group values (myuuid(),dirnameid,(select group_id from auth.group where lower(group_name) = 'execs'));
				insert into dirname_group values (myuuid(),dirnameid,(select group_id from auth.group where lower(group_name) = 'financial'));
			when 'photos' then
				insert into dirname_group values (myuuid(),dirnameid,(select group_id from auth.group where lower(group_name) = 'execs'));
				insert into dirname_group values (myuuid(),dirnameid,(select group_id from auth.group where lower(group_name) = 't0'));
				insert into dirname_group values (myuuid(),dirnameid,(select group_id from auth.group where lower(group_name) = 'techs'));
				insert into dirname_group values (myuuid(),dirnameid,(select group_id from auth.group where lower(group_name) = 'slc'));
				insert into dirname_group values (myuuid(),dirnameid,(select group_id from auth.group where lower(group_name) = 'wta'));
			when 'versions' then
				insert into dirname_group values (myuuid(),dirnameid,(select group_id from auth.group where lower(group_name) = 'execs'));
				insert into dirname_group values (myuuid(),dirnameid,(select group_id from auth.group where lower(group_name) = 't0'));
				insert into dirname_group values (myuuid(),dirnameid,(select group_id from auth.group where lower(group_name) = 'slc'));
				insert into dirname_group values (myuuid(),dirnameid,(select group_id from auth.group where lower(group_name) = 'wta'));
			when 'pos' then
				insert into dirname_group values (myuuid(),dirnameid,(select group_id from auth.group where lower(group_name) = 'execs'));
				insert into dirname_group values (myuuid(),dirnameid,(select group_id from auth.group where lower(group_name) = 'pos'));
			else
				insert into dirname_group values (myuuid(),dirnameid,(select group_id from auth.group where lower(group_name) = 'wouser'));
		end case;
	end loop dir;
	close cur_dir;
END;
