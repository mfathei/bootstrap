CREATE PROCEDURE workorder.insert_nhp_recommended_dose()
  BEGIN
    DECLARE iid                             VARCHAR(50);   
    DECLARE mproduct_id                     INT(11);       
    DECLARE mpopulation_type_desc           VARCHAR(120);  
    DECLARE mpopulation_type_desc_f         VARCHAR(120);  
    DECLARE mage                            INT(3);        
    DECLARE mage_minimum                    INT(3);        
    DECLARE mage_maximum                    INT(3);        
    DECLARE muom_type_desc_age              VARCHAR(120);  
    DECLARE muom_type_desc_age_f            VARCHAR(120);  
    DECLARE mquantity_dose                  DOUBLE;        
    DECLARE mquantity_minimum_dose          DOUBLE;        
    DECLARE mquantity_maximum_dose          DOUBLE;        
    DECLARE muom_type_desc_quantity_dose    VARCHAR(120);  
    DECLARE muom_type_desc_quantity_dose_f  VARCHAR(120);  
    DECLARE mfrequency                      INT(6);        
    DECLARE mfrequency_minimum              INT(6);        
    DECLARE mfrequency_maximum              INT(6);        
    DECLARE muom_type_desc_frequency        VARCHAR(120);  
    DECLARE muom_type_desc_frequency_f      VARCHAR(120);
    DECLARE cur_finished INT DEFAULT 0;
    DECLARE my_prods_cur CURSOR FOR 
    SELECT id,product_id,population_type_desc,population_type_desc_f,age,age_minimum,age_maximum,uom_type_desc_age,uom_type_desc_age_f,quantity_dose,quantity_minimum_dose,quantity_maximum_dose,uom_type_desc_quantity_dose,uom_type_desc_quantity_dose_f,frequency,frequency_minimum,frequency_maximum,uom_type_desc_frequency,uom_type_desc_frequency_f
     FROM nhp_prod_recommended_dose
    ;-- where product_id = 94268 ;-- 563;
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET cur_finished = 1;
    
    SET @product_object = (SELECT id FROM object_type_tbl WHERE object_type_name = 'Product');
    SET @admin = '25c50cc0-8630-11e4-aacb-1c6f65f2b147';
    SET @ingreds_count = 0;
    OPEN my_prods_cur;
    
    my_loop: LOOP
        FETCH my_prods_cur INTO iid,mproduct_id,mpopulation_type_desc,mpopulation_type_desc_f,mage,mage_minimum,mage_maximum,muom_type_desc_age,muom_type_desc_age_f,mquantity_dose,mquantity_minimum_dose,mquantity_maximum_dose,muom_type_desc_quantity_dose,muom_type_desc_quantity_dose_f,mfrequency,mfrequency_minimum,mfrequency_maximum,muom_type_desc_frequency,muom_type_desc_frequency_f;
        IF cur_finished = 1 THEN
            LEAVE my_loop;
        END IF;
        SET @currid = UUID();
        
        -- dosage still required
        INSERT INTO business_object_tbl(id, fullname, `object_type_id`, bo_name, owner_id, updator_id, creator_id)
            VALUES(@currid, pname, @product_object, cname, @admin, @admin, @admin);
        
        -- product_code must be changed to product_code_type_id
        INSERT product_tbl(id, product_code, sub_category_type)
            VALUES(@currid, 'NHP', 'Non-medicinal');
        
        SET @ingreds_count = @ingreds_count + 1;
    END LOOP my_loop;
    
    CLOSE my_prods_cur;
    
    SELECT CONCAT(@ingreds_count, ' recommended_dose inserted!') AS result;
    
END;
