CREATE PROCEDURE workorder.company_bo_proc(IN xmlData TEXT)
  BEGIN
SET @page = EXTRACTVALUE(xmlData, '//page');
SET @LIMIT = EXTRACTVALUE(xmlData, '//limit');
SET @sortOrder =  EXTRACTVALUE(xmlData, '//sortOrder');
SET @INDEX =  EXTRACTVALUE(xmlData, '//index');
SET @Export =  EXTRACTVALUE(xmlData, '//Export');
SET @Opeartion =  EXTRACTVALUE(xmlData, '//Opeartion');
SET @selectquery ="SELECT *	";
SET @queryFrom = " FROM company_address_view ";
SET @queryWhere = ' where 1 = 1  ';
SET @queryWhere = CONCAT(@queryWhere,' and hidden = 0 ');
 -- SET @queryWhere = CONCAT(@queryWhere,' and project_id = ',"'", @project_id,"'");
SET @myArrayOfValue = 'id,abbrev,trademark,incorp_date,incorp_type_id,incorp_number,trading_symbol,year_end_month,tax_number,company_properties,contact_id,incorp_authority_id,incorp_act_id,incorp_jurisdication_stateprov_id,incorp_jurisdication_federal_id,extraprovincial_registration,object_type_id,list_index,bo_name,fullname,description,bo__properties,next_bo_id,value_id,template_id,business_rule_id,status,hidden,mobile_sync,last_accessed_date,update_type,updated_date,created_date,effective_date,expiry_date,participant_id,owner_id,owner_group_id,last_accessor_id,updator_id,creator_id,external_id,external_key_id,external_source_id,file_id,image_id,';
SET @Postition = LOCATE(',', @myArrayOfValue);
WHILE ( @Postition > 0 ) DO
	SET @STR = SUBSTRING(@myArrayOfValue, 1, @Postition-1);
	SET @myArrayOfValue = SUBSTRING(@myArrayOfValue, @Postition + 1);
	SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//',@STR));
	IF (@Col != '' AND @Col !='NULL') THEN
		SET  @STR = TRIM(@STR);
		SET @queryWhere = CONCAT(@queryWhere,CONCAT(' AND ',@STR,' like('"'%", @Col ,"%'"') '));	
	END IF;
	
	SET @Postition = LOCATE(',', @myArrayOfValue);
END WHILE;
SET @querycount = CONCAT( 'SELECT count(*) into @cnt ', @queryFrom, @queryWhere );
PREPARE stmt1 FROM @querycount;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
SET @selectquery = CONCAT (@selectquery,', ', @cnt, ' as Count ');
SET @QUERY = CONCAT( @selectquery, @queryFrom, @queryWhere );
SET @QUERY = CONCAT(@QUERY, ' order by ', @INDEX,'  ', @sortOrder);
IF( @Export ="false") THEN
SET @page = (@page - 1) * @LIMIT;
SET @QUERY = CONCAT(@QUERY, ' LIMIT ', @LIMIT ,' OFFSET ',  @page);
 
END IF;
PREPARE stmt1 FROM @QUERY;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
END;
