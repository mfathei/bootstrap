CREATE PROCEDURE workorder.ProductGroup(IN `$CompanyId` VARCHAR(36))
  BEGIN
DECLARE fetch_status INT DEFAULT 0;
DECLARE $PriceListId VARCHAR(36);
DECLARE $GroupId VARCHAR(36);
DECLARE $TestId VARCHAR(36);
DECLARE $GroupName VARCHAR(255);
  DECLARE PriceList_cursor CURSOR FOR 
	SELECT  object_id FROM  relationship_tbl
	WHERE subject_id  = $CompanyId AND object_id IN  (SELECT id FROM business_object_tbl WHERE object_type_id IN (SELECT id FROM object_type_tbl WHERE object_type_name = 'price list'));
  /*DECLARE Group_cursor CURSOR FOR 
				select  object_id from  relationship_tbl
				where subject_id  = $PriceListId and object_id in  (select id from business_object_tbl where object_type_id in (select id from object_type_tbl where object_type_name = 'group'));*/
 DECLARE CONTINUE HANDLER FOR NOT FOUND SET fetch_status = 100;
  OPEN PriceList_cursor;
 --  OPEN Group_cursor;
 	WHILE fetch_status = 0
					DO
    FETCH PriceList_cursor INTO $PriceListId;
CALL `WhoKnozMe`.`GroupCursor`($PriceListId, $GroupName);
   --  FETCH Group_cursor INTO $GroupId;
					/*SET $TestId = (select object_id from relationship_tbl where subject_id = $GroupId  LIMIT 1);
				
					if $TestId in (select id from business_object_tbl where object_type_id = (select id from object_type_tbl where object_type_name = 'product')) then
					set $GroupName = (select fullname from business_object_tbl where id = $GroupId);
					else 
					while $TestId <> (select id from business_object_tbl where object_type_id = (select id from object_type_tbl where object_type_name = 'product') limit 1)
					do
					set $GroupId = $TestId;
					set $TestId = (select object_id from relationship_tbl where subject_id = $GroupId LIMIT 1);
					end while;					
					set $GroupName = (select fullname from business_object_tbl where id = $GroupId);
					-- select $GroupName;
					end if;
 select 'test',  $GroupName, $GroupId;
FETCH NEXT FROM Group_cursor into $GroupId;*/
FETCH PriceList_cursor INTO $PriceListId;
  END WHILE;
  -- CLOSE Group_cursor;
  CLOSE PriceList_cursor;
END;
