CREATE PROCEDURE salesrep.add_attachment(IN filename  VARCHAR(255), IN contenttype VARCHAR(255),
                                         IN actionid  VARCHAR(50), IN tablename VARCHAR(50))
  BEGIN
    set @uuid = (select myuuid());
    set @sql = concat('insert into ',tablename,' (attachment_id,action_id,attachment_name,attachment_contenttype) values ('',@uuid,'','',actionid,'','',filename,'','',contenttype,'')');
    PREPARE stmt FROM @sql;
    execute stmt;
    deallocate prepare stmt;
    set @sql = concat('select * from ',tablename,' where attachment_id = '',@uuid,''');
    prepare stmt from @sql;
    execute stmt;
    deallocate prepare stmt;
END;
