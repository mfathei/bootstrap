CREATE VIEW salesrep.emails AS
  SELECT
    `e`.`email_id`       AS `email_id`,
    `e`.`emailtype_id`   AS `emailtype_id`,
    `t`.`emailtype_name` AS `emailtype_name`,
    `e`.`salesrep_id`    AS `salesrep_id`,
    `e`.`is_main`        AS `is_main`,
    `e`.`email_text`     AS `email_text`
  FROM (`salesrep`.`email` `e`
    JOIN `salesrep`.`email_type` `t` ON ((`e`.`emailtype_id` = `t`.`emailtype_id`)))
  ORDER BY `e`.`is_main` DESC;
