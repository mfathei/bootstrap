CREATE VIEW salesrep.notes AS
  SELECT
    `salesrep`.`note`.`note_id`                            AS `note_id`,
    `salesrep`.`note`.`salesrep_id`                        AS `salesrep_id`,
    date_format(`salesrep`.`note`.`note_date`, '%Y-%m-%d') AS `note_date`,
    `salesrep`.`note`.`note_text`                          AS `note_text`
  FROM `salesrep`.`note`
  ORDER BY `salesrep`.`note`.`note_date` DESC;
