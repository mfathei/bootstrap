CREATE VIEW salesrep.phones AS
  SELECT
    `p`.`phone_id`       AS `phone_id`,
    `p`.`phonetype_id`   AS `phonetype_id`,
    `t`.`phonetype_name` AS `phonetype_name`,
    `p`.`salesrep_id`    AS `salesrep_id`,
    `p`.`is_main`        AS `is_main`,
    `p`.`phone_text`     AS `phone_text`
  FROM (`salesrep`.`phone` `p`
    JOIN `salesrep`.`phone_type` `t` ON ((`p`.`phonetype_id` = `t`.`phonetype_id`)))
  ORDER BY `p`.`is_main` DESC;
