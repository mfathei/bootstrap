CREATE VIEW salesrep.addresses AS
  SELECT
    `a`.`address_id`       AS `address_id`,
    `a`.`addresstype_id`   AS `addresstype_id`,
    `t`.`addresstype_name` AS `addresstype_name`,
    `a`.`salesrep_id`      AS `salesrep_id`,
    `a`.`city_id`          AS `city_id`,
    `c`.`city_name`        AS `city_name`,
    `c`.`state_id`         AS `state_id`,
    `s`.`state_name`       AS `state_name`,
    `s`.`country_id`       AS `country_id`,
    `co`.`country_name`    AS `country_name`,
    `a`.`is_main`          AS `is_main`,
    `a`.`address_text`     AS `address_text`,
    `a`.`postal_code`      AS `postal_code`
  FROM ((((`salesrep`.`address` `a`
    JOIN `salesrep`.`address_type` `t` ON ((`a`.`addresstype_id` = `t`.`addresstype_id`))) JOIN `common`.`city` `c`
      ON ((`a`.`city_id` = `c`.`city_id`))) JOIN `common`.`state` `s` ON ((`s`.`state_id` = `c`.`state_id`))) JOIN
    `common`.`country` `co` ON ((`co`.`country_id` = `s`.`country_id`)))
  ORDER BY `a`.`is_main` DESC;
