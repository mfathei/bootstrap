CREATE VIEW salesrep.salesreps AS
  SELECT
    `s`.`salesrep_id`    AS `salesrep_id`,
    `t`.`territory_name` AS `territory_name`,
    `s`.`first_name`     AS `first_name`,
    `s`.`last_name`      AS `last_name`,
    `s`.`company_name`   AS `company_name`,
    `s`.`web_page`       AS `web_page`,
    `y`.`reptype_name`   AS `reptype_name`,
    (SELECT `ay`.`actiontype_name`
     FROM (`salesrep`.`action_type` `ay`
       JOIN `salesrep`.`action` `a` ON ((`ay`.`actiontype_id` = `a`.`actiontype_id`)))
     WHERE (`a`.`salesrep_id` = `s`.`salesrep_id`)
     ORDER BY `a`.`action_date` DESC
     LIMIT 1)            AS `actiontype_name`,
    (SELECT `a`.`action_date`
     FROM `salesrep`.`action` `a`
     WHERE (`a`.`salesrep_id` = `s`.`salesrep_id`)
     ORDER BY `a`.`action_date` DESC
     LIMIT 1)            AS `action_date`,
    (SELECT `a`.`action_expirydate`
     FROM `salesrep`.`action` `a`
     WHERE (`a`.`salesrep_id` = `s`.`salesrep_id`)
     ORDER BY `a`.`action_date` DESC
     LIMIT 1)            AS `action_expirydate`
  FROM ((`salesrep`.`sales_rep` `s`
    JOIN `common`.`territory` `t` ON ((`s`.`territory_id` = `t`.`territory_id`))) JOIN `salesrep`.`rep_type` `y`
      ON ((`y`.`reptype_id` = `s`.`reptype_id`)))
  ORDER BY `s`.`first_name`;
