CREATE VIEW salesrep.actions AS
  SELECT
    `a`.`action_id`                                  AS `action_id`,
    `a`.`actiontype_id`                              AS `actiontype_id`,
    `t`.`actiontype_name`                            AS `actiontype_name`,
    `a`.`salesrep_id`                                AS `salesrep_id`,
    date_format(`a`.`action_date`, '%Y-%m-%d')       AS `action_date`,
    date_format(`a`.`action_expirydate`, '%Y-%m-%d') AS `action_expirydate`
  FROM (`salesrep`.`action` `a`
    JOIN `salesrep`.`action_type` `t` ON ((`a`.`actiontype_id` = `t`.`actiontype_id`)))
  ORDER BY `a`.`action_date` DESC;
