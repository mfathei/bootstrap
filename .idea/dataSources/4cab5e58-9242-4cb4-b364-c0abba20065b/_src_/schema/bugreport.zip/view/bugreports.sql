CREATE VIEW bugreport.bugreports AS
  SELECT
    `b`.`report_id`                                AS `report_id`,
    `b`.`user_id`                                  AS `user_id`,
    concat(`u`.`first_name`, ' ', `u`.`last_name`) AS `user_name`,
    `u`.`user_email`                               AS `user_email`,
    `b`.`module`                                   AS `module`,
    `b`.`report_date`                              AS `report_date`,
    `s`.`report_statusname`                        AS `report_statusname`
  FROM ((`bugreport`.`report` `b`
    JOIN `auth`.`user` `u` ON ((`b`.`user_id` = `u`.`user_id`))) JOIN `bugreport`.`report_status` `s`
      ON ((`s`.`report_statusid` = `b`.`report_statusid`)))
  ORDER BY `b`.`report_date` DESC;
