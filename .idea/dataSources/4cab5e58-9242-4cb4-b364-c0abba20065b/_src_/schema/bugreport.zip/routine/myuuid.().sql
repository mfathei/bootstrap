CREATE FUNCTION bugreport.myuuid()
  RETURNS VARCHAR(50)
  if @@hostname like '%[.]%'
then
	return concat(LEFT(@@hostname,LOCATE('.',@@hostname) - 1),'-',uuid());
else 
	return concat(@@hostname,'-',uuid());  
end if;
