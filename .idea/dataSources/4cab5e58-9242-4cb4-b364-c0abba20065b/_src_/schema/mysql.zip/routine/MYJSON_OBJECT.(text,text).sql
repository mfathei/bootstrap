CREATE FUNCTION MYJSON_OBJECT(ky TEXT, val TEXT)
  RETURNS TEXT
  BEGIN
        return concat('{"', ky,'": "', val,'"}');
    END;
