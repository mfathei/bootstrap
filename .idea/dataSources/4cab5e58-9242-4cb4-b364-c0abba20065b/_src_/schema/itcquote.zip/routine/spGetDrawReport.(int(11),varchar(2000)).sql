CREATE PROCEDURE itcquote.spGetDrawReport(IN pDrawingRequestID INT, IN pTemplatesDir VARCHAR(2000))
  BEGIN
    -- Insert statements for procedure here
    DECLARE vxmlDoc TEXT CHARSET utf8 ;
    DECLARE vstrXSL VARCHAR (21844) CHARSET utf8 ;
    DECLARE vstrDoc VARCHAR (21844) CHARSET utf8 ;
    DECLARE vstrQuote VARCHAR (21844) CHARSET utf8 ;
    DECLARE vstrQuoteItems VARCHAR (21844) CHARSET utf8 ;
    DECLARE vQuoteID INT ;
    SET pTemplatesDir = 'http://portal.sprung.com/ITCquotes/V01/WS/ITCQuotesShared/Templates/DrawingRequest.xsl' ;
    -- SET pTemplatesDir = 'http://192.168.250.113:8080/ITCQuotesShared/Templates/DrawingRequest.xsl'  ;
    SET vstrXSL = pTemplatesDir ;
    SET vQuoteID = 
    (SELECT 
        QuoteID 
    FROM
        DrawingRequests 
    WHERE (
            DrawingRequestID = pDrawingRequestID
        )) ;
    -- to create and fill temporary table GetQuoteDrawingRequestsReport_t
    set @i = GetQuoteDrawingRequestsReport(pDrawingRequestID) ;
    SELECT 
        Convert(CURDATE(), CHAR(50)),
        Convert(CreateDate, CHAR(50)),
        ContactName,
        SendTo,
        SendVia,
        DrawingType,
        DrawingCategory,
        DrawingSize,
        DrawingUnit,
        DeliveryPoint,
        Caption,
        Comments,
        ReferenceDrawingRequestID,
        -- Salma Modified on 22 march 2015 added requested date & delivery date instead of expected date
        
            Convert(RequestedDeliveryDate, CHAR(50)),
        
            Convert(PromisedDeliveryDate, CHAR(50)) -- Salma Modified on 3-6-2015 added the following fields
        ,
        QuoteID,
        Company,
        Address,
        Address2,
        City,
        State,
        Country,
        Zip,
        PhoneNo,
        Fax,
        Email,
        WebSite,
        Attention,
        SalesRep,
        Location,
        Application,
        QuoteDuration,
        PricingPolicy,
        BuiltCode,
        WindRate,
        
            CONVERT(CAST(SnowLoad AS unsigned), CHAR(30)),
        -- Salma Modified on 22 march 2015 added StructureWidth,StructureLength and Expsoure
        StructureWidth,
        StructureLength,
        Exposure 
        into 
        @CurrentDate,
        @CreateDate,
        @ContactName,
        @SendTo,
        @SendVia,
        @DrawingType,
        @DrawingCategory,
        @DrawingSize,
        @DrawingUnit,
        @DeliveryPoint,
        @Caption,
        @Comments,
        @ReferenceDrawingRequestID,
        @RequestedDeliveryDate,
        @PromisedDeliveryDate,
        @QuoteID,
        @Company,
        @Address,
        @Address2,
        @City,
        @State,
        @Country,
        @Zip,
        @PhoneNo,
        @Fax,
        @Email,
        @WebSite,
        @Attention,
        @SalesRep,
        @Location,
        @Application,
        @QuoteDuration,
        @PricingPolicy,
        @BuiltCode,
        @WindRate,
        @SnowLoad,
        @StructureWidth,
        @StructureLength,
        @Exposure 
    FROM
        GetQuoteDrawingRequestsReport_t -- FOR XML PATH('')
        ;
    -- for xml path('')
    
    SET vstrDoc = xml_tag ('CurrentDate',@CurrentDate,null,null) ;
    SET vstrDoc = concat( vstrDoc, xml_tag ('CreateDate',@CreateDate,null,null)) ;
    SET vstrDoc = concat( vstrDoc, xml_tag ('ContactName',@ContactName,null,null)) ;
    SET vstrDoc = concat( vstrDoc, xml_tag ('SendTo',@SendTo,null,null)) ;
    SET vstrDoc = concat( vstrDoc, xml_tag ('SendVia',@SendVia,null,null)) ;
    SET vstrDoc = concat( vstrDoc, xml_tag ('DrawingType',@DrawingType,null,null)) ;
    SET vstrDoc = concat( vstrDoc, xml_tag ('DrawingCategory',@DrawingCategory,null,null)) ;
    SET vstrDoc = concat( vstrDoc, xml_tag ('DrawingSize',@DrawingSize,null,null)) ;
    SET vstrDoc = concat( vstrDoc, xml_tag ('DrawingUnit',@DrawingUnit,null,null)) ;
    SET vstrDoc = concat( vstrDoc, xml_tag ('DeliveryPoint',@DeliveryPoint,null,null)) ;
    SET vstrDoc = concat( vstrDoc, xml_tag ('Captio_utf8',@Caption,null,null)) ;
    SET vstrDoc = concat( vstrDoc, xml_tag ('Comments',@Comments,null,null)) ;
    SET vstrDoc = concat( vstrDoc, xml_tag ('ReferenceDrawingRequestID',@ReferenceDrawingRequestID,null,null)) ;
    SET vstrDoc = concat( vstrDoc, xml_tag ('RequestedDeliveryDate',@RequestedDeliveryDate,null,null)) ;
    SET vstrDoc = concat( vstrDoc, xml_tag ('PromisedDeliveryDate',@PromisedDeliveryDate,null,null)) ;
    SET vstrDoc = concat( vstrDoc, xml_tag ('QuoteID',@QuoteID,null,null)) ;    
    SET vstrDoc = concat( vstrDoc, xml_tag ('Company',@Company,null,null)) ;
    SET vstrDoc = concat( vstrDoc, xml_tag ('Address',@Address,null,null)) ;
    SET vstrDoc = concat( vstrDoc, xml_tag ('Address2',@Address2,null,null)) ;
    SET vstrDoc = concat( vstrDoc, xml_tag ('City',@City,null,null)) ;
    SET vstrDoc = concat( vstrDoc, xml_tag ('State',@State,null,null)) ;
    SET vstrDoc = concat( vstrDoc, xml_tag ('Country',@Country,null,null)) ;
    SET vstrDoc = concat( vstrDoc, xml_tag ('Zip',@Zip,null,null)) ;
    SET vstrDoc = concat( vstrDoc, xml_tag ('PhoneNo',@PhoneNo,null,null)) ;
    SET vstrDoc = concat( vstrDoc, xml_tag ('Fax',@Fax,null,null)) ;
    SET vstrDoc = concat( vstrDoc, xml_tag ('Email',@Email,null,null)) ;
    SET vstrDoc = concat( vstrDoc, xml_tag ('WebSite',@WebSite,null,null)) ;
    SET vstrDoc = concat( vstrDoc, xml_tag ('Attentio_utf8',@Attention,null,null)) ;
    SET vstrDoc = concat( vstrDoc, xml_tag ('SalesRep',@SalesRep,null,null)) ;
    SET vstrDoc = concat( vstrDoc, xml_tag ('Locatio_utf8',@Location,null,null)) ;
    SET vstrDoc = concat( vstrDoc, xml_tag ('Applicatio_utf8',@Application,null,null)) ;
    SET vstrDoc = concat( vstrDoc, xml_tag ('QuoteDuratio_utf8',@QuoteDuration,null,null)) ;
    SET vstrDoc = concat( vstrDoc, xml_tag ('PricingPolicy',@PricingPolicy,null,null)) ;
    SET vstrDoc = concat( vstrDoc, xml_tag ('BuiltCode',@BuiltCode,null,null)) ;
    SET vstrDoc = concat( vstrDoc, xml_tag ('WindRate',@WindRate,null,null)) ;
    SET vstrDoc = concat( vstrDoc, xml_tag ('SnowLoad',@SnowLoad,null,null)) ;
    SET vstrDoc = concat( vstrDoc, xml_tag ('StructureWidth',@StructureWidth,null,null)) ;
    SET vstrDoc = concat( vstrDoc, xml_tag ('StructureLength',@StructureLength,null,null)) ;
    SET vstrDoc = concat( vstrDoc, xml_tag ('Exposure',@Exposure ,null,null)) ;
    
    -- SET vstrQuote = (SELECT ;
    --                   QuoteID,
    --		  IFNULL(Company,'') as Company ,
    --		  IFNULL( Address , '') as Address,
    --		  IFNULL(Address2,'')as Address2,
    --		  IFNULL(City ,'') as City,
    --		  IFNULL(State,'') as State,
    --		  IFNULL(Country,'') as Country,
    --		  IFNULL( Zip,'') as Zip,
    --		  IFNULL(PhoneNo,'') as PhoneNo,
    --		  IFNULL(Fax,'') as Fax,
    --		  IFNULL( Email,'') as Email,
    --		  IFNULL(Attention , '') as Attention,
    --		  IFNULL(SalesRep ,'') as SalesRep,
    --		  IFNULL( Location  , '') as Location ,
    --		  IFNULL( Application  ,'') as Application,
    --		  IFNULL(QuoteDuration ,'') as QuoteDuration ,
    --		  IFNULL(PricingPolicy,'') as PricingPolicy ,
    --		  IFNULL(BuiltCode,'') as BuiltCode ,
    --		  IFNULL(WindRate,'') as WindRate,
    --		  IFNULL(CONVERT(varchar(30), CAST(SnowLoad AS float), 0) ,'') as SnowLoad,
    --		  -- Salma Modified on 22 march 2015 added StructureWidth,StructureLength and Expsoure
    --		  IFNULL(StructureWidth ,'') as StructureWidth,
    --		  IFNULL(StructureLength ,'') as StructureLength,
    --		  IFNULL(Exposure ,'') as Exposure
    --                 FROM GetQuoteReport(vQuoteID,1) FOR XML PATH(''))
    SET vstrQuoteItems = GetQuoteItemsReport(vQuoteID, 1) ;
    
    SET vstrDoc = -- _utf8'<?xml version="1.0" encoding="iso-8859-1"?>' + 
    concat('<?xml version="1.0" encoding="UTF-8" standalone="no"?>' , '<?xml-stylesheet type="text/xsl" href="' , vstrXSL , '"?>' , '<DrawReport xmlns="DrawReportNS">' , vstrDoc , -- vstrQuote +
    vstrQuoteItems , '</DrawReport>' );
    SET vxmlDoc = vstrDoc; -- CAST(vstrDoc AS TEXT);
    SELECT 
        vstrDoc AS DrawReport,
        vxmlDoc AS DrawReportAsXML,
        vstrXSL AS TemplateFullName ;
END;
