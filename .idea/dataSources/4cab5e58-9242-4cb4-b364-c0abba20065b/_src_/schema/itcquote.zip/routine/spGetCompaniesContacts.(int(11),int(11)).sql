CREATE PROCEDURE itcquote.spGetCompaniesContacts(IN `_AccountID` INT, IN `_TerritoryID` INT)
  BEGIN
	
	SELECT ContactID
		,ContactName
	FROM Contacts
	WHERE (ContactTypeID = 1)
		AND (
			(
				(ScopeID = 1)
				AND (CreateAccountID = _AccountID)
				)
			OR (
				(ScopeID = 2)
				AND (
					CreateAccountID IN (
						SELECT AccountID
						FROM Accounts
						WHERE TerritoryID = _TerritoryID
						)
					)
				)
			OR
			/*--((ScopeID IS NULL) ) OR
			--((CreateAccountID IS NULL) ) OR*/
			((ScopeID = 3))
			);
END;
