CREATE FUNCTION itcquote.xml_escape(tagvalue VARCHAR(2000))
  RETURNS VARCHAR(2000)
  BEGIN
IF (tagvalue IS NULL) THEN
RETURN null;
END IF;
RETURN REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
tagvalue,'&','&amp;'),
'<','&lt;'),
'>','&gt;'),
'"','&quot;'),
''','&apos;');
END
;
