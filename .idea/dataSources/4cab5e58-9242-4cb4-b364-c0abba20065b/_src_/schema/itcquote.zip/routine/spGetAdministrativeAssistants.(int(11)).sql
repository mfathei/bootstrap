CREATE PROCEDURE itcquote.spGetAdministrativeAssistants(IN `_TerritoryID` INT)
  BEGIN
    -- Insert statements for procedure here
	SELECT * from DevelopmentManagers 
	where Title like 'Administrative Assistant%' 
	And (_TerritoryID=0 OR TerritoryID=_TerritoryID);
END;
