CREATE PROCEDURE itcquote.spAddPricingType(IN  `_PurchaseTypeID` INT, IN `_PricingTypeName` VARCHAR(50),
                                           IN  `_PriceTerm`      INT, IN `_Description` VARCHAR(1000),
                                           OUT `_PricingTypeID`  INT)
  begin 
INSERT into PricingTypes
(
	
	PurchaseTypeID,
	PricingTypeName,
	PriceTerm,
	Description
)
VALUES
(
	_PurchaseTypeID,
	_PricingTypeName,
	_PriceTerm,
	_Description
);
SELECT last_insert_id() into _PricingTypeID ;
end;
