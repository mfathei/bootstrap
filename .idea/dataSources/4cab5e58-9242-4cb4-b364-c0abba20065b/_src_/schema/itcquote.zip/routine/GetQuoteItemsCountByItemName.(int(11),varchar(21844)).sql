CREATE FUNCTION itcquote.GetQuoteItemsCountByItemName(pQuoteID INT, pQuoteItemName VARCHAR(21844))
  RETURNS INT
  BEGIN
	RETURN (
			SELECT count(*)
			FROM QuotesItems
			WHERE (QuotesItems.QuoteID = pQuoteID)
				AND (QuotesItems.ItemName LIKE CONCAT('%' , pQuoteItemName , '%'))
			);
END;
