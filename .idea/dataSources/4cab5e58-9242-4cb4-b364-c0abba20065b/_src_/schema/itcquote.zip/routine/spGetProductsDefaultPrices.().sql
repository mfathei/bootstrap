CREATE PROCEDURE itcquote.spGetProductsDefaultPrices()
  BEGIN
     SELECT     PricingTypes.PricingTypeName, PricingPolicies.PricingPolicyName, PricingPolicies.PricingPolicyID, PricingTypes.PricingTypeID, t.OldPricingPolicyID, 
                      t.OldPricingTypeID
FROM         (SELECT     PricingPolicyID AS OldPricingPolicyID, PricingTypeID AS OldPricingTypeID
FROM         ProductsDefaultPrices AS ProductsDefaultPrices_1
GROUP BY PricingPolicyID, PricingTypeID) AS t INNER JOIN
                      PricingPolicies ON t.OldPricingPolicyID = PricingPolicies.PricingPolicyID INNER JOIN
                      PricingTypes ON t.OldPricingPolicyID = PricingTypes.PricingTypeID;
END;
