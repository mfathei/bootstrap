CREATE PROCEDURE itcquote.spGetQuoteItemsAggregates(IN `_QuoteID` INT, IN `_QuoteItemsTypeID` INT)
  BEGIN
IF   _QuoteItemsTypeID = 0
    then
	  SELECT  SUM(Quantity * CustomSalePrice) AS TotalSalePrice,
              SUM(Quantity * CustomLeaseTermAPrice) AS TotalLeaseTermAPrice,
			  SUM(Quantity * CustomLeaseTermBPrice) AS TotalLeaseTermBPrice, 
              SUM(Quantity * CustomManhours) AS TotalManhours
	  FROM QuotesItems WHERE QuoteID = _QuoteID ;
  
    ELSE
  
	  SELECT  SUM(Quantity * CustomSalePrice) AS TotalSalePrice,
              SUM(Quantity * CustomLeaseTermAPrice) AS TotalLeaseTermAPrice,
			  SUM(Quantity * CustomLeaseTermBPrice) AS TotalLeaseTermBPrice, 
              SUM(Quantity * CustomManhours) AS TotalManhours  	
	  FROM QuotesItems WHERE (QuoteID = _QuoteID) AND (ItemTypeID = _QuoteItemsTypeID);
  
END if;
END;
