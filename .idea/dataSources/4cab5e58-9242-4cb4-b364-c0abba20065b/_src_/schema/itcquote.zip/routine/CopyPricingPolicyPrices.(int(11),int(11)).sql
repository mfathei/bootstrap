CREATE PROCEDURE itcquote.CopyPricingPolicyPrices(IN pfromPolicyID INT, IN ptoPolicyID INT)
  BEGIN
	DECLARE vCount INT ;
		-- pfromPolicyID int = 1, -- Inc
		-- ptoPolicyID int = 16 -- GSA
	call BackupOldPrices(ptoPolicyID);
	DELETE
	FROM ProductsPrices
	WHERE PricingPolicyID = ptoPolicyID;
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	-- SET vPolicyName = (SELECT PricingPolicyName FROM PricingPolicies WHERE PricingPolicyID=vpolicyID);
	-- SET vPolicyName=vPolicyName+'_'+CONVERT(VARCHAR(50),Month(GETDATE()))+'_'+CONVERT(VARCHAR(50),YEAR(GETDATE()))
	-- set vCount= (SELECT COUNT(*) FROM PricingPolicies WHERE PricingPolicyName = vPolicyName)
	-- if(vCount > 0) RETURN -1
	-- INSERT INTO  PricingPolicies (PricingPolicyName,[Description])--values(vPolicyName,)
	-- SELECT vPolicyName,[DescriptionFROM PricingPolicies WHERE PricingPolicyID=vpolicyID
	-- set vnewPolicyID=(SELECT vvIDENTITY)
	INSERT INTO ProductsPrices (
		ProductID
		,PricingPolicyID
		,PricingTypeID
		,Price
		)
	SELECT ProductID
		,ptoPolicyID
		,PricingTypeID
		,Price
	FROM ProductsPrices
	WHERE PricingPolicyID = pfromPolicyID;
	-- LTD Round((Price+(Price*9.5/100)),2)
	SET vCount = (
			SELECT COUNT(*)
			FROM ProductsPrices
			WHERE PricingPolicyID = ptoPolicyID
			);
	select vCount;
		-- If return -1 then pricing policy with the same name already exists
		-- If return 0 then pricing policy is added but with no prices
		-- Otherwise return the number of added prices 
END;
