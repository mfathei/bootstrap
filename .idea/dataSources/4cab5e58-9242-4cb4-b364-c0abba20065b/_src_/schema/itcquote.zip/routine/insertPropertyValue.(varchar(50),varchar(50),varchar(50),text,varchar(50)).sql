CREATE PROCEDURE itcquote.insertPropertyValue(IN `$property_id`       VARCHAR(50), IN `$property_name` VARCHAR(50),
                                              IN `$property_value_id` VARCHAR(50), IN `$property_value` TEXT,
                                              IN `$property_type_id`  VARCHAR(50))
  BEGIN
	set @pid = (select property_id  from property  where property_id=$property_id);
    if @pid is null then -- insert property
		set @pid = myuuid();
        INSERT INTO `property`
                (`property_id`,`property_name`,`property_type_id`)
                VALUES
                (@pid,$property_name,$property_type_id);
        set @pvalid = myuuid();
        INSERT INTO  `property_value`
                            (`property_id`, `property_value_id`, `the_value`,`value_index`)
                        select 
                             @pid, @pvalid, $property_value,(max(value_index)+1) from property_value;
        select @pid as prop_id, @pvalid as prop_val_id;
    else  -- update property
		set @pvalid = (select property_value_id  from property_value  where property_value_id=$property_value_id);
        if @pvalid is not null then -- update
			UPDATE  `property_value`
                            SET  `the_value` = $property_value 
                            WHERE `property_id` =$property_id  AND `property_value_id` = @pvalid ;
		else -- insert
            set @pvalid = myuuid();
			INSERT INTO  `property_value`
                            (`property_id`, `property_value_id`, `the_value`,`value_index`)
                        select 
                             $property_id, @pvalid, $property_value,(max(value_index)+1) from property_value;
		end if;
        select $property_id as prop_id, @pvalid as prop_val_id;
    end if;
END;
