CREATE PROCEDURE itcquote.GetQuoteReport(IN pQuoteID INT, IN pReportTypeID INT)
    this_proc:BEGIN
	-- Fill the table variable with the rows for your result set
	DECLARE vTheDate VARCHAR(50);
	DECLARE vModifyAccountID INT;
	DECLARE vModifyAccountName VARCHAR(50);
	DECLARE vCompanyID INT;
	DECLARE vCompany VARCHAR(50);
	DECLARE vCompanyHeader VARCHAR(50);
	DECLARE vAddress VARCHAR(250);
	DECLARE vAddress2 VARCHAR(250);
	DECLARE vCity VARCHAR(50);
	DECLARE vState VARCHAR(50);
	DECLARE vCountry VARCHAR(50);
	DECLARE vZip VARCHAR(15);
	DECLARE vPhoneNo VARCHAR(15);
	DECLARE vFax VARCHAR(15);
	DECLARE vEmail VARCHAR(50);
	DECLARE vAttentionID INT;
	DECLARE vAttention VARCHAR(150);
	DECLARE vLastName VARCHAR(150);
	DECLARE vSalesRepID INT;
	DECLARE vSalesRep VARCHAR(50);
	DECLARE vLeadOriginID INT;
	DECLARE vLeadOrigin VARCHAR(50);
	DECLARE vPurchaseTerritoryID int;
	DECLARE vPurchaseTerritory VARCHAR(50);
	DECLARE vLandingTerritoryID int;
	DECLARE vLandingTerritory VARCHAR(50);
	DECLARE vStructureID INT;
	DECLARE vStructureWidth INT;
	DECLARE vSize NVARCHAR(50);
	DECLARE vApplicationID INT;
	DECLARE vLocationID INT;
		-- Salma--Modified on 20-12-2014 added AltAirfareCharge
	DECLARE vAltAirfareCharge DECIMAL(10, 2) default 0;
	DECLARE vBuiltCode VARCHAR(50);
	DECLARE vLocation VARCHAR(50);
	DECLARE vPricingPolicyID int;
	DECLARE vPricingPolicy VARCHAR(50);
		-- Salma--modified on 15-1-2015---to get the symbol for pricing from table or PricingPolicies
	DECLARE vPricingPolicySymbol VARCHAR(50);
	DECLARE vLeaseATerm int;
	DECLARE vLeaseBTerm int;
	DECLARE vAnchorageID INT;
	DECLARE vAluminumBarID INT;
	DECLARE vExposureID INT;
		-- ----Salma : Modified in 21-5-2015 -- changed vWindRate from int to float to varchar
	DECLARE vWindRate VARCHAR(30);
		-- ----Salma : Modified 3-6-2015 added MPH and KPH fields
	DECLARE vMPH BIT;
	DECLARE vKPH BIT;
	DECLARE vKPA BIT;
	DECLARE vStructureLength FLOAT;
	DECLARE vIsExport BIT;
	DECLARE vIsMiddleEast BIT;
		-- Salma: added on 28-12-2014 IsGolf, IsMilitary and IsUs to be used weith Bahrain in FOB wording
	DECLARE vIsGulf BIT;
	DECLARE vIsMilitary BIT;
	DECLARE vIsUS BIT;
	DECLARE vStructureSQFT FLOAT;
	DECLARE vInsulationTypeID INT;
	DECLARE vInsulationThicknessID INT;
	DECLARE vMembraneType VARCHAR(50);
	DECLARE vMembraneTypeID INT;
		-- salma: modified in 27-3-2014 -- added FabricType 
	DECLARE vFabricTypeID INT;
	DECLARE vFabricType VARCHAR(50);
	DECLARE vSQFTPerDay INT;
	DECLARE vLeaseTermAID int;
	DECLARE vLeaseTermBID int;
	DECLARE vNoOfCraneBreakPoints int;
	DECLARE vQuoteDuration int;
	DECLARE vNoOfTechConsultants int;
	DECLARE vNoOfRoundEnds int;
	DECLARE vNoOfCenterBays int;
	DECLARE vCenterBaySpacing FLOAT;
	DECLARE vStandardCenterBaySpacing FLOAT;
	DECLARE vStructureStandardLength FLOAT;
	DECLARE vStructureStandardSQFT FLOAT;
	DECLARE vIsAdditionToExistingStructure BIT;
	DECLARE vCompletedByAccountID INT;
	DECLARE vCompletedByAccountName VARCHAR(100);
		-- Salma modified in 21-12-2014 added the rest of the needed data for BDM
	DECLARE vCompletedByTitle VARCHAR(100);
	DECLARE vCompletedByInitials VARCHAR(50);
		-- Salma modified in 9-2-2015 added email for BDM
	DECLARE vCompletedByEmail VARCHAR(100);
		-- Salma--Modified on 10-2-2015 added vCompletedByAssistantInitials
	DECLARE vCompletedByAssistantInitials VARCHAR(50);
	DECLARE vTypedByAccountID INT;
	DECLARE vTypedByAccountName VARCHAR(50);
	DECLARE vUsage VARCHAR(150);
	DECLARE vPolicies VARCHAR(150);
	DECLARE vGuarantee VARCHAR(150);
	DECLARE vInPersonMeeting BIT;
	DECLARE vMailClient BIT;
	DECLARE vMailRep BIT;
	DECLARE vFaxClient BIT;
	DECLARE vFaxRep BIT;
	DECLARE vBrochures BIT;
	DECLARE vStructureCustomLeaseTermAPrice DECIMAL(10, 2);
	DECLARE vStructureCustomLeaseTermBPrice DECIMAL(10, 2);
	DECLARE vStructureCustomSalePrice DECIMAL(10, 2);
	DECLARE vStructureExtendedLeaseTermAPrice DECIMAL(10, 2);
	DECLARE vStructureExtendedLeaseTermBPrice DECIMAL(10, 2);
	DECLARE vStructureExtendedSalePrice DECIMAL(10, 2);
	DECLARE vOptionsLeaseTermAPrice DECIMAL(10, 2);
	DECLARE vOptionsLeaseTermBPrice DECIMAL(10, 2);
	DECLARE vOptionsSalePrice DECIMAL(10, 2);
	DECLARE vTotalLeaseTermAPrice DECIMAL(10, 2);
	DECLARE vTotalLeaseTermBPrice DECIMAL(10, 2);
	DECLARE vTotalSalePrice DECIMAL(10, 2);
	DECLARE vMonthlyA DECIMAL(10, 2);
	DECLARE vMonthlyB DECIMAL(10, 2);
	DECLARE vWithOrder DECIMAL(10, 2);
	DECLARE vFinalTotalLeaseTermAPrice DECIMAL(10, 2);
	DECLARE vFinalTotalLeaseTermBPrice DECIMAL(10, 2);
	DECLARE vFinalTotalSalePrice DECIMAL(10, 2);
	DECLARE vMonthlyAWord NVARCHAR(200);
	DECLARE vMonthlyBWord NVARCHAR(200);
	DECLARE vFinalTotalSalePriceWord NVARCHAR(200);
	DECLARE vTotalManhours INT;
	DECLARE vOptionsManhours INT;
	DECLARE vNoOfWorkers INT;
	DECLARE vNoOfWorkingDays INT;
		-- Salma : Modified in 5-3-2013 added  vCalculatedNoOfWorkers and vCalculatedNoOfWorkingDays -- to be used in Quote Letters---
	DECLARE vCalculatedNoOfWorkers INT;
	DECLARE vCalculatedNoOfWorkingDays INT;
	DECLARE vCraneHours INT;
	DECLARE vManLifts VARCHAR(50);
	DECLARE vCraneSize VARCHAR(50);
	DECLARE vFabricContaminationCost DECIMAL(10, 2);
	DECLARE vFrieghtCost DECIMAL(10, 2);
	DECLARE vTechCost DECIMAL(10, 2);
		-- Salma : Modified in  2-2-2015 added  vAreaWeightsLoadsCount and vItemsLoadsCount -- to be used in Quote Report---
	DECLARE vAreaWeightsLoadsCount INT;
	DECLARE vItemsLoadsCount INT;
	DECLARE vLoadsCount INT;
	DECLARE vMembraneLinerColorID INT;
	DECLARE vMembraneLinerColor VARCHAR(50);
	DECLARE vMembraneColorID INT;
	DECLARE vMembraneColor VARCHAR(150);
		-- ----Salma : Modified in 21-5-2015 -- changed vSnowLoad from int to float
	DECLARE vSnowLoad FLOAT;
		-- Salma -- modified on 2-6-2014-- snowload condition----
	DECLARE vIsSnowLoad BIT;
	DECLARE vSnowLoadExpression VARCHAR(100);
	DECLARE vExposure VARCHAR(50);
	DECLARE vAnchorage VARCHAR(50);
	DECLARE vApplicationName VARCHAR(150);
	DECLARE vClauseName VARCHAR(50);
	DECLARE vDeliveryWording TEXT CHARSET utf8;
	DECLARE vAnchorageWording TEXT CHARSET utf8;
	DECLARE vEngWording TEXT CHARSET utf8;
	DECLARE vFOBClause TEXT CHARSET utf8;
	DECLARE vOptionClause TEXT CHARSET utf8;
	DECLARE vOptionClause3 TEXT CHARSET utf8;
	DECLARE vOptionClause12 TEXT CHARSET utf8;
	DECLARE vOptionClause24 TEXT CHARSET utf8;
	DECLARE vOptionClause36 TEXT CHARSET utf8;
	DECLARE vOptionClause48 TEXT CHARSET utf8;
	DECLARE vOptionClause60 TEXT CHARSET utf8;
	DECLARE vTwoMonthlyPeriods TEXT CHARSET utf8;
	DECLARE vMoreThanTwoMonthlyPeriods TEXT CHARSET utf8;
	DECLARE vExtrasFOBClause TEXT CHARSET utf8;
	DECLARE vAccessoryClause TEXT CHARSET utf8;
	DECLARE vVentilationInsClause TEXT CHARSET utf8;
	DECLARE vVentilationClause TEXT CHARSET utf8;
	DECLARE vCraneLiftingHooks TEXT CHARSET utf8;
	DECLARE vCargoDoorsESDSSD TEXT CHARSET utf8;
	DECLARE vOpaqueFabricClause TEXT CHARSET utf8;
	DECLARE vRollingServiceDoorsInAccessoryClause TEXT CHARSET utf8;
	DECLARE vLeaseTermA24Clause TEXT CHARSET utf8;
	DECLARE vLeaseTermB24Clause TEXT CHARSET utf8;
		-- Modified by salma on 18 -8-2014 to be used in the certificate section
	DECLARE vCertificateMembraneClause TEXT CHARSET utf8;
	DECLARE vCertificateMembraneText TEXT CHARSET utf8;
	DECLARE vCertificateMembraneText1 TEXT CHARSET utf8;
	DECLARE vStructureEnvironmentalOrApplication TEXT CHARSET utf8;
	DECLARE vToolClause TEXT CHARSET utf8;
	DECLARE vEnviroHeading TEXT CHARSET utf8;
	DECLARE vContamination TEXT CHARSET utf8;
	DECLARE vContamination1 TEXT CHARSET utf8;
	DECLARE vContamination2 TEXT CHARSET utf8;
	DECLARE vTechWording TEXT CHARSET utf8;
	DECLARE vTechChargeWording TEXT CHARSET utf8;
		-- Salma Modified on 12-2-2015 -- added vTechnicalConsultantWording and vOvertimeWording 
	DECLARE vTechnicalConsultantWording TEXT CHARSET utf8;
	DECLARE vOvertimeWording TEXT CHARSET utf8;
	DECLARE vRollDoorManpower TEXT CHARSET utf8;
	DECLARE vGuaranteeClause TEXT CHARSET utf8;
	DECLARE vCraneTitle TEXT CHARSET utf8;
	DECLARE vCraneWording TEXT CHARSET utf8;
	DECLARE vBranch VARCHAR(100);
	DECLARE vCountClauses INT default 0;
	DECLARE vLeaseAUnder12Months TEXT CHARSET utf8;
	DECLARE vLeaseBUnder12Months TEXT CHARSET utf8;
		-- --Salma : Modified in 4-3-2013 add the following values to be used in vLeaseTermA24Clause & vLeaseTermB24Clause----
	DECLARE vCompareVariable VARCHAR(200) default 'no daylight panels';
	DECLARE vnodaylightVariable VARCHAR(200) default ' opaque membrane, no daylight panels.';
	DECLARE vdaylightVariable VARCHAR(200) default ' opaque membrane, complete with daylight panels.';
		-- ----------------------------------------------------------------------------------------------------
		-- Salma: Just Modified in 5-6-2014 adding ElectricalAcessories clause Condition -- -------------
	DECLARE vElectricalAccessories TEXT CHARSET utf8;
		-- Salma: Just Modified in 13-10-2014 adding TerritoryAddress and TerritoryPhone based on CreatorTerritory -- -------------
	DECLARE vCreateAccountID INT;
	DECLARE vCreatorTerritory int;
	DECLARE vTerritoryAddress TEXT CHARSET utf8;
	DECLARE vTerritoryPhone TEXT CHARSET utf8;
	DECLARE vTerritoryFooter TEXT CHARSET utf8;
	DECLARE vTerritoryFooterInc TEXT CHARSET utf8;
		-- Salma: added on 12-2-2012 to show Inc or Ltd in signature depending on structure width
	DECLARE vCompanySignature VARCHAR(50);
		-- Salma: added on 3-12-2014 get price of hand tools only
	DECLARE vToolsTotalSalePrice DECIMAL(10, 2) default 0;
		-- Salma: added on 4-12-2014 get TermsPurchaseClause based on PricingPolicyID
	DECLARE vTermsPurchaseClause TEXT CHARSET utf8;
		-- Salma: added on 7-12-2014 get DeliveryClause based on PricingPolicyID
	DECLARE vDeliveryClause TEXT CHARSET utf8;
		-- Salma: added on 7-1-2015 to get the introduction paragraph
	DECLARE vAboutSprung TEXT CHARSET utf8;
		-- Salma--added on 19-1-2015---to get count of clauses for accessories
	DECLARE vAccessoriesClausesCombined INT default 0;
		-- Salma -- Modified in 10-8-2015 added InsulationPackage to be used in SQFT
	DECLARE vInsulationPackageID INT;
	
        if pQuoteID is null
        then
            leave this_proc;
        end if;
	
drop temporary table if exists GetQuoteReport_t;
create temporary table GetQuoteReport_t(
	QuoteID INT
	,TheDate VARCHAR(50)
	,ModifyAccountID INT
	,ModifyAccountName VARCHAR(50)
	,CompanyID INT
	,Company VARCHAR(150)
	,CompanyHeader VARCHAR(150)
	,Address VARCHAR(250)
	,Address2 VARCHAR(250)
	,City VARCHAR(50)
	,STATE VARCHAR(50)
	,Country VARCHAR(50)
	,Zip VARCHAR(15)
	,PhoneNo VARCHAR(15)
	,Fax VARCHAR(15)
	,Email VARCHAR(50)
	,AttentionID INT
	,Attention VARCHAR(150)
	,LastName VARCHAR(150)
	,SalesRepID INT
	,SalesRep VARCHAR(150)
	,LeadOriginID INT
	,LeadOrigin VARCHAR(150)
	,PurchaseTerritoryID int
	,PurchaseTerritory VARCHAR(50)
	,LandingTerritoryID int
	,LandingTerritory VARCHAR(50)
	,LocationID INT
	,Location VARCHAR(150)
	,BuiltCode VARCHAR(50)
	,ApplicationID INT
	,Application VARCHAR(150)
	,PricingPolicyID int
	,PricingPolicy VARCHAR(50)
	,
	-- Salma--modified on 15-1-2015---to get the symbol for pricing from table or PricingPolicies
	PricingPolicySymbol VARCHAR(50)
	,LeaseTermAID int
	,LeaseTermBID int
	,IsExport VARCHAR(5)
	,IsMiddleEast VARCHAR(5)
	,QuoteDuration VARCHAR(15)
	,NoOfTechConsultants VARCHAR(15)
	,CompletedByAccountID INT
	,CompletedByAccountName VARCHAR(50)
	,
	-- Salma modified in 21-12-2014 added the rest of the needed data for BDM
	CompletedByTitle VARCHAR(100)
	,CompletedByInitials VARCHAR(50)
	,
	-- Salma modified in 9-2-2015 added email for BDM
	CompletedByEmail VARCHAR(100)
	,TypedByAccountID INT
	,TypedByAccountName VARCHAR(50)
	,`Usage` VARCHAR(150)
	,Policies VARCHAR(150)
	,Guarantee VARCHAR(150)
	,InPersonMeeting VARCHAR(5)
	,MailClient VARCHAR(5)
	,MailRep VARCHAR(5)
	,FaxClient VARCHAR(5)
	,FaxRep VARCHAR(5)
	,Brochures VARCHAR(5)
	,StructureID INT
	,StructureWidth INT
	,StructureLength VARCHAR(15)
	,Size VARCHAR(50)
	,StructureSQFT VARCHAR(15)
	,StandardCenterBaySpacing VARCHAR(15)
	,StructureStandardLength VARCHAR(15)
	,StructureStandardSQFT VARCHAR(15)
	,SQFTPerDay INT
	,InsulationTypeID INT
	,InsulationThicknessID INT
	,MembraneLinerColorID INT
	,MembraneLinerColor VARCHAR(100)
	,MembraneTypeID INT
	,MembraneType VARCHAR(50)
	,
	-- salma: modified in 27-3-2014 --added FabricType 
	FabricTypeID INT
	,FabricType VARCHAR(50)
	,MembraneColorID INT
	,MembraneColor VARCHAR(100)
	,AnchorageID INT
	,Anchorage VARCHAR(50)
	,ExposureID INT
	,Exposure VARCHAR(50)
	,NoOfCraneBreakPoints int
	,
	-- ----Salma : Modified in 21-5-2015 --changed WindRate and SnowLoad from int to float
	WindRate VARCHAR(30)
	,SnowLoad DECIMAL
	,
	-- Salma --modified on 2-6-2014-- snowload condition----
	IsSnowLoad BIT
	,SnowLoadExpression VARCHAR(100)
	,AluminumBarID INT
	,StructureCustomLeaseTermAPrice VARCHAR(30)
	,StructureCustomLeaseTermBPrice VARCHAR(30)
	,StructureCustomSalePrice VARCHAR(30)
	,StructureExtendedLeaseTermAPrice VARCHAR(30)
	,StructureExtendedLeaseTermBPrice VARCHAR(30)
	,StructureExtendedSalePrice VARCHAR(30)
	,OptionsLeaseTermAPrice VARCHAR(30)
	,OptionsLeaseTermBPrice VARCHAR(30)
	,OptionsSalePrice VARCHAR(30)
	,TotalLeaseTermAPrice VARCHAR(30)
	,TotalLeaseTermBPrice VARCHAR(30)
	,TotalSalePrice VARCHAR(30)
	,MonthlyA VARCHAR(30)
	,MonthlyB VARCHAR(30)
	,WithOrder VARCHAR(30)
	,FinalTotalLeaseTermAPrice VARCHAR(30)
	,FinalTotalLeaseTermBPrice VARCHAR(30)
	,FinalTotalSalePrice VARCHAR(30)
	,MonthlyAWord NVARCHAR(100)
	,MonthlyBWord NVARCHAR(100)
	,FinalTotalSalePriceWord NVARCHAR(100)
	,TotalManhours INT
	,MenNo INT
	,DaysNo INT
	,CalculatedMenNo INT
	,CalculatedDaysNo INT
	,CraneSize VARCHAR(50)
	,CraneHours INT
	,ManLifts VARCHAR(50)
	,FabricContaminationCost VARCHAR(30)
	,FrieghtCost VARCHAR(30)
	,TechCost VARCHAR(30)
	,LoadsCount VARCHAR(30)
	,ClauseName VARCHAR(50)
	,DeliveryWording TEXT CHARSET utf8
	,AnchorageWording TEXT CHARSET utf8
	,EngWording TEXT CHARSET utf8
	,FOBClause TEXT CHARSET utf8
	,OptionClause TEXT CHARSET utf8
	,OptionClause3 TEXT CHARSET utf8
	,OptionClause12 TEXT CHARSET utf8
	,OptionClause24 TEXT CHARSET utf8
	,OptionClause36 TEXT CHARSET utf8
	,OptionClause48 TEXT CHARSET utf8
	,OptionClause60 TEXT CHARSET utf8
	,TwoMonthlyPeriods TEXT CHARSET utf8
	,MoreThanTwoMonthlyPeriods TEXT CHARSET utf8
	,ExtrasFOBClause TEXT CHARSET utf8
	,AccessoryClause TEXT CHARSET utf8
	,VentilationInsClause TEXT CHARSET utf8
	,VentilationClause TEXT CHARSET utf8
	,CraneLiftingHooks TEXT CHARSET utf8
	,CargoDoorsESDSSD TEXT CHARSET utf8
	,OpaqueFabricClause TEXT CHARSET utf8
	,RollingServiceDoorsInAccessoryClause TEXT CHARSET utf8
	,LeaseTermA24Clause TEXT CHARSET utf8
	,LeaseTermB24Clause TEXT CHARSET utf8
	,
	-- Modified by salma on 18 -8-2014 to be used in the certificate section
	CertificateMembraneClause TEXT CHARSET utf8
	,CertificateMembraneText TEXT CHARSET utf8
	,CertificateMembraneText1 TEXT CHARSET utf8
	,StructureEnvironmentalOrApplication TEXT CHARSET utf8
	,ToolClause TEXT CHARSET utf8
	,EnviroHeading TEXT CHARSET utf8
	,Contamination TEXT CHARSET utf8
	,Contamination1 TEXT CHARSET utf8
	,Contamination2 TEXT CHARSET utf8
	,TechWording TEXT CHARSET utf8
	,TechChargeWording TEXT CHARSET utf8
	,
	-- Salma Modified on 12-2-2015 --added @TechnicalConsultantWording and @OvertimeWording 
	TechnicalConsultantWording TEXT CHARSET utf8
	,OvertimeWording TEXT CHARSET utf8
	,RollDoorManpower TEXT CHARSET utf8
	,GuaranteeClause TEXT CHARSET utf8
	,CraneTitle TEXT CHARSET utf8
	,CraneWording TEXT CHARSET utf8
	,Branch VARCHAR(100)
	,LeaseAUnder12Months TEXT CHARSET utf8
	,LeaseBUnder12Months TEXT CHARSET utf8
	-- Salma: Just Modified in 5-6-2014 adding ElectricalAcessories clause Condition ---------------
	,ElectricalAccessories TEXT CHARSET utf8
	-- Salma: Just Modified in 13-10-2014 adding TerritoryAddress and TerritoryPhone based on CreatorTerritory ---------------
	,TerritoryAddress TEXT CHARSET utf8
	,TerritoryPhone TEXT CHARSET utf8
	,CreatorTerritory int
	,CompanySignature VARCHAR(50)
	-- Salma: added on 4-12-2014 get TermsPurchaseClause based on PricingPolicyID
	,TermsPurchaseClause TEXT CHARSET utf8
	-- Salma: added on 7-12-2014 get DeliveryClause based on PricingPolicyID
	,DeliveryClause TEXT CHARSET utf8
	-- Salma: added on 7-1-2015 to get the introduction paragraph
	,AboutSprung TEXT CHARSET utf8
	-- Salma--added on 19-1-2015---to get count of clauses for accessories
	,AccessoriesClausesCombined INT
	);
	
	IF GetNoOfEarthAnchorsRatio(vStructureWidth, vStructureLength, vNoOfCraneBreakPoints, vStandardCenterBaySpacing, vStructureStandardLength, vIsAdditionToExistingStructure) <> 0
    then
		leave this_proc;
    end if;
	IF GetNoOfLiftsRatio(vStructureWidth, vStructureLength) <> 0
    then
		leave this_proc;
    end if;
    
	SELECT 
ModifyAccountID
,CompanyID
,AttentionID
,SalesRepID
,LeadOriginID
,PurchaseTerritoryID
,LandingTerritoryID
,LocationID
,ApplicationID
,PricingPolicyID
,IFNULL(LeaseTermAID, 0)
,IFNULL(LeaseTermBID, 0)
,IsExported
,IsMiddleEast
,IsShippedToGulfState
,IsMilitary
,IsShippedFromUs
,QuoteDuration
,NoOfTechConsultants
,CompletedByAccountID
,TypedByAccountID
,`Usage`
,Policies
,Guarantee
,InPersonMeeting
,MailClient
,MailRep
,FaxClient
,FaxRep
,Brochures
,StructureID
,StructureLength
,InsulationTypeID
,InsulationThicknessID
,MembraneLinerColorID
,MembraneTypeID
,FabricTypeID
,IFNULL(MembraneColorID, 0)
,AnchorageID
,ExposureID
,IFNULL(CONVERT(CAST(WindRate AS DECIMAL), CHAR(30)), '0.0')
,WindMPH
,WindKPH
,WindKPA
,SnowRate
,IsSnowLoad
,NoOfRoundEnds
,NoOfCraneBreakPoints
,NoOfCenterBays
,CenterBaySpacing
,IFNULL(IsAdditionToExistingStructure, 0)
,CreateAccountID
,InsulationPackageID
into
vModifyAccountID
,vCompanyID
,vAttentionID
,vSalesRepID
,vLeadOriginID
,vPurchaseTerritoryID
,vLandingTerritoryID
,vLocationID
,vApplicationID
,vPricingPolicyID
,vLeaseTermAID
,vLeaseTermBID
,
vIsExport
,vIsMiddleEast
,
vIsGulf
,vIsMilitary
,vIsUS
,vQuoteDuration
,vNoOfTechConsultants
,vCompletedByAccountID
,vTypedByAccountID
,vUsage
,vPolicies
,vGuarantee
,vInPersonMeeting
,vMailClient
,vMailRep
,vFaxClient
,vFaxRep
,vBrochures
,vStructureID
,vStructureLength
,vInsulationTypeID
,vInsulationThicknessID
,vMembraneLinerColorID
,vMembraneTypeID
,
vFabricTypeID
,vMembraneColorID
,vAnchorageID
,vExposureID
,vWindRate
,
vMPH
,vKPH
,vKPA
,vSnowLoad
,
vIsSnowLoad
,vNoOfRoundEnds
,vNoOfCraneBreakPoints
,vNoOfCenterBays
,vCenterBaySpacing
,vIsAdditionToExistingStructure
,vCreateAccountID
,vInsulationPackageID
	FROM Quotes
	WHERE (QuoteID = pQuoteID);
	-- IF(vWindRateValue IS NOT NULL)
	-- BEGIN
	--	SET vWindRate=CONVERT(varchar(30), CAST(vWindRateValue AS float), 0) 
	-- END
	-- ELSE 
	-- BEGIN 
	--	SET vWindRate='0.0'
	-- END
	-- ----Salma : Modified 3-6-2015 added MPH and KPH fields
	IF (vMPH = 1)
	then
		SET vWindRate = concat(vWindRate , ' MPH');
	
	ELSEIF (vKPH = 1)
	then
		SET vWindRate = concat(vWindRate , ' KPH');
	
	ELSEIF (vKPA = 1)
	then
		SET vWindRate = concat(vWindRate , ' KPA');
	END if;
	SELECT  QI.CustomLeaseTermAPrice
		, QI.CustomLeaseTermBPrice
		, QI.CustomSalePrice
        into
        vStructureCustomLeaseTermAPrice,
        vStructureCustomLeaseTermBPrice,
        vStructureCustomSalePrice
	FROM QuotesItems QI
	INNER JOIN Products P ON QI.ProductID = P.ProductID
	WHERE (QuoteID = pQuoteID)
		AND (ItemTypeID = 1)
		AND (P.ProductTypeID = 1);
	-- ProductTypeID = 1: Structures
	SELECT  QI.Quantity * QI.CustomLeaseTermAPrice
		, QI.Quantity * QI.CustomLeaseTermBPrice
		, QI.Quantity * QI.CustomSalePrice
        into
        vStructureExtendedLeaseTermAPrice,
        vStructureExtendedLeaseTermBPrice,
        vStructureExtendedSalePrice
	FROM QuotesItems QI
	INNER JOIN Products P ON QI.ProductID = P.ProductID
	WHERE (QuoteID = pQuoteID)
		AND (ItemTypeID = 1)
		AND (P.ProductTypeID = 1);
	-- ProductTypeID = 1: Structures
	SELECT  SUM(QI.Quantity * QI.CustomLeaseTermAPrice)
		, SUM(QI.Quantity * QI.CustomLeaseTermBPrice)
		, SUM(QI.Quantity * QI.CustomSalePrice)
		, IFNULL(CEILING(SUM(Quantity * CustomManhours)), 0)
        into
        vOptionsLeaseTermAPrice,
        vOptionsLeaseTermBPrice,
        vOptionsSalePrice,
        vOptionsManhours
	FROM QuotesItems QI
	LEFT JOIN Products P ON QI.ProductID = P.ProductID
	WHERE (QuoteID = pQuoteID)
		AND (ItemTypeID = 1)
		AND (
			(QI.ProductID = 0)
			OR (P.ProductTypeID <> 1)
			);
	SELECT  SUM(Quantity * CustomLeaseTermAPrice)
		, SUM(Quantity * CustomLeaseTermBPrice)
		, CEILING(SUM(Quantity * CustomSalePrice))
		, IFNULL(CEILING(SUM(Quantity * CustomManhours)), 0)
        into
        vTotalLeaseTermAPrice,
        vTotalLeaseTermBPrice,
        vTotalSalePrice,
        vTotalManhours
	FROM QuotesItems
	WHERE (QuoteID = pQuoteID)
		AND (ItemTypeID = 1);
	-- Salma: added on3-12-2014 get price of hand tools only
	SELECT  CEILING(SUM(Quantity * CustomSalePrice)) into vToolsTotalSalePrice
	FROM QuotesItems
	INNER JOIN Products ON QuotesItems.ProductID = Products.ProductID
		AND ProductTypeID = 33
	WHERE (QuoteID = pQuoteID)
		AND (ItemTypeID = 1)
		AND (ProductTypeID = 33);
	IF (vLeaseTermAID = 0)
    then
		SET vMonthlyA = 0;
	ELSE
		SET vMonthlyA = CEILING(vTotalLeaseTermAPrice / vLeaseTermAID);
    end if;
    
	IF (vLeaseTermBID = 0)
    then
		SET vMonthlyB = 0;
	ELSE
		SET vMonthlyB = CEILING(vTotalLeaseTermBPrice / vLeaseTermBID);
    end if;
    
	SET vWithOrder = CEILING(vTotalSalePrice / 2.0);
	SET vFinalTotalLeaseTermAPrice = vLeaseTermAID * vMonthlyA;
	SET vFinalTotalLeaseTermBPrice = vLeaseTermBID * vMonthlyB;
	SET vFinalTotalSalePrice = 2.0 * vWithOrder;
	-- --------------------------------------------------------
	SET vMonthlyAWord = (
			SELECT fn_Num_ToWords(vMonthlyA)
			);
	SET vMonthlyBWord = (
			SELECT fn_Num_ToWords(vMonthlyB)
			);
	SET vFinalTotalSalePriceWord = (
			SELECT fn_Num_ToWords(vTotalSalePrice)
			);
	-- ---------------------------------------------------------------------------------------------------
	SET vStructureWidth = GetProductPropertyValue_Int(vStructureID, 6);
	-- SET vExposure = GetProductPropertyValue(vExposureID, 58);
	SET vStructureSQFT = GetStructureSQFT(vStructureWidth, vStructureLength);
	SET vSize = concat(convert( vStructureWidth, CHAR(15)) , '' x ' , convert(vStructureLength, CHAR(15)) , ''');
	SET vStandardCenterBaySpacing = GetStructureStandardCenterBaySpacing(vStructureID, vCenterBaySpacing, vSnowLoad);
	SET vStructureStandardLength = GetStructureStandardLength(vNoOfCenterBays, vStandardCenterBaySpacing, vNoOfRoundEnds, vStructureWidth);
	SET vStructureStandardSQFT = GetStructureStandardSQFT(vStructureWidth, vStructureLength, vNoOfCraneBreakPoints, vStandardCenterBaySpacing, vStructureStandardLength, vIsAdditionToExistingStructure);
	-- Salma: Just Modified in 13-10-2014 adding TerritoryAddress and TerritoryPhone based on CreatorTerritory -- -------------
	SELECT  TerritoryID into vCreatorTerritory
	FROM Accounts
	WHERE AccountID = vCreateAccountID;
	SELECT  TerritoryAddress
		, TerritoryPhone
		, TerritoryFooter
		, TerritoryFooterInc
        into
        vTerritoryAddress,
        vTerritoryPhone,
        vTerritoryFooter,
        vTerritoryFooterInc
	FROM Territories
	WHERE TerritoryID = vCreatorTerritory;
	IF (vPricingPolicyID = 1)
	then
		SET vTerritoryFooter = vTerritoryFooterInc;
	END if;
	IF (
			vPricingPolicyID = 3
			AND vStructureWidth >= 100
			)
	then
		SET vTerritoryFooter = REPLACE(vTerritoryFooter, 'Ltd - Calgary, Alberta, Canada', 'Inc - Salt Lake City ');
	END if;
	IF (
			vTerritoryFooter IS NOT NULL
			AND vTerritoryFooter <> ''
			)
    then
		SET vTerritoryAddress = vTerritoryFooter;
    end if;
	-- IF(vCreatorTerritory=10)
	-- SET vTerritoryPhone='1 '+vTerritoryPhone
	IF vApplicationID IN (
			92
			,93
			,94
			,95
			,96
			)
	then
		SET vFabricContaminationCost = 0.5 * vStructureSQFT;
	END if;
	-- ----Salma Modified in 2-4-2014: get SQFTPerDay property value according to quote insulation
	-- ----Salma Modified in 10-8-2015: get SQFTPerDay property value according to quote insulation and Insulation Package
	IF (IsInsulated(vInsulationTypeID) > 0)
	then
		IF (vInsulationPackageID = 784) -- No Liner
        then
			SET vSQFTPerDay = GetProductPropertyValue_Int(vStructureID, 124); -- SqFtPerDayInsulatedNoLiner;
		ELSE
			SET vSQFTPerDay = GetProductPropertyValue_Int(vStructureID, 112); -- SqFtPerDayInsulated;
        end if;
	
	ELSE
		SET vSQFTPerDay = GetProductPropertyValue_Int(vStructureID, 64); -- SQFTperDay;
    end if;
	-- IF(vSQFTPerDay IS NULL OR vSQFTPerDay=0)
	-- SET vSQFTPerDay=1
	SET vCraneHours = IFNULL(GetCraneHours(pQuoteID), ' ');
	SET vCraneSize = IFNULL(GetProductPropertyValue(vStructureID, 40), ' ');
	SET vManLifts = IFNULL(GetProductPropertyValue(vStructureID, 66), ' ');
	SET vNoOfWorkers = GetNoOfWorkers(vStructureID, vIsMiddleEast);
	-- ----Salma Modified in 20-10-2014--use vStructureStandardSQFT insetad of vStructureSQFT-----
	SET vNoOfWorkingDays = GetNoOfWorkingDays(vInsulationTypeID, vStructureStandardSQFT, vSQFTPerDay, vOptionsManhours, vNoOfWorkers);
	-- ----Salma Modified in 5-3-2013-- added condition for quote letter to make calculations of NoOFWorkers & NoOfWorkingDays-----
	-- ----and stored vNoOfWorkingDays in vOriginalNoOfWorkingDays before changing it to be used in vTechCost
	IF (vNoOfTechConsultants > 1)
	then
		SET vCalculatedNoOfWorkers = vNoOfWorkers * vNoOfTechConsultants;
		SET vCalculatedNoOfWorkingDays = Round(((vNoOfWorkingDays * 1.1) / vNoOfTechConsultants), 0);
	
	ELSE
	
		SET vCalculatedNoOfWorkers = vNoOfWorkers;
		SET vCalculatedNoOfWorkingDays = vNoOfWorkingDays;
	END if;
    call GetTransportationCosts(pQuoteID, vStructureID, vStructureStandardSQFT, vLocationID, vNoOfTechConsultants, vCalculatedNoOfWorkingDays);
	-- ----Salma Modified in 1-9-2014------- pass vStructureStandardSQFT instead of vStructureSQFT
	SELECT  FrieghtCost
		, TechCost
		, AreaWeightsLoadsCount
		, ItemsLoadsCount
        into
        vFrieghtCost,
        vTechCost,
        vAreaWeightsLoadsCount,
        vItemsLoadsCount
	-- Salma Modified on 20-1-2015--- used vCalculatedNoOfWorkingDays instead of vNoOfWorkingDays to divide by NoOfTechConsulatants
	FROM GetTransportationCosts_t;
	SET vLoadsCount = vAreaWeightsLoadsCount + vItemsLoadsCount;
	-- Salma Modified on 9-2-2015 -- add TechCost to TotalSalePrice in case on International in Quote Letter
	IF (
			pReportTypeID = 1
			AND vPricingPolicyID = 3
			) -- letter and International 
	then
		SET vTotalSalePrice = CEILING(vTotalSalePrice + vTechCost);
	END if;
	-- ------------ Contacts Info -- --------------------------------------  
	SELECT  ContactName into vModifyAccountName
	FROM Contacts
	WHERE (ContactID = vModifyAccountID);
	-- ----Salma Modified in 21-12-2014------- get completed by from BDM tables not contacts
	-- SELECT  vCompletedByAccountName = ContactName FROM Contacts WHERE (ContactID = vCompletedByAccountID)
	-- Salma modified in 9-2-2015 added email for BDM
	SELECT  concat(FirstName , ' ' , LastName)
		, Title
		, Initials
		, Email
        into
        vCompletedByAccountName,
        vCompletedByTitle,
        vCompletedByInitials,
        vCompletedByEmail
	FROM DevelopmentManagers
	WHERE (ManagerID = vCompletedByAccountID);
	-- Salma modified in 10-2-2015 added vCompletedByAssistantInitials for BDM
	IF (
			vCompletedByInitials IS NOT NULL
			AND vCompletedByInitials NOT LIKE ''
			)
	then
		SELECT  A.Initials into vCompletedByAssistantInitials
		FROM DevelopmentManagers AS M
		INNER JOIN DevelopmentManagers AS A ON M.TerritoryID = A.TerritoryID
		WHERE M.ManagerID = vCompletedByAccountID
			AND A.Title LIKE 'Administrative Assistant'
		ORDER BY A.ManagerID limit 1;
		IF (
				vCompletedByAssistantInitials IS NOT NULL
				AND vCompletedByAssistantInitials NOT LIKE ''
				)
		then
			SET vCompletedByInitials = concat(vCompletedByInitials , '/' , vCompletedByAssistantInitials);
		END if;
	END if;
	SELECT  ContactName into vTypedByAccountName
	FROM Contacts
	WHERE (ContactID = vTypedByAccountID);
	SELECT  ContactName
		, ContactName
		, Address
		, Address2
		, City
		, STATE
		, Country
		, Zip -- ,
        into
        vCompany,
        vCompanyHeader,
        vAddress,
        vAddress2,
        vCity,
        vState,
        vCountry,
        vZip
		-- Formatting the phone number whatever its input Format is
		-- vPhoneNo = FormatPhoneNumber(replace(PhoneNo, '-', '')), 
		-- vFax = Fax,
		-- vEmail = Email
	FROM Contacts
	WHERE (ContactID = vCompanyID);
	SELECT  ContactName  
		-- --------updated in 29/04/2012 until getting confirmation for the header contacts------------
		-- Formatting the phone number whatever its input Format is
		, FormatPhoneNumber(replace(PhoneNo, '-', ''))
		, FormatPhoneNumber(replace(Fax, '-', ''))
		, TRIM(Email)
        into
        vAttention,
        vPhoneNo,
        vFax,
        vEmail
	-- ------------------------------------------------
	FROM Contacts
	WHERE (ContactID = vAttentionID);
	SELECT  ContactName into vSalesRep
	FROM Contacts
	WHERE (ContactID = vSalesRepID);
	IF (
			vAttention IS NOT NULL
			AND vAttention <> ''
			)
	then
		SET vLastName = SUBSTRING(vAttention, LOCATE(' ', vAttention, 0) + 1, length(vAttention));
	END if;
	-- -----------------------------------------------------------------------
	-- ------------------------- Others -- -----------------------------------
	SELECT  TerritoryName into vPurchaseTerritory
	FROM Territories 
	WHERE TerritoryID = vPurchaseTerritoryID;
	SELECT  TerritoryName into vLandingTerritory
	FROM Territories
	WHERE TerritoryID = vLandingTerritoryID;
	SELECT  LeadOriginName into vLeadorigin
	FROM LeadOrigins
	WHERE LeadOriginID = vLeadOriginID;
	-- SELECT  vLocation = LocationName FROM Locations WHERE LocationID = vLocationID
	SELECT  concat(T1.LocationName , ', ' , IFNULL(T2.LocationName, '')) into vLocation
	FROM Locations T1
	LEFT JOIN Locations T2 ON T1.ParentID = T2.LocationID
	WHERE T1.LocationID = vLocationID;
	-- Salma--Modified on 20-12-2014 added AltAirfareCharge
	SELECT  AltAirfareCharge into vAltAirfareCharge
	FROM Locations
	WHERE LocationID = vLocationID;
	SELECT  BuildingCodes.BuildingCodeName into vBuiltCode
	FROM BuildingCodes
	INNER JOIN Locations ON BuildingCodes.BuildingCodeID = Locations.BuildingCodeID
	WHERE (Locations.LocationID = vLocationID);
	SELECT ApplicationName into vApplicationName
	FROM Applications
	WHERE (ApplicationID = vApplicationID);
	IF IFNULL(vUsage, '') = ''
	then
		SELECT  IFNULL(T2.ApplicationName, '') into vUsage
		FROM Applications T1
		LEFT JOIN Applications T2 ON T1.ParentID = T2.ApplicationID
		WHERE T1.ApplicationID = vApplicationID;
	END if;
	SELECT  PricingPolicyName
		, PricingPolicySymbol
        into 
        vPricingPolicy,
        vPricingPolicySymbol
	FROM PricingPolicies
	WHERE (PricingPolicyID = vPricingPolicyID);
	-- ---------------------------------------------------------------------
	-- Salma: added on 4-12-2014 get TermsPurchaseClause based on PricingPolicyID
	SET vTermsPurchaseClause = IFNULL(GetClauseWording(0, vPricingPolicyID, 'TermsPurchaseClause'), ' ');
	-- Salma: added on 7-12-2014 get DeliveryClause based on PricingPolicyID
	SET vDeliveryClause = IFNULL(GetClauseWording(0, vPricingPolicyID, 'DeliveryClause'), ' ');
	-- Salma: modified on 13-1-2015-- replace location 
	SET vDeliveryClause = REPLACE(vDeliveryClause, '#Location#', vLocation);
	-- IF vPricingPolicyID=3 AND vStructureWidth <= 160
	-- SET vDeliveryClause=vDeliveryClause+' Any demurrage for container return will be buyers responsibility.'
	-- IF(vPricingPolicyID <> 3 AND vDeliveryClause <> ' ')
	-- SET vDeliveryClause=vDeliveryClause+' '+vLocation+'.'
	-- --------------- Delivery Wording -- -------------------
	-- Salma: modified on 25-12-2014 remove structure width conditon as it is not used
	-- IF vStructureWidth <= 160 SET vClauseName = 'Availability';
	-- ELSE SET vClauseName = 'Delivery2';
	SET vClauseName = 'Availability';
	SET vDeliveryWording = IFNULL(GetClauseWording(0, NULL, vClauseName), ' ');
	-- Salma: modified on 13-1-2015-- commented the following as it is now part of Delivery Clause
	-- IF vPricingPolicyID=3 AND vStructureWidth <= 160
	-- SET vDeliveryWording =vDeliveryWording -- +' Any demurrage for container return will be buyers responsibility.';
	-- ------------------------------------------------------
	-- --------------- Eng Wording -- -------------------
	-- - Salma:  Modified in 28-12-2014 use EngineeringClause instead of the constant -- ----
	SET vEngWording = IFNULL(GetClauseWording(0, vPricingPolicyID, 'EngineeringClause'), ' ');
	-- SET vEngWording = 'This structure has been designed to meet ' + CAST(vWindRate AS varchar(50)) + ' mph, Exposure ' + vExposure + ', Wind as per ASCE-7-93 (UBC).';
	-- SET vEngWording = 'This structure has been designed to meet ' + CAST(vWindRate AS varchar(50)) + ' mph, Exposure ' + vExposure + ', 3 second wind gust as per ASCE-7-98 (IBC).';
	-- ------------------------------------------------------
	-- --------------- Clauses -- -----------------------------
	-- - Salma:  Modified in 13-10-2014 changing conditions and replacing parameters -- -------------
	-- SET vClauseName = 'FOBWording';
	-- SET vFOBClause = GetClauseWording(0, vPricingPolicyID, vClauseName);
	-- IF (vPricingPolicyID=1 or vPricingPolicyID=2) set vClauseName='PriceFOB'
	-- ELSE SET vClauseName = 'PriceExWorks';
	-- SET vFOBClause = GetClauseWording(0, NULL, vClauseName);
	-- Salma modified in 24-12-2014 renamed the clauses and added conditions for Bahrian 
	IF (
			vPricingPolicyID = 1
			OR vPricingPolicyID = 2
			) -- inc, ltd or bahrain
	then
		SET vClauseName = 'FOBWording';
	
	ELSEIF (vPricingPolicyID = 4) -- Bahrain
	then
		IF (
				vIsGulf = 1
				AND vIsMilitary = 1
				)
        then
			SET vClauseName = 'FOBWording';
		ELSEIF (
				vIsGulf = 1
				AND vIsMilitary = 0
				)
        then
			SET vClauseName = 'FOBWording2';
		ELSEIF (
				vIsUS = 1
				AND vIsMilitary = 1
				)
        then
			SET vClauseName = 'FOBWording3';
		ELSEIF (
				vIsUS = 1
				AND vIsMilitary = 0
				)
        then
			SET vClauseName = 'FOBWording4';
		ELSEIF (
				vIsGulf = 0
				AND vIsUS = 0
				)
        then
			SET vClauseName = 'FOBWording2';
        end if;
	ELSEIF (vPricingPolicyID = 3) -- international depends on width
	then
		IF (vStructureWidth <= 90)
        then
			SET vClauseName = 'FOBWording(30)';
        end if;
        
		IF (vStructureWidth >= 100)
        then
			SET vClauseName = 'FOBWording(100)';
        end if;
	END if;
	SET vFOBClause = GetClauseWording(0, vPricingPolicyID, vClauseName);
	-- IF (vPricingPolicyID=1)--inc 
	-- BEGIN
	-- SET vClauseName = 'Width100Address';
	-- SET vFOBClause =vFOBClause+' '+ GetClauseWording(0, NULL, vClauseName);
	-- END
	-- ELSE
	-- BEGIN 
	--	IF(vPricingPolicyID=2)--ltd
	--	then
	--		 SET vClauseName = 'Width30Address';
	--		 SET vFOBClause =vFOBClause+' '+ GetClauseWording(0, NULL, vClauseName);
	--	END 
	--	ELSE 
	--	BEGIN
	--		IF (vStructureWidth <=90) SET vClauseName = 'Width30Address';
	--		IF (vStructureWidth >=100)SET vClauseName = 'Width100Address'
	--		SET vFOBClause =vFOBClause+' '+ GetClauseWording(0, NULL, vClauseName);
	--	END
	-- END
	-- - Just Modified in 30/04/2012 after adding the new ClauseName with the new conditional Layers---------------
	-- IF (vLeaseTermAID <= 12) AND (vLeaseTermBID <= 12) SET vClauseName = 'Options1to12';
	-- ELSEIF (vLeaseTermAID >= 24) AND (vLeaseTermBID >=24) SET vClauseName = 'Options24to36';
	-- ELSE SET vClauseName = 'Options12to24';
	-- SET vOptionClause = GetClauseWording(0, vPricingPolicyID, vClauseName);
	-- - Salma: Just Modified in 21/02/2013 changing conditions and replacing parameters -- -------------
	-- if (vLeaseTermAID >=3 ) or (vLeaseTermBID >=3)
	IF (vLeaseTermAID >= 1)
		OR (vLeaseTermBID >= 1)
	then
		SET vClauseName = 'GreaterThan3';
		SET vOptionClause3 = GetClauseWording(0, vPricingPolicyID, vClauseName);
		SET vCountClauses = vCountClauses + 1;
	END if;
	-- -Salma: Just Modified in 18/02/2013 conditions should be between 
	-- if (vLeaseTermAID >=12 AND vLeaseTermAID <24  ) or (vLeaseTermBID >=12 AND vLeaseTermBID <24)
	IF (
			vLeaseTermAID >= 1
			AND vLeaseTermAID < 24
			)
		OR (
			vLeaseTermBID >= 1
			AND vLeaseTermBID < 24
			)
	then
		SET vClauseName = 'GreaterThan12';
		SET vOptionClause12 = GetClauseWording(0, vPricingPolicyID, vClauseName);
		SET vCountClauses = vCountClauses + 1;
	END if;
	IF (
			vLeaseTermAID >= 24
			AND vLeaseTermAID < 36
			)
		OR (
			vLeaseTermBID >= 24
			AND vLeaseTermBID < 36
			)
	then
		SET vClauseName = 'GreaterThan24';
		SET vOptionClause24 = GetClauseWording(0, vPricingPolicyID, vClauseName);
		SET vCountClauses = vCountClauses + 1;
	END if;
	IF (
			vLeaseTermAID >= 36
			AND vLeaseTermAID < 48
			)
		OR (
			vLeaseTermBID >= 36
			AND vLeaseTermBID < 48
			)
	then
		SET vClauseName = 'GreaterThan36';
		SET vOptionClause36 = GetClauseWording(0, vPricingPolicyID, vClauseName);
		SET vCountClauses = vCountClauses + 1;
	END if;
	IF (
			vLeaseTermAID >= 48
			AND vLeaseTermAID < 60
			)
		OR (
			vLeaseTermBID >= 48
			AND vLeaseTermBID < 60
			)
	then
		SET vClauseName = 'GreaterThan48';
		SET vOptionClause48 = GetClauseWording(0, vPricingPolicyID, vClauseName);
		SET vCountClauses = vCountClauses + 1;
	END if;
	IF (vLeaseTermAID >= 60)
		OR (vLeaseTermBID >= 60)
	then
		SET vClauseName = 'GreaterThan60';
		SET vOptionClause60 = GetClauseWording(0, vPricingPolicyID, vClauseName);
		SET vCountClauses = vCountClauses + 1;
	END if;
	-- if (vLeaseTermAID > 0 ) and (vLeaseTermBID > 0) and (vCountClauses=2)
	IF (vCountClauses = 2)
	then
		SET vClauseName = 'TwoMonthlyPeriods';
		SET vTwoMonthlyPeriods = GetClauseWording(0, NULL, vClauseName);
	END if;
	-- if (vLeaseTermAID > 0 ) and (vLeaseTermBID > 0)and (vCountClauses=3)
	IF (vCountClauses = 3)
	then
		SET vClauseName = 'MoreThanTwoMonthlyPeriods';
		SET vMoreThanTwoMonthlyPeriods = GetClauseWording(0, NULL, vClauseName);
	END if;
	-- ------If Inc then Salt Lake City.---------------------------------------------
	-- ------If Ltd then Calgary.----------------------------------------------------
	IF (vPricingPolicyID = 1)
		OR (vPricingPolicyID = 12)
    then
		SET vBranch = 'Salt Lake City, Utah';
	ELSE
		SET vBranch = 'Calgary';
    end if;
	-- ------------------------------------------------------------------------------
	SET vExtrasFOBClause = vFOBClause ;-- IFNULL(GetClauseWording(0, vPricingPolicyID, 'FOBWording'),' ');
	-- ----Just Modified in 24-11-2011 to put Accessory Clause in conditin if there is an Accessory
	IF (
			SELECT GetQuoteItemsCount(pQuoteID)
			) > 0
    then
		SET vAccessoryClause = GetClauseWording(0, NULL, 'Accessory');
	ELSE
		SET vAccessoryClause = '';
    end if;
	-- ----Just Modified in 04-12-2011 to put Accessory Clause in conditin if its parent is Louvred Openings and its property name Is Insulated and its value = 1
	-- ----Salma: Just Modified in 18-02-2013 to put Accessory Clause in conditin if it's Insulation Type not equal "None" and Membrane Type contain "Polyurethane"
	IF (
			SELECT CheckQuotePropertyValueByProductName(pQuoteID, 'Louvred Opening', 'Option', 'IsInsulated', 1)
			) > 0
	then
		SET vVentilationInsClause = GetClauseWording(0, NULL, 'VentilationIns');
		-- Salma--added on 19-1-2015---to get count of clauses for accessories
		SET vAccessoriesClausesCombined = vAccessoriesClausesCombined + 1;
	
	ELSE
		SET vVentilationInsClause = '';
    end if;
	-- ----Just Modified in 04-12-2011 to put Accessory Clause in conditin if its parent is Louvred Openings and its property name Is Insulated and its value = 0
	-- ----Salma: Just Modified in 18-02-2013 to put Accessory Clause in conditin if it's Insulation Type not equal "None" and Membrane Type contain "Polyurethane"
	IF (
			SELECT CheckQuotePropertyValueByProductName(pQuoteID, 'Louvred Opening', 'Option', 'IsInsulated', 0)
			) > 0
	then
		SET vVentilationClause = GetClauseWording(0, NULL, 'Ventilation');
		-- Salma--added on 19-1-2015---to get count of clauses for accessories
		SET vAccessoriesClausesCombined = vAccessoriesClausesCombined + 1;
	
	ELSE
		SET vVentilationClause = '';
    end if;
	-- ----Just Modified in 06-12-2011 to put Accessory Clause in conditin if it's Insulation Type = "None" and Membrane Type contain "Acrylic"
	-- ----Salma: 28-2-2013 change Polyurethane to Acrylic--------------------------------------------------------------------------------------
	-- salma modified on 17-9-2015--- changed the condition to add the clause only in case no skylight
	IF (
			SELECT GetPropertyValue(vInsulationTypeID)
			) = 'None'
		AND LOWER(GetPropertyValue(vFabricTypeID)) LIKE '%no daylight panels%'
		-- if  (select GetPropertyValue(vInsulationTypeID))= 'None' and (select GetPropertyValue(vFabricTypeID))like '%Polyurethane%' 
	then
		SET vOpaqueFabricClause = GetClauseWording(0, vPricingPolicyID, 'OpaqueFabric');
		-- Salma--added on 19-1-2015---to get count of clauses for accessories
		SET vAccessoriesClausesCombined = vAccessoriesClausesCombined + 1;
	
	ELSE
		SET vOpaqueFabricClause = '';
    end if;
	-- Salma : Just Modified in 18-02-2013 uncommented the calling and change Acrylic to Polyurethane
	-- if  (select GetPropertyValue(vMembraneTypeID))like '%Polyurethane%'
	-- SET vRollingServiceDoorsInAccessoryClause = GetClauseWording(0, vPricingPolicyID, 'RollingServiceDoorsInAccessory');
	-- else
	IF (
			SELECT GetQuoteItemsCountByItemName(pQuoteID, 'Rolling Service Door')
			) > 0
		-- SET vRollingServiceDoorsInAccessoryClause =REPLACE(GetClauseWording(0, 1, 'RollingServiceDoorsInAccessory') , CHAR(10), '&#10;' );
	then
		-- Salma : Just Modified in 1-04-2015 passing vPricingPolicyID instead of 1
		SET vRollingServiceDoorsInAccessoryClause = GetClauseWording(0, vPricingPolicyID, 'RollingServiceDoorsInAccessory');
		-- Salma--added on 19-1-2015---to get count of clauses for accessories
		SET vAccessoriesClausesCombined = vAccessoriesClausesCombined + 1;
	
	ELSE
		SET vRollingServiceDoorsInAccessoryClause = '';
    end if;
	-- if  (select CheckQuotePropertyValue(pQuoteID,'Membrane','Option','MembraneType','%Acrylic%'))>0
	-- SET vRollingServiceDoorsInAccessoryClause = GetClauseWording(0, vPricingPolicyID, 'RollingServiceDoorsInAccessory');
	-- else
	-- SET vRollingServiceDoorsInAccessoryClause ='';
	-- if ((select CheckQuotePropertyValue(pQuoteID,'Membrane','Option','MembraneType','%Tedlar%'))>0 and (vLeaseTermAID=24) )or ((select CheckQuotePropertyValue(pQuoteID,'Membrane','Option','MembraneType','%Kynar%'))>0 and (vLeaseTermAID=24))
	-- set vLeaseTermA24Clause ='Tedlar or Kynar coated opaque membrane, available in a wide range of colors, please contact local Sprung sales office.'
	-- else set vLeaseTermA24Clause ='As available from existing inventory.' 
	-- if ((select CheckQuotePropertyValue(pQuoteID,'Membrane','Option','MembraneType','%Tedlar%'))>0 and (vLeaseTermBID=24) ) or ((select CheckQuotePropertyValue(pQuoteID,'Membrane','Option','MembraneType','%Kynar%'))>0 and (vLeaseTermBID=24))
	-- set vLeaseTermB24Clause ='Tedlar or Kynar coated opaque membrane, available in a wide range of colors, please contact local Sprung sales office.'
	-- else set vLeaseTermB24Clause ='As available from existing inventory.' 
	-- to put Accessory Clause in conditin if it's Insulation Type contain "Tedlar" with LeaseTermA = 24 or Membrane Type contain "Kynar" with LeaseTermA = 24
	-- if ((select GetPropertyValue(vMembraneTypeID))like '%Tedlar%' and (vLeaseTermAID=24)) or ((select GetPropertyValue(vMembraneTypeID))like '%Kynar%' and (vLeaseTermAID=24))
	IF (
			(
				SELECT GetPropertyValue(vFabricTypeID)
				) LIKE '%Tedlar%'
			)
		OR (
			(
				SELECT GetPropertyValue(vFabricTypeID)
				) LIKE '%Kynar%'
			)
		-- Salma: Modified on 20-02-2013 added # after Tedlar to be replaced in xsl by ®
	then
		SET vLeaseTermA24Clause = 'Tedlar# or Kynar coated opaque membrane, available in a wide range of colors, please contact local Sprung sales office.';
	
			-- Salma: Modified on 20-02-2013 the clause value was 'As available from existing inventory.' and is replaced by 'Acrylic opaque membrane, no daylight panels.'
			-- else set vLeaseTermA24Clause ='Acrylic opaque membrane, no daylight panels.'
			-- 'As available from existing inventory.' 
			-- Salma: Modified on 04-03-2013 the clause value was 'Acrylic opaque membrane, no daylight panels.' and is replaced by variable based on membrane type
	ELSEIF (LOWER(GetPropertyValue(vFabricTypeID)) LIKE CONCAT('%' , vCompareVariable , '%'))
	then
		SET vLeaseTermA24Clause = concat(SUBSTRING(GetPropertyValue(vFabricTypeID), 1, (LOCATE(' ', concat(GetPropertyValue(vFabricTypeID) ,' ')) - 1)) , vnodaylightVariable);
	
	ELSE
	
		SET vLeaseTermA24Clause = concat(SUBSTRING(GetPropertyValue(vFabricTypeID), 1, (LOCATE(' ', concat(GetPropertyValue(vFabricTypeID) , ' ')) - 1)) , vdaylightVariable);
	END if;
	-- to put Accessory Clause in conditin if it's Insulation Type contain "Tedlar" with LeaseTermB = 24 or Membrane Type contain "Kynar" with LeaseTermB = 24
	-- if ((select GetPropertyValue(vMembraneTypeID))like '%Tedlar%' and (vLeaseTermBID=24)) or ((select GetPropertyValue(vMembraneTypeID))like '%Kynar%' and (vLeaseTermBID=24))
	IF (
			(
				SELECT GetPropertyValue(vFabricTypeID)
				) LIKE '%Tedlar%'
			)
		OR (
			(
				SELECT GetPropertyValue(vFabricTypeID)
				) LIKE '%Kynar%'
			)
    then
		-- Salma: Modified on 20-02-2013 added # after Tedlar to be replaced in xsl by ®
		SET vLeaseTermB24Clause = 'Tedlar# or Kynar coated opaque membrane, available in a wide range of colors, please contact local Sprung sales office.';
			-- Salma: Modified on 20-02-2013 the clause value was 'As available from existing inventory.' and is replaced by 'Acrylic opaque membrane, no daylight panels.'
			-- else set vLeaseTermB24Clause='Acrylic opaque membrane, no daylight panels.'
			-- 'As available from existing inventory.' 
			-- Salma: Modified on 04-03-2013 the clause value was 'Acrylic opaque membrane, no daylight panels.' and is replaced by variable based on membrane type
	ELSEIF (LOWER(GetPropertyValue(vFabricTypeID)) LIKE CONCAT('%' , vCompareVariable , '%'))
	then
		SET vLeaseTermB24Clause = concat(SUBSTRING(GetPropertyValue(vFabricTypeID), 1, (LOCATE(' ', concat(GetPropertyValue(vFabricTypeID) , ' ')) - 1)) , vnodaylightVariable);
	
	ELSE
		SET vLeaseTermB24Clause = concat(SUBSTRING(GetPropertyValue(vFabricTypeID), 1, (LOCATE(' ', concat(GetPropertyValue(vFabricTypeID) , ' ')) - 1)) , vdaylightVariable);
    end if;
	-- ---Salma: Modified on 12-11-2014 -- added different membraneclauses for certificated based on FabricType
	IF (
			(
				SELECT GetPropertyValue(vFabricTypeID)
				) LIKE '%Tedlar%'
			)
		OR (
			(
				SELECT GetPropertyValue(vFabricTypeID)
				) LIKE '%Kynar%'
			)
		-- Salma: Modified on 20-02-2013 added # after Tedlar to be replaced in xsl by ®
	then
		SET vCertificateMembraneClause = GetClauseWording(0, NULL, 'TedlarCertificateClause');
		SET vCertificateMembraneText = GetClauseWording(0, NULL, 'TedlarCertificateClause1');
		SET vCertificateMembraneText1 = GetClauseWording(0, NULL, 'TedlarCertificateClause2');
	
	ELSEIF (
			(
				SELECT GetPropertyValue(vFabricTypeID)
				) LIKE '%Polyurethane%'
			)
	then
		SET vCertificateMembraneClause = GetClauseWording(0, NULL, 'PolyurethaneCertificateClause');
		SET vCertificateMembraneText = GetClauseWording(0, NULL, 'PolyurethaneCertificateClause1');
		SET vCertificateMembraneText1 = GetClauseWording(0, NULL, 'PolyurethaneCertificateClause2');
	
	ELSE -- LTA
	
		SET vCertificateMembraneClause = GetClauseWording(0, NULL, 'LTACertificateClause');
		SET vCertificateMembraneText = GetClauseWording(0, NULL, 'LTACertificateClause1');
		SET vCertificateMembraneText1 = GetClauseWording(0, NULL, 'LTACertificateClause2');
	END if;
	-- to put Clause in conditin if it's application name is Environmental both parent or child
	IF (
			SELECT COUNT(*)
			FROM Applications
			INNER JOIN Quotes ON Applications.ApplicationID = Quotes.ApplicationID
			WHERE (Applications.ApplicationName LIKE '%Environmental%')
				OR (
					Applications.ParentID = (
						SELECT ApplicationID
						FROM Applications
						WHERE (ApplicationName LIKE '%Environmental%')
						limit 1)
					)
			GROUP BY Quotes.QuoteID
			HAVING (Quotes.QuoteID = pQuoteID)
			) > 0
    then
		SET vStructureEnvironmentalOrApplication = REPLACE(IFNULL(GetClauseWording(0, NULL, 'Contamination'), ''), '$', vPricingPolicySymbol);
	ELSE
		SET vStructureEnvironmentalOrApplication = '';
    end if;
	-- to put Clause in condition if it have a product named "Crane Lifting Hooks"
	IF (
			SELECT CheckQuoteProductExist(pQuoteID, 'Crane Lifting Hooks', 'Option')
			) > 0
	then
		SET vCraneLiftingHooks = GetClauseWording(0, NULL, 'CraneLift');
		-- Salma--added on 19-1-2015---to get count of clauses for accessories
		SET vAccessoriesClausesCombined = vAccessoriesClausesCombined + 1;
	
	ELSE
		SET vCraneLiftingHooks = '';
    end if;
	-- to put Clause in condition if it have a product named "End Sliding Cargo Doors"
	-- Modified by Salma on 22-5-2013-- put brackets around the cargo doors conditions------------------
	IF (
			(
				SELECT CheckQuoteProductExist(pQuoteID, 'End Sliding Cargo Doors', 'Option')
				) > 0
			OR (
				SELECT CheckQuoteProductExist(pQuoteID, 'Side Sliding Cargo Doors', 'Option')
				) > 0
			)
		AND (IsInsulated(vInsulationTypeID)) > 0
	then
		SET vCargoDoorsESDSSD = GetClauseWording(0, NULL, 'CargoDoors');
		-- Salma--added on 19-1-2015---to get count of clauses for accessories
		SET vAccessoriesClausesCombined = vAccessoriesClausesCombined + 1;
	
	ELSE
		SET vCargoDoorsESDSSD = '';
    end if;
	-- --------------------------------------------------
	IF (vIsExport = 1)
    then
		SET vClauseName = 'ToolsExport';
			-- Modified by Salma on 20-10-2014-- send pricing policy as NUll since u depend on export and territory not Policy
			-- also if T21 (international) then use InternationalTools clause----
			-- ELSEIF(vCreatorTerritory=10) SET vClauseName='InternationalTools'
			-- Modified by Salma on 24-14-2014-- send pricing policy instead of territory in case of bahrian & international 
	ELSEIF (
			vPricingPolicyID = 3
			OR vPricingPolicyID = 4
			)
    then
		SET vClauseName = 'InternationalTools';
	ELSE
		SET vClauseName = 'Tools';
    end if;
	IF (vClauseName = 'InternationalTools') -- in case of international and bahrain 
	then
		SET vToolClause = GetClauseWording(0, vPricingPolicyID, vClauseName);
	
	ELSE
	
		SET vToolClause = GetClauseWording(0, vPricingPolicyID, vClauseName);
	END if;
	IF (vIsExport = 1)
    then
		SET vToolClause = concat(vToolClause , ' ' , CONVERT( vToolsTotalSalePrice, CHAR(30)) , ' providing that all tools have been returned in good condition.');
	ELSEIF (vCreatorTerritory = 10)
    then
		SET vToolClause = concat(vToolClause , ' ' , CONVERT(vToolsTotalSalePrice, CHAR(30)));
    end if;
    
	IF vApplicationID IN (
			92
			,93
			,94
			,95
			,96
			)
	then
		SET vEnviroHeading = GetClauseWording(0, NULL, 'EnviroHeading');
		SET vContamination = REPLACE(GetClauseWording(0, NULL, 'Contamination'), '$', vPricingPolicySymbol);
		SET vContamination1 = REPLACE(GetClauseWording(0, NULL, 'Contamination1'), '$', vPricingPolicySymbol);
		SET vContamination2 = REPLACE(GetClauseWording(0, NULL, 'Contamination2'), '$', vPricingPolicySymbol);
	END if;
	IF (vNoOfTechConsultants > 1)
    then
		SET vClauseName = 'TechsWording';
	ELSE
		SET vClauseName = 'TechWording';
    end if;
    
	SET vTechWording = GetClauseWording(0, vPricingPolicyID, vClauseName);
	-- Salma--Modified on 29-12-2014--- added conditions for AltAirfare in case on bahrain
	IF (vNoOfTechConsultants > 1)
	then
		IF (
				vAltAirfareCharge = 0
				AND vPricingPolicyID = 4
				) -- bahrian
        then
			SET vClauseName = 'TechsFixedChargeWording' ;-- No Airport;
		ELSE
			SET vClauseName = 'TechsChargeWording';
        end if;
	
	ELSE
	
		IF (
				vAltAirfareCharge = 0
				AND vPricingPolicyID = 4
				) -- bahrian
        then
			SET vClauseName = 'TechFixedChargeWording' ;-- No Airport;
		ELSE
			SET vClauseName = 'TechChargeWording';
        end if;
	END if;
	SET vTechChargeWording = GetClauseWording(0, vPricingPolicyID, vClauseName);
	-- Salma Modified on 12-2-2015 -- added vTechnicalConsultantWording and vOvertimeWording 
	SET vTechnicalConsultantWording = IFNULL(GetClauseWording(0, vPricingPolicyID, 'TechnicalConsultantWording'), '');
	IF (vTechnicalConsultantWording NOT LIKE '')
    then
		SET vTechnicalConsultantWording = REPLACE(vTechnicalConsultantWording, '#', CONVERT( CAST(vCalculatedNoOfWorkingDays AS signed), CHAR(100)));
    end if;
    
	SET vOvertimeWording = IFNULL(GetClauseWording(0, vPricingPolicyID, 'OvertimeWording'), '');
	IF (vOvertimeWording NOT LIKE '')
    then
		SET vOvertimeWording = REPLACE(vOvertimeWording, '$', vPricingPolicySymbol);
    end if;
	-- Salma: Modified in 7-12-2014 added if condition to show the clause only when there's Rolling Service Door Product
	IF (
			SELECT GetQuoteItemsCountByItemName(pQuoteID, 'Rolling Service Door')
			) > 0
    then
		SET vRollDoorManpower = GetClauseWording(0, NULL, 'RollDoorManpower');
	ELSE
		SET vRollDoorManpower = '';
    end if;
	-- modified by Salma on 26-10-2014-use GuaranteeGeneric in all cases and comment the FabricType dependent clauses--------------------------------------------------------
	-- --Note: vMembraneTypeID = 4 : Means Premium Fabric
	-- IF ((vFabricTypeID = 4) OR (vFabricTypeID = 426)) SET vClauseName = 'GuaranteePrem';
	-- --modified by Salma on 11-12-2013---------------------------------------------------------
	-- ELSEIF ((vFabricTypeID = 3) OR (vFabricTypeID = 425)) SET vClauseName = 'GuaranteeLTA';
	-- ELSE SET vClauseName = 'GuaranteeReg';
	-- SET vGuaranteeClause = IFNULL(GetClauseWording(0, vPricingPolicyID, vClauseName),'') ;
	SET vClauseName = 'GuaranteeGeneric';
	SET vGuaranteeClause = IFNULL(GetClauseWording(0, NULL, vClauseName), '');
	-- Both CarneTitle and CraneWording currently have same values to All pricing policies, so I pass PricingPolicyID = 1 as fixed value
	-- Salma modified in 25-12-2014 pass PolicyId as NULL since it is generic
	IF (vStructureWidth <= 50)
    then
		SET vClauseName = 'CraneTitle1';
	ELSE
		SET vClauseName = 'CraneTitle2';
    end if;
    
	SET vCraneTitle = GetClauseWording(0, NULL, vClauseName);
	IF (vStructureWidth <= 50)
    then
		SET vClauseName = 'CraneWording1';
	ELSE
		SET vClauseName = 'CraneWording2';
    end if;
    
	SET vCraneWording = GetClauseWording(0, NULL, vClauseName);
	-- - Salma: Just Modified in 5-6-2014 adding ElectricalAcessories clause Condition
	-- -set clause value only if Quotes items that have IsElectric property=1 exists -- -------------
	IF (
			SELECT COUNT(*)
			FROM QuotesItems
			INNER JOIN ProductsPropertiesValues ON QuotesItems.ProductID = ProductsPropertiesValues.ProductID
			WHERE (
					ProductsPropertiesValues.PropertyID = 107
					AND ProductsPropertiesValues.PropertyValueID = 504
					)
				AND QuotesItems.QuoteID = pQuoteID
			) > 0
	then
		SET vElectricalAccessories = GetClauseWording(0, NULL, 'ElectricalAccessories');
		-- Salma--added on 19-1-2015---to get count of clauses for accessories
		SET vAccessoriesClausesCombined = vAccessoriesClausesCombined + 1;
	
	ELSE
		SET vElectricalAccessories = '';
    end if;
	-- -----------------------------------------------------------------
	-- -----------------------Some Properties values--------------------
	SET vMembraneLinerColor = IFNULL(GetPropertyValue(vMembraneLinerColorID), ' ');
	SET vMembraneType = IFNULL(GetPropertyValue(vMembraneTypeID), ' ');
	SET vFabricType = IFNULL(GetPropertyValue(vFabricTypeID), ' ');
	SET vMembraneColor = IFNULL(GetPropertyValue(vMembraneColorID), ' ');
	SET vAnchorage = IFNULL(GetPropertyValue(vAnchorageID), ' ');
	SET vExposure = IFNULL(GetPropertyValue(vExposureID), ' ');
	-- -----------------------------------------------------------------
	-- --------------- Anchorage Wording -- -------------------
	-- ------------ Updated in 08/12/2011 -- ------------------
	-- SELECT vAluminumBarID = ProductID
	-- FROM QuotesItems
	-- WHERE (QuoteID = pQuoteID) AND (ProductID = 23)
	-- IF vAnchorageID IN (58, 59) AND (vAluminumBarID IS NULL) SET vClauseName = 'AnchoragePinsEA';
	-- ELSEIF vAnchorageID IN (58, 59) AND (vAluminumBarID IS NOT NULL) SET vClauseName = 'AnchoragePinsEAPA';
	-- ELSEIF vAnchorageID = 60 SET vClauseName = 'AnchorageConcrete';
	-- ELSEIF vAnchorageID = 61 SET vClauseName = 'AnchorageConcreteEx';
	IF vAnchorage = 'Earth'
    then
		SET vClauseName = 'AnchoragePinsEA';
	ELSEIF vAnchorage = 'Asphalt'
    then
		SET vClauseName = 'AnchoragePinsEAPA'; -- 'AnchoragePinsPA';
	ELSEIF vAnchorage = 'Concrete'
    then
		SET vClauseName = 'AnchorageConcrete';
	ELSEIF vAnchorage = 'Concrete Exists'
    then
		SET vClauseName = 'AnchorageConcreteEx';
			-- Modified by Salma on 28-4-2013 -- -to add Balast Weights clause-----------------
	ELSEIF vAnchorage = 'Ballast Weights'
    then
		SET vClauseName = 'AnchorageBallastWeights';
	ELSE
		SET vClauseName = '';
    end if;
	SET vAnchorageWording = IFNULL(GetClauseWording(0, NULL, vClauseName), '');
	-- ------------------------------------------------------
	-- -----------LeasAUnder12Months Wording-----------------
	-- -----------Salma: Updated in 21/2/2013----------------
	IF (
			vLeaseTermAID >= 1
			AND vLeaseTermAID < 12
			)
	then
		SET vClauseName = 'LeaseAUnder12Months';
		SET vLeaseAUnder12Months = GetClauseWording(0, NULL, vClauseName);
		SET vLeaseAUnder12Months = REPLACE(vLeaseAUnder12Months, '#LEASE#', vLeaseTermAID);
		SET vLeaseAUnder12Months = REPLACE(vLeaseAUnder12Months, '$', concat(vPricingPolicySymbol , CONVERT( CAST((vStructureWidth * vStructureLength * GetProductPriceForCertainPurchase(vStructureID, vPricingPolicyID, 5)) AS DECIMAL(10, 2)), CHAR(100))));
	END if;
	IF (
			vLeaseTermBID >= 1
			AND vLeaseTermBID < 12
			)
	then
		SET vClauseName = 'LeaseBUnder12Months';
		SET vLeaseBUnder12Months = GetClauseWording(0, NULL, vClauseName);
		SET vLeaseBUnder12Months = REPLACE(vLeaseBUnder12Months, '#LEASE#', vLeaseTermBID);
		SET vLeaseBUnder12Months = concat(REPLACE(vLeaseBUnder12Months, '$', vPricingPolicySymbol) , CONVERT(CAST((vStructureWidth * vStructureLength * GetProductPriceForCertainPurchase(vStructureID, vPricingPolicyID, 5)) AS DECIMAL(10, 2)), CHAR(100)));
	END if;
	-- ------------------------------------------------------
	-- -----------Salma: Modified in 21/2/2013---------------
	IF (vFax LIKE '')
	then
		SET vFax = NULL;
	END if;
	IF (vPhoneNo LIKE '')
	then
		SET vPhoneNo = NULL;
	END if;
	-- Salma -- modified on 2-6-2014-- snowload condition----	
	IF (
			(
				vStructureWidth = 30
				OR vStructureWidth = 40
				OR vStructureWidth = 50
				)
			AND vIsSnowLoad = 1
			)
	then
		SET vCenterBaySpacing = GetProductPropertyValue(vStructureID, 30); -- DefaultCenterBaySpacing;
		IF (vCenterBaySpacing = 15)
			-- Salma -- modified on 15-1-2015-- snowload wording----	
		then
			IF (vStructureWidth = 30)
            then
				SET vSnowLoadExpression = concat(CONVERT(CAST(vSnowLoad AS decimal), CHAR(100)) , ' (snowload in excess of 30-40 LBS)'); -- +' (snowload in excess of 45 PSF)';
			ELSEIF (vStructureWidth = 40)
            then
                SET vSnowLoadExpression = concat(CONVERT(CAST(vSnowLoad AS decimal), CHAR(100)) , ' (snowload in excess of 40-24 LBS)'); -- +' (snowload in excess of 25 PSF)';
			ELSEIF (vStructureWidth = 50)
            then
				SET vSnowLoadExpression = concat(CONVERT(CAST(vSnowLoad AS decimal), CHAR(100)) , ' (snowload in excess of 50-19 LBS)'); -- +' (snowload in excess of 20 PSF)';
            end if;
		ELSE
			SET vSnowLoadExpression = CONVERT(CAST(vSnowLoad AS decimal), CHAR(100));
        end if;
	ELSE
		SET vSnowLoadExpression = CONVERT(CAST(vSnowLoad AS decimal), CHAR(100));
    end if;
	-- Salma: added on 12-2-2012 to show Inc or Ltd in signature depending on structure width
	IF (vPricingPolicyID = 3) -- International
	then
		IF (vStructureWidth <= 90)
        then
			SET vCompanySignature = 'LTD.';
        end if;
		IF (vStructureWidth >= 100)
        then
			SET vCompanySignature = 'INC.';
        end if;
	ELSE
		SET vCompanySignature = 'INC.';
	END if;
	-- ------------------------------------------------------ 
	-- salma modified in 15-6-2014 show date
	SET vTheDate = concat(DATE_FORMAT(CURDATE(), '%M') , RIGHT(CONVERT(CURDATE(), CHAR(12)), 9)) ;-- CONVERT(VARCHAR, CURDATE(), 107) -- DATEADD(day, DATEDIFF(day, 0, CURDATE()), 0);
		-- -------------------------------------------------------
	-- Salma added in 7-1-2015 to get the introduction paragraph
	SET vAboutSprung = IFNULL(GetClauseWording(0, NULL, 'AboutSprung'), ' ');
	INSERT into GetQuoteReport_t
	values (pQuoteID
		,vTheDate
		,vModifyAccountID
		,IFNULL(vModifyAccountName, ' ')
		,vCompanyID
		,IFNULL(vCompany, NULL)
		,IFNULL(vCompanyHeader, NULL)
		,IFNULL(vAddress, ' ')
		,IFNULL(vAddress2, ' ')
		,IFNULL(vCity, ' ')
		,IFNULL(vState, ' ')
		,IFNULL(vCountry, ' ')
		,IFNULL(vZip, ' ')
		,IFNULL(vPhoneNo, ' ')
		,IFNULL(vFax, ' ')
		,IFNULL(vEmail, ' ')
		,vAttentionID
		,IFNULL(vAttention, ' ')
		,IFNULL(vLastName, ' ')
		,vSalesRepID
		,IFNULL(vSalesRep, ' ')
		,vLeadOriginID
		,IFNULL(vLeadOrigin, NULL)
		,vPurchaseTerritoryID
		,IFNULL(vPurchaseTerritory, NULL)
		,vLandingTerritoryID
		,IFNULL(vLandingTerritory, NULL)
		,vLocationID
		,IFNULL(vLocation, NULL)
		,IFNULL(vBuiltCode, NULL)
		,vApplicationID
		,IFNULL(vApplicationName, NULL)
		,vPricingPolicyID
		,IFNULL(vPricingPolicy, NULL)
		,IFNULL(vPricingPolicySymbol, '$')
		,IFNULL(vLeaseTermAID, 0)
		,IFNULL(vLeaseTermBID, 0)
		,CASE vIsExport
			WHEN 1
				THEN 'YES'
			ELSE 'NO'
			END
		,CASE vIsMiddleEast
			WHEN 1
				THEN 'YES'
			ELSE 'NO'
			END
		,concat(CAST(vQuoteDuration AS CHAR(15)) , ' days')
		,vNoOfTechConsultants
		,vCompletedByAccountID
		,IFNULL(vCompletedByAccountName, ' ')
		,
		-- Salma modified in 21-12-2014 added the rest of the needed data for BDM
		IFNULL(vCompletedByTitle, ' ')
		,IFNULL(vCompletedByInitials, ' ')
		,
		-- Salma modified in 9-2-2015 added email for BDM
		IFNULL(vCompletedByEmail, ' ')
		,vTypedByAccountID
		,IFNULL(vTypedByAccountName, ' ')
		,IFNULL(vUsage, ' ')
		,IFNULL(vPolicies, ' ')
		,IFNULL(vGuarantee, ' ')
		,CASE vInPersonMeeting
			WHEN 1
				THEN 'YES'
			ELSE 'NO'
			END
		,CASE vMailClient
			WHEN 1
				THEN 'YES'
			ELSE 'NO'
			END
		,CASE vMailRep
			WHEN 1
				THEN 'YES'
			ELSE 'NO'
			END
		,CASE vFaxClient
			WHEN 1
				THEN 'YES'
			ELSE 'NO'
			END
		,CASE vFaxRep
			WHEN 1
				THEN 'YES'
			ELSE 'NO'
			END
		,CASE vBrochures
			WHEN 1
				THEN 'YES'
			ELSE 'NO'
			END
		,vStructureID
		,vStructureWidth
		,vStructureLength
		,vSize
		,CONVERT(CAST(vStructureSQFT AS DECIMAL(10, 2)), CHAR(15))
		,vStandardCenterBaySpacing
		,vStructureStandardLength
		,CONVERT(CAST(vStructureStandardSQFT AS DECIMAL(10, 2)), CHAR(15))
		,vSQFTPerDay
		,vInsulationTypeID
		,vInsulationThicknessID
		,vMembraneLinerColorID
		,vMembraneLinerColor
		,vMembraneTypeID
		,vMembraneType
		,
		-- Salma : modified in 27-3-2014 added FabricType
		vFabricTypeID
		,vFabricType
		,vMembraneColorID
		,vMembraneColor
		,vAnchorageID
		,vAnchorage
		,vExposureID
		,vExposure
		,vNoOfCraneBreakPoints
		,vWindRate
		,vSnowLoad
		,
		-- Salma : modified in 2-6-2014 added snowload condition
		vIsSnowLoad
		,vSnowLoadExpression
		,vAluminumBarID
		,IFNULL(CONVERT(vStructureCustomLeaseTermAPrice, CHAR(30)), ' ')
		,IFNULL(CONVERT(vStructureCustomLeaseTermBPrice, CHAR(30)), ' ')
		,IFNULL(CONVERT(vStructureCustomSalePrice, CHAR(30)), ' ')
		,IFNULL(CONVERT(vStructureExtendedLeaseTermAPrice, CHAR(30)), ' ')
		,IFNULL(CONVERT(vStructureExtendedLeaseTermBPrice, CHAR(30)), ' ')
		,IFNULL(CONVERT(vStructureExtendedSalePrice, CHAR(30)), ' ')
		,IFNULL(CONVERT(vOptionsLeaseTermAPrice, CHAR(30)), ' ')
		,IFNULL(CONVERT(vOptionsLeaseTermBPrice, CHAR(30)), ' ')
		,IFNULL(CONVERT(vOptionsSalePrice, CHAR(30)), ' ')
		,IFNULL(CONVERT(vTotalLeaseTermAPrice, CHAR(30)), ' ')
		,IFNULL(CONVERT(vTotalLeaseTermBPrice, CHAR(30)), ' ')
		,IFNULL(CONVERT(vTotalSalePrice, CHAR(30)), ' ')
		,IFNULL(CONVERT(vMonthlyA, CHAR(30)), ' ')
		,IFNULL(CONVERT(vMonthlyB, CHAR(30)), ' ')
		,IFNULL(CONVERT(vWithOrder, CHAR(30)), ' ')
		,IFNULL(CONVERT(vFinalTotalLeaseTermAPrice, CHAR(30)), ' ')
		,IFNULL(CONVERT(vFinalTotalLeaseTermBPrice, CHAR(30)), ' ')
		,IFNULL(CONVERT(vFinalTotalSalePrice, CHAR(30)), ' ')
		,vMonthlyAWord
		,vMonthlyBWord
		,vFinalTotalSalePriceWord
		,vTotalManhours
		,vNoOfWorkers
		,vNoOfWorkingDays
		,vCalculatedNoOfWorkers
		,vCalculatedNoOfWorkingDays
		,vCraneSize
		,vCraneHours
		,vManLifts
		,CONVERT(vFabricContaminationCost, CHAR(30))
		,CONVERT(vFrieghtCost, CHAR(30))
		,CONVERT(vTechCost, CHAR(30))
		,CONVERT(vLoadsCount, CHAR(30))
		,vClauseName
		,vDeliveryWording
		,vAnchorageWording
		,vEngWording
		,IFNULL(CONVERT(vFOBClause, CHAR(21844) CHARSET utf8), '')
		,vOptionClause
		,IFNULL(CONVERT(vOptionClause3, CHAR(21844) CHARSET utf8), '')
		,IFNULL(CONVERT(vOptionClause12, CHAR(21844) CHARSET utf8), '')
		,IFNULL(CONVERT(vOptionClause24, CHAR(21844) CHARSET utf8), '')
		,IFNULL(CONVERT(vOptionClause36, CHAR(21844) CHARSET utf8), '')
		,IFNULL(CONVERT(vOptionClause48, CHAR(21844) CHARSET utf8), '')
		,IFNULL(CONVERT(vOptionClause60, CHAR(21844) CHARSET utf8), '')
		,IFNULL(CONVERT(vTwoMonthlyPeriods, CHAR(21844) CHARSET utf8), '')
		,IFNULL(CONVERT(vMoreThanTwoMonthlyPeriods, CHAR(21844) CHARSET utf8), '')
		,IFNULL(CONVERT(vExtrasFOBClause, CHAR(21844) CHARSET utf8), '')
		,vAccessoryClause
		,IFNULL(CONVERT(vVentilationInsClause, CHAR(21844) CHARSET utf8), '')
		,IFNULL(CONVERT(vVentilationClause, CHAR(21844) CHARSET utf8), '')
		,IFNULL(CONVERT(vCraneLiftingHooks, CHAR(21844) CHARSET utf8), '')
		,IFNULL(CONVERT(vCargoDoorsESDSSD, CHAR(21844) CHARSET utf8), '')
		,IFNULL(CONVERT(vOpaqueFabricClause, CHAR(21844) CHARSET utf8), '')
		,IFNULL(CONVERT(vRollingServiceDoorsInAccessoryClause, CHAR(21844) CHARSET utf8), '')
		,vLeaseTermA24Clause
		,vLeaseTermB24Clause
		,
		-- Modified by salma on 18 -8-2014 to be used in the certificate section
		vCertificateMembraneClause
		,vCertificateMembraneText
		,vCertificateMembraneText1
		,vStructureEnvironmentalOrApplication
		,IFNULL(CONVERT(vToolClause, CHAR(21844) CHARSET utf8), '')
		,IFNULL(CONVERT(vEnviroHeading, CHAR(21844) CHARSET utf8), '')
		,IFNULL(CONVERT(vContamination, CHAR(21844) CHARSET utf8), '')
		,IFNULL(CONVERT(vContamination1, CHAR(21844) CHARSET utf8), '')
		,IFNULL(CONVERT(vContamination2, CHAR(21844) CHARSET utf8), '')
		,IFNULL(CONVERT(vTechWording, CHAR(21844) CHARSET utf8), '')
		,IFNULL(CONVERT(vTechChargeWording, CHAR(21844) CHARSET utf8), '')
		,vTechnicalConsultantWording
		,vOvertimeWording
		,IFNULL(CONVERT(vRollDoorManpower, CHAR(21844) CHARSET utf8), '')
		,vGuaranteeClause
		,vCraneTitle
		,vCraneWording
		,vBranch
		,IFNULL(CONVERT(vLeaseAUnder12Months, CHAR(21844) CHARSET utf8), '')
		,IFNULL(CONVERT(vLeaseBUnder12Months, CHAR(21844) CHARSET utf8), '')
		,vElectricalAccessories
		,IFNULL(CONVERT(vTerritoryAddress, CHAR(21844) CHARSET utf8), ' ')
		,IFNULL(CONVERT(vTerritoryPhone, CHAR(21844) CHARSET utf8), ' ')
		,vCreatorTerritory
		,vCompanySignature
		,
		-- Salma: added on 4-12-2014 get TermsPurchaseClause based on PricingPolicyID
		vTermsPurchaseClause
		,
		-- Salma: added on 7-12-2014 get DeliveryClause based on PricingPolicyID
		vDeliveryClause
		,vAboutSprung
		,
		-- Salma--added on 19-1-2015---to get count of clauses for accessories
		vAccessoriesClausesCombined);
END;
