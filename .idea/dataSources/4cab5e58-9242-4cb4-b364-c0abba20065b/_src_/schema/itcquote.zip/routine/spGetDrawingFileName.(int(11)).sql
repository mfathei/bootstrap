CREATE PROCEDURE itcquote.spGetDrawingFileName(IN `_DrawingRequestID` INT)
  BEGIN
	SELECT DrawingsFiles.FileName
	FROM DrawingsFiles
	INNER JOIN Drawings ON DrawingsFiles.DrawingID = Drawings.DrawingID
	INNER JOIN DrawingRequests ON Drawings.DrawingRequestID = DrawingRequests.DrawingRequestID
	WHERE (DrawingRequests.DrawingRequestID = _DrawingRequestID);
END;
