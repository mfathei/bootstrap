CREATE PROCEDURE itcquote.GetTransportationCosts(IN pQuoteID         INT, IN pStructureID INT, IN pStructureSQFT FLOAT,
                                                 IN pLocationID      INT, IN pNoOfTechConsultants INT,
                                                 IN pNoOfWorkingDays INT)
  BEGIN
	DECLARE vPricingPolicyID int;
	DECLARE vFrieghtCost DECIMAL(10, 2);
	DECLARE vTechCost DECIMAL(10, 2);
	DECLARE vHalfLoadCharge DECIMAL(10, 2);
	DECLARE vFullLoadCharge DECIMAL(10, 2);
	DECLARE vAirFareCharge DECIMAL(10, 2);
	DECLARE vToolsReturnCharge DECIMAL(10, 2);
		-- Salma-- Modified on 29-12-2014 -- added AltAirfareCharge and DangerPay
	DECLARE vAltAirFareCharge DECIMAL(10, 2);
	DECLARE vDangerPay DECIMAL(10, 2);
	DECLARE vHalfTruck FLOAT;
	DECLARE vFullTruck FLOAT;
	DECLARE vAreaWeightsLoadsCount INT;
	DECLARE vItemsLoadsCount INT;
		-- Salma-- modified in 17-6-2014-- made LoadsCount float instead of int
	DECLARE vLoadsCount FLOAT;
	DECLARE vTechChargePerDiem DECIMAL(10, 2);
		-- Salma-- modified in 2-6-2014-- added count >14 then extrafrieght=1
	DECLARE vCountItems INT;
	DECLARE vExtraFrieght INT default 0;
		-- -Salma -- Modified in 5-6-2014-- added the calcualtion for load counts in insulation
	DECLARE vStructureWidth INT;
	DECLARE vInsulationTypeID INT;
	DECLARE vIsInsulated BIT;
	DECLARE vSqftPerLoad INT;
		-- Salma -- Modified in 10-11-2014 use "Unit Area Weight Insulated":109 if insulated else use "Unit Area Weight":3
	DECLARE vUnitAreaPropertyID INT default 3;
		-- Salma -- Modified in 24-12-2014 using BeamSize to determine FullTruck value
	DECLARE vBeamSize VARCHAR(50);
		-- Salma modified in 29-1-2015 add the calculation of weight of related products
	DECLARE vweightRelated FLOAT;
	DECLARE vAreaWeights FLOAT;
    drop temporary table if exists GetTransportationCosts_t;
    create temporary table GetTransportationCosts_t(
        AreaWeightsLoadsCount INT
        ,ItemsLoadsCount INT
        ,FrieghtCost DECIMAL(10, 2)
        ,TechCost DECIMAL(10, 2)
	);
	-- ---------------------------- Retrieve Information From DB -- -------------- 	
	SELECT PricingPolicyID into vPricingPolicyID 
	FROM Quotes
	WHERE (QuoteID = pQuoteID);
	-- -Salma -- Modified in 5-6-2014-- added the calcualtion for load counts in insulation
	SET vStructureWidth = GetProductPropertyValue_Int(pStructureID, 6);
	SELECT InsulationTypeID into vInsulationTypeID 
	FROM Quotes
	WHERE QuoteID = pQuoteID;
	SET vIsInsulated = IsInsulated(vInsulationTypeID);
	-- Salma -- Modified in 24-12-2014 using BeamSize to determine FullTruck value
	SET vBeamSize = GetProductPropertyValue(pStructureID, 106); -- beamSize;
	-- Salma -- Modified in 10-11-2014 use "Unit Area Weight Insulated" if insulated else use "Unit Area Weight"
	IF (vIsInsulated = 1)
	then
		SET vUnitAreaPropertyID = 109;
	
	ELSE
	
		SET vUnitAreaPropertyID = 3;
	END if;
	-- ---------------------------- Constants and Initializations -- -------------- 
	SET vHalfTruck = GetPropertyValue(147); -- This is a system constant which is currently set to 20000;
		-- SET vFullTruck = 2.0 * vHalfTruck  -- It is better to be a system constant same as HalfTruck;
	SET vFullTruck = 35000.0; -- According to Ross's email on 2010_05_31, where Trailer load is 35000 lbs;
	-- Salma -- Modified in 24-12-2014 using BeamSize to determine FullTruck value
	-- Salma -- Modified in 12-1-2015 changed the value from 20000 to 34000 and commented beam size condition
	IF (vPricingPolicyID = 3) -- AND vBeamSize like '8'''' x 12''''')--International and 8" x 12"
	then
		SET vFullTruck = 34000.0; -- According to Ross's email on 2015_01_12, where Trailer load is 34000 lbs    -- 20000.0;
	END if;
	-- Salma -- Modified in 05-02-2015 changed the value from 35000 to 40000 in case of INC and LTD
	-- Salma -- Modified in 15-02-2015 changed the value from 35000 to 40000 in case of GSA
	IF (
			vPricingPolicyID = 1
			OR vPricingPolicyID = 16
			OR vPricingPolicyID = 2
			) -- INC, GSA or LTD
	then
		SET vFullTruck = 40000.0;
	END if;
	-- SET vToolsReturnCharge = 500.0 -- This is a constant for tools return cost;
	SET vToolsReturnCharge = 1000.0; -- This is a constant for tools return cost;
	IF vPricingPolicyID = 4
    then
		SET vTechChargePerDiem = CAST(GetPropertyValue(423) AS DECIMAL(10, 2)); -- For Bahrain Pricing Policy (700$);
			-- Salma: Modified on 29-12-2014--- added the constant for international
	ELSEIF vPricingPolicyID = 3
    then
		SET vTechChargePerDiem = CAST(250 AS DECIMAL(10, 2)); -- For International;
	ELSE
		SET vTechChargePerDiem = CAST(GetPropertyValue(148) AS DECIMAL(10, 2)); -- For other Pricing Policies (305$);
    end if;
	-- ---------------------------- Calculates Frieghts cost -- -------------- 
	SELECT CEILING(SUM(QI.Quantity * CAST(PV.TheValue AS DECIMAL))) into vAreaWeights -- / vFullTruck)
	FROM QuotesItems AS QI
	INNER JOIN ProductsPropertiesValues AS PPV ON QI.ProductID = PPV.ProductID
	INNER JOIN PropertiesValues AS PV ON PPV.PropertyValueID = PV.PropertyValueID
	WHERE (QI.QuoteID = pQuoteID)
		AND (PPV.PropertyID = vUnitAreaPropertyID); -- Unit Area Weight (PropertyID = 3) 
	SET vAreaWeights = IFNULL(vAreaWeights, 0.00);
	-- Salma added in 29-1-2015-- the calcualtion for weight in related products
	SELECT CEILING(SUM(weightRelated)) into vweightRelated -- /vFullTruck)
	FROM (
		SELECT IFNULL(SUM(QI.InteriorDoorQuantity * CAST(PVInterior.TheValue AS decimal)), 0) AS weightRelated
		FROM RelatedProducts AS QI
		INNER JOIN ProductsPropertiesValues AS PPVInterior ON QI.InteriorDoor = PPVInterior.ProductID
		INNER JOIN PropertiesValues AS PVInterior ON PPVInterior.PropertyValueID = PVInterior.PropertyValueID
		WHERE (QI.QuoteID = pQuoteID)
			AND (PPVInterior.PropertyID = vUnitAreaPropertyID)
		
		UNION ALL
		
		SELECT IFNULL(SUM(QI.ExteriorDoorQuantity * CAST(PVExterior.TheValue AS decimal)), 0) AS weightRelated
		FROM RelatedProducts AS QI
		INNER JOIN ProductsPropertiesValues AS PPVExterior ON QI.ExteriorDoor = PPVExterior.ProductID
		INNER JOIN PropertiesValues AS PVExterior ON PPVExterior.PropertyValueID = PVExterior.PropertyValueID
		WHERE (QI.QuoteID = pQuoteID)
			AND (PPVExterior.PropertyID = vUnitAreaPropertyID)
		
		UNION ALL
		
		SELECT IFNULL(SUM(QI.WindowQuantity * CAST(PVWindow.TheValue AS decimal)), 0) AS weightRelated
		FROM RelatedProducts AS QI
		INNER JOIN ProductsPropertiesValues AS PPVWindow ON QI.Window = PPVWindow.ProductID
		INNER JOIN PropertiesValues AS PVWindow ON PPVWindow.PropertyValueID = PVWindow.PropertyValueID
		WHERE (QI.QuoteID = pQuoteID)
			AND (PPVWindow.PropertyID = vUnitAreaPropertyID)
		
		UNION ALL
		
		SELECT IFNULL(SUM(1 * CAST(PVLogo.TheValue AS decimal)), 0) AS weightRelated
		FROM RelatedProducts AS QI
		INNER JOIN ProductsPropertiesValues AS PPVLogo ON QI.Logo = PPVLogo.ProductID
		INNER JOIN PropertiesValues AS PVLogo ON PPVLogo.PropertyValueID = PVLogo.PropertyValueID
		WHERE (QI.QuoteID = pQuoteID)
			AND (PPVLogo.PropertyID = vUnitAreaPropertyID)
		) as w;
	SET vweightRelated = IFNULL(vweightRelated, 0.00);
	-- Salma -- Modified in 08-03-2015 changed CEILING to Round and added 0.35 in case of INC, GSA or LTD
	IF (
			vPricingPolicyID = 1
			OR vPricingPolicyID = 16
			OR vPricingPolicyID = 2
			) -- INC, GSA or LTD
	then
		SET vAreaWeightsLoadsCount = Round((((vAreaWeights + vweightRelated) / vFullTruck) + 0.35), 0);
	
	ELSE
	
		SET vAreaWeightsLoadsCount = CEILING((vAreaWeights + vweightRelated) / vFullTruck);
	END if;
	SELECT SUM(CEILING(QI.Quantity * CAST(PV.TheValue AS decimal))) into vItemsLoadsCount  -- change int to Float--
	FROM QuotesItems AS QI
	INNER JOIN ProductsPropertiesValues AS PPV ON QI.ProductID = PPV.ProductID
	INNER JOIN PropertiesValues AS PV ON PPV.PropertyValueID = PV.PropertyValueID
	WHERE (QI.QuoteID = pQuoteID)
		AND (PPV.PropertyID = 73); -- LoadsCount (PropertyID = 73) 
	SET vItemsLoadsCount = Round(IFNULL(vItemsLoadsCount, 0), 0); -- Round the ItemsLoadsCount to integer after calculation --;
	SET vLoadsCount = vAreaWeightsLoadsCount + vItemsLoadsCount;
	SELECT  HalfLoadCharge
		, FullLoadCharge
		, AirfareCharge
		, AltAirfareCharge
		, DangerPay
        into
        vHalfLoadCharge,
        vFullLoadCharge,
        vAirFareCharge,
        vAltAirFareCharge,
        vDangerPay
	FROM Locations
	WHERE (LocationID = pLocationID);
	-- Salma-- modified in 2-6-2014-- added count >14 then extrafrieght=1
	-- Salma-- modified in 1-9-2014-- added count >18 then extrafrieght=1
	-- Salma -- Modified in 09-1-2015--excluded default items from count
	-- Salma -- Modified in 28-1-2015--commented the extra load code
	-- SELECT vCountItems=COUNT(*) from QuotesItems where QuoteID=pQuoteID AND IsAutoAdded<>1
	-- IF(vCountItems>18)
	-- BEGIN
	--	SET vExtraFrieght=1;
	--	SET vLoadsCount=vLoadsCount+vExtraFrieght;
	-- END
	-- Salma -- Modified in 29-1-2015--added new condition for the extra load 
	IF (
			vIsInsulated = 1
			AND pStructureSQFT > 2500
			AND pStructureSQFT < 5000
			AND vLoadsCount = 1
			)
	then
		SET vExtraFrieght = 1;
		SET vLoadsCount = vLoadsCount + vExtraFrieght;
		-- Salma modified in 11-2-2015 added the extra frieght to AreaWeightsLoadsCount to be shown correctly in Quote Report
		SET vAreaWeightsLoadsCount = vAreaWeightsLoadsCount + vExtraFrieght;
	END if;
	-- IF(vIsInsulated=1)
	-- BEGIN
	--	SET vSqftPerLoad=GetProductPropertyValue_Int(pStructureID, 114)
	--	IF(vSqftPerLoad>0 AND pStructureSQFT <= vSqftPerLoad)
	--	BEGIN
	--		-- SET vLoadsCount=vLoadsCount+1
	--		SET vLoadsCount=1
	--	END
	--	ELSE
	--		IF(vSqftPerLoad>0 AND pStructureSQFT> vSqftPerLoad)
	--		BEGIN
	--			-- SET vLoadsCount=vLoadsCount+(pStructureSQFT/vSqftPerLoad)
	--			SET vLoadsCount=pStructureSQFT/vSqftPerLoad
	--		END
	--	SET vLoadsCount=vLoadsCount+(pStructureSQFT/13000)
	--	SET vLoadsCount=vLoadsCount+0.5
	--	SET vLoadsCount=Round(vLoadsCount,0)
	-- END
	-- Salma Modified on 23-3-2015 freight and tech =0 if shipping is to Calgray or Salt Lake
	SET vFrieghtCost = vFullLoadCharge * vLoadsCount + vToolsReturnCharge;
	SET vFrieghtCost = ROUND(vFrieghtCost, - 1);
	SET vFrieghtCost = IFNULL(vFrieghtCost, 0);
	-- ------------------------ Claculates Tech. Cost -- -----------------------
	-- -modified by salma--20-5-2014-- added no of weeks calculation for Tech cost------------
	IF (pNoOfWorkingDays <= 5)
    then
		SET pNoOfWorkingDays = pNoOfWorkingDays + 1;
	ELSEIF (pNoOfWorkingDays > 5)
		AND (pNoOfWorkingDays <= 10)
    then
		SET pNoOfWorkingDays = pNoOfWorkingDays + 2;
	ELSEIF (pNoOfWorkingDays > 10)
    then
		SET pNoOfWorkingDays = pNoOfWorkingDays + (2 * ROUND(pNoOfWorkingDays / 5.0, 0));
    end if;
	-- Salma -- Modified on 29-12-2014--added the condition for AltAirfareCharge and DangerPay depending on Policy
	IF (vPricingPolicyID = 4) -- Bahrain
	then
		SET vTechCost = pNoOfTechConsultants * (pNoOfWorkingDays * (vTechChargePerDiem + vDangerPay) + vAltAirFareCharge);
	
	ELSE
	
		SET vTechCost = pNoOfTechConsultants * (pNoOfWorkingDays * (vTechChargePerDiem + vDangerPay) + vAirFareCharge);
	END if;
	-- SET vTechCost = pNoOfTechConsultants * (pNoOfWorkingDays*vTechChargePerDiem + vAirFareCharge);
	SET vTechCost = ROUND(vTechCost, - 1);
	SET vTechCost = IFNULL(vTechCost, 0);
	-- ----------------------------------------------------------------------------------------------
	-- Salma Modified on 23-3-2015 freight and tech =0 if shipping is to Calgray or Salt Lake
	IF (
			pLocationID = 332
			OR pLocationID = 194
			)
	then
		SET vFrieghtCost = 0;
		SET vTechCost = 0;
	END if;
	-- -------- Fill the table variable with the rows for your result set -- -------------------------
	INSERT into GetTransportationCosts_t
	values(vAreaWeightsLoadsCount
		,vItemsLoadsCount
		,vFrieghtCost
	    ,vTechCost);
END;
