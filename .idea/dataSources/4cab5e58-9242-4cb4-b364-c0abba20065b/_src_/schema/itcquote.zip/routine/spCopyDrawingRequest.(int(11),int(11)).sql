CREATE PROCEDURE itcquote.spCopyDrawingRequest(IN `_DrawingRequestID` INT, IN `_CreateAccountID` INT)
  BEGIN		
 Declare _ID int;
 drop TEMPORARY TABLE if exists  _tempTable;
 create TEMPORARY TABLE _tempTable(old_key int, new_key int);
 
 INSERT INTO DrawingRequests(CreateAccountID,CreateDate,AttentionID,CompletedForID,RequestedBy,ScopeID,QuoteID,ReferenceDrawingRequestID,SendToID,SendViaID,DrawingTypeID,
 DrawingCategoryID,DrawingSizeID,DrawingUnitID,DeliveryPoint,RequestedDeliveryDate,IsStamped,NoOfCopies,StatusID,Caption,Comments,CompanyID,
 Address,Address2,City,State,Zip,Telephone,Fax,RepTerritory,StructureLocation,Location,StructureWidth,StructureLength,StructureColor,Anchorage,StructureApplication,ProjectName,
 ApprovedBy,SeriesID,Wind,WindMPH,WindKPH,WindKPA,Snow,Exposure,BlogCode,SalesManager,IsExtraFieldsSaved,MembraneTypeID,IsInsulated,SkyLight,InsulationPackageID)
 Select _CreateAccountID,GETDATE(),AttentionID,CompletedForID,RequestedBy,ScopeID,QuoteID,ReferenceDrawingRequestID,SendToID,SendViaID,DrawingTypeID,
 GetPropertyValueIDByValue_PropertyID(122,'Revision'),DrawingSizeID,DrawingUnitID,DeliveryPoint,RequestedDeliveryDate,IsStamped,NoOfCopies,1,Caption,
 Comments,CompanyID,
 Address,Address2,City,State,Zip,Telephone,Fax,RepTerritory,StructureLocation,Location,StructureWidth,StructureLength,StructureColor,Anchorage,StructureApplication,ProjectName,
 ApprovedBy,SeriesID,Wind,WindMPH,WindKPH,WindKPA,Snow,Exposure,BlogCode,SalesManager,IsExtraFieldsSaved,MembraneTypeID,IsInsulated,SkyLight,InsulationPackageID
 from DrawingRequests
 where DrawingRequestID=_DrawingRequestID;
 
 Set _ID = (SELECT @@IDENTITY);
 
 INSERT INTO FilesVersions(CreateDate,FileContent,FileID,FileTypeID,FileVersion,Notes,VersionCaption)
 SELECT GETDATE(),FileContent,_ID,FileTypeID,FileVersion,Notes,VersionCaption
 from FilesVersions
 where FileID=_DrawingRequestID ;
 
  iNSERT into Drawings (DwgNumber,Customer,Customer1,Width,Length,CreateAccountID,CreateDate,ModifyAccountID,ModifyDate,ScopeID,DrawingRequestID,DrawnByID,DrawnBy,ExpectedDate,ActualDate,
     TerritoryID,SalesPersonID,SalesPerson,City,State,StructureUse,Wind,WindMPH,WindKPH,WindKPA,Snow,DrawingTypeID,StatusID,Caption,Comments) 
 select t2.DwgNumber,t2.Customer,t2.Customer1,t2.Width,t2.Length,_CreateAccountID,GETDATE(),NULL,NULL,t2.ScopeID,_ID,t2.DrawnByID,t2.DrawnBy,t2.ExpectedDate,t2.ActualDate,
     t2.TerritoryID,t2.SalesPersonID,t2.SalesPerson,t2.City,t2.State,t2.StructureUse,t2.Wind,t2.WindMPH,t2.WindKPH,t2.WindKPA,t2.Snow,t2.DrawingTypeID,t2.StatusID,t2.Caption,t2.Comments
	 from   Drawings t2 where t2.DrawingRequestID=_DrawingRequestID
	 ON DUPLICATE KEY  update  DrawingID=t2.DrawingID ; 	
	 insert into _tempTable values(t2.DrawingID,DrawingID);
 INSERT INTO DrawingsFiles(CreateAccountID,CreateDate,DrawingID,FilePath,FileName,FileTypeID,Extention,Caption,IsDeliverable,Comments)
 SELECT _CreateAccountID,GETDATE(),IT.new_key,FilePath,FileName,FileTypeID,Extention,Caption,IsDeliverable,Comments
 FROM DrawingsFiles
 INNER JOIN _tempTable IT ON( IT.old_key = DrawingsFiles.DrawingID);
 SELECT _ID as DrawingRequestID;
end;
