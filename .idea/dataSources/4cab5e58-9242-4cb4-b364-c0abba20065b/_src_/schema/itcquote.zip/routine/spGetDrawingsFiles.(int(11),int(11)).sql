CREATE PROCEDURE itcquote.spGetDrawingsFiles(IN `_AccountID` INT, IN `_TerritoryID` INT)
  BEGIN
DECLARE _IsAdmin bit;
SET _IsAdmin=(select IsAdmin from Accounts Where AccountID=_AccountID);
SELECT     DrawingsFiles.FileID, 
           DrawingsFiles.CreateAccountID, 
           DrawingsFiles.CreateDate, 
           DrawingsFiles.ModifyAccountID,
           DrawingsFiles.ModifyDate, 
           DrawingsFiles.DrawingID, 
           DrawingsFiles.FilePath, 
           DrawingsFiles.FileName, 
           DrawingsFiles.FileTypeID, 
           DrawingsFiles.Extention, 
           DrawingsFiles.Caption, 
           DrawingsFiles.IsDeliverable, 
           DrawingsFiles.Comments
FROM       DrawingsFiles LEFT OUTER JOIN
           Drawings ON  DrawingsFiles.DrawingID = Drawings.DrawingID 
WHERE
        ((Drawings.ScopeID = 1) AND (Drawings.CreateAccountID = _AccountID OR _IsAdmin=1)) OR 
        ((Drawings.ScopeID = 2) AND (Drawings.CreateAccountID IN (SELECT AccountID FROM Accounts WHERE TerritoryID = _TerritoryID) OR _IsAdmin=1)) OR
        ((Drawings.ScopeID IS NULL) ) OR
        ((Drawings.CreateAccountID IS NULL) ) OR
        ((Drawings.ScopeID = 3) );
END;
