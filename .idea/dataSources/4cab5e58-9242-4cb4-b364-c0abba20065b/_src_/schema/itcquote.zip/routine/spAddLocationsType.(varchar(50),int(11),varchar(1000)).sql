CREATE PROCEDURE itcquote.spAddLocationsType(IN `_LocationTypeName` VARCHAR(50), IN `_TreeLevel` INT,
                                             IN `_Description`      VARCHAR(1000), OUT `_LocationTypeID` INT)
  begin
SET _LocationTypeID  = (select MAX(LocationTypeID)+1 from LocationsTypes );
if _TreeLevel=''  then set _TreeLevel =null; end if ;
if _Description=''  then set _Description =null; end if ;  
INSERT  into LocationsTypes
(
   LocationTypeID ,
   LocationTypeName ,
   TreeLevel      , 
   Description     
)
VALUES
(
  _LocationTypeID,
  _LocationTypeName ,
  _TreeLevel , 
  _Description     
);
SELECT _LocationTypeID  as LocationTypeID;
end;
