CREATE PROCEDURE itcquote.spCopyProductPropertiesValues(IN `_SourceProductID` INT, IN `_DestProductID` INT)
  BEGIN
if _SourceProductID ='' or  _SourceProductID is null  then  set  _SourceProductID=0; end if ;
if _DestProductID ='' or  _DestProductID is null  then  set  _DestProductID=0; end if ;
    -- Insert statements for procedure here
  INSERT INTO ProductsPropertiesValues
  (ProductID, ProductTypeID, PropertyID, PropertyValueID)
  SELECT 
  _DestProductID, ProductTypeID, PropertyID, PropertyValueID
  FROM ProductsPropertiesValues 
  WHERE (ProductID = _SourceProductID);
end;
