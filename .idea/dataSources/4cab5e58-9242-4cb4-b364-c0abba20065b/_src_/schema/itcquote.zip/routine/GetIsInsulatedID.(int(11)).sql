CREATE FUNCTION itcquote.GetIsInsulatedID(pInsulationTypeID INT)
  RETURNS INT
  BEGIN
	-- Declare the return variable here
	DECLARE vResult INT;
	-- Add the T-SQL statements to compute the return value here
	IF (pInsulationTypeID = 49) THEN
		SET vResult = 90;
	ELSE
		SET vResult = 91;
    END IF;
	-- Return the result of the function
	RETURN vResult;
END;
