CREATE FUNCTION itcquote.GetNoOfEyeNuts(pStructureWidth INT, pNoOfBeams INT)
  RETURNS INT(6)
  BEGIN
	DECLARE vResult int;
	DECLARE pMultiply int;
	IF (pStructureWidth <= 40) 
	then
		SET pMultiply = 1;
	ELSEIF (
			pStructureWidth >= 50
			AND pStructureWidth <= 90
			) 
	then
		SET pMultiply = 2;
	ELSEIF (pStructureWidth >= 100)
	then
		SET pMultiply = 4;
	ELSE
		SET pMultiply = 4;
	end if;
	SET vResult = pMultiply * pNoOfBeams;
	RETURN IFNULL(vResult, 0);
END;
