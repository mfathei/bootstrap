CREATE PROCEDURE itcquote.spGetDrawingsTable(IN `_DrawID`     INT, IN `_AccountID` INT, IN `_TerritoryID` INT,
                                             IN `_DwgNumber`  VARCHAR(50), IN `_Customer` VARCHAR(150),
                                             IN `_Customer1`  VARCHAR(150), IN `_Width` FLOAT, IN `_Length` FLOAT,
                                             IN `_Comments`   VARCHAR(1000), IN `_Title` VARCHAR(10000),
                                             IN `_StatusID`   INT, IN `_PageNo` INT, IN `_PageSize` INT,
                                             IN `_SortColumn` VARCHAR(20), IN `_SortOrder` VARCHAR(4))
  BEGIN
	/*–Declaring Local Variables corresponding to parameters for modification */
	DECLARE _lPageNbr ,_lPageSize ,_lFirstRec ,_lLastRec ,_lTotalRows int;
	declare _lSortCol NVARCHAR(20);
    DECLARE _IsAdmin BIT;
	DECLARE _StatusGroupID int;
    
    
    if _AccountID is null or _AccountID='' then set _AccountID=0;  end if;
	if _PageNo is null or _PageNo='' then set  _PageNo=1;           end if;
	if _PageSize is null or _PageSize='' then set _PageSize=200 ; end if;
	if _SortColumn is null or _SortColumn='' then set _SortColumn='DrawingID' ; end if;
	if _SortOrder is null or _SortOrder='' then set _SortOrder='Desc' ; end if;
    
    
    /*Setting Local Variables*/
	SET _lPageNbr = _PageNo;
	SET _lPageSize = _PageSize;
	SET _lSortCol = TRIM(_SortColumn);
	SET _lFirstRec = (_lPageNbr - 1) * _lPageSize;
	SET _lLastRec = (_lPageNbr * _lPageSize + 1);
	SET _lTotalRows = _lFirstRec - _lLastRec + 1;
	-- Modified by salma 4-2-2014 make added conditions for Isadmin to allow Admins to view all Quotes even Private
	
	SET _IsAdmin = (
			SELECT IsAdmin
			FROM Accounts
			WHERE AccountID = _AccountID
			);
	--  group status of drawing  from  fnGetStatus
	drop TEMPORARY TABLE if exists	 xx;
    CREATE TEMPORARY TABLE  xx AS (select fnGetStatus(_StatusGroupID) );
	--  group status of drawing requests from  fnGetStatus
SET _StatusGroupID = 1;
drop temporary table if exists CTE_Results;
create temporary table  CTE_Results
	AS (
		SELECT @i:=@i+1 AS ROWNUM, 
			 Count(*)  AS TotalCount
             ,DrawingID
			,DwgNumber
			,Customer
			,Customer1
			,Width
			,Length
			,CreateAccountID
			,CreateDate
			,ModifyAccountID
			,ModifyDate
			,ScopeID
			,DrawingRequestID
			,DrawnByID
			,DrawnBy
			,ExpectedDate
			,ActualDate
			,TerritoryID
			,SalesPersonID
			,SalesPerson
			,City
			,STATE
			,StructureUse
			,Wind
			,Snow
			,DrawingTypeID
			,tbStatus.StatusID
			,StatusName
			,Caption
			,Comments
		FROM   (SELECT @i:=0) AS foo,Drawings
		LEFT  JOIN xx AS tbStatus ON Drawings.StatusID = tbStatus.StatusID
		WHERE (
				(
					(ScopeID = 1)
					AND (
						CreateAccountID = _AccountID
						OR _IsAdmin = 1
						)
					)
				OR (
					(ScopeID = 2)
					AND (
						(
							CreateAccountID IN (
								SELECT AccountID
								FROM Accounts
								WHERE TerritoryID = _TerritoryID
								)
							)
						OR (_IsAdmin = 1)
						)
					)
				OR ((ScopeID IS NULL))
				OR ((CreateAccountID IS NULL))
				OR ((ScopeID = 3))
				)
			AND (
				(
					(
						_DrawID IS NULL
						OR _DrawID = 0
						)
					OR (DrawingRequestID = _DrawID)
					)
				AND (
					_StatusID IS NULL
					OR _StatusID = 0
					OR (Drawings.StatusID = _StatusID)
					)
				AND (
					_Title IS NULL
					OR _Title LIKE ''
					OR (Caption LIKE _Title)
					)
				AND (
					_Customer IS NULL
					OR _Customer LIKE ''
					OR (Customer LIKE _Customer)
					)
				AND (
					_Customer1 IS NULL
					OR _Customer1 LIKE ''
					OR (Customer1 LIKE _Customer1)
					)
				AND (
					_DwgNumber IS NULL
					OR _DwgNumber LIKE ''
					OR (DwgNumber LIKE _DwgNumber)
					)
				AND (
					_Width IS NULL
					OR _Width LIKE ''
					OR (Width = _Width)
					)
				AND (
					_Length IS NULL
					OR _Length LIKE ''
					OR (Length = _Length)
					)
				AND (
					_Comments IS NULL
					OR _Comments LIKE ''
					OR (Comments LIKE _Comments)
					)
				)
	ORDER BY CASE 
						WHEN (
								_lSortCol = 'DrawingID'
								AND _SortOrder = 'ASC'
								)
							THEN DrawingID
						END ASC
					,CASE 
						WHEN (
								_lSortCol = 'DrawingID'
								AND _SortOrder = 'DESC'
								)
							THEN DrawingID
						END DESC
					,CASE 
						WHEN (
								_lSortCol = 'DwgNumber'
								AND _SortOrder = 'ASC'
								)
							THEN DwgNumber
						END ASC
					,CASE 
						WHEN (
								_lSortCol = 'DwgNumber'
								AND _SortOrder = 'DESC'
								)
							THEN DwgNumber
						END DESC
					,CASE 
						WHEN (
								_lSortCol = 'Caption'
								AND _SortOrder = 'ASC'
								)
							THEN Caption
						END ASC
					,CASE 
						WHEN (
								_lSortCol = 'Caption'
								AND _SortOrder = 'DESC'
								)
							THEN Caption
						END DESC
					,CASE 
						WHEN (
								_lSortCol = 'Customer'
								AND _SortOrder = 'ASC'
								)
							THEN Customer
						END ASC
					,CASE 
						WHEN (
								_lSortCol = 'Customer'
								AND _SortOrder = 'DESC'
								)
							THEN Customer
						END DESC
					,CASE 
						WHEN (
								_lSortCol = 'Customer1'
								AND _SortOrder = 'ASC'
								)
							THEN Customer1
						END ASC
					,CASE 
						WHEN (
								_lSortCol = 'Customer1'
								AND _SortOrder = 'DESC'
								)
							THEN Customer1
						END DESC
					,CASE 
						WHEN (
								_lSortCol = 'Width'
								AND _SortOrder = 'ASC'
								)
							THEN Width
						END ASC
					,CASE 
						WHEN (
								_lSortCol = 'Width'
								AND _SortOrder = 'DESC'
								)
							THEN Width
						END DESC
					,CASE 
						WHEN (
								_lSortCol = 'Length'
								AND _SortOrder = 'ASC'
								)
							THEN Length
						END ASC
					,CASE 
						WHEN (
								_lSortCol = 'Length'
								AND _SortOrder = 'DESC'
								)
							THEN Length
						END DESC
					,CASE 
						WHEN (
								_lSortCol = 'Comments'
								AND _SortOrder = 'ASC'
								)
							THEN Comments
						END ASC
					,CASE 
						WHEN (
								_lSortCol = 'Comments'
								AND _SortOrder = 'DESC'
								)
							THEN Comments
						END DESC
					,CASE 
						WHEN (
								_lSortCol = 'ActualDate'
								AND _SortOrder = 'ASC'
								)
							THEN ActualDate
						END ASC
					,CASE 
						WHEN (
								_lSortCol = 'ActualDate'
								AND _SortOrder = 'DESC'
								)
							THEN ActualDate
						END DESC
					,CASE 
						WHEN (
								_lSortCol = 'ExpectedDate'
								AND _SortOrder = 'ASC'
								)
							THEN ExpectedDate
						END ASC
					,CASE 
						WHEN (
								_lSortCol = 'ExpectedDate'
								AND _SortOrder = 'DESC'
								)
							THEN ExpectedDate
						END DESC
					,CASE 
						WHEN (
								_lSortCol = 'StatusName'
								AND _SortOrder = 'ASC'
								)
							THEN StatusName
						END ASC
					,CASE 
						WHEN (
								_lSortCol = 'StatusName'
								AND _SortOrder = 'DESC'
								)
							THEN StatusName
						END DESC
	);
	SELECT TotalCount
		,ROWNUM
		,DrawingID
		,DwgNumber
		,Customer
		,Customer1
		,Width
		,Length
		,CreateAccountID
		,CreateDate
		,ModifyAccountID
		,ModifyDate
		,ScopeID
		,DrawingRequestID
		,DrawnByID
		,DrawnBy
		,ExpectedDate
		,ActualDate
		,TerritoryID
		,SalesPersonID
		,SalesPerson
		,City
		,STATE
		,StructureUse
		,Wind
		,Snow
		,DrawingTypeID
		,StatusID
		,StatusName
		,Caption
		,Comments
	FROM CTE_Results AS CPC
	WHERE ROWNUM > _lFirstRec
		AND ROWNUM < _lLastRec
	ORDER BY ROWNUM ASC;
END;
