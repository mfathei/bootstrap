CREATE FUNCTION itcquote.GetClauseWording(pClauseID INT, pPricingPolicyID INT, pClauseName VARCHAR(50))
  RETURNS VARCHAR(1000)
  BEGIN
	--  Declare the return variable here
	DECLARE vResult VARCHAR(1000);
	--  Add the T-SQL statements to compute the return value here
	IF pClauseID = 0
	then
		IF pPricingPolicyID IS NULL
		then
			SELECT CD.ClauseWording into vResult
			FROM Clauses AS C
			INNER JOIN ClausesDetails AS CD ON C.ClauseID = CD.ClauseID
			WHERE (C.ClauseName = pClauseName);
		
		ELSE
		
			SELECT CD.ClauseWording INTO vResult
			FROM Clauses AS C
			INNER JOIN ClausesDetails AS CD ON C.ClauseID = CD.ClauseID
			WHERE (CD.PricingPolicyID = pPricingPolicyID)
				AND (C.ClauseName = pClauseName);
		END if;
	
	ELSE
	
		SELECT CD.ClauseWording INTO vResult
		FROM Clauses AS C
		INNER JOIN ClausesDetails AS CD ON C.ClauseID = CD.ClauseID
		WHERE (C.ClauseID = pClauseID)
			AND (CD.PricingPolicyID = pPricingPolicyID);
	END if;
	--  Return the result of the function
	--  RETURN ISNULL(vResult, '')
	RETURN vResult;
END;
