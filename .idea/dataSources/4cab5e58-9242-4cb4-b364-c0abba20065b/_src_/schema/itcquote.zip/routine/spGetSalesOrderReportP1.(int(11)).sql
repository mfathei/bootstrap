CREATE FUNCTION itcquote.spGetSalesOrderReportP1(pSalesOrderID INT)
  RETURNS TEXT
  BEGIN
        declare vResult text charset utf8 default '';
        DECLARE output TEXT CHARSET utf8 DEFAULT '';
        DECLARE cFinished int default 0;
        declare cur_1 cursor for 
			SELECT 
                concat(xml_tag('CurrentDate', CONVERT(CURDATE(), CHAR(50)), null, null),
                xml_tag('CurrentTime', CONVERT(CURDATE(), CHAR(50)), NULL, NULL),
                xml_tag('SalesOrderNumber', SalesOrders.SalesOrderID, NULL, NULL),
				xml_tag('SalesOrderID', SalesOrders.SalesOrderID, NULL, NULL), 
				xml_tag('CreateDate', CONVERT(SalesOrders.CreateDate, CHAR(50)), NULL, NULL),
				xml_tag('Title', SalesOrders.Title, NULL, NULL), 
				xml_tag('CODE', SalesOrders.Code, NULL, NULL),
				xml_tag('SalesOrderType', SalesOrdersTypes.TheName, NULL, NULL),
				xml_tag('CreateLoginName', Accounts.LoginName, NULL, NULL),
				xml_tag('EndUserName', (
						SELECT LoginName
						FROM Accounts
						WHERE (AccountID = SalesOrders.ModifyAccountID)
						), NULL, NULL), 
				xml_tag('MonthlyLease', CONVERT(CONVERT(SalesOrders.MonthlyLease, DECIMAL(10, 2)), CHAR(50)), NULL, NULL),
				xml_tag('AdditionalMonths', CONVERT(CONVERT(SalesOrders.AdditionalMonths, DECIMAL(10, 2)), CHAR(50)), NULL, NULL), 
				xml_tag('SalePrice', CONVERT(CONVERT(SalesOrders.SalePrice, DECIMAL(10, 2)), CHAR(50)), NULL, NULL),
				xml_tag('FreightCharge', CONVERT(CONVERT(SalesOrders.FreightCharge, DECIMAL(10, 2)), CHAR(50)), NULL, NULL),
				xml_tag('BackFreightCharge', CONVERT(CONVERT(SalesOrders.BackFreightCharge, DECIMAL(10, 2)), CHAR(50)), NULL, NULL),
				xml_tag('TechCost', CONVERT(CONVERT(SalesOrders.TechCost, DECIMAL(10, 2)), CHAR(50)), NULL, NULL),
				xml_tag('CommissionAmount', CONVERT(CONVERT(SalesOrders.CommissionAmount, DECIMAL(10, 2)), CHAR(50)), NULL, NULL),
				xml_tag('ShipDate', CONVERT(SalesOrders.ShipDate, CHAR(50)), NULL, NULL),
				xml_tag('OnSiteDate', CONVERT(SalesOrders.OnSiteDate, CHAR(50)), NULL, NULL),
				xml_tag('SalesOrderStatus', SalesOrdersStatus.TheName, NULL, NULL),
				xml_tag('LeaseTerm', SalesOrders.LeaseTerm, NULL, NULL),
				xml_tag('PaymentTerms', PaymentTerms.TheName, NULL, NULL),
				xml_tag('SalesOrderKind', PropertiesValues.TheValue, NULL, NULL), 
				xml_tag('SalesOrderInfo', SalesOrders.SalesOrderInfo, NULL, NULL), 
				xml_tag('SpecialInstructions', SalesOrders.SpecialInstructions, NULL, NULL), 
				xml_tag('ShippingContactName', Contacts.ContactName, NULL, NULL),
				xml_tag('ShippingAddress', Contacts.Address, NULL, NULL), 
				xml_tag('ShippingAddress2', Contacts.Address2, NULL, NULL), 
				xml_tag('ShippingState', Contacts.STATE, NULL, NULL),
				xml_tag('ShippingCity', Contacts.City, NULL, NULL),
				xml_tag('ShippingZip', Contacts.Zip, NULL, NULL), 
				xml_tag('ShippingFax', Contacts.Fax, NULL, NULL),
				xml_tag('BillingContactName', Contacts_1.ContactName, NULL, NULL), 
				xml_tag('BillingAddress', Contacts.Address, NULL, NULL), 
				xml_tag('BillingAddress2', Contacts.Address2, NULL, NULL),
				xml_tag('BillingState', Contacts.STATE, NULL, NULL),
				xml_tag('BillingCity', Contacts.City, NULL, NULL),
				xml_tag('BillingZip', Contacts.Zip, NULL, NULL),
				xml_tag('BillingPhoneNo', Contacts.PhoneNo, NULL, NULL),
				xml_tag('BillingMobileNo', Contacts.MobileNo, NULL, NULL), 
				xml_tag('BillingFax', Contacts.Fax, NULL, NULL), 
				xml_tag('BillingEmail', Contacts.Email, NULL, NULL), 
				xml_tag('BillingWebSite', Contacts.WebSite, NULL, NULL)
				)
			FROM PaymentTerms
			RIGHT JOIN SalesOrders
			LEFT JOIN Contacts ON SalesOrders.ShippingContactID = Contacts.ContactID
			LEFT JOIN PropertiesValues ON SalesOrders.SalesOrderKindID = PropertiesValues.PropertyValueID ON PaymentTerms.PaymentTermID = SalesOrders.PaymentTermID LEFT JOIN Contacts AS Contacts_1 ON SalesOrders.BillingContactID = Contacts_1.ContactID LEFT JOIN Accounts ON SalesOrders.CreateAccountID = Accounts.AccountID LEFT JOIN SalesOrdersStatus ON SalesOrders.SalesOrderStatusID = SalesOrdersStatus.SalesOrderStatusID LEFT JOIN SalesOrdersTypes ON SalesOrders.SalesOrderTypeID = SalesOrdersTypes.SalesOrderTypeID WHERE (SalesOrders.SalesOrderID = pSalesOrderID)
			-- FOR XML PATH('')
			;
			
			
	declare continue handler for not found set cFinished = 1;
	
    set @ln = '
';
	
	open cur_1;
			
    my_loop: LOOP
    
        fetch cur_1 into output;
        if cFinished = 1 then
            -- close cur_1;
            leave my_loop;
        end if;
        
        set vResult = concat(vResult , output);
    
    end LOOP my_loop;
    CLOSE cur_1;
    return vResult;
    END;
