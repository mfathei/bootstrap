CREATE PROCEDURE itcquote.fnGetSpecialEmails()
  BEGIN
drop temporary table if exists fnGetSpecialEmails_t;
create TEMPORARY TABLE  fnGetSpecialEmails_t(
	MailID int NOT NULL
	,EmailAddress VARCHAR(100)
);
	-- mohamed.abdallavitcanint.net  
	-- Engineer Department
	INSERT INTO fnGetSpecialEmails_t (
		MailID
		,EmailAddress
		)
	VALUES (
		1
		,GetPropertyValue(415)
		);
	-- Sales Manager
	INSERT INTO fnGetSpecialEmails_t (
		MailID
		,EmailAddress
		)
	VALUES (
		2
		,GetPropertyValue(416)
		);
	--  Lease Mail 1 
	INSERT INTO fnGetSpecialEmails_t (
		MailID
		,EmailAddress
		)
	VALUES (
		3
		,GetPropertyValue(419)
		);
	--  Lease Mail 2
	INSERT INTO fnGetSpecialEmails_t (
		MailID
		,EmailAddress
		)
	VALUES (
		4
		,GetPropertyValue(421)
		);
END;
