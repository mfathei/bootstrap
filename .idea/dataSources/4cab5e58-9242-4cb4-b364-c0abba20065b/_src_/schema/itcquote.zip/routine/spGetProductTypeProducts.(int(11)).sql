CREATE PROCEDURE itcquote.spGetProductTypeProducts(IN `_ProductTypeID` INT)
  BEGIN
  
SELECT ProductID, ProductName FROM Products
WHERE ProductTypeID = _ProductTypeID
ORDER BY ProductName;
END;
