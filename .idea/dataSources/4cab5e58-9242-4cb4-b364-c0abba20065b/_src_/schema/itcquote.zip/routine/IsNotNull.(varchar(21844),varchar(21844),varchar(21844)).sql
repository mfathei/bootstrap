CREATE FUNCTION itcquote.IsNotNull(pcheck_expression       VARCHAR(21844), preplacement_value VARCHAR(21844),
                                   pelse_replacement_value VARCHAR(21844))
  RETURNS VARCHAR(21844)
  BEGIN
	IF pcheck_expression IS NOT NULL
		AND TRIM(pcheck_expression) <> ''
	THEN
		RETURN preplacement_value;
	
	ELSE
	
		RETURN pelse_replacement_value;
	END IF;
	RETURN pcheck_expression;
END;
