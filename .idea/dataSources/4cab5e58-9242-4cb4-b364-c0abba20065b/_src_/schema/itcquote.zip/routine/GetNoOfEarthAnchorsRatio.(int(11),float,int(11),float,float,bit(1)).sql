CREATE FUNCTION itcquote.GetNoOfEarthAnchorsRatio(pStructureWidth          INT, pStructureLength FLOAT,
                                                  pNoOfCraneBreakPoints    INT, pStandardCenterBaySpacing FLOAT,
                                                  pStructureStandardLength FLOAT, pIsAdditionToExistingStructure BIT)
  RETURNS FLOAT
  BEGIN
	DECLARE vResult FLOAT;
	IF (pStructureLength < pStructureWidth)
		AND (pIsAdditionToExistingStructure <> 1)
	THEN
		SET pNoOfCraneBreakPoints = pNoOfCraneBreakPoints + 1;
	END IF;
	SET vResult = pStructureWidth * (pStructureStandardLength + pNoOfCraneBreakPoints * pStandardCenterBaySpacing);
	SELECT COUNT(QuoteID) AS C INTO vResult
	FROM Quotes Q
	INNER JOIN Properties P ON TRIM(SUBSTRING(Q.Notes, 1, 50)) = TRIM(P.PropertyName)
	WHERE length(TRIM(SUBSTRING(Q.Notes, 1, 50))) > 3;
	RETURN IFNULL(vResult, 0);
END;
