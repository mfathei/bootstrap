CREATE FUNCTION itcquote.escapeXML(val TEXT)
  RETURNS TEXT
  BEGIN
        -- Escaping illegal XML characters
        set val = replace(val, "&", "&amp;");
        set val = replace(val, "<", "&lt;");
        set val = replace(val, ">", "&gt;"); 
        
    return val;
    END;
