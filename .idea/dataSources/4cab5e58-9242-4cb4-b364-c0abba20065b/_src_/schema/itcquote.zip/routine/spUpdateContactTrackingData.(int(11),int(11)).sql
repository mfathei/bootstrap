CREATE PROCEDURE itcquote.spUpdateContactTrackingData(IN pContactID INT, IN pLoginAccountID INT)
  BEGIN
	
	-- Insert statements for procedure here
	UPDATE Contacts
	SET CreateDate = CURDATE()
		,CreateAccountID = pLoginAccountID
	WHERE (ContactID = pContactID)
		AND (
			(CreateDate IS NULL)
			OR (CreateAccountID IS NULL)
			);
	UPDATE Contacts
	SET ModifyDate = CURDATE()
		,ModifyAccountID = pLoginAccountID
	WHERE (ContactID = pContactID);
END;
