CREATE PROCEDURE itcquote.spGetAnchorages()
  BEGIN
call spGetPropertyValues (56);
END;
