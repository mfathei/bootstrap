CREATE FUNCTION itcquote.GetDrawingsCount(pDrawingRequestID INT, pAccountID INT, pTerritoryID INT)
  RETURNS INT
  BEGIN
	--  Declare the return variable here
	DECLARE vResult INT;
	--  Add the T-SQL statements to compute the return value here
	SELECT COUNT(*) into vResult 
	FROM Drawings
	WHERE DrawingRequestID = pDrawingRequestID
		AND (
			(
				(ScopeID = 1)
				AND (CreateAccountID = pAccountID)
				)
			OR (
				(ScopeID = 2)
				AND (
					CreateAccountID IN (
						SELECT AccountID
						FROM Accounts
						WHERE TerritoryID = pTerritoryID
						)
					)
				)
			OR ((ScopeID = 3))
			);
	--  Return the result of the function
	RETURN IFNULL(vResult, 0);
END;
