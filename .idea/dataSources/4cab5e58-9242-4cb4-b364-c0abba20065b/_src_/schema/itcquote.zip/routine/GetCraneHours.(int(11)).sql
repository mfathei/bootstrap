CREATE FUNCTION itcquote.GetCraneHours(pQuoteID INT)
  RETURNS INT
  BEGIN
	DECLARE vResult INT;
	DECLARE pStructureID INT;
	DECLARE pStructureWidth INT;
	DECLARE pAddOn INT;
	DECLARE pX INT;
	DECLARE pY INT;
		
	declare pStructureLength FLOAT;
	SELECT SUM(QI.Quantity * CAST(PV.TheValue AS signed)) into pX 
	FROM QuotesItems AS QI
	INNER JOIN ProductsPropertiesValues AS PPV ON QI.ProductID = PPV.ProductID
	INNER JOIN PropertiesValues AS PV ON PPV.PropertyValueID = PV.PropertyValueID
	WHERE (QI.QuoteID = pQuoteID)
		AND (PPV.PropertyID = 67)
		AND (PPV.ProductTypeID <> 1);
	SELECT  Q.StructureID
		,Q.StructureLength
		,CAST(PV.TheValue AS signed)
		into
        pStructureID,
        pStructureLength
		,pY 
	FROM Quotes AS Q
	INNER JOIN ProductsPropertiesValues AS PPV ON Q.StructureID = PPV.ProductID
	INNER JOIN PropertiesValues AS PV ON PPV.PropertyValueID = PV.PropertyValueID
	WHERE (Q.QuoteID = pQuoteID)
		AND (PPV.PropertyID = 67);
	--  This Part Models Paradox  code in pageSummary.arrive()
	SET pStructureWidth = GetProductPropertyValue_Int(pStructureID, 6);
	SET pAddOn = 0;
	IF (pStructureWidth >= 100)
	then
		SET pAddOn = 12;
	END if;
	SET pX = IFNULL(pX, 0);
	SET pY = IFNULL(pY, 0);
	SET vResult = CEILING(pX + pY * (pStructureLength / 100.0) + pAddOn);
	RETURN IFNULL(vResult, 0);
END;
