CREATE PROCEDURE itcquote.spGetLatestFilesVersion(IN `_FileID` INT, IN `_FileTypeID` INT)
  BEGIN
                                
	select * from FilesVersions 
	where FileID=_FileID
	and FileTypeID=_FileTypeID
	and VersionCaption in (select MAX (VersionCaption) from FilesVersions where FileID=_FileID and FileTypeID=_FileTypeID) ;
END;
