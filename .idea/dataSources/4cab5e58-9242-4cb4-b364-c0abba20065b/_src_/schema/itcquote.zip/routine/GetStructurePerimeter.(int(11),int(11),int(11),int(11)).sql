CREATE FUNCTION itcquote.GetStructurePerimeter(pStructureWidth INT, pStructureLength INT, pNoOfFlatEnds INT,
                                               pNoOfRoundEnds  INT)
  RETURNS FLOAT
  BEGIN
	-- Declare the return variable here
	DECLARE vResult FLOAT;
	DECLARE vRE INT;
	DECLARE vFE INT;
	DECLARE vS FLOAT;
	SET vFE = pNoOfFlatEnds * pStructureWidth;
	SET vRE = pNoOfRoundEnds * ((3.14 * pStructureWidth) / 2);
	IF (pNoOfRoundEnds = 2)
	THEN
		SET vS = 2.0 * (pStructureLength - pStructureWidth);
	ELSEIF (pNoOfRoundEnds = 1)
	THEN
		SET vS = 2.0 * (pStructureLength - (pStructureWidth / 2));
	ELSE
		SET vS = 2.0 * pStructureLength;
	END IF;
	-- Add the T-SQL statements to compute the return value here
	SET vResult = vFE + vRE + vS;
	-- Return the result of the function
	RETURN vResult;
END;
