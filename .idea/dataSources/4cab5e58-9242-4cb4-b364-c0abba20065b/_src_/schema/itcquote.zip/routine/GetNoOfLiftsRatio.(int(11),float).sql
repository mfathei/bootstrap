CREATE FUNCTION itcquote.GetNoOfLiftsRatio(pStructureWidth INT, pStructureLength FLOAT)
  RETURNS FLOAT
  BEGIN
	DECLARE vResult FLOAT;
	SET vResult = pStructureLength * pStructureWidth;
	SELECT COUNT(QuoteID) AS Y INTO vResult
	FROM Quotes Q
	INNER JOIN Properties P ON Q.Title = P.PropertyName
	WHERE length(TRIM(Q.Title)) > 3;
	RETURN IFNULL(vResult, 0);
END;
