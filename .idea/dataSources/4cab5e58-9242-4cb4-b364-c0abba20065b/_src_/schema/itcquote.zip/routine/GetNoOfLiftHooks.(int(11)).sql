CREATE FUNCTION itcquote.GetNoOfLiftHooks(pQuoteID INT)
  RETURNS INT
  BEGIN
	--  Declare the return variable here
	DECLARE vResult INT;
	DECLARE pStructureID INT;
	DECLARE pX INT;
		
    DECLARE pNoOfFlatEnds int;
	DECLARE pNoOfRoundEnds int;
	DECLARE pNoOfCenterBays int;
	DECLARE pNoOfCraneBreakPoints int;
	DECLARE pNoOfBeamsPerFlatEnd int;
	DECLARE pNoOfBeamsPerRoundEnd int;
	DECLARE pNoOfBeamsPerCenterBay int;
	DECLARE pNoOfBeamsPerCraneLiftBreakpoint int;
	DECLARE pNoOfHooksPerBeam int;
		
	DECLARE pNoOfBeams int;
		
	--  Add the T-SQL statements to compute the return value here
	SELECT  StructureID
		,NoOfFlatEnds
		,NoOfRoundEnds
		,NoOfCenterBays
		,NoOfCraneBreakPoints
		into
		pStructureID
		,pNoOfFlatEnds
		,pNoOfRoundEnds
		,pNoOfCenterBays
		,pNoOfCraneBreakPoints
	FROM Quotes
	WHERE (QuoteID = pQuoteID);
	SET pNoOfBeamsPerFlatEnd = GetProductPropertyValue_Int(pStructureID, 11);
	SET pNoOfBeamsPerRoundEnd = GetProductPropertyValue_Int(pStructureID, 14);
	SET pNoOfBeamsPerCenterBay = GetProductPropertyValue_Int(pStructureID, 60);
	SET pNoOfBeamsPerCraneLiftBreakpoint = GetProductPropertyValue_Int(pStructureID, 61);
	SET pNoOfHooksPerBeam = GetProductPropertyValue_Int(pStructureID, 63);
	SET pNoOfBeams = GetNoOfBeams(pNoOfFlatEnds, pNoOfBeamsPerFlatEnd, pNoOfRoundEnds, pNoOfBeamsPerRoundEnd, pNoOfCenterBays, pNoOfBeamsPerCenterBay, pNoOfCraneBreakPoints, pNoOfBeamsPerCraneLiftBreakpoint);
	--  PropertyID = 63 : NoOfHooksPerSingleBeam  
	SELECT SUM(QI.Quantity * CAST(PV.TheValue AS signed)) into pX 
	FROM QuotesItems AS QI
	INNER JOIN ProductsPropertiesValues AS PPV ON QI.ProductID = PPV.ProductID
	INNER JOIN PropertiesValues AS PV ON PPV.PropertyValueID = PV.PropertyValueID
	WHERE (QI.QuoteID = pQuoteID)
		AND (PPV.PropertyID = 63);
	IF pX IS NULL then
		SET pX = 0;
	end if;
	
	SET vResult = pX + pNoOfBeams * pNoOfHooksPerBeam;
	IF vResult IS NULL then
		SET vResult = 0;
	end if;
	--  Return the result of the function
	RETURN vResult;
END;
