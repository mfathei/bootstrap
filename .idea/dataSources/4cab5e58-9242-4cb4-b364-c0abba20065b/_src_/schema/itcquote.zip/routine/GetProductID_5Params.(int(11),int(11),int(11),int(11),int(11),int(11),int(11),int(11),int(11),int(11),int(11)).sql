CREATE FUNCTION itcquote.GetProductID_5Params(pProductTypeID      INT, pPropertyID_01 INT, pPropertyValueID_01 INT,
                                              pPropertyID_02      INT, pPropertyValueID_02 INT, pPropertyID_03 INT,
                                              pPropertyValueID_03 INT, pPropertyID_04 INT, pPropertyValueID_04 INT,
                                              pPropertyID_05      INT, pPropertyValueID_05 INT)
  RETURNS INT
  BEGIN
	--  Declare the return variable here
	DECLARE vResult INT;
	DECLARE pQuoteVal1 
		,pQuoteVal2 
		,pQuoteVal3 
		,pQuoteVal4 
		,pQuoteVal5 VARCHAR(255);
    if pPropertyValueID_01 is null
    then
        set pPropertyValueID_01 = 0;
    end if;
    if pPropertyValueID_02 is null
    then
        set pPropertyValueID_02 = 0;
    end if;
    
    if pPropertyValueID_03 is null
    then
        set pPropertyValueID_03 = 0;
    end if;
    
    if pPropertyValueID_04 is null
    then
        set pPropertyValueID_04 = 0;
    end if;
    
    if pPropertyValueID_05 is null
    then
        set pPropertyValueID_05 = 0;
    end if;
	SET pQuoteVal1 = GetPropertyValue(pPropertyValueID_01);
	SET pQuoteVal2 = GetPropertyValue(pPropertyValueID_02);
	SET pQuoteVal3 = GetPropertyValue(pPropertyValueID_03);
	SET pQuoteVal4 = GetPropertyValue(pPropertyValueID_04);
	SET pQuoteVal5 = GetPropertyValue(pPropertyValueID_05);
    call GetWidthRangePropertyValueID_ByWidth(pPropertyValueID_01);
    CALL GetWidthRangePropertyValueID_ByWidth02(pPropertyValueID_02);
    CALL GetWidthRangePropertyValueID_ByWidth03(pPropertyValueID_03);
    CALL GetWidthRangePropertyValueID_ByWidth04(pPropertyValueID_04);
    CALL GetWidthRangePropertyValueID_ByWidth05(pPropertyValueID_05);
	SELECT T1.ProductID into vResult 
	FROM ProductsPropertiesValues AS T1
	INNER JOIN ProductsPropertiesValues AS T2 ON T1.ProductID = T2.ProductID
	INNER JOIN ProductsPropertiesValues AS T3 ON T1.ProductID = T3.ProductID
	INNER JOIN ProductsPropertiesValues AS T4 ON T1.ProductID = T4.ProductID
	INNER JOIN ProductsPropertiesValues AS T5 ON T1.ProductID = T5.ProductID
	INNER JOIN Properties AS P1 ON P1.PropertyID = T1.PropertyID
	INNER JOIN PropertiesValues AS PV1 ON P1.PropertyID = PV1.PropertyID
	INNER JOIN Properties AS P2 ON P2.PropertyID = T2.PropertyID
	INNER JOIN PropertiesValues AS PV2 ON P2.PropertyID = PV2.PropertyID
	INNER JOIN Properties AS P3 ON P3.PropertyID = T3.PropertyID
	INNER JOIN PropertiesValues AS PV3 ON P3.PropertyID = PV3.PropertyID
	INNER JOIN Properties AS P4 ON P4.PropertyID = T4.PropertyID
	INNER JOIN PropertiesValues AS PV4 ON P4.PropertyID = PV4.PropertyID
	INNER JOIN Properties AS P5 ON P5.PropertyID = T5.PropertyID
	INNER JOIN PropertiesValues AS PV5 ON P5.PropertyID = PV5.PropertyID
	-- Modified by salma on 3-4-2014--  to get producttypeid from product
	-- INNER JOIN PropertiesValues AS PV2 on P2.PropertyID = PV2.PropertyID
	INNER JOIN Products ON Products.ProductID = T1.ProductID
	WHERE (Products.ProductTypeID = pProductTypeID)
		AND
		-- WHERE  (T1.ProductTypeID = pProductTypeID) AND
		(
			(
				(
					(
						--  Salma: Modified in 26-3-2014
						-- (pPropertyID_01 != 101) AND
						(
							(
								(pPropertyValueID_01 IS NOT NULL)
								AND (T1.PropertyValueID = pPropertyValueID_01)
								)
							OR (
								(pPropertyID_01 = 106)
								AND (pPropertyValueID_01 IS NOT NULL)
								AND (T1.PropertyValueID = 502)
								)
							OR --  property value = Other
							--  if property value id = null (property exists but has no value)
							(
								(pPropertyValueID_01 IS NULL)
								AND (T1.PropertyValueID IS NULL)
								)
							OR
							-- -- Salma: Modified in 18-3-2014 added the condition for WidthRange 
							(
								(pPropertyValueID_01 IS NOT NULL)
								AND (
									(pPropertyID_01 = 104)
									AND T1.PropertyValueID IN (
										SELECT *
										FROM  GetWidthRangePropertyValueID_ByWidth_t -- GetWidthRangePropertyValueID_ByWidth(pPropertyValueID_01)
										)
									)
								)
							)
						)
					-- OR
					-- --  if property = FabricType, then use like instead of equal
					-- ((pPropertyID_01 = 101) AND
					--    (((pPropertyValueID_01 is not null) AND ((pPropertyID_01 = 101) AND ((T1.PropertyID = pPropertyID_01) AND (T1.PropertyValueID = PV1.PropertyValueID) 
					-- AND (pQuoteVal1 like PV1.TheValue , '%'))))) OR 
					-- ((pPropertyValueID_01 is null) AND (T1.PropertyValueID is null))))
					)
				)
			AND (
				(
					(
						-- (pPropertyID_02 != 101) AND
						(
							(
								(pPropertyValueID_02 IS NOT NULL)
								AND (T2.PropertyValueID = pPropertyValueID_02)
								)
							OR (
								(pPropertyID_02 = 106)
								AND (pPropertyValueID_02 IS NOT NULL)
								AND (T2.PropertyValueID = 502)
								)
							OR --  property value = Other
							(
								(pPropertyValueID_02 IS NULL)
								AND (T2.PropertyValueID IS NULL)
								)
							OR
							-- -- Salma: Modified in 18-3-2014 added the condition for WidthRange 
							(
								(pPropertyValueID_02 IS NOT NULL)
								AND (
									(pPropertyID_02 = 104)
									AND T2.PropertyValueID IN (
										SELECT *
										FROM GetWidthRangePropertyValueID_ByWidth02_t -- GetWidthRangePropertyValueID_ByWidth02(pPropertyValueID_02)
										)
									)
								)
							)
						)
					--  OR
					-- ((pPropertyID_02 = 101) AND
					--    (((pPropertyValueID_02 is not null) AND ((pPropertyID_02 = 101) AND ((T2.PropertyID = pPropertyID_02) AND (T2.PropertyValueID = PV2.PropertyValueID) 
					-- AND (pQuoteVal2 like PV2.TheValue , '%'))))) OR 
					-- ((pPropertyValueID_02 is null) AND (T2.PropertyValueID is null))))
					)
				)
			AND (
				(
					(
						-- (pPropertyID_03 != 101) AND
						(
							(
								(pPropertyValueID_03 IS NOT NULL)
								AND (T3.PropertyValueID = pPropertyValueID_03)
								)
							OR (
								(pPropertyID_03 = 106)
								AND (pPropertyValueID_03 IS NOT NULL)
								AND (T3.PropertyValueID = 502)
								)
							OR --  property value = Other
							(
								(pPropertyValueID_03 IS NULL)
								AND (T3.PropertyValueID IS NULL)
								)
							OR
							-- -- Salma: Modified in 18-3-2014 added the condition for WidthRange 
							(
								(pPropertyValueID_03 IS NOT NULL)
								AND (
									(pPropertyID_03 = 104)
									AND T3.PropertyValueID IN (
										SELECT *
										FROM GetWidthRangePropertyValueID_ByWidth03_t -- GetWidthRangePropertyValueID_ByWidth03(pPropertyValueID_03)
										)
									)
								)
							)
						)
					--  OR
					-- ((pPropertyID_03 = 101) AND
					--    (((pPropertyValueID_03 is not null) AND ((pPropertyID_03 = 101) AND ((T3.PropertyID = pPropertyID_03) AND (T3.PropertyValueID = PV3.PropertyValueID) 
					-- AND (pQuoteVal3 like PV3.TheValue , '%'))))) OR 
					-- ((pPropertyValueID_03 is null) AND (T3.PropertyValueID is null))))
					)
				)
			AND (
				(
					(
						-- (pPropertyID_04 != 101) AND
						(
							(
								(pPropertyValueID_04 IS NOT NULL)
								AND (T4.PropertyValueID = pPropertyValueID_04)
								)
							OR (
								(pPropertyID_04 = 106)
								AND (pPropertyValueID_04 IS NOT NULL)
								AND (T4.PropertyValueID = 502)
								)
							OR --  property value = Other
							(
								(pPropertyValueID_04 IS NULL)
								AND (T4.PropertyValueID IS NULL)
								)
							OR
							-- -- Salma: Modified in 18-3-2014 added the condition for WidthRange 
							(
								(pPropertyValueID_04 IS NOT NULL)
								AND (
									(pPropertyID_04 = 104)
									AND T4.PropertyValueID IN (
										SELECT *
										FROM GetWidthRangePropertyValueID_ByWidth04_t -- GetWidthRangePropertyValueID_ByWidth04(pPropertyValueID_04)
										)
									)
								)
							)
						)
					-- OR
					-- ((pPropertyID_04 = 101) AND
					--    (((pPropertyValueID_04 is not null) AND ((pPropertyID_04 = 101) AND ((T4.PropertyID = pPropertyID_04) AND (T4.PropertyValueID = PV4.PropertyValueID) 
					-- AND (pQuoteVal4 like PV4.TheValue , '%'))))) OR 
					-- ((pPropertyValueID_04 is null) AND (T4.PropertyValueID is null))))
					)
				)
			AND (
				(
					(
						-- (pPropertyID_05 != 101) AND
						(
							(
								(pPropertyValueID_05 IS NOT NULL)
								AND (T5.PropertyValueID = pPropertyValueID_05)
								)
							OR (
								(pPropertyID_05 = 106)
								AND (pPropertyValueID_05 IS NOT NULL)
								AND (T5.PropertyValueID = 502)
								)
							OR --  property value = Other
							(
								(pPropertyValueID_05 IS NULL)
								AND (T5.PropertyValueID IS NULL)
								)
							OR
							-- -- Salma: Modified in 18-3-2014 added the condition for WidthRange 
							(
								(pPropertyValueID_05 IS NOT NULL)
								AND (
									(pPropertyID_05 = 104)
									AND T5.PropertyValueID IN (
										SELECT *
										FROM GetWidthRangePropertyValueID_ByWidth05_t -- GetWidthRangePropertyValueID_ByWidth05(pPropertyValueID_05)
										)
									)
								)
							)
						)
					)
				)
			);
	-- OR
	-- ((pPropertyID_05 = 101) AND
	--    (((pPropertyValueID_05 is not null) AND ((pPropertyID_05 = 101) AND ((T5.PropertyID = pPropertyID_05) AND (T5.PropertyValueID = PV5.PropertyValueID) 
	-- AND (pQuoteVal5 like PV5.TheValue , '%'))))) OR 
	-- ((pPropertyValueID_05 is null) AND (T5.PropertyValueID is null))))
	RETURN IFNULL(vResult, 0);
END;
