CREATE FUNCTION itcquote.GetProductName(pProductID INT)
  RETURNS VARCHAR(200)
  BEGIN
	--  Declare the return variable here
	--  Declare the return variable here
	DECLARE vResult VARCHAR(200);
	--  Add the T-SQL statements to compute the return value here
	SELECT ProductName into vResult 
	FROM Products
	WHERE ProductID = pProductID;
	--  Return the result of the function
	RETURN IFNULL(vResult, '');
END;
