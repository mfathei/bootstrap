CREATE FUNCTION itcquote.GetStructureSQFT(pStructureWidth INT, pStructureLength FLOAT)
  RETURNS FLOAT
  BEGIN
	DECLARE vResult FLOAT;
	SET vResult = pStructureWidth * pStructureLength;
	RETURN IFNULL(vResult, 0);
END;
