CREATE PROCEDURE itcquote.GetDrawingRequestsTable(IN `_AccountID`   INT, IN `_TerritoryID` INT, IN `_QuoteID` INT,
                                                  IN `_StatusID`    INT, IN `_DrawingRequestID` INT,
                                                  IN `_Title`       VARCHAR(150), IN `_BDM` VARCHAR(100),
                                                  IN `_DrawingsNum` TEXT)
  begin
Declare _StatusGroupID  int; 
DECLARE _IsAdmin bit;
DECLARE _IsDrafting bit;
call fnGetStatus(_StatusGroupID);
DROP TEMPORARY TABLE IF EXISTS GetDrawingRequestsTable_t;
CREATE TEMPORARY TABLE GetDrawingRequestsTable_t (DrawingRequestID int,
           Caption varchar(150), 
           CreateDate datetime, 
           StatusID int, 
           StatusName varchar(50), 
           Comments varchar(1000), 
           DrawingsCount int,
           CreateAccountID int, 
           ModifyAccountID int, 
           ModifyDate datetime, 
		   AttentionID int, 
		   CompletedForID int,
           ScopeID int ,
           QuoteID int, 
           ReferenceDrawingRequestID int, 
		   SendToID int, 
           SendViaID int, 
           DrawingTypeID int, 
           DrawingCategoryID int, 
           DrawingSizeID int, 
		   DrawingUnitID int, 
           DeliveryPoint varchar(150), 
           RequestedDeliveryDate datetime,
           PromisedDeliveryDate datetime,
           IsStamped bit, 
           NoOfCopies int,
		   DrawingsNum text
		   -- Modified by salma 15-7-2015 added company name and BDM
           ,CompanyName varchar(100)
		   ,SalesManager varchar(100));
set  _StatusGroupID = 2;
SET _IsAdmin=(select IsAdmin from Accounts Where AccountID=_AccountID);
SET _IsDrafting=(SELECT CASE WHEN EXISTS (select Contacts.ContactID from Accounts inner join Contacts on Accounts.ContactID=Contacts.ContactID and ContactTypeID=7 
				 where AccountID=_AccountID)THEN CAST(1 AS signed)ELSE CAST(0 AS signed) END);
Insert Into GetDrawingRequestsTable_t(DrawingRequestID,Caption , CreateDate, StatusID, StatusName, Comments ,
           DrawingsCount ,CreateAccountID , ModifyAccountID,ModifyDate,AttentionID, CompletedForID ,ScopeID ,QuoteID,ReferenceDrawingRequestID ,SendToID 
           ,SendViaID , DrawingTypeID , DrawingCategoryID , DrawingSizeID ,DrawingUnitID, DeliveryPoint,RequestedDeliveryDate, PromisedDeliveryDate , IsStamped,
           NoOfCopies,DrawingsNum,CompanyName,SalesManager )
(
	SELECT DrawingRequests.DrawingRequestID ,
           DrawingRequests.Caption, 
           DrawingRequests.CreateDate, 
           DrawingRequests.StatusID, 
           tbStatus.StatusName, 
           DrawingRequests.Comments, 
           tbDrawingsCount.DrawingsCount,
           DrawingRequests.CreateAccountID, 
           DrawingRequests.ModifyAccountID, 
           DrawingRequests.ModifyDate, 
		   DrawingRequests.AttentionID, 
		   DrawingRequests.CompletedForID,
           DrawingRequests.ScopeID,
           DrawingRequests.QuoteID, 
           DrawingRequests.ReferenceDrawingRequestID, 
		   DrawingRequests.SendToID, 
           DrawingRequests.SendViaID, 
           DrawingRequests.DrawingTypeID, 
           DrawingRequests.DrawingCategoryID, 
           DrawingRequests.DrawingSizeID, 
		   DrawingRequests.DrawingUnitID, 
           DrawingRequests.DeliveryPoint, 
           DrawingRequests.RequestedDeliveryDate,
           DrawingRequests.PromisedDeliveryDate,
           DrawingRequests.IsStamped, 
		   DrawingRequests.NoOfCopies,
		   -- Modified by salma 19-4-2015 added calling to function to get DwgNum of drawings related to this drawing Request
		   dbo.getDrawingsNumForDrawingRequest(DrawingRequests.DrawingRequestID) as DrawingsNum
		     -- Modified by salma 15-7-2015 added company name and Completed for
		  ,Company.ContactName as CompanyName
		  ,BDM.ContactName as SalesManager
		 
FROM       DrawingRequests INNER JOIN
		   Accounts ON DrawingRequests.CreateAccountID = Accounts.AccountID
		    LEFT  JOIN
		   (SELECT DrawingRequests_1.DrawingRequestID, COUNT(*) AS DrawingsCount
		    FROM  DrawingRequests AS DrawingRequests_1
		    INNER JOIN
		    Drawings ON DrawingRequests_1.DrawingRequestID = Drawings.DrawingRequestID
		    GROUP BY DrawingRequests_1.DrawingRequestID) AS tbDrawingsCount ON 
		    DrawingRequests.DrawingRequestID = tbDrawingsCount.DrawingRequestID 
		    LEFT  JOIN
		  fnGetStatus_t   AS tbStatus ON DrawingRequests.StatusID = tbStatus.StatusID
		    LEFT  JOIN Contacts Company on DrawingRequests.CompanyID=Company.ContactID and Company.ContactTypeID=1
		    LEFT  JOIN Contacts BDM on DrawingRequests.CompletedForID=BDM.ContactID and BDM.ContactTypeID=8
 WHERE (((DrawingRequests.ScopeID = 1) AND (DrawingRequests.CreateAccountID = _AccountID OR _IsAdmin=1)) OR 
        ((DrawingRequests.ScopeID = 2) AND ((DrawingRequests.CreateAccountID IN (SELECT AccountID FROM Accounts WHERE TerritoryID = _TerritoryID)) OR (_IsAdmin=1))) OR
        ((DrawingRequests.ScopeID IS NULL) ) OR
        ((DrawingRequests.CreateAccountID IS NULL) ) OR
        ((DrawingRequests.ScopeID = 3) )
           -- Modified by salma 2-6-2015 added a condition to show drawing request to Drafting users if assigned to them regardless of scope
        OR (_IsDrafting=1))
        AND
         (((_QuoteID IS NULL OR _QuoteID = 0) OR (QuoteID = _QuoteID))AND
        (_StatusID IS NULL OR _StatusID =0 OR (DrawingRequests.StatusID=_StatusID))AND 
        (_Title IS NULL OR _Title like '' OR (Caption like _Title))AND 
        (_BDM IS NULL OR _BDM like '' OR (BDM.ContactName like _BDM))AND 
        (_DrawingsNum IS NULL OR _DrawingsNum like '' OR (dbo.getDrawingsNumForDrawingRequest(DrawingRequests.DrawingRequestID) like _DrawingsNum)) AND
        
        (_DrawingRequestID IS NULL OR _DrawingRequestID =0 OR (DrawingRequests.DrawingRequestID=_DrawingRequestID)))
        );
        
        
end;
