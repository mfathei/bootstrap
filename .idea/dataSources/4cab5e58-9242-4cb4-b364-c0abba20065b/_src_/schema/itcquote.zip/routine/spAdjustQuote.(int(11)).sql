CREATE PROCEDURE itcquote.spAdjustQuote(IN `_QuoteID` INT)
  BEGIN		
	DECLARE	_PricingPolicyID ,_LeaseTermAID,_LeaseTermBID int;
	declare _StructureID ,_StructureWidth int;
	declare _StructureLength float;
	declare _NoOfCenterBays int;
	declare _StructureWidthID int;	
	declare _LeaseA,_LeaseB,_Sale decimal(19,4) ;
	declare _ProductID int;
	declare _Quantity float;
	declare _PriceAddOn decimal(19,4);
	declare _QuantityAddOn float;
	/*================================================================================================
Get General quote attributes used in next adjustments and calculations
================================================================================================*/
        SELECT		 
		PricingPolicyID, LeaseTermAID, LeaseTermBID,StructureID,  StructureLength, NoOfCenterBays
        into
        _PricingPolicyID, 
		_LeaseTermAID ,
		_LeaseTermBID,
		_StructureID,
		_StructureLength,
		_NoOfCenterBays
	FROM Quotes WHERE QuoteID = _QuoteID ;
	
	SET _StructureWidthID = GetProductPropertyValueID(_StructureID, 6);
	/*================================================================================================
Adjust "Engineered Stamped Drawings" (ProductID = 591)
================================================================================================*/
		SELECT  
		SUM(QI.Quantity * QI.CustomLeaseTermAPrice),SUM(QI.Quantity * QI.CustomLeaseTermBPrice),SUM(QI.Quantity * QI.CustomSalePrice)
        into _LeaseA ,_LeaseB , _Sale 
	FROM QuotesItems QI
	LEFT JOIN Products P ON( QI.ProductID = P.ProductID)
	WHERE QI.QuoteID = _QuoteID AND QI.ItemTypeID = 1 AND P.ProductTypeID = 1;
    
	UPDATE QuotesItems
	SET CustomLeaseTermAPrice = OriginalLeaseTermAPrice
		,CustomLeaseTermBPrice = OriginalLeaseTermBPrice
		,CustomSalePrice = OriginalSalePrice
	WHERE (QuoteID = @QuoteID)
		AND (ProductID = 591);
	-- UPDATE QuotesItems SET 
	--	CustomLeaseTermAPrice = CASE WHEN @LeaseA > 75000 THEN 0 ELSE OriginalLeaseTermAPrice END,
	--	CustomLeaseTermBPrice = CASE WHEN @LeaseB > 75000 THEN 0 ELSE OriginalLeaseTermBPrice END,
	--	CustomSalePrice = CASE WHEN @Sale > 75000 THEN 0 ELSE OriginalSalePrice END
	-- WHERE (QuoteID = @QuoteID) AND (ProductID = 591)									 
	/*================================================================================================
Adjust Pricing of "Engineered Flat End Panel(s)" (ProductTypeID = 12: Engineered Flat Ends)
================================================================================================*/
	UPDATE QuotesItems
	SET CustomLeaseTermAPrice = (CASE 
			WHEN @LeaseTermAID >= 12
				THEN 0
			ELSE OriginalLeaseTermAPrice
			END)
		,CustomLeaseTermBPrice = (CASE 
			WHEN @LeaseTermBID >= 12
				THEN 0
			ELSE OriginalLeaseTermBPrice
			END)
	WHERE (QuoteID = @QuoteID)
		AND (
			ProductID IN (
				SELECT ProductID
				FROM Products
				WHERE ProductTypeID = 12
				)
			);
	/*================================================================================================
Adjust purchase pricing for Structures of widths 30' and 40' 
in case of longs lower than certain value and PricingPolicy is INC
================================================================================================*/
	SET @StructureWidth = dbo.GetProductPropertyValue_Int(@StructureID, 6);
	SET @PriceAddOn = 0;
	IF (@PricingPolicyID = 1)
		AND (@StructureWidth = 30)
		AND (@StructureLength <= 50)
	then
		SET @PriceAddOn = 3;
	end if;
    
	IF (@PricingPolicyID = 1)
		AND (@StructureWidth = 40)
		AND (@StructureLength <= 60)
	then  
		SET @PriceAddOn = 2;
    end if ;
    
	IF (@PriceAddOn <> 0)
	then 
		UPDATE QuotesItems
		SET CustomSalePrice = OriginalSalePrice + @PriceAddOn
		WHERE (QuoteID = @QuoteID)
			AND (ProductID = @StructureID);
	END if;
	/*================================================================================================
Adjust quantity of "Bay of Cable Bracing" Item (ProductTypeID=6: Doors)
From: pageOptions.cmRollingDoors() 
================================================================================================*/
	SELECT  QI.Quantity into @Quantity
	FROM QuotesItems QI
	INNER JOIN Products P ON (QI.ProductID = P.ProductID)
	WHERE (QI.QuoteID = @QuoteID)
		AND (QI.ItemTypeID = 1)
		AND (P.ProductTypeID = 6)
		AND (QI.ItemName LIKE '%Double Panel Rolling%');
	SET @Quantity = ifnull(@Quantity, 0);
	IF (@Quantity <> 0)
	then
		SET @QuantityAddOn = 0;
		IF (@StructureWidth < 70)
			AND (@Quantity = 1)
		then
			SET @QuantityAddOn = 0;
		ELSEIF (@NoOfCenterBays = 1)
        then
			SET @QuantityAddOn = 1;
		ELSE
			SET @QuantityAddOn = @Quantity;
		end if;
        
		SELECT QI.ProductID ,QI.Quantity into  @ProductID ,@Quantity 			
		FROM QuotesItems QI
		INNER JOIN Products P ON QI.ProductID = P.ProductID
		WHERE (QI.QuoteID = @QuoteID)
			AND (QI.ItemTypeID = 1)
			AND (P.ProductTypeID = 48);
		SET @ProductID = ifnull(@ProductID, 0);
		IF @ProductID = 0
		then 
			SET @ProductID = dbo.GetProductID(48, 6, @StructureWidthID, '');
			IF @ProductID <> 0
			then
				SET @Quantity = @QuantityAddOn;
				call spInsertQuoteItem(@QuoteID
					,@ProductID
					,1
					,@Quantity
					,@PricingPolicyID
					,1
					,@LeaseTermAID
					,@LeaseTermBID);
			END if;
		
		ELSE
		
			UPDATE QuotesItems
			SET Quantity = @QuantityAddOn
			WHERE (QuoteID = @QuoteID)
				AND (ItemTypeID = 1)
				AND (ProductID = @ProductID);
		END if;
	END if;
			/*================================================================================================
Adjust Aspect..
================================================================================================*/
END;
