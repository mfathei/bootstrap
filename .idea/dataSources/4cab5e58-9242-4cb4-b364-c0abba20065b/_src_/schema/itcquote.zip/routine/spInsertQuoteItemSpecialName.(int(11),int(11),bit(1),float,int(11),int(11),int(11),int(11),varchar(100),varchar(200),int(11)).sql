CREATE PROCEDURE itcquote.spInsertQuoteItemSpecialName(IN pQuoteID      INT, IN pProductID INT, IN pIsAutoAdded BIT,
                                                       IN pQuantity     FLOAT, IN pPricingPolicyID INT,
                                                       IN pSaleTypeID   INT, IN pLeaseTermAID INT, IN pLeaseTermBID INT,
                                                       IN pNotes        VARCHAR(100), IN pItemName VARCHAR(200),
                                                       IN pItemTypeID   INT)
  BEGIN
	DECLARE vSalePrice DECIMAL(10, 2);
	DECLARE vLeaseTermAPrice DECIMAL(10, 2);
	DECLARE vLeaseTermBPrice DECIMAL(10, 2);
	DECLARE vManhours FLOAT;
	DECLARE vProductName VARCHAR(200);
	DECLARE vIsDisplayedInReports BIT;
	DECLARE vInsulationTypeID INT;
	DECLARE vIsInsulated BIT;
    if pNotes is null
    then
        set pNotes = '';
    end if;
    if pItemName is null
    then
        set pItemName = '';
    end if;
	IF pQuantity > 0
    then
		
        SELECT InsulationTypeID into vInsulationTypeID 
        FROM Quotes
        WHERE (QuoteID = pQuoteID);
        SET vIsInsulated = IsInsulated(vInsulationTypeID);
        SET vSalePrice = GetProductPrice(pProductID, pPricingPolicyID, 1, pSaleTypeID);
        SET vLeaseTermAPrice = GetProductPrice(pProductID, pPricingPolicyID, 2, pLeaseTermAID);
        SET vLeaseTermBPrice = GetProductPrice(pProductID, pPricingPolicyID, 2, pLeaseTermBID);
        SET vManhours = GetProductManhours(pProductID, vIsInsulated);
        SELECT ProductName,IsDisplayedInReports into vProductName,vIsDisplayedInReports  
        FROM Products
        WHERE (ProductID = pProductID);
        DELETE from QuotesItems
        WHERE (QuoteID = pQuoteID)
            AND (ProductID = pProductID);
        IF pItemName <> ''
        then
            SET vProductName = pItemName;
        END if;
        INSERT INTO QuotesItems (
            QuoteID
            ,ProductID
            ,ItemName
            ,ItemTypeID
            ,IsAutoAdded
            ,IsDisplayedInReports
            ,Quantity
            ,OriginalSalePrice
            ,OriginalLeaseTermAPrice
            ,OriginalLeaseTermBPrice
            ,OriginalManhours
            ,CustomSalePrice
            ,CustomLeaseTermAPrice
            ,CustomLeaseTermBPrice
            ,CustomManhours
            ,Notes
            -- Salma modified in 14-7-2015 -- added the condition for special name
            ,HasSpecialName
            )
        VALUES (
            pQuoteID
            ,pProductID
            ,IFNULL(vProductName, '')
            ,pItemTypeID
            ,pIsAutoAdded
            ,vIsDisplayedInReports
            ,pQuantity
            ,vSalePrice
            ,vLeaseTermAPrice
            ,vLeaseTermBPrice
            ,vManhours
            ,vSalePrice
            ,vLeaseTermAPrice
            ,vLeaseTermBPrice
            ,vManhours
            ,pNotes
            -- Salma modified in 14-7-2015 -- added the condition for special name
            ,1
            );
            
    end if;
END;
