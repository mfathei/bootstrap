CREATE FUNCTION itcquote.CustomFormatDocAsXML(pstrDoc VARCHAR(21844), pFullTemplateName VARCHAR(1000))
  RETURNS VARCHAR(21844)
  BEGIN
	--  Declare the return variable here
	SET pstrDoc = concat('<?xml version="1.0" encoding="UTF-8" standalone="no"?>' , '<?xml-stylesheet type="text/xsl" href="' , pFullTemplateName , '"?>' , '<ITCQuotesReport xmlns="ITCQuotesReportNS">' , pstrDoc , '</ITCQuotesReport>');
	-- SET pstrDoc = REPLACE(pstrDoc, _utf8'"utf-8"', _utf8'"utf-16"'); 
	--  Return the result of the function
	RETURN pstrDoc;
END;
