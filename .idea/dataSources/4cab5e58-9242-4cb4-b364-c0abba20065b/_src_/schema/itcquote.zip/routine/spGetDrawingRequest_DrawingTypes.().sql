CREATE PROCEDURE itcquote.spGetDrawingRequest_DrawingTypes()
  begin
  call spGetPropertyValues_ByName ('DrawingRequest_DrawingTypes');
END;
