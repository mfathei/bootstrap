CREATE PROCEDURE itcquote.spAddPricingPolicy(IN PricingPolicyName VARCHAR(50), IN PricingPolicySymbol VARCHAR(50),
                                             IN Description       VARCHAR(1000), OUT PricingPolicyID INT)
  begin 
INSERT into PricingPolicies
(
	PricingPolicyName,
	PricingPolicySymbo,
	Description
)
VALUES
(
	PricingPolicyName,
	PricingPolicySymbol,
	Description
);
SELECT PricingPolicyID = last_insert_id();
end;
