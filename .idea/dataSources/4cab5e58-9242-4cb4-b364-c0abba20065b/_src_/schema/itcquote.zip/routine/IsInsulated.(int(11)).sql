CREATE FUNCTION itcquote.IsInsulated(pInsulationTypeID INT)
  RETURNS BIT
  BEGIN
	-- Declare the return variable here
	DECLARE vResult BIT;
	-- Add the T-SQL statements to compute the return value here
	IF (pInsulationTypeID = 49) THEN
		SET vResult = 0;
	ELSE
		SET vResult = 1;
    END IF;
    
	-- Return the result of the function
	RETURN vResult;
END;
