CREATE FUNCTION itcquote.GetNoOfEarthAnchors(pStructureWidth INT, pNoOfBeams INT, pWindRate FLOAT)
  RETURNS INT(6)
  BEGIN
	DECLARE vResult int;
	DECLARE pMultiply int;
	SET vResult = pNoOfBeams;
	IF (pStructureWidth < 60)
		AND (pWindRate > 120) then
		SET vResult = 2 * pNoOfBeams;
    end if;
    
	IF (pStructureWidth >= 60) then
		SET vResult = 2 * pNoOfBeams;
    end if;
    
	RETURN IFNULL(vResult, 0);
END;
