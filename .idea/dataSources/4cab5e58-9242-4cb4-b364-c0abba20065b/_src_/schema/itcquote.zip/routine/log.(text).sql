CREATE PROCEDURE itcquote.log(IN ptxt TEXT)
  BEGIN
        INSERT INTO `log`(txt) VALUES(ptxt);
    END;
