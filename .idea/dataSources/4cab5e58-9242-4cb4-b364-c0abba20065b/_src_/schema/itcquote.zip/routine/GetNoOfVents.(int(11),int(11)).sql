CREATE FUNCTION itcquote.GetNoOfVents(pQuoteID INT, pVentID INT)
  RETURNS INT(6)
  BEGIN
	DECLARE vResult int;
	DECLARE pStructureID INT;
	DECLARE pApplicationID int;
	DECLARE pNoOfRoundEnds int;
	DECLARE pNoOfCenterBays int;
	DECLARE pStructureEndModuleVolume INT;
	DECLARE pStructureCenterModuleVolume INT;
	DECLARE pCFM int;
	DECLARE pAirChargeRate int;
	SELECT StructureID
		,ApplicationID
		,NoOfRoundEnds
		,NoOfCenterBays
		into
		pStructureID
		,pApplicationID
		,pNoOfRoundEnds
		,pNoOfCenterBays
	FROM Quotes
	WHERE (QuoteID = pQuoteID);
	
	SET pStructureEndModuleVolume = GetProductPropertyValue_Int(pStructureID, 38);
	SET pStructureCenterModuleVolume = GetProductPropertyValue_Int(pStructureID, 35);
	
	SET pCFM = GetProductPropertyValue_Int(pVentID, 15);
	SELECT AirChargeRate into pAirChargeRate 
	FROM Applications
	WHERE (ApplicationID = pApplicationID);
	
	SET vResult = CEILING(pAirChargeRate * (pNoOfRoundEnds * pStructureEndModuleVolume + pNoOfCenterBays * pStructureCenterModuleVolume) / (60.0 * pCFM));
	SET vResult = IFNULL(vResult, 0);
	
	IF (vResult = 0)
	then
		SET vResult = 1;
    end if;
    
	RETURN vResult;
END;
