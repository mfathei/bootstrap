CREATE FUNCTION itcquote.fn_Num_ToWords(pInput DECIMAL(32, 3))
  RETURNS TEXT
  BEGIN
	-- declare pInput Numeric(32,3) 
	-- set pInput = 42.8572
	DECLARE vNumber NUMERIC(32);
	
	DECLARE vCents INT;
	DECLARE vinputNumber VARCHAR(38);
		
	DECLARE voutputString TEXT;
	DECLARE vlength INT;
	DECLARE vcounter INT;
	DECLARE vloops INT;
	DECLARE vposition INT;
	DECLARE vchunk CHAR(3); -- for chunks of 3 numbers;
	DECLARE vtensones CHAR(2);
	DECLARE vhundreds CHAR(1);
	DECLARE vtens CHAR(1);
	DECLARE vones CHAR(1);
	DECLARE vVCents VARCHAR(2);
	DROP TEMPORARY TABLE IF EXISTS vNumbersTable;
	CREATE TEMPORARY TABLE vNumbersTable (
		number CHAR(2)
		,word VARCHAR(10)
		);
    SET vNumber = FLOOR(pInput);
	-- Select cast(pInput as money)
	SET vCents = 100 * (CAST(pInput AS DECIMAL(32, 2)) - vNumber);
	IF vNumber = 0
    then
		RETURN 'Zero';
    end if;
	-- initialize the variables
	SET vinputNumber = CONVERT(vNumber ,CHAR(38))
		,voutputString = ''
		,vcounter = 1;
    
	SET vlength = length(vinputNumber)
		,vposition = length(vinputNumber) - 2
		,vloops = length(vinputNumber) / 3;
call log(concat('vlength= ', vlength));
	-- make sure there is an extra loop added for the remaining numbers
	IF length(vinputNumber) % 3 <> 0
    then
		SET vloops = vloops + 1;
    end if;
	-- insert data for the numbers and words
	INSERT INTO vNumbersTable
	SELECT '00'
		,''
	
	UNION ALL
	
	SELECT '01'
		,'One'
	
	UNION ALL
	
	SELECT '02'
		,'Two'
	
	UNION ALL
	
	SELECT '03'
		,'Three'
	
	UNION ALL
	
	SELECT '04'
		,'Four'
	
	UNION ALL
	
	SELECT '05'
		,'Five'
	
	UNION ALL
	
	SELECT '06'
		,'Six'
	
	UNION ALL
	
	SELECT '07'
		,'Seven'
	
	UNION ALL
	
	SELECT '08'
		,'Eight'
	
	UNION ALL
	
	SELECT '09'
		,'Nine'
	
	UNION ALL
	
	SELECT '10'
		,'Ten'
	
	UNION ALL
	
	SELECT '11'
		,'Eleven'
	
	UNION ALL
	
	SELECT '12'
		,'Twelve'
	
	UNION ALL
	
	SELECT '13'
		,'Thirteen'
	
	UNION ALL
	
	SELECT '14'
		,'Fourteen'
	
	UNION ALL
	
	SELECT '15'
		,'Fifteen'
	
	UNION ALL
	
	SELECT '16'
		,'Sixteen'
	
	UNION ALL
	
	SELECT '17'
		,'Seventeen'
	
	UNION ALL
	
	SELECT '18'
		,'Eighteen'
	
	UNION ALL
	
	SELECT '19'
		,'Nineteen'
	
	UNION ALL
	
	SELECT '20'
		,'Twenty'
	
	UNION ALL
	
	SELECT '30'
		,'Thirty'
	
	UNION ALL
	
	SELECT '40'
		,'Forty'
	
	UNION ALL
	
	SELECT '50'
		,'Fifty'
	
	UNION ALL
	
	SELECT '60'
		,'Sixty'
	
	UNION ALL
	
	SELECT '70'
		,'Seventy'
	
	UNION ALL
	
	SELECT '80'
		,'Eighty'
	
	UNION ALL
	
	SELECT '90'
		,'Ninety';
	WHILE vcounter <= vloops
	do
		-- get chunks of 3 numbers at a time, padded with leading zeros
		SET vchunk = RIGHT(concat('000' , SUBSTRING(vinputNumber, vposition, 3)), 3);
		IF vchunk <> '000'
		then
			SET vtensones = SUBSTRING(vchunk, 2, 2)
				,vhundreds = SUBSTRING(vchunk, 1, 1)
				,vtens = SUBSTRING(vchunk, 2, 1)
				,vones = SUBSTRING(vchunk, 3, 1);
			-- If twenty or less, use the word directly from vNumbersTable
			IF CONVERT(vtensones, signed) <= 20
				OR vOnes = '0'
			then
				SET @tmp = (
						SELECT word
						FROM vNumbersTable
						WHERE vtensones = number
						);
                        
                       SET voutputString = concat(@tmp, CASE vcounter
						WHEN 1
							THEN '' -- No name
						WHEN 2
							THEN ' Thousand'
						WHEN 3
							THEN ' Million'
						WHEN 4
							THEN ' Billion'
						WHEN 5
							THEN ' Trillion'
						WHEN 6
							THEN ' Quadrillion'
						WHEN 7
							THEN ' Quintillion'
						WHEN 8
							THEN ' Sextillion'
						WHEN 9
							THEN ' Septillion'
						WHEN 10
							THEN ' Octillion'
						WHEN 11
							THEN ' Nonillion'
						WHEN 12
							THEN ' Decillion'
						WHEN 13
							THEN ' Undecillion'
						ELSE ''
						END , ' '  -- + ', '
					, voutputString);
			
			ELSE
			 -- break down the ones and the tens separately
                SET @tmp = ' ';
				SET @tmp2 = (
						SELECT word
						FROM vNumbersTable
						WHERE concat(vtens , '0') = number
						) ;
                
                set @tmp = concat(@tmp, @tmp2, '-' );
                
                SET @tmp2 = (
						SELECT word
						FROM vNumbersTable
						WHERE concat('0' , vones) = number
						);
                set voutputString = concat(@tmp, @tmp2
                        , CASE vcounter
						WHEN 1
							THEN '' -- No name
						WHEN 2
							THEN ' Thousand '
						WHEN 3
							THEN ' Million '
						WHEN 4
							THEN ' Billion '
						WHEN 5
							THEN ' Trillion '
						WHEN 6
							THEN ' Quadrillion '
						WHEN 7
							THEN ' Quintillion '
						WHEN 8
							THEN ' Sextillion '
						WHEN 9
							THEN ' Septillion '
						WHEN 10
							THEN ' Octillion '
						WHEN 11
							THEN ' Nonillion '
						WHEN 12
							THEN ' Decillion '
						WHEN 13
							THEN ' Undecillion '
						ELSE ''
						END , voutputString);
			END if;
			-- now get the hundreds
			IF vhundreds <> '0'
			then
                set @tmp = (
						SELECT word
						FROM vNumbersTable
						WHERE concat('0' , vhundreds) = number
						);
                        
				SET voutputString = concat(@tmp , ' Hundred ' , ' and ' , voutputString);
                
			END if;
		END if;
		-- return voutputString
		SET vcounter = vcounter + 1
			,vposition = vposition - 3;
			
	END while;
	-- Remove any double spaces
	SET voutputString = TRIM(REPLACE(voutputString, '  ', ' '));
	-- Salma: Modified in 3-3-2013 -- Make first word only capital------------------------------ 
	SET voutputstring = concat(UPPER(LEFT(voutputstring, 1)) , LOWER(SUBSTRING(voutputstring, 2, 8000)));
	-- return  LOCATE(' ', voutputstring, 20)
	-- return SUBSTRING(voutputstring, 2, 8000)
	-- return SUBSTRING(voutputstring, len(voutputstring)-1, 1)
	SET vVCents = convert(vCents, CHAR(20));
	-- if (len(vVCents) = 1)set vVCents = '0' + vVcents
	-- Salma: Modified in 4-3-2013 -- Make Dollars and Cents lower case------------------------------ 
	SET voutputString = concat(voutputString , ' dollars');
	IF (vCents <= 0)
	then
		RETURN voutputString;
	end if;
	RETURN concat(voutputString , ' and ' , vVCents , ' cents'); -- return the result
END;
