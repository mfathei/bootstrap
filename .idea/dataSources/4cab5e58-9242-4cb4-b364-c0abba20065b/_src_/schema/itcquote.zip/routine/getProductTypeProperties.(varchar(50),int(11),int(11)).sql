CREATE PROCEDURE itcquote.getProductTypeProperties(IN `$product_type_id` VARCHAR(50), IN `$offset` INT, IN `$limit` INT)
  BEGIN

set @query = concat("select SQL_CALC_FOUND_ROWS  ppv.product_type_id,  ppv.product_id,pv.property_value_id, p.property_id,  property_name, the_value  
					from product_property_value ppv 
                    join product_type_property ptp on ppv.product_type_id= ptp.product_type_id  
                    join property p on ptp.property_id= p.property_id  and  ppv.property_id=p.property_id
                    left join property_value pv on pv.property_value_id = ppv.property_value_id  and pv.property_id = p.property_id 
                    where ppv.product_type_id='", $product_type_id ,"'
                    group by ptp.property_id  order by   property_name asc limit ", $limit," offset " , $offset  );

  -- select @query;
PREPARE stmt1 FROM @query;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1;
SELECT FOUND_ROWS();  

END;
