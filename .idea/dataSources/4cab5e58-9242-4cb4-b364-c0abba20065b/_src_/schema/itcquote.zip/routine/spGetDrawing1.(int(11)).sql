CREATE PROCEDURE itcquote.spGetDrawing1(IN `_DrawRequestID` INT)
  BEGIN
	IF (_DrawRequestID != 0)
	then
		SELECT DrawingID
			,CreateAccountID
			,CreateDate
			,ModifyAccountID
			,ModifyDate
			,DrawingRequestID
			,DrawnByID
			,ExpectedDate
			,ActualDate
			,DrawingTypeID
			,StatusID
			,Caption
			,Comments
		FROM Drawings
		WHERE (DrawingRequestID = _DrawRequestID);
	
	ELSE
	
		SELECT DrawingID
			,CreateAccountID
			,CreateDate
			,ModifyAccountID
			,ModifyDate
			,DrawingRequestID
			,DrawnByID
			,ExpectedDate
			,ActualDate
			,DrawingTypeID
			,StatusID
			,Caption
			,Comments
		FROM Drawings;
	
END if;
END;
