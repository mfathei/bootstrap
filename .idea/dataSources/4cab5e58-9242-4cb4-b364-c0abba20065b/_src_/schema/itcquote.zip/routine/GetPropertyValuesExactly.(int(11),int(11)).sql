CREATE FUNCTION itcquote.GetPropertyValuesExactly(pPropertyID INT, pPropertyValueID INT)
  RETURNS VARCHAR(30)
  BEGIN
	DECLARE vResult VARCHAR(30);
	SET vResult = (
			SELECT PropertiesValues.TheValue
			FROM Properties
			INNER JOIN PropertiesValues ON Properties.PropertyID = PropertiesValues.PropertyID
			WHERE (Properties.PropertyID = pPropertyID)
				AND (PropertiesValues.PropertyValueID = pPropertyValueID)
			);
	RETURN vResult;
END;
