CREATE PROCEDURE itcquote.spGetContactsDetails(IN `_ContactID` INT)
  BEGIN
	SELECT ContactID
		,ContactName
		,ContactTypeID
		,CreateDate
		,CreateAccountID
		,ScopeID
		,ModifyAccountID
		,ModifyDate
		,CompanyID
		,Address
		,Zip
		,PhoneNo
		,MobileNo
		,Fax
		,Email
		,WebSite
		,Description
	FROM Contacts
	WHERE (ContactID = _ContactID);
END;
