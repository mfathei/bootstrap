CREATE PROCEDURE itcquote.UpdateIsNotAutoAdded(IN pQuoteId INT)
  BEGIN
	DECLARE vMinAI INT;
	DECLARE vMaxAI INT;
	DECLARE vPricingPolicyID INT;
	DECLARE vSaleTypeID INT;
	DECLARE vLeaseTermAID INT;
	DECLARE vLeaseTermBID INT;
	DECLARE vProductID INT;
	DECLARE vProductTypeID INT;
	DECLARE vQuantity INT;
	DECLARE vNotes VARCHAR(21844) CHARSET utf8;
	DECLARE vItemTypeID INT;
	DECLARE vRelatedProductID INT default 0;
	DECLARE vItemName VARCHAR(500);
	DECLARE vNoOfConnections INT;
	DECLARE vRequiredLength FLOAT;
	DECLARE vInteriorDoorID INT;
	DECLARE vExteriorDoorID INT;
	DECLARE vWindowID INT;
	DECLARE vLogoID INT;
	DECLARE vQuantityInterior FLOAT DEFAULT 1;
	DECLARE vQuantityExterior FLOAT DEFAULT 1;
	DECLARE vQuantityWindow FLOAT DEFAULT 1;
	DECLARE vIsDisplayedInReports BIT;
	DECLARE vSalePrice DECIMAL(10, 2);
	DECLARE vLeaseTermAPrice DECIMAL(10, 2);
	DECLARE vLeaseTermBPrice DECIMAL(10, 2);
	DECLARE vManHours FLOAT;
	SET vMinAI = (
			SELECT MIN(AI)
			FROM QuotesItems
			WHERE QuoteID = pQuoteId
				AND IsAutoAdded = 0
			);
			
	SET vMaxAI = (
			SELECT MAX(AI)
			FROM QuotesItems
			WHERE QuoteID = pQuoteId
				AND IsAutoAdded = 0
			);
			
	SET vPricingPolicyID = (
			SELECT PricingPolicyID
			FROM Quotes
			WHERE QuoteID = vQuoteID
			);
			
	SET vSaleTypeID = (
			SELECT SaleTypeID
			FROM Quotes
			WHERE QuoteID = vQuoteID
			);
			
	SET vLeaseTermAID = (
			SELECT LeaseTermAID
			FROM Quotes
			WHERE QuoteID = vQuoteID
			);
			
	SET vLeaseTermBID = (
			SELECT LeaseTermBID
			FROM Quotes
			WHERE QuoteID = vQuoteID
			);
	WHILE vMinAI <= vMaxAI
	do
		SET vProductID = (
				SELECT ProductID
				FROM QuotesItems
				WHERE AI = vMinAI
				);
				
		SET vProductTypeID = (
				SELECT ProductTypeID
				FROM QuotesItems
				INNER JOIN Products ON QuotesItems.ProductID = Products.ProductID
				WHERE AI = vMinAI
				);
				
		SET vQuantity = (
				SELECT Quantity
				FROM QuotesItems
				WHERE AI = vMinAI
				);
				
		SET vNotes = (
				SELECT Notes
				FROM QuotesItems
				WHERE AI = vMinAI
				);
				
		SET vItemTypeID = (
				SELECT ItemTypeID
				FROM QuotesItems
				WHERE AI = vMinAI
				);
				
		SET vItemName = (
				SELECT ItemName
				FROM QuotesItems
				WHERE AI = vMinAI
				);
				
		IF (
				vProductTypeID = 21
				OR vProductTypeID = 41
				OR vProductTypeID = 42
				) -- Corrdiors, Canopies and Vestibules
		then
			SET vRelatedProductID = (
					SELECT RelatedProductID
					FROM QuotesItems
					WHERE AI = vMinAI
					);
					
			SET vNoOfConnections = (
					SELECT NoOfConnectedStructures
					FROM QuotesItems
					WHERE AI = vMinAI
					);
					
			SET vRequiredLength = (
					SELECT RequiredLength
					FROM QuotesItems
					WHERE AI = vMinAI
					);
					
			SET vInteriorDoorID = (
					SELECT InteriorDoor
					FROM RelatedProducts
					WHERE QuoteID = vQuoteID
						AND ProductID = vProductID
						AND RelatedProductID = vRelatedProductID
					);
					
			SET vExteriorDoorID = (
					SELECT ExteriorDoor
					FROM RelatedProducts
					WHERE QuoteID = vQuoteID
						AND ProductID = vProductID
						AND RelatedProductID = vRelatedProductID
					);
					
			SET vWindowID = (
					SELECT Window
					FROM RelatedProducts
					WHERE QuoteID = vQuoteID
						AND ProductID = vProductID
						AND RelatedProductID = vRelatedProductID
					);
					
			SET vLogoID = (
					SELECT Logo
					FROM RelatedProducts
					WHERE QuoteID = vQuoteID
						AND ProductID = vProductID
						AND RelatedProductID = vRelatedProductID
					);
					
			SET vQuantityInterior = (
					SELECT InteriorDoorQuantity
					FROM RelatedProducts
					WHERE QuoteID = vQuoteID
						AND ProductID = vProductID
						AND RelatedProductID = vRelatedProductID
					);
					
			SET vQuantityExterior = (
					SELECT ExteriorDoorQuantity
					FROM RelatedProducts
					WHERE QuoteID = vQuoteID
						AND ProductID = vProductID
						AND RelatedProductID = vRelatedProductID
					);
					
			SET vQuantityWindow = (
					SELECT WindowQuantity
					FROM RelatedProducts
					WHERE QuoteID = vQuoteID
						AND ProductID = vProductID
						AND RelatedProductID = vRelatedProductID
					);
			DELETE
			FROM RelatedProducts
			WHERE QuoteID = vQuoteID
				AND ProductID = vProductID
				AND RelatedProductID = vRelatedProductID;
			DELETE
			FROM QuotesItems
			WHERE AI = vMinAI;
			call spInsertRelatedQuoteItem(vQuoteID
				,vProductID
				,vNotes
				,vItemName
				,vItemTypeID
				,vNoOfConnections
				,vRequiredLength
				,vInteriorDoorID
				,vExteriorDoorID
				,vWindowID
				,vLogoID
				,vQuantity
				,vQuantityInterior
				,vQuantityExterior
				,vQuantityWindow);
		
		ELSEIF (vProductID <> 0)
		then
			DELETE
			FROM QuotesItems
			WHERE AI = vMinAI;
			call spInsertQuoteItem(vQuoteID
				,vProductID
				,0
				,vQuantity
				,vPricingPolicyID
				,vSaleTypeID
				,vLeaseTermAID
				,vLeaseTermBID
				,vNotes
				,vItemTypeID);
		
		ELSE
		
			SET vIsDisplayedInReports = (
					SELECT IsDisplayedInReports
					FROM QuotesItems
					WHERE AI = vMinAI
					);
					
			SET vSalePrice = (
					SELECT CustomSalePrice
					FROM QuotesItems
					WHERE AI = vMinAI
					);
					
			SET vLeaseTermAPrice = (
					SELECT CustomLeaseTermAPrice
					FROM QuotesItems
					WHERE AI = vMinAI
					);
					
			SET vLeaseTermBPrice = (
					SELECT CustomLeaseTermBPrice
					FROM QuotesItems
					WHERE AI = vMinAI
					);
					
			SET vManHours = (
					SELECT CustomManhours
					FROM QuotesItems
					WHERE AI = vMinAI
					);
					
			DELETE
			FROM QuotesItems
			WHERE AI = vMinAI;
			call spInsertQuoteItemCustom(vQuoteID
				,0
				,vItemName
				,vItemTypeID
				,0
				,vIsDisplayedInReports
				,vQuantity
				,vSalePrice
				,vLeaseTermAPrice
				,vLeaseTermBPrice
				,vManHours
				,vNotes);
		END if;
		IF vMinAI = vMaxAI
		then
			SET vMinAI = vMaxAI + 100;
		
		ELSE
		
			SET vMinAI = (
					SELECT MIN(AI)
					FROM QuotesItems
					WHERE QuoteID = pQuoteId
						AND IsAutoAdded = 0
					);
		END if;
	END while;
END;
