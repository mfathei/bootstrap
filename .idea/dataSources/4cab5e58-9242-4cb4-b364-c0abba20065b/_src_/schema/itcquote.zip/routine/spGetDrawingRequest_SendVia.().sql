CREATE PROCEDURE itcquote.spGetDrawingRequest_SendVia()
  begin	
  call spGetPropertyValues_ByName ('DrawingRequest_SendVia');
END;
