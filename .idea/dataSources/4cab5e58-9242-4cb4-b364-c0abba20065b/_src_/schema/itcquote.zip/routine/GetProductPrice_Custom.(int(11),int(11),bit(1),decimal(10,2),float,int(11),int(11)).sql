CREATE FUNCTION itcquote.GetProductPrice_Custom(pProductID               INT, pProductTypeID INT,
                                                pIsInsulatedStructure    BIT, pOriginalprice DECIMAL(10, 2),
                                                pRequiredLength          FLOAT, pNoOfConnectedStructures INT,
                                                pWallsCount              INT)
  RETURNS DECIMAL(10, 2)
  BEGIN
	DECLARE vResult DECIMAL(10, 2);
	DECLARE pDefaultLength FLOAT;
	-- PropertyID  = 1
	DECLARE pDefaultWidth FLOAT;
	-- PropertyID  = 2
	DECLARE pConsumedLength FLOAT;
	DECLARE pConnectionFees DECIMAL(10, 2);
	-- PropertyID  = 78
	DECLARE pSubtractFees DECIMAL(10, 2);
	-- PropertyID  = 79
	DECLARE pNetConnectionFees DECIMAL(10, 2);
	SET vResult = pOriginalprice;
	IF (pProductTypeID = 21)
	then
		SET pDefaultLength = GetProductPropertyValue_float(pProductID, 1);
		SET pDefaultWidth = GetProductPropertyValue_float(pProductID, 2);
		SET pConnectionFees = GetProductPropertyValue_float(pProductID, 78);
		SET pSubtractFees = GetProductPropertyValue_float(pProductID, 79);
		SET pConsumedLength = pDefaultLength * CEILING(pRequiredLength / pDefaultLength);
		SET pNetConnectionFees = pConnectionFees * pNoOfConnectedStructures - pSubtractFees * pWallsCount;
		SET vResult = pConsumedLength * pDefaultWidth * pOriginalprice + pNetConnectionFees;
	END if;
	IF (
			pProductTypeID IN (
				40
				,41
				)
			)
	then
		SET pDefaultLength = GetProductPropertyValue_float(pProductID, 1);
		SET pDefaultWidth = GetProductPropertyValue_float(pProductID, 2);
		SET pConnectionFees = GetProductPropertyValue_float(pProductID, 78);
		IF pRequiredLength < pDefaultLength
		then
			SET pConsumedLength = pDefaultLength;
		ELSE
			SET pConsumedLength = pRequiredLength;
		end if;
		SET pNetConnectionFees = pConnectionFees;
		SET vResult = pConsumedLength * pDefaultWidth * pOriginalprice + pNetConnectionFees;
	END if;
	RETURN vResult;
END;
