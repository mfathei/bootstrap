CREATE FUNCTION itcquote.GetProductPropertyValue_Int(pProductID INT, pPropertyID INT)
  RETURNS INT
  BEGIN
	-- Declare the return variable here
	DECLARE vResult INT;
	-- Add the T-SQL statements to compute the return value here
	SELECT CAST(PropertiesValues.TheValue AS SIGNED) AS R INTO vResult
	FROM ProductsPropertiesValues
	INNER JOIN PropertiesValues ON ProductsPropertiesValues.PropertyValueID = PropertiesValues.PropertyValueID
	WHERE (ProductsPropertiesValues.ProductID = pProductID)
		AND (ProductsPropertiesValues.PropertyID = pPropertyID);
	IF vResult IS NULL THEN
		SET vResult = 0;
    END IF;
	-- Return the result of the function
	RETURN vResult;
END;
