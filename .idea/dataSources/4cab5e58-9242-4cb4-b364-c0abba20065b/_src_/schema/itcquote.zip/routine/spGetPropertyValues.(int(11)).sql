CREATE PROCEDURE itcquote.spGetPropertyValues(IN `_PropertyID` INT)
  BEGIN
  SELECT Properties.PropertyID, Properties.PropertyTypeID, PropertiesValues.ValueIndex, PropertiesValues.PropertyValueID, PropertiesValues.TheValue
  FROM Properties 
  INNER JOIN PropertiesValues ON Properties.PropertyID = PropertiesValues.PropertyID 
  WHERE (Properties.PropertyID = _PropertyID);
END;
