CREATE FUNCTION itcquote.CheckQuoteProductExist(pQuoteID INT, pProductName VARCHAR(21844), pItemTypeName VARCHAR(21844))
  RETURNS INT
  BEGIN
	RETURN (
			SELECT count(*)
			FROM QuotesItems
			WHERE QuotesItems.QuoteID = pQuoteID
				AND (
					QuotesItems.ItemTypeID = (
						SELECT ItemTypeID
						FROM QuotesItemsTypes
						WHERE (ItemTypeName = pItemTypeName)
						)
					)
				AND (
					QuotesItems.ProductID IN (
						SELECT ProductID
						FROM Products
						-- Salma: Modified in 3-3-2013 make the condition contains instead of exact---
						WHERE (ProductName LIKE CONCAT('%' , pProductName , '%'))
							OR (
								ParentID IN (
									SELECT ProductID
									FROM Products
									WHERE (ProductName LIKE CONCAT('%' , pProductName , '%'))
									)
								)
						)
					)
			);
END;
