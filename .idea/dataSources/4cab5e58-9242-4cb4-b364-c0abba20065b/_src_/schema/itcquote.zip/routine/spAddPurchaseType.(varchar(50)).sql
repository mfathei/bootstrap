CREATE PROCEDURE itcquote.spAddPurchaseType(IN PurchaseTypeName VARCHAR(50), OUT PurchaseTypeID INT)
  begin
INSERT into PurchaseTypes
(
	PurchaseTypeName
)
VALUES
(
	PurchaseTypeName
);
SELECT  last_insert_id() into PurchaseTypeID;
end;
