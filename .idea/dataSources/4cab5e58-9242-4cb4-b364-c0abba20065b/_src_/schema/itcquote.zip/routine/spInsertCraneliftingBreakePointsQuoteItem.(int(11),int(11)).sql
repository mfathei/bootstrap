CREATE PROCEDURE itcquote.spInsertCraneliftingBreakePointsQuoteItem(IN `_QuoteID` INT, IN `_ProductID` INT)
  BEGIN
 
	    DECLARE _Price ,_SalePrice  ,_LeaseTermAPrice ,_LeaseTermBPrice   decimal(19,2);
		declare _Manhours_,CenterBaySpacing ,_StandardCenterBaySpacing ,_SnowRate ,_Manhours  numeric(11,2);
	    declare _SaleTypeID ,_LeaseTermAID ,_LeaseTermBID ,_NoOfCraneBreakPoints int;
		declare _StructureWidth , _StructureID INT;
		declare _IsInsulated int(1);
		
		/*------Salma : Modified in 21-5-2015 --changed SnowRate from int to float*/
		 
	/* ----Salma: Modified on 21-2-2013 added the following variable to calculate manhours ----
	--,_InsulationTypeID int,
	--_IsMiddleEast bit,
	--_StructureLength int,
	--_StructureSQFT float,
	--_SQFTPerDay int,
	--_NoOfCenterBays int,
	--_SQFTFor1Bay float,
	--_OptionsManhours int,
	--_NoOfWorkers int,
	--_NoOfWorkingDays int*/
	SET _SaleTypeID = 1;
	SET _Manhours = 1;
	SELECT _NoOfCraneBreakPoints = Quotes.NoOfCraneBreakPoints
		,_CenterBaySpacing = CenterBaySpacing
		,_StructureID = StructureID
		,_LeaseTermAID = LeaseTermAID
		,_LeaseTermBID = LeaseTermBID
		,_SnowRate = SnowRate
/*	----Salma: Modified on 21-2-2013 added the following variable to calculate manhours ----
	--,_InsulationTypeID = InsulationTypeID,
	--_IsMiddleEast = IsMiddleEast,
	--_NoOfCenterBays=NoOfCenterBays,
	--_StructureLength = StructureLength*/
	
	FROM Quotes
	WHERE Quotes.QuoteID = _QuoteID;
	SET _StandardCenterBaySpacing = dbo.GetStructureStandardCenterBaySpacing(_StructureID, _CenterBaySpacing, _SnowRate);
	SET _StructureWidth = dbo.GetProductPropertyValue_Int(_StructureID, 6);
	/*----Salma: Modified on 21-2-2013 added the following to calculate manhours ----
	--SET _StructureSQFT = dbo.GetStructureSQFT(_StructureWidth,_StructureLength)
	--SET _SQFTPerDay = dbo.GetProductPropertyValue_Int(_StructureID, 64)
	--SET _SQFTFor1Bay=(_StructureSQFT/_NoOfCenterBays)/1500
	--SELECT  
	--_OptionsManhours = ISNULL(CEILING(SUM(Quantity * CustomManhours)), 0)
	--FROM QuotesItems QI
	--LEFT OUTER JOIN Products P ON QI.ProductID = P.ProductID 
	--WHERE (QuoteID = _QuoteID) AND (ItemTypeID = 1) 
	--AND ((QI.ProductID = 0) OR (P.ProductTypeID <> 1))
	--   SET _NoOfWorkers = dbo.GetNoOfWorkers(_StructureID, _IsMiddleEast)
	--SET _NoOfWorkingDays = dbo.GetNoOfWorkingDays(_InsulationTypeID, _StructureSQFT, _SQFTPerDay, _OptionsManhours, _NoOfWorkers)
	--   SET _Manhours=_SQFTFor1Bay+_NoOfWorkingDays
	------------------------------------------------------------------------------------------------------------------------------
	-- Salma: modified on 20-2-2013 set all prices to zero
	-- SET _SalePrice = dbo.GetProductPrice(_StructureID, 1, 1, _SaleTypeID)*_StandardCenterBaySpacing*_StructureWidth
	-- SET _LeaseTermAPrice = dbo.GetProductPrice(_StructureID, 1, 2, _LeaseTermAID)*_StandardCenterBaySpacing*_StructureWidth
	-- SET _LeaseTermBPrice = dbo.GetProductPrice(_StructureID, 1, 2, _LeaseTermBID)*_StandardCenterBaySpacing*_StructureWidth*/
	SET _SalePrice = 0;
	SET _LeaseTermAPrice = 0;
	SET _LeaseTermBPrice = 0;
	INSERT INTO QuotesItems (
		QuoteID
		,ProductID
		,ItemName
		,ItemTypeID
		,IsAutoAdded
		,IsDisplayedInReports
		,Quantity
		,OriginalSalePrice
		,OriginalLeaseTermAPrice
		,OriginalLeaseTermBPrice
		,OriginalManhours
		,CustomSalePrice
		,CustomLeaseTermAPrice
		,CustomLeaseTermBPrice
		,CustomManhours
		,Notes
		)
	VALUES (
		_QuoteID
		,0
		,'Crane Lifting Break Points'
		,1
		,0
		,1
		,_NoOfCraneBreakPoints
		,_SalePrice
		,_LeaseTermAPrice
		,_LeaseTermBPrice
		,_Manhours
		,-- Manhours
		_SalePrice
		,_LeaseTermAPrice
		,_LeaseTermBPrice
		,_Manhours
		,-- Manhours 
        ''
		);
END;
