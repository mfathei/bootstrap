CREATE PROCEDURE itcquote.spUpdateQuoteTrackingData(IN pQuoteID INT, IN pLoginAccountID INT)
  BEGIN
	-- Insert statements for procedure here
	UPDATE Quotes
	SET CreateDate = CURDATE()
		,CreateAccountID = pLoginAccountID
	WHERE (QuoteID = pQuoteID)
		AND (
			(CreateDate IS NULL)
			OR (CreateAccountID IS NULL)
			);
	UPDATE Quotes
	SET ModifyDate = CURDATE()
		,ModifyAccountID = pLoginAccountID
	WHERE (QuoteID = pQuoteID);
END;
