CREATE FUNCTION itcquote.IsSkyylight(pQuoteID INT)
  RETURNS BIT
  BEGIN
	-- Declare the return variable here
	DECLARE vResult BIT;
	DECLARE vFabricTypeID INT;
	-- Add the T-SQL statements to compute the return value here
	SELECT FabricTypeID INTO vFabricTypeID
	FROM Quotes
	WHERE QuoteID = pQuoteID;
	IF (LOWER(GetPropertyValue(vFabricTypeID)) LIKE '%with daylight%')
	THEN
		SET vResult = 1;
	ELSE
		SET vResult = 0;
    END IF;
    
	-- Return the result of the function
	RETURN vResult;
END;
