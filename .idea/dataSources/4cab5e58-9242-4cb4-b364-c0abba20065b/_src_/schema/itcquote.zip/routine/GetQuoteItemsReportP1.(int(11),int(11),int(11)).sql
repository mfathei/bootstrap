CREATE FUNCTION itcquote.GetQuoteItemsReportP1(pQuoteID INT, pReportTypeID INT, vDisplayedInReports INT)
  RETURNS TEXT
  BEGIN
        declare vResult text charset utf8 default '';
        DECLARE vProductName TEXT CHARSET utf8 DEFAULT '';
        DECLARE vProductNameOnly TEXT CHARSET utf8 DEFAULT '';
        declare vQuantity CHAR(50);
        declare vCustomLeaseTermAPrice varchar(50);
        DECLARE vCustomLeaseTermBPrice VARCHAR(50);
        DECLARE vCustomSalePrice VARCHAR(50);
        DECLARE vCustomManhours VARCHAR(50);
        DECLARE vExtendedLeaseTermAPrice VARCHAR(50);
        DECLARE vExtendedLeaseTermBPrice VARCHAR(50);
        DECLARE vExtendedSalePrice VARCHAR(50);
        DECLARE vExtendedManhours VARCHAR(50);
        
        DECLARE cFinished int default 0;
        DECLARE vDisplayedInReports int;
        declare cur_1 cursor for SELECT
				-- Salma Modified on 21-7-2015 -- added the conditions for SpecialName in Letter
				CASE 
					WHEN (
							QuotesItems.HasSpecialName = 1
							OR pReportTypeID = '2'
							)
						THEN IsNotNull(QuotesItems.Notes, concat(QuotesItems.ItemName , ' (' , QuotesItems.Notes , ')'), QuotesItems.ItemName)
					ELSE IsNotNull(QuotesItems.Notes, CONCAT(QuoteLetterProductName , ' (' , QuotesItems.Notes , ')'), QuoteLetterProductName)
					END AS ProductName
				,
				-- IFNULL(QuotesItems.ItemName , ' ') AS ProductNameOnly, 
				CASE 
					WHEN (
							QuotesItems.HasSpecialName = 1
							OR pReportTypeID = '2'
							)
						AND Products.ProductTypeID IN (
							21
							,41
							,42
							)
						THEN IsNotNull(QuotesItems.Notes, concat(QuotesItems.ItemName , ' (' , QuotesItems.Notes , ')'), QuotesItems.ItemName)
					WHEN (
							QuotesItems.HasSpecialName = 1
							OR pReportTypeID = '2'
							)
						AND (
							Products.ProductTypeID NOT IN (
								21
								,41
								,42
								)
							OR QuotesItems.ProductID = 0
							)
						THEN IFNULL(QuotesItems.ItemName, ' ')
					WHEN (
							QuotesItems.HasSpecialName = 0
							AND pReportTypeID = '1'
							)
						AND Products.ProductTypeID IN (
							21
							,41
							,42
							)
						THEN IsNotNull(QuotesItems.Notes, concat(QuoteLetterProductName , ' (' , QuotesItems.Notes , ')'), QuoteLetterProductName)
					ELSE IFNULL(QuoteLetterProductName, ' ')
					END AS ProductNameOnly
				,CASE 
					WHEN FormatQuoteItemQuantity(Products.ProductTypeID, QuotesItems.ProductID, QuotesItems.ItemName, QuotesItems.Quantity) >= 99999999
						THEN ' '
					ELSE CONVERT(QuotesItems.Quantity, CHAR(50))
					END AS Quantity
				,CONVERT( QuotesItems.CustomLeaseTermAPrice, CHAR(50)) AS CustomLeaseTermAPrice
				,CONVERT( QuotesItems.CustomLeaseTermBPrice, CHAR(50)) AS CustomLeaseTermBPrice
				,CONVERT( QuotesItems.CustomSalePrice , CHAR(50)) AS CustomSalePrice
				,CONVERT( QuotesItems.CustomManhours , CHAR(50)) AS CustomManhours
				,
				-- Salma: Modifed in 30-11-2014 removed the following comments to get prices totally without division
				CONVERT(QuotesItems.Quantity * QuotesItems.CustomLeaseTermAPrice, char(50)) AS ExtendedLeaseTermAPrice
				,CONVERT(QuotesItems.Quantity * QuotesItems.CustomLeaseTermBPrice, CHAR(50)) AS ExtendedLeaseTermBPrice
				,CONVERT(QuotesItems.Quantity * QuotesItems.CustomSalePrice , CHAR(50)) AS ExtendedSalePrice
				,CONVERT(QuotesItems.Quantity * QuotesItems.CustomManhours , CHAR(50)) AS ExtendedManhours
			-- Salma: Modifed in 30-11-2014 commented the following lines to get prices totally without division
			-- Divide by QuantityUnit value for Earth Anchor product
			-- CONVERT(varchar(50), CAST(((QuotesItems.Quantity * QuotesItems.CustomLeaseTermAPrice)/IFNULL(NULLIF(GetProductPropertyValue(QuotesItems.ProductID,100), ''), 1))  AS money), 1) AS ExtendedLeaseTermAPrice, 
			-- CONVERT(varchar(50), CAST(((QuotesItems.Quantity * QuotesItems.CustomLeaseTermBPrice)/IFNULL(NULLIF(GetProductPropertyValue(QuotesItems.ProductID,100), ''), 1)) AS money), 1) AS ExtendedLeaseTermBPrice, 
			-- CONVERT(varchar(50), CAST(((QuotesItems.Quantity * QuotesItems.CustomSalePrice)/IFNULL(NULLIF(GetProductPropertyValue(QuotesItems.ProductID,100), ''), 1)) AS money), 1) AS ExtendedSalePrice, 
			-- CONVERT(varchar(50), CAST(((QuotesItems.Quantity * QuotesItems.CustomManhours)/IFNULL(NULLIF(GetProductPropertyValue(QuotesItems.ProductID,100), ''), 1)) AS money), 1) AS ExtendedManhours
			FROM QuotesItems
			LEFT JOIN Products ON QuotesItems.ProductID = Products.ProductID
			LEFT JOIN ProductsTypes ON ProductsTypes.ProductTypeID = Products.ProductTypeID
			WHERE (QuotesItems.QuoteID = pQuoteID)
				AND (QuotesItems.ItemTypeID = 1)
				AND (
					(
						vDisplayedInReports IS NOT NULL
						AND QuotesItems.IsDisplayedInReports = 1
						)
					OR (vDisplayedInReports IS NULL)
					)
			ORDER BY FormatQuoteItemQuantity(Products.ProductTypeID, QuotesItems.ProductID, QuotesItems.ItemName, QuotesItems.Quantity)
				,QuotesItems.ItemName
				,QuotesItems.Notes
			-- FOR XML PATH('OptionItem')
			;
			
			
	declare continue handler for not found set cFinished = 1;
	
    set @ln = '
';
	
	open cur_1;
			
    my_loop: LOOP
    
        fetch cur_1 into vProductName,vProductNameOnly,vQuantity,vCustomLeaseTermAPrice,vCustomLeaseTermBPrice,vCustomSalePrice,vCustomManhours,vExtendedLeaseTermAPrice,vExtendedLeaseTermBPrice,vExtendedSalePrice,vExtendedManhours; 
        if cFinished = 1 then
            -- close cur_1;
            leave my_loop;
        end if;
        
        set vResult = concat(vResult , '<OptionItem>', @ln); -- open row tag
        set vResult = concat(vResult , xml_tag('ProductName',vProductName,null,null), @ln);
        set vResult = concat(vResult , xml_tag('ProductNameOnly',vProductNameOnly,NULL,NULL), @ln);
        set vResult = concat(vResult , xml_tag('Quantity',vQuantity,NULL,NULL), @ln);
        set vResult = concat(vResult , xml_tag('CustomLeaseTermAPrice',vCustomLeaseTermAPrice,NULL,NULL), @ln);
        set vResult = concat(vResult , xml_tag('CustomLeaseTermBPrice',vCustomLeaseTermBPrice,NULL,NULL), @ln);
        set vResult = concat(vResult , xml_tag('CustomSalePrice',vCustomSalePrice,NULL,NULL), @ln);
        set vResult = concat(vResult , xml_tag('CustomManhours',vCustomManhours,NULL,NULL), @ln);
        set vResult = concat(vResult , xml_tag('ExtendedLeaseTermAPrice',vExtendedLeaseTermAPrice,NULL,NULL), @ln);
        set vResult = concat(vResult , xml_tag('ExtendedLeaseTermBPrice',vExtendedLeaseTermBPrice,NULL,NULL), @ln);
        set vResult = concat(vResult , xml_tag('ExtendedSalePrice',vExtendedSalePrice,NULL,NULL), @ln);
        set vResult = concat(vResult , xml_tag('ExtendedManhours',vExtendedManhours,NULL,NULL), @ln);
        set vResult = concat(vResult , '</OptionItem>', @ln); -- close row tag
    
    end LOOP my_loop;
    CLOSE cur_1;
    return vResult;
    END;
