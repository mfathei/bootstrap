CREATE FUNCTION itcquote.GetProductPropertyValue(pProductID INT, pPropertyID INT)
  RETURNS VARCHAR(100)
  BEGIN
	--  Declare the return variable here
	DECLARE vResult VARCHAR(100);
	--  Add the T-SQL statements to compute the return value here
	SELECT PropertiesValues.TheValue INTO vResult
	FROM ProductsPropertiesValues
	INNER JOIN PropertiesValues ON ProductsPropertiesValues.PropertyValueID = PropertiesValues.PropertyValueID
	WHERE (ProductsPropertiesValues.ProductID = pProductID)
		AND (ProductsPropertiesValues.PropertyID = pPropertyID);
	IF vResult IS NULL
	then
		SET vResult = '';
    end if;
	--  Return the result of the function
	RETURN vResult;
END;
