CREATE FUNCTION itcquote.CheckQuotePropertyValueByProductName(pQuoteID       INT, pProductName VARCHAR(21844),
                                                              pItemTypeName  VARCHAR(21844),
                                                              pPropertyName  VARCHAR(21844),
                                                              pPropertyValue VARCHAR(21844))
  RETURNS INT
  BEGIN
	-- declare presult bit
	-- declare pswitchParameters Nvarchar(Max)
	RETURN (
			SELECT count(*)
			FROM QuotesItems
			INNER JOIN Products ON QuotesItems.ProductID = Products.ProductID
			INNER JOIN ProductsTypes ON Products.ProductTypeID = ProductsTypes.ProductTypeID
			INNER JOIN ProductsPropertiesValues ON Products.ProductID = ProductsPropertiesValues.ProductID
			INNER JOIN QuotesItemsTypes ON QuotesItems.ItemTypeID = QuotesItemsTypes.ItemTypeID
			INNER JOIN Properties ON ProductsPropertiesValues.PropertyID = Properties.PropertyID
			WHERE (QuotesItems.QuoteID = pQuoteID)
				AND (Products.ProductName LIKE CONCAT('%' , pProductName , '%'))
				AND (QuotesItemsTypes.ItemTypeName = pItemTypeName)
				AND Properties.PropertyName = (
					CASE 
						WHEN pPropertyName <> ''
							THEN pPropertyName
						END
					)
				AND GetProductPropertyValue(QuotesItems.ProductID, ProductsPropertiesValues.PropertyID) LIKE (
					CASE 
						WHEN cast(pPropertyValue as CHAR(21844) CHARSET utf8) <> ''
							THEN pPropertyValue
						END
					)
			);
		-- select presult
		-- set pswitchParameters += (select IsNotNull(pPropertieValue,'GetProductPropertyValue(QuotesItems.ProductID, ProductsPropertiesValues.PropertyID) = '+pPropertieValue+') and ',''))
		-- if (ISNULL(pPropertyName)) set pswitchParameters += '1=1'
		--  print pswitchParameters
		-- -- ////////////////////////////////////////////////
		-- select * from (exec pswitchParameters)
		-- create table #myi (i bit)
		-- insert #myi (i) exec pswitchParameters
		-- set presult = (select top 1 * from #myi)
		-- drop table #myi
		--  -- ////////////////////////////////////////////////
		-- select presult
		-- return (SELECT count(*)
		-- FROM         QuotesItems INNER JOIN
		--                       Products ON QuotesItems.ProductID = Products.ProductID INNER JOIN
		--                       ProductsTypes ON Products.ProductTypeID = ProductsTypes.ProductTypeID INNER JOIN
		--                       ProductsPropertiesValues ON Products.ProductID = ProductsPropertiesValues.ProductID INNER JOIN
		--                       QuotesItemsTypes ON QuotesItems.ItemTypeID = QuotesItemsTypes.ItemTypeID INNER JOIN
		--                       Properties ON ProductsPropertiesValues.PropertyID = Properties.PropertyID
		-- WHERE (QuotesItems.QuoteID = pQuoteID) 
		-- AND (ProductsTypes.ProductTypeName = pProductTypeName) 
		-- AND (QuotesItemsTypes.ItemTypeName = pItemTypeName)
		-- AND (GetProductPropertyValue(QuotesItems.ProductID, ProductsPropertiesValues.PropertyID) = pPropertieValue)
		-- and (Properties.PropertyName = pPropertyName)
		-- )
END;
