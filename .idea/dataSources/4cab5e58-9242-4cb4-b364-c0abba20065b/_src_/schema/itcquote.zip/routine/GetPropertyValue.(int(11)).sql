CREATE FUNCTION itcquote.GetPropertyValue(pPropertyValueID INT)
  RETURNS VARCHAR(100)
  BEGIN
	--  Declare the return variable here
	DECLARE vResult VARCHAR(100);
	--  Add the T-SQL statements to compute the return value here
	IF NOT (pPropertyValueID IS NULL)
	then
		SELECT TheValue into vResult
		FROM PropertiesValues
		WHERE (PropertyValueID = pPropertyValueID);
	END if;
	--  Return the result of the function
	RETURN IFNULL(vResult, '');
END;
