CREATE PROCEDURE itcquote.GetPricingPoliciesByTerritory(IN territoryID INT, IN PricingPolicyID INT, IN AccountID INT)
  BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
    
IF ((select count(TerritoryID) from Territory_PricingPolicy where TerritoryID=@territoryID)  > 0)
then
    -- Insert statements for procedure here
	select distinct PricingPolicies.*
	from PricingPolicies
	inner join Territory_PricingPolicy on (PricingPolicies.PricingPolicyID=Territory_PricingPolicy.PricingPolicyID)
	AND Territory_PricingPolicy.TerritoryID=territoryID
	where  Territory_PricingPolicy.TerritoryID=territoryID OR (PricingPolicyID is not null AND PricingPolicies.PricingPolicyID=PricingPolicyID)
	-- salma modified on 10-2-2015 to get AccountsPricingPolicy
	OR(AccountID IS NOT NULL AND PricingPolicies.PricingPolicyID in (select PricingPolicyID from AccountPricingPolicies where AccountID=@AccountID ))
	AND PricingPolicies.IsVisibleInQuote=1
	
	ORDER BY PricingPolicyName;
ELSE
	select *
	from PricingPolicies
	WHERE PricingPolicies.IsVisibleInQuote=1
	ORDER BY PricingPolicyName;
end if;
END;
