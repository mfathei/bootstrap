CREATE PROCEDURE itcquote.spGetProductQuoteItems(IN `_QuoteID` INT, IN `_ItemType` INT)
  BEGIN
  SELECT     QuotesItems.QuoteID, QuotesItems.ProductID, QuotesItems.ItemName, QuotesItems.ItemTypeID, QuotesItems.IsAutoAdded, 
                      QuotesItems.IsDisplayedInReports, QuotesItems.Quantity, QuotesItems.OriginalSalePrice, QuotesItems.OriginalLeaseTermAPrice, 
                      QuotesItems.OriginalLeaseTermBPrice, QuotesItems.OriginalManhours, QuotesItems.CustomSalePrice, QuotesItems.CustomLeaseTermAPrice, 
                      QuotesItems.CustomLeaseTermBPrice, QuotesItems.CustomManhours, QuotesItems.Notes, QuotesItems.Description, QuotesItems.RequiredLength, 
                      QuotesItems.NoOfConnectedStructures, QuotesItems.WallsCount, QuotesItems.InstancesNo, Products.ProductName, Products.UnitID
FROM         Products RIGHT JOIN QuotesItems ON Products.ProductID = QuotesItems.ProductID
WHERE     (QuotesItems.QuoteID = _QuoteID) AND (QuotesItems.ItemTypeID = _ItemType)
ORDER BY QuotesItems.QuoteID;
END;
