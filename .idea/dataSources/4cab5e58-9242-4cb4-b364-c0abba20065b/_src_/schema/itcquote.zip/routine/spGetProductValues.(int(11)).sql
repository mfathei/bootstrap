CREATE PROCEDURE itcquote.spGetProductValues(IN `_ProductID` INT)
  BEGIN
  
  SELECT    ProductsTypesProperties.ProductTypeID, ProductsTypesProperties.PropertyID, ProductsTypesProperties.SortOrder, 
                      ProductsTypesProperties.DefaultValueID, ProductsTypesProperties.Description, Properties.PropertyName, PropertiesValues.TheValue, 
                      Products.ProductID, PropertiesValues.PropertyValueID
  FROM         Products INNER JOIN ProductsTypesProperties ON Products.ProductTypeID = ProductsTypesProperties.ProductTypeID 
  INNER JOIN
                      Properties ON ProductsTypesProperties.PropertyID = Properties.PropertyID 
                      INNER JOIN
                      PropertiesValues ON Properties.PropertyID = PropertiesValues.PropertyID
                      INNER JOIN
                      ProductsPropertiesValues ON Products.ProductID = ProductsPropertiesValues.ProductID AND 
                      ProductsTypesProperties.ProductTypeID = ProductsPropertiesValues.ProductTypeID AND 
                      ProductsTypesProperties.PropertyID = ProductsPropertiesValues.PropertyID AND 
                      PropertiesValues.PropertyID = ProductsPropertiesValues.PropertyID AND 
                      PropertiesValues.PropertyValueID = ProductsPropertiesValues.PropertyValueID
  GROUP BY ProductsTypesProperties.ProductTypeID, ProductsTypesProperties.PropertyID, ProductsTypesProperties.SortOrder, 
                      ProductsTypesProperties.DefaultValueID, ProductsTypesProperties.Description, Properties.PropertyName, PropertiesValues.TheValue, 
                      Products.ProductID, PropertiesValues.PropertyValueID
  HAVING      (Products.ProductID = _ProductID);
END;
