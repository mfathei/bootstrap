CREATE PROCEDURE itcquote.deletePropertyValues(IN `$property_id` VARCHAR(50))
  BEGIN
declare exit HANDLER for sqlexception
begin 
	select 'error' as done;
	ROLLBACK;
end;
declare exit HANDLER for sqlwarning
begin 
	select 'error' as done;
	ROLLBACK;
end;
start transaction;
delete from product_property_value where property_id = $property_id;
delete from property_value where property_id = $property_id;
commit;
select 'done' as done;
END;
