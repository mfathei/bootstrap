CREATE PROCEDURE itcquote.BackupOldPrices(IN ppolicyID INT)
  BEGIN
	DECLARE vnewPolicyID INT;
	DECLARE vPolicyName VARCHAR(50);
	DECLARE vCount INT;
	DECLARE vResult INT;
	DECLARE vPricingPolicySymbol VARCHAR(50);
    IF ppolicyID IS NULL
    THEN
        SET ppolicyID = 0;
    END IF;
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET vPolicyName = (
			SELECT PricingPolicyName
			FROM PricingPolicies
			WHERE PricingPolicyID = ppolicyID
			);
			
	SET vPolicyName = concat(vPolicyName , '_' , CONVERT(MONTH(GETDATE()), CHAR(50)) , '_' , CONVERT(YEAR(GETDATE()), CHAR(50)));
	-- Salma Modified on 14-1-2015 -- to add the PricingPolicySymbol
	SET vPricingPolicySymbol = (
			SELECT PricingPolicySymbol
			FROM PricingPolicies
			WHERE PricingPolicyID = ppolicyID
			);
			
	SET vCount = (
			SELECT COUNT(*)
			FROM PricingPolicies
			WHERE PricingPolicyName = vPolicyName
			);
	IF (vCount > 0)
	THEN
		SET vResult = -1;
    ELSE
    
        -- Salma Modified on 14-1-2015 -- to add the PricingPolicySymbol
        INSERT INTO PricingPolicies (
            PricingPolicyName
            ,Description
            ,PricingPolicyUniqueName
            ,IsVisible
            ,PricingPolicySymbol
            ) -- values(vPolicyName,)
        SELECT vPolicyNam
            ,Description
            ,vPolicyName
            ,0
            ,vPricingPolicySymbol
        FROM PricingPolicies
        WHERE PricingPolicyID = ppolicyID;
        SET vnewPolicyID = (
                SELECT @@IDENTITY
                );
        INSERT INTO ProductsPrices (
            ProductID
            ,PricingPolicyID
            ,PricingTypeID
            ,Price
            )
        SELECT ProductID
            ,vnewPolicyID
            ,PricingTypeID
            ,Price
        FROM ProductsPrices
        WHERE PricingPolicyID = ppolicyID;
        SET vCount = (
                SELECT COUNT(*)
                FROM ProductsPrices
                WHERE PricingPolicyID = vnewPolicyID
                );
        SET vresult = vCount;
            -- If return -1 then pricing policy with the same name already exists
            -- If return 0 then pricing policy is added but with no prices
            -- Otherwise return the number of added prices 
    END IF;
    
    SELECT vResult;
END;
