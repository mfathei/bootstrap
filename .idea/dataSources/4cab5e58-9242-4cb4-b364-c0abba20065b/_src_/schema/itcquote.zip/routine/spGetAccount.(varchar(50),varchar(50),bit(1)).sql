CREATE PROCEDURE itcquote.spGetAccount(IN `_LoginName`  VARCHAR(50), IN `_LoginPassword` VARCHAR(50),
                                       IN `_FromPortal` BIT)
  BEGIN
	if _FromPortal ='' or _FromPortal is null then set _FromPortal=0; end if;
  SELECT * FROM Accounts
  WHERE (UPPER(LoginName) = UPPER(_LoginName)) AND ((LoginPassword = _LoginPassword) or (_FromPortal=1 AND Portal_Password = _LoginPassword))
  AND IsActive=1;
end;
