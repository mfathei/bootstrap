CREATE FUNCTION itcquote.GetNoOfBeams(pNoOfFlatEnds             INT, pNoOfBeamsPerFlatEnd INT, pNoOfRoundEnds INT,
                                      pNoOfBeamsPerRoundEnd     INT, pNoOfCenterBays INT, pNoOfBeamsPerCenterBay INT,
                                      pNoOfCraneLiftsBreakpoint INT, pNoOfBeamsPerCraneLiftBreakpoint INT)
  RETURNS INT
  BEGIN
	DECLARE vResult INT;
	SET vResult = pNoOfFlatEnds * pNoOfBeamsPerFlatEnd + pNoOfRoundEnds * pNoOfBeamsPerRoundEnd + (pNoOfCenterBays + 1) * pNoOfBeamsPerCenterBay + pNoOfCraneLiftsBreakpoint * pNoOfBeamsPerCraneLiftBreakpoint;
	RETURN IFNULL(vResult, 0);
END;
