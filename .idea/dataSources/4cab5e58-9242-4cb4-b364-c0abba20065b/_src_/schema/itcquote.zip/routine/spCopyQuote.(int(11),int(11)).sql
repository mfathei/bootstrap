CREATE PROCEDURE itcquote.spCopyQuote(IN `_QuoteID` INT, IN `_CreateAccountID` INT)
  BEGIN
	Declare _ID int; /*-- the new created Quote*/
			
 	INSERT INTO Quotes (CreateAccountID,ScopeID,Title,Code,PricingPolicyID,SaleTypeID,LeaseTermAID,LeaseTermBID,CompanyID,AttentionID,SalesRepID,LeadOriginID,
 	QuoteDuration,RepTerritoryID,PurchaseTerritoryID,LandingTerritoryID,LocationID,ApplicationID,StructureID,StructureLength,InsulationTypeID,InsulationThicknessID,InsulationPackageID,
 	FabricTypeID,MembraneColorID,MembraneLinerColorID,AnchorageID,ExposureID,NoOfFlatEnds,NoOfRoundEnds,NoOfCenterBays,CenterBaySpacing,NoOfCraneBreakPoints,
 	NoOfToolsSets,WindRate,WindMPH,WindKPH,WindKPA,SnowRate,IsExported,IsMiddleEast,NoOfTechConsultants,IsAdditionToExistingStructure,ProvideOpaqueMembrane,ProvideTensionCable,ProvideConduitHoles,
 	CompletedByAccountID,TypedByAccountID,Quotes.Usage,Policies,Guarantee,InPersonMeeting,MailClient,MailRep,FaxClient,FaxRep,Brochures,IsShippedFromBahrin,IsShippedFromUS,
 	IsShippedToGulfState,IsMilitary,Notes,MembraneTypeID,IsSnowLoad)
 	SELECT _CreateAccountID,ScopeID,Title,Code,PricingPolicyID,SaleTypeID,LeaseTermAID,LeaseTermBID,CompanyID,AttentionID,SalesRepID,LeadOriginID,
 	QuoteDuration,RepTerritoryID,PurchaseTerritoryID,LandingTerritoryID,LocationID,ApplicationID,StructureID,StructureLength,InsulationTypeID,InsulationThicknessID,InsulationPackageID,
 	FabricTypeID,MembraneColorID,MembraneLinerColorID,AnchorageID,ExposureID,NoOfFlatEnds,NoOfRoundEnds,NoOfCenterBays,CenterBaySpacing,NoOfCraneBreakPoints,
 	NoOfToolsSets,WindRate,WindMPH,WindKPH,WindKPA,SnowRate,IsExported,IsMiddleEast,NoOfTechConsultants,IsAdditionToExistingStructure,ProvideOpaqueMembrane,ProvideTensionCable,ProvideConduitHoles,
 	CompletedByAccountID, TypedByAccountID ,Quotes.Usage,Policies,Guarantee,InPersonMeeting,MailClient,MailRep,FaxClient,FaxRep,Brochures,IsShippedFromBahrin,IsShippedFromUS,
 	IsShippedToGulfState,IsMilitary,Notes,MembraneTypeID,IsSnowLoad
 	from Quotes where QuoteID=_QuoteID ;
	
    Set _ID = (SELECT last_insert_id());
    
    call spInsertDefaultQuoteItems (_ID);
	call spInsertIsNotAutoAddedProducts( _QuoteID, _ID); 
    
    select _ID;
    
end;
