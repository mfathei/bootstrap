CREATE PROCEDURE itcquote.GetQuotesTable(IN `_AccountID` INT, IN `_TerritoryID` INT, IN `_QuoteID` INT, IN `_Code` TEXT,
                                         IN `_Title`     TEXT, IN `_Company` VARCHAR(100))
  begin
DECLARE _IsAdmin bit;
DROP TEMPORARY TABLE IF EXISTS GetQuotesTable_t;
CREATE TEMPORARY TABLE GetQuotesTable_t(QuoteID int,
           Title text, 
           Code text,
           CreateDate datetime, 
           CreateAccountID int, 
           ScopeID int ,
           ContactName text,
           CompletedByAccountID int,
           TerritoryName varchar(50),
           PreparedBy text,
           CompletedFor text); 
    
    
	SET _IsAdmin = (select IsAdmin from Accounts Where AccountID=_AccountID);
    
     SET @qry = CONCAT("INSERT INTO `GetQuotesTable_t`(QuoteID ,Title, Code,CreateDate , CreateAccountID , ScopeID  ,ContactName ,
           CompletedByAccountID ,TerritoryName ,PreparedBy ,CompletedFor) SELECT QuoteID, Quotes.Title, Code, Quotes.CreateDate, Quotes.CreateAccountID,
           Quotes.ScopeID,Contacts.ContactName,CompletedByAccountID,
	TerritoryName,prerpared.ContactName as PreparedBy,concat(ifnull(FirstName,''),' ',ifnull(LastName,''))as CompletedFor
	FROM Quotes
	left outer join Contacts on Quotes.CompanyID=Contacts.ContactID AND ContactTypeID=1
	left outer join Accounts on Quotes.CreateAccountID=Accounts.AccountID
	left outer join Territories on Accounts.TerritoryID=Territories.TerritoryID
	left outer join Contacts as prerpared on Accounts.ContactID=prerpared.ContactID
	left outer join DevelopmentManagers  on Quotes.CompletedByAccountID=DevelopmentManagers.ManagerID
	WHERE( ((Quotes.ScopeID = 1) AND (Quotes.CreateAccountID =", _AccountID, "OR", _IsAdmin,"=1)) OR 
		((Quotes.ScopeID = 2) AND ((Quotes.CreateAccountID IN (SELECT AccountID FROM Accounts WHERE TerritoryID =", _TerritoryID,"')) OR (",_IsAdmin,"=1))) OR
		((Quotes.ScopeID IS NULL) ) OR
		((Quotes.CreateAccountID IS NULL) ) OR
		((Quotes.ScopeID = 3) ))
	    AND ((",_QuoteID," IS NULL OR", _QuoteID,"=0) OR Quotes.QuoteID=",_QuoteID,")
        AND ((",_Code," IS NULL OR", _Code," like '') OR Quotes.Code like '%'",_Code,"'%')
        AND ((",_Title," IS NULL OR", _Title," like '') OR Quotes.Title like '%'",_Title,"'%')
        AND ((",_Company," IS NULL OR ",_Company," like '') OR Contacts.ContactName like '%'",_Company,"'%')
        
 ) ");    
    PREPARE stmt FROM @qry;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
end;
