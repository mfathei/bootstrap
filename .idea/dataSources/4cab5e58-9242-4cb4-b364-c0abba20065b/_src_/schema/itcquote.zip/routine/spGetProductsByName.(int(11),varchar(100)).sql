CREATE PROCEDURE itcquote.spGetProductsByName(IN `_QuoteID` INT, IN `_ProductName` VARCHAR(100))
  BEGIN
	DECLARE _StructureID ,_StructureWidthID ,_MembraneTypeID ,_InsulationTypeID 
        ,_ISInsulatedID ,_StructureWidth ,_WidthRange ,_IsLatticeValueID   ,_SpecialWidthValueID ,_InsulationPackageID    INT;
			/*--Salma : modified in 30-05-2013--added CenterBaySpacing, DefaultByaSpacingID*/
            declare _CenterBaySpacing ,_DefaultBaySpacingID VARCHAR(50);
            declare _WidthRangeStr NVARCHAR(200);
IF _QuoteID  is null or  _QuoteID='' then set _QuoteID=-1; end if;
	IF _QuoteID = - 1
	then
		IF _ProductName =''
        then
			SELECT *
			FROM Products
			/*--Modified by salma on 26-2-2014 to add IsVisible condition*/
			WHERE IsVisible = 1
			ORDER BY ParentID
				,SortOrder;
		ELSE
			SELECT *
			FROM Products
			WHERE Products.ProductName LIKE concat('%',_ProductName,'%')
			/*	--Modified by salma on 26-2-2014 to add IsVisible condition*/
				AND IsVisible = 1
			ORDER BY ParentID
				,SortOrder;
		end if;
	
	ELSE
	
	
		/*	--Salma : modified in 06-06-2013--get structure width and widthrange property*/
			
			/*--Ghada : modified in 03-03-2014--get structure width and widthrange property (should be more generic)*/
			    
		/*	--Salma : modified in 03-07-2013--added IsLattice*/
			
		/*	--Salma : modified in 04-07-2013--added SpecialWidth*/
			
		/*	--Salma : modified in 14-06-2015--added InsulationPackage*/
			
		SELECT _StructureID = StructureID
			,_InsulationTypeID = InsulationTypeID
			,_MembraneTypeID = MembraneTypeID
			/*--Salma : modified in 30-05-2013--added DefaultBaySpacing=CenterBayScpaing*/
			,_CenterBaySpacing = CenterBaySpacing
			/*--Salma : modified in 14-06-2015--added InsulationPackage*/
			,_InsulationPackageID = InsulationPackageID
		FROM Quotes
		WHERE (QuoteID = _QuoteID);
		SET _StructureWidthID = dbo.GetProductPropertyValueID(_StructureID, 6);
		/*--Salma: modified in 03-07-2013 --get IslatticeValueId for selected Structure Product*/
		SET _IsLatticeValueID = dbo.GetProductPropertyValueID(_StructureID, 105);
		/*--Salma: modified in 04-07-2013 --get SpecialWidthValueId for selected Structure Product*/
		SET _SpecialWidthValueID = dbo.GetProductPropertyValueID(_StructureID, 106);
		SET _ISInsulatedID = GetIsInsulatedID(_InsulationTypeID);
		/*--Salma : modified in 30-05-2013--get DefaultBaySpacingID*/
		IF (_CenterBaySpacing IS NOT NULL)
		then
			SET _DefaultBaySpacingID = dbo.GetPropertyValueIDByValue_PropertyID(30, _CenterBaySpacing);
		ELSE
		
			SET _DefaultBaySpacingID = NULL;
		end if ;
	/*	--Ghada : modified in 03-03-2014--get structure width and widthrange property (commented old code, should be more generic)
		--Salma : modified in 06-06-2013--get structure width and widthrange property
		--   SET _StructureWidth = dbo.GetProductPropertyValue_Int(_StructureID, 6)
		--   IF(_StructureWidth>=30 and _StructureWidth <= 40)
		--   BEGIN
		--SET _WidthRange=dbo.GetPropertyValueIDByValue_PropertyID(104,'30-40')
		--END
		--ELSE IF(_StructureWidth >40)
		--BEGIN
		--SET _WidthRange=dbo.GetPropertyValueIDByValue_PropertyID(104,'50-160')
		--END
		-- Salma: modified in 04-03-2014-- commented the conditions since i added function that returns all PropertyValueID that matches the StructureWidth
		--SET _WidthRangeStr = ''*/
		SET _StructureWidth = dbo.GetProductPropertyValue_Int(_StructureID, 6);
		/*--   IF(_StructureWidth>=30 and _StructureWidth <= 40)
		--   BEGIN
		--SET _WidthRange=dbo.GetPropertyValueIDByValue_PropertyID(104,'30-40')
		--	IF(_WidthRangeStr <> '')
		--	BEGIN
		--	SET _WidthRangeStr = _WidthRangeStr + ','
		--	END
		--SET _WidthRangeStr = _WidthRangeStr + Ltrim(Rtrim(Str(_WidthRange)))
		--END
		--IF(_StructureWidth>=50 and _StructureWidth <= 160)
		--BEGIN
		--SET _WidthRange=dbo.GetPropertyValueIDByValue_PropertyID(104,'50-160')
		--	IF(_WidthRangeStr <> '')
		--	BEGIN
		--	SET _WidthRangeStr = _WidthRangeStr + ','
		--	END
		--SET _WidthRangeStr = _WidthRangeStr + Ltrim(Rtrim(Str(_WidthRange)))
		--END
		--IF(_StructureWidth>=30 and _StructureWidth <= 160)
		--BEGIN
		--SET _WidthRange=dbo.GetPropertyValueIDByValue_PropertyID(104,'30-160')
		--	IF(_WidthRangeStr <> '')
		--	BEGIN
		--	SET _WidthRangeStr = _WidthRangeStr + ','
		--	END
		--SET _WidthRangeStr = _WidthRangeStr + Ltrim(Rtrim(Str(_WidthRange)))
		--END
		--IF(_StructureWidth>=50 and _StructureWidth <= 60)
		--BEGIN
		--SET _WidthRange=dbo.GetPropertyValueIDByValue_PropertyID(104,'50-60')
		--	IF(_WidthRangeStr <> '')
		--	BEGIN
		--	SET _WidthRangeStr = _WidthRangeStr + ','
		--	END
		--SET _WidthRangeStr = _WidthRangeStr + Ltrim(Rtrim(Str(_WidthRange)))
		--END
		--IF(_StructureWidth>=70 and _StructureWidth <= 90)
		--BEGIN
		--SET _WidthRange=dbo.GetPropertyValueIDByValue_PropertyID(104,'70-90')
		--	IF(_WidthRangeStr <> '')
		--	BEGIN
		--	SET _WidthRangeStr = _WidthRangeStr + ','
		--	END
		--SET _WidthRangeStr = _WidthRangeStr + Ltrim(Rtrim(Str(_WidthRange)))
		--END
		--IF(_StructureWidth>=100 and _StructureWidth <= 130)
		--BEGIN
		--SET _WidthRange=dbo.GetPropertyValueIDByValue_PropertyID(104,'100-130')
		--	IF(_WidthRangeStr <> '')
		--	BEGIN
		--	SET _WidthRangeStr = _WidthRangeStr + ','
		--	END
		--SET _WidthRangeStr = _WidthRangeStr + Ltrim(Rtrim(Str(_WidthRange))) 
		--END
		-------------------------------------------------------------------------*/
		call GetWidthRangePropertyValueID_ByWidth(_StructureWidth);
		IF (_ProductName = '')
		then
			SELECT *
			FROM Products
			WHERE ProductID NOT IN (
					SELECT DISTINCT ProductID
					FROM ProductsPropertiesValues
					WHERE (
							(PropertyID = 6)
							AND (PropertyValueID <> _StructureWidthID)
							)
						OR
						/*--Salma : modified in 12-03-2014--added use 101 fabricType instead of 12 MembraneType
						--Salma: modified in 27-03-2014 --using MembraneType that has only 3 values so no need for the like condition
						--old code commented
						--((PropertyID = 101) AND (dbo.GetPropertyValue(_MembraneTypeID) not like dbo.GetPropertyValue(PropertyValueID) +'%'))   OR --membrane type*/
						(
							(PropertyID = 101)
							AND (PropertyValueID <> _MembraneTypeID)
							)
						OR /*--membrane type
						--((PropertyID = 12) AND (PropertyValueID <> _MembraneTypeID))   OR*/
						(
							(PropertyID = 54)
							AND (PropertyValueID <> _InsulationTypeID)
							)
						OR (
							(PropertyID = 7)
							AND (PropertyValueID <> _ISInsulatedID)
							)
						/*--Salma : modified in 30-05-2013--added DefaultBaySpacingProperty*/
						OR (
							(PropertyID = 30)
							AND (
								(_DefaultBaySpacingID IS NOT NULL)
								AND (PropertyValueID <> _DefaultBaySpacingID)
								)
							) -- DefaultBaySpacing
						/*--Ghada : modified in 03-03-2014--added WidthRangeProperty (commented old code)
						--Salma : modified in 06-06-2013--added WidthRangeProperty
						--OR ((PropertyID = 104)  AND (PropertyValueID <> _WidthRange))  -- WidthRange
						-- Salma: modified in 04-03-2014-- added function that returns all PropertyValueID that matches the StructureWidth*/
						OR (
							(PropertyID = 104)
							AND (
								PropertyValueID NOT IN (
									SELECT *
									FROM GetWidthRangePropertyValueID_ByWidth_t
									)
								)
							)/* -- WidthRange*/
					/*	--Salma : modified in 03-07-2013--added IsLatticeProperty*/
						OR (
							(PropertyID = 105)
							AND (PropertyValueID <> _IsLatticeValueID)
							) /*-- is lattice*/
						/*--Salma : modified in 04-07-2013--added SpecialWidthProperty*/
						OR (
							(PropertyID = 106)
							AND (PropertyValueID <> _SpecialWidthValueID)
							) /*-- SpecialWidth*/
						/*--Salma : modified in 14-06-2015--added InsulationPackage*/
						OR (
							(PropertyID = 123)
							AND (PropertyValueID <> _InsulationPackageID)
							)/*--InsulationPackage*/
					)
				/*--Modified by salma on 26-2-2014 to add IsVisible condition*/
				AND IsVisible = 1
			/*	--Modified by salma on 3-4-2014 to hide the following product types when add product from quote 
				--1	Structures
				--2	Membrane
				--3 Insulation
				--12 Engineered Flat Ends
				--13 Engineered Flat Ends Membranes
				--14 Engineered Flat Ends Insulation*/
				AND ProductTypeID NOT IN (
					1
					,2
					,3
					,12
					,13
					,14
					)
			ORDER BY ParentID
				,SortOrder ;
		
		ELSE
		
			SELECT *
			FROM Products
			WHERE ProductID NOT IN (
					SELECT DISTINCT ProductID
					FROM ProductsPropertiesValues
					WHERE (
							(PropertyID = 6)
							AND (PropertyValueID <> _StructureWidthID)
							)
						OR
					/*	--Salma : modified in 12-03-2014--added use 101 fabricType instead of 12 MembraneType
						--Salma: modified in 27-03-2014 --using MembraneType that has only 3 values so no need for the like condition
						--old code commented
						--((PropertyID = 101) AND (dbo.GetPropertyValue(_MembraneTypeID) not like dbo.GetPropertyValue(PropertyValueID) +'%'))   OR --membrane type*/
						(
							(PropertyID = 101)
							AND (PropertyValueID <> _MembraneTypeID)
							)
						OR /*--membrane type
						--((PropertyID = 12) AND (PropertyValueID <> _MembraneTypeID))   OR*/
						(
							(PropertyID = 54)
							AND (PropertyValueID <> _InsulationTypeID)
							)
						OR (
							(PropertyID = 7)
							AND (PropertyValueID <> _ISInsulatedID)
							)
						/*--Salma : modified in 30-05-2013--added DefaultBaySpacingProperty*/
						OR (
							(PropertyID = 30)
							AND (
								(_DefaultBaySpacingID IS NOT NULL)
								AND (PropertyValueID <> _DefaultBaySpacingID)
								)
							) -- DefaultBaySpacing
					/*	--Ghada : modified in 03-03-2014--added WidthRangeProperty (commented old code)
						--Salma : modified in 06-06-2013--added WidthRangeProperty
						--OR ((PropertyID = 104)  AND (PropertyValueID <> _WidthRange))  -- WidthRange
						-- Salma: modified in 04-03-2014-- added function that returns all PropertyValueID that matches the StructureWidth*/
						OR (
							(PropertyID = 104)
							AND (
								PropertyValueID NOT IN (
									SELECT *
									FROM GetWidthRangePropertyValueID_ByWidth_t
									)
								)
							) /*-- WidthRange
						--Salma : modified in 03-07-2013--added IsLatticeProperty*/
						OR (
							(PropertyID = 105)
							AND (PropertyValueID <> _IsLatticeValueID)
							) /*-- is lattice
						--Salma : modified in 04-07-2013--added SpecialWidthProperty*/
						OR (
							(PropertyID = 106)
							AND (PropertyValueID <> _SpecialWidthValueID)
							) /*-- SpecialWidth
						--Salma : modified in 14-06-2015--added InsulationPackage*/
						OR (
							(PropertyID = 123)
							AND (PropertyValueID <> _InsulationPackageID)
							) /*--InsulationPackage*/
					)
				AND Products.ProductName LIKE concat('%',_ProductName,'%')
				/*--Modified by salma on 26-2-2014 to add IsVisible condition*/
				AND IsVisible = 1
			/*	--Modified by salma on 3-4-2014 to hide the following product types when add product from quote 
				--1	Structures
				--2	Membrane
				--3 Insulation
				--12 Engineered Flat Ends
				--13 Engineered Flat Ends Membranes
				--14 Engineered Flat Ends Insulation*/
				AND ProductTypeID NOT IN (
					1
					,2
					,3
					,12
					,13
					,14
					)
			ORDER BY ParentID,SortOrder ;
		
end if;	
END if;
END;
