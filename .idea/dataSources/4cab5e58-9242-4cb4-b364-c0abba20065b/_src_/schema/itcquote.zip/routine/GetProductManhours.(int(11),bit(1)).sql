CREATE FUNCTION itcquote.GetProductManhours(pProductID INT, pIsInsulated BIT)
  RETURNS FLOAT
  BEGIN
	DECLARE vResult FLOAT;
	IF (pIsInsulated = 0)
	then
		SET vResult = GetProductPropertyValue_float(pProductID, 50); -- Note: Manhours propertyID = 50
	
	ELSE
	
		SET vResult = GetProductPropertyValue_float(pProductID, 76) ;-- Note: ManhoursForInsulatedStructures propertyID = 76
		IF (vResult = 0.0)
		then
			SET vResult = GetProductPropertyValue_float(pProductID, 50); -- Note: Manhours propertyID = 50
		end if;
	END if;
	RETURN IFNULL(vResult, 0.0);
END;
