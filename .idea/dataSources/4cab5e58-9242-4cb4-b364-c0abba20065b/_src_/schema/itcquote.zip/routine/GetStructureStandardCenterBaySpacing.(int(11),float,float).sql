CREATE FUNCTION itcquote.GetStructureStandardCenterBaySpacing(pStructureID INT, pCenterBaySpacing FLOAT,
                                                              pSnowRate    FLOAT)
  RETURNS FLOAT
  BEGIN
	DECLARE vResult FLOAT;
	DECLARE vStructureWidth INT;
	DECLARE vSCBS_Special INT;
	SET vSCBS_Special = 15;
	SET vStructureWidth = GetProductPropertyValue_Int(pStructureID, 6);
	SET vResult = GetProductPropertyValue_float(pStructureID, 30);
	SET vResult = IFNULL(vResult, 0.0);
	IF (vStructureWidth = 30)
		AND (pSnowRate > 49) THEN
		SET vResult = vSCBS_Special;
	END IF;
	
	IF (vStructureWidth = 40)
		AND (pSnowRate > 34) THEN
		SET vResult = vSCBS_Special;
	END IF;
	
	IF (vStructureWidth = 50)
		AND (pSnowRate > 24) THEN
		SET vResult = vSCBS_Special;
	END IF;
	
	IF (vResult < pCenterBaySpacing)
	THEN
		SET vResult = pCenterBaySpacing;
	END IF;
	RETURN IFNULL(vResult, 0.0);
END;
