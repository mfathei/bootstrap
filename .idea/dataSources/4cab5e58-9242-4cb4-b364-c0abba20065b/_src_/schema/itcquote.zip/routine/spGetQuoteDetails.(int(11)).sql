CREATE PROCEDURE itcquote.spGetQuoteDetails(IN `_QuoteID` INT)
  BEGIN
 
select QuoteID,creator.LoginName as CreatedBy, creatorContact.ContactName as PreparedBy,Quotes.CreateDate,creatorTerr.TerritoryName as CreatorTerritory,modifier.LoginName as ModifiedBy,ScopeName ,Quotes.Title,Code,
PricingPolicies.PricingPolicyName,SaleTypeID,LeaseTermAID,LeaseTermBID,company.ContactName as Company,
contact.ContactName as Attention,salesRep.ContactName as SalesRep,LeadOriginName,QuoteDuration,
RepTerritory.TerritoryName as RepTerritory,PurchaseTerritory.TerritoryName as PurchaseTerritory,
LandingTerritory.TerritoryName as LandingTerritory,(locationParent.LocationName+','+locations.LocationName) as Location,
(applicationParent.ApplicationName+','+Applications.ApplicationName) as ApplicationName,
ProductName as Structure, PropertiesValues.TheValue as StructureWidth, StructureLength,
insulationType.TheValue as InsulationType, insulationThickness.TheValue as InsulationThickness,
insulationPackage.TheValue as InsulationPackage,membrane.TheValue as MembraneType,
fabricType.TheValue as Membrane,linerColor.TheValue as LinerColor, anchorageMethod.TheValue as AnchorageMethod,
expsoure.TheValue as Expsoure,NoOfFlatEnds,NoOfRoundEnds,NoOfCenterBays,CenterBaySpacing,NoOfCraneBreakPoints,
NoOfToolsSets,WindRate,WindKPA,WindKPH,WindMPH,SnowRate,IsExported,IsMiddleEast,NoOfTechConsultants,IsAdditionToExistingStructure,
ProvideOpaqueMembrane,ProvideTensionCable,ProvideConduitHoles,(DevelopmentManagers.FirstName+' '+DevelopmentManagers.LastName) as CompletedFor,
IsShippedFromBahrin,IsShippedFromUS,IsShippedToGulfState,IsMilitary,Notes,IsSnowLoad
from Quotes
inner join Accounts creator on creator.AccountID=Quotes.CreateAccountID 
inner join Territories creatorTerr on creator.TerritoryID=creatorTerr.TerritoryID
LEFT  join Contacts creatorContact on creator.ContactID=creatorContact.ContactID
left  join Accounts modifier on Quotes.ModifyAccountID=modifier.AccountID 
left  join Scopes on Quotes.ScopeID=Scopes.ScopeID
left  join PricingPolicies on Quotes.PricingPolicyID=PricingPolicies.PricingPolicyID
left  join Contacts  company on quotes.CompanyID=company.ContactID and company.ContactTypeID=1
left  join Contacts  contact on Quotes.AttentionID=contact.ContactID
left  join Contacts  salesRep on Quotes.SalesRepID=salesRep.ContactID and salesRep.ContactTypeID=4
left  join LeadOrigins on Quotes.LeadOriginID=LeadOrigins.LeadOriginID
left  join Territories RepTerritory on Quotes.RepTerritoryID=RepTerritory.TerritoryID
left  join Territories PurchaseTerritory on Quotes.PurchaseTerritoryID=PurchaseTerritory.TerritoryID
left  join Territories LandingTerritory on Quotes.LandingTerritoryID=LandingTerritory.TerritoryID
left  join Locations on Quotes.LocationID=Locations.LocationID
left  join Locations locationParent on Locations.ParentID=locationParent.LocationID
left  join Applications on Quotes.ApplicationID=Applications.ApplicationID
left  join Applications applicationParent on Applications.ParentID=applicationParent.ApplicationID
left  join Products on Quotes.StructureID=Products.ProductID and Products.ProductTypeID=1
left  join ProductsPropertiesValues on Products.ProductID=ProductsPropertiesValues.ProductID and ProductsPropertiesValues.PropertyID=6
left  join PropertiesValues on PropertiesValues.PropertyValueID=ProductsPropertiesValues.PropertyValueID
left  join PropertiesValues insulationType on Quotes.InsulationTypeID=insulationType.PropertyValueID and insulationType.PropertyID=54
left  join PropertiesValues insulationThickness on Quotes.InsulationThicknessID=insulationThickness.PropertyValueID and insulationThickness.PropertyID=49
left  join PropertiesValues insulationPackage on Quotes.InsulationPackageID=insulationPackage.PropertyValueID and insulationPackage.PropertyID=123
left  join PropertiesValues membrane on Quotes.MembraneTypeID=membrane.PropertyValueID and membrane.PropertyID=101
left  join PropertiesValues fabricType on Quotes.FabricTypeID=fabricType.PropertyValueID and fabricType.PropertyID=12
left  join PropertiesValues linerColor on Quotes.MembraneColorID=linerColor.PropertyValueID and linerColor.PropertyID=55
left  join PropertiesValues anchorageMethod on Quotes.AnchorageID=anchorageMethod.PropertyValueID and anchorageMethod.PropertyID=56
left  join PropertiesValues expsoure on Quotes.ExposureID=expsoure.PropertyValueID and expsoure.PropertyID=58
left  join DevelopmentManagers on Quotes.CompletedByAccountID=DevelopmentManagers.ManagerID
Where QuoteID=_QuoteID;
END;
