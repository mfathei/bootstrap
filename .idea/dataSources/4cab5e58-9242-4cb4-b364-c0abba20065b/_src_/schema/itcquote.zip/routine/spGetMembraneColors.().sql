CREATE PROCEDURE itcquote.spGetMembraneColors()
  BEGIN
                                
	call spGetPropertyValues (13);
END;
