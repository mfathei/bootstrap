CREATE FUNCTION itcquote.GetDefaultStructureLength(pStructureWidth INT, pStructureLength INT, pNoOfFlatEnds INT,
                                                   pNoOfRoundEnds  INT, pNoOfCenterBays INT, pCenterBaySpacing INT)
  RETURNS INT
  BEGIN
	--  Declare the return variable here
	DECLARE vResult INT;
	--  Add the T-SQL statements to compute the return value here
	SET vResult = pStructureWidth + pStructureLength;
	--  Return the result of the function
	RETURN vResult;
END;
