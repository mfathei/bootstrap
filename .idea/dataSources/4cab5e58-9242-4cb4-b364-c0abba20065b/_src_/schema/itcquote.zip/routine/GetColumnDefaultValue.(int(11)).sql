CREATE FUNCTION itcquote.GetColumnDefaultValue(pColumnID INT)
  RETURNS VARCHAR(21844)
  BEGIN
	DECLARE vResult VARCHAR(21844) CHARSET utf8;
	SET vResult = N'Equivalent quote result from (Quote Expert)
-- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- 	
#Men: 
#Days: 
Frieght Cost: 
Technical Cost: 
Eng. FlatEnd: 
Accessories Sale: 
Accessories Lease A: 
Accessories Lease B: 
Sale: 
Lease A: 
Lease B: 
Comments by Ross:
-- -- -- -- -- -- -- -- -- -- 
Comments by Mahmoud:
-- -- -- -- -- -- -- -- -- -- -
';
	-- SET vResult GetClauseWording(0, 'QuoteNotesDefaultValue', 1)
	-- SELECT vResult = Notes FROM Quotes WHERE QuoteID = 3
	RETURN vResult;
END;
