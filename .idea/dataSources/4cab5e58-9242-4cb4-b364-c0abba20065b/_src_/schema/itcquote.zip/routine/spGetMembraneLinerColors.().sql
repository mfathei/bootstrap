CREATE PROCEDURE itcquote.spGetMembraneLinerColors()
  BEGIN
                                
	call spGetPropertyValues (55);
END;
