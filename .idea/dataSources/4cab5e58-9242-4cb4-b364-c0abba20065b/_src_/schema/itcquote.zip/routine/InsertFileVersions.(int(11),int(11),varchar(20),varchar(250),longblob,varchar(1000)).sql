CREATE PROCEDURE itcquote.InsertFileVersions(IN FileTypeID     INT, IN FileID INT, IN FileVersion VARCHAR(20),
                                             IN VersionCaption VARCHAR(250), IN FileContent LONGBLOB,
                                             IN Notes          VARCHAR(1000))
  BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	/*SET NOCOUNT ON;*/
	
	Insert into FilesVersions 
	(
		FileTypeID,
		FileID,
		FileVersion,
		VersionCaption,
		FileContent,
		Notes
	)
	values
	(
		FileTypeID,
		FileID,
		FileVersion,
		VersionCaption,
		FileContent,
		Notes
	);
END;
