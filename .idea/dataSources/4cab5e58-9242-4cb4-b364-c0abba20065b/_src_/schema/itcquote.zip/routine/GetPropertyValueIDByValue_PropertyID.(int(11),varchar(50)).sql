CREATE FUNCTION itcquote.GetPropertyValueIDByValue_PropertyID(pPropertyID INT, pTheValue VARCHAR(50))
  RETURNS INT
  BEGIN
	-- Declare the return variable here
	DECLARE vResult INT;
	-- Add the T-SQL statements to compute the return value here
	SELECT PropertyValueID into vResult 
	FROM PropertiesValues
	WHERE (PropertyID = pPropertyID)
		AND (TheValue = pTheValue);
	IF vResult IS NULL
	then
		SET vResult = 0;
    END IF;
    
	-- Return the result of the function
	RETURN vResult;
END;
