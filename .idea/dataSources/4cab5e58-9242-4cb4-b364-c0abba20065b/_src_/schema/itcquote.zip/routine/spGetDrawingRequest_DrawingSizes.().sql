CREATE PROCEDURE itcquote.spGetDrawingRequest_DrawingSizes()
  BEGIN
	
  call spGetPropertyValues_ByName ('DrawingRequest_DrawingSizes');
END;
