CREATE PROCEDURE itcquote.fnGetStatus(IN pGroupID INT)
  BEGIN
drop temporary table if exists fnGetStatus_t;
create temporary table fnGetStatus_t(
	StatusID int NOT NULL
	,StatusName VARCHAR(100)
	);
	-- Drawing Status
	IF (pGroupID = 1)
	then
		INSERT INTO fnGetStatus_t (
			StatusID
			,StatusName
			)
		VALUES (
			1
			,'Open'
			);
		INSERT INTO fnGetStatus_t (
			StatusID
			,StatusName
			)
		VALUES (
			3
			,'Finished'
			);
	END if;
	-- Drawing Request Status
	IF (pGroupID = 2)
	then
		INSERT INTO fnGetStatus_t (
			StatusID
			,StatusName
			)
		VALUES (
			1
			,'Open'
			);
		-- Salma Modified on 28-4-2015 added Submitted Status
		INSERT INTO fnGetStatus_t (
			StatusID
			,StatusName
			)
		VALUES (
			6
			,'Submitted'
			);
		INSERT INTO fnGetStatus_t (
			StatusID
			,StatusName
			)
		VALUES (
			4
			,'Acknowledged'
			);
		-- Salma Modified on 13-7-2015 added In Progress Status
		INSERT INTO fnGetStatus_t (
			StatusID
			,StatusName
			)
		VALUES (
			5
			,'In Progress'
			);
		INSERT INTO fnGetStatus_t (
			StatusID
			,StatusName
			)
		VALUES (
			3
			,'Finished'
			);
		INSERT INTO fnGetStatus_t (
			StatusID
			,StatusName
			)
		VALUES (
			2
			,'Cancel'
			);
			-- Salma Modified on 22-4-2015 added Closed Status
			-- Salma Modified on 13-5-2015 removed Closed Status
			-- INSERT INTO fnGetStatus_t (StatusID,StatusName) VALUES  ( 5,'Closed')
	END if;
END;
