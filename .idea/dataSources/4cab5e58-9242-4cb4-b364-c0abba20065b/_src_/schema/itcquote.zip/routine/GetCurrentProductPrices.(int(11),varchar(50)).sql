CREATE PROCEDURE itcquote.GetCurrentProductPrices(IN pProduct INT, IN pyear VARCHAR(50))
  BEGIN
SELECT ProductsPrices.ProductID
	,ProductsPrices.Price
	,PricingPolicies.PricingPolicyName
	,PricingTypes.PricingTypeName
FROM Products
INNER JOIN ProductsPrices ON Products.ProductID = ProductsPrices.ProductID
INNER JOIN PricingPolicies ON ProductsPrices.PricingPolicyID = PricingPolicies.PricingPolicyID
INNER JOIN PricingTypes ON ProductsPrices.PricingTypeID = PricingTypes.PricingTypeID
WHERE (
		(REVERSE(SUBSTRING(REVERSE(PricingPolicies.PricingPolicyName), 0, CHARINDEX('_', REVERSE(PricingPolicies.PricingPolicyName)))) = '')
		OR (REVERSE(SUBSTRING(REVERSE(PricingPolicies.PricingPolicyName), 0, CHARINDEX('_', REVERSE(PricingPolicies.PricingPolicyName)))) > pyear)
		)
	AND (ProductsPrices.ProductID = pProduct);
END;
