CREATE PROCEDURE itcquote.spGetQuoteItemsByQuoteID(IN `_QuoteID` INT)
  BEGIN
	SELECT ProductID
      ,ItemName
      ,RelatedProductID
      ,ItemTypeID
      ,IsAutoAdded
      ,IsDisplayedInReports
      ,IsQuantityDisplayedInReports
      ,Quantity
      ,OriginalSalePrice
      ,OriginalLeaseTermAPrice
      ,OriginalLeaseTermBPrice
      ,OriginalManhours
      ,CustomSalePrice
      ,CustomLeaseTermAPrice
      ,CustomLeaseTermBPrice
      ,CustomManhours
      ,Notes AS QINotes
      ,Description
      ,RequiredLength
      ,NoOfConnectedStructures
      ,WallsCount
      ,InstancesNo
      ,AI
   FROM QuotesItems
where QuoteID=_QuoteID
ORDER BY ItemName;
END;
