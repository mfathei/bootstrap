CREATE FUNCTION itcquote.getAllLocationParents(`$location_id` VARCHAR(50))
  RETURNS TEXT
  BEGIN
	declare result text default '';
    set @local_parent_id = $location_id;
	myloop: loop
		set @local_parent_id = (select parent_id from location where location_id = @local_parent_id);
        if @local_parent_id is null then
			leave myloop;
        end if;
        
        set result = concat(result , @local_parent_id, ",");
    end loop;
    
    set result = SUBSTR(result, 1, LENGTH(result)- 1);   
RETURN result;
END;
