CREATE FUNCTION itcquote.GetProductPropertyValue_float(pProductID INT, pPropertyID INT)
  RETURNS FLOAT
  BEGIN
	DECLARE vResult FLOAT;
	SELECT CAST(PropertiesValues.TheValue AS DECIMAL(10,2)) INTO vResult
	FROM ProductsPropertiesValues
	INNER JOIN PropertiesValues ON ProductsPropertiesValues.PropertyValueID = PropertiesValues.PropertyValueID
	WHERE (ProductsPropertiesValues.ProductID = pProductID)
		AND (ProductsPropertiesValues.PropertyID = pPropertyID);
	RETURN IFNULL(vResult, 0.0);
END;
