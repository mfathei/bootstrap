CREATE PROCEDURE itcquote.spAddPropertyType(IN  `_PropertyTypeName` VARCHAR(50), IN `_Description` VARCHAR(1000),
                                            OUT `_PropertyTypeID`   INT)
  begin
INSERT into PropertiesTypes (PropertyTypeName,Description )
VALUES(_PropertyTypeName,_Description);
SELECT LAST_INSERT_ID() into _PropertyTypeID ;
end;
