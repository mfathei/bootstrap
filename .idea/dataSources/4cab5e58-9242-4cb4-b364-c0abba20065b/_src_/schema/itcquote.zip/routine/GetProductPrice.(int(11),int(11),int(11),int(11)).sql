CREATE FUNCTION itcquote.GetProductPrice(pProductID INT, pPricingPolicyID INT, pPurchaseTypeID INT, pLeaseTerm INT)
  RETURNS DECIMAL(10, 2)
  BEGIN
	DECLARE vResult decimal(10, 2);
	DECLARE pMonthlyLeasePrice decimal(10, 2);
	DECLARE pSingleMonthLeasePrice decimal(10, 2);
	DECLARE p24MonthsLeasePrice decimal(10, 2);
		-- Salma: Modified in 19-3-2013 -- to add Lease Fixed Under 12M-- -- 
	DECLARE pLeaseFixedUnder12M decimal(10, 2);
		-- Salma: Modified in 06-07-2014 -- if result > price of 1 or 2 year take 1 or 2 year price-- -- 	
	DECLARE p12MonthsLeasePrice decimal(10, 2);
	IF pPurchaseTypeID = 1
	then -- get sale price
		SELECT Price into vResult 
		FROM ProductsPrices
		WHERE (ProductID = pProductID)
			AND (PricingPolicyID = pPricingPolicyID)
			AND (PricingTypeID = 1);
		SET vResult = IFNULL(vResult, 0);
			-- lease price calculation
	ELSE
		IF (pLeaseTerm = 0)
		then
			SET vResult = 0;
			RETURN vResult;
		END if;
		-- get Fixed Lease price
		SELECT ProductsPrices.Price into vResult 
		FROM ProductsPrices
		INNER JOIN PricingTypes ON ProductsPrices.PricingTypeID = PricingTypes.PricingTypeID
		WHERE (ProductsPrices.ProductID = pProductID)
			AND (ProductsPrices.PricingPolicyID = pPricingPolicyID)
			AND (PricingTypes.PurchaseTypeID = 4) limit 1;
		SET vResult = IFNULL(vResult, 0);
		IF (vResult = 0)
		then -- get Lease Monthly price
			SELECT ProductsPrices.Price into pMonthlyLeasePrice 
			FROM ProductsPrices
			INNER JOIN PricingTypes ON ProductsPrices.PricingTypeID = PricingTypes.PricingTypeID
			WHERE (ProductsPrices.ProductID = pProductID)
				AND (ProductsPrices.PricingPolicyID = pPricingPolicyID)
				AND (PricingTypes.PurchaseTypeID = 5) limit 1;
			SET pMonthlyLeasePrice = IFNULL(pMonthlyLeasePrice, 0);
			-- Salma: Modified in 19-3-2013 -- get Lease Fixed Under 12M value-- -- 
			SELECT ProductsPrices.Price into pLeaseFixedUnder12M 
			FROM ProductsPrices
			INNER JOIN PricingTypes ON ProductsPrices.PricingTypeID = PricingTypes.PricingTypeID
			WHERE (ProductsPrices.ProductID = pProductID)
				AND (ProductsPrices.PricingPolicyID = pPricingPolicyID)
				AND (PricingTypes.PurchaseTypeID = 6) limit 1;
			SET pLeaseFixedUnder12M = IFNULL(pLeaseFixedUnder12M, 0);
			-- Salma: Modified in 19-3-2013 -- add Lease Fixed Under 12M to the condition-- -- 
			IF (
					pLeaseFixedUnder12M = 0
					AND (
						pMonthlyLeasePrice <> 0
						AND pLeaseTerm > 1
						AND pLeaseTerm < 12
						)
					)
			then
				SELECT ProductsPrices.Price into pSingleMonthLeasePrice 
				FROM ProductsPrices
				INNER JOIN PricingTypes ON ProductsPrices.PricingTypeID = PricingTypes.PricingTypeID
				WHERE (ProductsPrices.ProductID = pProductID)
					AND (ProductsPrices.PricingPolicyID = pPricingPolicyID)
					AND (PricingTypes.PurchaseTypeID = 2)
					AND (PricingTypes.PriceTerm = 1) limit 1;
				SET pSingleMonthLeasePrice = IFNULL(pSingleMonthLeasePrice, 0);
				SET vResult = pSingleMonthLeasePrice + (pLeaseTerm - 1) * pMonthlyLeasePrice;
			
			ELSE
			
				-- Salma: Modified in 19-3-2013 -- get prices based on Lease Fixed Under 12M value-- -- 
				IF (
						pLeaseFixedUnder12M <> 0
						AND pLeaseTerm > 0
						AND pLeaseTerm < 12
						)
				then
					SELECT ProductsPrices.Price into pSingleMonthLeasePrice
					FROM ProductsPrices
					INNER JOIN PricingTypes ON ProductsPrices.PricingTypeID = PricingTypes.PricingTypeID
					WHERE (ProductsPrices.ProductID = pProductID)
						AND (ProductsPrices.PricingPolicyID = pPricingPolicyID)
						AND (PricingTypes.PurchaseTypeID = 2)
						AND (PricingTypes.PriceTerm = 1) limit 1;
					SET pSingleMonthLeasePrice = IFNULL(pSingleMonthLeasePrice, 0);
					IF (
							pSingleMonthLeasePrice <> 0
							AND pLeaseTerm = 1
							)
					then
						SET vResult = IFNULL(pSingleMonthLeasePrice, 0);
					
					ELSE
					
						SET vResult = IFNULL(pLeaseFixedUnder12M, 0);
					END if;
				
				ELSE
				
					SELECT pLeaseTerm * ProductsPrices.Price / PricingTypes.PriceTerm into vResult
					FROM ProductsPrices
					INNER JOIN PricingTypes ON ProductsPrices.PricingTypeID = PricingTypes.PricingTypeID
					WHERE (ProductsPrices.ProductID = pProductID)
						AND (ProductsPrices.PricingPolicyID = pPricingPolicyID)
						AND (PricingTypes.PurchaseTypeID = 2)
						AND (PricingTypes.PriceTerm <= pLeaseTerm)
					ORDER BY PricingTypes.PriceTerm DESC limit 1;
					SET vResult = IFNULL(vResult, 0);
				END if;
			END if;
			-- Salma: Modified in 06-07-2014 -- if result > price of 1 or 2 year take 1 or 2 year price-- -- 	
			IF (pLeaseTerm > 0)
				AND (pLeaseTerm < 12)
			then
				SELECT ProductsPrices.Price into p12MonthsLeasePrice
				FROM ProductsPrices
				INNER JOIN PricingTypes ON ProductsPrices.PricingTypeID = PricingTypes.PricingTypeID
				WHERE (ProductsPrices.ProductID = pProductID)
					AND (ProductsPrices.PricingPolicyID = pPricingPolicyID)
					AND (PricingTypes.PurchaseTypeID = 2)
					AND (PricingTypes.PriceTerm = 12) limit 1;
				SET p12MonthsLeasePrice = IFNULL(p12MonthsLeasePrice, 0);
				IF (p12MonthsLeasePrice <> 0)
					AND (vResult > p12MonthsLeasePrice)
				then
					SET vResult = p12MonthsLeasePrice;
				END if;
			END if;
			IF (pLeaseTerm > 12)
				AND (pLeaseTerm < 24)
			then
				SELECT ProductsPrices.Price into p24MonthsLeasePrice
				FROM ProductsPrices
				INNER JOIN PricingTypes ON ProductsPrices.PricingTypeID = PricingTypes.PricingTypeID
				WHERE (ProductsPrices.ProductID = pProductID)
					AND (ProductsPrices.PricingPolicyID = pPricingPolicyID)
					AND (PricingTypes.PurchaseTypeID = 2)
					AND (PricingTypes.PriceTerm = 24) limit 1;
				SET p24MonthsLeasePrice = IFNULL(p24MonthsLeasePrice, 0);
				IF (p24MonthsLeasePrice <> 0)
					AND (vResult > p24MonthsLeasePrice)
				then
					SET vResult = p24MonthsLeasePrice;
				END if;
			END if;
		END if;
	END if;
	RETURN vResult;
END;
