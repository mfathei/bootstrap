CREATE PROCEDURE itcquote.spGetDrawingRequests(IN `_AccountID` INT, IN `_TerritoryID` INT)
  BEGIN
	
	DECLARE _StatusGroupID int;
/*	--Modified by salma 22-3-2015 make added conditions for Isadmin to allow Admins to view all DrawingRequests even Private and added scope conditions*/
	DECLARE _IsAdmin int(1);
	SET _StatusGroupID = 2;
	SET _IsAdmin = (
			SELECT IsAdmin
			FROM Accounts
			WHERE AccountID = _AccountID);
	drop TEMPORARY TABLE if exists	 xx;
    CREATE TEMPORARY TABLE  xx AS (select fnGetStatus(@StatusGroupID) );
	
	SELECT DrawingRequests.DrawingRequestID
		,DrawingRequests.Caption
		,DrawingRequests.CreateDate
		,DrawingRequests.StatusID
		,tbStatus.StatusName
		,DrawingRequests.Comments
		,tbDrawingsCount.DrawingsCount
		,DrawingRequests.CreateAccountID
		,DrawingRequests.ModifyAccountID
		,DrawingRequests.ModifyDate
		,DrawingRequests.AttentionID
		,DrawingRequests.CompletedForID
		,DrawingRequests.ScopeID
		,DrawingRequests.QuoteID
		,DrawingRequests.ReferenceDrawingRequestID
		,DrawingRequests.SendToID
		,DrawingRequests.SendViaID
		,DrawingRequests.DrawingTypeID
		,DrawingRequests.DrawingCategoryID
		,DrawingRequests.DrawingSizeID
		,DrawingRequests.DrawingUnitID
		,DrawingRequests.DeliveryPoint
		,DrawingRequests.RequestedDeliveryDate
		,DrawingRequests.PromisedDeliveryDate
		,DrawingRequests.IsStamped
		,DrawingRequests.NoOfCopies
		,
		/*--Modified by salma 19-4-2015 added calling to function to get DwgNum of drawings related to this drawing Request*/
        getDrawingsNumForDrawingRequest(DrawingRequests.DrawingRequestID) AS DrawingNum
	FROM DrawingRequests
	INNER JOIN Accounts ON DrawingRequests.CreateAccountID = Accounts.AccountID
	LEFT  JOIN (
		SELECT DrawingRequests_1.DrawingRequestID
			,COUNT(*) AS DrawingsCount
		FROM DrawingRequests AS DrawingRequests_1
		INNER JOIN Drawings ON DrawingRequests_1.DrawingRequestID = Drawings.DrawingRequestID
		GROUP BY DrawingRequests_1.DrawingRequestID
		) AS tbDrawingsCount ON DrawingRequests.DrawingRequestID = tbDrawingsCount.DrawingRequestID
	LEFT  JOIN xx AS tbStatus ON DrawingRequests.StatusID = tbStatus.StatusID
	/*--WHERE     
	--(DrawingRequests.CreateAccountID = @AccountID)
	--AND(Accounts.TerritoryID = @TerritoryID) */
	WHERE (
			(DrawingRequests.ScopeID = 1)
			AND (
				DrawingRequests.CreateAccountID = _AccountID
				OR _IsAdmin = 1
				)
			)
		OR (
			(DrawingRequests.ScopeID = 2)
			AND (
				(
					DrawingRequests.CreateAccountID IN (
						SELECT AccountID
						FROM Accounts
						WHERE TerritoryID = _TerritoryID
						)
					)
				OR (_IsAdmin = 1)
				)
			)
		OR ((DrawingRequests.ScopeID IS NULL))
		OR ((DrawingRequests.CreateAccountID IS NULL))
		OR ((DrawingRequests.ScopeID = 3));
END;
