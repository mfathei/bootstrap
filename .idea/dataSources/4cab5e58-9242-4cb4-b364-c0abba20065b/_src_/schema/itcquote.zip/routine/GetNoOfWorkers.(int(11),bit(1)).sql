CREATE FUNCTION itcquote.GetNoOfWorkers(pStructureID INT, pIsMiddleEast BIT)
  RETURNS INT
  BEGIN
	DECLARE vResult INT;
	SET vResult = GetProductPropertyValue_Int(pStructureID, 68);
	IF pIsMiddleEast = 1
	then
		SET vResult = vResult + 2;
	END if;
	RETURN IFNULL(vResult, 0);
END;
