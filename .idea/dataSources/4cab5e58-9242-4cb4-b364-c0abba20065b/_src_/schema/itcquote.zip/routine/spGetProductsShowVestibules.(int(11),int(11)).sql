CREATE PROCEDURE itcquote.spGetProductsShowVestibules(IN `_QuoteID` INT, IN `_ProductTypeID` INT)
  BEGIN
    DECLARE _StructureID , _StructureWidthID , _MembraneTypeID ,_InsulationTypeID ,_ISInsulatedID ,_StructureWidth 
	,_WidthRange ,_IsLatticeValueID 	,_SpecialWidthValueID    ,_InsulationPackageID int;
	-- Salma : modified in 30-05-2013--added CenterBaySpacing, DefaultByaSpacingID
	
	-- Salma : modified in 06-06-2013--get structure width and widthrange property
	
	-- Ghada : modified in 03-03-2014--get structure width and widthrange property (should be more generic)
	
	-- Salma : modified in 03-07-2013--added IsLattice
	
	-- Salma : modified in 04-07-2013--added SpecialWidth
	  -- Salma : modified in 14-06-2015--added InsulationPackage
 
    declare _WidthRangeStr , _CenterBaySpacing  varchar(50);
	declare _DefaultBaySpacingID varchar(50);
    if _QuoteID=null or _QuoteID='' then set _QuoteID =-1 ; end if;
 
 
	SELECT 
		 StructureID,InsulationTypeID, MembraneTypeID,CenterBaySpacing,InsulationPackageID 
         into
		 _StructureID,_InsulationTypeID ,_MembraneTypeID ,_CenterBaySpacing,_InsulationPackageID
   
	/*	--Salma : modified in 30-05-2013--added DefaultBaySpacing=CenterBayScpaing*/
		
		/*--Salma : modified in 14-06-2015--added InsulationPackage*/
        
	FROM Quotes WHERE QuoteID = _QuoteID;
    SET _StructureWidthID = dbo.GetProductPropertyValueID(_StructureID, 6);
    
  /*  --Salma: modified in 03-07-2013 --get IslatticeValueId for selected Structure Product*/
    SET _IsLatticeValueID = dbo.GetProductPropertyValueID(_StructureID, 105);
   /*  --Salma: modified in 04-07-2013 --get SpecialWidthValueId for selected Structure Product*/
    SET _SpecialWidthValueID = dbo.GetProductPropertyValueID(_StructureID, 106);
    SET _ISInsulatedID = dbo.GetIsInsulatedID(_InsulationTypeID);
    
  /*  --Salma : modified in 30-05-2013--get DefaultBaySpacingID*/
    if(_CenterBaySpacing IS NOT NULL)
    then
    SET _DefaultBaySpacingID = dbo.GetPropertyValueIDByValue_PropertyID(30,_CenterBaySpacing);
    
    Else
    
    SET _DefaultBaySpacingID =NULL;
	SET _StructureWidth = dbo.GetProductPropertyValue_Int(_StructureID, 6);
    call GetWidthRangePropertyValueID_ByWidth(_StructureWidth);
    SELECT * FROM Products 
    WHERE   
          ProductID NOT IN (
          SELECT DISTINCT ProductID
          FROM ProductsPropertiesValues 
          WHERE 
          ((PropertyID = 6)  AND (PropertyValueID <> _StructureWidthID)) OR -- width
          ((PropertyID = 101) AND (PropertyValueID <> _MembraneTypeID))   OR -- membrane type
          ((PropertyID = 54) AND (PropertyValueID <> _InsulationTypeID)) OR -- insulation type
          ((PropertyID = 7)  AND (PropertyValueID <> _ISInsulatedID))       -- is insulated
          OR ((PropertyID = 30)  AND ((_DefaultBaySpacingID  IS NOT NULL) AND (PropertyValueID<>_DefaultBaySpacingID)))  -- DefaultBaySpacing
              OR ((PropertyID = 104)  AND (PropertyValueID not in (SELECT * FROM GetWidthRangePropertyValueID_ByWidth_t)))  -- WidthRange
          OR ((PropertyID = 105)  AND (PropertyValueID <> _IsLatticeValueID))  -- is lattice
          OR ((PropertyID = 106) AND (PropertyValueID <> _SpecialWidthValueID))  -- SpecialWidth/BeamSize
             -- Salma : modified in 14-06-2015--added InsulationPackage
		  OR ((PropertyID = 123) AND (PropertyValueID <> _InsulationPackageID))  -- InsulationPackage
       )
		AND ProductID IN (
          SELECT DISTINCT ProductID
          FROM ProductsPropertiesValues
          WHERE ((PropertyID = 115 ) AND (PropertyValueID = 654) ) 
          )
          AND IsVisible =1  
      /*    
         --Modified by salma on 3-4-2014 to hide the following product types when add product from quote 
		--1	Structures
		--2	Membrane
		--3 Insulation
		--12 Engineered Flat Ends
		--13 Engineered Flat Ends Membranes
		--14 Engineered Flat Ends Insulation*/
       and ProductTypeID NOT IN (1,2,3,12,13,14) 
       AND((_ProductTypeID!=0 AND _ProductTypeID=ProductTypeID) )
    
      
    ORDER BY ParentID, SortOrder;
  END if;
END;
