CREATE PROCEDURE itcquote.GetTerritoriesByPricingPolicy(IN pricingPolicyID INT)
  BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	/*SET NOCOUNT ON;*/
IF ((select count(PricingPolicyID) from Territory_PricingPolicy where PricingPolicyID=@PricingPolicyID)  > 0)
then 
    -- Insert statements for procedure here
	select *
	from Territories
	inner join Territory_PricingPolicy on (Territories.TerritoryID=Territory_PricingPolicy.TerritoryID
	AND Territory_PricingPolicy.PricingPolicyID=@pricingPolicyID)
	ORDER BY TerritoryName;
ELSE
	select *
	from Territories
	ORDER BY TerritoryName;
END if;
END;
