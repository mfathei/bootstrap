CREATE PROCEDURE itcquote.spUpdateProductProperties(IN pProductID INT, IN pProductTypeID INT)
  BEGIN
	-- Insert statements for procedure here
	DELETE
	FROM ProductsPropertiesValues
	WHERE (ProductID = pProductID)
		AND (
			PropertyID NOT IN (
				SELECT PropertyID
				FROM ProductsTypesProperties
				WHERE (ProductTypeID = pProductTypeID)
				)
			);
	UPDATE ProductsPropertiesValues
	SET ProductTypeID = pProductTypeID
	WHERE (ProductID = pProductID);
	INSERT INTO ProductsPropertiesValues (
		ProductID
		,ProductTypeID
		,PropertyID
		)
	SELECT pProductID
		,pProductTypeID
		,PropertyID
	FROM ProductsTypesProperties
	WHERE (ProductTypeID = pProductTypeID)
		AND (
			PropertyID NOT IN (
				SELECT PropertyID
				FROM ProductsPropertiesValues
				WHERE (ProductID = pProductID)
				)
			);
END;
