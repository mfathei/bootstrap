CREATE PROCEDURE itcquote.spGetAccountDrawingRequests(IN `_statesID` INT, IN `_AccountID` INT, IN `_TerritoryID` INT)
  BEGIN
	
	SELECT *
		,GetDrawingsCount(DrawingRequestID, _AccountID, _TerritoryID) as calls
	FROM DrawingRequests
	WHERE (
			(_statesID = 0)
			OR (StatusID = _statesID)
			)
		AND (
			(
				(ScopeID = 1)
				AND (CreateAccountID = _AccountID)
				)
			OR (
				(ScopeID = 2)
				AND (
					CreateAccountID IN (
						SELECT AccountID
						FROM Accounts
						WHERE TerritoryID = _TerritoryID
						)
					)
				)
			OR ((ScopeID = 3))
			);
end;
