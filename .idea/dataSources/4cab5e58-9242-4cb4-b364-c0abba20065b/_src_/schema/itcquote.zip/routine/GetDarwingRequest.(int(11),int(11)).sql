CREATE PROCEDURE itcquote.GetDarwingRequest(IN `_DrawingRequestID` INT, IN `_QuotaID` INT)
  begin
call GetQuoteDrawingRequestsReport(_DrawingRequestID);
call GetQuoteReport(_QuotaID,2);
DROP TEMPORARY TABLE IF EXISTS GetDarwingRequest_t;
    CREATE TEMPORARY TABLE GetDarwingRequest_t as(
    	SELECT   
convert(replace(date_format(now(),'%d %m %Y'),'-','/'),char(50))as CurrentDate,  
ifnull(Drawingrequest.ContactName,'') as ContactName,
ifnull(Drawingrequest.Address,'') as Address,
ifnull(Drawingrequest.Zip,'') as Zip,
ifnull(Drawingrequest.PhoneNo,'') as PhoneNo ,
ifnull(Drawingrequest.MobileNo,'') as MobileNo,
ifnull(Drawingrequest.Fax,'') as Fax,
ifnull(Drawingrequest.Email,'') as Email,
ifnull(Drawingrequest.WebSite,'') as  WebSite,
ifnull(Drawingrequest.DrawingRequestID,'') as DrawingRequestID,
ifnull(Drawingrequest.CreateAccountID,'') as CreateAccountID,
ifnull(Drawingrequest.CreateDate,'') as CreateDate,
ifnull(Drawingrequest.ModifyAccountID,'') as ModifyAccountID,
ifnull(Drawingrequest.ModifyDate,'') as ModifyDate,
ifnull(Drawingrequest.ScopeID,'') as ScopeID,
ifnull(Drawingrequest.QuoteID,'') as QuoteID,
ifnull(Drawingrequest.ReferenceDrawingRequestID,'') as ReferenceDrawingRequestID,
ifnull(Drawingrequest.SendToID,'') as SendToID,
ifnull(Drawingrequest.SendViaID,'') as SendViaID,
ifnull(Drawingrequest.DrawingTypeID,'') as DrawingTypeID, 
ifnull(Drawingrequest.DrawingSizeID,'') as DrawingSizeID, 
ifnull(Drawingrequest.DrawingUnitID,'') as DrawingUnitID, 
ifnull(Drawingrequest.DeliveryPoint,'') as DeliveryPoint, 
	-- Salma Modified on 22 march 2015 added requested date & delivery date instead of expected date
ifnull(Convert( date_format(dateDrawingrequest.RequestedDeliveryDate,'%d %m %Y'),char),'') as RequestedDeliveryDate, 
ifnull(Convert(date_format(Drawingrequest.PromisedDeliveryDate,'%d %m %Y'),char),'') as PromisedDeliveryDate, 
ifnull(Drawingrequest.IsStamped,'') as IsStamped, 
ifnull(Drawingrequest.NoOfCopies,'') as NoOfCopies, 
ifnull(Drawingrequest.StatusID,'') as StatusID, 
ifnull(Drawingrequest.Caption,'') as Caption, 
ifnull(Drawingrequest.Comments,'') as Comments, 
ifnull(Drawingrequest.ContactID,'') as ContactID, 
ifnull(Drawingrequest.SendTo,'') as SendTo, 
ifnull(Drawingrequest.SendVia,'') as SendVia, 
ifnull(Drawingrequest.DrawingType,'') as DrawingType, 
ifnull(Drawingrequest.DrawingSize,'') as DrawingSize, 
ifnull(Drawingrequest.DrawingUnit,'') as DrawingUnit, 
ifnull(Quotes_DrawingRequest.Attention,'') as Attention, 
ifnull(Quotes_DrawingRequest.StructureWidth,'') as StructureWidth, 
ifnull(Quotes_DrawingRequest.StructureLength,'') as StructureLength, 
ifnull(Quotes_DrawingRequest.StructureSQFT,'') as StructureSQFT, 
ifnull(Quotes_DrawingRequest.Location,'') as Location, 
ifnull(Quotes_DrawingRequest.PricingPolicy,'') as PricingPolicy, 
ifnull(Quotes_DrawingRequest.WithOrder,'') as WithOrder, 
ifnull(Quotes_DrawingRequest.DaysNo,'') as DaysNo, 
ifnull(Quotes_DrawingRequest.DeliveryWording,'') as DeliveryWording, 
ifnull(Quotes_DrawingRequest.AnchorageWording,'') as AnchorageWording, 
ifnull(Quotes_DrawingRequest.QuoteDuration,'') as QuoteDuration, 
ifnull(Quotes_DrawingRequest.MembraneColorID,'') as MembraneColorID, 
ifnull(Quotes_DrawingRequest.EngWording,'') as EngWording, 
ifnull(Quotes_DrawingRequest.WindRate,'') as WindRate, 
ifnull(Quotes_DrawingRequest.SnowLoad,'') as SnowLoad, 
ifnull(Quotes_DrawingRequest.Contamination1,'') as Contamination1, 
ifnull(Quotes_DrawingRequest.Application,'') as ApplicationName, 
ifnull(Quotes_DrawingRequest.Exposure,'') as Exposure, 
ifnull(Quotes_DrawingRequest.Anchorage,'') as Anchorage, 
ifnull(Quotes_DrawingRequest.MembraneColor,'') as StructureColor,
ifnull(Quotes_DrawingRequest.BuiltCode,'') as BuiltCode
FROM         (SELECT     ContactName, Address, Zip, PhoneNo, MobileNo, Fax, Email, WebSite, DrawingRequestID, CreateAccountID, CreateDate, ModifyAccountID, 
                                              ModifyDate, ScopeID, QuoteID, ReferenceDrawingRequestID, SendToID, SendViaID, DrawingTypeID, DrawingSizeID, DrawingUnitID, 
                                              DeliveryPoint, RequestedDeliveryDate,PromisedDeliveryDate, IsStamped, NoOfCopies, StatusID, Caption, Comments, ContactID, SendTo, SendVia, DrawingType, 
                                              DrawingSize, DrawingUnit
                       from GetQuoteDrawingRequestsReport_t AS GetQuoteDrawingRequestsReport_1) AS Drawingrequest INNER JOIN
                          (SELECT     QuoteID, TheDate, ModifyAccountName, Company, Address, Zip, PhoneNo, Fax, Email, Attention, StructureWidth, StructureLength, StructureSQFT, 
                      Location, PricingPolicy, LeaseTermAID, LeaseTermBID, NoOfCraneBreakPoints, QuoteDuration, TotalSalePrice, TotalLeaseTermAPrice, 
                      TotalLeaseTermBPrice, WithOrder, MonthlyA, MonthlyB, FinalTotalSalePrice, FinalTotalLeaseTermAPrice, FinalTotalLeaseTermBPrice, TotalManhours, 
                      MenNo, DaysNo, CraneHours, ManLifts, CraneSize, FabricContaminationCost, FrieghtCost, TechCost, MembraneColorID, DeliveryWording, 
                      AnchorageWording, EngWording, FOBClause, OptionClause, ExtrasFOBClause, AccessoryClause, ToolClause, EnviroHeading, Contamination, 
                      Contamination1, Contamination2, TechWording, TechChargeWording, RollDoorManpower, GuaranteeClause, CraneTitle, CraneWording, WindRate, 
                      SnowLoad, Exposure, Anchorage, MembraneColor, Application, ModifyAccountID, BuiltCode
FROM  GetQuoteReport_t AS GetQuoteReport_1) AS Quotes_DrawingRequest ON 
                      Drawingrequest.QuoteID = Quotes_DrawingRequest.QuoteID
);
end;
