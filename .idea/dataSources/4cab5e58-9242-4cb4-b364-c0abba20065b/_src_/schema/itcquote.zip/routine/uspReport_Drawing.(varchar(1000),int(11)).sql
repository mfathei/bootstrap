CREATE PROCEDURE itcquote.uspReport_Drawing(IN pFullTemplateName VARCHAR(1000), IN pDrawingID INT)
  BEGIN
		DECLARE vxmlDoc TEXT charset utf8;
        DECLARE vstrDoc VARCHAR(21844) CHARSET utf8;
    if pFullTemplateName is null 
    then
        set pFullTemplateName = '';
    end if;
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	IF (pDrawingID IS NOT NULL)
	then
		-- SET vxmlDoc = (
				SELECT CONVERT(CURDATE(), CHAR(50)) AS CurrentDate
					,IFNULL(Contacts.ContactName, '') AS ContactName
					,IFNULL(Contacts.Zip, '') AS Zip
					,IFNULL(Contacts.Address, '') AS Address
					,IFNULL(Contacts.PhoneNo, '') AS PhoneNo
					,IFNULL(Contacts.MobileNo, '') AS MobileNo
					,IFNULL(Contacts.Fax, '') AS Fax
					,IFNULL(Contacts.Email, '') AS Email
					,IFNULL(Contacts.WebSite, '') AS WebSite
					,IFNULL(CONVERT(Drawings.ExpectedDate, CHAR(50)), '') AS ExpectedDate
					,IFNULL(DrawingRequests.QuoteID, '') AS QuoteID
					,IFNULL(DrawingRequests.IsStamped, '') AS IsStamped
					,IFNULL(Drawings.DrawnByID, '') AS DrawnByID
					,IFNULL(DrawingRequests.NoOfCopies, '') AS NoOfCopies
					,IFNULL(CONVERT(Drawings.ActualDate, CHAR(50)), '') AS ActualDate
					,IFNULL(CONVERT(DrawingRequests.`RequestedDeliveryDate`, CHAR(50)), '') AS ExpectedDeliveryDate
					,IFNULL(DrawingRequests.DeliveryPoint, '') AS DeliveryPoint
					,IFNULL(Drawings.DrawingID, '') AS DrawingID
					,IFNULL(Drawing_type.TheValue, '') AS DrawingType
					,IFNULL(Drawind_size.TheValue, '') AS Drawingsize
					,IFNULL(SendTO.TheValue, '') AS SendTo
					,IFNULL(Send_Via.TheValue, '') AS SendVia
					,IFNULL(DrawingSize.TheValue, '') AS DrawingSize
					,IFNULL(Contacts_Sales.ContactName, '') AS SalesName
					,IFNULL(Contacts_Attention.ContactName, '') AS Attention
					,IFNULL(Exposure.TheValue, '') AS ExposureValue
					,IFNULL(Anchorage.TheValue, '') AS AnchorageValue
					,IFNULL(Quotes.WindRate, '') AS WindRate
					,IFNULL(Quotes.SnowRate, '') AS SnowRate
					,IFNULL(Quotes.StructureLength, '') AS StructureLength
					,IFNULL(Contacts_Companies.ContactName, '') AS CompanyName
					,IFNULL(BuildingCodes.BuildingCodeName, '') AS BuildingCode
					,IFNULL(Locations.LocationName, '') AS StructureLocation
					,IFNULL(Applications.ApplicationName, '') AS ApplicationName
				FROM Drawings
				INNER JOIN DrawingRequests ON Drawings.DrawingRequestID = DrawingRequests.DrawingRequestID
				INNER JOIN Contacts ON Drawings.DrawnByID = Contacts.ContactID
				INNER JOIN PropertiesValues AS Drawing_type ON DrawingRequests.DrawingTypeID = Drawing_type.PropertyValueID
				INNER JOIN PropertiesValues AS Drawind_size ON DrawingRequests.DrawingSizeID = Drawind_size.PropertyValueID
				INNER JOIN PropertiesValues AS SendTO ON DrawingRequests.SendToID = SendTO.PropertyValueID
				INNER JOIN PropertiesValues AS Send_Via ON DrawingRequests.SendViaID = Send_Via.PropertyValueID
				INNER JOIN PropertiesValues AS DrawingSize ON DrawingRequests.DrawingSizeID = DrawingSize.PropertyValueID
				INNER JOIN Quotes ON DrawingRequests.QuoteID = Quotes.QuoteID
				INNER JOIN Locations ON Quotes.LocationID = Locations.LocationID
				INNER JOIN BuildingCodes ON Locations.BuildingCodeID = BuildingCodes.BuildingCodeID
				INNER JOIN Applications ON Quotes.ApplicationID = Applications.ApplicationID
				LEFT JOIN Contacts AS Contacts_Companies ON Quotes.CompanyID = Contacts_Companies.ContactID
				LEFT JOIN Contacts AS Contacts_Sales ON Quotes.SalesRepID = Contacts_Sales.ContactID
				LEFT JOIN PropertiesValues AS Anchorage ON Quotes.AnchorageID = Anchorage.PropertyValueID
				LEFT JOIN PropertiesValues AS Exposure ON Quotes.ExposureID = Exposure.PropertyValueID
				LEFT JOIN Contacts AS Contacts_Attention ON Quotes.AttentionID = Contacts_Attention.ContactID
				WHERE (Drawings.DrawingID = pDrawingID)
				-- FOR XML path('TheRow')
				-- );
                ;
                    
                
		SET vstrDoc = (
				SELECT vxmlDoc AS Thelist
				-- FOR XML path('TheReport')
				);
                
		SET vstrDoc = CustomFormatDocAsXML(vstrDoc, pFullTemplateName);
		-- SET vxmlDoc = CAST(vstrDoc AS XML);
	END if;
	SELECT vstrDoc AS ReportAsStr,vxmlDoc AS ReportAsXML;
END;
