CREATE PROCEDURE itcquote.GetDrawingsTable(IN `_DrawID` INT, IN `_AccountID` INT, IN `_TerritoryID` INT)
  begin
DECLARE _IsAdmin bit;
Declare _StatusGroupID  int; 
call  fnGetStatus(_StatusGroupID);
DROP TEMPORARY TABLE IF EXISTS GetDrawingsTable_t ;
CREATE TEMPORARY TABLE GetDrawingsTable_t (DrawingID int,
           DwgNumber varchar(50),
           Customer varchar(150), 
           Customer1 varchar(150),
           Width varchar(50),
           Length varchar(50),
           CreateAccountID int, 
           CreateDate datetime, 
           ModifyAccountID int, 
           ModifyDate datetime, 
		   ScopeID int ,
           DrawingRequestID int, 
           DrawnByID int,
           DrawnBy varchar(150),
           ExpectedDate datetime,
           ActualDate datetime,
           TerritoryID int, 
           SalesPersonID int,
           SalesPerson varchar(150),
           City varchar(50),
           State varchar(50),
           StructureUse varchar(50),
           Wind varchar(20),
           Snow varchar(20),
           DrawingTypeID int,
           StatusID int, 
           StatusName varchar(50), 
           Caption varchar(150), 
           Comments varchar(1000));
	
    
 
SET _IsAdmin=(select IsAdmin from Accounts Where AccountID=_AccountID);
set     _StatusGroupID = 1;
Insert Into GetDrawingsTable_t(DrawingID,DwgNumber ,Customer , Customer1,Width ,Length,CreateAccountID ,CreateDate , ModifyAccountID , 
           ModifyDate ,ScopeID ,  DrawingRequestID, DrawnByID ,DrawnBy ,ExpectedDate ,ActualDate ,TerritoryID ,SalesPersonID ,
           SalesPerson , City ,State,StructureUse , Wind ,Snow , DrawingTypeID ,StatusID, StatusName ,Caption , Comments )
(
	SELECT DrawingID,DwgNumber ,Customer , Customer1,Width ,Length,CreateAccountID ,CreateDate , ModifyAccountID , 
           ModifyDate ,ScopeID ,  DrawingRequestID, DrawnByID ,DrawnBy ,ExpectedDate ,ActualDate ,TerritoryID ,SalesPersonID ,
           SalesPerson , City ,State,StructureUse , Wind ,Snow , DrawingTypeID ,Drawings.StatusID, StatusName ,Caption , Comments
  FROM Drawings
  LEFT  JOIN fnGetStatus_t AS tbStatus ON Drawings.StatusID = tbStatus.StatusID
  WHERE 
      ((_DrawID = 0) OR (DrawingRequestID = _DrawID)) AND
        (
          ((ScopeID = 1) AND (CreateAccountID = _AccountID  OR _IsAdmin=1)) OR 
          ((ScopeID = 2) AND (CreateAccountID IN (SELECT AccountID FROM Accounts WHERE TerritoryID = _TerritoryID) OR _IsAdmin=1)) OR        
          ((ScopeID IS NULL) ) OR
          ((CreateAccountID IS NULL) ) OR
          ((ScopeID = 3))
        )
        
 );
end;
