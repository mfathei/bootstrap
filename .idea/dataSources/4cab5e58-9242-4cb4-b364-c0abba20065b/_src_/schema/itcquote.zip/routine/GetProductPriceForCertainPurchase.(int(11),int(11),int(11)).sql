CREATE FUNCTION itcquote.GetProductPriceForCertainPurchase(pProductID INT, pPricingPolicyID INT, pPurchaseTypeID INT)
  RETURNS DECIMAL(10, 2)
  BEGIN
	DECLARE vResult DECIMAL(10, 2);
	SELECT ProductsPrices.Price INTO vResult
	FROM ProductsPrices
	INNER JOIN PricingTypes ON ProductsPrices.PricingTypeID = PricingTypes.PricingTypeID
	WHERE (ProductsPrices.ProductID = pProductID)
		AND (ProductsPrices.PricingPolicyID = pPricingPolicyID)
		AND (PricingTypes.PurchaseTypeID = pPurchaseTypeID) LIMIT 1;
	SET vResult = IFNULL(vResult, 0);
	RETURN vResult;
END;
