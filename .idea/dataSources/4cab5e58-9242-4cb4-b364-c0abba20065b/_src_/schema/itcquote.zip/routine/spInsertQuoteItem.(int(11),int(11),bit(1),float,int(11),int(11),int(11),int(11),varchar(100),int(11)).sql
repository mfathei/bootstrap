CREATE PROCEDURE itcquote.spInsertQuoteItem(IN `_QuoteID`      INT, IN `_ProductID` INT, IN `_IsAutoAdded` BIT,
                                            IN `_Quantity`     FLOAT, IN `_PricingPolicyID` INT, IN `_SaleTypeID` INT,
                                            IN `_LeaseTermAID` INT, IN `_LeaseTermBID` INT, IN `_Notes` VARCHAR(100),
                                            IN `_ItemTypeID`   INT)
  BEGIN
		DECLARE _SalePrice ,_LeaseTermAPrice ,_LeaseTermBPrice decimal(19,11);
		declare _Manhours  ,_StructureLength  ,_StructureSQFT,_Length ,_Width ,_CenterBaySpacing ,_Surcharge30  ,_Surcharge40   FLOAT;
		declare _ProductName VARCHAR(200);
		declare _IsDisplayedInReports ,_IsInsulated BIT;
		-- Modified by Salma 01-05-2013---------------------
        declare _InsulationTypeID ,_StructureID ,_ProductTypeID ,_StructureWidth ,_Termination ,_ConnectionFees ,
               _Product20ID ,_StructureWidthID ,_CenterBaySpacingID ,_IsSnowLoad ,_FabricTypeID,_SubtractFees INT;
		-- Modified by Salma 15-01-2014---------------------
		
		-- Salma --modified on 26-5-2014-- center bay spacing----
		
		-- Salma modified on 17-7-2014 use QuoteID  to get FabricType to be used in Cannopies,Vestibules & Corridors
		
		declare _prfaba FLOAT default 0;
		declare _prfabb FLOAT default 0;
		declare _prfabs FLOAT default 0;
		declare _Connections INT default 1;
		declare _intWalls INT default 0;
		-- Salma modified on 10-11-2014 -- remove Surcharge based on CenterBay in quote
		declare _QuoteCenterBay FLOAT default  0;
		-- Salma --modified on 9-4-2015-- surcharge variable depending on pricing policy----
if _ItemTypeID=null or _ItemTypeID='' then set _ItemTypeID=1; end if;
    /*	IF _Quantity <= 0
     then
		RETURN
	 end if;
     */
     sp_loop:loop
       IF _Quantity <= 0
       then leave sp_loop;
       end if;
       end loop ;
     
	SET _Surcharge30 = GetFirstPropetyValueByName('INC30Surcharge');
	IF (_Surcharge30 = 0)
    then
		SET _Surcharge30 = 3.25;
	    SET _Surcharge40 = GetFirstPropetyValueByName('INC40Surcharge');
	end if;
	IF (_Surcharge40 = 0)
    then
		SET _Surcharge40 = 2.25 ;
    end if;
	SELECT _QuoteCenterBay = CenterBaySpacing
	FROM Quotes
	WHERE QuoteID = _QuoteID;
	SELECT _FabricTypeID = FabricTypeID
	FROM Quotes
	WHERE QuoteID = _QuoteID;
	SELECT _InsulationTypeID = InsulationTypeID
	FROM Quotes
	WHERE (QuoteID = _QuoteID);
	SET _IsInsulated = IsInsulated(_InsulationTypeID);
	SET _SalePrice = GetProductPrice(_ProductID, _PricingPolicyID, 1, _SaleTypeID);
	SET _LeaseTermAPrice = GetProductPrice(_ProductID, _PricingPolicyID, 2, _LeaseTermAID);
	SET _LeaseTermBPrice = GetProductPrice(_ProductID, _PricingPolicyID, 2, _LeaseTermBID);
	SET _Manhours = GetProductManhours(_ProductID, _IsInsulated);
	-- -Modified by Salma 01-05-2013 
	-- modify STRUCTURE product Sales price based on insultaion, width & length--
	-- adding surcharge price per sqft to Width structure Sale price for Non-insulated structures
	SET _ProductTypeID = GetProductTypeByProductID(_ProductID);
	SELECT _StructureID = StructureID
		,_StructureLength = StructureLength
		,_IsSnowLoad = IsSnowLoad
	FROM Quotes
	WHERE (QuoteID = _QuoteID);
	SET _StructureWidth = GetProductPropertyValue_Int(_StructureID, 6);
	-- Salma --modified on 26-5-2014-- take prices of 20 center bay product in case of 3015,4015 or 5015-
	IF (
			_ProductTypeID = 1
			AND (
				_StructureWidth = 30
				OR _StructureWidth = 40
				OR _StructureWidth = 50
				)
			AND _IsSnowLoad = 1
			)
	then
		SET _CenterBaySpacing = GetProductPropertyValue(_ProductID, 30) --DefaultCenterBaySpacing;
		IF (_CenterBaySpacing = 15)
		then
			SET _StructureWidthID = GetPropertyValueIDByValue_PropertyID(6, _StructureWidth);
			SET _CenterBaySpacingID = GetPropertyValueIDByValue_PropertyID(30, 20);
			SET _Product20ID = GetProductID_2Params(_ProductTypeID, 6, _StructureWidthID, 30, _CenterBaySpacingID);
			SET _SalePrice = GetProductPrice(_Product20ID, _PricingPolicyID, 1, _SaleTypeID);
			SET _LeaseTermAPrice = GetProductPrice(_Product20ID, _PricingPolicyID, 2, _LeaseTermAID);
			SET _LeaseTermBPrice = GetProductPrice(_Product20ID, _PricingPolicyID, 2, _LeaseTermBID);
		END if;
	END if;
	-- Salma --modified on 27-10-2014-- remove _IsInsulated=0 condition and change width 50 to 30 ---
	-- SET _StructureSQFT = GetStructureSQFT(_StructureWidth, _StructureLength)
	-- Salma --modified on 9-4-2015-- surcharge variable depending on pricing policy----
	IF (_PricingPolicyID = 2) -- LTD
	then
		SET _Surcharge30 = GetFirstPropetyValueByName('LTD30Surcharge');
		SET _Surcharge40 = GetFirstPropetyValueByName('LTD40Surcharge');
	END if;
	IF (_ProductTypeID = 1) -- _IsInsulated=0 AND
	then
		IF (
				_StructureWidth = 30
				AND _StructureLength <= 50
				)
		then
			-- Salma modified on 10-11-2014 -- remove Surcharge based on CenterBay in quote
			IF (
					_StructureLength = 50
					AND (
						_QuoteCenterBay >= 15
						AND _QuoteCenterBay < 20
						)
					) -- no surcharge
			then
				SET _SalePrice = _SalePrice;
				SET _LeaseTermAPrice = _LeaseTermAPrice;
				SET _LeaseTermBPrice = _LeaseTermBPrice;
			
			ELSE
			
				SET _SalePrice = _SalePrice + _Surcharge30 ;-- surcharge per sqft
					-- Salma --modified on 12-6-2013-- add surcharge for LeaseA and LeaseB prices----
				SET _LeaseTermAPrice = _LeaseTermAPrice + _Surcharge30; -- surcharge per sqft
				SET _LeaseTermBPrice = _LeaseTermBPrice + _Surcharge30; -- surcharge per sqft
			end if;
		    
		ELSEIF (
				_StructureWidth = 40
				AND _StructureLength <= 60
				)
		then
			SET _SalePrice = _SalePrice + _Surcharge40; -- surcharge per sqft
				-- Salma --modified on 12-6-2013-- add surcharge for LeaseA and LeaseB prices----
			SET _LeaseTermAPrice = _LeaseTermAPrice + _Surcharge40 ;-- surcharge per sqft
			SET _LeaseTermBPrice = _LeaseTermBPrice + _Surcharge40; -- surcharge per sqft
		
	END if;
end if;
	-- --------------------------------------------------------------------------------------------------
	-- Modified by Salma 17-7-2014---added the following to be used in cannopies & vestibules calculations
	IF (
			_ProductTypeID = 41
			OR _ProductID = 42
			)
	then
		-- IF(_FabricTypeID=4 OR _FabricTypeID=426) 
		-- BEGIN
		--   IF( _PricingPolicyID=1 )
		--   BEGIN
		-- SET _prfaba=4.30
		-- SET _prfabb=4.30
		-- SET _prfabs=4.30
		--  END
		--  ELSE 
		--  BEGIN
		-- SET _prfaba=4.70
		-- SET _prfabb=4.70
		-- SET _prfabs=4.70
		--  END
		-- END
		--  ELSE
		--  BEGIN
		-- SET _prfaba=4.30
		-- SET _prfabb=4.30
		-- SET _prfabs=4.30
		-- END 
		SET _prfaba = _LeaseTermAPrice;
		SET _prfabb = _LeaseTermBPrice;
		SET _prfabs = _SalePrice;
	END if;
	-- --Modified by Salma 15-01-2014----------added the calculation for canopies-------
	IF (_ProductTypeID = 41)
	then
		SET _Length = GetProductPropertyValue(_ProductID, 1);
		SET _Width = GetProductPropertyValue(_ProductID, 2);
		SET _ConnectionFees = GetProductPropertyValue(_ProductID, 78);
		SET _Termination = GetProductPropertyValue(_ProductID, 108) * 10 * 2 * _Length;
		SET _SalePrice = ((_prfabs + _SalePrice) * _Width * _Length) + _SalePrice + _ConnectionFees + _Termination;
		SET _LeaseTermAPrice = ((_prfaba + _LeaseTermAPrice) * _Width * _Length) + _LeaseTermAPrice + _ConnectionFees + _Termination;
		SET _LeaseTermBPrice = ((_prfabb + _LeaseTermBPrice) * _Width * _Length) + _LeaseTermBPrice + _ConnectionFees + _Termination;
	END if;
	-- --Modified by Salma 16-07-2014----------added the calculation for vestibules-------
	IF (_ProductTypeID = 42)
	then
		SET _Length = GetProductPropertyValue(_ProductID, 1);
		SET _Width = GetProductPropertyValue(_ProductID, 2);
		SET _ConnectionFees = GetProductPropertyValue(_ProductID, 78);
		SET _Termination = GetProductPropertyValue(_ProductID, 108) * 10 * 2 * _Length;
		SET _SalePrice = ((_prfabs + _SalePrice) * _Width * _Length) + _SalePrice + _ConnectionFees + _Termination;
		SET _LeaseTermAPrice = ((_prfaba + _LeaseTermAPrice) * _Width * _Length) + _LeaseTermAPrice + _ConnectionFees + _Termination;
		SET _LeaseTermBPrice = ((_prfabb + _LeaseTermBPrice) * _Width * _Length) + _LeaseTermBPrice + _ConnectionFees + _Termination;
	END if;
	-- --Modified by Salma 17-07-2014----------added the calculation for corrdiors-------
	IF (_ProductTypeID = 21)
	then
		SET _Length = GetProductPropertyValue(_ProductID, 1);
		SET _Width = GetProductPropertyValue(_ProductID, 2);
		SET _ConnectionFees = GetProductPropertyValue(_ProductID, 78);
		SET _SubtractFees = GetProductPropertyValue(_ProductID, 79);
		SET _ConnectionFees = ((_Connections * _ConnectionFees) - (_intWalls * _SubtractFees));
		SET _SalePrice = ((_Width * _Length * _SalePrice) + _ConnectionFees) + (_Width * _Length * _prfabs);
		SET _LeaseTermAPrice = ((_Width * _Length * _LeaseTermAPrice) + _ConnectionFees) + (_Width * _Length * _prfaba);
		SET _LeaseTermBPrice = ((_Width * _Length * _LeaseTermBPrice) + _ConnectionFees) + (_Width * _Length * _prfabb);
	END if;
	-- --------------------------------------------------------------------------------
	SELECT  QuoteLetterProductName
		, IsDisplayedInReports
	into
	_ProductName,_IsDisplayedInReports
	FROM Products
	WHERE (ProductID = _ProductID);
	DELETE from QuotesItems
	WHERE (QuoteID = _QuoteID)
		AND (ProductID = _ProductID);
	INSERT INTO QuotesItems (
		QuoteID
		,ProductID
		,ItemName
		,ItemTypeID
		,IsAutoAdded
		,IsDisplayedInReports
		,Quantity
		,OriginalSalePrice
		,OriginalLeaseTermAPrice
		,OriginalLeaseTermBPrice
		,OriginalManhours
		,CustomSalePrice
		,CustomLeaseTermAPrice
		,CustomLeaseTermBPrice
		,CustomManhours
		,Notes
		)
	VALUES (
		_QuoteID
		,_ProductID
		,ifnull(_ProductName, '')
		,_ItemTypeID
		,_IsAutoAdded
		,_IsDisplayedInReports
		,_Quantity
		,_SalePrice
		,_LeaseTermAPrice
		,_LeaseTermBPrice
		,_Manhours
		,_SalePrice
		,_LeaseTermAPrice
		,_LeaseTermBPrice
		,_Manhours
		,_Notes
		);
end;
