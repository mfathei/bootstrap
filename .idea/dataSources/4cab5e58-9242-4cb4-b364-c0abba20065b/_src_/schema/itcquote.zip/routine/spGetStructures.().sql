CREATE PROCEDURE itcquote.spGetStructures()
  BEGIN
  SELECT Products.ProductID, Products.ProductTypeID, Products.ProductName, ProductsPropertiesValues.PropertyID, 
  ProductsPropertiesValues.PropertyValueID, PropertiesValues.TheValue, 
  cast(PropertiesValues.TheValue as SIGNED ) AS TheValueInt
  FROM  Products 
  INNER JOIN ProductsPropertiesValues ON Products.ProductID = ProductsPropertiesValues.ProductID
  INNER JOIN PropertiesValues ON ProductsPropertiesValues.PropertyValueID = PropertiesValues.PropertyValueID
  WHERE (Products.ProductTypeID = 1) AND (ProductsPropertiesValues.PropertyID = 6)
  ORDER BY PropertiesValues.TheValue;
  -- WHERE (Products.ProductTypeID IN (1, 21, 40, 41)) AND (ProductsPropertiesValues.PropertyID = 6)
  -- ORDER BY Products.ProductTypeID, PropertiesValues.TheValue
END;
