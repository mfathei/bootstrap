CREATE PROCEDURE itcquote.spGetAccountEmail(IN `_AccountID` INT)
  BEGIN
	SELECT Contacts.Email
	FROM Contacts
	INNER JOIN Accounts ON Contacts.ContactID = Accounts.ContactID
	WHERE (Accounts.AccountID = _AccountID);
end;
