CREATE FUNCTION itcquote.GetNoOfEarthAnchorsWithTriple(pQuoteID INT, pSubtractQunatity INT)
  RETURNS INT(6)
  BEGIN
	DECLARE vResult int;
	DECLARE pMultiply int;
	DECLARE pRollingCount INT default 0;
	DECLARE pStructureID INT;
	DECLARE pStructureWidth INT;
	DECLARE pStructureLength FLOAT;
	DECLARE pWindRate FLOAT;
	DECLARE pNoOfFlatEnds int;
	DECLARE pNoOfRoundEnds int;
	DECLARE pNoOfBeamsPerFlatEnd int;
	DECLARE pNoOfBeamsPerRoundEnd int;
	DECLARE pNoOfBeamsPerCenterBay int;
	DECLARE pNoOfBeamsPerCraneLiftBreakpoint int;
	DECLARE pStandardCenterBaySpacing FLOAT;
	DECLARE -- <-- -- --  Standard measures  
		pStructureStandardLength FLOAT;
	DECLARE pNoOfCenterBays int;
	DECLARE pNoOfCraneBreakPoints int;
	DECLARE pNoOfHooksPerBeam int;
	DECLARE pIsAdditionToExistingStructure BIT;
	DECLARE pNoOfBeams int;
	SELECT StructureID
		,StructureLength
		,NoOfFlatEnds
		,NoOfRoundEnds
		,NoOfCenterBays
		,NoOfCraneBreakPoints
		,WindRate
		,IFNULL(IsAdditionToExistingStructure, 0)
		into
		pStructureID
		,pStructureLength
		,pNoOfFlatEnds
		,pNoOfRoundEnds
		,pNoOfCenterBays
		,pNoOfCraneBreakPoints
		,pWindRate
		,pIsAdditionToExistingStructure
	FROM Quotes
	WHERE (QuoteID = pQuoteID);
	SET pStructureWidth = GetProductPropertyValue_Int(pStructureID, 6);
	SET pNoOfBeamsPerFlatEnd = GetProductPropertyValue_Int(pStructureID, 11);
	SET pNoOfBeamsPerRoundEnd = GetProductPropertyValue_Int(pStructureID, 14);
	SET pNoOfBeamsPerCenterBay = GetProductPropertyValue_Int(pStructureID, 60);
	SET pNoOfBeamsPerCraneLiftBreakpoint = GetProductPropertyValue_Int(pStructureID, 61);
	SET pNoOfHooksPerBeam = GetProductPropertyValue_Int(pStructureID, 63);
	SET pNoOfBeams = GetNoOfBeams(pNoOfFlatEnds, pNoOfBeamsPerFlatEnd, pNoOfRoundEnds, pNoOfBeamsPerRoundEnd, pNoOfCenterBays, pNoOfBeamsPerCenterBay, pNoOfCraneBreakPoints, pNoOfBeamsPerCraneLiftBreakpoint);
	SET vResult = pNoOfBeams;
	IF (pStructureWidth < 60)
		AND (pWindRate > 120)
	then
		SET vResult = 2 * pNoOfBeams;
	end if;
	IF (pStructureWidth >= 60)
	then
		SET vResult = 2 * pNoOfBeams;
	end if;
	SELECT SUM(Quantity) into pRollingCount
	FROM QuotesItems
	INNER JOIN Products ON QuotesItems.ProductID = Products.ProductID
	WHERE QuoteID = pQuoteID
		AND ProductTypeID = 56 ;-- ProductName like '%Triple Panel Rolling Door%'
		
	SET pRollingCount = pRollingCount - pSubtractQunatity;
	SET pRollingCount = IFNULL(pRollingCount, 0);
	SET vResult = vResult + pRollingCount;
	RETURN IFNULL(vResult, 0);
END;
