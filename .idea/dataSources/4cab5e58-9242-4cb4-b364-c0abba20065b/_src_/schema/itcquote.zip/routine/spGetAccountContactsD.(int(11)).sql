CREATE PROCEDURE itcquote.spGetAccountContactsD(IN pContactTypeID INT)
  BEGIN
	-- Insert statements for procedure here
	SELECT Contacts.ContactID
		,Contacts.ContactName
		,Contacts.ContactTypeID
		,Contacts.CreateDate
		,Contacts.CreateAccountID
		,Contacts.ScopeID
		,Contacts.IsActive
		,ContactsTypes.ContactTypeName
		,Contacts.IsActive
		,Scopes.ScopeName
	FROM Contacts
	LEFT JOIN ContactsTypes ON Contacts.ContactTypeID = ContactsTypes.ContactTypeID
	LEFT JOIN Scopes ON Contacts.ScopeID = Scopes.ScopeID
	WHERE (Contacts.ContactTypeID = pContactTypeID)
	ORDER BY Contacts.ContactID;
END;
