CREATE PROCEDURE itcquote.spGetQuotes(IN `_AccountID` INT, IN `_TerritoryID` INT)
  BEGIN
	DECLARE _IsAdmin int(1);
    if _AccountID=null or _AccountID='' then set _AccountID=-1; end if;
	SET _IsAdmin=(select IsAdmin from Accounts Where AccountID=_AccountID);
	SELECT QuoteID, Quotes.Title, Code, Quotes.CreateDate, Quotes.CreateAccountID, Quotes.ScopeID,Contacts.ContactName,CompletedByAccountID,
	TerritoryName,prerpared.ContactName as PreparedBy,(ifnull(FirstName,'')+' '+ifnull(LastName,''))as CompletedFor
	FROM Quotes
	left  join Contacts on Quotes.CompanyID=Contacts.ContactID AND ContactTypeID=1
	left  join Accounts on Quotes.CreateAccountID=Accounts.AccountID
	left  join Territories on Accounts.TerritoryID=Territories.TerritoryID
	left  join Contacts as prerpared on Accounts.ContactID=prerpared.ContactID
	left  join DevelopmentManagers  on Quotes.CompletedByAccountID=DevelopmentManagers.ManagerID
	WHERE ((Quotes.ScopeID = 1) AND (Quotes.CreateAccountID = _AccountID OR _IsAdmin=1)) OR 
		((Quotes.ScopeID = 2) AND ((Quotes.CreateAccountID IN (SELECT AccountID FROM Accounts WHERE TerritoryID = _TerritoryID)) OR (_IsAdmin=1))) OR
		((Quotes.ScopeID IS NULL) ) OR
		((Quotes.CreateAccountID IS NULL) ) OR
		((Quotes.ScopeID = 3) );
END;
