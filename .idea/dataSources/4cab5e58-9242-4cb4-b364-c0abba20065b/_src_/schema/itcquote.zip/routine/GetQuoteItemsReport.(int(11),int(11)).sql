CREATE FUNCTION itcquote.GetQuoteItemsReport(pQuoteID INT, pReportTypeID INT)
  RETURNS VARCHAR(21844)
  BEGIN
	DECLARE vResult VARCHAR(21844) CHARSET utf8;
	DECLARE vLeaseTermAID int;
	DECLARE vLeaseTermBID int;
	DECLARE vDisplayedInReports int;
	DECLARE vstrQuoteOptions VARCHAR(21844) CHARSET utf8;
	DECLARE vstrQuoteExtras VARCHAR(21844) CHARSET utf8;
	
	SELECT  LeaseTermAID
		, LeaseTermBID
		INTO 
		vLeaseTermAID
		,vLeaseTermBID
	FROM Quotes
	WHERE (QuoteID = pQuoteID);
	-- Salma Modified on 20-1-2015 -- added , pReportTypeID to parameters of GetQuoteItemsReport to show all items in case of Report
	
	IF (pReportTypeID = 1) -- letter
	THEN
		SET vDisplayedInReports = 1;
	ELSE
		SET vDisplayedInReports = NULL;
    END IF;
    
	SET vstrQuoteOptions = GetQuoteItemsReportP1(pQuoteId,pReportTypeID,vDisplayedInReports);
	SET vstrQuoteExtras = GetQuoteItemsReportP2(pQuoteId,pReportTypeID,vDisplayedInReports, vLeaseTermAID, vLeaseTermBID);
			
	-- --------------------------------------------	  
	SET vstrQuoteOptions = IFNULL(vstrQuoteOptions, '');
	SET vstrQuoteExtras = IFNULL(vstrQuoteExtras, '');
	SET vResult = concat('<QuoteOptions>' , REPLACE(vstrQuoteOptions, '&#x0D;', ';') , '</QuoteOptions>' , '<QuoteExtras>' , vstrQuoteExtras , '</QuoteExtras>');
	RETURN vResult;
END;
