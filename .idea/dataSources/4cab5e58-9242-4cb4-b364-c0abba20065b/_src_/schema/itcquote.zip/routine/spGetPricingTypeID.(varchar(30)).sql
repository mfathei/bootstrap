CREATE PROCEDURE itcquote.spGetPricingTypeID(IN pPricingTypeName VARCHAR(30))
  BEGIN
	SELECT PricingTypeID
	FROM PricingTypes
	WHERE (PricingTypeName = pPricingTypeName);
END;
