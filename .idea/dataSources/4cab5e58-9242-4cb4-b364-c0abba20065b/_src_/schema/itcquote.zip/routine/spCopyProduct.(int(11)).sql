CREATE PROCEDURE itcquote.spCopyProduct(IN `_ProductID` INT)
  BEGIN
	
    -- Insert statements for procedure here
  DECLARE _NewProductID int;
  DECLARE _ProductName varchar(50);
 if _ProductID ='' or _ProductID is null then set _ProductID = 0;  end if; 
  SET _ProductName = 'Copy Of ' ;
  INSERT INTO Products
  (ParentID, SortOrder, ProductTypeID, UnitID, ProductCode, ProductName,QuoteLetterProductName , Description)
  SELECT 
  ParentID, SortOrder, ProductTypeID, UnitID, ProductCode, concat(_ProductName , ProductName) AS ProductName,QuoteLetterProductName, Description
  FROM Products 
  WHERE ProductID = _ProductID;
  SELECT IDENT_CURRENT('Products') into _NewProductID ;
  
  call spCopyProductPropertiesValues( _ProductID, _NewProductID);
  call spCopyProductPrices( _ProductID, _NewProductID);
  
  SELECT _NewProductID AS NewProductID;
end;
