CREATE FUNCTION itcquote.FormatQuoteItemQuantity(pProductTypeID INT, pProductID INT, pProductName VARCHAR(1000),
                                                 pQuantity      DECIMAL)
  RETURNS DECIMAL
  BEGIN
	DECLARE vResult DECIMAL;
	SET vResult = pQuantity;
	-- CONVERT(varchar(50), pQuantity)
	IF (
			pProductTypeID IN (
				1
				,2
				,3
				,20
				)
			)
		OR (pProductID IN (21))
		OR (pProductName LIKE '%Center Bay Spacing%')
		OR (INSTR('Conduit Holes', pProductName) > 0)
		OR (INSTR('Engineered Stamped Drawings', pProductName) > 0)
	then
		SET vResult = 99999999;
	
	ELSEIF (INSTR('Bahrain Export Tarrif', pProductName) > 0)
	then
		SET vResult = 100000000;
	
	ELSEIF (INSTR('General Excise Tax', pProductName) > 0)
	then
		SET vResult = 100000001;
	END if;
	RETURN vResult;
END;
