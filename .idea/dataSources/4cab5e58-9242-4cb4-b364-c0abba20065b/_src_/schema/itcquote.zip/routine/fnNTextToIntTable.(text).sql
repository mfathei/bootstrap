CREATE PROCEDURE itcquote.fnNTextToIntTable(IN pData TEXT)
  BEGIN
	DECLARE vPtr INT;
	DECLARE vLength INT;
	DECLARE vv NCHAR;
	DECLARE vvv NVARCHAR(10);
    drop temporary table if exists fnNTextToIntTable_t;
    create temporary table fnNTextToIntTable_t(`Value` INT NULL);
	SELECT  (DATALENGTH(pData) / 2) + 1 ,1 into vLength, vPtr;
	WHILE (vPtr < vLength)
	do
		SET vv = SUBSTRING(pData, vPtr, 1);
		IF vv = ','
		then
			INSERT INTO fnNTextToIntTable_t
			VALUES (CAST(vvv AS unsigned));
			SET vvv = NULL;
		
		ELSE
		
			SET vvv = concat(IFNULL(vvv, '') , vv);
		END if;
		SET vPtr = vPtr + 1;
	END while;
	-- If the last number was not followed by a comma, add it to the result set
	IF vvv IS NOT NULL
	then
		INSERT INTO fnNTextToIntTable_t
		VALUES (CAST(vvv AS unsigned));
	end if;
END;
