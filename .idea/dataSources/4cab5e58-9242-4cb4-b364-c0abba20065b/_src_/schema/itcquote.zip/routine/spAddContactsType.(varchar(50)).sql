CREATE PROCEDURE itcquote.spAddContactsType(IN `_ContactTypeName` VARCHAR(50), OUT `_ContactTypeID` INT)
  begin
INSERT into ContactsTypes(ContactTypeName)VALUES(_ContactTypeName);
select last_insert_id() into _ContactTypeID ;
end;
