CREATE FUNCTION itcquote.MyROWNUM()
  RETURNS INT
  BEGIN
        declare id int;
        
    if @MyROWNUM  is null 
    then
        set @MyROWNUM = 1;
        set id = @MyROWNUM;
        return id;
    end if;
     
    SET @MyROWNUM = @MyROWNUM + 1;
    SET id = @MyROWNUM;
    RETURN id;
        
    END;
