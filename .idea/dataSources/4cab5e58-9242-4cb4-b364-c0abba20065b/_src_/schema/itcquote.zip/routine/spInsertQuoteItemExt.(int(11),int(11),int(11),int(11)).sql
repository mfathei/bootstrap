CREATE PROCEDURE itcquote.spInsertQuoteItemExt(IN `_QuoteID`    INT, IN `_ProductID` INT, IN `_ProductTypeID` INT,
                                               IN `_ItemTypeID` INT)
  BEGIN
	DECLARE  _PricingPolicyID ,  _SaleTypeID , _LeaseTermAID , _LeaseTermBID int;
	declare _IsAutoAdded bit;
	declare _Quantity float;
	SET _IsAutoAdded = 0;
	SET _SaleTypeID = 1;
  
	SELECT 
		_PricingPolicyID = PricingPolicyID, 
		_LeaseTermAID = LeaseTermAID, 
		_LeaseTermBID = LeaseTermBID
	FROM Quotes WHERE (QuoteID = _QuoteID);
  
	SET _Quantity =  dbo.GetQuoteItemQuantity(_QuoteID, _ProductTypeID, _ProductID);
	call  spInsertQuoteItem( _QuoteID, _ProductID, _IsAutoAdded, _Quantity, _PricingPolicyID, _SaleTypeID, _LeaseTermAID, _LeaseTermBID, '', _ItemTypeID);
end;
