CREATE PROCEDURE itcquote.spGetMembraneTypes()
  BEGIN
                                
	call spGetPropertyValues (12);
END;
