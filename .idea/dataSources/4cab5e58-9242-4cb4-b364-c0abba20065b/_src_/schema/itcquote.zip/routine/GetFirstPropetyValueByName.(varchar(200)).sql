CREATE FUNCTION itcquote.GetFirstPropetyValueByName(pPropertyName VARCHAR(200))
  RETURNS FLOAT
  BEGIN
	--  Declare the return variable here
	DECLARE vResult FLOAT;
	--  Add the T-SQL statements to compute the return value here
	SET vResult = (
			SELECT CAST(PropertiesValues.TheValue AS decimal(10, 2))
			FROM Properties
			INNER JOIN PropertiesValues ON Properties.PropertyID = PropertiesValues.PropertyID
			WHERE (Properties.PropertyName LIKE pPropertyName) limit 1
			);
	IF vResult IS NULL then
		SET vResult = 0;
	end if;
	--  Return the result of the function
	RETURN vResult;
END;
