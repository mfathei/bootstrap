CREATE PROCEDURE itcquote.deleteProduct(IN `$product_id` VARCHAR(50))
  BEGIN
declare exit HANDLER for sqlexception
begin 
	select 'error' as done;
	ROLLBACK;
end;
declare exit HANDLER for sqlwarning
begin 
	select 'error' as done;
	ROLLBACK;
end;
start transaction;
delete from product_price where product_id = $product_id;
delete from product where product_id = $product_id;
commit;
select 'done' as done;
END;
