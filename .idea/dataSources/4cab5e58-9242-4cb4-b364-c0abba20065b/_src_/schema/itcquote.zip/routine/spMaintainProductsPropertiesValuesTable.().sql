CREATE PROCEDURE itcquote.spMaintainProductsPropertiesValuesTable()
  BEGIN
	declare ending int  default 0;
	DECLARE _ProductID INT;
	DECLARE _ProductTypeID int;
	DECLARE product_cursor CURSOR
	FOR
	SELECT ProductID,ProductTypeID FROM Products;
    declare continue handler for not found set  ending =1;
	OPEN product_cursor;
    spfetching :loop
	FETCH product_cursor  INTO _ProductID ,_ProductTypeID;
		call spUpdateProductProperties( _ProductID
			,_ProductTypeID);
            if ending=1
            then leave spfetching;
            end if;
            end loop;
	CLOSE product_cursor;
end;
