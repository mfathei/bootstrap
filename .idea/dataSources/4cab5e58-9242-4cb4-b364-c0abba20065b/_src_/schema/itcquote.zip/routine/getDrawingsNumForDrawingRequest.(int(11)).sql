CREATE FUNCTION itcquote.getDrawingsNumForDrawingRequest(pDrawingRequestID INT)
  RETURNS VARCHAR(21844)
  BEGIN
	--  Declare the return variable here
	DECLARE plistStr VARCHAR(21844) CHARSET utf8;
	SELECT (concat(COALESCE(concat(plistStr , CASE 
				WHEN DwgNumber NOT LIKE ''
					THEN ','
				ELSE ''
				END), '') , DwgNumber)) into plistStr
	FROM Drawings
	WHERE DrawingRequestID = pDrawingRequestID
	ORDER BY DrawingID ASC;
	--  Return the result of the function
	RETURN plistStr;
END;
