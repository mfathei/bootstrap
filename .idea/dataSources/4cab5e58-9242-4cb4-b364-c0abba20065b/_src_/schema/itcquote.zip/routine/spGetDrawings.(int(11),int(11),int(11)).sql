CREATE PROCEDURE itcquote.spGetDrawings(IN `_DrawID` INT, IN `_AccountID` INT, IN `_TerritoryID` INT)
  BEGIN
	-- Modified by salma 22-3-2015 make added conditions for Isadmin to allow Admins to view all DrawingRequests even Private and added scope conditions
	DECLARE _IsAdmin BIT;
	SET _IsAdmin = (
			SELECT IsAdmin
			FROM Accounts
			WHERE AccountID = _AccountID
			);
	SELECT *
	FROM Drawings
	WHERE (
			(_DrawID = 0)
			OR (DrawingRequestID = _DrawID)
			)
		AND (
			(
				(ScopeID = 1)
				AND (
					CreateAccountID = _AccountID
					OR _IsAdmin = 1
					)
				)
			OR (
				(ScopeID = 2)
				AND (
					CreateAccountID IN (
						SELECT AccountID
						FROM Accounts
						WHERE TerritoryID = _TerritoryID
						)
					OR _IsAdmin = 1
					)
				)
			OR ((ScopeID IS NULL))
			OR ((CreateAccountID IS NULL))
			OR ((ScopeID = 3))
			);
END;
