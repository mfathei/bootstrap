CREATE FUNCTION itcquote.GetNoOfWorkingDays(pInsulationTypeID INT, pStructureSQFT FLOAT, pSQFTPerDay FLOAT,
                                            pTotalManhours    FLOAT, pNoOfWorkers FLOAT)
  RETURNS INT
  BEGIN
	DECLARE vResult INT;
	IF (pSQFTPerDay) <> 0
		AND (pNoOfWorkers <> 0)
	then
		-- - Salma Modified in 2-4-2014: change calculation
		SET vResult = ROUND((pStructureSQFT / pSQFTPerDay) + (pTotalManhours / pNoOfWorkers / 8.0), 0);
		-- Salma Modified in 12-6-2014 --  added the condiftion for less than 4 
		IF (vResult < 4)
		then
			SET vResult = 4;
        end if;
		-- IF pInsulationTypeID = 49
		-- BEGIN		    
		-- 	SET vResult = ROUND((pStructureSQFT / pSQFTPerDay) + (pTotalManhours / pNoOfWorkers / 8.0), 0)
		-- END
		-- ELSE
		-- BEGIN    
		-- 	-- SET vResult = CEILING(3.0*(pStructureSQFT / pSQFTPerDay) + 2.0*(pTotalManhours / pNoOfWorkers / 8.0))
		-- 	SET vResult = ROUND(3.0*(pStructureSQFT / pSQFTPerDay) + (pTotalManhours / pNoOfWorkers / 8.0), 0)
		-- END
		IF (vResult <= 5)
		then
			SET vResult = vResult + 1;
		end if;
				-- ELSEIF (vResult > 5) AND (vResult <= 10) SET vResult = vResult + 2
				-- ELSEIF (vResult > 10) SET vResult = vResult + 2 * FLOOR(vResult / 5.0)
	END if;
	RETURN IFNULL(vResult, 0);
END;
