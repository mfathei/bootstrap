CREATE PROCEDURE itcquote.DeleteOldPrices(IN vpolicyID INT)
  BEGIN
	DECLARE vCount INT;
	DECLARE vResult INT;
    IF vpolicyID IS NULL 
    THEN
        SET vpolicyID = 0;
    END IF;
	-- SET NOCOUNT ON added to prevent extra result sets from
	SET vCount = (
			SELECT Count(*)
			FROM PricingPolicies
			WHERE PricingPolicyID = vpolicyID
			);
	IF (vCount = 0)
	THEN
		set vResult = -1;
    else
        SET vCount = (
                SELECT Count(*)
                FROM ProductsPrices
                WHERE PricingPolicyID = vpolicyID
                );
        DELETE
        FROM ProductsPrices
        WHERE PricingPolicyID = vpolicyID;
        DELETE
        FROM PricingPolicies
        WHERE PricingPolicyID = vpolicyID;
        SET vResult = vCount1;
            -- If return -1 then pricing policy doesn't exist
            -- If return 0 then pricing policy is deleted but has no prices
            -- Otherwise return the number of deleted prices 
	end if;
	
    select vResult;	
	
END;
