CREATE FUNCTION itcquote.GetStructureStandardLength(pNoOfCenterBays INT, pStandardCenterBaySpacing FLOAT,
                                                    pNoOfRoundEnds  INT, pStructureWidth INT)
  RETURNS FLOAT
  BEGIN
	DECLARE vResult FLOAT;
	SET vResult = pNoOfCenterBays * pStandardCenterBaySpacing + pNoOfRoundEnds * (pStructureWidth / 2.0);
    
	RETURN IFNULL(vResult, 0);
END;
