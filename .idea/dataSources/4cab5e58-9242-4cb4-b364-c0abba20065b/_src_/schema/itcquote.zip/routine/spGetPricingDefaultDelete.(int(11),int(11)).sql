CREATE PROCEDURE itcquote.spGetPricingDefaultDelete(IN `_PricingTypeID` INT, IN `_PricingPolicyID` INT)
  BEGIN
   delete  FROM  ProductsDefaultPrices     
WHERE  PricingPolicyID=_PricingPolicyID and PricingTypeID=_PricingTypeID;
END;
