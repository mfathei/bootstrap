CREATE FUNCTION itcquote.forXML(columnLabels VARCHAR(1000), forPATH VARCHAR(50), queryFull VARCHAR(21844))
  RETURNS TEXT
  begin
    
    declare vResult TEXT charset utf8 DEFAULT '' ;
    
    return vResult;
    
end;
