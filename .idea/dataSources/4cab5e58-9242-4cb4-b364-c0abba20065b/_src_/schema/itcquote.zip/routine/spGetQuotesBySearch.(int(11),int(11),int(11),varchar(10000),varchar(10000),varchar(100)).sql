CREATE PROCEDURE itcquote.spGetQuotesBySearch(IN `_AccountID` INT, IN `_TerritoryID` INT, IN `_QuoteID` INT,
                                              IN `_Code`      VARCHAR(10000), IN `_Title` VARCHAR(10000),
                                              IN `_Company`   VARCHAR(100))
  BEGIN
DECLARE _IsAdmin int(1);
if _AccountID=null or _AccountID='' then set _AccountID=-1; end if;
SET _IsAdmin=(select IsAdmin from Accounts Where AccountID=_AccountID);
  SELECT QuoteID, Title, Code, Quotes.CreateDate, Quotes.CreateAccountID, Quotes.ScopeID,Contacts.ContactName,CompletedByAccountID
  FROM Quotes
  left outer join Contacts on Quotes.CompanyID=Contacts.ContactID AND ContactTypeID=1
  
  WHERE (((Quotes.ScopeID = 1) AND (Quotes.CreateAccountID = _AccountID OR _IsAdmin=1)) OR 
        ((Quotes.ScopeID = 2) AND ((Quotes.CreateAccountID IN (SELECT AccountID FROM Accounts WHERE TerritoryID = _TerritoryID)) OR (_IsAdmin=1))) OR
        ((Quotes.ScopeID IS NULL) ) OR
        ((Quotes.CreateAccountID IS NULL) ) OR
        ((Quotes.ScopeID = 3) ))
        AND ((_QuoteID IS NULL OR _QuoteID=0) OR Quotes.QuoteID=_QuoteID)
        AND ((_Code IS NULL) OR Quotes.Code like concat ( '%',_Code,'%'))
        AND ((_Title IS NULL ) OR Quotes.Title like concat( '%',_Title,'%'))
        AND ((_Company IS NULL ) OR ContactName like concat( '%',_Company,'%'));
END;
