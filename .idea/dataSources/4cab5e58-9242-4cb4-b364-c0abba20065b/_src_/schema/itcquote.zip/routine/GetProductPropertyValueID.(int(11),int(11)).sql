CREATE FUNCTION itcquote.GetProductPropertyValueID(pProductID INT, pPropertyID INT)
  RETURNS INT
  BEGIN
	-- Declare the return variable here
	DECLARE vResult INT;
	-- Add the T-SQL statements to compute the return value here
	SELECT PropertyValueID INTO vResult
	FROM ProductsPropertiesValues
	WHERE (ProductID = pProductID)
		AND (PropertyID = pPropertyID);
	IF vResult IS NULL THEN
		SET vResult = 0;
    END IF;
	-- Return the result of the function
	RETURN vResult;
END;
