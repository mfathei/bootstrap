CREATE PROCEDURE itcquote.spGetProductsByNameShowVestibules(IN `_QuoteID`       INT, IN `_ProductName` VARCHAR(100),
                                                            IN `_ProductTypeID` INT)
  BEGIN
	
 
	DECLARE _StructureID ,_StructureWidthID ,_MembraneTypeID ,_InsulationTypeID ,_ISInsulatedID,_StructureWidth 
		    ,_WidthRange,_IsLatticeValueID ,_SpecialWidthValueID ,_InsulationPackageID  int ;
        
        declare _CenterBaySpacing ,_DefaultBaySpacingID VARCHAR(50);
		declare _WidthRangeStr NVARCHAR(200);
        
	if _QuoteID =null or _QuoteID='' then  set _QuoteID = -1; end if;
    set  _ProductName='';
        
	SELECT   StructureID , InsulationTypeID , MembraneTypeID , CenterBaySpacing , InsulationPackageID
	    into _StructureID,_InsulationTypeID ,_MembraneTypeID ,_CenterBaySpacing ,_InsulationPackageID 
	FROM Quotes
	WHERE QuoteID = _QuoteID;
	SET _StructureWidthID = GetProductPropertyValueID(_StructureID, 6);
	SET _IsLatticeValueID = GetProductPropertyValueID(_StructureID, 105);
	SET _SpecialWidthValueID = GetProductPropertyValueID(_StructureID, 106);
	SET _ISInsulatedID = GetIsInsulatedID(_InsulationTypeID);
	IF (_CenterBaySpacing IS NOT NULL)
	then
		SET _DefaultBaySpacingID = dbo.GetPropertyValueIDByValue_PropertyID(30, _CenterBaySpacing);
	
	ELSE
	
		SET _DefaultBaySpacingID = NULL;
	END if;
	SET _StructureWidth = dbo.GetProductPropertyValue_Int(_StructureID, 6);
    call GetWidthRangePropertyValueID_ByWidth(_StructureWidth);
	IF (_ProductName = '')
	then
		SELECT *
		FROM Products
		WHERE ProductID NOT IN (
				SELECT DISTINCT ProductID
				FROM ProductsPropertiesValues
				WHERE (
						(PropertyID = 6)
						AND (PropertyValueID <> _StructureWidthID)
						)
					OR (
						(PropertyID = 101)
						AND (PropertyValueID <> _MembraneTypeID)
						)
					OR 
					(
						(PropertyID = 54)
						AND (PropertyValueID <> _InsulationTypeID)
						)
					OR (
						(PropertyID = 7)
						AND (PropertyValueID <> _ISInsulatedID)
						)
					OR (
						(PropertyID = 30)
						AND (
							(_DefaultBaySpacingID IS NOT NULL)
							AND (PropertyValueID <> _DefaultBaySpacingID)
							)
						)
					OR (
						(PropertyID = 104)
						AND (
							PropertyValueID NOT IN (
								SELECT *
								FROM GetWidthRangePropertyValueID_ByWidth_t
								)
							)
						) 
					OR (
						(PropertyID = 105)
						AND (PropertyValueID <> _IsLatticeValueID)
						) 
					OR (
						(PropertyID = 106)
						AND (PropertyValueID <> _SpecialWidthValueID)
						)
				
					OR (
						(PropertyID = 123)
						AND (PropertyValueID <> _InsulationPackageID)
						) 
				)
			AND ProductID IN (
				SELECT DISTINCT ProductID
				FROM ProductsPropertiesValues
				WHERE (
						(PropertyID = 115)
						AND (PropertyValueID = 654)
						)
				)
			AND IsVisible = 1
			AND ProductTypeID NOT IN (
				1
				,2
				,3
				,12
				,13
				,14
				)
			AND (
				(
					_ProductTypeID != 0
					AND _ProductTypeID = ProductTypeID
					)
				OR (_ProductTypeID = 0)
				) 
		ORDER BY ParentID,SortOrder ;
	
	ELSE
	
		SELECT *
		FROM Products
		WHERE ProductID NOT IN (
				SELECT DISTINCT ProductID
				FROM ProductsPropertiesValues
				WHERE (
						(PropertyID = 6)
						AND (PropertyValueID <> _StructureWidthID)
						)
					OR (
						(PropertyID = 101)
						AND (PropertyValueID <> _MembraneTypeID)
						)
					OR 
					(
						(PropertyID = 54)
						AND (PropertyValueID <> _InsulationTypeID)
						)
					OR (
						(PropertyID = 7)
						AND (PropertyValueID <> _ISInsulatedID)
						)
					OR (
						(PropertyID = 30)
						AND (
							(_DefaultBaySpacingID IS NOT NULL)
							AND (PropertyValueID <> _DefaultBaySpacingID)
							)
						) 
					OR (
						(PropertyID = 104)
						AND (
							PropertyValueID NOT IN (
								SELECT *
								FROM  GetWidthRangePropertyValueID_ByWidth_t
								)
							)
						) 
					OR (
						(PropertyID = 105)
						AND (PropertyValueID <> _IsLatticeValueID)
						) 
					OR (
						(PropertyID = 106)
						AND (PropertyValueID <> _SpecialWidthValueID)
						) 
				
					OR (
						(PropertyID = 123)
						AND (PropertyValueID <> _InsulationPackageID)
						) 
				)
			AND Products.ProductName LIKE concat( '%' , _ProductName , '%')
			AND ProductID IN (
				SELECT DISTINCT ProductID
				FROM ProductsPropertiesValues
				WHERE (PropertyID = 115)
					AND (PropertyValueID = 654)
				)
			AND IsVisible = 1
		
			AND ProductTypeID NOT IN (
				1
				,2
				,3
				,12
				,13
				,14
				)
			AND (
				(
					_ProductTypeID != 0
					AND _ProductTypeID = ProductTypeID
					)
				OR (_ProductTypeID = 0)
				)
		ORDER BY ParentID
			,SortOrder;
	
END if;
end;
