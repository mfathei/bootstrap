CREATE PROCEDURE itcquote.spInsertRelatedQuoteItem(IN `_QuoteID`          INT, IN `_ProductID` INT,
                                                   IN `_Notes`            VARCHAR(10000), IN `_ItemName` VARCHAR(500),
                                                   IN `_ItemTypeID`       INT, IN `_NoOfConnections` INT,
                                                   IN `_RequiredLength`   FLOAT, IN `_InteriorDoorID` INT,
                                                   IN `_ExteriorDoorID`   INT, IN `_WindowID` INT, IN `_LogoID` INT,
                                                   IN `_Quantity`         FLOAT, IN `_QuantityInterior` FLOAT,
                                                   IN `_QuantityExterior` FLOAT, IN `_QuantityWindow` FLOAT,
                                                   IN `_HasSpecialName`   BIT)
  BEGIN
	DECLARE _QuantityCal FLOAT default  1;
    declare _SalePrice ,_LeaseTermAPrice ,_LeaseTermBPrice decimal (19,11);
		declare _SalePriceInterior decimal(19,11) default 0;
		declare _LeaseTermAPriceInterior decimal(19,11) default 0;
		 declare _LeaseTermBPriceInterior decimal(19,11) default 0;
		 declare _SalePriceExterior decimal(19,11) default 0;
		declare _LeaseTermAPriceExterior decimal(19,11) default 0;
		 declare _LeaseTermBPriceExterior decimal(19,11) default 0;
		declare _SalePriceWindow decimal(19,11) default 0;
		 declare _LeaseTermAPriceWindow decimal(19,11) default 0;
		declare _LeaseTermBPriceWindow decimal(19,11) default  0;
		declare _SalePriceLogo decimal(19,11) default  0;
		declare _LeaseTermAPriceLogo decimal(19,11) default 0;
		declare _LeaseTermBPriceLogo decimal(19,11) default  0;
		declare _Manhours ,_Length ,_Width  FLOAT;
		declare _ProductName VARCHAR(200);
		declare _IsDisplayedInReports ,_IsInsulated 	,_IsAutoAdded,_IsSnowLoad BIT;
		declare _InsulationTypeID ,_ProductTypeID ,_Termination ,_ConnectionFees ,_Product20ID ,_StructureWidthID ,_FabricTypeID ,_SubtractFees INT;
		
	
	
		-- Salma modified on 17-7-2014 use QuoteID  to get FabricType to be used in Cannopies,Vestibules & Corridors
	
		-- ,_prfaba float=0
		-- ,_prfabb float=0
		-- ,_prfabs float=0
		
		declare _Connections INT default 1;
		declare _intWalls INT default 0;
		declare _PricingPolicyID ,_SaleTypeID ,_LeaseTermAID ,_LeaseTermBID int ;
		-- ,_NoOfRoundEnds int
		-- ,_NoOfCenterBays int
		declare _CenterBaySpacing FLOAT;
		-- ,_NoOfCraneBreakPoints int
		-- ,_SnowRate int
		-- ,_StandardCenterBaySpacing float --<------ Standard measures  
		-- ,_StructureStandardLength float
		declare _StandardSQFT FLOAT;
		declare _ID INT default  0;
       if _ItemTypeID=null or _ItemTypeID='' then set _ItemTypeID=1; end if;
	   if _Quantity=null or _Quantity='' then set _Quantity=1; end if; 
	   if _QuantityInterior=null or _QuantityInterior='' then set _QuantityInterior=1; end if; 
	   if _QuantityExterior=null or _QuantityExterior='' then set _QuantityExterior=1; end if; 
	   if _HasSpecialName=null or _HasSpecialName='' then set _HasSpecialName=0; end if;
        
	SET _IsAutoAdded = 0;
	SET _SaleTypeID = 1;
	SELECT _PricingPolicyID = PricingPolicyID
		,_LeaseTermAID = LeaseTermAID
		,_LeaseTermBID = LeaseTermBID
	-- ,_SnowRate = SnowRate,
	-- _NoOfCenterBays = NoOfCenterBays,
	-- _NoOfRoundEnds = NoOfRoundEnds,
	-- _NoOfCraneBreakPoints = NoOfCraneBreakPoints
	FROM Quotes
	WHERE (QuoteID = _QuoteID);
	SELECT _FabricTypeID = FabricTypeID
	FROM Quotes
	WHERE QuoteID = _QuoteID;
	SELECT _InsulationTypeID = InsulationTypeID
	FROM Quotes
	WHERE (QuoteID = _QuoteID);
	SET _IsInsulated = dbo.IsInsulated(_InsulationTypeID);
	-- prices calculation-
	SET _SalePrice = dbo.GetProductPrice(_ProductID, _PricingPolicyID, 1, _SaleTypeID);
	SET _LeaseTermAPrice = dbo.GetProductPrice(_ProductID, _PricingPolicyID, 2, _LeaseTermAID);
	SET _LeaseTermBPrice = dbo.GetProductPrice(_ProductID, _PricingPolicyID, 2, _LeaseTermBID);
	IF _InteriorDoorID IS NOT NULL
	then
		SET _SalePriceInterior = dbo.GetProductPrice(_InteriorDoorID, _PricingPolicyID, 1, _SaleTypeID) * _QuantityInterior;
		SET _LeaseTermAPriceInterior = dbo.GetProductPrice(_InteriorDoorID, _PricingPolicyID, 2, _LeaseTermAID) * _QuantityInterior;
		SET _LeaseTermBPriceInterior = dbo.GetProductPrice(_InteriorDoorID, _PricingPolicyID, 2, _LeaseTermBID) * _QuantityInterior;
	END if;
	IF _ExteriorDoorID IS NOT NULL
	then
		SET _SalePriceExterior = dbo.GetProductPrice(_ExteriorDoorID, _PricingPolicyID, 1, _SaleTypeID) * _QuantityExterior;
		SET _LeaseTermAPriceExterior = dbo.GetProductPrice(_ExteriorDoorID, _PricingPolicyID, 2, _LeaseTermAID) * _QuantityExterior;
		SET _LeaseTermBPriceExterior = dbo.GetProductPrice(_ExteriorDoorID, _PricingPolicyID, 2, _LeaseTermBID) * _QuantityExterior;
	end if;
	IF _WindowID IS NOT NULL
	then 
		SET _SalePriceWindow = dbo.GetProductPrice(_WindowID, _PricingPolicyID, 1, _SaleTypeID) * _QuantityWindow;
		SET _LeaseTermAPriceWindow = dbo.GetProductPrice(_WindowID, _PricingPolicyID, 2, _LeaseTermAID) * _QuantityWindow;
		SET _LeaseTermBPriceWindow = dbo.GetProductPrice(_WindowID, _PricingPolicyID, 2, _LeaseTermBID) * _QuantityWindow;
	END if;
	IF _LogoID IS NOT NULL
	then
		SET _SalePriceLogo = dbo.GetProductPrice(_LogoID, _PricingPolicyID, 1, _SaleTypeID);
		SET _LeaseTermAPriceLogo = dbo.GetProductPrice(_LogoID, _PricingPolicyID, 2, _LeaseTermAID);
		SET _LeaseTermBPriceLogo = dbo.GetProductPrice(_LogoID, _PricingPolicyID, 2, _LeaseTermBID);
	END if;
	-- -Modified by Salma 01-05-2013 
	-- modify STRUCTURE product Sales price based on insultaion, width & length--
	-- adding surcharge price per sqft to Width structure Sale price for Non-insulated structures
	SET _ProductTypeID = dbo.GetProductTypeByProductID(_ProductID);
	-- --------------------------------------------------------------------------------------------------
	-- Modified by Salma 17-7-2014---added the following to be used in cannopies & vestibules calculations
	-- IF(_ProductTypeID=41 OR _ProductTypeID=42)
	-- BEGIN
	-- --IF(_FabricTypeID=4 OR _FabricTypeID=426) 
	/*--	--BEGIN
	--	--   IF( _PricingPolicyID=1 )
	--	--   BEGIN
	--	--	SET _prfaba=4.30
	--	--	SET _prfabb=4.30
	--	--	SET _prfabs=4.30
	--	--  END
	--	--  ELSE 
	--	--  BEGIN
	--	--	SET _prfaba=4.70
	--	--	SET _prfabb=4.70
	--	--	SET _prfabs=4.70
	--	--  END
	--	--END
	-- --  ELSE
	-- --  BEGIN
	--	--	SET _prfaba=4.30
	--	--	SET _prfabb=4.30
	--	--	SET _prfabs=4.30
	--	--END 
	--SET _prfabs = dbo.GetProductPrice(_ProductID, _PricingPolicyID, 1, _SaleTypeID)
	--   SET _prfaba = dbo.GetProductPrice(_ProductID, _PricingPolicyID, 2, _LeaseTermAID)
	--SET _prfabb = dbo.GetProductPrice(_ProductID, _PricingPolicyID, 2, _LeaseTermBID)
	--   -- SET _prfaba=_LeaseTermAPrice
	---- SET _prfabb=_LeaseTermBPrice
	---- SET _prfabs=_SalePrice
	--   END*/
	SET _Width = dbo.GetProductPropertyValue(_ProductID, 2);
	IF (
			_ProductTypeID = 41
			OR _ProductTypeID = 42
			)
	then
		SET _Length = 12.5 --dbo.GetProductPropertyValue(_ProductID,1);
	END if;
	IF (_ProductTypeID = 21)
	then
		SET _Length = _RequiredLength;
		SET _CenterBaySpacing = dbo.GetProductPropertyValue(_ProductID, 116);
		SET _StandardSQFT = (CEILING(_Length / _CenterBaySpacing) * _CenterBaySpacing) * _Width;
		-- manhours calculation-
		SET _Manhours = CEILING(_StandardSQFT * dbo.GetProductManhours(_ProductID, _IsInsulated));
	
	ELSE
	
		-- manhours calculation-
		SET _Manhours = dbo.GetProductManhours(_ProductID, _IsInsulated);
	END if;
	IF _InteriorDoorID IS NOT NULL
	then
		SET _Manhours = _Manhours + (dbo.GetProductManhours(_InteriorDoorID, _IsInsulated) * _QuantityInterior);
	END if;
	IF _ExteriorDoorID IS NOT NULL
	then
		SET _Manhours = _Manhours + (dbo.GetProductManhours(_ExteriorDoorID, _IsInsulated) * _QuantityExterior);
	END if;
	IF _WindowID IS NOT NULL
	then
		SET _Manhours = _Manhours + (dbo.GetProductManhours(_WindowID, _IsInsulated) * _QuantityWindow);
	END if;
	IF _LogoID IS NOT NULL
	then
		SET _Manhours = _Manhours + (dbo.GetProductManhours(_LogoID, _IsInsulated));
	END if;
	/*---Standard SQFT calculation---------------------
	--SET _StandardCenterBaySpacing = dbo.GetStructureStandardCenterBaySpacing(_ProductID, _CenterBaySpacing, _SnowRate)
	--SET _StructureStandardLength = dbo.GetStructureStandardLength(_NoOfCenterBays, _StandardCenterBaySpacing, _NoOfRoundEnds, _Width)
	--SET _StandardSQFT = dbo.GetStructureStandardSQFT(_Width, _Length, _NoOfCraneBreakPoints, _StandardCenterBaySpacing, _StructureStandardLength, 0)
	----Modified by Salma 15-01-2014----------added the calculation for canopies-------*/
	IF (_ProductTypeID = 41)
	then
		-- SET _ConnectionFees=dbo.GetProductPropertyValue(_ProductID,78)
		-- SET _Termination=dbo.GetProductPropertyValue(_ProductID,108)*10*2*_Length
		SET _SalePrice = _SalePrice + _SalePriceLogo; -- +_ConnectionFees+_Termination
		SET _LeaseTermAPrice = _LeaseTermAPrice + _LeaseTermAPriceLogo; -- + _ConnectionFees+_Termination
		SET _LeaseTermBPrice = _LeaseTermBPrice + _LeaseTermBPriceLogo; -- + _ConnectionFees+_Termination
	END if;
	 -- Modified by Salma 16-07-2014----------added the calculation for vestibules-------
	IF (_ProductTypeID = 42)
	then
		-- SET _ConnectionFees=dbo.GetProductPropertyValue(_ProductID,78)
		-- SET _Termination=dbo.GetProductPropertyValue(_ProductID,108)*10*2*_Length
		SET _SalePrice = _SalePrice + _SalePriceInterior + _SalePriceExterior + _SalePriceWindow + _SalePriceLogo; -- + _ConnectionFees+_Termination
		SET _LeaseTermAPrice = _LeaseTermAPrice + _LeaseTermAPriceInterior + _LeaseTermAPriceExterior + _LeaseTermAPriceWindow + _LeaseTermAPriceLogo; -- + _ConnectionFees+_Termination
		SET _LeaseTermBPrice = _LeaseTermBPrice + _LeaseTermBPriceInterior + _LeaseTermBPriceExterior + _LeaseTermBPriceWindow + _LeaseTermBPriceLogo; -- + _ConnectionFees+_Termination
	END if;
	-- --Modified by Salma 17-07-2014----------added the calculation for corrdiors-------
	IF (_ProductTypeID = 21)
	then
		SET _Connections = _NoOfConnections;
		SET _Connections = ifnull(_Connections, 1);
		-- SET _QuantityCal=_Length*_Width
		-- SET _QuantityCal= ISNULL(_QuantityCal,1)
		SET _ConnectionFees = dbo.GetProductPropertyValue(_ProductID, 78);
		-- SET _SubtractFees=dbo.GetProductPropertyValue(_ProductID,79)
		SET _ConnectionFees = ((_Connections * _ConnectionFees)) ;-- -(_intWalls*_SubtractFees))
		SET _SalePrice = (_StandardSQFT * _SalePrice) + _SalePriceInterior + _SalePriceExterior + _SalePriceWindow + _SalePriceLogo + _ConnectionFees;
		IF (_LeaseTermAID <> 0)
		then
			SET _LeaseTermAPrice = (_StandardSQFT * _LeaseTermAPrice) + _LeaseTermAPriceInterior + _LeaseTermAPriceExterior + _LeaseTermAPriceWindow + _LeaseTermAPriceLogo + _ConnectionFees;
		ELSE
		
			SET _LeaseTermAPrice = 0;
		END if;
		IF (_LeaseTermBID <> 0)
		then
			SET _LeaseTermBPrice = (_StandardSQFT * _LeaseTermBPrice) + _LeaseTermBPriceInterior + _LeaseTermBPriceExterior + _LeaseTermBPriceWindow + _LeaseTermBPriceLogo + _ConnectionFees;
		
		ELSE
		
			SET _LeaseTermBPrice = 0;
		END if;
	END if;
	-- --------------------------------------------------------------------------------
	SELECT  QuoteLetterProductName
		, IsDisplayedInReports
	into
	_ProductName,_IsDisplayedInReports
	FROM Products
	WHERE (ProductID = _ProductID);
	-- IF(_ProductTypeID=21)--rename corrdior product accroding to length
	-- BEGIN
	-- SET _ProductName+=' '+CONVERT(varchar(10), _Length)+''' long Num: '+CONVERT(varchar(10), _ItemName)
	-- END
	-- ELSE
	-- BEGIN
	-- SET _ProductName+=' Num: '+CONVERT(varchar(10), _ItemName)
	-- END
	-- SET _ProductName = _ItemName;
	-- DELETE QuotesItems WHERE (QuoteID = _QuoteID) AND (ProductID = _ProductID) AND(ItemName=_ItemName)
	-- DELETE RelatedProducts WHERE (QuoteID = _QuoteID) AND (ProductID = _ProductID) AND(ItemName=_ItemName)
	INSERT INTO QuotesItems (
		QuoteID
		,ProductID
		,ItemName
		,
		-- Salma modified on 22-7-2015 to add special name in case of Corridors 
		HasSpecialName
		,ItemTypeID
		,IsAutoAdded
		,IsDisplayedInReports
		,Quantity
		,OriginalSalePrice
		,OriginalLeaseTermAPrice
		,OriginalLeaseTermBPrice
		,OriginalManhours
		,CustomSalePrice
		,CustomLeaseTermAPrice
		,CustomLeaseTermBPrice
		,CustomManhours
		,Notes
		,NoOfConnectedStructures
		,RequiredLength
		)
	VALUES (
		_QuoteID
		,_ProductID
		,ifnull(_ProductName, '')
		,
		-- Salma modified on 22-7-2015 to add special name in case of Corridors 
		_HasSpecialName
		,_ItemTypeID
		,_IsAutoAdded
		,_IsDisplayedInReports
		,_Quantity
		,_SalePrice
		,_LeaseTermAPrice
		,_LeaseTermBPrice
		,_Manhours
		,_SalePrice
		,_LeaseTermAPrice
		,_LeaseTermBPrice
		,_Manhours
		,_Notes
		,_Connections
		,_Length
		);
	INSERT INTO RelatedProducts (
		QuoteID
		,ProductID
		,InteriorDoor
		,ExteriorDoor
		,Window
		,Logo
		,InteriorDoorQuantity
		,ExteriorDoorQuantity
		,WindowQuantity
		)
	VALUES (
		_QuoteID
		,_ProductID
		,_InteriorDoorID
		,_ExteriorDoorID
		,_WindowID
		,_LogoID
		,_QuantityInterior
		,_QuantityExterior
		,_QuantityWindow
		);
	SELECT  last_insert_id() into  _ID ;
	IF (_ID <> 0)
	then
		UPDATE QuotesItems
		SET RelatedProductID = _ID
		WHERE QuoteID = _QuoteID
			AND ProductID = _ProductID
			AND RelatedProductID = 0;
	END if;
	SELECT _ID AS RelatedProductID;
end;
