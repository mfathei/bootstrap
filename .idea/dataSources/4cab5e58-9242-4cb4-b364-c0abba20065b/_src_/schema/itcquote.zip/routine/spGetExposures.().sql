CREATE PROCEDURE itcquote.spGetExposures()
  begin	
call  spGetPropertyValues( 58);
END;
