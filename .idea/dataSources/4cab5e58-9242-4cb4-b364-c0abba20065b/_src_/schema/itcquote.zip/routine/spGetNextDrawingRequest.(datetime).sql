CREATE PROCEDURE itcquote.spGetNextDrawingRequest(IN `_Date` DATETIME)
  BEGIN
select  * from DrawingRequests
	where PromisedDeliveryDate >= _Date     
	order by PromisedDeliveryDate,DrawingRequestID  asc limit 0,1;
END;
