CREATE FUNCTION itcquote.GetProductID(pProductTypeID INT, pPropertyID INT, pPropertyValueID INT, pTheValue VARCHAR(100))
  RETURNS INT
  BEGIN
	-- Salma: modified in 28-2-2013: added null condition, added like condition
	DECLARE vResult INT;
	declare pQuoteVal VARCHAR(255);
    IF pPropertyValueID IS NULL
    THEN
        SET pPropertyValueID = 0;
    END IF;
    IF pTheValue IS NULL
    THEN
        SET pTheValue = '';
    END IF;
	SET pQuoteVal = GetPropertyValue(pPropertyValueID);
    CALL GetWidthRangePropertyValueID_ByWidth(pPropertyValueID);
	IF pPropertyValueID = 0
	then
		SELECT ProductsPropertiesValues.ProductID into vResult 
		FROM ProductsPropertiesValues
		INNER JOIN PropertiesValues ON ProductsPropertiesValues.PropertyValueID = PropertiesValues.PropertyValueID
		WHERE (ProductsPropertiesValues.ProductTypeID = pProductTypeID)
			AND (ProductsPropertiesValues.PropertyID = pPropertyID)
			AND (PropertiesValues.TheValue = pTheValue);
	
	ELSE
		SELECT T1.ProductID INTO vResult 
		FROM ProductsPropertiesValues AS T1
		INNER JOIN Properties ON Properties.PropertyID = T1.PropertyID
		INNER JOIN PropertiesValues AS PV ON Properties.PropertyID = PV.PropertyID
		-- Modified by salma on 3-4-2014--  to get producttypeid from product
		-- INNER JOIN PropertiesValues AS PV2 on P2.PropertyID = PV2.PropertyID
		INNER JOIN Products ON Products.ProductID = T1.ProductID
		WHERE (Products.ProductTypeID = pProductTypeID)
			AND
			-- WHERE  (T1.ProductTypeID = pProductTypeID) AND
			(T1.PropertyID = pPropertyID)
			AND
			-- (T1.PropertyValueID = pPropertyValueID) AND
			--  Salma: Modified in 26-3-2014
			(
				(
					-- (pPropertyID != 101) AND
					(
						(
							(
								(pPropertyValueID IS NOT NULL)
								AND (T1.PropertyValueID = pPropertyValueID)
								)
							OR (
								(pPropertyID = 106)
								AND (pPropertyValueID IS NOT NULL)
								AND (T1.PropertyValueID = 502)
								)
							OR --  property value = Other
							--  if property value id = null (property exists but has no value)
							(
								(pPropertyValueID IS NULL)
								AND (T1.PropertyValueID IS NULL)
								)
							OR
							-- -- Salma: Modified in 18-3-2014 added the condition for WidthRange 
							(
								(pPropertyValueID IS NOT NULL)
								AND (
									(pPropertyID = 104)
									AND T1.PropertyValueID IN (
										SELECT *
										FROM GetWidthRangePropertyValueID_ByWidth_t -- GetWidthRangePropertyValueID_ByWidth(pPropertyValueID)
										)
									)
								)
							)
						)
					)
				--  OR
				--  --  if property = FabricType, then use like instead of equal
				-- ((pPropertyID = 101) AND
				--    (((pPropertyValueID is not null) AND (((T1.PropertyID = pPropertyID) AND (T1.PropertyValueID = PV.PropertyValueID) 
				--  AND (pQuoteVal like PV.TheValue , '%'))))) OR 
				-- ((pPropertyValueID is null) AND (T1.PropertyValueID is null)))))
				);
	END if;
	RETURN IFNULL(vResult, 0);
END;
