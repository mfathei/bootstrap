CREATE FUNCTION itcquote.xml_tag(tagname VARCHAR(2000), tagvalue VARCHAR(2000), attrs VARCHAR(2000),
                                 subtags VARCHAR(2000))
  RETURNS VARCHAR(2000)
  BEGIN
DECLARE result VARCHAR(2000);
SET result = CONCAT('<' , tagname);
IF attrs IS NOT NULL THEN
SET result = CONCAT(result,' ', attrs);
END IF;
IF (tagvalue IS NULL AND subtags IS NULL) THEN
RETURN CONCAT(result,' />');
END IF;
RETURN CONCAT(result ,'>',ifnull(xml_escape(IFNULL(tagvalue, '')),''),
ifnull(subtags,''),'</',tagname, '>');
END;
