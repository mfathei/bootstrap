CREATE PROCEDURE itcquote.spGetDrawingRequestsTable(IN `_AccountID`  INT, IN `_TerritoryID` INT, IN `_QuoteID` INT,
                                                    IN `_StatusID`   INT, IN `_PageNo` INT, IN `_PageSize` INT,
                                                    IN `_SortColumn` VARCHAR(20), IN `_SortOrder` VARCHAR(4))
  BEGIN
	DECLARE _lPageNbr,_lPageSize ,_lFirstRec ,_lLastRec ,_lTotalRows   INT;
    declare _lSortCol NVARCHAR(20);
    DECLARE _IsAdmin BIT;
    DECLARE _StatusGroupID int;
  
	if _AccountID is null or _AccountID='' then set _AccountID=0;  end if;
	if _PageNo is null or _PageNo='' then set  _PageNo=1;           end if;
	if _PageSize is null or _PageSize='' then set _PageSize=200 ; end if;
	if _SortColumn is null or _SortColumn='' then set _SortColumn='DrawingRequestID' ; end if;
	if _SortOrder is null or _SortOrder='' then set _SortOrder='Desc' ; end if;
    
	SET _lPageNbr = _PageNo;
	SET _lPageSize = _PageSize;
	SET _lSortCol = TRIM(_SortColumn);
	SET _lFirstRec = (_lPageNbr - 1) * _lPageSize;
	SET _lLastRec = (_lPageNbr * _lPageSize + 1);
	SET _lTotalRows = _lFirstRec - _lLastRec + 1;
	-- Modified by salma 4-2-2014 make added conditions for Isadmin to allow Admins to view all Quotes even Private
	SET _IsAdmin = (
			SELECT IsAdmin
			FROM Accounts
			WHERE AccountID = _AccountID
			);
drop TEMPORARY TABLE if exists	 xx;
    CREATE TEMPORARY TABLE  xx AS (select fnGetStatus(_StatusGroupID) );
	--  group status of drawing requests from  fnGetStatus
	SET _StatusGroupID = 2;
drop temporary table if exists CTE_Results;
create temporary table  CTE_Results
	AS (
		SELECT @i:=@i+1 AS ROWNUM, 
			 Count(*)  AS TotalCount
			,DrawingRequests.DrawingRequestID
			,DrawingRequests.Caption
			,DrawingRequests.CreateDate
			,DrawingRequests.StatusID
			,tbStatus.StatusName
			,DrawingRequests.Comments
			,tbDrawingsCount.DrawingsCount
			,DrawingRequests.CreateAccountID
			,DrawingRequests.ModifyAccountID
			,DrawingRequests.ModifyDate
			,DrawingRequests.AttentionID
			,DrawingRequests.CompletedForID
			,DrawingRequests.ScopeID
			,DrawingRequests.QuoteID
			,DrawingRequests.ReferenceDrawingRequestID
			,DrawingRequests.SendToID
			,DrawingRequests.SendViaID
			,DrawingRequests.DrawingTypeID
			,DrawingRequests.DrawingCategoryID
			,DrawingRequests.DrawingSizeID
			,DrawingRequests.DrawingUnitID
			,DrawingRequests.DeliveryPoint
			,DrawingRequests.RequestedDeliveryDate
			,DrawingRequests.PromisedDeliveryDate
			,DrawingRequests.IsStamped
			,DrawingRequests.NoOfCopies,
		/*	--Modified by salma 19-4-2015 added calling to function to get DwgNum of drawings related to this drawing Request*/
			getDrawingsNumForDrawingRequest(DrawingRequests.DrawingRequestID) AS DrawingsNum
		FROM   (SELECT @i:=0) AS foo, DrawingRequests
		INNER JOIN Accounts ON DrawingRequests.CreateAccountID = Accounts.AccountID
		LEFT  JOIN (
			SELECT DrawingRequests_1.DrawingRequestID
				,COUNT(*) AS DrawingsCount
			FROM DrawingRequests AS DrawingRequests_1
			INNER JOIN Drawings ON DrawingRequests_1.DrawingRequestID = Drawings.DrawingRequestID
			GROUP BY DrawingRequests_1.DrawingRequestID
			) AS tbDrawingsCount ON DrawingRequests.DrawingRequestID = tbDrawingsCount.DrawingRequestID
		LEFT  JOIN      xx   AS tbStatus ON DrawingRequests.StatusID = tbStatus.StatusID
		WHERE (
				(
					(DrawingRequests.ScopeID = 1)
					AND (
						DrawingRequests.CreateAccountID = _AccountID
						OR _IsAdmin = 1
						)
					)
				OR (
					(DrawingRequests.ScopeID = 2)
					AND (
						(
							DrawingRequests.CreateAccountID IN (
								SELECT AccountID
								FROM Accounts
								WHERE TerritoryID = _TerritoryID
								)
							)
						OR (_IsAdmin = 1)
						)
					)
				OR ((DrawingRequests.ScopeID IS NULL))
				OR ((DrawingRequests.CreateAccountID IS NULL))
				OR ((DrawingRequests.ScopeID = 3))
				)
			AND (
				(
					(
						_QuoteID IS NULL
						OR _QuoteID = 0
						)
					OR (QuoteID = _QuoteID)
					)
				AND (
					_StatusID IS NULL
					OR _StatusID = 0
					OR (DrawingRequests.StatusID = _StatusID)
					)
				) 
                ORDER BY CASE 
						WHEN (
								_lSortCol = 'DrawingRequestID'
								AND _SortOrder = 'ASC'
								)
							THEN DrawingRequests.DrawingRequestID
						END ASC
					,CASE 
						WHEN (
								_lSortCol = 'DrawingRequestID'
								AND _SortOrder = 'DESC'
								)
							THEN DrawingRequests.DrawingRequestID
						END DESC
					,CASE 
						WHEN (
								_lSortCol = 'Caption'
								AND _SortOrder = 'ASC'
								)
							THEN Caption
						END ASC
					,CASE 
						WHEN (
								_lSortCol = 'Caption'
								AND _SortOrder = 'DESC'
								)
							THEN Caption
						END DESC
					,CASE 
						WHEN (
								_lSortCol = 'CreateDate'
								AND _SortOrder = 'ASC'
								)
							THEN CreateDate
						END ASC
					,CASE 
						WHEN (
								_lSortCol = 'CreateDate'
								AND _SortOrder = 'DESC'
								)
							THEN CreateDate
						END DESC
					,CASE 
						WHEN (
								_lSortCol = 'PromisedDeliveryDate'
								AND _SortOrder = 'ASC'
								)
							THEN PromisedDeliveryDate
						END ASC
					,CASE 
						WHEN (
								_lSortCol = 'PromisedDeliveryDate'
								AND _SortOrder = 'DESC'
								)
							THEN PromisedDeliveryDate
						END DESC
					,CASE 
						WHEN (
								_lSortCol = 'DrawingsNum'
								AND _SortOrder = 'ASC'
								)
							THEN getDrawingsNumForDrawingRequest(DrawingRequests.DrawingRequestID)
						END ASC
					,CASE 
						WHEN (
								_lSortCol = 'DrawingsNum'
								AND _SortOrder = 'DESC'
								)
							THEN getDrawingsNumForDrawingRequest(DrawingRequests.DrawingRequestID)
						END DESC
					,CASE 
						WHEN (
								_lSortCol = 'StatusName'
								AND _SortOrder = 'ASC'
								)
							THEN StatusName
						END ASC
					,CASE 
						WHEN (
								_lSortCol = 'StatusName'
								AND _SortOrder = 'DESC'
								)
							THEN StatusName
						END DESC
		);
         
        
				
	SELECT TotalCount
		,ROWNUM
		,DrawingRequestID
		,Caption
		,CreateDate
		,StatusID
		,StatusName
		,Comments
		,DrawingsCount
		,CreateAccountID
		,ModifyAccountID
		,ModifyDate
		,AttentionID
		,CompletedForID
		,ScopeID
		,QuoteID
		,ReferenceDrawingRequestID
		,SendToID
		,SendViaID
		,DrawingTypeID
		,DrawingCategoryID
		,DrawingSizeID
		,DrawingUnitID
		,DeliveryPoint
		,RequestedDeliveryDate
		,PromisedDeliveryDate
		,IsStamped
		,NoOfCopies
		,DrawingsNum
	FROM CTE_Results AS CPC
	WHERE ROWNUM > _lFirstRec
		AND ROWNUM < _lLastRec
	ORDER BY ROWNUM ASC;
END;
