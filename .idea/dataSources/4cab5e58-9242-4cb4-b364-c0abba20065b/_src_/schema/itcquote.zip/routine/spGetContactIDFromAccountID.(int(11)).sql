CREATE PROCEDURE itcquote.spGetContactIDFromAccountID(IN `_AccountID` INT)
  BEGIN
	SELECT Contacts.ContactID
	FROM Contacts
	INNER JOIN Accounts ON Contacts.ContactID = Accounts.ContactID
	WHERE (Accounts.AccountID = _AccountID);
END;
