CREATE FUNCTION itcquote.getOccurrence(str VARCHAR(21844), subText VARCHAR(50))
  RETURNS INT
  begin
    
    declare vResult INT DEFAULT 0 ;
    
    set @res = locate(subText, str);
    
    while @res > 0 do
        SET vResult = vResult + 1;
        SET @res = LOCATE(subText, str, @res + 1);
    end while;
    
    
    return vResult;
end;
