CREATE PROCEDURE itcquote.spGetInsulationThickness()
  begin	
call  spGetPropertyValues (49);
END;
