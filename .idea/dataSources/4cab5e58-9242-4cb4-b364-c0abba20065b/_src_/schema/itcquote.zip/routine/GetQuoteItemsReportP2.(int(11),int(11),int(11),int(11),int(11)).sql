CREATE FUNCTION itcquote.GetQuoteItemsReportP2(pQuoteID      INT, pReportTypeID INT, vDisplayedInReports INT,
                                               vLeaseTermAID INT, vLeaseTermBID INT)
  RETURNS TEXT
  BEGIN
        declare vResult text charset utf8 default '';
        DECLARE vProductName TEXT CHARSET utf8 DEFAULT '';
        -- DECLARE vProductNameOnly TEXT CHARSET utf8 DEFAULT '';
        declare vQuantity VARCHAR(50);
        declare vCustomLeaseTermAPrice varchar(50);
        DECLARE vCustomLeaseTermBPrice VARCHAR(50);
        DECLARE vCustomSalePrice VARCHAR(50);
        DECLARE vCustomManhours VARCHAR(50);
        DECLARE vExtendedLeaseTermAPrice VARCHAR(50);
        DECLARE vExtendedLeaseTermBPrice VARCHAR(50);
        DECLARE vExtendedSalePrice VARCHAR(50);
        DECLARE vExtendedManhours VARCHAR(50);
        
        DECLARE cFinished int default 0;
        DECLARE vDisplayedInReports int;
        declare cur_1 cursor for SELECT
				-- Salma Modified on 21-7-2015 -- added the conditions for SpecialName in Letter
				CASE 
					WHEN (
							QuotesItems.HasSpecialName = 1
							OR pReportTypeID = '2'
							)
						THEN IFNULL(QuotesItems.ItemName, ' ')
					ELSE IFNULL(QuoteLetterProductName, ' ')
					END AS ProductName
				,
				--  IFNULL(QuotesItems.ItemName , ' ')as ProductName,
				-- IFNULL(QuotesItems.ItemName +' ('+ QuotesItems.Notes +')', QuotesItems.ItemName) AS ProductName,
				CASE 
					WHEN FormatQuoteItemQuantity(Products.ProductTypeID, QuotesItems.ProductID, QuotesItems.ItemName, QuotesItems.Quantity) >= 99999999
						THEN ' '
					ELSE CONVERT(QuotesItems.Quantity, CHAR(50))
					END AS Quantity
				,
				-- Salma: Modifed in 21-2-213 added ceiling in CustomLeaseTermAPrice & CustomeLeaseTermBPrice------------------------------------------------
				concat(TRIM(CONVERT(CAST(CEILING(QuotesItems.CustomLeaseTermAPrice / NULLIF(vLeaseTermAID, 0)) AS DECIMAL(10, 2)), CHAR(50))) , '/month') AS CustomLeaseTermAPrice
				,concat(TRIM(CONVERT(CAST(CEILING(QuotesItems.CustomLeaseTermBPrice / NULLIF(vLeaseTermBID, 0)) AS DECIMAL(10, 2)), CHAR(50))) , '/month') AS CustomLeaseTermBPrice
				,
				-- -------------------------------------------------------------------------------------------------------------------------------------------
				CONVERT(CAST(QuotesItems.CustomSalePrice AS DECIMAL(10, 2)), CHAR(50)) AS CustomSalePrice
				,CONVERT(CAST(QuotesItems.CustomManhours AS DECIMAL(10, 2)), CHAR(50)) AS CustomManhours
				,
				-- Salma: Modifed in 30-11-2014 removed the following comments to get prices totally without division
				CONVERT(CAST(QuotesItems.Quantity * QuotesItems.CustomLeaseTermAPrice AS DECIMAL(10, 2)), CHAR(50)) AS ExtendedLeaseTermAPrice
				,CONVERT( CAST(QuotesItems.Quantity * QuotesItems.CustomLeaseTermBPrice AS DECIMAL(10, 2)), CHAR(50)) AS ExtendedLeaseTermBPrice
				,CONVERT(CAST(QuotesItems.Quantity * QuotesItems.CustomSalePrice AS DECIMAL(10, 2)), CHAR(50)) AS ExtendedSalePrice
				,CONVERT(CAST(QuotesItems.Quantity * QuotesItems.CustomManhours AS DECIMAL(10, 2)), CHAR(50)) AS ExtendedManhours
			-- Salma: Modifed in 30-11-2014 commented the following lines to get prices totally without division
			-- Divide by QuantityUnit value for Earth Anchor product
			-- CONVERT(varchar(50), CAST(((QuotesItems.Quantity * QuotesItems.CustomLeaseTermAPrice)/IFNULL(NULLIF(GetProductPropertyValue(QuotesItems.ProductID,100), ''), 1))  AS money), 1) AS ExtendedLeaseTermAPrice, 
			-- CONVERT(varchar(50), CAST(((QuotesItems.Quantity * QuotesItems.CustomLeaseTermBPrice)/IFNULL(NULLIF(GetProductPropertyValue(QuotesItems.ProductID,100), ''), 1)) AS money), 1) AS ExtendedLeaseTermBPrice, 
			-- CONVERT(varchar(50), CAST(((QuotesItems.Quantity * QuotesItems.CustomSalePrice)/IFNULL(NULLIF(GetProductPropertyValue(QuotesItems.ProductID,100), ''), 1)) AS money), 1) AS ExtendedSalePrice, 
			-- CONVERT(varchar(50), CAST(((QuotesItems.Quantity * QuotesItems.CustomManhours)/IFNULL(NULLIF(GetProductPropertyValue(QuotesItems.ProductID,100), ''), 1)) AS money), 1) AS ExtendedManhours
			FROM QuotesItems
			LEFT JOIN Products ON QuotesItems.ProductID = Products.ProductID
			WHERE (QuotesItems.QuoteID = pQuoteID)
				AND (QuotesItems.ItemTypeID = 2)
				AND (
					(
						vDisplayedInReports IS NOT NULL
						AND QuotesItems.IsDisplayedInReports = 1
						)
					OR (vDisplayedInReports IS NULL)
					)
			ORDER BY FormatQuoteItemQuantity(Products.ProductTypeID, QuotesItems.ProductID, QuotesItems.ItemName, QuotesItems.Quantity)
				,QuotesItems.ItemName
				,QuotesItems.Notes
			-- FOR XML PATH('ExtraItem')
			;
			
			
	declare continue handler for not found set cFinished = 1;
	
    set @ln = '
';
	
	open cur_1;
			
    my_loop: LOOP
    
        fetch cur_1 into vProductName,vQuantity,vCustomLeaseTermAPrice,vCustomLeaseTermBPrice,vCustomSalePrice,vCustomManhours,vExtendedLeaseTermAPrice,vExtendedLeaseTermBPrice,vExtendedSalePrice,vExtendedManhours; 
        if cFinished = 1 then
            -- close cur_1;
            leave my_loop;
        end if;
        
        set vResult = concat(vResult , '<ExtraItem>', @ln); -- open row tag
        set vResult = concat(vResult , xml_tag('ProductName',vProductName,null,null), @ln);
        -- set vResult = concat(vResult , '<ProductNameOnly',vProductNameOnly),'</ProductNameOnly', @ln);
        set vResult = concat(vResult , xml_tag('Quantity',vQuantity,NULL,NULL), @ln);
        set vResult = concat(vResult , xml_tag('CustomLeaseTermAPrice',vCustomLeaseTermAPrice,NULL,NULL), @ln);
        set vResult = concat(vResult , xml_tag('CustomLeaseTermBPrice',vCustomLeaseTermBPrice,NULL,NULL), @ln);
        set vResult = concat(vResult , xml_tag('CustomSalePrice',vCustomSalePrice,NULL,NULL), @ln);
        set vResult = concat(vResult , xml_tag('CustomManhours',vCustomManhours,NULL,NULL), @ln);
        set vResult = concat(vResult , xml_tag('ExtendedLeaseTermAPrice',vExtendedLeaseTermAPrice,NULL,NULL), @ln);
        set vResult = concat(vResult , xml_tag('ExtendedLeaseTermBPrice',vExtendedLeaseTermBPrice,NULL,NULL), @ln);
        set vResult = concat(vResult , xml_tag('ExtendedSalePrice',vExtendedSalePrice,NULL,NULL), @ln);
        set vResult = concat(vResult , xml_tag('ExtendedManhours',vExtendedManhours,NULL,NULL), @ln);
        set vResult = concat(vResult , '</ExtraItem>', @ln); -- close row tag
    
    end LOOP my_loop;
    CLOSE cur_1;
    return vResult;
    END;
