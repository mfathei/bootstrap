CREATE PROCEDURE itcquote.spInsertTaxProducts(IN `_QuoteID` INT)
  BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	    DECLARE _ProductID INT;
		DECLARE _Quantity FLOAT;
		DECLARE _PricingPolicyID int;
		DECLARE _SaleTypeID int;
		DECLARE _LeaseTermAID int;
		DECLARE _LeaseTermBID int;
		DECLARE _LocationName VARCHAR(100);
		DECLARE _ParentLocationName VARCHAR(100);
		DECLARE _Constant FLOAT;
		DECLARE _OptionsLeaseAPrice decimal(19,11);
		DECLARE _OptionsLeaseBPrice decimal(19,11);
		DECLARE _OptionsSalePrice decimal(19,11);
		DECLARE _LeaseAPrice decimal(19,11);
		DECLARE _LeaseBPrice decimal(19,11);
		DECLARE _SalePrice decimal(19,11);
		DECLARE _ItemName VARCHAR(200);
		DECLARE _Notes VARCHAR(100);
		DECLARE _LocationID int;
		DECLARE _ItemTypeID int;
		DECLARE _IsAutoAdded BIT;
		DECLARE _IsDisplayedInReports BIT;
		-- -Salma : Modified in 29-12-2014 --added IsGulf AND IsMilitary to be used for Bahrain Export Tarrif Custom Product
		DECLARE _IsGulf BIT;
		DECLARE _IsMilitary BIT;
	-- Insert statements for procedure here
	SET _ItemTypeID = 1;
	SET _IsAutoAdded = 1;
	SET _IsDisplayedInReports = 1;
	SET _SaleTypeID = 1;
	SELECT _PricingPolicyID = PricingPolicyID
		,_LocationID = LocationID
		-- -Salma : Modified in 29-12-2014 --added IsGulf AND IsMilitary to be used for Bahrain Export Tarrif Custom Product
		,_IsGulf = IsShippedToGulfState
		,_IsMilitary = IsMilitary
	FROM Quotes
	WHERE QuoteID = _QuoteID;
	-- Delete tax products
	DELETE
	FROM QuotesItems
	WHERE QuoteID = _QuoteID
		AND (
			ItemName LIKE 'General Excise Tax included at 4.712%'
			OR ItemName LIKE 'Bahrain Export Tarrif included at 12%'
			OR ItemName LIKE 'Bahrain Export Tarrif included at 5%'
			);
	-- get location and parent location
	SET _LocationName = (
			SELECT LocationName
			FROM Locations
			WHERE LocationID = _LocationID
			);
	SET _ParentLocationName = (
			SELECT LocationName
			FROM Locations
			WHERE LocationID IN (
					SELECT ParentID
					FROM Locations
					WHERE LocationID = _LocationID
					)
			);
	-- Insert Tax Product
	-- -Salma : Modified in 29-12-2014 --added IsGulf AND IsMilitary to be used for Bahrain Export Tarrif Custom Product
	IF (
			_PricingPolicyID = 4
			AND _IsGulf = 1
			AND _IsMilitary = 0
			)
	then
		SET _ProductID = 0; -- 0 means custom Item
		IF (
				_LocationName = 'Saudi Arabia'
				OR _ParentLocationName = 'Saudi Arabia'
				)
		then
			SET _ItemName = 'Bahrain Export Tarrif included at 12%';
			SET _Constant = 0.12;
		
		ELSE
		
			SET _ItemName = 'Bahrain Export Tarrif included at 5%';
			SET _Constant = 0.05;
		END if;
		SET _Quantity = 1;
		SET _Notes = '';
		SELECT _OptionsLeaseAPrice = SUM(QI.Quantity * QI.CustomLeaseTermAPrice)
			,_OptionsLeaseBPrice = SUM(QI.Quantity * QI.CustomLeaseTermBPrice)
			,_OptionsSalePrice = SUM(QI.Quantity * QI.CustomSalePrice)
		FROM QuotesItems QI
		LEFT  JOIN Products P ON QI.ProductID = P.ProductID
		WHERE (QuoteID = _QuoteID)
			AND (
				(QI.ProductID = 0)
				OR (P.ProductTypeID <> 1)
				);
		SET _OptionsLeaseAPrice = Round(_OptionsLeaseAPrice, 0);
		SET _OptionsLeaseBPrice = Round(_OptionsLeaseBPrice, 0);
		SET _OptionsSalePrice = Round(_OptionsSalePrice, 0);
		SELECT _LeaseAPrice = SUM(QI.Quantity * QI.CustomLeaseTermAPrice)
			,_LeaseBPrice = SUM(QI.Quantity * QI.CustomLeaseTermBPrice)
			,_SalePrice = SUM(QI.Quantity * QI.CustomSalePrice)
		FROM QuotesItems QI
		LEFT  JOIN Products P ON QI.ProductID = P.ProductID
		WHERE (QuoteID = _QuoteID)
			AND (P.ProductTypeID = 1);
		SET _LeaseAPrice = Round(_LeaseAPrice, 0);
		SET _LeaseBPrice = Round(_LeaseBPrice, 0);
		SET _SalePrice = Round(_SalePrice, 0);
		SET _LeaseAPrice = Round((_OptionsLeaseAPrice + _LeaseAPrice) * _Constant, 0);
		SET _LeaseBPrice = Round((_OptionsLeaseBPrice + _LeaseBPrice) * _Constant, 0);
		SET _SalePrice = Round((_OptionsSalePrice + _SalePrice) * _Constant, 0);
		call spInsertQuoteItemCustom (_QuoteID
			,_ProductID
			,_ItemName
			,_ItemTypeID
			,_IsAutoAdded
			,_IsDisplayedInReports
			,_Quantity
			,_SalePrice
			,_LeaseAPrice
			,_LeaseBPrice
			,0
			,_Notes);
	END if ;
	-- -Salma : Modified added in 12-1-2015 --Hawaii State Tax Custom Product
	IF (_PricingPolicyID <> 16)
	then
		SET _ProductID = 0; -- 0 means custom Item
		IF (
				_LocationName = 'Hawaii'
				OR _ParentLocationName = 'Hawaii'
				)
		then
			SET _ItemName = 'General Excise Tax included at 4.712%';
			SET _Constant = 0.04712;
			SET _Quantity = 1;
			SET _Notes = '';
			SELECT _OptionsLeaseAPrice = SUM(QI.Quantity * QI.CustomLeaseTermAPrice)
				,_OptionsLeaseBPrice = SUM(QI.Quantity * QI.CustomLeaseTermBPrice)
				,_OptionsSalePrice = SUM(QI.Quantity * QI.CustomSalePrice)
			FROM QuotesItems QI
			LEFT OUTER JOIN Products P ON QI.ProductID = P.ProductID
			WHERE (QuoteID = _QuoteID); -- AND ((QI.ProductID = 0) OR (P.ProductTypeID <> 1))
			SET _OptionsLeaseAPrice = Round(_OptionsLeaseAPrice, 0);
			SET _OptionsLeaseBPrice = Round(_OptionsLeaseBPrice, 0);
			SET _OptionsSalePrice = Round(_OptionsSalePrice, 0);
			-- SELECT  
			-- _LeaseAPrice = SUM(QI.Quantity * QI.CustomLeaseTermAPrice),
			-- _LeaseBPrice = SUM(QI.Quantity * QI.CustomLeaseTermBPrice), 
			-- _SalePrice = SUM(QI.Quantity * QI.CustomSalePrice)
			-- FROM QuotesItems QI
			-- LEFT OUTER JOIN Products P ON QI.ProductID = P.ProductID 
			-- WHERE (QuoteID = _QuoteID) AND (P.ProductTypeID = 1)
			-- SET _LeaseAPrice=Round(_LeaseAPrice,0)
			-- SET _LeaseBPrice=Round(_LeaseBPrice,0)
			-- SET _SalePrice=Round(_SalePrice,0)
			SET _LeaseAPrice = Round(_OptionsLeaseAPrice * _Constant, 0);
			SET _LeaseBPrice = Round(_OptionsLeaseBPrice * _Constant, 0);
			SET _SalePrice = Round(_OptionsSalePrice * _Constant, 0);
			call spInsertQuoteItemCustom( _QuoteID
				,_ProductID
				,_ItemName
				,_ItemTypeID
				,_IsAutoAdded
				,_IsDisplayedInReports
				,_Quantity
				,_SalePrice
				,_LeaseAPrice
				,_LeaseBPrice
				,0
				,_Notes);
		END if;
	END if;
end;
