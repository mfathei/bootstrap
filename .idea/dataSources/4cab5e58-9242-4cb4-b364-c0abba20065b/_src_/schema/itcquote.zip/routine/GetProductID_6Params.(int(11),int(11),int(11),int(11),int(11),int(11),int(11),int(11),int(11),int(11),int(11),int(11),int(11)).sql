CREATE FUNCTION itcquote.GetProductID_6Params(pProductTypeID      INT, pPropertyID_01 INT, pPropertyValueID_01 INT,
                                              pPropertyID_02      INT, pPropertyValueID_02 INT, pPropertyID_03 INT,
                                              pPropertyValueID_03 INT, pPropertyID_04 INT, pPropertyValueID_04 INT,
                                              pPropertyID_05      INT, pPropertyValueID_05 INT, pPropertyID_06 INT,
                                              pPropertyValueID_06 INT)
  RETURNS INT
  BEGIN
	--  Declare the return variable here
	DECLARE vResult INT;
	DECLARE pQuoteVal1 VARCHAR(255);
	DECLARE pQuoteVal2 VARCHAR(255);
	DECLARE pQuoteVal3 VARCHAR(255);
	DECLARE pQuoteVal4 VARCHAR(255);
	DECLARE pQuoteVal5 VARCHAR(255);
	DECLARE pQuoteVal6 VARCHAR(255);
    if pPropertyValueID_01 is null
    then
        set pPropertyValueID_01 = 0;
    end if;
    if pPropertyValueID_02 is null
    then
        set pPropertyValueID_02 = 0;
    end if;
    
    if pPropertyValueID_03 is null
    then
        set pPropertyValueID_03 = 0;
    end if;
    
    if pPropertyValueID_04 is null
    then
        set pPropertyValueID_04 = 0;
    end if;
    
    if pPropertyValueID_05 is null
    then
        set pPropertyValueID_05 = 0;
    end if;
    
    if pPropertyValueID_06 is null
    then
        set pPropertyValueID_06 = 0;
    end if;
    
	SET pQuoteVal1 = GetPropertyValue(pPropertyValueID_01);
	SET pQuoteVal2 = GetPropertyValue(pPropertyValueID_02);
	SET pQuoteVal3 = GetPropertyValue(pPropertyValueID_03);
	SET pQuoteVal4 = GetPropertyValue(pPropertyValueID_04);
	SET pQuoteVal5 = GetPropertyValue(pPropertyValueID_05);
	SET pQuoteVal6 = GetPropertyValue(pPropertyValueID_06);
    call GetWidthRangePropertyValueID_ByWidth(pPropertyValueID_01);
    CALL GetWidthRangePropertyValueID_ByWidth02(pPropertyValueID_02);
    CALL GetWidthRangePropertyValueID_ByWidth03(pPropertyValueID_03);
    CALL GetWidthRangePropertyValueID_ByWidth04(pPropertyValueID_04);
    CALL GetWidthRangePropertyValueID_ByWidth05(pPropertyValueID_05);
    CALL GetWidthRangePropertyValueID_ByWidth06(pPropertyValueID_06);
	SELECT T1.ProductID into vResult 
	FROM ProductsPropertiesValues AS T1
	INNER JOIN ProductsPropertiesValues AS T2 ON T1.ProductID = T2.ProductID
	INNER JOIN ProductsPropertiesValues AS T3 ON T1.ProductID = T3.ProductID
	INNER JOIN ProductsPropertiesValues AS T4 ON T1.ProductID = T4.ProductID
	INNER JOIN ProductsPropertiesValues AS T5 ON T1.ProductID = T5.ProductID
	INNER JOIN ProductsPropertiesValues AS T6 ON T1.ProductID = T6.ProductID
	INNER JOIN Properties AS P1 ON P1.PropertyID = T1.PropertyID
	INNER JOIN PropertiesValues AS PV1 ON P1.PropertyID = PV1.PropertyID
	INNER JOIN Properties AS P2 ON P2.PropertyID = T2.PropertyID
	INNER JOIN PropertiesValues AS PV2 ON P2.PropertyID = PV2.PropertyID
	INNER JOIN Properties AS P3 ON P3.PropertyID = T3.PropertyID
	INNER JOIN PropertiesValues AS PV3 ON P3.PropertyID = PV3.PropertyID
	INNER JOIN Properties AS P4 ON P4.PropertyID = T4.PropertyID
	INNER JOIN PropertiesValues AS PV4 ON P4.PropertyID = PV4.PropertyID
	INNER JOIN Properties AS P5 ON P5.PropertyID = T5.PropertyID
	INNER JOIN PropertiesValues AS PV5 ON P5.PropertyID = PV5.PropertyID
	INNER JOIN Properties AS P6 ON P6.PropertyID = T6.PropertyID
	INNER JOIN PropertiesValues AS PV6 ON P6.PropertyID = PV6.PropertyID
	INNER JOIN Products ON Products.ProductID = T1.ProductID
	WHERE (Products.ProductTypeID = pProductTypeID)
		AND (
			(
				(
					(
						(
							(
								(pPropertyValueID_01 IS NOT NULL)
								AND (T1.PropertyValueID = pPropertyValueID_01)
								)
							OR (
								(pPropertyID_01 = 106)
								AND (pPropertyValueID_01 IS NOT NULL)
								AND (T1.PropertyValueID = 502)
								)
							OR --  property value = Other
							(
								(pPropertyValueID_01 IS NULL)
								AND (T1.PropertyValueID IS NULL)
								)
							OR (
								(pPropertyValueID_01 IS NOT NULL)
								AND (
									(pPropertyID_01 = 104)
									AND T1.PropertyValueID IN (
										SELECT * from
										GetWidthRangePropertyValueID_ByWidth_t -- FROM GetWidthRangePropertyValueID_ByWidth(pPropertyValueID_01)
										)
									)
								)
							)
						)
					)
				)
			AND (
				(
					(
						(
							(
								(pPropertyValueID_02 IS NOT NULL)
								AND (T2.PropertyValueID = pPropertyValueID_02)
								)
							OR (
								(pPropertyID_02 = 106)
								AND (pPropertyValueID_02 IS NOT NULL)
								AND (T2.PropertyValueID = 502)
								)
							OR --  property value = Other
							(
								(pPropertyValueID_02 IS NULL)
								AND (T2.PropertyValueID IS NULL)
								)
							OR (
								(pPropertyValueID_02 IS NOT NULL)
								AND (
									(pPropertyID_02 = 104)
									AND T2.PropertyValueID IN (
										SELECT * from
										GetWidthRangePropertyValueID_ByWidth02_t -- FROM GetWidthRangePropertyValueID_ByWidth02(pPropertyValueID_02)
										)
									)
								)
							)
						)
					)
				)
			AND (
				(
					(
						(
							(
								(pPropertyValueID_03 IS NOT NULL)
								AND (T3.PropertyValueID = pPropertyValueID_03)
								)
							OR (
								(pPropertyID_03 = 106)
								AND (pPropertyValueID_03 IS NOT NULL)
								AND (T3.PropertyValueID = 502)
								)
							OR --  property value = Other
							(
								(pPropertyValueID_03 IS NULL)
								AND (T3.PropertyValueID IS NULL)
								)
							OR (
								(pPropertyValueID_03 IS NOT NULL)
								AND (
									(pPropertyID_03 = 104)
									AND T3.PropertyValueID IN (
										SELECT * from
										GetWidthRangePropertyValueID_ByWidth03_t -- FROM GetWidthRangePropertyValueID_ByWidth03(pPropertyValueID_03)
										)
									)
								)
							)
						)
					)
				)
			AND (
				(
					(
						(
							(
								(pPropertyValueID_04 IS NOT NULL)
								AND (T4.PropertyValueID = pPropertyValueID_04)
								)
							OR (
								(pPropertyID_04 = 106)
								AND (pPropertyValueID_04 IS NOT NULL)
								AND (T4.PropertyValueID = 502)
								)
							OR --  property value = Other
							(
								(pPropertyValueID_04 IS NULL)
								AND (T4.PropertyValueID IS NULL)
								)
							OR (
								(pPropertyValueID_04 IS NOT NULL)
								AND (
									(pPropertyID_04 = 104)
									AND T4.PropertyValueID IN (
										SELECT * from
										GetWidthRangePropertyValueID_ByWidth04_t -- FROM GetWidthRangePropertyValueID_ByWidth04(pPropertyValueID_04)
										)
									)
								)
							)
						)
					)
				)
			AND (
				(
					(
						(
							(
								(pPropertyValueID_05 IS NOT NULL)
								AND (T5.PropertyValueID = pPropertyValueID_05)
								)
							OR (
								(pPropertyID_05 = 106)
								AND (pPropertyValueID_05 IS NOT NULL)
								AND (T5.PropertyValueID = 502)
								)
							OR --  property value = Other
							(
								(pPropertyValueID_05 IS NULL)
								AND (T5.PropertyValueID IS NULL)
								)
							OR (
								(pPropertyValueID_05 IS NOT NULL)
								AND (
									(pPropertyID_05 = 104)
									AND T5.PropertyValueID IN (
										SELECT * from
										GetWidthRangePropertyValueID_ByWidth05_t -- FROM GetWidthRangePropertyValueID_ByWidth05(pPropertyValueID_05)
										)
									)
								)
							)
						)
					)
				)
			AND (
				(
					(
						(
							(
								(pPropertyValueID_06 IS NOT NULL)
								AND (T6.PropertyValueID = pPropertyValueID_06)
								)
							OR (
								(pPropertyID_06 = 106)
								AND (pPropertyValueID_06 IS NOT NULL)
								AND (T6.PropertyValueID = 502)
								)
							OR --  property value = Other
							(
								(pPropertyValueID_06 IS NULL)
								AND (T6.PropertyValueID IS NULL)
								)
							OR (
								(pPropertyValueID_06 IS NOT NULL)
								AND (
									(pPropertyID_06 = 104)
									AND T6.PropertyValueID IN (
										SELECT * from
										GetWidthRangePropertyValueID_ByWidth06_t -- FROM GetWidthRangePropertyValueID_ByWidth06(pPropertyValueID_06)
										)
									)
								)
							)
						)
					)
				)
			);
	RETURN IFNULL(vResult, 0);
END;
