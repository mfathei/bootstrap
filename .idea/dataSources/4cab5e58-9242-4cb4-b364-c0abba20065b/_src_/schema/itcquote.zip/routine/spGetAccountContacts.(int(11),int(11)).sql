CREATE PROCEDURE itcquote.spGetAccountContacts(IN `_AccountID` INT, IN `_TerritoryID` INT)
  BEGIN	
    -- Insert statements for procedure here
  SELECT ContactID, ContactName, ContactTypeID, CreateDate, CreateAccountID,IsActive, ScopeID
  FROM Contacts
  WHERE (ScopeID = 1 AND CreateAccountID = _AccountID)
  OR 
        (ScopeID = 2 AND CreateAccountID IN (SELECT AccountID FROM Accounts WHERE TerritoryID = _TerritoryID))
  OR
        ScopeID = 3 ;
        end;
