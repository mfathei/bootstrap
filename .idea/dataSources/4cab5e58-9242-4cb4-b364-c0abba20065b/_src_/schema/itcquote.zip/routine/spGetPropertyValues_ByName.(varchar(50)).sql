CREATE PROCEDURE itcquote.spGetPropertyValues_ByName(IN `_PropertyName` VARCHAR(50))
  BEGIN
  SELECT Properties.PropertyID, Properties.PropertyTypeID, PropertiesValues.ValueIndex, PropertiesValues.PropertyValueID, PropertiesValues.TheValue
  FROM Properties 
  INNER JOIN PropertiesValues ON Properties.PropertyID = PropertiesValues.PropertyID 
  WHERE (Properties.PropertyName = _PropertyName);
END;
