CREATE PROCEDURE itcquote.GetProductValues(IN ProductID INT)
  begin 
SELECT        Products.ProductID, ProductsPropertiesValues.PropertyID, Properties.PropertyName, PropertiesValues.TheValue
FROM            Products INNER JOIN
                         ProductsPropertiesValues ON (Products.ProductID = ProductsPropertiesValues.ProductID) INNER JOIN
                         Properties ON (ProductsPropertiesValues.PropertyID = Properties.PropertyID) LEFT JOIN
                         PropertiesValues ON (ProductsPropertiesValues.PropertyID = PropertiesValues.PropertyID AND 
                         ProductsPropertiesValues.PropertyValueID = PropertiesValues.PropertyValueID AND Properties.PropertyID = PropertiesValues.PropertyID)
WHERE        Products.ProductID =ProductID ;
END;
