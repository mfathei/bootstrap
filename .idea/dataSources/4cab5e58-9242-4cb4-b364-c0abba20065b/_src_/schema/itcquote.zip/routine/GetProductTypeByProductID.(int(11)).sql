CREATE FUNCTION itcquote.GetProductTypeByProductID(pProductID INT)
  RETURNS INT
  BEGIN
	DECLARE vResult INT;
		SELECT  ProductTypeID into vResult
		FROM Products
		WHERE ProductID = pProductID;
	RETURN IFNULL(vResult, 0);
END;
