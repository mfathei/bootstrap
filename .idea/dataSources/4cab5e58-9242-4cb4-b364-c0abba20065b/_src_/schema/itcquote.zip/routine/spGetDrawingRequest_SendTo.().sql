CREATE PROCEDURE itcquote.spGetDrawingRequest_SendTo()
  begin
  call spGetPropertyValues_ByName ('DrawingRequest_SendTo');
END;
