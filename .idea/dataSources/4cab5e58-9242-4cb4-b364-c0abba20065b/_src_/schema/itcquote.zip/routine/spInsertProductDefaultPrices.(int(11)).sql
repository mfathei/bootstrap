CREATE PROCEDURE itcquote.spInsertProductDefaultPrices(IN `_ProductID` INT)
  BEGIN
	if _ProductID=null or _ProductID='' then set _ProductID=0; end if;
	-- Insert statements for procedure here
	INSERT INTO ProductsPrices (
		ProductID
		,PricingPolicyID
		,PricingTypeID
		)
	SELECT _ProductID AS ProductID
		,ProductsDefaultPrices.PricingPolicyID
		,ProductsDefaultPrices.PricingTypeID
	FROM (
		     SELECT ProductID
			,PricingPolicyID
			,PricingTypeID
			FROM ProductsPrices
	     	WHERE (ProductID = _ProductID)
		) AS ProductPrices
	RIGHT  JOIN ProductsDefaultPrices ON ProductPrices.PricingPolicyID = ProductsDefaultPrices.PricingPolicyID
		AND ProductPrices.PricingTypeID = ProductsDefaultPrices.PricingTypeID
	WHERE (ProductPrices.ProductID IS NULL);
end;
