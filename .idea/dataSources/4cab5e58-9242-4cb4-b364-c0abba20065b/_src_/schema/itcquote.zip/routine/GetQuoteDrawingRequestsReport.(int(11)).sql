CREATE PROCEDURE itcquote.GetQuoteDrawingRequestsReport(IN pDrawingRequestIDParam INT)
  BEGIN
    -- Fill the table variable with the rows for your result set
    DECLARE vContactName VARCHAR (50) ;
    DECLARE vAddress VARCHAR (150) ;
    DECLARE vZip VARCHAR (50) ;
    DECLARE vPhoneNo VARCHAR (50) ;
    DECLARE vMobileNo VARCHAR (50) ;
    DECLARE vFax VARCHAR (50) ;
    DECLARE vEmail VARCHAR (50) ;
    DECLARE vWebSite VARCHAR (50) ;
    DECLARE vDrawingRequestID INT ;
    DECLARE vCreateAccountID INT ;
    DECLARE vCreateDate DATETIME ;
    DECLARE vModifyAccountID INT ;
    DECLARE vModifyDate DATETIME ;
    DECLARE vScopeID INT ;
    DECLARE vQuoteID INT ;
    DECLARE vReferenceDrawingRequestID INT ;
    DECLARE vSendToID INT ;
    DECLARE vSendTo VARCHAR (50) ;
    DECLARE vSendViaID INT ;
    DECLARE vSendVia VARCHAR (50) ;
    DECLARE vDrawingTypeID INT ;
    DECLARE vDrawingType VARCHAR (50) ;
    -- Salma Modified on 28-5-2015 added Drawing Category
    DECLARE vDrawingCategoryID INT ;
    DECLARE vDrawingCategory VARCHAR (50) ;
    DECLARE vDrawingSizeID INT ;
    DECLARE vDrawingSize VARCHAR (75) ;
    DECLARE vDrawingUnitID INT ;
    DECLARE vDrawingUnit VARCHAR (75) ;
    DECLARE vDeliveryPoint VARCHAR (150) ;
    -- Salma Modified on 22 march 2015 added requested date & delivery date instead of expected date
    DECLARE vRequestedDeliveryDate DATETIME ;
    DECLARE vPromisedDeliveryDate DATETIME ;
    DECLARE vIsStamped BIT ;
    DECLARE vNoOfCopies int ;
    DECLARE vStatusID int ;
    DECLARE vCaption VARCHAR (150) ;
    DECLARE vComments VARCHAR (1000) ;
    DECLARE vContactID INT ;
    -- Salma Modified on 3-6-2015 added the following fields
    DECLARE vCompanyID INT ;
    DECLARE vCompany VARCHAR (150) ;
    DECLARE vAddress2 VARCHAR (250) ;
    DECLARE vCity VARCHAR (50) ;
    DECLARE vState VARCHAR (50) ;
    DECLARE vCountry VARCHAR (50) ;
    DECLARE vAttentionID INT ;
    DECLARE vAttention VARCHAR (150) ;
    DECLARE vSalesRepID INT ;
    DECLARE vSalesRep VARCHAR (150) ;
    DECLARE vLocationID INT ;
    DECLARE vLocation VARCHAR (150) ;
    DECLARE vApplicationID INT ;
    DECLARE vApplication VARCHAR (150) ;
    DECLARE vQuoteDuration VARCHAR (15) ;
    DECLARE vPricingPolicyID int ;
    DECLARE vPricingPolicy VARCHAR (50) ;
    DECLARE vBuiltCode VARCHAR (50) ;
    DECLARE vWindRate VARCHAR (30) ;
    DECLARE vMPH BIT ;
    DECLARE vKPH BIT ;
    DECLARE vKPA BIT ;
    DECLARE vSnowLoad FLOAT ;
    DECLARE vStructureWidth INT ;
    DECLARE vStructureLength VARCHAR (15) ;
    DECLARE vExposureID INT ;
    DECLARE vExposure VARCHAR (50) ;
    -- --------------------------------------------
    drop temporary table if exists GetQuoteDrawingRequestsReport_t ;
    create temporary table GetQuoteDrawingRequestsReport_t (
        ContactName VARCHAR (50),
        Address VARCHAR (150),
        Zip VARCHAR (50),
        PhoneNo VARCHAR (50),
        MobileNo VARCHAR (50),
        Fax VARCHAR (50),
        Email VARCHAR (50),
        WebSite VARCHAR (50),
        DrawingRequestID INT,
        CreateAccountID INT,
        CreateDate DATETIME,
        ModifyAccountID INT,
        ModifyDate DATETIME,
        ScopeID INT,
        QuoteID INT,
        ReferenceDrawingRequestID INT,
        SendToID INT,
        SendTo VARCHAR (50),
        SendViaID INT,
        SendVia VARCHAR (50),
        DrawingTypeID INT,
        DrawingType VARCHAR (50),
        -- Salma Modified on 28-5-2015 added Drawing Category
        DrawingCategoryID INT,
        DrawingCategory VARCHAR (50),
        DrawingSizeID INT,
        DrawingSize VARCHAR (75),
        DrawingUnitID INT,
        DrawingUnit VARCHAR (75),
        DeliveryPoint VARCHAR (150),
        -- Salma Modified on 22 march 2015 added requested date & delivery date instead of expected date
        RequestedDeliveryDate DATETIME,
        PromisedDeliveryDate DATETIME,
        IsStamped BIT,
        NoOfCopies int,
        StatusID int,
        Caption VARCHAR (150),
        Comments VARCHAR (1000),
        ContactID INT-- Salma Modified on 6-3-2015 added the following fields
        ,
        Company VARCHAR (150),
        Address2 VARCHAR (250),
        City VARCHAR (50),
        STATE VARCHAR (50),
        Country VARCHAR (50),
        Attention VARCHAR (150),
        SalesRep VARCHAR (150),
        Location VARCHAR (150),
        Application VARCHAR (150),
        QuoteDuration VARCHAR (15),
        PricingPolicy VARCHAR (50),
        BuiltCode VARCHAR (50),
        WindRate VARCHAR (30),
        SnowLoad FLOAT,
        StructureWidth INT,
        StructureLength VARCHAR (15),
        Exposure VARCHAR (50)
    ) ;
    -- ------------------------------------------------------------------------------
    SELECT 
        DrawingRequestID,
        CreateAccountID,
        CreateDate,
        ModifyAccountID,
        ModifyDate,
        ScopeID,
        QuoteID,
        ReferenceDrawingRequestID,
        SendToID,
        SendViaID,
        DrawingTypeID,
        DrawingCategoryID,
        DrawingSizeID,
        DrawingUnitID,
        IFNULL(DeliveryPoint, ''),
        RequestedDeliveryDate,
        vPromisedDeliveryDate,
        IsStamped,
        NoOfCopies,
        StatusID,
        Caption,
        IFNULL(Comments, ''),
        CompanyID,
        IFNULL(Address, ''),
        IFNULL(Address2, ''),
        IFNULL(Zip, ''),
        IFNULL(City, ''),
        IFNULL(STATE, ''),
        IFNULL(Telephone, ''),
        IFNULL(Fax, ''),
        IFNULL(WebSite, ''),
        AttentionID,
        SalesManager,
        StructureLocation,
        StructureApplication,
        IFNULL(
            CONVERT(CAST(Wind AS signed), CHAR(30)),
            '0.0'
        ),
        WindMPH,
        WindKPH,
        WindKPA,
        Snow,
        StructureWidth,
        StructureLength,
        Exposure into vDrawingRequestID,
        vCreateAccountID,
        vCreateDate,
        vModifyAccountID,
        vModifyDate,
        vScopeID,
        vQuoteID,
        vReferenceDrawingRequestID,
        vSendToID,
        vSendViaID,
        vDrawingTypeID,
        vDrawingCategoryID,
        vDrawingSizeID,
        vDrawingUnitID,
        vDeliveryPoint,
        vRequestedDeliveryDate,
        vPromisedDeliveryDate,
        vIsStamped,
        vNoOfCopies,
        vStatusID,
        vCaption,
        vComments,
        vCompanyID,
        vAddress,
        vAddress2,
        vZip,
        vCity,
        vState,
        vPhoneNo,
        vFax,
        vWebSite,
        vAttentionID,
        vSalesRepID,
        vLocationID,
        vApplicationID,
        vWindRate,
        vMPH,
        vKPH,
        vKPA,
        vSnowLoad,
        vStructureWidth,
        vStructureLength,
        vExposureID 
    FROM
        DrawingRequests 
    WHERE DrawingRequestID = pDrawingRequestIDParam ;
    -- -------------------------------------------------------------------------------
    SELECT 
        ContactID into vContactID 
    FROM
        Accounts 
    WHERE (AccountID = vCreateAccountID) ;
    -- -------------------------------------------------------------------------------
    SELECT 
        ContactName into vContactName -- Salma Modified on 3-6-2015 added the following fields
        -- , 
        -- vAddress = ifnull(Address,''), 
        -- vZip = ifnull(Zip,''),
        -- vPhoneNo = ifnull(PhoneNo,''), 
        -- vMobileNo = ifnull(MobileNo,''),
        -- vFax = ifnull(Fax,''), 
        -- vEmail = ifnull(Email,''), 
        -- vWebSite = ifnull(WebSite,'')
    FROM
        Contacts 
    WHERE ContactID = vContactID ;
    -- ----------------------------------------------------------------------------------
    SET vSendTo = GetPropertyValues_ByName (
        'DrawingRequest_SendTo',
        vSendToID
    ) ;
    SET vSendVia = GetPropertyValues_ByName (
        'DrawingRequest_SendVia',
        vSendViaID
    ) ;
    SET vDrawingType = GetPropertyValues_ByName (
        'DrawingRequest_DrawingTypes',
        vDrawingTypeID
    ) ;
    SET vDrawingSize = GetPropertyValues_ByName (
        'DrawingRequest_DrawingSizes',
        vDrawingSizeID
    ) ;
    SET vDrawingUnit = GetPropertyValues_ByName (
        'DrawingRequest_DrawingUnits',
        vDrawingUnitID
    ) ;
    -- ----------------------------------------------------------------------------------
    -- Salma Modified on 3-6-2015 added the following fields
    SELECT 
        ContactName into vCompany 
    FROM
        Contacts 
    WHERE (ContactID = vCompanyID) ;
    SELECT 
        ContactName,
        TRIM(Email) into vAttention,
        vEmail 
    FROM
        Contacts 
    WHERE (ContactID = vAttentionID) ;
    SELECT 
        ContactName into vSalesRep 
    FROM
        Contacts 
    WHERE (ContactID = vSalesRepID) ;
    -- SELECT  vLocation = LocationName FROM Locations WHERE LocationID = vLocationID
    IF (
        vLocationID IS NOT NULL 
        AND vLocationID <> 0
    ) 
    then 
    SELECT 
        concat(T1.LocationName , ', ' , IFNULL(T2.LocationName, '')) into vLocation 
    FROM
        Locations T1 
        LEFT JOIN Locations T2 
            ON T1.ParentID = T2.LocationID 
    WHERE T1.LocationID = vLocationID ;
    ELSE 
    SELECT 
        Location into vLocation 
    FROM
        DrawingRequests 
    WHERE DrawingRequestID = vDrawingRequestID ;
    END if ;
    SELECT 
        BuildingCodes.BuildingCodeName into vBuiltCode 
    FROM
        BuildingCodes 
        INNER JOIN Locations 
            ON BuildingCodes.BuildingCodeID = Locations.BuildingCodeID 
    WHERE (
            Locations.LocationID = vLocationID
        ) ;
    SELECT 
        ApplicationName into vApplication 
    FROM
        Applications 
    WHERE (ApplicationID = vApplicationID) ;
    SELECT 
        PricingPolicyID into vPricingPolicyID 
    FROM
        Quotes 
    WHERE QuoteID = vQuoteID ;
    SELECT 
        QuoteDuration into vQuoteDuration 
    FROM
        Quotes 
    WHERE QuoteID = vQuoteID ;
    SELECT 
        PricingPolicyName into vPricingPolicy 
    FROM
        PricingPolicies 
    WHERE (
            PricingPolicyID = vPricingPolicyID
        ) ;
    SET vExposure = IFNULL(
        GetPropertyValue (vExposureID),
        ' '
    ) ;
    IF (vMPH = 1) 
    then SET vWindRate = concat(vWindRate ,' MPH') ;
    ELSEIF (vKPH = 1) 
    then SET vWindRate = concat(vWindRate ,' KPH') ;
    ELSEIF (vKPA = 1) 
    then SET vWindRate = concat(vWindRate , ' KPA') ;
    END if ;
    -- ----------------------------------------------------------------------------------------
    INSERT GetQuoteDrawingRequestsReport_t 
    values
        (
            vContactName,
            vAddress,
            vZip,
            vPhoneNo,
            vMobileNo,
            vFax,
            vEmail,
            vWebSite,
            vDrawingRequestID,
            vCreateAccountID,
            vCreateDate,
            vModifyAccountID,
            vModifyDate,
            vScopeID,
            vQuoteID,
            vReferenceDrawingRequestID,
            vSendToID,
            vSendTo,
            vSendViaID,
            vSendVia,
            vDrawingTypeID,
            vDrawingType,
            -- Salma Modified on 28-5-2015 added Drawing Category
            vDrawingCategoryID,
            vDrawingCategory,
            vDrawingSizeID,
            vDrawingSize,
            vDrawingUnitID,
            vDrawingUnit,
            vDeliveryPoint,
            vRequestedDeliveryDate,
            vPromisedDeliveryDate,
            vIsStamped,
            vNoOfCopies,
            vStatusID,
            vCaption,
            vComments,
            vContactID,
            -- Salma Modified on 3-6-2015 added the following fields
            IFNULL(vCompany, NULL),
            vAddress2,
            vCity,
            vState,
            vCountry,
            IFNULL(vAttention, ' '),
            IFNULL(vSalesRep, ' '),
            IFNULL(vLocation, NULL),
            IFNULL(vApplication, NULL),
            concat(
                CAST(vQuoteDuration AS CHAR(15)),
                ' days'
            ),
            IFNULL(vPricingPolicy, NULL),
            IFNULL(vBuiltCode, NULL),
            vWindRate,
            vSnowLoad,
            vStructureWidth,
            vStructureLength,
            vExposure
        ) ;
    
END;
