CREATE PROCEDURE itcquote.spInsertDefaultQuoteItems(IN pQuoteID INT)
    this_proc:BEGIN
	DECLARE vProductID INT;
	DECLARE vQuantity FLOAT;
	DECLARE vPricingPolicyID int;
	DECLARE vSaleTypeID int;
	DECLARE vLeaseTermAID int;
	DECLARE vLeaseTermBID int;
	DECLARE vStructureID INT;
	DECLARE vInsulationTypeID INT;
	DECLARE vInsulationThicknessID INT;
	DECLARE vMembraneTypeID INT;
		-- salma in 26_3_2014 added FabricTypeID
	DECLARE vFabricTypeID INT;
	DECLARE vMembraneColorID INT;
	DECLARE vMembraneLinerColorID INT;
	DECLARE vAnchorageID INT;
	DECLARE vExposureID INT;
	DECLARE vLocationID int;
	DECLARE vStructureLength FLOAT;
	DECLARE vStructureSQFT FLOAT;
	DECLARE vNoOfFlatEnds int;
	DECLARE vNoOfRoundEnds int;
	DECLARE vNoOfCenterBays int;
	DECLARE vCenterBaySpacing FLOAT;
	DECLARE vNoOfCraneBreakPoints int;
	DECLARE vNoOfToolsSets int;
	DECLARE vWindRate FLOAT;
		-- ----Salma : Modified in 21-5-2015 -- changed SnowRate from int to float
	DECLARE vSnowRate FLOAT;
	DECLARE vStandardCenterBaySpacing FLOAT;
	-- <------ Standard measures  
	DECLARE vStructureStandardLength FLOAT;
	DECLARE vStructureStandardSQFT FLOAT;
	DECLARE vIsAdditionToExistingStructure BIT;
	DECLARE vStructureWidthID INT;
	DECLARE vStructureWidth INT;
	DECLARE vNoOfBeamsPerFlatEnd int;
	DECLARE vNoOfBeamsPerRoundEnd int;
	DECLARE vNoOfBeamsPerCenterBay int;
	DECLARE vNoOfBeamsPerCraneLiftBreakpoint int;
	DECLARE vNoOfHooksPerBeam int;
	DECLARE vNoOfBeams int;
	DECLARE vNoOfOpenEnds int;
	DECLARE vNotes VARCHAR(100);
	DECLARE vIsInsulated BIT;
	DECLARE vIsInsulatedValueID INT;
		-- ----Salma : Modified in 02-07-2013 -- added the IsLattice property to be used in Structures and Engineered Flat Ends
	DECLARE vIsLatticeValueID INT;
		-- --------------------------------------------------------------------------------------------------------------------
		-- ----Salma : Modified in 04-07-2013 -- added the SpecialWidth property to be used in Structures and Engineered Flat Ends
	DECLARE vSpecialWidthValueID INT;
		-- --------------------------------------------------------------------------------------------------------------------
	DECLARE vProvideTensionCable BIT;
	DECLARE vProvideOpaqueMembrane BIT;
	DECLARE vProvideConduitHoles BIT;
	DECLARE vItemTypeID int;
	DECLARE vIsAutoAdded BIT;
	DECLARE vIsDisplayedInReports BIT;
	DECLARE vInsulationTypeValue VARCHAR(200);
	DECLARE vItemName VARCHAR(200);
		-- --Salma : Modified in 28-2-2013 add the following values to be used in membrane product naming----
	DECLARE vCompareVariable VARCHAR(200) DEFAULT 'no daylight panels';
		-- --Salma : Modified in 6-4-2014 add the following values to be used in membrane product naming----
	DECLARE vnodaylightVariable VARCHAR(200) DEFAULT ' opaque membrane';
		-- vdaylightVariable varchar(200)DEFAULT', Complete with daylight panels'
	DECLARE vdaylightVariable VARCHAR(200) DEFAULT ' opaque membrane with Daylight Panels';
		-- --------------------------------------------------------------------------------------------------- 
		-- --Salma : Modified in 13-6-2013 add the following values to be used in New Membrane product--------
	DECLARE vLeaseTermAPrice DECIMAL(10, 2);
	DECLARE vLeaseTermBPrice DECIMAL(10, 2);
		-- ----------------------------------------------------------------------------------------------------
		-- --Salma : Modified in 7-4-2014 add the following to be used in Eng. Flat End & Base level spreaders product--------
	DECLARE vEngFlatEndProductID INT DEFAULT 0;
		-- Salma Modified on 22-1-2015 -- get Domestic product if IsMilitary or GSA PricingPolicy else get Standard------
	DECLARE vIsMilitary BIT;
	DECLARE vIsDomestic INT;
		-- Salma -- Modified in 4-2-2015 using BeamSize to determine Conduit hole product price value
	DECLARE vBeamSize VARCHAR(50);
		-- Salma -- Modified in 18-6-2015 added InsulationPackage to be used in Insulation and Engineered Flat End
	DECLARE vInsulationPackageID INT;
		-- salma modified on 14-9-2015 to name the product using the company name 
	DECLARE vCompanyID INT;
	DECLARE vCompanyName VARCHAR(200);
	SET vItemTypeID = 1;
	SET vIsAutoAdded = 1;
	SET vIsDisplayedInReports = 1;
	SET vSaleTypeID = 1;
SELECT
    PricingPolicyID,
    LeaseTermAID,
    LeaseTermBID,
    StructureID,
    StructureLength,
    InsulationTypeID,
    InsulationThicknessID,
    MembraneTypeID,
    FabricTypeID,
    MembraneColorID,
    MembraneLinerColorID,
    AnchorageID,
    ExposureID,
    LocationID,
    StructureLength,
    NoOfFlatEnds,
    NoOfRoundEnds,
    NoOfCenterBays,
    CenterBaySpacing,
    NoOfCraneBreakPoints,
    NoOfToolsSets,
    WindRate,
    SnowRate,
    IFNULL(
        IsAdditionToExistingStructure,
        0
    ),
    ProvideOpaqueMembrane,
    ProvideTensionCable,
    ProvideConduitHoles -- Salma Modified on 22-1-2015 -- get Domestic product if IsMilitary or GSA PricingPolicy else get Standard------
    ,
    IsMilitary -- Salma --Modified in 18-6-2015 added InsulationPackage to be used in Insulation and Engineered Flat End
    ,
    InsulationPackageID -- Salma modified on 14-9-2015 to name the product using the company name
    ,
    CompanyID INTO vPricingPolicyID,
    vLeaseTermAID,
    vLeaseTermBID,
    vStructureID,
    vStructureLength,
    vInsulationTypeID,
    vInsulationThicknessID,
    vMembraneTypeID,
    vFabricTypeID,
    vMembraneColorID,
    vMembraneLinerColorID,
    vAnchorageID,
    vExposureID,
    vLocationID,
    vStructureLength,
    vNoOfFlatEnds,
    vNoOfRoundEnds,
    vNoOfCenterBays,
    vCenterBaySpacing,
    vNoOfCraneBreakPoints,
    vNoOfToolsSets,
    vWindRate,
    vSnowRate,
    vIsAdditionToExistingStructure,
    vProvideOpaqueMembrane,
    vProvideTensionCable,
    vProvideConduitHoles,
    vIsMilitary,
    vInsulationPackageID,
    vCompanyID
FROM
    Quotes
WHERE (QuoteID = pQuoteID) ;
	IF (
			vCompanyID IS NOT NULL
			AND vCompanyID <> 0
			)
    then
		SELECT  ContactName into vCompanyName
		FROM Contacts
		WHERE ContactID = vCompanyID;
	ELSE
		SET vCompanyName = 'Complimentary';
    end if;
	SET vStructureWidthID = GetProductPropertyValueID(vStructureID, 6);
	SET vStructureWidth = GetProductPropertyValue_Int(vStructureID, 6);
	SET vNoOfBeamsPerFlatEnd = GetProductPropertyValue_Int(vStructureID, 11);
	SET vNoOfBeamsPerRoundEnd = GetProductPropertyValue_Int(vStructureID, 14);
	IF GetNoOfEarthAnchorsRatio(vStructureWidth, vStructureLength, vNoOfCraneBreakPoints, vStandardCenterBaySpacing, vStructureStandardLength, vIsAdditionToExistingStructure) <> 0
	then
        leave this_proc;
    end if;
	IF GetNoOfLiftsRatio(vStructureWidth, vStructureLength) <> 0
	then
        leave this_proc;
    end if;
    
	SET vNoOfBeamsPerCenterBay = GetProductPropertyValue_Int(vStructureID, 60);
	SET vNoOfBeamsPerCraneLiftBreakpoint = GetProductPropertyValue_Int(vStructureID, 61);
	SET vNoOfHooksPerBeam = GetProductPropertyValue_Int(vStructureID, 63);
	SET vStructureSQFT = GetStructureSQFT(vStructureWidth, vStructureLength);
	SET vNoOfBeams = GetNoOfBeams(vNoOfFlatEnds, vNoOfBeamsPerFlatEnd, vNoOfRoundEnds, vNoOfBeamsPerRoundEnd, vNoOfCenterBays, vNoOfBeamsPerCenterBay, vNoOfCraneBreakPoints, vNoOfBeamsPerCraneLiftBreakpoint);
	SET vNoOfOpenEnds = 2 - vNoOfFlatEnds - vNoOfRoundEnds;
	SET vIsInsulated = IsInsulated(vInsulationTypeID);
	SET vIsInsulatedValueID = GetIsInsulatedID(vInsulationTypeID);
	SET vStandardCenterBaySpacing = GetStructureStandardCenterBaySpacing(vStructureID, vCenterBaySpacing, vSnowRate);
	SET vStructureStandardLength = GetStructureStandardLength(vNoOfCenterBays, vStandardCenterBaySpacing, vNoOfRoundEnds, vStructureWidth);
	SET vStructureStandardSQFT = GetStructureStandardSQFT(vStructureWidth, vStructureLength, vNoOfCraneBreakPoints, vStandardCenterBaySpacing, vStructureStandardLength, vIsAdditionToExistingStructure);
	-- -Salma--Modified on 02-07-2013-- get IsLattice from Structure Product 
	SET vIsLatticeValueID = GetProductPropertyValueID(vStructureID, 105);
	-- Salma: modified in 04-07-2013 -- get SpecialWidthValueId for selected Structure Product
	SET vSpecialWidthValueID = GetProductPropertyValueID(vStructureID, 106);
	-- Delete Previously Auto Added Products for this quote -- --------
	DELETE from QuotesItems
	WHERE (QuoteID = pQuoteID)
		AND (IsAutoAdded = vIsAutoAdded);
	-- 0100 Insert "Quote Structure" Product -- --------------------
	SET vProductID = vStructureID;
	SET vQuantity = vStructureStandardSQFT;
	call spInsertQuoteItem(pQuoteID
		,vProductID
		,vIsAutoAdded
		,vQuantity
		,vPricingPolicyID
		,vSaleTypeID
		,vLeaseTermAID
		,vLeaseTermBID);
	-- 0200 Insert "Complimentary Graphic Logo at Entrance" Product -- --------------------
	SET vProductID = 29;
	SET vQuantity = 1;
	-- salma modified on 14-9-2015 to name the product using the company name 
	SET vItemName = concat(vCompanyName , ' Graphic Logo at Entrance');
	call spInsertQuoteItemSpecialName(pQuoteID
		,vProductID
		,vIsAutoAdded
		,vQuantity
		,vPricingPolicyID
		,vSaleTypeID
		,vLeaseTermAID
		,vLeaseTermBID
		,vNotes
		,vItemName);
	-- EXEC spInsertQuoteItem pQuoteID, vProductID, vIsAutoAdded, vQuantity, vPricingPolicyID, vSaleTypeID, vLeaseTermAID, vLeaseTermBID
	-- 0300 Insert "Perimeter Flat Bar" Product -- --------------------
	-- -Salma--Modified on 12-6-2013-- added the condition for ballast weights anchorage
	IF vAnchorageID <> 58
		AND vAnchorageID <> 441
	then
		SET vProductID = 21;
		-- -Salma--Modified on 14-11-2013-- adding vNoOfFlatEnds & vNoOfRoundEnds to the parameters sent
		SET vQuantity = Ceiling(GetStructurePerimeter(vStructureWidth, vStructureLength, vNoOfFlatEnds, vNoOfRoundEnds));
		call spInsertQuoteItem(pQuoteID
			,vProductID
			,vIsAutoAdded
			,vQuantity
			,vPricingPolicyID
			,vSaleTypeID
			,vLeaseTermAID
            ,vLeaseTermBID);
	END if;
	-- 0400 Insert "Crane Lifting Hook" Product -- --------------------
	/*
	SET vProductID = 26;
	SET vQuantity = vNoOfBeams * vNoOfHooksPerBeam;
	EXEC spInsertQuoteItem pQuoteID, vProductID, vIsAutoAdded, vQuantity, vPricingPolicyID, vSaleTypeID, vLeaseTermAID, vLeaseTermBID
	*/
	/**   commented by mohamed fathy 2-6-2016  
	-- 0500 Insert "Bay of Cable Bracing" Product("Bay of Cable Bracing": ProductTypeID = 48) -- ----
	
	-- Salma Modified on 15-1-2015 -- added CenterBaySpacing in the condition -- ----
	-- SET vProductID = GetProductID(48, 6, vStructureWidthID, '');
	-- Salma Modified on 22-1-2015 -- get Domestic product if IsMilitary or GSA PricingPolicy else get Standard------
	IF(vIsMilitary=1 OR vPricingPolicyID=16)--Military or GSA
	  BEGIN
	  -- Domestic
	  SET vIsDomestic=1
	  END
    ELSE
      BEGIN
      SET vIsDomestic=0
	  END
  
    SET vProductID = GetProductID_3Params(48, 6, vStructureWidthID,116,GetPropertyValueIDByValue_PropertyID(116,vCenterBaySpacing),117,GetPropertyValueIDByValue_PropertyID(117,vIsDomestic));
	
	-- SET vProductID = GetProductID_2Params(48, 6, vStructureWidthID,116,GetPropertyValueIDByValue_PropertyID(116,vCenterBaySpacing));
	-- Salma Modified on 21-1-2015 -- if there's no product with matching CenterBaySpacing then try to get one with matching width only -- ----
	IF (vProductID =0)
	BEGIN
		-- SET vProductID = GetProductID(48, 6, vStructureWidthID, '');
		SET vProductID = GetProductID_2Params(48, 6, vStructureWidthID,117,GetPropertyValueIDByValue_PropertyID(117,vIsDomestic));
	END
	IF vProductID <> 0 
	BEGIN	
		SET vQuantity = 0;
		-- Salma Modified on 11-1-2015 -- added width in the condition -- ----
		-- IF (vNoOfOpenEnds = 2) SET vQuantity = 2 -- From pageStructureInfo.depart();
		-- IF (vNoOfCraneBreakPoints > 0) SET vQuantity = 2 * vNoOfCraneBreakPoints -- From pageOptions.cmLiftingHooks();
		IF(vStructureWidth<=60) SET vQuantity = vNoOfOpenEnds ;
		ELSEIF (vStructureWidth > 60) SET vQuantity = 2* vNoOfOpenEnds ;
		
	DECLARE  vLeaseTermBID
	END;
   **/
	-- 0600 Insert "Earth Anchor" Product (Earth Anchors ProductTypeID = 29)--------------------		
	-- vAnchorageID IN (58, 59) means Earth or Asphalt
	IF vAnchorageID IN (
			58
			,59
			)
	then
		-- ---------------Modified by Salma in 30-5-2013-- to use GetProductID_2Params insetad of GetProductID---
		-- -------------30 >> DefaultBaySpacing PropertyID-------------------------------------------------------
		-- ---------------Modified by Salma in 18-3-2014-- to use WidthRange instead of StructureWidth---
		-- SET vProductID = GetProductID_2Params(29, 6, vStructureWidthID,30,null);
		SET vProductID = GetProductID_2Params(29, 30, NULL, 104, vStructureWidth);
		IF vProductID <> 0
		then
			-- salama modified in 4-6-2014-- added Triple Panel Rolling Door condition------------------
			SET vQuantity = GetNoOfEarthAnchorsWithTriple(pQuoteID, 0) ;-- GetNoOfEarthAnchors(vStructureWidth, vNoOfBeams, vWindRate);
			call spInsertQuoteItem(pQuoteID
				,vProductID
				,vIsAutoAdded
				,vQuantity
				,vPricingPolicyID
				,vSaleTypeID
				,vLeaseTermAID
                ,vLeaseTermBID);
		END if;
		-- ---------------Modified by Salma in 30-5-2013-- to get Base Level Spreader Product---
		-- ---------------based on Non-Insulation, Width,CenterBaySpacing and No of Flat Ends------------------------
		IF vIsInsulated = 0
			AND vNoOfFlatEnds > 0
		then
			-- get propertyValueID that matches the vCenterBaySpacing -- then get the matching product--
			-- ---------------Modified by Salma in 2-4-2014-- use product type Base Level Spreader whose ProductTypeID=55---
			SET vProductID = GetProductID_2Params(55, 6, vStructureWidthID, 30, GetPropertyValueIDByValue_PropertyID(30, vCenterBaySpacing));
			IF vProductID <> 0
			then
				-- Salma: modified in 7-04-2014 get Engineered flat end product to get CableBracingQtty value form it---------------------------106 is BeamSize 
				SET vEngFlatEndProductID = GetProductID_5Params(12, 6, vStructureWidthID, 101, vMembraneTypeID, 7, vIsInsulatedValueID, 105, vIsLatticeValueID, 106, vSpecialWidthValueID);
				IF vEngFlatEndProductID <> 0
					-- Salma: modified in 15-01-2015-- added OpenEnds in the calcuation
				then
					SET vQuantity = vNoOfFlatEnds * 2 * GetProductPropertyValue_Int(vEngFlatEndProductID, 113) + (vNoOfOpenEnds * 2 * GetProductPropertyValue_Int(vEngFlatEndProductID, 113)); -- 113:CableBracingQtty ;
				
				ELSE
				
					SET vQuantity = (vNoOfFlatEnds * 2) + (vNoOfOpenEnds * 2);
				END if;
				-- GetNoOfEarthAnchors(vStructureWidth, vNoOfBeams, vWindRate)
				call spInsertQuoteItem(pQuoteID
					,vProductID
					,vIsAutoAdded
					,vQuantity
					,vPricingPolicyID
					,vSaleTypeID
					,vLeaseTermAID
                    ,vLeaseTermBID);
			END if;
		END if;
	END if;
	-- Modified by Salma 29-4-2013 
	-- Insert "Ballast Weight" Product (Ballast Weight ProductTypeID = 27)--------------------		
	IF vAnchorageID = 441
	then
		SET vProductID = GetProductID(27, 6, vStructureWidthID, '');
		IF vProductID <> 0
		then
			SET vQuantity = GetNoOfEarthAnchors(vStructureWidth, vNoOfBeams, vWindRate);
			call spInsertQuoteItem(pQuoteID
				,vProductID
				,vIsAutoAdded
				,vQuantity
				,vPricingPolicyID
				,vSaleTypeID
				,vLeaseTermAID
                ,vLeaseTermBID);
		END if;
	END if;
	-- 0700 Insert "C Schedule Allowance" Product -- --------------------
	IF vPricingPolicyID = 2
	then
		SET vProductID = 163;
		SET vQuantity = 1;
		call spInsertQuoteItem(pQuoteID
			,vProductID
			,vIsAutoAdded
			,vQuantity
			,vPricingPolicyID
			,vSaleTypeID
			,vLeaseTermAID
	        ,vLeaseTermBID);
	END if;
/**
	-- Salma Modified on 28/7/2015 commented Tools & Earth Anchor Insulation Kit products based on Ross's email-- 
	-- 0800 Insert "Set of specialized hand tools for erection" Product (Tools ProductTypeID = 33)  -- --------
	-- IF vNoOfToolsSets > 0 
	-- BEGIN
	-- -- Modified by salma on 26-7-2015 to use WithdRange instead of Structure width
	--	-- SET vProductID = GetProductID(33, 6, vStructureWidthID, '');
	--	SET vProductID = GetProductID(33, 104,vStructureWidth, '');
	--	IF(vProductID<>0)
	--	BEGIN
	--	SET vQuantity = vNoOfToolsSets ;
	--	EXEC spInsertQuoteItem pQuoteID, vProductID, vIsAutoAdded, vQuantity, vPricingPolicyID, vSaleTypeID, vLeaseTermAID, vLeaseTermBID
	--	END
	-- END
	-- --Salma Modified on 22/7/2015 Insert "Earth Anchor Instulation Kit" Product in case Tools Product and Earth Anchor products are added as default----------
	-- Select vProductID = ProductID from QuotesItems where ProductID in (select ProductID from Products where ProductTypeID=33) and QuoteID=pQuoteID -- Tools
	-- IF(vProductID IS NOT NULL AND vProductID<>0)
	-- BEGIN
	-- SET vProductID=0
	-- Select vProductID = ProductID from QuotesItems where ProductID in (select ProductID from Products where ProductTypeID=29) and IsAutoAdded=1 and QuoteID=pQuoteID -- Earth Anchors
	-- IF(vProductID IS NOT NULL AND vProductID<>0)
	-- BEGIN -- check if already added
	--    SET vProductID=0
	--	Select vProductID = ProductID from QuotesItems where ProductID in (select ProductID from Products where ProductTypeID=33) and ItemName like 'Earth Anchor Installation Kit'  and QuoteID=pQuoteID--Earth Anchor Installation Kit
	--	IF(vProductID IS NULL OR vProductID=0)
	--	BEGIN
	--		SELECT vProductID =ProductID from Products where ProductTypeID=33 and ProductName like 'Earth Anchor Installation Kit'
	--		IF(vProductID IS NOT NULL AND vProductID<>0)
	--		BEGIN
	--			SET vQuantity = vNoOfToolsSets ;
	--			EXEC spInsertQuoteItem pQuoteID, vProductID, vIsAutoAdded, vQuantity, vPricingPolicyID, vSaleTypeID, vLeaseTermAID, vLeaseTermBID
	--		END
	--	END
	-- END
	-- END
	-- 0900 Insert "Insulation" Product (vInsulationTypeID = 49 : No Insulation)  -- --------------------
    */
	IF vInsulationTypeID <> 49
	then
		-- Salma: modified in 27-2-2013 -- --------------------------------------------------------------------------------------------------
		-- SET vProductID = GetProductID(3, 6, vStructureWidthID, '');
		-- if( vStructureWidth > = 30 AND vStructureWidth < =  90)
		--	BEGIN
		-- Salma: modified on 18-6-2015 used BeamSize,WidthRange,InsulationPackage if no poroduct check product using old code (InsulationThickness, Structure Width)
		SET vProductID = GetProductID_3Params(3, 106, vSpecialWidthValueID, 104, vStructureWidth, 123, vInsulationPackageID);
		IF vProductID IS NULL
			OR vProductID = 0
        then
			SET vProductID = GetProductID_2Params(3, 49, GetProductPropertyValueID(vStructureID, 49), 6, NULL);
        end if;
		-- End
		-- if( vStructureWidth > = 100 AND vStructureWidth < = 200)
		-- BEGIN
		-- SET vProductID =GetProductID_2Params_oneEmpty(3,49,vInsulationThicknessID,6,'');
		-- End
		IF vProductID <> 0
		then
			SET vQuantity = vStructureSQFT;
			-- SET vNotes = 'c/w "' + GetPropertyValue(vMembraneLinerColorID) + '" Interior Membrane';
			-- Salma: modified in 28-2-2013 -- - change Skylight to Daylight Panels and comment the if case------------------
			-- if(GetPropertyValue(vInsulationTypeID)='Daylight Panels')
			-- BEGIN
			-- SET vInsulationTypeValue='daylight panels';
			-- END
			-- ElSE
			-- BEGIN
			SET vInsulationTypeValue = LOWER(GetPropertyValue(vInsulationTypeID));
			-- Salma: modified in 11-8-2015--- add teh following if case------------------
			IF (vInsulationTypeValue LIKE 'daylight panels')
            then
				SET vInsulationTypeValue = concat(' to the ' , vInsulationTypeValue);
			ELSE
				SET vInsulationTypeValue = '';
            end if;
			-- END
			-- Salma: modified in 14-1-2015 -- -Remove Johns Manville from product name in case the PricingPolicy is Baharin------------------
			IF (vPricingPolicyID = 4) -- Bahrain
            then
				-- modified by mohamed fathy 12-6-2016
				SET vItemName = GetQuoteLetterProductName(vProductID); -- SET vItemName=REPLACE(GetProductName(vProductID),'Johns Manville ','');
			ELSE
				-- modified by mohamed fathy 12-6-2016
				SET vItemName = GetQuoteLetterProductName(vProductID); -- SET vItemName=GetProductName(vProductID);
					-- ----Salma Modified in 10-8-2015: get SQFTPerDay property value according to quote insulation and Insulation Package
            end if;
            
			IF (IsInsulated(vInsulationTypeID) > 0)
			then
				IF (vInsulationPackageID = 784) -- No Liner
                then
					-- Salma: modified in 12-5-2015 -- -editted text
					-- SET vItemName=vItemName+' '+vInsulationTypeValue +' c/w "' + GetPropertyValue(vMembraneLinerColorID) + '" Interior Membrane'
					SET vItemName = vItemName + vInsulationTypeValue + ' c/w white polypropylene or foil backing (no interior liner membrane)';
				ELSE
					-- Salma: modified in 12-5-2015 -- -editted text
					-- SET vItemName=vItemName+' '+vInsulationTypeValue +' c/w "' + GetPropertyValue(vMembraneLinerColorID) + '" Interior Membrane'
					SET vItemName = vItemName + vInsulationTypeValue + ' c/w ' + LOWER(GetPropertyValue(vMembraneLinerColorID)) + ' interior liner membrane';
                end if;
			END if;
			call spInsertQuoteItemSpecialName(pQuoteID
				,vProductID
				,vIsAutoAdded
				,vQuantity
				,vPricingPolicyID
				,vSaleTypeID
				,vLeaseTermAID
				,vLeaseTermBID
				,vNotes
				,vItemName
				-- SET vItemName = GetPropertyValue(vInsulationTypeID) +' c/w "' + GetPropertyValue(vMembraneLinerColorID) + '" Interior Membrane';
	            ,vNotes);
		END if;
	END if;
	-- 1000 Insert "Opaque Membrane-No Skylight" Product (vInsulationTypeID = 51 : To Peak) -- ---------------
	IF (vInsulationTypeID <> 51)
		AND (vProvideOpaqueMembrane = 1)
	then
		SET vProductID = GetProductID(20, 6, vStructureWidthID, '');
		IF vProductID <> 0
		then
			SET vQuantity = vStructureSQFT;
			call spInsertQuoteItem(pQuoteID
				,vProductID
				,vIsAutoAdded
				,vQuantity
				,vPricingPolicyID
				,vSaleTypeID
				,vLeaseTermAID
                ,vLeaseTermBID);
		END if;
	END if;
	-- 1100 Insert "Membrane" -- --------------
	-- SET vProductID = GetProductID(2, 12, vFabricTypeID, '');
	SET vProductID = GetProductID(2, 101, vMembraneTypeID, '');
	-- SET vProductID = GetProductID_2Params(2, 12, vMembraneTypeID, 13, vMembraneColorID);
	IF vProductID <> 0
	then
		-- SET vQuantity = vStructureStandardSQFT;
		SET vQuantity = vStructureSQFT;
		-- Salma: Modified on 20-02-2013 cleared Notes
		SET vNotes = '';
		-- IF vInsulationTypeID = 50 SET vNotes = 'complete with translucent skylight';
		-- ELSE SET vNotes = 'no skylight';
		-- Salma: modified in 06-06-2013 -- - get product based on membrane type, insulation and width range------------------
		IF (LOWER(GetPropertyValue(vMembraneTypeID)) LIKE '%premium%')
		then
			-- --Salma : Modified in 6-4-2014 modify naming----
			SET vItemName = 'Tedlar or Kynar';
			IF (
					vStructureWidth >= 30
					AND vStructureWidth <= 40
					)
			then
				-- --Salma : Modified in 1-7-2015 use vStructureWidth instead of GetPropertyValueIDByValue_PropertyID(104,'30-40')
				SET vProductID = GetProductID_3Params(2, 104, vStructureWidth, 101, vMembraneTypeID, 7, NULL);
			
			ELSEIF (vStructureWidth > 40)
			then
				-- --Salma : Modified in 1-7-2015 use vStructureWidth instead of GetPropertyValueIDByValue_PropertyID(104,'50-160')
				SET vProductID = GetProductID_3Params(2, 104, vStructureWidth, 101, vMembraneTypeID, 7, NULL);
			END if;
		
		ELSEIF (LOWER(GetPropertyValue(vMembraneTypeID)) LIKE '%standard%')
		then
			-- --Salma : Modified in 6-4-2014 modify naming----
			SET vItemName = 'Polyurethane';
			SET vProductID = GetProductID_3Params(2, 104, NULL, 101, vMembraneTypeID, 7, NULL);
		
		ELSEIF (LOWER(GetPropertyValue(vMembraneTypeID)) LIKE '%lta%')
		then
			-- --Salma : Modified in 6-4-2014 modify naming----
			SET vItemName = 'Low Temperature Arctic';
			-- --Salma : Modified in 1-7-2015  use 4 params instead of 3 to check insulation package----
			-- SET vProductID = GetProductID_3Params(2, 104,null, 101, vMembraneTypeID,7, vIsInsulatedValueID);
			SET vProductID = GetProductID_4Params(2, 104, vStructureWidth, 101, vMembraneTypeID, 7, vIsInsulatedValueID, 123, vInsulationPackageID);
		END if;
		-- Salma: modified in 28-2-2013 -- - set product name as required based on membrane type------------------
		IF (LOWER(GetPropertyValue(vFabricTypeID)) LIKE CONCAT('%' , vCompareVariable , '%'))
		then
			-- --Salma : Modified in 6-4-2014 modify naming----
			SET vItemName = CONCAT(vItemName , vnodaylightVariable);
				-- SET vItemName =GetProductName(vProductID)+vnodaylightVariable;
				-- ----------------------------------------------------------------------------------------------------------
		ELSE
		
			-- --Salma : Modified in 6-4-2014 modify naming----
			SET vItemName = CONCAT(vItemName , vdaylightVariable);
				-- SET vItemName =GetProductName(vProductID)+vdaylightVariable;
		END if;
		-- SET vNotes = GetPropertyValue(vMembraneTypeID) + ' ' + GetPropertyValue(vMembraneColorID) + ', ' +vNotes;
        -- EXEC spInsertQuoteItem @QuoteID, @ProductID, @IsAutoAdded, @Quantity, @PricingPolicyID, @SaleTypeID, @LeaseTermAID, @LeaseTermBID, @Notes
		call spInsertQuoteItemSpecialName(pQuoteID
			,vProductID
			,vIsAutoAdded
			,vQuantity
			,vPricingPolicyID
			,vSaleTypeID
			,vLeaseTermAID
			,vLeaseTermBID
			,vNotes
	        ,vItemName);
	END if; 
	-- 1200 Insert "Framed Opening(s)" Product (vInsulationTypeID = 49 : No Insulation) -- --------------------
	/*
	IF vInsulationTypeID = 49 SET vProductID = 43  ;
	ELSE SET vProductID = 44;
	SET vQuantity = 1 ;
	EXEC spInsertQuoteItem pQuoteID, vProductID, vIsAutoAdded, vQuantity, vPricingPolicyID, vSaleTypeID, vLeaseTermAID, vLeaseTermBID  
	*/
	-- 1300 Insert "Cable Tensioned End Panel. (ProductTypeID = 28: Cable Tensioned Flat End Panels; PropetyID = 12 = membraneTypeID) -- ---  
	SET vProvideTensionCable = 1;-- added by mohamed fathy 1-6-2016;
	IF (vProvideTensionCable = 1)
		AND (vNoOfOpenEnds > 0)
	then
		-- Salma: modified in 16-3-2014 -- - add is insulated property to the parameters of the product------------------
		SET vProductID = GetProductID_3Params(28, 6, vStructureWidthID, 101, vMembraneTypeID, 7, vIsInsulatedValueID);
		IF vProductID <> 0
		then
			-- Salma: modified in 28-2-2013 -- - set product name as required based on membrane type------------------
			-- Salma: modified in 3-6-2013 -- - set product name as required based on open ends------------------
			-- modified by Mohamed Fathy 12-6-2016
			SET vItemName = GetQuoteLetterProductName(vProductID); -- SET vItemName = 'Open Ends c/w ' + SUBSTRING(GetProductName(vProductID), 1, LOCATE('-', GetProductName(vProductID)) - 1)+' - '+GetPropertyValue(vFabricTypeID);
			SET vQuantity = vNoOfOpenEnds;
            -- EXEC spInsertQuoteItem @QuoteID, @ProductID, @IsAutoAdded, @Quantity, @PricingPolicyID, @SaleTypeID, @LeaseTermAID, @LeaseTermBID
			call spInsertQuoteItemSpecialName(pQuoteID
				,vProductID
				,vIsAutoAdded
				,vQuantity
				,vPricingPolicyID
				,vSaleTypeID
				,vLeaseTermAID
				,vLeaseTermBID
				,vNotes
                ,vItemName);
				-- Salma: added in 25-2-2014 -- - add custom product if no open matching open ends product------------------
		ELSE
		
			-- added by Mohamed fathy 7-6-2016
			IF vStructureWidth >= 30
				AND vStructureWidth <= 60
			then
				SET vItemName = 'Open end(s) each c/w 1 bay(s) of cable bracing';
			
			ELSEIF vStructureWidth >= 70
				AND vStructureWidth <= 160
			then
				SET vItemName = 'Open end(s) each c/w 2 bay(s) of cable bracing';
			
			ELSE
			
				SET vItemName = 'Open Ends';
			END if;
			SET vQuantity = vNoOfOpenEnds;
			SET vNotes = '';
			call spInsertQuoteItemCustom(pQuoteID
				,vProductID
				,vItemName
				,vItemTypeID
				,vIsAutoAdded
				,vIsDisplayedInReports
				,vQuantity
				,0
				,0
				,0
				,0
                ,vNotes);
		END if;
	END if;
	-- 1400 Insert "Interior Suspension Eyenut(s)" Product -- --------------------
	SET vProductID = 45;
	SET vQuantity = GetNoOfEyeNuts(vStructureWidth, vNoOfBeams);
	call spInsertQuoteItem(pQuoteID
		,vProductID
		,vIsAutoAdded
		,vQuantity
		,vPricingPolicyID
		,vSaleTypeID
		,vLeaseTermAID
		,vLeaseTermBID);
	-- 1500 Insert "Engineered Flat End(s)" Product (ProductTypeID = 12: Engineered Flat Ends)-----
	IF vNoOfFlatEnds <> 0
	then
		-- A Insert "Engineered Flat End Panel(s)" (ProductTypeID = 12: Engineered Flat Ends)
		-- SET vProductID = GetProductID_3Params(12, 6, vStructureWidthID, 12, vMembraneTypeID, 7, vIsInsulatedValueID);
		-- Salma: modified in 02-07-2013 used param4 function to add Islattice Product---------------------------
		-- Salma: modified in 04-07-2013 used param5 function to add SpecialWidth Product--------------------------
		-- Salma: modified in 18-6-2015 use also InsulationPackage and use  GetProductID_6Params instead of GetProductID_5Params
		SET vProductID = GetProductID_6Params(12, 6, vStructureWidthID, 101, vMembraneTypeID, 7, vIsInsulatedValueID, 105, vIsLatticeValueID, 106, vSpecialWidthValueID, 123, vInsulationPackageID);
		-- Salma: modified in 28-2-2013 used param3 function , passing 101 instead of MembraneID---------------------------
		-- SET vProductID = GetProductID_3Params(12, 6, vStructureWidthID, 101, vMembraneTypeID, 7, vIsInsulatedValueID);
		-- SET vProductID = GetProductID_2Params(12, 6, vStructureWidthID, 12, vMembraneTypeID);
		IF vProductID <> 0
		then
			-- ----Salma:Modified in 4-3-2013-- add the note to item name and don't write a note for the product
			SET vQuantity = vNoOfFlatEnds;
			SET vNotes = 'c/w cable bracing as required';
			-- modified by Mohamed Fathy 12-6-2016
			SET vItemName = GetQuoteLetterProductName(vProductID); -- GetProductName(vProductID) -- +' '+vNotes ;
			SET vNotes = '';
			call spInsertQuoteItemSpecialName(pQuoteID
				,vProductID
				,vIsAutoAdded
				,vQuantity
				,vPricingPolicyID
				,vSaleTypeID
				,vLeaseTermAID
				,vLeaseTermBID
				,vNotes
				,vItemName
                ,vNotes);
		END if;
		-- B Insert "Engineered Flat End membrane" (ProductTypeID = 13: Engineered Flat Ends Membrane)
		-- SET vProductID = GetProductID_3Params(13, 6, vStructureWidthID, 12, vMembraneTypeID, 7, vIsInsulatedValueID);
		-- Salma: modified in 28-2-2013 used param3 function , passing 101 instead of MembraneID---------------------------
		SET vProductID = GetProductID_3Params(13, 6, vStructureWidthID, 101, vMembraneTypeID, 7, vIsInsulatedValueID);
		-- SET vProductID = GetProductID_2Params(13, 6, vStructureWidthID, 12, vMembraneTypeID);
		IF vProductID <> 0
		then
			SET vQuantity = vNoOfFlatEnds;
			call spInsertQuoteItem(pQuoteID
				,vProductID
				,vIsAutoAdded
				,vQuantity
				,vPricingPolicyID
				,vSaleTypeID
				,vLeaseTermAID
                ,vLeaseTermBID);
		END if;
		-- C Insert "Engineered Flat End Insulation" (ProductTypeID = 14: Engineered Flat Ends Insulation)
		IF vIsInsulated = 1
			-- IF vInsulationTypeID <> 49
		then
			SET vProductID = GetProductID(14, 6, vStructureWidthID, '');
			IF vProductID <> 0
			then
				SET vQuantity = vNoOfFlatEnds;
				call spInsertQuoteItem(pQuoteID
					,vProductID
					,vIsAutoAdded
					,vQuantity
					,vPricingPolicyID
					,vSaleTypeID
					,vLeaseTermAID
                    ,vLeaseTermBID);
			END if;
		END if;
	END if;
	-- 1600 Insert "Engineered Stamped Drawings" -- ------------------------------
	SET vProductID = 591;
	SET vQuantity = 1;
	call spInsertQuoteItem(pQuoteID
		,vProductID
		,vIsAutoAdded
		,vQuantity
		,vPricingPolicyID
		,vSaleTypeID
		,vLeaseTermAID
		,vLeaseTermBID);
	-- 1700 Insert "Engineering Site Inspections" Location (indiana, IndianaPolis...) -- --------------------
	IF vLocationID IN (
			29
			,119
			)
	then
		SET vProductID = 0; -- 0 means custom Item;
		SET vItemName = 'Engineering Site Inspections';
		SET vQuantity = 1;
		SET vNotes = '';
		call spInsertQuoteItemCustom(pQuoteID
			,vProductID
			,vItemName
			,vItemTypeID
			,vIsAutoAdded
			,vIsDisplayedInReports
			,vQuantity
			,5000
			,5000
			,5000
			,0
	        ,vNotes);
	END if;
	-- 1800 Insert "Conduit Holes Set" -- ----------------------------------------
	SET vProductID = 0; -- 0 means custom Item;
	SET vItemName = 'Conduit Holes Set as per diagram provided by Sprung';
	SET vQuantity = vStructureSQFT;
	SET vNotes = '';
    /**
	-- --Salma--modified in 4-2-2015--changed the conditions and commented the old ones
	-- IF vStructureWidth <= 90
	-- BEGIN
	--	EXEC spInsertQuoteItemCustom pQuoteID, vProductID, vItemName, vItemTypeID, vIsAutoAdded, vIsDisplayedInReports, vQuantity, 0, 0, 0, 0, vNotes
	-- END
	-- ELSE
	-- BEGIN
	--	IF vProvideConduitHoles = 1
	--	BEGIN
	--	-- --Salma--modified in 24-7-2013--changed the price from 0.5 to 0.54
	--		EXEC spInsertQuoteItemCustom pQuoteID, vProductID, vItemName, vItemTypeID, vIsAutoAdded, vIsDisplayedInReports, vQuantity, 0.54, 0.54, 0.54, 0, vNotes
	--	END
	-- END
    */
	-- --Salma--modified in 25-2-2015 removed the width condition and added the beamsize ones
	SET vBeamSize = GetProductPropertyValue(vStructureID, 106); -- beamSize;
	IF (
			(vBeamSize NOT LIKE '5" X 10"')
			AND vProvideConduitHoles = 1
			) -- vStructureWidth <= 90 OR vProvideConduitHoles = 1
	then
		-- IF(vBeamSize NOT like '5" X 10"')
		
			IF (vPricingPolicyID = 2) -- LTD
            then
				call spInsertQuoteItemCustom(pQuoteID
					,vProductID
					,vItemName
					,vItemTypeID
					,vIsAutoAdded
					,vIsDisplayedInReports
					,vQuantity
					,0.59
					,0.59
					,0.59
					,0
                    ,vNotes);
			ELSE
				call spInsertQuoteItemCustom(pQuoteID
					,vProductID
					,vItemName
					,vItemTypeID
					,vIsAutoAdded
					,vIsDisplayedInReports
					,vQuantity
					,0.54
					,0.54
					,0.54
					,0
                    ,vNotes);
            end if;
            
			-- ELSE 
            -- EXEC spInsertQuoteItemCustom @QuoteID, @ProductID, @ItemName, @ItemTypeID, @IsAutoAdded, @IsDisplayedInReports, @Quantity, 0, 0, 0, 0, @Notes
	
	ELSEIF (vBeamSize LIKE '5" X 10"')
	then
		call spInsertQuoteItemCustom(pQuoteID
			,vProductID
			,vItemName
			,vItemTypeID
			,vIsAutoAdded
			,vIsDisplayedInReports
			,vQuantity
			,0
			,0
			,0
			,0
            ,vNotes);
	END if;
	-- 1900 Insert "Center Bay Spacing" -- ----------------------------------------
	SET vProductID = 0; -- 0 means custom Item;
	SET vItemName = concat(ltrim(Str(vCenterBaySpacing, LEN(vCenterBaySpacing), 2)) , ' Center Bay Spacing');
	SET vQuantity = 1;
	SET vNotes = '';
	IF vStructureWidth > 51
		AND vStandardCenterBaySpacing <> vCenterBaySpacing
	then
		-- --Salma--modified in 21-1-2015--changed lease pricr to be 0 instead of vStructureStandardSQFT
		call spInsertQuoteItemCustom(pQuoteID
			,vProductID
			,vItemName
			,vItemTypeID
			,vIsAutoAdded
			,vIsDisplayedInReports
			,vQuantity
			,0
			,0
			,0
			,0
            ,vNotes);
	END if;
    /**
	-- --Salma--modified in 12-1-2014-- commented the following since the sur charge is now added to the prices list already---
	-- --Salma--modified in 12-6-2013-- added the following case to show "New Membrane" custom product in case LeaseA<12---
	-- IF ((vLeaseTermAID > 0 AND vLeaseTermAID < 12 )OR (vLeaseTermBID > 0 AND vLeaseTermBID < 12 ) )
	-- BEGIN
	--	SET vProductID = 0 -- 0 means custom Item;
	--	SET vQuantity = 1;
	--	SET vItemName ='New Membrane';
	--	SET vNotes = '';
	--	IF(vLeaseTermAID > 0 AND vLeaseTermAID < 12 )
	--		SET vLeaseTermAPrice= vStructureStandardSQFT*1.75
	--	ELSE 
	--		SET vLeaseTermAPrice=0
	--	if(vLeaseTermBID > 0 AND vLeaseTermBID < 12 )
	--		SET vLeaseTermBPrice= vStructureStandardSQFT*1.75
	--	ELSE 
	--		SET vLeaseTermBPrice=0
	--    EXEC spInsertQuoteItemCustom pQuoteID, vProductID, vItemName, vItemTypeID, vIsAutoAdded, vIsDisplayedInReports, vQuantity, 0, vLeaseTermAPrice,vLeaseTermBPrice, 0, vNotes
	-- END
    **/
	-- Salma Modified in 12-1-2015 added tax products
	call spInsertTaxProducts(pQuoteID);
		-- ----------------------------------------------------------------------------------------
END;
