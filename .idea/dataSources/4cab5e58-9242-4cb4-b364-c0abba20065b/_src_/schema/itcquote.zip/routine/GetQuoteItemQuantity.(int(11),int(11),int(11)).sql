CREATE FUNCTION itcquote.GetQuoteItemQuantity(pQuoteID INT, pProductTypeID INT, pProductID INT)
  RETURNS INT(6)
  BEGIN
	DECLARE vResult int;
	SET vResult = 1;
	IF pProductTypeID = 7
	THEN
		SET vResult = GetNoOfVents(pQuoteID, pProductID);
	END IF;
	IF pProductTypeID = 10
	THEN
		SET vResult = GetNoOfLiftHooks(pQuoteID);
	END IF;
	RETURN vResult;
END;
