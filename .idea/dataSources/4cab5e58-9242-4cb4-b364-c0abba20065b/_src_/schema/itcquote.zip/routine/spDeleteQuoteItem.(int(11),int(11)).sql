CREATE PROCEDURE itcquote.spDeleteQuoteItem(IN `_QuoteID` INT, IN `_ProductID` INT)
  BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
    -- Insert statements for procedure here
	DELETE from  QuotesItems WHERE (QuoteID = _QuoteID) AND (ProductID = _ProductID);
end;
