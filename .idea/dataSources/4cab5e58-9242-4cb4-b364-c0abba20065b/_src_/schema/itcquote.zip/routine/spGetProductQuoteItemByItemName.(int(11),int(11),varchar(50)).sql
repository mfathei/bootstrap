CREATE PROCEDURE itcquote.spGetProductQuoteItemByItemName(IN pQuoteID INT, IN pProductID INT, IN pItemName VARCHAR(50))
  BEGIN
SELECT QuotesItems.QuoteID
	,QuotesItems.ProductID
	,QuotesItems.ItemName
	,QuotesItems.ItemTypeID
	,QuotesItems.IsAutoAdded
	,QuotesItems.IsDisplayedInReports
	,QuotesItems.Quantity
	,QuotesItems.OriginalSalePrice
	,QuotesItems.OriginalLeaseTermAPrice
	,QuotesItems.OriginalLeaseTermBPrice
	,QuotesItems.OriginalManhours
	,QuotesItems.CustomSalePrice
	,QuotesItems.CustomLeaseTermAPrice
	,QuotesItems.CustomLeaseTermBPrice
	,QuotesItems.CustomManhours
	,QuotesItems.Notes
	,QuotesItems.Description
	,QuotesItems.RequiredLength
	,QuotesItems.NoOfConnectedStructures
	,QuotesItems.WallsCount
	,QuotesItems.InstancesNo
	,Products.ProductName
	,Products.UnitID
FROM Products
RIGHT JOIN QuotesItems ON Products.ProductID = QuotesItems.ProductID
WHERE (QuotesItems.QuoteID = pQuoteID)
	AND (QuotesItems.Productid = pProductID)
	AND (itemname = pItemName)
ORDER BY QuotesItems.QuoteID;
END;
