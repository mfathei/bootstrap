CREATE PROCEDURE itcquote.ApproveGSAprices()
  BEGIN
	DECLARE vCount INT;
	DECLARE vfromPolicyID INT DEFAULT 1;
		-- Inc
	DECLARE vtoPolicyID INT DEFAULT 16; -- GSA
	CALL BackupOldPrices(vtoPolicyID);
	DELETE
	FROM ProductsPrices
	WHERE PricingPolicyID = vtoPolicyID;
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	-- SET vPolicyName = (SELECT PricingPolicyName FROM PricingPolicies WHERE PricingPolicyID=vpolicyID);
	-- SET vPolicyName=vPolicyName+'_'+CONVERT(VARCHAR(50),Month(GETDATE()))+'_'+CONVERT(VARCHAR(50),YEAR(GETDATE()))
	-- set vCount= (SELECT COUNT(*) FROM PricingPolicies WHERE PricingPolicyName = vPolicyName)
	-- if(vCount > 0) RETURN -1
	-- INSERT INTO  PricingPolicies (PricingPolicyName,[Description])--values(vPolicyName,)
	-- SELECT vPolicyName,[DescriptionFROM PricingPolicies WHERE PricingPolicyID=vpolicyID
	-- set vnewPolicyID=(SELECT vvIDENTITY)
	INSERT INTO ProductsPrices (
		ProductID
		,PricingPolicyID
		,PricingTypeID
		,Price
		)
	SELECT ProductID
		,vtoPolicyID
		,PricingTypeID
		,Price
	FROM ProductsPrices
	WHERE PricingPolicyID = vfromPolicyID;
	SET vCount = (
			SELECT COUNT(PricingPolicyID)
			FROM ProductsPrices
			WHERE PricingPolicyID = vtoPolicyID
			);
	SELECT vCount;
		-- If return -1 then pricing policy with the same name already exists
		-- If return 0 then pricing policy is added but with no prices
		-- Otherwise return the number of added prices 
END;
