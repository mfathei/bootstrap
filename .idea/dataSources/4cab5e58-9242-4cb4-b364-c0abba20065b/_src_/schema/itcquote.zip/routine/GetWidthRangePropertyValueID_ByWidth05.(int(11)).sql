CREATE PROCEDURE itcquote.GetWidthRangePropertyValueID_ByWidth05(IN pStructureWidth INT)
  BEGIN
	-- DECLARE pPropertyValueID INT;
	
    DROP TEMPORARY TABLE IF EXISTS GetWidthRangePropertyValueID_ByWidth05_t; 
    CREATE TEMPORARY TABLE GetWidthRangePropertyValueID_ByWidth05_t(`Value` INT NULL);
	--  Fill the table variable with the rows for your result set
    SET @qry = CONCAT("INSERT INTO `GetWidthRangePropertyValueID_ByWidth05_t`(Value) ( SELECT PropertyValueID FROM PropertiesValues WHERE PropertyID = 104 AND "
        , pStructureWidth," BETWEEN TRIM(REPLACE(SUBSTRING(TheValue, 1, INSTR(TheValue,'-')), '-', '')) 
		AND TRIM(REPLACE(SUBSTRING(TheValue, INSTR(TheValue,'-'), LENGTH(TheValue)), '-', ''))) ");  	 
    PREPARE stmt FROM @qry;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
    
END;
