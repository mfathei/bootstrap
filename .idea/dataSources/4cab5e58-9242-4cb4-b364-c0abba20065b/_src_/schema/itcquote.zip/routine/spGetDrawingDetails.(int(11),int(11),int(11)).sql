CREATE PROCEDURE itcquote.spGetDrawingDetails(IN `_DrawID` INT, IN `_AccountID` INT, IN `_TerritoryID` INT)
  BEGIN
SELECT  *
FROM    Drawings 
where  (DrawingID = _DrawID);
END;
