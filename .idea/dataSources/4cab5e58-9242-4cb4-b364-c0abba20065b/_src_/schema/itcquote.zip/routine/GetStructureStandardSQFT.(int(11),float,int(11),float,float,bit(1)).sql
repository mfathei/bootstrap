CREATE FUNCTION itcquote.GetStructureStandardSQFT(pStructureWidth          INT, pStructureLength FLOAT,
                                                  pNoOfCraneBreakPoints    INT, pStandardCenterBaySpacing FLOAT,
                                                  pStructureStandardLength FLOAT, pIsAdditionToExistingStructure BIT)
  RETURNS FLOAT
  BEGIN
	DECLARE vResult FLOAT;
		-- Salma Modified on 24-7-2013--add the following parameter to be used instead of pNoOfCraneBreakPoints in the calculation
	DECLARE vCraneBreakPoints FLOAT;
	IF (pStructureLength < pStructureWidth)
		AND (pIsAdditionToExistingStructure <> 1)
	THEN
		-- Salma Modified on 24-7-2013--add 0.5 intsead of 1 if length < width according to prices page 2
		-- SET vCraneBreakPoints = pNoOfCraneBreakPoints + 1
		SET vCraneBreakPoints = pNoOfCraneBreakPoints + 0.5;
	ELSE
		SET vCraneBreakPoints = pNoOfCraneBreakPoints;
	END IF;
	SET vResult = pStructureWidth * (pStructureStandardLength + (vCraneBreakPoints * pStandardCenterBaySpacing));
	-- Salma Modified on 21-10-2014--- added condition so that if StandardSQFT < area therefore it should be equal to area
	IF (vResult < (pStructureLength * pStructureWidth))
	THEN
		SET vResult = pStructureLength * pStructureWidth;
	END IF;
	RETURN IFNULL(vResult, 0.0);
END;
