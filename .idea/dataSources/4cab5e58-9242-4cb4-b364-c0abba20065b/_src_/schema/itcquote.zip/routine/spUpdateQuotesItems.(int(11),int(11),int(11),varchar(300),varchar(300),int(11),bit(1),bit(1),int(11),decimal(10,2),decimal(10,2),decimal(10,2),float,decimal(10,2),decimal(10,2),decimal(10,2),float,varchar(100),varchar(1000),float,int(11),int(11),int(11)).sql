CREATE PROCEDURE itcquote.spUpdateQuotesItems(IN pQuoteID                 INT, IN pProductID INT, IN pOldProductID INT,
                                              IN pOldItemName             VARCHAR(300), IN pItemName VARCHAR(300),
                                              IN pItemTypeID              INT, IN pIsAutoAdded BIT,
                                              IN pIsDisplayedInReports    BIT, IN pQuantity INT,
                                              IN pOriginalSalePrice       DECIMAL(10, 2),
                                              IN pOriginalLeaseTermAPrice DECIMAL(10, 2),
                                              IN pOriginalLeaseTermBPrice DECIMAL(10, 2), IN pOriginalManhours FLOAT,
                                              IN pCustomSalePrice         DECIMAL(10, 2),
                                              IN pCustomLeaseTermAPrice   DECIMAL(10, 2),
                                              IN pCustomLeaseTermBPrice   DECIMAL(10, 2), IN pCustomManhours FLOAT,
                                              IN pNotes                   VARCHAR(100), IN pDescription VARCHAR(1000),
                                              IN pRequiredLength          FLOAT, IN pNoOfConnectedStructures INT,
                                              IN pWallsCount              INT, IN pInstancesNo INT)
  BEGIN
	IF pItemTypeID <> 0
	then
		UPDATE QuotesItems
		SET ProductID = pProductID
			,ItemName = pItemName
			,ItemTypeID = pItemTypeID
			,IsAutoAdded = pIsAutoAdded
			,IsDisplayedInReports = pIsDisplayedInReports
			,Quantity = pQuantity
			,OriginalSalePrice = pOriginalSalePrice
			,OriginalLeaseTermAPrice = pOriginalLeaseTermAPrice
			,OriginalLeaseTermBPrice = pOriginalLeaseTermBPrice
			,OriginalManhours = pOriginalManhours
			,CustomSalePrice = pCustomSalePrice
			,CustomLeaseTermAPrice = pCustomLeaseTermAPrice
			,CustomLeaseTermBPrice = pCustomLeaseTermBPrice
			,CustomManhours = pCustomManhours
			,Notes = pNotes
			,Description = pDescription
			,RequiredLength = pRequiredLength
			,NoOfConnectedStructures = pNoOfConnectedStructures
			,WallsCount = pWallsCount
			,InstancesNo = pInstancesNo
		WHERE QuoteID = pQuoteID
			AND ProductID = pOldProductID
			AND ItemName = pOldItemName;
	
	ELSE
	
		UPDATE QuotesItems
		SET ProductID = pProductID
			,ItemName = pItemName
			,IsAutoAdded = pIsAutoAdded
			,IsDisplayedInReports = pIsDisplayedInReports
			,Quantity = pQuantity
			,OriginalSalePrice = pOriginalSalePrice
			,OriginalLeaseTermAPrice = pOriginalLeaseTermAPrice
			,OriginalLeaseTermBPrice = pOriginalLeaseTermBPrice
			,OriginalManhours = pOriginalManhours
			,CustomSalePrice = pCustomSalePrice
			,CustomLeaseTermAPrice = pCustomLeaseTermAPrice
			,CustomLeaseTermBPrice = pCustomLeaseTermBPrice
			,CustomManhours = pCustomManhours
			,Notes = pNotes
			,Description = pDescription
			,RequiredLength = pRequiredLength
			,NoOfConnectedStructures = pNoOfConnectedStructures
			,WallsCount = pWallsCount
			,InstancesNo = pInstancesNo
		WHERE QuoteID = pQuoteID
			AND ProductID = pOldProductID
			AND ItemName = pOldItemName;
	END if;
END;
