CREATE FUNCTION itcquote.GetQuoteReportTemplateFullName(pQuoteID INT, pTemplatesDir VARCHAR(2000), pReportTypeID INT)
  RETURNS VARCHAR(21844)
  BEGIN
	DECLARE vResult VARCHAR(21844) CHARSET utf8;
	DECLARE vSeparator VARCHAR(1);
	DECLARE vLeaseTermAID int;
	DECLARE vLeaseTermBID int;
	SET vSeparator = '\';
	-- IF CHARINDEX(\'Templates\', pTemplatesDir) = 0
		SET pTemplatesDir = 'http://portal.sprung.com/ITCquotes/V01/WS/ITCQuotesShared/Templates/';
		-- SET pTemplatesDir = 'http://192.168.250.113:8080/ITCQuotesShared/Templates/'  ;
		SET vSeparator = '/';
	IF INSTR(vSeparator, pTemplatesDir) = 0
	THEN
		SET pTemplatesDir = concat(pTemplatesDir , vSeparator);
	END IF;
	IF pReportTypeID = 2 -- Compact Report Template
	THEN
		SET pTemplatesDir = concat(pTemplatesDir , 'Compact');
		
			-- Salma Modifeied in 26-5-2015 added the condition to create report without prices
	ELSEIF pReportTypeID = 3 -- Compact Report Template with no Prices
	THEN
		SET pTemplatesDir = concat(pTemplatesDir , 'NoPrices');
	
	ELSE
	
		SELECT IFNULL(LeaseTermAID, 0)
			,IFNULL(LeaseTermBID, 0)
			INTO
			vLeaseTermAID 
			,vLeaseTermBID
		FROM Quotes
		WHERE (QuoteID = pQuoteID);
		IF (vLeaseTermAID = 0)
			AND (vLeaseTermBID = 0)
		THEN
			SET pTemplatesDir = concat(pTemplatesDir , 'S');
        END IF;
        
		IF (vLeaseTermAID <> 0)
			AND (vLeaseTermBID = 0)
		THEN
			SET pTemplatesDir = concat(pTemplatesDir , 'SA');
        END IF;
    
		IF (vLeaseTermAID <> 0)
			AND (vLeaseTermBID <> 0)
		THEN	
			SET pTemplatesDir = concat(pTemplatesDir , 'SAB');
		END IF;
	END IF;
	SET vResult = concat(pTemplatesDir , vSeparator , 'ITCQuoteSeed.xsl');
	RETURN vResult;
END
;
