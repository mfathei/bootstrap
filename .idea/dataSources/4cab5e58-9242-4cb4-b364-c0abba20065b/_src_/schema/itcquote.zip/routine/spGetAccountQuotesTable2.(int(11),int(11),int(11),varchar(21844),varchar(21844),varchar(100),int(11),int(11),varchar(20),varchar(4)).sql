CREATE PROCEDURE itcquote.spGetAccountQuotesTable2(IN pAccountID  INT, IN pTerritoryID INT, IN pQuoteID INT,
                                                   IN pCode       VARCHAR(21844), IN pTitle VARCHAR(21844),
                                                   IN pCompany    VARCHAR(100), IN pPageNo INT, IN pPageSize INT,
                                                   IN pSortColumn VARCHAR(20), IN pSortOrder VARCHAR(4))
  BEGIN
	/*–Declaring Local Variables corresponding to parameters for modification */
	DECLARE vlPageNbr INT;
	DECLARE vlPageSize INT;
	DECLARE vlSortCol NVARCHAR(20);
	DECLARE vlFirstRec INT;
	DECLARE vlLastRec INT;
	DECLARE vlTotalRows INT;
	DECLARE vIsAdmin INT;
    IF pAccountID IS NULL
    THEN
        SET pAccountID = 0;
    END IF;
    IF pPageNo IS NULL
    THEN
        SET pPageNo = 1;
    END IF;
    IF pPageSize IS NULL
    THEN
        SET pPageSize = 200;
    END IF;    
    IF pSortColumn IS NULL OR pSortColumn = ''
    THEN
        SET pSortColumn = 'QuoteID';
    END IF; 
    
    IF pSortOrder IS NULL OR pSortOrder = ''
    THEN
        SET pSortOrder = 'Desc';
    END IF; 
        
	/*Setting Local Variables*/
	SET vlPageNbr = pPageNo;
	SET vlPageSize = pPageSize;
	SET vlSortCol = TRIM(pSortColumn);
	SET vlFirstRec = (vlPageNbr - 1) * vlPageSize;
	SET vlLastRec = (vlPageNbr * vlPageSize + 1);
	SET vlTotalRows = vlFirstRec - vlLastRec + 1;
	-- Modified by salma 4-2-2014 make added conditions for Isadmin to allow Admins to view all Quotes even Private
	SET vIsAdmin = (
			SELECT IsAdmin
			FROM Accounts
			WHERE AccountID = pAccountID
			);
    if vIsAdmin = b'1' THEN
        SET vIsAdmin =  1;
    else
        SET vIsAdmin =  0;
    end if;
    
			
		/**	
		-- DECLARE vSelectQuery VARCHAR(21844) CHARSET utf8;
		-- DECLARE vSQLQuery VARCHAR(21844) CHARSET utf8;
		-- DECLARE vSelectCount VARCHAR(21844) CHARSET utf8;
		-- DECLARE vSQLCount VARCHAR(21844) CHARSET utf8;
		-- DECLARE vQueryFrom VARCHAR(21844) CHARSET utf8;
		-- DECLARE vQueryWhere VARCHAR(21844) CHARSET utf8;
		-- DECLARE vQueryGroup VARCHAR(21844) CHARSET utf8;
		-- DECLARE vParmCount VARCHAR(21844) CHARSET utf8;
		-- DECLARE vcnt int;
		-- DECLARE vQueryLimit VARCHAR(21844) CHARSET utf8	;
		-- DECLARE vindex VARCHAR(21844) CHARSET utf8;
		-- DECLARE vQueryOrder VARCHAR(21844) CHARSET utf8;
		-- DECLARE vQueryOrder1 VARCHAR(21844) CHARSET utf8;
		-- SET vQueryWhere  =' ';
		-- SET vQueryOrder =' ';
		-- SET vSelectCount = 'SELECT  vcnt = count(distinct QuoteID)';
		-- SET vQueryFrom = ' FROM Quotes;
		-- left outer join Contacts on Quotes.CompanyID=Contacts.ContactID AND ContactTypeID=1
		-- left outer join Accounts on Quotes.CreateAccountID=Accounts.AccountID
		-- left outer join Territories on Accounts.TerritoryID=Territories.TerritoryID
		-- left outer join Contacts as prerpared on Accounts.ContactID=prerpared.ContactID
		-- left outer join DevelopmentManagers  on Quotes.CompletedByAccountID=DevelopmentManagers.ManagerID'
		-- SET vQueryWhere=' WHERE( ((Quotes.ScopeID = 1) AND (Quotes.CreateAccountID ='+Convert(Varchar, pAccountID)+' OR '+Convert(Varchar,vIsAdmin)+'=1)) OR 
		--	((Quotes.ScopeID = 2) AND ((Quotes.CreateAccountID IN (SELECT AccountID FROM Accounts WHERE TerritoryID = '+Convert(Varchar,pTerritoryID)+')) OR ('+Convert(Varchar,vIsAdmin)+'=1))) OR
		--	((Quotes.ScopeID IS NULL) ) OR
		--	((Quotes.CreateAccountID IS NULL) ) OR
		--	((Quotes.ScopeID = 3) ))'
		-- if (Convert(Varchar,pQuoteID)	= 'NULL') SET pQuoteID = 0	;
		-- if( pQuoteID !=0)			
		-- set vQueryWhere +=	' AND  (Quotes.QuoteID='+Convert(Varchar,pQuoteID)+' )'
		-- if (pCode	= 'NULL') SET pCode = ''	;
		-- if( pCode !='')			
		-- set vQueryWhere +=	' AND  (Quotes.Code like' + '''%'+pCode+'%'')'
		-- if (pTitle	= 'NULL') SET pTitle = ''	;
		-- if( pTitle !='')			
		-- set vQueryWhere +=	' AND  (Quotes.Title like' + '''%'+pTitle+'%'')'
		-- if (pCompany	= 'NULL') SET pCompany = ''	;
		-- if( pCompany !='')			
		-- set vQueryWhere +=	' AND  (Contacts.ContactName like' + '''%'+pCompany+'%'')'
		--  SET vSQLCount =   vSelectCount + vQueryFrom +  vQueryWhere;
		--  SET vParmCount = N' vcnt int OUTPUT';
		--  EXEC sp_executesql vSQLCount, vParmCount , vcnt = vcnt OUTPUT;
		-- select vcnt 
		-- Modified by salma 30-6-2014 add inner join to get company name
		-- Modified by salma 1-4-2015 added more joins to get Territory, PrepraredBy and CompletedFor
		--  SET vSelectQuery = 'SELECT  ' + CONVERT(VARCHAR, vcnt) + ' as TotalCount,;
		--   QuoteID, Quotes.Title, Code, Quotes.CreateDate, Quotes.CreateAccountID, Quotes.ScopeID,Contacts.ContactName,CompletedByAccountID,
		-- TerritoryName,prerpared.ContactName as PreparedBy,(IFNULL(FirstName,'''')+'' ''+IFNULL(LastName,''''))as CompletedFor'
		-- IF(pSortColumn = 'CompletedFor')
		-- BEGIN
		-- SET vQueryOrder =' Order By DevelopmentManagers.FirstName,DevelopmentManagers.LastName '+pSortOrder;
		-- SET vQueryOrder1 =' Order By CompletedFor '+pSortOrder;
		--   END
		--   Else IF(pSortColumn = 'PreparedBy')
		-- BEGIN
		-- SET vQueryOrder =' Order By prerpared.ContactName '+pSortOrder;
		-- SET vQueryOrder1 =' Order By ContactName '+pSortOrder;
		--   END
		--   Else IF(pSortColumn = 'TerritoryName')
		-- BEGIN
		-- SET vQueryOrder =' Order By Territories.TerritoryName '+pSortOrder;
		-- SET vQueryOrder1 =' Order By TerritoryName '+pSortOrder;
		--   END
		--   ELSE
		--   BEGIN
		--    SET vQueryOrder=' Order By Quotes.'+pSortColumn+' '+pSortOrder
		--    SET vQueryOrder1 =' Order By QuotesRes.'+pSortColumn+' '+pSortOrder;
		-- END	   
		-- SET vQueryLimit = ' WHERE QuotesRes.rownum > '+CONVERT(VARCHAR, vlFirstRec)+' AND QuotesRes.rownum < '+CONVERT(VARCHAR, vlLastRec);
		-- SET vSelectQuery += ' ,ROW_NUMBER() OVER (' + vQueryOrder + ') rownum  '
		--   SET vSQLQuery = 'SELECT * from ;
		--				('
		--				 + vSelectQuery  + vQueryFrom + vQueryWhere +
		--			    ') QuotesRes '	+ vQueryLimit  + vQueryOrder1
		-- EXEC sp_executesql vSQLQuery 
		--	CREATE TABLE #MyTable (TotalCount int, QuoteID int, Title varchar(500), Code varchar(500), CreateDate datetime, CreateAccountID int, ScopeID int,ContactName varchar(500),
		--	CompletedByAccountID int ,TerritoryName varchar(500), PreparedBy varchar(500), CompletedFor varchar(500))    
		-- --INSERT INTO #MyTable   
		-- insert into #MyTable (TotalCount, QuoteID, Title, Code, CreateDate, CreateAccountID, ScopeID,ContactName,CompletedByAccountID,TerritoryName, PreparedBy, CompletedFor)
		-- EXEC sp_executesql vSQLQuery ;
        **/
	if @row_count is null then
        set @row_count = 0;
	end if;
	
	-- initialize rownum custom function
    SET @MyROWNUM = 0;
    SET @qry = concat('SELECT SQL_CALC_FOUND_ROWS 
             1 AS ROWNUM
			, NULL AS TotalCount
			,
			-- Modified by salma 30-6-2014 add inner join to get company name
			-- Modified by salma 1-4-2015 added mopre joins to get Territory, PrepraredBy and CompletedFor
			QuoteID
			,Quotes.Title
			,Code
			,Quotes.CreateDate
			,Quotes.CreateAccountID
			,Quotes.ScopeID
			,Contacts.ContactName
			,CompletedByAccountID
			,TerritoryName
			,prerpared.ContactName AS PreparedBy
			,CONCAT(IFNULL(FirstName, '') , ' ' , IFNULL(LastName, '')) AS CompletedFor
		FROM Quotes
		LEFT JOIN Contacts ON Quotes.CompanyID = Contacts.ContactID
			AND ContactTypeID = 1
		LEFT JOIN Accounts ON Quotes.CreateAccountID = Accounts.AccountID
		LEFT JOIN Territories ON Accounts.TerritoryID = Territories.TerritoryID
		LEFT JOIN Contacts AS prerpared ON Accounts.ContactID = prerpared.ContactID
		LEFT JOIN DevelopmentManagers ON Quotes.CompletedByAccountID = DevelopmentManagers.ManagerID
		WHERE (
    (
        (Quotes.ScopeID = 1) 
        AND (
            Quotes.CreateAccountID = ', pAccountID,' 
            OR ', vIsAdmin,' = 1
        )
    ) 
    OR (
        (Quotes.ScopeID = 2) 
        AND (
            (
                Quotes.CreateAccountID IN 
                (SELECT 
                    AccountID 
                FROM
                    Accounts 
                WHERE TerritoryID = ', pTerritoryID,')
            ) 
            OR (', vIsAdmin,' = 1)
        )
    ) 
    OR ((Quotes.ScopeID IS NULL)) 
    OR ((Quotes.CreateAccountID IS NULL)) 
    OR ((Quotes.ScopeID = 3))
    ) 	    AND (
				(
					', pQuoteID,' IS NULL
					OR ', pQuoteID,' = 0
					)
				OR Quotes.QuoteID = ', pQuoteID,'
				)
			AND (
				(
					'', pCode,'' IS NULL
					OR '', pCode,'' LIKE ''
					)
				OR Quotes.Code LIKE '', CONCAT('%' , pCode , '%') ,''
				)
			AND (
				(
					'', pTitle,'' IS NULL
					OR '', pTitle,'' LIKE ''
					)
				OR Quotes.Title LIKE '', CONCAT('%' , pTitle , '%') ,''
				)
			AND (
				(
					'', pCompany,'' IS NULL
					OR '', pCompany,'' LIKE ''
					)
				OR Contacts.ContactName LIKE '', CONCAT('%' , pCompany , '%') ,''
				)
     ');
    SET @qryFrom = '';
    SET @qryWhere = '';
    -- select $search, @qryWhere;
    SET @qryGrpHav = '';
    -- SET @qrySort = CONCAT('ORDER BY ',$sidx,' ',$sord,' , fname asc, lname asc ');
    SET @qrySort = CONCAT('ORDER BY ',pSortColumn,' ', pSortOrder);
    SET pPageNo = (pPageNo - 1) * pPageSize;
    SET @qryLimit = CONCAT(' LIMIT ', pPageSize ,' OFFSET ',  pPageNo);
    
    IF pPageNo <> 0 THEN
        SET @qry = REPLACE(@qry, 'SQL_CALC_FOUND_ROWS', '');
    end if;
    
    -- select @qryLimit;
    -- SET @qryLimit = CONCAT(' LIMIT ',$strt,', ',$lmt,' ;');
    SET @qry = CONCAT(@qry, @qryFrom, @qryWhere, @qryGrpHav, @qrySort);
    -- if($export = '0') then
    SET @qry = CONCAT(@qry, @qryLimit);
    -- end if;
    SELECT @qry;
    PREPARE stmt1 FROM @qry;
    EXECUTE stmt1;
    -- if($export = '0') then
    IF pPageNo = 0 THEN
        SET @row_count = FOUND_ROWS();        
    end if;
    SELECT @row_count;
    -- end if;
    DEALLOCATE PREPARE stmt1;
        
        
END;
