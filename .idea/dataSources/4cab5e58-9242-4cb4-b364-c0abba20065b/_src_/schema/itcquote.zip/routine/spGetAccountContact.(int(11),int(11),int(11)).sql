CREATE PROCEDURE itcquote.spGetAccountContact(IN `_AccountID` INT, IN `_TerritoryID` INT, IN `_ContactID` INT)
  BEGIN
	
SELECT   
    Contacts.ContactID, 
	Contacts.ContactName, 
	Contacts.ContactTypeID, 
    Contacts.CreateDate, 
	Contacts.CreateAccountID, 
    Contacts.ScopeID, 
	ContactsTypes.ContactTypeName, 
	Scopes.ScopeName,
	Contacts.CompanyID ,
	Contacts.IsActive       
	FROM   Contacts 
	LEFT OUTER JOIN ContactsTypes ON (Contacts.ContactTypeID = ContactsTypes.ContactTypeID )
	LEFT OUTER JOIN Scopes ON( Contacts.ScopeID = Scopes.ScopeID)
	WHERE ((Contacts.ScopeID = 1) AND  (Contacts.CreateAccountID = _AccountID)) 
	OR ((Contacts.ScopeID = 2) AND (Contacts.CreateAccountID IN (SELECT  AccountID FROM  Accounts WHERE (TerritoryID = _TerritoryID))) )
	OR (Contacts.ScopeID = 3) 
	OR (_AccountID in (select AccountID from Accounts where IsAdmin=1))
	OR (_ContactID IS NOT NULL AND _ContactID<>0 AND Contacts.ContactID=_ContactID)
    Order by Contacts.ContactID ;
end;
