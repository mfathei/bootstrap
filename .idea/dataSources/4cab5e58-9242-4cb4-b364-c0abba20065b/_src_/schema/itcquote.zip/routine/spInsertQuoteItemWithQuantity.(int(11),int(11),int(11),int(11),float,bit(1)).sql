CREATE PROCEDURE itcquote.spInsertQuoteItemWithQuantity(IN pQuoteID    INT, IN pProductID INT, IN pProductTypeID INT,
                                                        IN pItemTypeID INT, IN pQuantity FLOAT, IN pIsAutoAdded BIT)
  BEGIN
	DECLARE vPricingPolicyID int;
	DECLARE vSaleTypeID int;
	DECLARE vLeaseTermAID int;
	DECLARE vLeaseTermBID int;
	-- --Modified by Salma 26-7-2015---------- commented IsAutoAdded-------
	-- ,pIsAutoAdded bit
	-- SET pIsAutoAdded = 0;
	SET vSaleTypeID = 1;
	SELECT  PricingPolicyID
		,LeaseTermAID
		,LeaseTermBID
        into
        vPricingPolicyID
        ,vLeaseTermAID
        ,vLeaseTermBID
	FROM Quotes
	WHERE (QuoteID = pQuoteID);
	call spInsertQuoteItem(pQuoteID
		,pProductID
		,pIsAutoAdded
		,pQuantity
		,vPricingPolicyID
		,vSaleTypeID
		,vLeaseTermAID
		,vLeaseTermBID
		,''
		,pItemTypeID);
END;
