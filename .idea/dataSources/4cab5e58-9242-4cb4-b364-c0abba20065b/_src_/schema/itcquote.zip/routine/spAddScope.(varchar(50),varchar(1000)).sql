CREATE PROCEDURE itcquote.spAddScope(IN ScopeName VARCHAR(50), IN Description VARCHAR(1000), OUT ScopeID INT)
  begin
INSERT into  Scopes
(
  ScopeName ,
Description    
)
VALUES
(
  ScopeName   ,
  Description     
);
SELECT ScopeID = last_insert_id();
end;
