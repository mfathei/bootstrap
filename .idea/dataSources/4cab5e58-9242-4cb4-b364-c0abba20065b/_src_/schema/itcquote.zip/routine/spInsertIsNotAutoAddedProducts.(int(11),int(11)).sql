CREATE PROCEDURE itcquote.spInsertIsNotAutoAddedProducts(IN `_FromQuoteID` INT, IN `_ToQuoteID` INT)
  BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	
		declare  _MinAI ,_ItemTypeID ,_NoOfConnections ,_InteriorDoorID ,_ExteriorDoorID ,_WindowID ,_LogoID ,_MaxAI ,_PricingPolicyID 
				,_SaleTypeID ,_LeaseTermAID ,_LeaseTermBID ,_ProductID ,_ProductTypeID ,_Quantity INT;
		declare  _RelatedProductID INT default 0;
        
        declare  _Notes VARCHAR(10000);
        declare  _ItemName VARCHAR(500);
        declare  _ManHours ,_RequiredLength FLOAT;
        declare  _QuantityInterior FLOAT default 1;
        declare  _QuantityExterior FLOAT default 1;
		declare  _QuantityWindow FLOAT default 1;
		declare  _IsDisplayedInReports ,_IsAutoAdded BIT;
		-- modified by salma on 21-5-2015 to add custom products
		
		declare  _SalePrice ,_LeaseTermAPrice ,_LeaseTermBPrice decimal(19,11);
	
	SET _MinAI = (
			SELECT MIN(AI)
			FROM QuotesItems
			WHERE QuoteID = _FromQuoteID
				AND IsAutoAdded = 0
			);
	SET _MaxAI = (
			SELECT MAX(AI)
			FROM QuotesItems
			WHERE QuoteID = _FromQuoteID
				AND IsAutoAdded = 0
			);
	SET _PricingPolicyID = (
			SELECT PricingPolicyID
			FROM Quotes
			WHERE QuoteID = _ToQuoteID
			);
	SET _SaleTypeID = (
			SELECT SaleTypeID
			FROM Quotes
			WHERE QuoteID = _ToQuoteID
			);
	SET _LeaseTermAID = (
			SELECT LeaseTermAID
			FROM Quotes
			WHERE QuoteID = _ToQuoteID
			);
	SET _LeaseTermBID = (
			SELECT LeaseTermBID
			FROM Quotes
			WHERE QuoteID = _ToQuoteID
			);
 WHILE   _MinAI <= _MaxAI
	do
		SET _ProductID = (
				SELECT ProductID
				FROM QuotesItems
				WHERE AI = _MinAI
				);
		SET _ProductTypeID = (
				SELECT ProductTypeID
				FROM QuotesItems
				INNER JOIN Products ON QuotesItems.ProductID = Products.ProductID
				WHERE AI = _MinAI
				);
		SET _Quantity = (
				SELECT Quantity
				FROM QuotesItems
				WHERE AI = _MinAI
				);
		SET _Notes = (
				SELECT Notes
				FROM QuotesItems
				WHERE AI = _MinAI
				);
		SET _ItemTypeID = (
				SELECT ItemTypeID
				FROM QuotesItems
				WHERE AI = _MinAI
				);
		SET _ItemName = (
				SELECT ItemName
				FROM QuotesItems
				WHERE AI = _MinAI
				);
		SET _IsAutoAdded = (
				SELECT IsAutoAdded
				FROM QuotesItems
				WHERE AI = _MinAI
				);
		IF (
				_ProductTypeID = 21
				OR _ProductTypeID = 41
				OR _ProductTypeID = 42
				) -- Corrdiors, Canopies and Vestibules
		then
			SET _RelatedProductID = (
					SELECT RelatedProductID
					FROM QuotesItems
					WHERE AI = _MinAI
					);
			SET _NoOfConnections = (
					SELECT NoOfConnectedStructures
					FROM QuotesItems
					WHERE AI = _MinAI
					);
			SET _RequiredLength = (
					SELECT RequiredLength
					FROM QuotesItems
					WHERE AI = _MinAI
					);
			SET _InteriorDoorID = (
					SELECT InteriorDoor
					FROM RelatedProducts
					WHERE QuoteID = _FromQuoteID
						AND ProductID = _ProductID
						AND RelatedProductID = _RelatedProductID
					);
			SET _ExteriorDoorID = (
					SELECT ExteriorDoor
					FROM RelatedProducts
					WHERE QuoteID = _FromQuoteID
						AND ProductID = _ProductID
						AND RelatedProductID = _RelatedProductID
					);
			SET _WindowID = (
					SELECT Window
					FROM RelatedProducts
					WHERE QuoteID = _FromQuoteID
						AND ProductID = _ProductID
						AND RelatedProductID = _RelatedProductID
					);
			SET _LogoID = (
					SELECT Logo
					FROM RelatedProducts
					WHERE QuoteID = _FromQuoteID
						AND ProductID = _ProductID
						AND RelatedProductID = _RelatedProductID
					);
			SET _QuantityInterior = (
					SELECT InteriorDoorQuantity
					FROM RelatedProducts
					WHERE QuoteID = _FromQuoteID
						AND ProductID = _ProductID
						AND RelatedProductID = _RelatedProductID
					);
			SET _QuantityExterior = (
					SELECT ExteriorDoorQuantity
					FROM RelatedProducts
					WHERE QuoteID = _FromQuoteID
						AND ProductID = _ProductID
						AND RelatedProductID = _RelatedProductID
					);
			SET _QuantityWindow = (
					SELECT WindowQuantity
					FROM RelatedProducts
					WHERE QuoteID = _FromQuoteID
						AND ProductID = _ProductID
						AND RelatedProductID = _RelatedProductID
					);
			-- DELETE FROM RelatedProducts where QuoteID=_QuoteID AND ProductID=_ProductID AND RelatedProductID=_RelatedProductID
			-- DELETE FROM QuotesItems where AI = _MinAI
			call spInsertRelatedQuoteItem (_ToQuoteID
				,_ProductID
				,_Notes
				,_ItemName
				,_ItemTypeID
				,_NoOfConnections
				,_RequiredLength
				,_InteriorDoorID
				,_ExteriorDoorID
				,_WindowID
				,_LogoID
				,_Quantity
				,_QuantityInterior
				,_QuantityExterior
				,_QuantityWindow);
		
		ELSEIF (_ProductID <> 0)
		then
			-- DELETE FROM QuotesItems where AI = _MinAI 
			call spInsertQuoteItem( _ToQuoteID
				,_ProductID
				,_IsAutoAdded
				,_Quantity
				,_PricingPolicyID
				,_SaleTypeID
				,_LeaseTermAID
				,_LeaseTermBID
				,_Notes
				,_ItemTypeID);
				--  _MinAI
		
		ELSEIF (_IsAutoAdded = 0)
		then
			SET _IsDisplayedInReports = (
					SELECT IsDisplayedInReports
					FROM QuotesItems
					WHERE AI = _MinAI
					);
			SET _SalePrice = (
					SELECT CustomSalePrice
					FROM QuotesItems
					WHERE AI = _MinAI
					);
			SET _LeaseTermAPrice = (
					SELECT CustomLeaseTermAPrice
					FROM QuotesItems
					WHERE AI = _MinAI
					);
			SET _LeaseTermBPrice = (
					SELECT CustomLeaseTermBPrice
					FROM QuotesItems
					WHERE AI = _MinAI
					);
			SET _ManHours = (
					SELECT CustomManhours
					FROM QuotesItems
					WHERE AI = _MinAI
					);
			SET _IsAutoAdded = (
					SELECT IsAutoAdded
					FROM QuotesItems
					WHERE AI = _MinAI
					);
			-- DELETE FROM QuotesItems where AI = _MinAI 
			-- modified by salma on 21-5-2015 to add custom products (uncommented the EXEC)
			call spInsertQuoteItemCustom( _ToQuoteID
				,0
				,_ItemName
				,_ItemTypeID
				,_IsAutoAdded
				,_IsDisplayedInReports
				,_Quantity
				,_SalePrice
				,_LeaseTermAPrice
				,_LeaseTermBPrice
				,_ManHours
				,_Notes);
		end if;
		IF _MinAI = _MaxAI
		then
			SET _MinAI = _MaxAI + 100;
		
		ELSE
		
			SET _MinAI = (
					SELECT MIN(AI)
					FROM QuotesItems
					WHERE QuoteID = _FromQuoteID
						AND IsAutoAdded = 0
						AND AI > _MinAI
					);
	    END if;
 end while;
end;
