CREATE PROCEDURE itcquote.spGetPricingPolicyID(IN `_PricingName` VARCHAR(30))
  BEGIN
  SELECT     PricingPolicyID
FROM         PricingPolicies
WHERE     (PricingPolicyName = _PricingName);
END;
