CREATE PROCEDURE itcquote.spGetSalesOrderReport(IN pSalesOrderID INT, IN pTemplatesDir VARCHAR(2000))
  BEGIN
	DECLARE vQuoteID INT;
	DECLARE vxmlDoc TEXT;
	DECLARE vstrXSL VARCHAR(21844) CHARSET utf8;
	DECLARE vstrDoc VARCHAR(21844) CHARSET utf8;
	DECLARE vstrQuote VARCHAR(21844) CHARSET utf8;
	DECLARE vstrQuoteItems VARCHAR(21844) CHARSET utf8;
	DECLARE vDrawingID INT;
	DECLARE vDrawingRequestID INT;
	DECLARE vPricingPolicyID INT;
	SET pTemplatesDir = 'http://portal.sprung.com/ITCquotes/V01/WS/ITCQuotesShared/Templates/';
	-- SET pTemplatesDir   =  'C:\_ITCQuotes\Templates\';
	SET vQuoteID = (
			SELECT SalesOrders.QuoteID
			FROM SalesOrders
			WHERE (SalesOrders.SalesOrderID = pSalesOrderID)
			);
            
	SET vPricingPolicyID = (
			SELECT PricingPolicyID
			FROM Quotes
			WHERE (Quotes.QuoteID = vQuoteID)
			);
	IF (vPricingPolicyID = 1) -- INC
	then
		SET pTemplatesDir = concat(pTemplatesDir , 'SalesOrderINC.xsl');
	END if;
	IF (vPricingPolicyID = 2) -- LTD 
	then
		SET pTemplatesDir = concat(pTemplatesDir , 'SalesOrderLTD.xsl');
	END if;
	SET vstrXSL = pTemplatesDir;
	-- ---------
	-- Get DrawingID   ,  DrawingRequestID 
	SELECT  IFNULL(vDrawingID, '')
		, IFNULL(DrawingRequests.DrawingRequestID, '')
        INTO vDrawingID,vDrawingRequestID
	FROM Quotes
	INNER JOIN DrawingRequests ON Quotes.QuoteID = DrawingRequests.QuoteID
	INNER JOIN Drawings ON DrawingRequests.DrawingRequestID = Drawings.DrawingRequestID
	WHERE (Quotes.QuoteID = vQuoteID) limit 1;
    call GetQuoteReport(vQuoteID, 2);
    
	-- ----------
	SET vstrQuote = (
			SELECT 
			concat(xml_tag('QuoteID',QuoteID,NULL,NULL),
xml_tag('TheDate',TheDate,NULL,NULL),
xml_tag('ModifyAccountID',ModifyAccountID,NULL,NULL),
xml_tag('ModifyAccountName',ModifyAccountName,NULL,NULL),
xml_tag('CompanyID',CompanyID,NULL,NULL),
xml_tag('Company',Company,NULL,NULL),
xml_tag('CompanyHeader',CompanyHeader,NULL,NULL),
xml_tag('Address',Address,NULL,NULL),
xml_tag('Address2',Address2,NULL,NULL),
xml_tag('City',City,NULL,NULL),
xml_tag('STATE',STATE,NULL,NULL),
xml_tag('Country',Country,NULL,NULL),
xml_tag('Zip',Zip,NULL,NULL),
xml_tag('PhoneNo',PhoneNo,NULL,NULL),
xml_tag('Fax',Fax,NULL,NULL),
xml_tag('Email',Email,NULL,NULL),
xml_tag('AttentionID',AttentionID,NULL,NULL),
xml_tag('Attention',Attention,NULL,NULL),
xml_tag('LastName',LastName,NULL,NULL),
xml_tag('SalesRepID',SalesRepID,NULL,NULL),
xml_tag('SalesRep',SalesRep,NULL,NULL),
xml_tag('LeadOriginID',LeadOriginID,NULL,NULL),
xml_tag('LeadOrigin',LeadOrigin,NULL,NULL),
xml_tag('PurchaseTerritoryID',PurchaseTerritoryID,NULL,NULL),
xml_tag('PurchaseTerritory',PurchaseTerritory,NULL,NULL),
xml_tag('LandingTerritoryID',LandingTerritoryID,NULL,NULL),
xml_tag('LandingTerritory',LandingTerritory,NULL,NULL),
xml_tag('LocationID',LocationID,NULL,NULL),
xml_tag('Location',Location,NULL,NULL),
xml_tag('BuiltCode',BuiltCode,NULL,NULL),
xml_tag('ApplicationID',ApplicationID,NULL,NULL),
xml_tag('Application',Application,NULL,NULL),
xml_tag('PricingPolicyID',PricingPolicyID,NULL,NULL),
xml_tag('PricingPolicy',PricingPolicy,NULL,NULL),
xml_tag('PricingPolicySymbol',PricingPolicySymbol,NULL,NULL),
xml_tag('LeaseTermAID',LeaseTermAID,NULL,NULL),
xml_tag('LeaseTermBID',LeaseTermBID,NULL,NULL),
xml_tag('IsExport',IsExport,NULL,NULL),
xml_tag('IsMiddleEast',IsMiddleEast,NULL,NULL),
xml_tag('QuoteDuration',QuoteDuration,NULL,NULL),
xml_tag('NoOfTechConsultants',NoOfTechConsultants,NULL,NULL),
xml_tag('CompletedByAccountID',CompletedByAccountID,NULL,NULL),
xml_tag('CompletedByAccountName',CompletedByAccountName,NULL,NULL),
xml_tag('CompletedByTitle',CompletedByTitle,NULL,NULL),
xml_tag('CompletedByInitials',CompletedByInitials,NULL,NULL),
xml_tag('CompletedByEmail',CompletedByEmail,NULL,NULL),
xml_tag('TypedByAccountID',TypedByAccountID,NULL,NULL),
xml_tag('TypedByAccountName',TypedByAccountName,NULL,NULL),
xml_tag('Usage',`Usage`,NULL,NULL),
xml_tag('Policies',Policies,NULL,NULL),
xml_tag('Guarantee',Guarantee,NULL,NULL),
xml_tag('InPersonMeeting',InPersonMeeting,NULL,NULL),
xml_tag('MailClient',MailClient,NULL,NULL),
xml_tag('MailRep',MailRep,NULL,NULL),
xml_tag('FaxClient',FaxClient,NULL,NULL),
xml_tag('FaxRep',FaxRep,NULL,NULL),
xml_tag('Brochures',Brochures,NULL,NULL),
xml_tag('StructureID',StructureID,NULL,NULL),
xml_tag('StructureWidth',StructureWidth,NULL,NULL),
xml_tag('StructureLength',StructureLength,NULL,NULL),
xml_tag('Size',Size,NULL,NULL),
xml_tag('StructureSQFT',StructureSQFT,NULL,NULL),
xml_tag('StandardCenterBaySpacing',StandardCenterBaySpacing,NULL,NULL),
xml_tag('StructureStandardLength',StructureStandardLength,NULL,NULL),
xml_tag('StructureStandardSQFT',StructureStandardSQFT,NULL,NULL),
xml_tag('SQFTPerDay',SQFTPerDay,NULL,NULL),
xml_tag('InsulationTypeID',InsulationTypeID,NULL,NULL),
xml_tag('InsulationThicknessID',InsulationThicknessID,NULL,NULL),
xml_tag('MembraneLinerColorID',MembraneLinerColorID,NULL,NULL),
xml_tag('MembraneLinerColor',MembraneLinerColor,NULL,NULL),
xml_tag('MembraneTypeID',MembraneTypeID,NULL,NULL),
xml_tag('MembraneType',MembraneType,NULL,NULL),
xml_tag('FabricTypeID',FabricTypeID,NULL,NULL),
xml_tag('FabricType',FabricType,NULL,NULL),
xml_tag('MembraneColorID',MembraneColorID,NULL,NULL),
xml_tag('MembraneColor',MembraneColor,NULL,NULL),
xml_tag('AnchorageID',AnchorageID,NULL,NULL),
xml_tag('Anchorage',Anchorage,NULL,NULL),
xml_tag('ExposureID',ExposureID,NULL,NULL),
xml_tag('Exposure',Exposure,NULL,NULL),
xml_tag('NoOfCraneBreakPoints',NoOfCraneBreakPoints,NULL,NULL),
xml_tag('WindRate',WindRate,NULL,NULL),
xml_tag('SnowLoad',SnowLoad,NULL,NULL),
xml_tag('IsSnowLoad',IsSnowLoad,NULL,NULL),
xml_tag('SnowLoadExpression',SnowLoadExpression,NULL,NULL),
xml_tag('AluminumBarID',AluminumBarID,NULL,NULL),
xml_tag('StructureCustomLeaseTermAPrice',StructureCustomLeaseTermAPrice,NULL,NULL),
xml_tag('StructureCustomLeaseTermBPrice',StructureCustomLeaseTermBPrice,NULL,NULL),
xml_tag('StructureCustomSalePrice',StructureCustomSalePrice,NULL,NULL),
xml_tag('StructureExtendedLeaseTermAPrice',StructureExtendedLeaseTermAPrice,NULL,NULL),
xml_tag('StructureExtendedLeaseTermBPrice',StructureExtendedLeaseTermBPrice,NULL,NULL),
xml_tag('StructureExtendedSalePrice',StructureExtendedSalePrice,NULL,NULL),
xml_tag('OptionsLeaseTermAPrice',OptionsLeaseTermAPrice,NULL,NULL),
xml_tag('OptionsLeaseTermBPrice',OptionsLeaseTermBPrice,NULL,NULL),
xml_tag('OptionsSalePrice',OptionsSalePrice,NULL,NULL),
xml_tag('TotalLeaseTermAPrice',TotalLeaseTermAPrice,NULL,NULL),
xml_tag('TotalLeaseTermBPrice',TotalLeaseTermBPrice,NULL,NULL),
xml_tag('TotalSalePrice',TotalSalePrice,NULL,NULL),
xml_tag('MonthlyA',MonthlyA,NULL,NULL),
xml_tag('MonthlyB',MonthlyB,NULL,NULL),
xml_tag('WithOrder',WithOrder,NULL,NULL),
xml_tag('FinalTotalLeaseTermAPrice',FinalTotalLeaseTermAPrice,NULL,NULL),
xml_tag('FinalTotalLeaseTermBPrice',FinalTotalLeaseTermBPrice,NULL,NULL),
xml_tag('FinalTotalSalePrice',FinalTotalSalePrice,NULL,NULL),
xml_tag('MonthlyAWord',MonthlyAWord,NULL,NULL),
xml_tag('MonthlyBWord',MonthlyBWord,NULL,NULL),
xml_tag('FinalTotalSalePriceWord',FinalTotalSalePriceWord,NULL,NULL),
xml_tag('TotalManhours',TotalManhours,NULL,NULL),
xml_tag('MenNo',MenNo,NULL,NULL),
xml_tag('DaysNo',DaysNo,NULL,NULL),
xml_tag('CalculatedMenNo',CalculatedMenNo,NULL,NULL),
xml_tag('CalculatedDaysNo',CalculatedDaysNo,NULL,NULL),
xml_tag('CraneSize',CraneSize,NULL,NULL),
xml_tag('CraneHours',CraneHours,NULL,NULL),
xml_tag('ManLifts',ManLifts,NULL,NULL),
xml_tag('FabricContaminationCost',FabricContaminationCost,NULL,NULL),
xml_tag('FrieghtCost',FrieghtCost,NULL,NULL),
xml_tag('TechCost',TechCost,NULL,NULL),
xml_tag('LoadsCount',LoadsCount,NULL,NULL),
xml_tag('ClauseName',ClauseName,NULL,NULL),
xml_tag('DeliveryWording',DeliveryWording,NULL,NULL),
xml_tag('AnchorageWording',AnchorageWording,NULL,NULL),
xml_tag('EngWording',EngWording,NULL,NULL),
xml_tag('FOBClause',FOBClause,NULL,NULL),
xml_tag('OptionClause',OptionClause,NULL,NULL),
xml_tag('OptionClause3',OptionClause3,NULL,NULL),
xml_tag('OptionClause12',OptionClause12,NULL,NULL),
xml_tag('OptionClause24',OptionClause24,NULL,NULL),
xml_tag('OptionClause36',OptionClause36,NULL,NULL),
xml_tag('OptionClause48',OptionClause48,NULL,NULL),
xml_tag('OptionClause60',OptionClause60,NULL,NULL),
xml_tag('TwoMonthlyPeriods',TwoMonthlyPeriods,NULL,NULL),
xml_tag('MoreThanTwoMonthlyPeriods',MoreThanTwoMonthlyPeriods,NULL,NULL),
xml_tag('ExtrasFOBClause',ExtrasFOBClause,NULL,NULL),
xml_tag('AccessoryClause',AccessoryClause,NULL,NULL),
xml_tag('VentilationInsClause',VentilationInsClause,NULL,NULL),
xml_tag('VentilationClause',VentilationClause,NULL,NULL),
xml_tag('CraneLiftingHooks',CraneLiftingHooks,NULL,NULL),
xml_tag('CargoDoorsESDSSD',CargoDoorsESDSSD,NULL,NULL),
xml_tag('OpaqueFabricClause',OpaqueFabricClause,NULL,NULL),
xml_tag('RollingServiceDoorsInAccessoryClause',RollingServiceDoorsInAccessoryClause,NULL,NULL),
xml_tag('LeaseTermA24Clause',LeaseTermA24Clause,NULL,NULL),
xml_tag('LeaseTermB24Clause',LeaseTermB24Clause,NULL,NULL),
xml_tag('CertificateMembraneClause',CertificateMembraneClause,NULL,NULL),
xml_tag('CertificateMembraneText',CertificateMembraneText,NULL,NULL),
xml_tag('CertificateMembraneText1',CertificateMembraneText1,NULL,NULL),
xml_tag('StructureEnvironmentalOrApplication',StructureEnvironmentalOrApplication,NULL,NULL),
xml_tag('ToolClause',ToolClause,NULL,NULL),
xml_tag('EnviroHeading',EnviroHeading,NULL,NULL),
xml_tag('Contamination',Contamination,NULL,NULL),
xml_tag('Contamination1',Contamination1,NULL,NULL),
xml_tag('Contamination2',Contamination2,NULL,NULL),
xml_tag('TechWording',TechWording,NULL,NULL),
xml_tag('TechChargeWording',TechChargeWording,NULL,NULL),
xml_tag('TechnicalConsultantWording',TechnicalConsultantWording,NULL,NULL),
xml_tag('OvertimeWording',OvertimeWording,NULL,NULL),
xml_tag('RollDoorManpower',RollDoorManpower,NULL,NULL),
xml_tag('GuaranteeClause',GuaranteeClause,NULL,NULL),
xml_tag('CraneTitle',CraneTitle,NULL,NULL),
xml_tag('CraneWording',CraneWording,NULL,NULL),
xml_tag('Branch',Branch,NULL,NULL),
xml_tag('LeaseAUnder12Months',LeaseAUnder12Months,NULL,NULL),
xml_tag('LeaseBUnder12Months',LeaseBUnder12Months,NULL,NULL),
xml_tag('ElectricalAccessories',ElectricalAccessories,NULL,NULL),
xml_tag('TerritoryAddress',TerritoryAddress,NULL,NULL),
xml_tag('TerritoryPhone',TerritoryPhone,NULL,NULL),
xml_tag('CreatorTerritory',CreatorTerritory,NULL,NULL),
xml_tag('CompanySignature',CompanySignature,NULL,NULL),
xml_tag('TermsPurchaseClause',TermsPurchaseClause,NULL,NULL),
xml_tag('DeliveryClause',DeliveryClause,NULL,NULL),
xml_tag('AboutSprung',AboutSprung,NULL,NULL),
xml_tag('AccessoriesClausesCombined',AccessoriesClausesCombined,NULL,NULL),
xml_tag('DrawingRequestID',vDrawingRequestID,NULL,NULL),
xml_tag('DrawingID',vDrawingID,NULL,NULL),
xml_tag('InsulationType',(
						SELECT TheValue
						FROM PropertiesValues
						WHERE (PropertyValueID = InsulationTypeID)
						),NULL,NULL),
xml_tag('IsInsulated',(CASE 
					WHEN IsInsulated(InsulationTypeID) = 1
						THEN 'Yes'
					ELSE 'No'
					END),NULL,NULL))
				 
			FROM GetQuoteReport_t
			-- FOR XML PATH('')
			);
            
	SET vstrQuoteItems = GetQuoteItemsReport(vQuoteID, 2);
	SET vstrDoc = spGetSalesOrderReportP1(pSalesOrderID);
            
	SET vstrDoc = concat('<?xml version="1.0" encoding="UTF-8" standalone="no"?>' , '<?xml-stylesheet type="text/xsl" href="' , vstrXSL , '"?>' , '<SalesOrderReport  xmlns="SalesOrderReportNS">' , vstrDoc , vstrQuote , vstrQuoteItems , '</SalesOrderReport>');
	SET vxmlDoc = vstrDoc; -- CAST(vstrDoc AS XML);
	SELECT vstrDoc AS SalesOrderReport
	,vxmlDoc AS SalesOrderReportAsXML
	,vstrXSL AS TemplateFullName;
END;
