CREATE PROCEDURE itcquote.FormatPhoneNumber(IN pInputNumber VARCHAR(25))
  BEGIN
    DECLARE pNumber DECIMAL;
    	--  Declare the return variable here
	DECLARE pFormatted VARCHAR(25); --  Formatted number to return
	DECLARE pCharNum VARCHAR(18); --  Character type of phone number
	DECLARE pExtension INT; --  Phone extesion
	DECLARE pNumerator BIGINT; --  Working number variable
	SET pInputNumber = replace(pInputNumber, '-', '');
	SET pInputNumber = replace(pInputNumber, '(', '');
	SET pInputNumber = replace(pInputNumber, ')', '');
	SET pInputNumber = replace(pInputNumber, ' ', '');
	IF pInputNumber IS NULL 
		OR TRIM(pInputNumber) = ''
	THEN
		-- Just return '' if input string is NULL or empty
		select '';
	END if;
	select pInputNumber;
	SET pNumber = CAST(pInputNumber as DECIMAL);
	select pNumber;
	--  Just enough room, since max phone number
	--  digits is 14 + 4 for extension is 18
	--  Get rid of the decimal
	SET pNumerator = CAST(pNumber * 10000 AS UNSIGNED);
	--  Cast to int to strip off leading zeros
	SET pExtension = CAST(RIGHT(pNumerator, 4) AS SIGNED);
	--  Strip off the extension
	SET pCharNum = CAST(LEFT(pNumerator, length(pNumerator) - 4) AS CHAR(18));
	select pCharNum;
	IF length(pCharNum) = 10 --  Full phone number, return (905) 555-1212
	then
		SET pFormatted = concat('(' , LEFT(pCharNum, 3) , ') ' , SUBSTRING(pCharNum, 4, 3) , '-' , RIGHT(pCharNum, 4));
		IF pExtension > 0 --  Add Extension
		then
			SET pFormatted = concat(pFormatted , ' ext ' , CAST(pExtension AS CHAR(4)));
		END if;
		select pFormatted;
	END if;
	
	IF length(pCharNum) = 7 --  No Area Code, return 555-1212
	then
		SET pFormatted = concat(LEFT(pCharNum, 3) , '-' , RIGHT(pCharNum, 4));
		IF pExtension > 0 --  Add Extension
		then
			SET pFormatted = concat(pFormatted , ' ext ' , CAST(pExtension AS CHAR(6)));
		END if;
		select pFormatted;
	END if;
	IF length(pCharNum) = 11
		--  Full phone number with access code,
		--  return  1 (905) 555-1212  (19055551212)
	then
		SET pFormatted = concat(LEFT(pCharNum, 1) , ' (' , SUBSTRING(pCharNum, 2, 3) , ') ' , SUBSTRING(pCharNum, 4, 3) , '-' , RIGHT(pCharNum, 4));
		IF pExtension > 0 --  Add Extension
		then
			SET pFormatted = concat(pFormatted , ' ext ' , CAST(pExtension AS CHAR(4)));
		END if;
		select pFormatted;
	END if;
	--  Last case, just return the number unformatted (unhandled format)
	SET pFormatted = pCharNum;
	IF pExtension > 0 --  Just the Extension
	then
		SET pFormatted = concat(pFormatted , ' ext ' , CAST(pExtension AS CHAR(4)));
		select concat('ext ' , CAST(pExtension AS CHAR(4)));
	END if;
	select pFormatted;
END;
