CREATE PROCEDURE itcquote.spCopyProductPrices(IN `_SourceProductID` INT, IN `_DestProductID` INT)
  BEGIN
if _SourceProductID =''  or _SourceProductID is null then set _SourceProductID = 0 ;  end if ;
if _DestProductID =''  or _DestProductID is null then set _DestProductID = 0 ;  end if ;
    -- Insert statements for procedure here
  INSERT INTO ProductsPrices
  (ProductID, PricingPolicyID, PricingTypeID, Price)
  SELECT 
  _DestProductID, PricingPolicyID, PricingTypeID, Price
  FROM ProductsPrices
  WHERE (ProductID = _SourceProductID);
end;
