CREATE PROCEDURE itcquote.spGetDrawingRequest_DrawingUnits()
  begin
   call spGetPropertyValues_ByName( 'DrawingRequest_DrawingUnits');
END;
