CREATE FUNCTION itcquote.GetPropertyValues_ByName(pPropertyName VARCHAR(50), pPropertyValueID INT)
  RETURNS VARCHAR(50)
  BEGIN
		DECLARE vResult VARCHAR(50);
		SET vResult = (
				SELECT PropertiesValues.TheValue
				FROM Properties
				INNER JOIN PropertiesValues ON Properties.PropertyID = PropertiesValues.PropertyID
				WHERE (Properties.PropertyName = pPropertyName)
					AND (PropertiesValues.PropertyValueID = pPropertyValueID)
				);
	RETURN vResult;
END;
