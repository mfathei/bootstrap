CREATE FUNCTION itcquote.GetQuoteItemsCount(pQuoteID INT)
  RETURNS INT
  BEGIN
	DECLARE vResult INT;
	DECLARE vQuoteOptionsCount INT;
	DECLARE vQuoteExtrasCount INT;
	-- SET vQuoteOptionsCount = (select count(*) from;
	-- (SELECT 
	--	 IFNULL(QuotesItems.ItemName + QuotesItems.Notes, QuotesItems.ItemName) AS ProductName, 
	--	 IFNULL(QuotesItems.ItemName , ' ') AS ProductNameOnly, 
	--	 CASE FormatQuoteItemQuantity(Products.ProductTypeID, QuotesItems.ProductID, QuotesItems.ItemName, QuotesItems.Quantity) WHEN 99999999 THEN ' ' ELSE CONVERT(varchar(50), QuotesItems.Quantity) END AS Quantity,
	--	 CONVERT(varchar(50), CAST(QuotesItems.CustomLeaseTermAPrice AS money), 1) AS CustomLeaseTermAPrice, 
	--	 CONVERT(varchar(50), CAST(QuotesItems.CustomLeaseTermBPrice AS money), 1) AS CustomLeaseTermBPrice, 
	--	 CONVERT(varchar(50), CAST(QuotesItems.CustomSalePrice AS money), 1) AS CustomSalePrice, 
	--	 CONVERT(varchar(50), CAST(QuotesItems.CustomManhours AS money), 1) AS CustomManhours,
	--	 CONVERT(varchar(50), CAST(QuotesItems.Quantity * QuotesItems.CustomLeaseTermAPrice AS money), 1) AS ExtendedLeaseTermAPrice, 
	--	 CONVERT(varchar(50), CAST(QuotesItems.Quantity * QuotesItems.CustomLeaseTermBPrice AS money), 1) AS ExtendedLeaseTermBPrice, 
	--	 CONVERT(varchar(50), CAST(QuotesItems.Quantity * QuotesItems.CustomSalePrice AS money), 1) AS ExtendedSalePrice, 
	--	 CONVERT(varchar(50), CAST(QuotesItems.Quantity * QuotesItems.CustomManhours AS money), 1) AS ExtendedManhours
	-- FROM QuotesItems 
	-- LEFT OUTER JOIN Products ON QuotesItems.ProductID = Products.ProductID
	-- WHERE (QuotesItems.QuoteID = pQuoteID) AND (QuotesItems.ItemTypeID = 1) AND (QuotesItems.IsDisplayedInReports = 1)
	-- --ORDER BY FormatQuoteItemQuantity(Products.ProductTypeID, QuotesItems.ProductID, QuotesItems.ItemName, QuotesItems.Quantity), QuotesItems.ItemName, QuotesItems.Notes
	-- )as QuoteOptions) 
	SET vQuoteExtrasCount = (
			SELECT count(*)
			FROM (
				SELECT IFNULL(QuotesItems.ItemName, ' ') AS ProductName
					,
					-- IFNULL(QuotesItems.ItemName +' ('+ QuotesItems.Notes +')', QuotesItems.ItemName) AS ProductName,
					CASE FormatQuoteItemQuantity(Products.ProductTypeID, QuotesItems.ProductID, QuotesItems.ItemName, QuotesItems.Quantity)
						WHEN 99999999
							THEN ' '
						ELSE CONVERT( QuotesItems.Quantity, CHAR(50))
						END AS Quantity
					,CONVERT( CAST(QuotesItems.CustomLeaseTermAPrice AS DECIMAL(10, 2)), CHAR(50)) AS CustomLeaseTermAPrice
					,CONVERT( CAST(QuotesItems.CustomLeaseTermBPrice AS DECIMAL(10, 2)), CHAR(50)) AS CustomLeaseTermBPrice
					,CONVERT( CAST(QuotesItems.CustomSalePrice AS DECIMAL(10, 2)), CHAR(50)) AS CustomSalePrice
					,CONVERT( CAST(QuotesItems.CustomManhours AS DECIMAL(10, 2)), CHAR(50)) AS CustomManhours
					,CONVERT( CAST(QuotesItems.Quantity * QuotesItems.CustomLeaseTermAPrice AS DECIMAL(10, 2)), CHAR(50)) AS ExtendedLeaseTermAPrice
					,CONVERT( CAST(QuotesItems.Quantity * QuotesItems.CustomLeaseTermBPrice AS DECIMAL(10, 2)), CHAR(50)) AS ExtendedLeaseTermBPrice
					,CONVERT( CAST(QuotesItems.Quantity * QuotesItems.CustomSalePrice AS DECIMAL(10, 2)), CHAR(50)) AS ExtendedSalePrice
					,CONVERT( CAST(QuotesItems.Quantity * QuotesItems.CustomManhours AS DECIMAL(10, 2)), CHAR(50)) AS ExtendedManhours
				FROM QuotesItems
				LEFT JOIN Products ON QuotesItems.ProductID = Products.ProductID
				WHERE (QuotesItems.QuoteID = pQuoteID)
					AND (QuotesItems.ItemTypeID = 2)
					AND (QuotesItems.IsDisplayedInReports = 1)
					-- ORDER BY FormatQuoteItemQuantity(Products.ProductTypeID, QuotesItems.ProductID, QuotesItems.ItemName, QuotesItems.Quantity), QuotesItems.ItemName, QuotesItems.Notes
				) AS QuoteExtras
			);
	-- --------------------------------------------	  
	-- SET vResult = vQuoteOptionsCount + vQuoteExtrasCount;
	SET vResult = vQuoteExtrasCount;
	RETURN vResult;
END;
