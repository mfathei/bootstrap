CREATE PROCEDURE itcquote.spGetInsulationTypes()
  begin	
call spGetPropertyValues  (54);
END;
