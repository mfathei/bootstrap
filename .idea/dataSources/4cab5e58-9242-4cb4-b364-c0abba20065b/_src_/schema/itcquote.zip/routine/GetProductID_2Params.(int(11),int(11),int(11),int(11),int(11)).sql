CREATE FUNCTION itcquote.GetProductID_2Params(pProductTypeID INT, pPropertyID_01 INT, pPropertyValueID_01 INT,
                                              pPropertyID_02 INT, pPropertyValueID_02 INT)
  RETURNS INT
  BEGIN
	-- Salma: modified in 28-2-2013: added null condition, added like condition
	DECLARE vResult INT;
	DECLARE pQuoteVal1 VARCHAR(255);
	DECLARE pQuoteVal2 VARCHAR(255);
    IF pPropertyValueID_01 IS NULL
    THEN
        SET pPropertyValueID_01 = 0;
    END IF;
    IF pPropertyValueID_02 IS NULL
    THEN
        SET pPropertyValueID_02 = 0;
    END IF;
    
	SET pQuoteVal1 = GetPropertyValue(pPropertyValueID_01);
	SET pQuoteVal2 = GetPropertyValue(pPropertyValueID_02);
    CALL GetWidthRangePropertyValueID_ByWidth(pPropertyValueID_01);
    CALL GetWidthRangePropertyValueID_ByWidth02(pPropertyValueID_02);
    
	SELECT T1.ProductID into vResult
	FROM ProductsPropertiesValues AS T1
	INNER JOIN ProductsPropertiesValues AS T2 ON T1.ProductID = T2.ProductID
	INNER JOIN Properties AS P1 ON P1.PropertyID = T1.PropertyID
	INNER JOIN PropertiesValues AS PV1 ON P1.PropertyID = PV1.PropertyID
	INNER JOIN Properties AS P2 ON P2.PropertyID = T2.PropertyID
	-- Modified by salma on 3-4-2014--  to get producttypeid from product
	-- INNER JOIN PropertiesValues AS PV2 on P2.PropertyID = PV2.PropertyID
	INNER JOIN Products ON Products.ProductID = T1.ProductID
	WHERE (Products.ProductTypeID = pProductTypeID)
		AND
		-- WHERE  (T1.ProductTypeID = pProductTypeID) AND
		(
			(
				(
					(
						--  Salma: Modified in 26-3-2014
						-- (pPropertyID_01 != 101) AND
						(
							(
								(pPropertyValueID_01 IS NOT NULL)
								AND (T1.PropertyValueID = pPropertyValueID_01)
								)
							OR (
								(pPropertyID_01 = 106)
								AND (pPropertyValueID_01 IS NOT NULL)
								AND (T1.PropertyValueID = 502)
								)
							OR --  property value = Other 
							(
								(pPropertyValueID_01 IS NULL)
								AND (T1.PropertyValueID IS NULL)
								)
							OR
							-- -- Salma: Modified in 18-3-2014 added the condition for WidthRange 
							(
								(pPropertyValueID_01 IS NOT NULL)
								AND (
									(pPropertyID_01 = 104)
									AND T1.PropertyValueID IN (
										SELECT *
										FROM GetWidthRangePropertyValueID_ByWidth_t -- GetWidthRangePropertyValueID_ByWidth(pPropertyValueID_01)
										)
									)
								)
							)
						)
					-- OR
					-- ((pPropertyID_01 = 101) AND
					--    (((pPropertyValueID_01 is not null) AND ((pPropertyID_01 = 101) AND ((T1.PropertyID = pPropertyID_01) AND (T1.PropertyValueID = PV1.PropertyValueID) 
					-- AND (pQuoteVal1 like PV2.TheValue , '%'))))) OR 
					-- ((pPropertyValueID_01 is null) AND (T1.PropertyValueID is null))))
					)
				)
			AND (
				(
					(
						-- (pPropertyID_02 != 101) AND
						(
							(
								(pPropertyValueID_02 IS NOT NULL)
								AND (T2.PropertyValueID = pPropertyValueID_02)
								)
							OR (
								(pPropertyID_02 = 106)
								AND (pPropertyValueID_02 IS NOT NULL)
								AND (T2.PropertyValueID = 502)
								)
							OR --  property value = Other 
							(
								(pPropertyValueID_02 IS NULL)
								AND (T2.PropertyValueID IS NULL)
								)
							OR
							-- -- Salma: Modified in 18-3-2014 added the condition for WidthRange 
							(
								(pPropertyValueID_02 IS NOT NULL)
								AND (
									(pPropertyID_02 = 104)
									AND T2.PropertyValueID IN (
										SELECT *
										FROM GetWidthRangePropertyValueID_ByWidth02_t -- GetWidthRangePropertyValueID_ByWidth02(pPropertyValueID_02)
										)
									)
								)
							)
						)
					)
				)
			);
	-- OR
	-- ((pPropertyID_02 = 101) AND
	--    (((pPropertyValueID_02 is not null) AND ((pPropertyID_02 = 101) AND ((T2.PropertyID = pPropertyID_02) AND (T2.PropertyValueID = PV2.PropertyValueID) 
	-- AND (pQuoteVal2 like PV2.TheValue , '%'))))) OR 
	-- ((pPropertyValueID_02 is null) AND (T2.PropertyValueID is null))))
	-- SELECT vResult = Tbl1.ProductID 
	-- FROM(
	-- 		SELECT ProductID, T1.PropertyID, T1.PropertyValueID 
	-- 		FROM ProductsPropertiesValues as T1
	-- 		INNER JOIN Properties on Properties.PropertyID = T1.PropertyID	
	--         INNER JOIN PropertiesValues AS PV on Properties.PropertyID = PV.PropertyID
	-- 		WHERE (ProductTypeID = pProductTypeID) AND (T1.PropertyID = pPropertyID_01) AND 
	-- 		(((pPropertyID_01 != 101) AND
	-- 	    (((pPropertyValueID_01 is not null) AND (T1.PropertyValueID = pPropertyValueID_01)) OR 
	-- 	    ((pPropertyID_01 = 106) AND (pPropertyValueID_01 is not null) AND (T1.PropertyValueID = 502)) OR  --  property value = Other
	-- 		--  if property value id = null (property exists but has no value)
	-- 		((pPropertyValueID_01 is null) AND (T1.PropertyValueID is null)))) OR
	-- 		--  if property = FabricType, then use like instead of equal
	-- 		((pPropertyID_01 = 101) AND
	-- 	    (((pPropertyValueID_01 is not null) AND ((pPropertyID_01 = 101) AND ((T1.PropertyID = pPropertyID_01) AND (T1.PropertyValueID = PV.PropertyValueID) 
	-- 		AND (pQuoteVal1 like PV.TheValue , '%'))))) OR 
	-- 		((pPropertyValueID_01 is null) AND (T1.PropertyValueID is null)))))
	-- 			-- (PropertyValueID = pPropertyValueID_01)	
	-- 			-- (((pPropertyValueID_01 is not null) AND (T1.PropertyValueID = pPropertyValueID_01)) 
	-- 			-- OR ((pPropertyValueID_01 is null) AND (T1.PropertyValueID is null)))
	-- 	) AS Tbl1
	-- INNER JOIN ProductsPropertiesValues AS tbl2 ON Tbl1.ProductID = tbl2.ProductID
	-- INNER JOIN Properties on Properties.PropertyID = tbl2.PropertyID	
	-- INNER JOIN PropertiesValues AS PV on Properties.PropertyID = PV.PropertyID
	-- WHERE (tbl2.PropertyID = pPropertyID_02) AND 
	-- 		-- (tbl2.PropertyValueID = pPropertyValueID_02)	
	-- 	  (((pPropertyID_02 != 101) AND
	-- 	  (((pPropertyValueID_02 is not null) AND (tbl2.PropertyValueID = pPropertyValueID_02)) OR 
	-- 	    ((pPropertyID_02 = 106) AND (pPropertyValueID_02 is not null) AND (tbl2.PropertyValueID = 502)) OR  --  property value = Other
	-- 		((pPropertyValueID_02 is null) AND (tbl2.PropertyValueID is null)))) OR
	-- 		((pPropertyID_02 = 101) AND
	-- 	  (((pPropertyValueID_02 is not null) AND ((pPropertyID_02 = 101) AND ((tbl2.PropertyID = pPropertyID_02) AND (tbl2.PropertyValueID = PV.PropertyValueID) 
	-- 		AND (pQuoteVal2 like PV.TheValue , '%'))))) OR 
	-- 		((pPropertyValueID_02 is null) AND (tbl2.PropertyValueID is null)))))
	RETURN IFNULL(vResult, 0);
END;
