CREATE PROCEDURE itcquote.spGetAccountContactsWithNoBDM(IN `_AccountID` INT, IN `_TerritoryID` INT, IN `_BDMID` INT)
  BEGIN
	SELECT Contacts.ContactID
		,Contacts.ContactName
		,Contacts.ContactTypeID
		,Contacts.CreateDate
		,Contacts.CreateAccountID
		,Contacts.ScopeID
		,ContactsTypes.ContactTypeName
		,Scopes.ScopeName
		,Contacts.CompanyID
	FROM Contacts
	LEFT  JOIN ContactsTypes ON Contacts.ContactTypeID = ContactsTypes.ContactTypeID
	LEFT  JOIN Scopes ON Contacts.ScopeID = Scopes.ScopeID
	WHERE (
			(
				(Contacts.ScopeID = 1)
				AND (Contacts.CreateAccountID = _AccountID)
				)
			OR (
				(Contacts.ScopeID = 2)
				AND (
					Contacts.CreateAccountID IN (
						SELECT AccountID
						FROM Accounts
						WHERE (TerritoryID = _TerritoryID)
						)
					)
				)
			OR (Contacts.ScopeID = 3)
			OR (
				_AccountID IN (
					SELECT AccountID
					FROM Accounts
					WHERE IsAdmin = 1
					)
				)
			)
		AND (
			(
				(
					ContactID NOT IN (
						SELECT ContactID
						FROM DevelopmentManagers
						WHERE ContactID IS NOT NULL
						)
					AND Contacts.IsActive = 1
					)
				OR (
					_BDMID IS NOT NULL
					AND (
						ContactID IN (
							SELECT ContactID
							FROM DevelopmentManagers
							WHERE ContactID IS NOT NULL
								AND ManagerID = @BDMID
							)
						)
					)
				)
			)
		AND (
			Contacts.ContactTypeID = 8
			OR Contacts.ContactTypeID = 9
			) 
	ORDER BY ContactName ;
end;
