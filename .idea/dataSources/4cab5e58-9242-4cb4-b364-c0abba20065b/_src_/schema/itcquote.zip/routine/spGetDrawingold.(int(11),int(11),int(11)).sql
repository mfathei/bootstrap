CREATE PROCEDURE itcquote.spGetDrawingold(IN `_DrawID` INT, IN `_AccountID` INT, IN `_TerritoryID` INT)
  BEGIN
	IF (_DrawID != 0)
	then
		SELECT Drawings.DrawingID
			,Drawings.ScopeID
			,Drawings.CreateAccountID
			,Drawings.CreateDate
			,Drawings.ModifyAccountID
			,Drawings.ModifyDate
			,Drawings.DrawingRequestID
			,Drawings.DrawnByID
			,Drawings.ExpectedDate
			,Drawings.ActualDate
			,Drawings.DrawingTypeID
			,Drawings.StatusID
			,Drawings.Caption
			,Drawings.Comments
		FROM Accounts
		INNER JOIN Contacts ON Accounts.AccountID = Contacts.CreateAccountID
			AND Accounts.AccountID = Contacts.ModifyAccountID
		INNER JOIN Drawings ON Accounts.AccountID = Drawings.CreateAccountID
		WHERE (Drawings.DrawingRequestID = _DrawID)
			AND (Contacts.ScopeID = 1)
			OR (Drawings.DrawingRequestID = _DrawID)
			AND (Contacts.ScopeID = 2)
			OR (Drawings.DrawingRequestID = _DrawID)
			AND (Contacts.ScopeID = 3)
		GROUP BY Drawings.DrawingID
			,Drawings.CreateAccountID
			,Drawings.ScopeID
			,Drawings.CreateDate
			,Drawings.ModifyAccountID
			,Drawings.ModifyDate
			,Drawings.DrawingRequestID
			,Drawings.DrawnByID
			,Drawings.ExpectedDate
			,Drawings.ActualDate
			,Drawings.DrawingTypeID
			,Drawings.StatusID
			,Drawings.Caption
			,Drawings.Comments
		HAVING (Drawings.DrawingRequestID = _DrawID)
			AND (Drawings.CreateAccountID = _AccountID)
			OR (
				Drawings.CreateAccountID IN (
					SELECT AccountID
					FROM Accounts AS Accounts_1
					WHERE (TerritoryID = -TerritoryID)
					)
				);
	
	ELSE
	
		SELECT Drawings.DrawingID
			,Drawings.ScopeID
			,Drawings.CreateAccountID
			,Drawings.CreateDate
			,Drawings.ModifyAccountID
			,Drawings.ModifyDate
			,Drawings.DrawingRequestID
			,Drawings.DrawnByID
			,Drawings.ExpectedDate
			,Drawings.ActualDate
			,Drawings.DrawingTypeID
			,Drawings.StatusID
			,Drawings.Caption
			,Drawings.Comments
		FROM Contacts
		INNER JOIN Drawings ON Contacts.CreateAccountID = Drawings.CreateAccountID
			AND Contacts.ModifyAccountID = Drawings.ModifyAccountID
		WHERE (Contacts.ScopeID = 1)
			OR (Contacts.ScopeID = 2)
			OR (Contacts.ScopeID = 3)
		GROUP BY Drawings.DrawingID
			,Drawings.CreateAccountID
			,Drawings.CreateDate
			,Drawings.ScopeID
			,Drawings.ModifyAccountID
			,Drawings.ModifyDate
			,Drawings.DrawingRequestID
			,Drawings.DrawnByID
			,Drawings.ExpectedDate
			,Drawings.ActualDate
			,Drawings.DrawingTypeID
			,Drawings.StatusID
			,Drawings.Caption
			,Drawings.Comments
		HAVING (Drawings.CreateAccountID = _AccountID)
			OR (
				Drawings.CreateAccountID IN (
					SELECT AccountID
					FROM Accounts AS Accounts_1
					WHERE (TerritoryID = _TerritoryID)
					)
				);
	
END if;
END;
