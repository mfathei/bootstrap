CREATE PROCEDURE itcquote.spInsertQuoteItemCustom(IN `_QuoteID`         INT, IN `_ProductID` INT,
                                                  IN `_ItemName`        VARCHAR(200), IN `_ItemTypeID` INT,
                                                  IN `_IsAutoAdded`     BIT, IN `_IsDisplayedInReports` BIT,
                                                  IN `_Quantity`        FLOAT, IN `_SalePrice` DECIMAL(19, 11),
                                                  IN `_LeaseTermAPrice` DECIMAL(19, 11),
                                                  IN `_LeaseTermBPrice` DECIMAL(19, 11), IN `_Manhours` FLOAT,
                                                  IN `_Notes`           VARCHAR(100))
  BEGIN
	
	/*IF _ItemName = '' RETURN
	IF _Quantity <= 0 RETURN*/
    sp_lapel:loop
    IF _ItemName = '' or _Quantity <= 0
    then leave sp_lapel;
    end if;
    end loop;
    
	DELETE from QuotesItems WHERE (QuoteID = _QuoteID) AND (ItemName = _ItemName);
	INSERT INTO QuotesItems(
	QuoteID, 
	ProductID, 
	ItemName,
	ItemTypeID, 
	IsAutoAdded, 
	IsDisplayedInReports, 
	Quantity, 
	OriginalSalePrice, 
	OriginalLeaseTermAPrice, 
	OriginalLeaseTermBPrice, 
	OriginalManhours, 
	CustomSalePrice, 
	CustomLeaseTermAPrice, 
	CustomLeaseTermBPrice, 
	CustomManhours, 
	Notes
	-- Salma modified in 14-7-2015 --added the condition for special name
	,HasSpecialName
	
	)
	VALUES (
	_QuoteID, 
	_ProductID, 
	_ItemName, 
	_ItemTypeID, 
	_IsAutoAdded, 
	_IsDisplayedInReports, 
	_Quantity, 
	_SalePrice, 
	_LeaseTermAPrice, 
	_LeaseTermBPrice, 
	_Manhours,
	_SalePrice, 
	_LeaseTermAPrice, 
	_LeaseTermBPrice, 
	_Manhours, 
	_Notes
	-- Salma modified in 14-7-2015 --added the condition for special name
	,1
	);
end;
