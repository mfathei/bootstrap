CREATE PROCEDURE itcquote.fnNTextToIntTable_test(IN `_Data` LONGTEXT, IN fnNTextToIntTable_t VARCHAR(200))
  begin
 DECLARE _Ptr , _Length int;
 declare _v nchar; 
 declare _vv nvarchar(10);
DROP TEMPORARY TABLE IF EXISTS fnNTextToIntTable_t;
CREATE TEMPORARY TABLE fnNTextToIntTable_t(Value INT NULL);
    select  (LENGTH(_Data) / 2) + 1, 1   into _Length ,_Ptr;
      WHILE (_Ptr < _Length)
    do 
        SET _v = SUBSTRING(@Data, @Ptr, 1);
        IF _v = ','
        then
        
	       INSERT INTO fnNTextToIntTable_t(`Value`)VALUES (CAST(_vv AS signed));   
		   SET _vv = NULL;
        ELSE
            SET _vv = concat(ifnull(_vv, '') , _v);
        END if;
        SET _Ptr = _Ptr + 1;
    END while;
      IF _vv IS NOT NULL
      
      then
          INSERT INTO fnNTextToIntTable_t(`Value`)VALUES (CAST(_vv AS signed));    
	  end if;
end;
