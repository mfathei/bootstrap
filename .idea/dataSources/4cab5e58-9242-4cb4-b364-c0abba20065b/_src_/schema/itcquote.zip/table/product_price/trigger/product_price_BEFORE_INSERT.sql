CREATE TRIGGER itcquote.product_price_BEFORE_INSERT
BEFORE INSERT ON itcquote.product_price
FOR EACH ROW
  BEGIN
	set NEW.id_for_view = MyUUID();
END;
