CREATE TRIGGER itcquote.product_AINS
AFTER INSERT ON itcquote.product
FOR EACH ROW
  begin
	set @ptype = NEW.product_type_id;
	if (@ptype is not null) then
		INSERT INTO product_property_value (product_id, product_type_id, property_id)
		SELECT P.product_id, P.product_type_id, PTP.property_id FROM product P 
		INNER JOIN product_type PT ON P.product_type_id = PT.product_type_id
		INNER JOIN product_type_property PTP ON PT.product_type_id = PTP.product_type_id
		WHERE (P.product_id = NEW.product_id);
	end if;
end;
