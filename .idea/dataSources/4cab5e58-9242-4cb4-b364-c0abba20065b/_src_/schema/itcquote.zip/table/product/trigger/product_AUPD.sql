CREATE TRIGGER itcquote.product_AUPD
AFTER UPDATE ON itcquote.product
FOR EACH ROW
  begin
	if (NEW.product_type_id <> OLD.product_type_id) then
		delete from product_property_value where product_id = NEW.product_id;
		INSERT INTO product_property_value (product_id, product_type_id, property_id)
		SELECT P.product_id, P.product_type_id, PTP.property_id FROM product P 
		INNER JOIN product_type PT ON P.product_type_id = PT.product_type_id
		INNER JOIN product_type_property PTP ON PT.product_type_id = PTP.product_type_id
		WHERE (P.product_id = NEW.product_id);
	end if;
end;
