CREATE VIEW itcquote.quotecustomers_grid AS
  SELECT
    `qc`.`customer_id`                               AS `customer_id`,
    `qc`.`customer_name`                             AS `customer_name`,
    `s`.`scope_name`                                 AS `scope_name`,
    `t`.`territory_name`                             AS `territory_name`,
    `qo`.`contact_id`                                AS `contact_id`,
    concat(`qo`.`first_name`, ' ', `qo`.`last_name`) AS `contcat_name`,
    (SELECT `itcquote`.`quotecontact_phone`.`phone_text`
     FROM `itcquote`.`quotecontact_phone`
     WHERE ((`itcquote`.`quotecontact_phone`.`contact_id` = `qo`.`contact_id`) AND
            (`itcquote`.`quotecontact_phone`.`is_main` = 1))
     LIMIT 1)                                        AS `contact_phone`,
    (SELECT `itcquote`.`quotecontact_email`.`email_text`
     FROM `itcquote`.`quotecontact_email`
     WHERE ((`itcquote`.`quotecontact_email`.`contact_id` = `qo`.`contact_id`) AND
            (`itcquote`.`quotecontact_email`.`is_main` = 1))
     LIMIT 1)                                        AS `contact_email`
  FROM (((`itcquote`.`quote_customer` `qc`
    JOIN `itcquote`.`quotecustomer_contact` `qo` ON ((`qc`.`customer_id` = `qo`.`customer_id`))) JOIN
    `itcquote`.`scope` `s` ON ((`s`.`scope_id` = `qc`.`scope_id`))) JOIN `common`.`territory` `t`
      ON ((`t`.`territory_id` = `qc`.`territory_id`)))
  WHERE (`qo`.`is_main` = 1)
  ORDER BY `qc`.`customer_name`;
