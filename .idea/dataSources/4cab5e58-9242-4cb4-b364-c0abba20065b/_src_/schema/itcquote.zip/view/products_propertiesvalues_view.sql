CREATE VIEW itcquote.products_propertiesvalues_view AS
  SELECT
    `itcquote`.`product`.`product_name`     AS `ProductName`,
    `itcquote`.`property`.`property_name`   AS `PropertyName`,
    `itcquote`.`property_value`.`the_value` AS `TheValue`
  FROM (((`itcquote`.`product_property_value`
    JOIN `itcquote`.`product`
      ON ((`itcquote`.`product`.`product_id` = `itcquote`.`product_property_value`.`product_id`))) JOIN
    `itcquote`.`property`
      ON ((`itcquote`.`property`.`property_id` = `itcquote`.`product_property_value`.`property_id`))) JOIN
    `itcquote`.`property_value`
      ON (((`itcquote`.`property_value`.`property_value_id` = `itcquote`.`product_property_value`.`property_value_id`)
           AND (`itcquote`.`property_value`.`property_id` = `itcquote`.`product_property_value`.`property_id`))))
  ORDER BY `itcquote`.`product`.`product_name`, `itcquote`.`property`.`property_name`
  LIMIT 10000;
