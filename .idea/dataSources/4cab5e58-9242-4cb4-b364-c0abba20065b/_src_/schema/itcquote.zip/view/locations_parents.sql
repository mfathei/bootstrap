CREATE VIEW itcquote.locations_parents AS
  SELECT
    `itcquote`.`location`.`location_id`                          AS `location_id`,
    `getAllLocationParents`(`itcquote`.`location`.`location_id`) AS `parents`
  FROM `itcquote`.`location`;
