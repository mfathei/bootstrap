CREATE VIEW itcquote.productstypes_properties_view AS
  SELECT
    `itcquote`.`product_type`.`product_type_name` AS `product_type_name`,
    `itcquote`.`property`.`property_name`         AS `PropertyName`
  FROM ((`itcquote`.`product_type_property`
    JOIN `itcquote`.`property`
      ON ((`itcquote`.`product_type_property`.`property_id` = `itcquote`.`property`.`property_id`))) JOIN
    `itcquote`.`product_type`
      ON ((`itcquote`.`product_type_property`.`product_type_id` = `itcquote`.`product_type`.`product_type_id`)))
  ORDER BY `itcquote`.`product_type`.`product_type_name`, `itcquote`.`property`.`property_name`;
