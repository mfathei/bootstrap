CREATE VIEW itcquote.applications_parents AS
  SELECT
    `itcquote`.`application`.`application_id`                             AS `application_id`,
    `getAllApplicationParents`(`itcquote`.`application`.`application_id`) AS `parents`
  FROM `itcquote`.`application`;
