CREATE VIEW itcquote.products_parents AS
  SELECT
    `itcquote`.`product`.`product_id`                  AS `product_id`,
    `getAllParents`(`itcquote`.`product`.`product_id`) AS `parents`
  FROM `itcquote`.`product`;
