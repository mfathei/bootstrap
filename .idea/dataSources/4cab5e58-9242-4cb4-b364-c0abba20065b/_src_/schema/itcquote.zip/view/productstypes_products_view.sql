CREATE VIEW itcquote.productstypes_products_view AS
  SELECT
    `itcquote`.`product_type`.`product_type_name` AS `ProductTypeName`,
    `itcquote`.`product`.`product_name`           AS `ProductName`,
    `itcquote`.`product`.`product_id`             AS `ProductID`,
    `itcquote`.`product`.`parent_id`              AS `ParentID`,
    `itcquote`.`product`.`sort_order`             AS `SortOrder`,
    `itcquote`.`product`.`is_visible`             AS `IsVisible`
  FROM (`itcquote`.`product`
    JOIN `itcquote`.`product_type`
      ON ((`itcquote`.`product`.`product_type_id` = `itcquote`.`product_type`.`product_type_id`)))
  WHERE (`itcquote`.`product`.`is_visible` = 1)
  ORDER BY `itcquote`.`product_type`.`product_type_name`, `itcquote`.`product`.`parent_id`,
    `itcquote`.`product`.`sort_order`;
