CREATE VIEW itcquote.quotes_view AS
  SELECT
    `itcquote`.`quote`.`quote_id`                                    AS `QuoteID`,
    `itcquote`.`quote`.`title`                                       AS `Title`,
    `itcquote`.`quote`.`code`                                        AS `Code`,
    `itcquote`.`quote`.`create_date`                                 AS `CreateDate`,
    `itcquote`.`quote`.`modify_date`                                 AS `ModifyDate`,
    `itcquote`.`scope`.`scope_name`                                  AS `ScopeName`,
    `common`.`contact`.`contact_name`                                AS `ContactName`,
    `itcquote`.`quote`.`quote_duration`                              AS `QuoteDuration`,
    `itcquote`.`territory`.`territory_name`                          AS `TerritoryName`,
    `prerpared`.`contact_name`                                       AS `PreparedBy`,
    concat(ifnull(`itcquote`.`development_manager`.`first_name`, ''), ' ',
           ifnull(`itcquote`.`development_manager`.`last_name`, '')) AS `CompletedFor`
  FROM ((((((`itcquote`.`quote`
    LEFT JOIN `common`.`contact` ON (((`itcquote`.`quote`.`company_id` = `common`.`contact`.`contact_id`) AND
                                      (`common`.`contact`.`contact_type_id` = 1)))) LEFT JOIN `common`.`account`
      ON ((`itcquote`.`quote`.`create_account_id` = `common`.`account`.`account_id`))) LEFT JOIN `itcquote`.`territory`
      ON ((`common`.`account`.`territory_id` = `itcquote`.`territory`.`territory_id`))) LEFT JOIN
    `common`.`contact` `prerpared` ON ((`common`.`account`.`contact_id` = `prerpared`.`contact_id`))) LEFT JOIN
    `itcquote`.`development_manager`
      ON ((`itcquote`.`quote`.`completed_by_account_id` = `itcquote`.`development_manager`.`manager_id`))) LEFT JOIN
    `itcquote`.`scope` ON ((`itcquote`.`quote`.`scope_id` = `itcquote`.`scope`.`scope_id`)));
