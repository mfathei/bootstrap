CREATE VIEW SafetyPass.vwcategorycertificate AS
  SELECT
    `CA`.`CategoryDefaultName` AS `CategoryDefaultName`,
    `OC`.`OrgId`               AS `OrgId`,
    `OC`.`CertificateId`       AS `CertificateId`,
    `C`.`CertificateName`      AS `CertificateName`,
    `CA`.`CategoryId`          AS `CategoryId`
  FROM ((`safetypass`.`orgcategorycert` `OC`
    JOIN `safetypass`.`category` `CA` ON ((`OC`.`CategoryId` = `CA`.`CategoryId`))) JOIN `safetypass`.`certificate` `C`
      ON ((`OC`.`CertificateId` = `C`.`CertificateId`)));
