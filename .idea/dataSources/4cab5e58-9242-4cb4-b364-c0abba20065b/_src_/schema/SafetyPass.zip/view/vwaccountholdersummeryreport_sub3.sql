CREATE VIEW SafetyPass.vwaccountholdersummeryreport_sub3 AS
  SELECT
    `safetypass`.`training`.`AccountholderId`                                       AS `AccountholderId`,
    coalesce(count(nullif(isnull(`safetypass`.`training`.`VerifiedById`), 'f')), 0) AS `total_verified_skills`,
    count(
        nullif(((`safetypass`.`training`.`ExpiryDate` < curdate()) AND isnull(`safetypass`.`training`.`VerifiedById`)),
               'f'))                                                                AS `verified_expired_skills`,
    count(nullif(((`safetypass`.`training`.`ExpiryDate` BETWEEN curdate() AND (curdate() + INTERVAL 90 DAY)) AND
                  isnull(`safetypass`.`training`.`VerifiedById`)), 'f'))            AS `verified_expiring_skills`,
    count(nullif((`safetypass`.`training`.`VerifiedById` IS NOT NULL), 'f'))        AS `total_unverified_skills`,
    count(nullif(((`safetypass`.`training`.`ExpiryDate` < curdate()) AND
                  (`safetypass`.`training`.`VerifiedById` IS NOT NULL)), 'f'))      AS `unverified_expired_skills`,
    count(nullif(((`safetypass`.`training`.`ExpiryDate` BETWEEN curdate() AND (curdate() + INTERVAL 90 DAY)) AND
                  (`safetypass`.`training`.`VerifiedById` IS NOT NULL)), 'f'))      AS `unverified_expiring_skills`
  FROM `safetypass`.`training`
  GROUP BY `safetypass`.`training`.`AccountholderId`;
