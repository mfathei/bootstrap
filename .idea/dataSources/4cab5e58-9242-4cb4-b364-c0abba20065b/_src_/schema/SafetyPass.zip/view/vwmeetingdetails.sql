CREATE VIEW SafetyPass.vwmeetingdetails AS
  SELECT
    `sm`.`SafetyMeetingId`   AS `SafetyMeetingId`,
    `smu`.`AccountholderId`  AS `AccountholderId`,
    `sm`.`MeetingTitle`      AS `MeetingTitle`,
    `sm`.`MeetingDate`       AS `MeetingDate`,
    `sm`.`MeetingSupervisor` AS `MeetingSupervisor`,
    `l`.`LocationName`       AS `LocationName`,
    `l`.`OrgId`              AS `OrgId`
  FROM ((`safetypass`.`safetymeeting` `sm`
    JOIN `safetypass`.`safetymeetinguser` `smu` ON ((`sm`.`SafetyMeetingId` = `smu`.`SafetyMeetingId`))) JOIN
    `safetypass`.`location` `l` ON ((`l`.`LocationId` = `sm`.`LocationId`)));
