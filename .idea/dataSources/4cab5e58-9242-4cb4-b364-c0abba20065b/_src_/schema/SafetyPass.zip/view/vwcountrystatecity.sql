CREATE VIEW SafetyPass.vwcountrystatecity AS
  SELECT
    `common_safetypass`.`city`.`CityId`         AS `CityID`,
    `common_safetypass`.`city`.`CityName`       AS `CityName`,
    `common_safetypass`.`state`.`StateId`       AS `StateId`,
    `common_safetypass`.`state`.`StateName`     AS `StateName`,
    `common_safetypass`.`state`.`StateISO`      AS `StateISO`,
    `common_safetypass`.`country`.`CountryId`   AS `CountryId`,
    `common_safetypass`.`country`.`CountryCode` AS `CountryCode`,
    `common_safetypass`.`country`.`CountryName` AS `CountryName`,
    `common_safetypass`.`country`.`CountryISO`  AS `CountryISO`
  FROM ((`common_safetypass`.`city`
    LEFT JOIN `common_safetypass`.`state`
      ON ((`common_safetypass`.`city`.`StateId` = `common_safetypass`.`state`.`StateId`))) LEFT JOIN
    `common_safetypass`.`country`
      ON ((`common_safetypass`.`country`.`CountryId` = `common_safetypass`.`state`.`CountryId`)));
