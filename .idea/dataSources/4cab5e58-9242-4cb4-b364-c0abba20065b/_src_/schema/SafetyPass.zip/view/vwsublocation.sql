CREATE VIEW SafetyPass.vwsublocation AS
  SELECT
    `SL`.`SubLocationId`   AS `SubLocationId`,
    `SL`.`LocationId`      AS `LocationId`,
    `SL`.`SubLocationName` AS `SubLocationName`,
    `SL`.`CreatedAt`       AS `CreatedAt`,
    `LO`.`LocationName`    AS `LocationName`,
    `LO`.`OrgId`           AS `OrgId`
  FROM (`safetypass`.`sublocation` `SL`
    JOIN `safetypass`.`location` `LO` ON ((`SL`.`LocationId` = `LO`.`LocationId`)));
