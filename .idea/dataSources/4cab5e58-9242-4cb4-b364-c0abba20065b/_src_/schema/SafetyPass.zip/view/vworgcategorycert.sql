CREATE VIEW SafetyPass.vworgcategorycert AS
  SELECT
    `tbl1`.`CertificateId`   AS `CertificateId`,
    `tbl2`.`CertificateName` AS `CertificateName`,
    `tbl1`.`CategoryId`      AS `CategoryId`,
    `tbl1`.`CategoryName`    AS `CategoryName`,
    `tbl1`.`OrgId`           AS `OrgId`,
    `tbl4`.`LegalName`       AS `LegalName`
  FROM (((`safetypass`.`orgcategorycert` `tbl1`
    JOIN `safetypass`.`certificate` `tbl2` ON ((`tbl1`.`CertificateId` = `tbl2`.`CertificateId`))) JOIN
    `safetypass`.`category` `tbl3` ON ((`tbl1`.`CategoryId` = `tbl3`.`CategoryId`))) JOIN
    `safetypass`.`organization` `tbl4` ON ((`tbl1`.`OrgId` = `tbl4`.`OrgId`)));
