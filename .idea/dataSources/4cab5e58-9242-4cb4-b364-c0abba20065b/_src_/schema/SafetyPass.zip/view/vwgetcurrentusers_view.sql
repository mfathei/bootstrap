CREATE VIEW SafetyPass.vwgetcurrentusers_view AS
  SELECT
    `safetypass`.`swiping`.`SwipeId`                                                 AS `recordId`,
    `safetypass`.`accountholder`.`CardNumber`                                        AS `userCard`,
    `safetypass`.`swiping`.`SwipInTime`                                              AS `startTime`,
    `safetypass`.`swiping`.`SwipOutTime`                                             AS `endTime`,
    `safetypass`.`accountholder`.`FName`                                             AS `userFname`,
    `safetypass`.`accountholder`.`LName`                                             AS `userLname`,
    `safetypass`.`organization`.`PresentationName`                                   AS `userOrganization`,
    `eorg`.`PresentationName`                                                        AS `equipmentOrganization`,
    `safetypass`.`swiping`.`IsOperator`                                              AS `userType`,
    `safetypass`.`accountholder`.`ExpiryDate`                                        AS `expiry_date`,
    (CASE WHEN (`safetypass`.`accountholder`.`ExpiryDate` > curdate())
      THEN 1
     ELSE 0 END)                                                                     AS `card_expired`,
    `safetypass`.`accountholder`.`AccountholderId`                                   AS `accountholder_id`,
    `safetypass`.`blacklist`.`BlacklistId`                                           AS `id`,
    `GATEMISSEDCERTSCOMMASEPARATED`(`safetypass`.`swiping`.`LocationId`,
                                    `safetypass`.`accountholder`.`AccountholderId`)  AS `missing`,
    `GATEEXPIREDCERTSCOMMASEPARATED`(`safetypass`.`swiping`.`LocationId`,
                                     `safetypass`.`accountholder`.`AccountholderId`) AS `expired`,
    `safetypass`.`swiping`.`LocationId`                                              AS `location_id`,
    `safetypass`.`location`.`MaxStayingMinute`                                       AS `MaxStayingMinute`,
    `safetypass`.`swiping`.`SwipeType`                                               AS `SwipeType`,
    `safetypass`.`accountholder`.`AreaId`                                            AS `AreaId`,
    `safetypass`.`equipment`.`EquipmentId`                                           AS `equipment_id`,
    `safetypass`.`equipment`.`CardNumber`                                            AS `CardNumber`,
    `safetypass`.`equipment`.`EquipmentName`                                         AS `equipmentName`,
    `safetypass`.`equipment`.`EquipmentCode`                                         AS `EquipmentCode`,
    `safetypass`.`equipment`.`SerialNumber`                                          AS `SerialNumber`,
    `safetypass`.`equipment`.`Manufacturer`                                          AS `Manufacturer`,
    `safetypass`.`equipment`.`ModelNumber`                                           AS `ModelNumber`,
    `safetypass`.`equipment`.`OwnerOrganization`                                     AS `OwnerOrganization`,
    `safetypass`.`equipment`.`InstallationDate`                                      AS `InstallationDate`,
    `safetypass`.`equipment`.`EquipmentDescription`                                  AS `EquipmentDescription`,
    `safetypass`.`equipment`.`InspectionDate`                                        AS `InspectionDate`,
    `safetypass`.`equipment`.`EquipmentImage`                                        AS `EquipmentImage`,
    `safetypass`.`equipment`.`last_update`                                           AS `last_update`
  FROM ((((((`safetypass`.`swiping`
    LEFT JOIN `safetypass`.`location`
      ON ((`safetypass`.`swiping`.`LocationId` = `safetypass`.`location`.`LocationId`))) LEFT JOIN
    `safetypass`.`accountholder`
      ON ((`safetypass`.`swiping`.`AccountholderId` = `safetypass`.`accountholder`.`AccountholderId`))) LEFT JOIN
    `safetypass`.`equipment`
      ON ((`safetypass`.`swiping`.`EquipmentId` = `safetypass`.`equipment`.`EquipmentId`))) LEFT JOIN
    `safetypass`.`organization` `eorg` ON ((`safetypass`.`equipment`.`OwnerOrganization` = `eorg`.`OrgId`))) LEFT JOIN
    `safetypass`.`organization`
      ON ((`safetypass`.`accountholder`.`OrgId` = `safetypass`.`organization`.`OrgId`))) LEFT JOIN
    `safetypass`.`blacklist`
      ON (((`safetypass`.`blacklist`.`AccountholderId` = `safetypass`.`accountholder`.`AccountholderId`) AND
           (`safetypass`.`blacklist`.`LocationId` = `safetypass`.`swiping`.`LocationId`))));
