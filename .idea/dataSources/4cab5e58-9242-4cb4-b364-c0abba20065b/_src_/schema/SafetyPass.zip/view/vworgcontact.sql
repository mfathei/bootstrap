CREATE VIEW SafetyPass.vworgcontact AS
  SELECT
    `oc`.`OrgContactId`      AS `OrgContactId`,
    `oc`.`OrgId`             AS `OrgId`,
    `org`.`LegalName`        AS `LegalName`,
    `org`.`PresentationName` AS `PresentationName`,
    `org`.`PresentationLogo` AS `PresentationLogo`,
    `org`.`Fax`              AS `OrgFax`,
    `org`.`Phone`            AS `OrgPhone`,
    `org`.`OrganizationType` AS `OrganizationType`,
    `org`.`ParentOrgId`      AS `ParentOrgId`,
    `oc`.`Street`            AS `Street`,
    `oc`.`CityId`            AS `CityId`,
    `ci`.`CityName`          AS `CityName`,
    `st`.`StateId`           AS `StateId`,
    `st`.`StateName`         AS `StateName`,
    `st`.`StateISO`          AS `StateISO`,
    `co`.`CountryId`         AS `CountryId`,
    `co`.`CountryName`       AS `CountryName`,
    `co`.`CountryCode`       AS `CountryCode`,
    `co`.`CountryISO`        AS `CountryISO`,
    `oc`.`PostalCode`        AS `PostalCode`,
    `oc`.`Phone`             AS `Phone`,
    `oc`.`Fax`               AS `Fax`,
    `oc`.`ContactTypeId`     AS `ContactTypeId`,
    `ct`.`ContactTypeName`   AS `ContactTypeName`
  FROM (((((`safetypass`.`orgcontact` `oc`
    JOIN `safetypass`.`organization` `org` ON ((`oc`.`OrgId` = `org`.`OrgId`))) JOIN
    `common_safetypass`.`contacttype` `ct` ON ((`oc`.`ContactTypeId` = `ct`.`ContactTypeId`))) JOIN
    `common_safetypass`.`city` `ci` ON ((`oc`.`CityId` = `ci`.`CityId`))) JOIN `common_safetypass`.`state` `st`
      ON ((`ci`.`StateId` = `st`.`StateId`))) JOIN `common_safetypass`.`country` `co`
      ON ((`st`.`CountryId` = `co`.`CountryId`)));
