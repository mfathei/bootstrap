CREATE VIEW SafetyPass.vwmeetingguestdetails AS
  SELECT
    `sm`.`SafetyMeetingId`   AS `SafetyMeetingId`,
    NULL                     AS `AccountholderId`,
    `sm`.`MeetingTitle`      AS `MeetingTitle`,
    `sm`.`MeetingDate`       AS `MeetingDate`,
    `sm`.`MeetingSupervisor` AS `MeetingSupervisor`,
    `l`.`LocationName`       AS `LocationName`,
    `l`.`OrgId`              AS `OrgId`
  FROM ((`safetypass`.`safetymeeting` `sm`
    JOIN `safetypass`.`safetymeetingguest` `smu` ON ((`sm`.`SafetyMeetingId` = `smu`.`SafetyMeetingId`))) JOIN
    `safetypass`.`location` `l` ON ((`l`.`LocationId` = `sm`.`LocationId`)));
