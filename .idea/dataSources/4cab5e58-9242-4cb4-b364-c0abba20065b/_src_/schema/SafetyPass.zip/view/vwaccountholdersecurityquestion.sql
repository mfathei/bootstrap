CREATE VIEW SafetyPass.vwaccountholdersecurityquestion AS
  SELECT
    `a`.`AccountholderId`                 AS `AccountholderId`,
    concat(`a`.`FName`, ' ', `a`.`LName`) AS `FullName`,
    `a`.`Email`                           AS `Email`,
    `sq`.`SecurityQuestion`               AS `SecurityQuestion`,
    `asq`.`SecurityQuestionAnswer`        AS `SecurityQuestionAnswer`,
    `asq`.`SecurityQuestionId`            AS `SecurityQuestionId`,
    `asq`.`Order`                         AS `Order`
  FROM ((`safetypass`.`accountholder` `a`
    JOIN `safetypass`.`accountholdersecurityquestion` `asq` ON ((`a`.`AccountholderId` = `asq`.`AccountholderId`))) JOIN
    `safetypass`.`securityquestion` `sq` ON ((`asq`.`SecurityQuestionId` = `sq`.`SecurityQuestionId`)))
  ORDER BY `asq`.`Order`;
