CREATE VIEW SafetyPass.vwaccountholderprivilege AS
  SELECT
    `a`.`AccountholderId`      AS `AccountholderId`,
    `a`.`FName`                AS `FName`,
    `a`.`LName`                AS `LName`,
    `a`.`Password`             AS `Password`,
    `a`.`DateOfBirth`          AS `DateOfBirth`,
    `a`.`MedicalInformation`   AS `MedicalInformation`,
    `a`.`Street`               AS `Street`,
    `a`.`CityId`               AS `CityId`,
    `a`.`Postal`               AS `Postal`,
    `a`.`Fax`                  AS `Fax`,
    `a`.`Email`                AS `Email`,
    `a`.`Phone`                AS `Phone`,
    `a`.`CardNumber`           AS `CardNumber`,
    `a`.`CreationDate`         AS `CreationDate`,
    `a`.`ExpiryDate`           AS `ExpiryDate`,
    `a`.`Status`               AS `Status`,
    `a`.`IssueDate`            AS `IssueDate`,
    `a`.`OrgId`                AS `OrgId`,
    `a`.`OwnerOrgId`           AS `OwnerOrgId`,
    `a`.`ReceiveNotification`  AS `ReceiveNotification`,
    `a`.`IsOrgAdmin`           AS `IsOrgAdmin`,
    `a`.`SupervisorId`         AS `SupervisorId`,
    `a`.`LastUpdate`           AS `LastUpdate`,
    `r`.`RoleId`               AS `RoleId`,
    `r`.`RoleName`             AS `RoleName`,
    `r`.`RoleDescription`      AS `RoleDescription`,
    `p`.`PrivilegeId`          AS `PrivilegeId`,
    `p`.`PrivilegeName`        AS `PrivilegeName`,
    `p`.`PrivilegeDescription` AS `PrivilegeDescription`
  FROM ((((`safetypass`.`accountholder` `a`
    JOIN `safetypass`.`accountholderrole` `ar` ON ((`a`.`AccountholderId` = `ar`.`AccountholderId`))) JOIN
    `safetypass`.`role` `r` ON ((`ar`.`RoleId` = `r`.`RoleId`))) JOIN `safetypass`.`privilegerole` `pr`
      ON ((`r`.`RoleId` = `pr`.`RoleId`))) JOIN `safetypass`.`privilege` `p`
      ON ((`pr`.`PrivilegeId` = `p`.`PrivilegeId`)));
