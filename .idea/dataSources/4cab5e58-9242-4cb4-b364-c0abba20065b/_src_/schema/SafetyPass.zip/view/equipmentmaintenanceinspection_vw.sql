CREATE VIEW SafetyPass.equipmentmaintenanceinspection_vw AS
  SELECT
    `em`.`EquipmentMaintenanceId` AS `EquipmentMaintenanceId`,
    `em`.`EquipmentInspectionId`  AS `EquipmentInspectionId`,
    (CASE WHEN isnull(`em`.`EquipmentId`)
      THEN `i`.`EquipmentId`
     ELSE `em`.`EquipmentId` END) AS `EquipmentId`,
    `em`.`MaintenanceDate`        AS `MaintenanceDate`,
    `em`.`MaintenanceType`        AS `MaintenanceType`,
    `em`.`last_update`            AS `last_update`,
    `i`.`InspectionId`            AS `InspectionId`,
    `i`.`InspectionDate`          AS `InspectionDate`,
    `i`.`last_update`             AS `EquipmentInspection_last_update`
  FROM (`safetypass`.`equipmentmaintenance` `em` LEFT JOIN `safetypass`.`equipmentinspection` `i`
      ON ((`em`.`EquipmentInspectionId` = `i`.`EquipmentInspectionId`)));
