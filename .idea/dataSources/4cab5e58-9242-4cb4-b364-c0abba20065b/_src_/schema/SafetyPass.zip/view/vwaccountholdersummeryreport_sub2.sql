CREATE VIEW SafetyPass.vwaccountholdersummeryreport_sub2 AS
  SELECT
    `safetypass`.`accountholdercertificate`.`AccountholderId`                              AS `AccountholderId`,
    count(0)                                                                               AS `total_certificates`,
    count(nullif((`safetypass`.`accountholdercertificate`.`ExpiryDate` < curdate()), 'f')) AS `expired_certificates`,
    count(nullif((`safetypass`.`accountholdercertificate`.`ExpiryDate` BETWEEN curdate() AND (curdate() +
                                                                                              INTERVAL 90 DAY)),
                 'f'))                                                                     AS `expiring_certificates`
  FROM `safetypass`.`accountholdercertificate`
  GROUP BY `safetypass`.`accountholdercertificate`.`AccountholderId`;
