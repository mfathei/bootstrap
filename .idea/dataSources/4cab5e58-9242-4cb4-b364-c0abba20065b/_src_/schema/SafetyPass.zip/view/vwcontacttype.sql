CREATE VIEW SafetyPass.vwcontacttype AS
  SELECT
    `common_safetypass`.`contacttype`.`ContactTypeId`   AS `ContactTypeId`,
    `common_safetypass`.`contacttype`.`ContactTypeName` AS `ContactTypeName`,
    `common_safetypass`.`contacttype`.`Order`           AS `Order`
  FROM `common_safetypass`.`contacttype`;
