CREATE VIEW SafetyPass.vwcertificatereport AS
  SELECT DISTINCT
    `safetypass`.`accountholder`.`AccountholderId`                      AS `AccountholderId`,
    `safetypass`.`organization`.`PresentationName`                      AS `PresentationName`,
    `safetypass`.`accountholder`.`FName`                                AS `FName`,
    `safetypass`.`accountholder`.`LName`                                AS `LName`,
    `safetypass`.`role`.`RoleDescription`                               AS `RoleDescription`,
    `safetypass`.`accountholder`.`CardNumber`                           AS `CardNumber`,
    `safetypass`.`certificate`.`CertificateName`                        AS `CertificateName`,
    `safetypass`.`orgcategorycert`.`OrgId`                              AS `OrgId`,
    `safetypass`.`accountholdercertificate`.`ExpiryDate`                AS `ExpiryDate`,
    `fnIsExpired`(`safetypass`.`accountholdercertificate`.`ExpiryDate`) AS `status`,
    `safetypass`.`accountholdercertificate`.`CertificateId`             AS `CertificateId`,
    `safetypass`.`accountholdercertificate`.`IssuedDate`                AS `IssuedDate`,
    `safetypass`.`category`.`CategoryDefaultName`                       AS `CategoryDefaultName`
  FROM (((((((`safetypass`.`accountholder`
    JOIN `safetypass`.`organization`
      ON ((`safetypass`.`organization`.`OrgId` = `safetypass`.`accountholder`.`OrgId`))) JOIN
    `safetypass`.`accountholderrole`
      ON ((`safetypass`.`accountholder`.`AccountholderId` = `safetypass`.`accountholderrole`.`AccountholderId`))) JOIN
    `safetypass`.`role` ON ((`safetypass`.`accountholderrole`.`RoleId` = `safetypass`.`role`.`RoleId`))) JOIN
    `safetypass`.`accountholdercertificate` ON ((`safetypass`.`accountholdercertificate`.`AccountholderId` =
                                                 `safetypass`.`accountholder`.`AccountholderId`))) JOIN
    `safetypass`.`certificate` ON ((`safetypass`.`accountholdercertificate`.`CertificateId` =
                                    `safetypass`.`certificate`.`CertificateId`))) LEFT JOIN
    `safetypass`.`orgcategorycert` ON ((`safetypass`.`orgcategorycert`.`CertificateId` =
                                        `safetypass`.`accountholdercertificate`.`CertificateId`))) JOIN
    `safetypass`.`category` ON ((`safetypass`.`orgcategorycert`.`CategoryId` = `safetypass`.`category`.`CategoryId`)));
