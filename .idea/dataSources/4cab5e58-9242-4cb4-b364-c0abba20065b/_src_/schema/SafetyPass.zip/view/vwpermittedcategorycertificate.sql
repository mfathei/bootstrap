CREATE VIEW SafetyPass.vwpermittedcategorycertificate AS
  SELECT
    `LC`.`LocationCategoryId`  AS `LocationCategoryId`,
    `LC`.`LocationId`          AS `LocationId`,
    `LC`.`CategoryId`          AS `CategoryId`,
    `LC`.`CreatedAt`           AS `CreatedAt`,
    `CA`.`CategoryDefaultName` AS `CategoryDefaultName`
  FROM (`safetypass`.`locationcategory` `LC`
    JOIN `safetypass`.`category` `CA` ON ((`LC`.`CategoryId` = `CA`.`CategoryId`)));
