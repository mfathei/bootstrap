CREATE VIEW SafetyPass.vwpermittedorganization AS
  SELECT
    `LO`.`LocationOrgId`    AS `LocationOrgId`,
    `LO`.`LocationId`       AS `LocationId`,
    `LO`.`PremittedOrgId`   AS `PremittedOrgId`,
    `LO`.`CreatedAt`        AS `CreatedAt`,
    `OZ`.`PresentationName` AS `PresentationName`,
    `OZ`.`Phone`            AS `Phone`,
    `OZ`.`Fax`              AS `Fax`
  FROM (`safetypass`.`locationorg` `LO`
    JOIN `safetypass`.`organization` `OZ` ON ((`LO`.`PremittedOrgId` = `OZ`.`OrgId`)));
