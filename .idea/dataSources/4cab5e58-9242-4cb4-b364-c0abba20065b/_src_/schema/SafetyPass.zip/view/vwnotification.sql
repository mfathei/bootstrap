CREATE VIEW SafetyPass.vwnotification AS
  SELECT
    `N`.`NotificationId`      AS `NotificationId`,
    `N`.`OrgId`               AS `OrgId`,
    `N`.`DaysStart`           AS `DaysStart`,
    `N`.`DaysFreq`            AS `DaysFreq`,
    `N`.`NotifyGroup`         AS `NotifyGroup`,
    `N`.`NotifyAccountHolder` AS `NotifyAccountHolder`,
    `N`.`CreatedAt`           AS `CreatedAt`,
    `NR`.`RoleId`             AS `RoleId`,
    `R`.`RoleName`            AS `RoleName`,
    `N`.`ModuleId`            AS `ModuleId`,
    `NM`.`ModuleName`         AS `ModuleName`
  FROM (((`safetypass`.`notification` `N` LEFT JOIN `safetypass`.`notificationrole` `NR`
      ON ((`N`.`NotificationId` = `NR`.`NotificationId`))) LEFT JOIN `safetypass`.`notificationmodule` `NM`
      ON ((`NM`.`NotificationModuleId` = `N`.`ModuleId`))) LEFT JOIN `safetypass`.`role` `R`
      ON ((`R`.`RoleId` = `NR`.`RoleId`)));
