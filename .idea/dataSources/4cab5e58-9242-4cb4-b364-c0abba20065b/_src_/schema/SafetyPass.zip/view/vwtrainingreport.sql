CREATE VIEW SafetyPass.vwtrainingreport AS
  SELECT
    `safetypass`.`training`.`AccountholderId`                      AS `AccountholderId`,
    `safetypass`.`accountholder`.`OwnerOrgId`                      AS `OrgId`,
    `safetypass`.`organization`.`PresentationName`                 AS `PresentationName`,
    `safetypass`.`accountholder`.`FName`                           AS `FName`,
    `safetypass`.`accountholder`.`LName`                           AS `LName`,
    `safetypass`.`accountholder`.`CardNumber`                      AS `CardNumber`,
    `safetypass`.`training`.`TrainingName`                         AS `TrainingName`,
    `safetypass`.`training`.`ExpiryDate`                           AS `ExpiryDate`,
    (CASE WHEN ((dayofmonth(`safetypass`.`training`.`ExpiryDate`) < 1) OR
                (month(`safetypass`.`training`.`ExpiryDate`) < 1))
      THEN 'IsExpired'
     ELSE `FNISEXPIRED`(`safetypass`.`training`.`ExpiryDate`) END) AS `status`,
    `safetypass`.`training`.`TrainingId`                           AS `TrainingId`,
    `safetypass`.`training`.`TrainingOrgId`                        AS `TrainingOrgId`,
    `safetypass`.`training`.`TrainingOrgName`                      AS `TrainingOrgName`,
    `safetypass`.`training`.`DateAcquired`                         AS `DateAcquired`
  FROM ((`safetypass`.`training`
    LEFT JOIN `safetypass`.`accountholder`
      ON ((`safetypass`.`training`.`AccountholderId` = `safetypass`.`accountholder`.`AccountholderId`))) LEFT JOIN
    `safetypass`.`organization` ON ((`safetypass`.`organization`.`OrgId` = `safetypass`.`accountholder`.`OwnerOrgId`)));
