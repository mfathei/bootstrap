CREATE VIEW SafetyPass.vwaccountholdersummeryreport AS
  SELECT
    `safetypass`.`accountholder`.`FName`                     AS `fname`,
    `safetypass`.`accountholder`.`LName`                     AS `lname`,
    `safetypass`.`accountholder`.`AccountholderId`           AS `AccountholderId`,
    `safetypass`.`accountholder`.`CardNumber`                AS `CardNumber`,
    `safetypass`.`accountholder`.`ExpiryDate`                AS `ExpiryDate`,
    `safetypass`.`accountholder`.`OrgId`                     AS `OrgId`,
    `safetypass`.`organization`.`PresentationName`           AS `PresentationName`,
    `dd`.`role`                                              AS `role`,
    `fnIsExpired`(`safetypass`.`accountholder`.`ExpiryDate`) AS `status`,
    coalesce(`c`.`total_certificates`, 0)                    AS `total_certificates`,
    coalesce(`c`.`expired_certificates`, 0)                  AS `expired_certificates`,
    coalesce(`c`.`expiring_certificates`, 0)                 AS `expiring_certificates`,
    coalesce(`t`.`total_verified_skills`, 0)                 AS `total_verified_skills`,
    coalesce(`t`.`verified_expired_skills`, 0)               AS `verified_expired_skills`,
    coalesce(`t`.`verified_expiring_skills`, 0)              AS `verified_expiring_skills`,
    coalesce(`t`.`total_unverified_skills`, 0)               AS `total_unverified_skills`,
    coalesce(`t`.`unverified_expired_skills`, 0)             AS `unverified_expired_skills`,
    coalesce(`t`.`unverified_expiring_skills`, 0)            AS `unverified_expiring_skills`
  FROM (((((`safetypass`.`accountholder`
    JOIN `safetypass`.`organization`
      ON ((`safetypass`.`organization`.`OrgId` = `safetypass`.`accountholder`.`OrgId`))) JOIN
    `safetypass`.`accountholderrole`
      ON ((`safetypass`.`accountholder`.`AccountholderId` = `safetypass`.`accountholderrole`.`AccountholderId`))) JOIN
    `safetypass`.`vwaccountholdersummeryreport_sub1` `dd`
      ON ((`safetypass`.`accountholder`.`AccountholderId` = `dd`.`AccountholderId`))) LEFT JOIN
    `safetypass`.`vwaccountholdersummeryreport_sub2` `c`
      ON ((`safetypass`.`accountholder`.`AccountholderId` = `c`.`AccountholderId`))) LEFT JOIN
    `safetypass`.`vwaccountholdersummeryreport_sub3` `t`
      ON ((`safetypass`.`accountholder`.`AccountholderId` = `t`.`AccountholderId`)));
