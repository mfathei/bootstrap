CREATE VIEW SafetyPass.vwaccountholderrole AS
  SELECT
    `a`.`AccountholderId`                       AS `AccountholderId`,
    `a`.`CardNumber`                            AS `CardNumber`,
    `a`.`FName`                                 AS `FName`,
    `a`.`LName`                                 AS `LName`,
    `a`.`Email`                                 AS `Email`,
    `o`.`PresentationName`                      AS `PresentationName`,
    `a`.`ExpiryDate`                            AS `ExpiryDate`,
    group_concat(`r`.`RoleName` SEPARATOR ', ') AS `RoleName`,
    `a`.`OrgId`                                 AS `OrgId`,
    `a`.`OwnerOrgId`                            AS `OwnerOrgId`,
    `a`.`IsActive`                              AS `IsActive`
  FROM (((`safetypass`.`accountholder` `a`
    JOIN `safetypass`.`accountholderrole` `ar` ON ((`a`.`AccountholderId` = `ar`.`AccountholderId`))) JOIN
    `safetypass`.`organization` `o` ON ((`a`.`OrgId` = `o`.`OrgId`))) JOIN `safetypass`.`role` `r`
      ON ((`ar`.`RoleId` = `r`.`RoleId`)))
  GROUP BY `a`.`AccountholderId`;
