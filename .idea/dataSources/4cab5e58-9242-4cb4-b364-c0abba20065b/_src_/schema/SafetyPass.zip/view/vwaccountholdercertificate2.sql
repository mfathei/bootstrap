CREATE VIEW SafetyPass.vwaccountholdercertificate2 AS
  SELECT
    `tbl1`.`AccountholderCertificateId` AS `AccountholderCertificateId`,
    `tbl1`.`AccountholderId`            AS `AccountholderId`,
    `tbl1`.`CertificateId`              AS `CertificateId`,
    `tbl2`.`CertificateName`            AS `CertificateName`,
    `tbl1`.`CertifyingOrgId`            AS `CertifyingOrgId`,
    `tbl4`.`PresentationName`           AS `CertifyingOrgName`,
    `tbl1`.`TrainingOrgId`              AS `TrainingOrgId`,
    `tbl3`.`PresentationName`           AS `TrainingOrgName`,
    `tbl1`.`CertificateNumber`          AS `CertificateNumber`,
    `tbl1`.`InstructorName`             AS `InstructorName`,
    `tbl1`.`CourseNumber`               AS `CourseNumber`,
    `tbl1`.`IssuedDate`                 AS `IssuedDate`,
    `tbl1`.`ExpiryDate`                 AS `ExpiryDate`,
    `tbl1`.`CertificateStatus`          AS `CertificateStatus`,
    `tbl1`.`CertificatePhoto`           AS `CertificatePhoto`,
    `acc`.`FName`                       AS `FName`,
    `acc`.`LName`                       AS `LName`,
    `acc`.`OrgId`                       AS `OrgId`,
    `FNISEXPIRED`(`tbl1`.`ExpiryDate`)  AS `ExpiryStatus`
  FROM ((((`safetypass`.`accountholdercertificate` `tbl1`
    JOIN `safetypass`.`certificate` `tbl2` ON ((`tbl1`.`CertificateId` = `tbl2`.`CertificateId`))) LEFT JOIN
    `safetypass`.`organization` `tbl3` ON ((`tbl1`.`TrainingOrgId` = `tbl3`.`OrgId`))) LEFT JOIN
    `safetypass`.`organization` `tbl4` ON ((`tbl1`.`CertifyingOrgId` = `tbl4`.`OrgId`))) LEFT JOIN
    `safetypass`.`accountholder` `acc` ON ((`tbl1`.`AccountholderId` = `acc`.`AccountholderId`)))
  WHERE (`tbl1`.`CertificateStatus` = 'Approved');
