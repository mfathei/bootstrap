CREATE VIEW SafetyPass.vwaccountholdersummeryreport_sub1 AS
  SELECT
    group_concat(DISTINCT `safetypass`.`role`.`RoleName` SEPARATOR ',') AS `role`,
    `safetypass`.`accountholderrole`.`AccountholderId`                  AS `AccountholderId`
  FROM (`safetypass`.`role`
    JOIN `safetypass`.`accountholderrole`
      ON ((`safetypass`.`accountholderrole`.`RoleId` = `safetypass`.`role`.`RoleId`)))
  GROUP BY `safetypass`.`accountholderrole`.`AccountholderId`;
