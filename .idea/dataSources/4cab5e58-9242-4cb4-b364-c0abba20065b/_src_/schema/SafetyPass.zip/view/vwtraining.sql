CREATE VIEW SafetyPass.vwtraining AS
  SELECT
    `T`.`TrainingId`                AS `TrainingId`,
    `T`.`AccountholderId`           AS `AccountholderId`,
    `T`.`TrainingName`              AS `TrainingName`,
    `T`.`DateAcquired`              AS `DateAcquired`,
    `T`.`VerifiedDate`              AS `VerifiedDate`,
    `T`.`ExpiryDate`                AS `ExpiryDate`,
    `T`.`TrainingStatus`            AS `TrainingStatus`,
    `T`.`VerifiedById`              AS `VerifiedById`,
    `T`.`InstructorName`            AS `InstructorName`,
    `T`.`Description`               AS `Description`,
    `T`.`CertificatePhoto`          AS `CertificatePhoto`,
    `O`.`OrgId`                     AS `TrainingOrgId`,
    `O`.`PresentationName`          AS `TrainingOrgName`,
    `VO`.`PresentationName`         AS `VerifiedOrgName`,
    `FNISEXPIRED`(`T`.`ExpiryDate`) AS `IsExpired`
  FROM ((`safetypass`.`training` `T` LEFT JOIN `safetypass`.`organization` `O`
      ON ((`O`.`OrgId` = `T`.`TrainingOrgId`))) LEFT JOIN `safetypass`.`organization` `VO`
      ON ((`VO`.`OrgId` = `T`.`VerifiedById`)));
