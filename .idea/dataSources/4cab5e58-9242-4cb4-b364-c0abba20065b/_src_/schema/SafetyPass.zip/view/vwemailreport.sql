CREATE VIEW SafetyPass.vwemailreport AS
  SELECT
    `ac`.`FName`            AS `FName`,
    `ac`.`LName`            AS `LName`,
    `ac`.`OrgId`            AS `OrgId`,
    `ac`.`AccountholderId`  AS `AccountholderId`,
    `ac`.`CardNumber`       AS `CardNumber`,
    `o`.`PresentationName`  AS `PresentationName`,
    (CASE WHEN (isnull(`ac`.`Email`) OR (`ac`.`Email` = ''))
      THEN 'No Email'
     ELSE `ac`.`Email` END) AS `Email`
  FROM (`safetypass`.`accountholder` `ac`
    JOIN `safetypass`.`organization` `o` ON ((`ac`.`OrgId` = `o`.`OrgId`)));
