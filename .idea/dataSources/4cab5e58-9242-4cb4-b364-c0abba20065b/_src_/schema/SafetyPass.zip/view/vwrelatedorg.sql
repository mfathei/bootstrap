CREATE VIEW SafetyPass.vwrelatedorg AS
  SELECT
    `o`.`OrgId`            AS `OrgId`,
    `o`.`LegalName`        AS `LegalName`,
    `o`.`PresentationName` AS `PresentationName`,
    `o`.`Phone`            AS `Phone`,
    `o`.`Fax`              AS `Fax`,
    `o`.`ParentOrgId`      AS `ParentOrgId`,
    `oc`.`Street`          AS `Street`,
    `ct`.`ContactTypeName` AS `ContactTypeName`
  FROM (`safetypass`.`organization` `o` LEFT JOIN (`safetypass`.`orgcontact` `oc`
    JOIN `safetypass`.`contacttype` `ct`
      ON (((`oc`.`ContactTypeId` = `ct`.`ContactTypeId`) AND (`ct`.`ContactTypeName` = 'Mailing'))))
      ON ((`o`.`OrgId` = `oc`.`OrgId`)));
