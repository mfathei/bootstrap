CREATE VIEW SafetyPass.vwtotalusersgrid AS
  SELECT
    `tbl1`.`SwipeId`                                                 AS `vwSwipeId`,
    `tbl3`.`CardNumber`                                              AS `vwCardNumber`,
    `tbl1`.`SwipInTime`                                              AS `vwSwipInTime`,
    `tbl1`.`SwipOutTime`                                             AS `vwSwipOutTime`,
    `tbl1`.`LocationId`                                              AS `vwLocationId`,
    `tbl3`.`AccountholderId`                                         AS `vwAccountholderId`,
    `tbl3`.`FName`                                                   AS `vwFName`,
    `tbl3`.`LName`                                                   AS `vwLName`,
    `tbl5`.`RoleName`                                                AS `vwRoleName`,
    `tbl1`.`SwipeType`                                               AS `vwSwipeType`,
    `tbl8`.`PresentationName`                                        AS `vwPresentationName`,
    `tbl6`.`OrgId`                                                   AS `vwOrgId`,
    timestampdiff(SECOND, `tbl1`.`SwipInTime`, `tbl1`.`SwipOutTime`) AS `total`
  FROM (((((`safetypass`.`swiping` `tbl1`
    JOIN `safetypass`.`accountholder` `tbl3` ON ((`tbl3`.`AccountholderId` = `tbl1`.`AccountholderId`))) JOIN
    `safetypass`.`accountholderrole` `tbl7` ON ((`tbl7`.`AccountholderId` = `tbl3`.`AccountholderId`))) JOIN
    `safetypass`.`role` `tbl5` ON ((`tbl5`.`RoleId` = `tbl7`.`RoleId`))) JOIN `safetypass`.`organization` `tbl8`
      ON ((`tbl8`.`OrgId` = `tbl3`.`OwnerOrgId`))) JOIN `safetypass`.`location` `tbl6`
      ON ((`tbl6`.`LocationId` = `tbl1`.`LocationId`)));
