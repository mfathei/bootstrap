CREATE TRIGGER SafetyPass.LocationOrg_BDEL
BEFORE DELETE ON SafetyPass.LocationOrg
FOR EACH ROW
  BEGIN
	INSERT INTO delete_hist(table_name, table_column, table_value) VALUES ('LocationOrg', 'LocationOrgId',OLD.`LocationOrgId`);
    END;
