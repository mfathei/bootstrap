CREATE TRIGGER SafetyPass.Blacklist_BDEL
BEFORE DELETE ON SafetyPass.Blacklist
FOR EACH ROW
  BEGIN
		INSERT INTO delete_hist(table_name, table_column, table_value) VALUES ('Blacklist', 'BlacklistId',OLD.`BlacklistId`);   
    END;
