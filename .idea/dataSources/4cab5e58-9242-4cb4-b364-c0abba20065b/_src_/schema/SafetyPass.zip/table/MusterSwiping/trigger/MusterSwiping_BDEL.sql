CREATE TRIGGER SafetyPass.MusterSwiping_BDEL
BEFORE DELETE ON SafetyPass.MusterSwiping
FOR EACH ROW
  BEGIN
		INSERT INTO delete_hist(id,`table_name`, table_column, table_value) VALUES (myuuid(),'MusterSwiping', 'SwipeId',OLD.`SwipeId`);
    END;
