CREATE TRIGGER SafetyPass.LocationCategory_BDEL
BEFORE DELETE ON SafetyPass.LocationCategory
FOR EACH ROW
  BEGIN
		INSERT INTO delete_hist(table_name, table_column, table_value) VALUES ('LocationCategory', 'LocationCategoryId',OLD.`LocationCategoryId`);
    END;
