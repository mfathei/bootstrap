CREATE TRIGGER SafetyPass.delete_hist_BINS
BEFORE INSERT ON SafetyPass.delete_hist
FOR EACH ROW
  BEGIN
	
		set NEW.`id` = UUID();
	
    END;
