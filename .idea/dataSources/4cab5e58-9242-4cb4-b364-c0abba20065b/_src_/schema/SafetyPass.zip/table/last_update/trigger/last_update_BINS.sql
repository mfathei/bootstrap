CREATE TRIGGER SafetyPass.last_update_BINS
BEFORE INSERT ON SafetyPass.last_update
FOR EACH ROW
  begin
   set @nid = (select max(`Order`) from last_update);
   if @nid is null then  
	SET NEW.`Order` = 1;
   else
	set NEW.`Order` = @nid + 1;
   END IF;
end;
