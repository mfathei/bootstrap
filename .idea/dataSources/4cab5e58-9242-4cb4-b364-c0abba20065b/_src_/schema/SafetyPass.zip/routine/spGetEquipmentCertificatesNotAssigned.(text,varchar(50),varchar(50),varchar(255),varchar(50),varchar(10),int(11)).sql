CREATE PROCEDURE SafetyPass.spGetEquipmentCertificatesNotAssigned(IN `$Search`          TEXT,
                                                                  IN `$CertifyingOrgId` VARCHAR(50),
                                                                  IN `$EquipmentId`     VARCHAR(50),
                                                                  IN `$keyword`         VARCHAR(255),
                                                                  IN `$Sidx`            VARCHAR(50),
                                                                  IN `$Sord`            VARCHAR(10), IN `$Lmt` INT)
  BEGIN

SET @qry = concat("
select SQL_CALC_FOUND_ROWS * 
                from CertificateForEquipment where
                CertificateName LIKE '", $keyword, "' and CertificateId not in(
                SELECT CertificateId 
                FROM EquipmentCertificate 
                WHERE EquipmentId = '", $EquipmentId, "'  AND 
                CertifyingOrgId = '", $CertifyingOrgId, "'
                ) ");
                  
SET @qryWhere = (CASE WHEN $Search IS NOT NULL AND $Search <> '' THEN CONCAT('
',$Search, '
') ELSE '
' END);
SET @qrysort= CONCAT('ORDER BY ',$Sidx,' ',$Sord);
SET @qryLimit = CONCAT(' LIMIT ', $Lmt );
SET @qry = CONCAT(@qry, @qryWhere, @qrysort);
SET @qry = CONCAT(@qry, @qryLimit);
-- select @qry;
PREPARE stmt FROM @qry;
EXECUTE stmt;

SELECT FOUND_ROWS();

DEALLOCATE PREPARE stmt;
end;
