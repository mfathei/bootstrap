CREATE PROCEDURE SafetyPass.spLogin(IN `$CardNumber` BIGINT, IN `$UserPassword` VARCHAR(255))
  BEGIN
DECLARE $ValidateLogin INT(1);
DECLARE $IsBlocked VARCHAR(15);
DECLARE $AccountholderId, $OrgId VARCHAR(50);
IF EXISTS (SELECT * FROM Accountholder WHERE CardNumber = $CardNumber)
THEN
	SET $ValidateLogin = fnValidateLogin($CardNumber, $UserPassword);
	SET $IsBlocked = fnIsBlocked($CardNumber);
	SET $AccountholderId = (SELECT AccountholderId FROM Accountholder WHERE CardNumber = $CardNumber);
	SET $OrgId = (SELECT OrgId FROM Accountholder WHERE AccountholderId = $AccountholderId);
	IF $ValidateLogin = 1 AND ($IsBlocked = 'WasBlocked' OR $IsBlocked = 'NotBlocked' OR $IsBlocked = 'Found') 
	THEN
    
		SELECT AccountholderId, CardNumber, FName, LName, `Email`, OrgId, OwnerOrgId FROM Accountholder WHERE AccountholderId = $AccountholderId;
		SELECT OrgId, LegalName, PresentationName, Phone, Fax, PresentationLogo FROM Organization WHERE OrgId = $OrgId;
        
		DELETE FROM LoginAttempt WHERE AccountholderId = $AccountholderId;
	ELSEIF $ValidateLogin = 2 AND ($IsBlocked = 'WasBlocked' OR $IsBlocked = 'NotBlocked' OR $IsBlocked = 'Found')
    
    THEN
		SELECT 'NotActive' AS BlockStatus;
        
	ELSEIF $IsBlocked = 'IsBlocked'
    
	THEN 
    
		SELECT $IsBlocked AS BlockStatus; -- IsBlocked
        
	ELSEIF $ValidateLogin = 0 AND $IsBlocked = 'Found' 
	THEN
    
		UPDATE LoginAttempt
		SET LoginAttemptCount = LoginAttemptCount + 1
		WHERE AccountholderId = $AccountholderId;
        
		IF (SELECT LoginAttemptCount FROM LoginAttempt WHERE AccountholderId = $AccountholderId) = 3
		THEN
        
			SELECT 'IsBlocked' AS BlockStatus;
            
		ELSE
        
			SELECT 'WrongPassword' AS BlockStatus;
            
		END IF;
	ELSEIF $ValidateLogin = 0 AND ($IsBlocked = 'WasBlocked' OR $IsBlocked = 'NotBlocked') 
	THEN
    
		INSERT INTO LoginAttempt
		(LoginAttemptId, AccountholderId, LoginAttemptCount)
		VALUES
		(MyUUID(), $AccountholderId, 1);
		SELECT 'WrongPassword' AS BlockStatus;
        
	END IF;
    
ELSE
	SELECT 'WrongPassword' AS BlockStatus;
    
END IF;
END;
