CREATE PROCEDURE SafetyPass.test()
  begin
DECLARE exit HANDLER FOR SQLSTATE '23000'
begin
  rollback;
  select 'just for test';
end;
insert into SafetyPass.AccountholderCertificate( AccountholderCertificateId, AccountholderId, CertificateId )
values(MyUUID(), 'dev2-85e24c94-55ae-11e5-8275-90489af8fc48', 'dev2-6ae1e854-55b3-11e5-8275-90489af8fc48');

select 'done!';
end;
