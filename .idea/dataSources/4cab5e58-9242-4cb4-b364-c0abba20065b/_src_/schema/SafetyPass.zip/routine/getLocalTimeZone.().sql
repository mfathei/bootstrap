CREATE FUNCTION SafetyPass.getLocalTimeZone()
  RETURNS VARCHAR(10)
  BEGIN
        declare vResult varchar(10) default '0';
        set @ltimezone = (select time_format(sec_to_time(timestampdiff(second, UTC_TIMESTAMP(), current_timestamp())), '%H:%i'));
        set vResult = @ltimezone;
        if substr(@ltimezone, 1, 1) <> '-' then 
            SET vResult = concat('+', @ltimezone);
        end if;
        return vResult;
    END;
