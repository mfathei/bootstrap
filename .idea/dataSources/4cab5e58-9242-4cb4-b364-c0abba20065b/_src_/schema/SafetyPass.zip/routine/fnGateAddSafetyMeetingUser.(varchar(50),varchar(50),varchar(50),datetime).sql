CREATE FUNCTION SafetyPass.fnGateAddSafetyMeetingUser(pSafetyMeetingId VARCHAR(50), pCardNumber VARCHAR(50),
                                                      pLocationId      VARCHAR(50), pInTime DATETIME)
  RETURNS VARCHAR(50)
  BEGIN
    Declare vresult VARCHAR(50) CHARSET UTF8;
    SET @stat = (SELECT Swiping.AccountholderId FROM Swiping INNER JOIN Accountholder ON(Swiping.AccountholderId = Accountholder.AccountholderId AND Accountholder.CardNumber = pCardNumber) WHERE Swiping.`LocationId` = pLocationId AND Swiping.`SwipOutTime` IS NULL);
    IF @stat IS NULL THEN
        set vresult = "NotSwipedIn";
        return vresult;
    END IF;
    
    SET @meetingid = (SELECT SafetyMeetingId FROM SafetyMeeting WHERE SafetyMeetingId = pSafetyMeetingId AND `LocationId` = pLocationId );
    IF @meetingid IS NULL THEN
        set vresult = "NoMeeting";
        return vresult;
    END IF;
    
    SET @meetingaccid = (SELECT SafetyMeetingUserId FROM SafetyMeetingUser WHERE SafetyMeetingId = pSafetyMeetingId AND `AccountholderId` = @stat );
    IF @meetingaccid IS not NULL THEN
        set vresult = "AlreadyInTheMeeting";
        return vresult;
    END IF;
    
    INSERT INTO SafetyMeetingUser(SafetyMeetingUserId, SafetyMeetingId, AccountholderId, InTime) VALUES(MyUUID(), pSafetyMeetingId, @stat, pInTime);
    set vresult = "InsertedInMeeting";
    RETURN vresult;
END;
