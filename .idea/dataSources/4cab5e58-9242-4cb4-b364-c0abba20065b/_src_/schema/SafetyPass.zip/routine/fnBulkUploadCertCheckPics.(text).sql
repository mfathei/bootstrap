CREATE FUNCTION SafetyPass.fnBulkUploadCertCheckPics(`$PicNames` TEXT)
  RETURNS TEXT
  BEGIN
DECLARE $Ret, $PicNamesQ TEXT;
DECLARE $PicName, $ProfilePic VARCHAR(255);
DECLARE $Cnt, $Counter, $Position INT;
SET $Ret = 'In DB but Not in ZIP File: ';
SET $PicNamesQ = CONCAT($PicNames, ',');
SET $Cnt = (SELECT COUNT(*) FROM ImportCertificate);
SET $Counter = 1;
PicCHKLoop: WHILE $Counter <= $Cnt
DO
	SET $ProfilePic = CONCAT('%',(sELECT TRIM(REPLACE(REPLACE(REPLACE(`CertificatePhoto`, '
', ' '), '
', ' '), '	', ' '))  FROM ImportCertificate WHERE AccountholderCertificateId = $Counter),'%');
    
    IF $PicNamesQ NOT LIKE $ProfilePic
    THEN
		SET $Ret = CONCAT($Ret, TRIM(BOTH '%' FROM $ProfilePic),', ');
        UPDATE ImportCertificate SET CertificatePhoto = NULL WHERE AccountholderCertificateId = $Counter;
    END IF;
    
	SET $Counter = $Counter + 1;
END WHILE;

RETURN $Ret;
END;
