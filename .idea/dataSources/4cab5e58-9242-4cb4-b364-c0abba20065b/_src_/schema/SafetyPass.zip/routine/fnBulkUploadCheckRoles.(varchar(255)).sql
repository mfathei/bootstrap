CREATE FUNCTION SafetyPass.fnBulkUploadCheckRoles(str VARCHAR(255))
  RETURNS VARCHAR(100)
  begin
set @res='';
set @statment=str;
set @chesk=(select locate('*',@statment));
if @chesk is not null
then 
theloop:loop
SET @Position = LOCATE('*',@statment);
set @restofstr=substring(@statment,@Position+1);
set @accessrole=substring(@statment,1,@Position-1);
  if not exists(select RoleName from Role where RoleName=@accessrole)
  then set @res=concat(@res,@accessrole); end if;
set @statment=@restofstr;
-- SET @Position = LOCATE(',',@statment);
if @Position=0 then leave theloop ; end if;
end loop;
 end if;
  if not exists(select RoleName from Role where RoleName=@statment)
  then set @res=concat(@res,@accessrole,@statment); end if;
return @res;

END;
