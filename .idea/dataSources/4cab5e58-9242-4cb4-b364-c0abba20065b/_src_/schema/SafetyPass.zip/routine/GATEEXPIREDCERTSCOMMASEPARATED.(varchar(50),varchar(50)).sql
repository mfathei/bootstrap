CREATE FUNCTION SafetyPass.GATEEXPIREDCERTSCOMMASEPARATED(pLocationId VARCHAR(50), pAccountholderId VARCHAR(50))
  RETURNS TEXT
  BEGIN
  DECLARE result TEXT character set utf8;
  SET SESSION group_concat_max_len = 1000000;
  SET result = 
  (
    -- expired certs
    SELECT GROUP_CONCAT(c.`CertificateName` separator ",") as expiredCerts FROM OrgCategoryCert occ
    INNER JOIN Location l ON(occ.OrgId = l.OrgId AND l.`LocationId` = pLocationId)
    INNER JOIN `LocationCategory` lc ON(l.LocationId = lc.LocationId AND occ.CategoryId = lc.CategoryId)
    INNER JOIN Category cg ON(occ.CategoryId = cg.CategoryId)
    INNER JOIN Certificate c ON(c.`CertificateId` = occ.`CertificateId`)
    INNER JOIN `AccountholderCertificate` aci ON(aci.`CertificateId` = c.`CertificateId` and aci.CertificateStatus = 'Approved')
    AND aci.`AccountholderId` = pAccountholderId 
    AND aci.`ExpiryDate` IS NOT NULL  
    AND aci.`ExpiryDate` <= NOW()
    AND aci.`ExpiryDate` <> '3000-00-00'
  );
  
  RETURN result;
END;
