CREATE PROCEDURE SafetyPass.spBulkUploadCertificate(IN `$AccountholderId` VARCHAR(50), IN `$PicNames` VARCHAR(50))
  BEGIN
DECLARE $InvalidPicName TEXT;
DECLARE $Man,$opt,$Certifying,$Training,$ai,$edate,$CN,$idate,$certs,$certorg,$torg VARCHAR(200);
DECLARE $Cert  VARCHAR(100);
declare ending,ending2 int default 0;
declare ex_cursor cursor for select `AccountholderCertificateId` ,ExpiryDate,CertificateNumber,`IssuedDate` from ImportCertificate;
declare ex_cursor1 cursor for select `AccountholderCertificateId` ,`Certificate`,`CertifyingOrg`,`TrainingOrg` from ImportCertificate;
SET $Man = '';
SET $opt = '';
SET $InvalidPicName = fnBulkUploadCertCheckPics($PicNames);


	IF EXISTS (SELECT * FROM ImportCertificate `ic` WHERE (Certificate IS NULL OR Certificate = '' OR Certificate NOT IN(SELECT CertificateName FROM vwOrgCategoryCert `vw` )))
		THEN SET $Man = CONCAT($Man, ', ', 'CertificateName');
	END IF;
   
	IF EXISTS (SELECT * FROM ImportCertificate WHERE (CertifyingOrg IS NULL OR CertifyingOrg = '' OR CertifyingOrg NOT IN (SELECT `O`.PresentationName from Organization `O`)))
		THEN SET $Man = CONCAT($Man, ', ', 'CertifyingOrg');
	END IF;
    IF EXISTS (SELECT * FROM ImportCertificate WHERE (`TrainingOrg` NOT IN (SELECT `O`.PresentationName from Organization `O`)))
		THEN SET $Man = CONCAT($Man, ', ', 'TrainingOrg');
	END IF;
    
    IF EXISTS (SELECT * FROM ImportCertificate WHERE ((`IssuedDate` is not null and (select IsDate(IssuedDate))=2) and(`ExpiryDate`is not null and (select IsDate(ExpiryDate))=2) and (date(`ExpiryDate`) < date ( `IssuedDate`) )))
		THEN SET $Man = CONCAT($Man, ', ', '`ExpiryDate`');
	END IF;
    IF EXISTS (SELECT * FROM ImportCertificate WHERE ((`IssuedDate` is not null and (select IsDate(IssuedDate))=2) and (`ExpiryDate` is not null and (select IsDate(ExpiryDate))=2) and ( date(`IssuedDate`) > date(`ExpiryDate`))))
		THEN SET $Man = CONCAT($Man, ', ', 'IssuedDate');
	END IF;
    
    IF $Man IS NOT NULL AND $Man != ''
	THEN
	SELECT  'Issues In Mandatory Fields' AS OperationStatus, COUNT(*) AS RecordCount, GROUP_CONCAT(DISTINCT AccountholderCertificateId 	  SEPARATOR ',' ) AS RecordLines, $Man AS FieldStatus FROM ImportCertificate `ic` WHERE (CertifyingOrg IS NULL OR CertifyingOrg = '' OR ((`IssuedDate` is not null and (select IsDate(IssuedDate))=2) and(`ExpiryDate`is not null and (select IsDate(ExpiryDate))=2) and (date(`ExpiryDate`) < date ( `IssuedDate`) ))OR CertifyingOrg NOT IN (SELECT `O`.PresentationName from Organization `O`)) OR (Certificate IS NULL OR Certificate = '' OR Certificate NOT IN(SELECT CertificateName FROM vwOrgCategoryCert `vw` ));
	TRUNCATE ImportCertificate;
   
	else
	   if exists(select * from ImportCertificate where (select IsDate(IssuedDate))=1  )
         then set $opt=Concat($opt,',','IssuedDate');
         end if;
          if exists(select * from ImportCertificate where (select IsDate(ExpiryDate))=1  )
         then set $opt=Concat($opt,',','ExpiryDate');
         end if;
       begin
       declare continue handler for not found set ending2 =1;
       open ex_cursor1;
       curs:loop
       fetch ex_cursor1 into $ai,$certs,$certorg,$torg;
       if ending2 =1 then leave curs; end if;
	   SET $Cert = (SELECT   CertificateId FROM vwOrgCategoryCert  where  `CertificateName`=$certs limit 1 );
	   SET $Certifying = (SELECT OrgId FROM Organization where PresentationName =$certorg  limit 1);
	   SET $Training = (SELECT OrgId FROM Organization where PresentationName =$torg  limit 1);
       if $Training ='' or $Training =null then set $Training=null; end if;
       update ImportCertificate set Certificate=$Cert,`CertifyingOrg`=$Certifying ,`TrainingOrg`=$Training where AccountholderCertificateId=$ai;
       end loop;
	   close ex_cursor1;
       end; 
       if exists (	select * from AccountholderCertificate acc join ImportCertificate ic on  acc.CertificateId=ic.Certificate and acc.AccountholderId=$AccountholderId )
         then
         	SELECT  'Issues In Mandatory Fields' AS OperationStatus, COUNT(*) AS RecordCount, GROUP_CONCAT(DISTINCT ic.`AccountholderCertificateId`) AS RecordLines, '[Duplicate: CertificateName inserted Before To This user]' AS FieldStatus   from AccountholderCertificate acc join ImportCertificate ic on  acc.CertificateId=ic.Certificate and acc.AccountholderId=$AccountholderId  ;
             	TRUNCATE ImportCertificate;

             else 
               IF EXISTS (SELECT  Certificate, COUNT(*) c FROM ImportCertificate GROUP BY Certificate  HAVING C > 1)
                  then 
                        SELECT  'Issues In Mandatory Fields' AS OperationStatus, COUNT(*) AS RecordCount, GROUP_CONCAT(DISTINCT AccountholderCertificateId  ) AS RecordLines, '[Duplicate:AccountHolder, Certificate, CertificateNumber]' AS FieldStatus FROM ImportCertificate ic join (select Certificate from ImportCertificate group by Certificate having count(AccountholderCertificateId)>1)t2  on t2.Certificate=ic.Certificate;
                      	TRUNCATE ImportCertificate;
                      else 
					  IF exists (SELECT * FROM ImportCertificate) 
                        then 
                           IF ($opt IS NOT NULL AND $opt != '' ) OR $InvalidPicName NOT LIKE 'In DB but Not in ZIP File: '
	                      THEN
					      SELECT 'Issues in Optional Fields' AS OperationStatus, COUNT(*) AS RecordCount, GROUP_CONCAT(DISTINCT AccountholderCertificateId SEPARATOR ',' ) AS RecordLines,$opt AS FieldStatus, $InvalidPicName AS PhotoStatus FROM ImportCertificate `ic` WHERE  CertificatePhoto IS NULL or (select IsDate(IssuedDate))=1 or (select IsDate(ExpiryDate))=1 ;
                          END IF; 
                         IF EXISTS (SELECT * FROM ImportCertificate WHERE (ExpiryDate ='' or CertificateNumber = '' or `IssuedDate` = '' or (select IsDate(`IssuedDate`))=1 or (select IsDate(ExpiryDate))=1))
	                      then 
                          begin
                          declare continue handler for not found set ending =1;
                          open ex_cursor;
                          curs:loop
                          fetch ex_cursor into $ai,$edate,$CN,$idate;
	                      if ending =1 then leave curs; end if;
						  if $edate=''  or (select IsDate($edate))=1 then
                          update ImportCertificate set ExpiryDate =null where `AccountholderCertificateId`=$ai;
						  end if;
                          if $CN='' then
						  update ImportCertificate set CertificateNumber =null where `AccountholderCertificateId`=$ai;
                          end if;
                          if $idate='' or (select IsDate($idate))=1 then
						  update ImportCertificate set `IssuedDate` = null where `AccountholderCertificateId`=$ai;
                          end if;
                          end loop;
                          close ex_cursor;
                          end ;
						  end if;
                         
                         
                          SET FOREIGN_KEY_CHECKS = 0;
                          INSERT  INTO AccountholderCertificate
                          (`AccountholderCertificateId` , `AccountholderId`, `CertificateId` , `CertificateNumber`, `IssuedDate`, `ExpiryDate` , `CertifyingOrgId`, `TrainingOrgId` ,`CertificatePhoto` ) 
                          SELECT
                          MyUUID() , $AccountholderId, `Certificate` , `CertificateNumber`, `IssuedDate` , `ExpiryDate`, `CertifyingOrg`,`TrainingOrg`, `CertificatePhoto`
                          FROM ImportCertificate; 
	                      SELECT  'Operation Successfull!' AS OperationStatus, COUNT(*) AS RecordCount, GROUP_CONCAT(DISTINCT AccountholderCertificateId SEPARATOR ',' ) AS RecordLines FROM ImportCertificate `ic`;
				          TRUNCATE ImportCertificate;
                          SET FOREIGN_KEY_CHECKS = 1;
                         
					else 
                          SELECT  'Issues In Mandatory Fields' AS OperationStatus, COUNT(*) AS RecordCount, GROUP_CONCAT(DISTINCT AccountholderCertificateId  ) AS RecordLines, 'The file is empty' AS FieldStatus FROM ImportCertificate  ;
                        	TRUNCATE ImportCertificate;
					end if;
                     
			end if;
		end if;
	end if;
END;
