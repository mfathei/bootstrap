CREATE PROCEDURE SafetyPass.GateMusterUserOut(IN `$LocationId` VARCHAR(50))
  BEGIN
 delete from MusterSwiping where LocationId = $LocationId;
END;
