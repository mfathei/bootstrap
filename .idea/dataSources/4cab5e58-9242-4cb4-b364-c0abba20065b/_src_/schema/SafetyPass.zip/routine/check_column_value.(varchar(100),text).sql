CREATE FUNCTION SafetyPass.check_column_value(`$STR` VARCHAR(100), `$Col` TEXT)
  RETURNS TEXT
  BEGIN
		-- ------------------------------------------------------ FKs and last_update columns
		IF $STR = 'location_id' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
            
		ELSEIF $STR = 'organization_id' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
            
		ELSEIF $STR = 'ownerOrganization' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
            
		ELSEIF $STR = 'issuedOrganization' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
            
		ELSEIF $STR = 'OldId' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
            
		ELSEIF $STR = 'accountholder_id' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
            
		ELSEIF $STR = 'role_name' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
            
		ELSEIF $STR = 'accountholder_id' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
            
		ELSEIF $STR = 'card_id' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
		ELSEIF $STR = 'location_id' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
		ELSEIF $STR = 'locationId' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
		ELSEIF $STR = 'accountholder_id' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
		ELSEIF $STR = 'ownerCardOrganizationId' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
		ELSEIF $STR = 'certificate_holder' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
		ELSEIF $STR = 'certifying_organization_id' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
		ELSEIF $STR = 'verifying_organization_id' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
		ELSEIF $STR = 'trainning_school_id' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
		ELSEIF $STR = 'OldId' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
		ELSEIF $STR = 'table' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
		ELSEIF $STR = 'action_id' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
		ELSEIF $STR = 'by' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
		ELSEIF $STR = 'old_action_id' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
		ELSEIF $STR = 'old_accountholder_id' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
		ELSEIF $STR = 'organization_id' AND $Col = ''
		THEN 
			SET $Col = 'NULL'; 
		ELSEIF $STR = 'certificate_holder' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
		ELSEIF $STR = 'certifying_organization_id' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
		ELSEIF $STR = 'verifying_organization_id' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
		ELSEIF $STR = 'trainning_school_id' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
		ELSEIF $STR = 'trainee' AND $Col = ''
		THEN 
			SET $Col = 'NULL'; 
		ELSEIF $STR = 'training_organization_id' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
		ELSEIF $STR = 'location_id' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
		ELSEIF $STR = 'meeting_id' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
		ELSEIF $STR = 'meeting_id' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
		ELSEIF $STR = 'meeting_id' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
		ELSEIF $STR = 'accountholder_id' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
		ELSEIF $STR = 'supervisor_id' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
		ELSEIF $STR = 'accountholder_id' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
		ELSEIF $STR = 'trainee' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
		ELSEIF $STR = 'training_organization_id' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
		ELSEIF $STR = 'user_card' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
		ELSEIF $STR = 'location_id' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
		END IF;
		-- ------------------------------------------------------ datetime columns
		IF $STR = 'start_time' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
					
		ELSEIF $STR = 'gkIssueDate' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
		 
		ELSEIF $STR = 'spIssueDate' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
		 
		ELSEIF $STR = 'time' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
            
		ELSEIF $STR = 'SyncTime' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
		 
		ELSEIF $STR = 'meeting_date' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
		 
		ELSEIF $STR = 'update_date' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
		 
		ELSEIF $STR = 'in_time' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
		 
		ELSEIF $STR = 'out_time' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
		 
		ELSEIF $STR = 'action_date' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
		 
		ELSEIF $STR = 'end_time' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
            
		ELSEIF $STR = 'date_of_birth' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
		 
		ELSEIF $STR = 'issue_date' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
		 
		ELSEIF $STR = 'expiry_date' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
		 
		ELSEIF $STR = 'creation_date' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
		 
		ELSEIF $STR = 'issued_date' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
		 
		ELSEIF $STR = 'installation_date' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
		 
		ELSEIF $STR = 'date_acquired' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
		 
		ELSEIF $STR = 'verified_date' AND $Col = ''
		THEN 
			SET $Col = 'NULL';
            
		END IF;
        
RETURN REPLACE($Col,''','\'');
END;
