CREATE FUNCTION SafetyPass.fnspcertificatesNotification(DaysStart INT(10), DaysFreq INT(10), exp_date DATETIME)
  RETURNS TINYINT
  begin
if(DaysFreq=0 or DaysFreq='' or DaysFreq=null)then set DaysFreq=0; end if ;
if(DaysStart=0 or DaysStart='' or DaysStart=null)then set DaysStart=0; end if ;
set @cd = curdate();
if(DaysStart=0)
then return 0;
else
if (date(exp_date)= @cd )
then
return 1;
end if;
if (date_sub(date(exp_date),interval DaysStart day )= @cd)
then
return 1;
end if;
end if;
set @xx=date_sub(date(exp_date), interval  DaysStart day) ;
if DaysFreq =0
then return 0;
else
if(@cd between @xx and date(exp_date) )
then 
   lo:loop
   
	   set @xx=date_add(@xx, interval  DaysFreq day) ;
       if @cd = @xx then return 1; end if;
	   if @xx >= date(exp_date)
	   then
		leave lo;
	   end if;
   end loop;
end if ;
end if;
return 0;
END;
