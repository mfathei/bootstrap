CREATE FUNCTION SafetyPass.fnTotalUsersGrid1(`$userCard`         BIGINT, `$sdate` DATETIME, `$edate` DATETIME,
                                             `$userOrganization` VARCHAR(50), `$location_id` VARCHAR(50))
  RETURNS TIME
  BEGIN
DECLARE $TMin, $TMax, $endTime DATETIME; -- times 
DECLARE $Min, $Max VARCHAR(50); -- Ids
DECLARE $total, $sdiff, $ediff, $tdiff TIME;
IF $location_id IS NULL OR $location_id = ''
THEN  
	-- calculating start time
	SET $Min = (SELECT SwipeId FROM Swiping tbl1 INNER JOIN Location tbl2 ON tbl1.LocationId = tbl2.LocationId inner join Accountholder ac on ac.AccountholderId=tbl1.AccountholderId  WHERE ac.CardNumber= $userCard and tbl2.OrgId = $userOrganization AND  ((SwipOutTime > $sdate AND SwipInTime < $edate) OR (SwipOutTime IS NULL AND SwipInTime < $edate)) ORDER BY SwipInTime ASC LIMIT 1);
	-- add calculated start time to calculated end time
	SET $TMin = (SELECT startTime FROM vwTotalUsersGrid WHERE SwipeId = $Min LIMIT 1);
    SET $TMin = (CASE WHEN $sdate >= $TMin THEN $sdate ELSE $TMin END);
	-- calculating end time
	SET  $Max= (SELECT SwipeId FROM Swiping tbl1 INNER JOIN Location tbl2 ON tbl1.LocationId = tbl2.LocationId inner join Accountholder ac on ac.AccountholderId=tbl1.AccountholderId  WHERE ac.CardNumber= $userCard and tbl2.OrgId = $userOrganization AND  ((SwipOutTime > $sdate AND SwipInTime < $edate) OR (SwipOutTime IS NULL AND SwipInTime < $edate)) ORDER BY SwipInTime desc LIMIT 1);
       -- SET $TMax = $edate;
        
		SET $TMax = (SELECT endTime FROM vwTotalUsersGrid WHERE SwipeId = $Max LIMIT 1);
        
		SET $TMax = (CASE WHEN $edate >= $TMax THEN $TMax ELSE $edate END);
        
	
	
    IF $Min = $Max
    THEN 
		
        SET $tdiff = SEC_TO_TIME(TIMESTAMPDIFF(SECOND, $TMin, $TMax));
		
    ELSE
		SET $sdiff = SEC_TO_TIME(TIMESTAMPDIFF(SECOND, $TMin, (SELECT SwipOutTime FROM Swiping WHERE SwipeId = $Min)));
		-- end of calculating start time     
		SET $ediff = SEC_TO_TIME(TIMESTAMPDIFF(SECOND, (SELECT SwipInTime FROM Swiping WHERE SwipeId = $Max), $TMax));
		-- end of calculating end time 
		
		SET $tdiff = ADDTIME($sdiff, $ediff); -- > 1
	-- end of adding calculated start time to calculated end time
	END IF;
	-- calculate times in range excluding first record and last record which have been calculated before 
    
     
    SET $total = SEC_TO_TIME((SELECT SUM(total) FROM vwTotalUsersGrid WHERE organization_id = $userOrganization AND CardNumber = $userCard and ((endTime > $sdate AND startTime < $edate) OR (endTime IS NULL AND startTime < $edate)) AND SwipeId NOT IN ($Min, $Max) GROUP BY CardNumber)); -- > 2
	-- end of calculating times in range excluding first record and last record which have been calculated before 
    
	-- add 1 to 2
    SET $total = ADDTIME($tdiff, $total);
    -- end adding 1 to 2
    -- SELECT $TMin, $TMax, $sdiff, $ediff, $tdiff, $total;
ELSE 
	-- calculating start time
	SET $Min = (SELECT SwipeId FROM Swiping inner join Accountholder ac on Swiping.AccountholderId=ac.AccountholderId  WHERE ac.CardNumber = $userCard and Swiping.LocationId = $location_id AND  ((SwipOutTime > $sdate AND SwipInTime < $edate) OR (SwipOutTime IS NULL AND SwipInTime < $edate)) ORDER BY SwipInTime ASC LIMIT 1);
    
	-- add calculated start time to calculated end time
	SET $TMin = (SELECT startTime FROM vwTotalUsersGrid WHERE SwipeId = $Min LIMIT 1);
    
    SET $TMin = (CASE WHEN $sdate >= $TMin THEN $sdate ELSE $TMin END);
		
	-- calculating end time
	/*IF EXISTS (SELECT recordId FROM users WHERE location_id = $location_id AND user_card = $userCard and ((end_time > $sdate AND start_time < $edate) OR (end_time IS NULL AND start_time < $edate)) AND end_time IS NULL)
    THEN*/
	
		SET $Max = (select SwipeId FROM Swiping inner join Accountholder ac on Swiping.AccountholderId=ac.AccountholderId  WHERE ac.CardNumber = $userCard and Swiping.LocationId  = $location_id and ((SwipOutTime > $sdate AND SwipInTime < $edate) OR (SwipOutTime IS NULL AND SwipInTime < $edate)) /*AND end_time IS NULL*/ ORDER BY SwipInTime DESC LIMIT 1);
        
       -- SET $TMax = $edate;
       
 
		SET $TMax = (SELECT endTime FROM vwTotalUsersGrid WHERE SwipeId = $Max LIMIT 1);
        
		SET $TMax = (CASE WHEN $edate >= $TMax THEN $TMax ELSE $edate END);
	
	
    IF $Min = $Max
    THEN 
        SET $tdiff = SEC_TO_TIME(TIMESTAMPDIFF(SECOND, $TMin, $TMax));
		
    ELSE
		SET $sdiff = SEC_TO_TIME(TIMESTAMPDIFF(SECOND, $TMin, (SELECT SwipOutTime FROM Swiping WHERE SwipeId = $Min)));
		-- end of calculating start time     
		SET $ediff = SEC_TO_TIME(TIMESTAMPDIFF(SECOND, (SELECT SwipInTime FROM Swiping WHERE SwipeId = $Max), $TMax));
		-- end of calculating end time 
		
		SET $tdiff = ADDTIME($sdiff, $ediff); -- > 1
	-- end of adding calculated start time to calculated end time
	END IF;
	-- calculate times in range excluding first record and last record which have been calculated before 
    
    SET $total = SEC_TO_TIME((SELECT SUM(total) FROM vwTotalUsersGrid WHERE CardNumber = $userCard and organization_id = $userOrganization AND location_id = $location_id AND  ((endTime > $sdate AND startTime < $edate) OR (endTime IS NULL AND startTime < $edate)) AND SwipeId NOT IN ($Min, $Max) GROUP BY CardNumber)); -- > 2
	-- end of calculating times in range excluding first record and last record which have been calculated before 
    
	-- add 1 to 2
    SET $total = ADDTIME($tdiff, $total);
    -- end adding 1 to 2
    -- SELECT $TMin, $TMax, $sdiff, $ediff, $tdiff, $total;
END IF;
RETURN  IFNULL($total, $tdiff);
END;
