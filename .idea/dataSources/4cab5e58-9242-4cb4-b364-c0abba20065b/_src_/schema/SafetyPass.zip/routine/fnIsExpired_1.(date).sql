CREATE FUNCTION SafetyPass.fnIsExpired_1(`$ExpiryDate` DATE)
  RETURNS VARCHAR(15)
  BEGIN
DECLARE $EXP int;
DECLARE $Ret varchar(15);
if $ExpiryDate is null or $ExpiryDate =''  or ExpiryDate='0000-00-00' then return null;
else 
SET $EXP = DATEDIFF($ExpiryDate, CURDATE());
IF $EXP >= 30 then SET $Ret = 'NotExpired';
ELSEIF $EXP BETWEEN 0 AND 30 then SET $Ret = 'Expiring';
ELSEIF $EXP < 0  then SET $Ret = 'IsExpired';
ELSEIF $EXP IS NULL or $EXP = '' then SET $Ret = 'NotExpired';
END IF;
end if;
RETURN $Ret;
END;
