CREATE FUNCTION SafetyPass.fnGateOrgBlocked(pCardNumber VARCHAR(50), pLocationId VARCHAR(50))
  RETURNS TINYINT
  BEGIN
        declare vAcId VARCHAR(50) CHARACTER SET utf8 default NULL;
declare vEqId VARCHAR(50) CHARACTER SET utf8 default NULL;
        declare vOrgId VARCHAR(50) CHARACTER SET utf8 default NULL;
        DECLARE vOrgIdBlocked INT(6) default 0;
        set vAcId = (select AccountholderId from Accountholder where CardNumber=pCardNumber);
set vEqId = (select EquipmentId from Equipment where CardNumber=pCardNumber);
        if (vAcId is null and vEqId is null) then
            return 1;
        end if;
        
        set vOrgId = (SELECT OrgId FROM Accountholder WHERE CardNumber=pCardNumber);
if vOrgId is null then
	set vOrgId = (SELECT OwnerOrganization FROM Equipment WHERE CardNumber=pCardNumber);
end if;
        set vOrgIdBlocked = (select count(LocationOrgId) from LocationOrg where LocationId = pLocationId and PremittedOrgId = vOrgId);
        if (vOrgIdBlocked > 0 and vOrgIdBlocked is not null) then
            RETURN 1;
        end if;
        
        return 0;
    END;
