CREATE PROCEDURE SafetyPass.spGetEquipments(IN `$Search` VARCHAR(2000), IN `$Sidx` VARCHAR(50), IN `$Sord` VARCHAR(10),
                                            IN `$Strt`   INT, IN `$Lmt` INT)
  BEGIN
SET @qry = 'SELECT 
SQL_CALC_FOUND_ROWS
 *
FROM Equipment ';
SET @qryWhere = (CASE WHEN $Search IS NOT NULL AND $Search <> '' THEN CONCAT('
',$Search, '
') ELSE '
' END);
SET @qryLimit = CONCAT('ORDER BY ',$Sidx,' ',$Sord,' 
LIMIT ',$Strt,', ',$Lmt,' ;');
SET @qry = CONCAT(@qry, @qryWhere, @qryLimit);
PREPARE stmt FROM @qry;
EXECUTE stmt;
SELECT FOUND_ROWS();
DEALLOCATE PREPARE stmt;
END;
