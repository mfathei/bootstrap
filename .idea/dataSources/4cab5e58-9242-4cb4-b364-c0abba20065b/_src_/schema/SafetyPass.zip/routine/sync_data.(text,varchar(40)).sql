CREATE PROCEDURE SafetyPass.sync_data(IN `$xml_val` TEXT, IN pSource VARCHAR(40))
  BEGIN
DECLARE $TableName VARCHAR(100);
DECLARE $Position, $loopcnt INT;
	INSERT INTO sync_log 
	(sync_log_id, `table_name`, table_id1, table_id2, `action`, `xml`, `action_d`)
	VALUES
	(MyUUID(), $TableName, IFNULL(@PK1val, @PKval), @PK1val, 'UPDATE', $xml_val, curdate() );
SET $TableName = EXTRACTVALUE($xml_val, '//Table');
-- SET @lst_update = EXTRACTVALUE($xml_val, '//last_sync');
set @remote_last_update = EXTRACTVALUE($xml_val, '//last_update');
SET @time_zone = EXTRACTVALUE($xml_val, '//time_zone');
if pSource = 'server' then
    SET @SentDate =  CURRENT_TIMESTAMP(); -- CONVERT_TZ(@remote_last_update , @time_zone, getLocalTimeZone());
else
    SET @SentDate =  CONVERT_TZ(@remote_last_update , @time_zone, getLocalTimeZone());
end if;
SELECT $TableName;
SET @PK = (SELECT GROUP_CONCAT(`COLUMN_NAME` SEPARATOR ', ') FROM information_schema.`COLUMNS` where TABLE_SCHEMA = DATABASE() AND `TABLE_NAME` = $TableName AND COLUMN_KEY = 'PRI'); 
select @PK;
IF @PK LIKE '%, %'
THEN
	SET $Position = LOCATE(',',@PK);
	SET @PK1 = (SELECT LEFT(@PK, $Position - 1));
	SET @PK1val = EXTRACTVALUE($xml_val, CONCAT('//', @PK1));
	-- SET @PK2 = (SELECT RIGHT(@PK, $Position - 1));
	SET @PK2 = (SELECT SUBSTRING(@PK, $Position + 1));
	SET @PK2val = EXTRACTVALUE($xml_val, CONCAT('//', @PK2));
	SET @WhereCluse = CONCAT(' WHERE ', @PK1, ' = '', @PK1val, '' AND ', @PK2, ' = '', @PK2val,''');
	-- SELECT @WhereCluse;
ELSE 
	SET @PKval = EXTRACTVALUE($xml_val, CONCAT('//', @PK));
	SET @WhereCluse = CONCAT(' WHERE ', @PK, ' = '', @PKval,''');
	-- SELECT @WhereCluse;
END IF;
SET @qry = (SELECT CONCAT('SELECT last_update INTO @updated FROM `',`TABLE_SCHEMA`,'`.`',`TABLE_NAME`,'` ',@WhereCluse,'') FROM information_schema.`TABLES` WHERE `TABLE_SCHEMA` = DATABASE() AND `TABLE_NAME` = $TableName);
SELECT @qry;
PREPARE stmt FROM @qry;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
SET @Cols = (SELECT GROUP_CONCAT(`COLUMN_NAME` SEPARATOR ',') FROM information_schema.`COLUMNS` WHERE `TABLE_SCHEMA` = DATABASE() AND `TABLE_NAME` = $TableName);
select @Cols;
IF @updated is not null -- UPDATE
THEN
select @updated,@SentDate;
    if @updated < @SentDate
    then
        SET $loopcnt = 1;
        SET @Cols = CONCAT(@Cols, ',');
        SET @SETClause = ' SET ';	
        SET $POSITION = LOCATE(',', @Cols);
        WHILE ( $POSITION > 0 ) DO
            SET @STR = SUBSTRING(@Cols, 1, $POSITION - 1);
            SET @STR= TRIM(@STR);
            SET @Cols = SUBSTRING(@Cols, $POSITION + 1);
            SET @Col =  EXTRACTVALUE($xml_val, CONCAT('//',@STR));
            
                    
            IF @Col = '' THEN
                SET @Col = 'NULL';
            END IF;
            
            SET @Col = REPLACE(@Col,''','\'') ;-- check_column_value(@STR, @Col);
            
            IF @STR = 'last_update' THEN
                SET @Col = @SentDate;
            END IF;
            
            IF $loopcnt = 1
            THEN
                SET @SETClause = CONCAT(@SETClause, '`',@STR ,'` = ', ''',@Col,'' ');
            ELSE 
                SET @SETClause = CONCAT(@SETClause, ', `', @STR ,'` = ', ''',@Col,'' ');
            END IF;
            SET $POSITION = LOCATE(',', @Cols);
            SET $loopcnt = $loopcnt + 1;
        END WHILE;
        SELECT @SETClause, @WhereCluse;
        SET @qryUPDATE = (SELECT CONCAT('UPDATE `',`TABLE_SCHEMA`,'`.`',`TABLE_NAME`,'` ', @SETClause,' ',@WhereCluse,' ;') FROM information_schema.`TABLES` WHERE `TABLE_SCHEMA` = DATABASE() AND `TABLE_NAME` = $TableName);
        SET @qryUPDATE = REPLACE(@qryUPDATE,  ' = 'NULL' ', ' = NULL');
        SELECT @qryUPDATE;
        PREPARE stmtUPD FROM @qryUPDATE;
        EXECUTE stmtUPD;
        DEALLOCATE PREPARE stmtUPD;
        /**
        INSERT INTO sync_log 
        (sync_log_id, `table_name`, table_id1, table_id2, `action`, `action_d`)
        VALUES
        (MyUUID(), $TableName, IFNULL(@PK1val, @PKval), @PK1val, 'UPDATE', curdate() );
        */
    end if;
	
ELSE -- INSERT
	SET $loopcnt = 1;
	SET @Cols = CONCAT(@Cols, ',');
	SET @ColNames = CONCAT('(', @Cols,')');
	SET @VALClause = ' VALUES (';	
	SET $Position = LOCATE(',', @Cols);
	SET @ColNames = (SELECT CONCAT('(',GROUP_CONCAT(concat('`',`COLUMN_NAME`,'`') SEPARATOR ','), ')') FROM information_schema.`COLUMNS` WHERE `TABLE_SCHEMA` = DATABASE() AND `TABLE_NAME` = $TableName);
	WHILE ( $Position > 0 ) DO
		SET @STR = SUBSTRING(@Cols, 1, $Position - 1);
		SET @STR= TRIM(@STR);
		SET @Cols = SUBSTRING(@Cols, $Position + 1);
		SET @Col =  extractvalue($xml_val, CONCAT('//',@STR));
        
        if @Col = '' then
			set @Col = 'NULL';
        end if;
        
		SET @Col = REPLACE(@Col,''','\'') ;-- check_column_value(@STR, @Col);
		
		IF @STR = 'last_update' THEN
            SET @Col = @SentDate;
		END IF;
		
        IF $loopcnt = 1
		THEN
			SET @VALClause = CONCAT(@VALClause, ''',@Col,'' ');
			-- SET @ColNames = CONCAT(@ColNames, '`',@STR,'`');
		ELSE 
			SET @VALClause = CONCAT(@VALClause, ', '',@Col,'' ');
		END IF;
		SET $Position = LOCATE(',', @Cols);
		SET $loopcnt = $loopcnt + 1;
	END WHILE;
	-- SET @VALClause = REPLACE(@VALClause, '''', NULL);
	SET @qryINSERT = (SELECT CONCAT('INSERT INTO `',`TABLE_SCHEMA`,'`.`',`TABLE_NAME`,'`',@ColNames,' ',@VALClause,');') FROM information_schema.`TABLES` WHERE `TABLE_SCHEMA` = DATABASE() AND `TABLE_NAME` = $TableName);
	SET @qryINSERT = REPLACE(@qryINSERT, ' 'NULL' ', ' NULL');
	SELECT @qryINSERT;
	SET FOREIGN_KEY_CHECKS = 0;
	PREPARE stmtINS FROM @qryINSERT;
	EXECUTE stmtINS;
	DEALLOCATE PREPARE stmtINS;
	SET FOREIGN_KEY_CHECKS = 1;
	/** INSERT INTO sync_log 
	(sync_log_id, `table_name`, table_id1, table_id2, `action`, `action_d`)
	VALUES
	(MyUUID(), $TableName, IFNULL(@PK1val, @PKval), @PK1val, 'INSERT', curdate() );**/
END IF;
END;
