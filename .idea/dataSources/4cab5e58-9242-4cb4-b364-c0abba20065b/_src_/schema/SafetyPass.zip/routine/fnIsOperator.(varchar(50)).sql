CREATE FUNCTION SafetyPass.fnIsOperator(`$user_card` VARCHAR(50))
  RETURNS INT
  BEGIN
    DECLARE $result INT default 0 ;
	set @operatorRole = (select RoleId from Role where RoleCode = 'sp_user');
    set @aid = (select AccountholderId from Accountholder where CardNumber=$user_card);
    
    set $result = (select count(AccountholderId) from AccountholderRole where AccountholderId = @aid and RoleId = @operatorRole);
    
    RETURN $result ;
END;
