CREATE PROCEDURE SafetyPass.GateCheckEquipmentStatus(IN pCardNumber VARCHAR(50), IN pLocationId VARCHAR(50))
  begin
    SET @accid = (SELECT EquipmentId FROM Equipment WHERE CardNumber = pCardNumber );
    IF @accid IS NULL THEN -- check cardNumber is wrong
		SET @result = 'notAuthorized';
        select '1' as isBlocked,@result as missedCerts,@result AS expiredCerts;    
    else -- if cardNumber is correct
		SET @statf = (SELECT SwipeId FROM Swiping INNER JOIN Equipment ON(Swiping.EquipmentId = Equipment.EquipmentId AND Equipment.CardNumber = pCardNumber) WHERE Swiping.`LocationId` = pLocationId AND Swiping.`SwipOutTime` IS NULL);
        if @statf is not null then  SELECT 'SwipedIn' AS isBlocked,NULL AS missedCerts,NULL AS expiredCerts;
         else 
          set @orgBlocked = fnGateOrgBlocked(pCardNumber,pLocationId);
          if (@orgBlocked = 1) then -- check user OrgId is blocked in table LocationOrg
             SELECT '1' AS isBlocked,NULL AS missedCerts,NULL AS expiredCerts;
          else -- if user OrgId is not blocked in table LocationOrg
              SET @stat = (SELECT SwipeId FROM Swiping INNER JOIN Equipment ON(Swiping.EquipmentId = Equipment.EquipmentId AND Equipment.CardNumber = pCardNumber) WHERE Swiping.`LocationId` = pLocationId AND Swiping.`SwipOutTime` IS NULL);
             IF @stat IS NULL THEN
                SELECT fnGateInBlackList(pCardNumber) AS isBlocked,GateEqMissedCertsCommaSeparated(pLocationId, @accid) AS missedCerts,GateEqExpiredCertsCommaSeparated(pLocationId, @accid) AS expiredCerts;
             -- ELSE    
                -- SELECT 'SwipedIn' AS isBlocked,NULL AS missedCerts,NULL AS expiredCerts;
             END IF;
          end if; 
		end if ;
    END IF; 
end;
