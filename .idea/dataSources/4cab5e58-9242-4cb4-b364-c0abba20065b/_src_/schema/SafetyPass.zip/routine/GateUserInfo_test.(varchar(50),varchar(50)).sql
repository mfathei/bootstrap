CREATE PROCEDURE SafetyPass.GateUserInfo_test(IN `$location_id` VARCHAR(50), IN `$card_id` VARCHAR(50))
  BEGIN
	SET SESSION group_concat_max_len = 1000000;
    SELECT 
        `Accountholder`.`AccountholderId` AS `Accountholder_id`,
        `Accountholder`.`FName` AS `fname`,
        `Accountholder`.`LName` AS `lname`,
        `Organization`.`PresentationName` AS `presenation_name`,
		`Role`.`RoleName` AS `role_name`,
        `Accountholder`.`CardNumber` AS `card_id`,
        `Accountholder`.`Password` AS `password`,
        `Blacklist`.`BlacklistId` AS `id` 
    FROM
        (
            `Accountholder` 
            LEFT JOIN `Organization` 
                ON (
                    `Accountholder`.`OrgId` = `Organization`.`OrgId`
                ) 
            LEFT JOIN `AccountholderRole` 
                ON (
                    `Accountholder`.`AccountholderId` = `AccountholderRole`.`AccountholderId`
                ) 
            LEFT JOIN `Role` 
                ON (
                    `AccountholderRole`.`RoleId` = `Role`.`RoleId`
                ) 
            LEFT JOIN `Blacklist` 
                ON (
                    `Blacklist`.`AccountholderId` = `Accountholder`.`AccountholderId` 
                    AND Blacklist.LocationId = $location_id
                )
        ) 
    WHERE `Accountholder`.`CardNumber` = $card_id ;
END;
