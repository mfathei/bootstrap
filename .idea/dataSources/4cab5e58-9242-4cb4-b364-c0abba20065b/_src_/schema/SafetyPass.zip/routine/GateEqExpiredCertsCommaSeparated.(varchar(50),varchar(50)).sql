CREATE FUNCTION SafetyPass.GateEqExpiredCertsCommaSeparated(pLocationId VARCHAR(50), pEquipmentId VARCHAR(50))
  RETURNS TEXT
  BEGIN
  DECLARE result TEXT character set utf8;
  SET SESSION group_concat_max_len = 1000000;
  SET result = 
  (     
    -- expired certs
    SELECT GROUP_CONCAT(c.`CertificateName` separator ",") as expiredCerts FROM OrgCategoryEquipCert occ
    INNER JOIN Location l ON(occ.OrgId = l.OrgId AND l.`LocationId` = pLocationId)
    INNER JOIN `LocationCategory` lc ON(l.LocationId = lc.LocationId AND occ.CategoryId = lc.CategoryId)
    INNER JOIN Category cg ON(occ.CategoryId = cg.CategoryId)
    INNER JOIN CertificateForEquipment c ON(c.`CertificateId` = occ.`CertificateId`)
    INNER JOIN `EquipmentCertificate` aci ON(aci.`CertificateId` = c.`CertificateId` and aci.CertificateStatus = 'Approved')
    AND aci.`EquipmentId` = pEquipmentId 
    AND aci.`ExpiryDate` IS NOT NULL  
    AND aci.`ExpiryDate` <= NOW()
    AND aci.`ExpiryDate` <> '3000-00-00'
  );
  
  RETURN result;
END;
