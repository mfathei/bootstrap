CREATE PROCEDURE SafetyPass.spBulkSkill(IN `$AccountholderId` VARCHAR(50), IN `$PicNames` VARCHAR(50))
  BEGIN
DECLARE $InvalidPicName TEXT;
DECLARE $Man,$opt,$Verifier,$Training VARCHAR(50);
declare ai int;
declare ending int default 0;
declare edate,vdate varchar(50);
declare expire_curs cursor for select ImportSkillId,ExpiryDate,VerifiedDate from ImportSkill;
declare continue handler for not found set ending =1;
SET $Man = '';
SET $opt = '';
SET $InvalidPicName = fnBulkUploadSkillCheckPics($PicNames);
/*
DECLARE $ImportSkillId VARCHAR(50);
SET $ImportSkillId = MyUUID();
*/
	IF EXISTS (SELECT * FROM ImportSkill WHERE (TrainingName IS NULL OR TrainingName = ''))
		THEN SET $Man = 'TrainingName';
	END IF;
	IF EXISTS (SELECT * FROM ImportSkill WHERE (SkillDescription IS NULL OR SkillDescription = ''))
		THEN SET $Man = CONCAT($Man, 'SkillDescription',',');
	END IF;
	IF EXISTS (SELECT * FROM ImportSkill WHERE (TrainingOrg IS NULL OR TrainingOrg = '' OR TrainingOrg = '' OR TrainingOrg NOT IN (SELECT O.PresentationName from Organization `O`)))
		THEN SET $Man = CONCAT($Man, 'TrainingOrg',',');
	END IF;
	IF EXISTS (SELECT * FROM ImportSkill WHERE (DateAcquired IS NULL OR DateAcquired='' or (select IsDate(DateAcquired))=1))
		THEN SET $Man = CONCAT($Man,'DateAcquired',',');
	END IF;
	IF EXISTS (SELECT * FROM ImportSkill WHERE ((VerifiedDate IS NULL OR VerifiedDate='' or (select IsDate(VerifiedDate))=1)and (Verifier is not null and Verifier!='')))
		THEN SET $Man = CONCAT($Man,'VerifiedDate',','); 
	END IF;
    IF EXISTS (SELECT * FROM ImportSkill WHERE ((DateAcquired is not null and (select IsDate(DateAcquired))=2) and  (ExpiryDate IS not NULL and (select IsDate(ExpiryDate))=2)   and  date(ExpiryDate)  <  date(DateAcquired)))
		THEN SET $Man = CONCAT($Man,'ExpiryDate',','); 
	end if;
IF $Man IS NOT NULL AND $Man != ''
THEN
	SELECT  'Issues In Mandatory Fields' AS OperationStatus, COUNT(*) AS RecordCount, GROUP_CONCAT(DISTINCT ImportSkillId SEPARATOR ',' ) AS RecordLines, $Man AS FieldStatus FROM ImportSkill `I` WHERE (TrainingName IS NULL OR TrainingName = '') OR (SkillDescription IS NULL OR SkillDescription = '') OR (TrainingOrg IS NULL OR TrainingOrg = '') OR (DateAcquired IS NULL or DateAcquired=''  or (select IsDate(DateAcquired))=1) OR (VerifiedDate IS NULL or VerifiedDate=''  or (select IsDate(VerifiedDate))=1)or(ExpiryDate IS  not NULL and ExpiryDate < DateAcquired) or(( VerifiedDate is null  or VerifiedDate =''  or(select IsDate(VerifiedDate))=1 )and(Verifier is not null)) or ((DateAcquired is not null and (select IsDate(DateAcquired))=2) and  (ExpiryDate IS not NULL and (select IsDate(ExpiryDate))=2)   and  date(ExpiryDate)  <  date(DateAcquired)) ;
    TRUNCATE ImportSkill;
ELSEIF (SELECT COUNT(*) FROM ImportSkill) > 0
THEN
	-- Check optional columns and Photos
IF EXISTS (SELECT * FROM ImportSkill WHERE (Instructor IS NULL OR Instructor = ''))
		THEN SET $opt = 'Instructor';
END IF;
IF EXISTS (SELECT * FROM ImportSkill `I` WHERE(( I.Verifier is not null and  I.Verifier !='') and  I.Verifier NOT IN (SELECT O.PresentationName from Organization `O`)))
		THEN SET $opt = CONCAT($opt, ', ', 'Verifier');
        UPDATE ImportSkill SET Verifier = NULL WHERE Verifier NOT IN (SELECT PresentationName from Organization );
          else if exists(SELECT * FROM ImportSkill `I` WHERE(( I.Verifier is null and  I.Verifier !='') and  I.Verifier NOT IN (SELECT O.PresentationName from Organization `O`))) 
          then 
          UPDATE ImportSkill SET Verifier = NULL WHERE Verifier NOT IN (SELECT PresentationName from Organization );
          END IF;
end if; 
IF EXISTS (SELECT * FROM ImportSkill WHERE (select IsDate(VerifiedDate))=1 )then SET $opt = CONCAT($opt, ', ', 'VerifiedDate');end if;
IF EXISTS (SELECT * FROM ImportSkill WHERE (select IsDate(ExpiryDate))=1 )then SET $opt = CONCAT($opt, ', ', 'ExpiryDate');end if;


IF EXISTS (SELECT * FROM ImportSkill WHERE (ExpiryDate IS NULL OR ExpiryDate = '') or( VerifiedDate ='') or ((select IsDate(ExpiryDate))=1 ) or ((select IsDate(VerifiedDate))=1 ))
		THEN 
        open expire_curs;
        curs:loop
        fetch expire_curs into ai,edate,vdate;
        if ending =1  then leave curs; end if;
        if  edate =''  or (select IsDate(edate))=1 then update ImportSkill set ExpiryDate = null where ImportSkillId=ai; end if ;
		if  vdate ='' or (select IsDate(vdate))=1  then update ImportSkill set VerifiedDate = null where ImportSkillId=ai; end if ;
        end loop;close expire_curs; 
END IF;
       
IF ($opt IS NOT NULL AND $opt != '' ) OR $InvalidPicName NOT LIKE 'In DB but Not in ZIP File: '
	THEN
	SELECT 'Issues in Optional Fields' AS OperationStatus, COUNT(ImportSkillId) AS RecordCount, GROUP_CONCAT(DISTINCT ImportSkillId SEPARATOR ',' ) AS RecordLines,$opt AS FieldStatus, $InvalidPicName AS PhotoStatus FROM ImportSkill `I` WHERE I.Verifier NOT IN (SELECT O.PresentationName from Organization `O`) OR (Instructor IS NULL OR Instructor = '') OR Photo IS NULL or (select IsDate(VerifiedDate))=1 or (select IsDate(ExpiryDate))=1;
END IF;

    SET $Verifier = (SELECT OrgId FROM Organization `o` JOIN ImportSkill `I` ON `o`.PresentationName = `I`.Verifier limit 1 );
    SET $Training = (SELECT OrgId FROM Organization `o` JOIN ImportSkill `I` ON `o`.PresentationName = `I`.TrainingOrg limit 1);
    
	INSERT INTO Training
    (`TrainingId`,`AccountholderId`,`TrainingName`, `Description`, `TrainingOrgName`, `TrainingOrgId`, `InstructorName`, `DateAcquired`, `ExpiryDate`, `VerifiedById`, `CertificatePhoto`,`VerifiedDate`)
    SELECT
    MyUUID(), $AccountholderId, `TrainingName`, `SkillDescription`, `TrainingOrg`, $Training, `Instructor`, `DateAcquired`, `ExpiryDate`, $Verifier,  `Photo`,`VerifiedDate`FROM ImportSkill;
	SELECT  'Operation Successfull!' AS OperationStatus, COUNT(*) AS RecordCount, GROUP_CONCAT(DISTINCT ImportSkillId SEPARATOR ',' ) AS RecordLines FROM ImportSkill `I` ;
    TRUNCATE ImportSkill;
END IF;
END;
