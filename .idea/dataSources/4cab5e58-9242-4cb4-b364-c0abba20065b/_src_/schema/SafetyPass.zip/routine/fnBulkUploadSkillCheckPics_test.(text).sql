CREATE FUNCTION SafetyPass.fnBulkUploadSkillCheckPics_test(`$PicNames` TEXT)
  RETURNS TEXT
  BEGIN
DECLARE $Ret, $PicNamesQ TEXT;
DECLARE pname varchar(255);
declare ending int default 0;
declare ai int;
declare bic_cur cursor for select ImportSkillId ,Photo from ImportSkill;
declare continue handler for not found set ending =1;
SET $Ret = 'In DB but Not in ZIP File: ';
SET @PicNamesQ = $PicNames;
/* SET $Cnt = (SELECT COUNT(*) FROM ImportSkill);
SET $Counter = 1;
PicCHKLoop: WHILE $Counter <= $Cnt
DO
	SET $ProfilePic = CONCAT('%',(SELECT Photo FROM ImportSkill WHERE ImportSkillId = $Counter),'%');
    
    IF $PicNamesQ NOT LIKE $ProfilePic
    THEN
		SET $Ret = CONCAT($Ret, TRIM(BOTH '%' FROM $ProfilePic),', ');
        UPDATE ImportSkill SET Photo = NULL WHERE ImportSkillId = $Counter;
    END IF;
    
	SET $Counter = $Counter + 1;
END WHILE;
RETURN $Ret;
*/
open  bic_cur;
curs:loop
fetch bic_cur into ai,pname ;
if ending =1 then leave curs; end if;
if  @PicNamesQ not like '%pname%'
then 
SET $Ret = CONCAT($Ret,pname,', ');
UPDATE ImportSkill SET Photo = NULL WHERE ImportSkillId = ai;
 end if;
end loop;
close bic_cur;
RETURN $Ret;
END;
