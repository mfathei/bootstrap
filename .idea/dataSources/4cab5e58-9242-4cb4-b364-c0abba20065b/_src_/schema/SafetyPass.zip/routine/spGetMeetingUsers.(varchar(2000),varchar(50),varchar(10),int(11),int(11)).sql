CREATE PROCEDURE SafetyPass.spGetMeetingUsers(IN `$Search` VARCHAR(2000), IN `$Sidx` VARCHAR(50),
                                              IN `$Sord`   VARCHAR(10), IN `$Strt` INT, IN `$Lmt` INT)
  BEGIN
SET @qry = 'SELECT SQL_CALC_FOUND_ROWS * FROM 
		(select ah.CardNumber,ah.AccountholderId,ah.OrgId,ah.`FName`,ah.`LName`,m.`MeetingTitle`,m.`MeetingSupervisor`,m.`MeetingDate`, l.`LocationName`,o.`PresentationName` AS `Company`,sm.`InTime`,sm.`SafetyMeetingId`,'User' AS `type`
from Accountholder ah inner join SafetyMeetingUser sm
ON (ah.`AccountholderId` = sm.`AccountholderId`) 
INNER JOIN SafetyMeeting m
ON (sm.`SafetyMeetingId` = m.`SafetyMeetingId`) 
INNER JOIN Location l
ON (m.`LocationId` = l.`LocationId`) 
INNER JOIN Organization o
ON (ah.`OrgId` = o.`OrgId`)
where (sm.`OutTime` is null or sm.`OutTime` = 0)) tbl ';
SET @qryWhere = (CASE WHEN $Search IS NOT NULL AND $Search <> '' THEN CONCAT('
',$Search, '
') ELSE '
' END);
SET @qryLimit = CONCAT(' ORDER BY ',$Sidx,' ',$Sord,' 
LIMIT ',$Strt,', ',$Lmt,' ;');
SET @qry = CONCAT(@qry, @qryWhere, @qryLimit);
PREPARE stmt FROM @qry;
EXECUTE stmt;
SELECT FOUND_ROWS();
DEALLOCATE PREPARE stmt;
END;
