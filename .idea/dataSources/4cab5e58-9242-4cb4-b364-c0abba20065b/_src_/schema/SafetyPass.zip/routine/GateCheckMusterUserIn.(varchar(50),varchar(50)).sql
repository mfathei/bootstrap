CREATE FUNCTION SafetyPass.GateCheckMusterUserIn(`$user_card` VARCHAR(50), `$location_id` VARCHAR(50))
  RETURNS VARCHAR(50)
  BEGIN
    DECLARE $result VARCHAR (50) ;
    DECLARE $record_id VARCHAR (50) ;
    DECLARE $swiped_in VARCHAR (50) ;
    SET $swiped_in = 
    (SELECT 
        SwipeId 
    FROM
        Swiping 
        INNER JOIN Accountholder 
            ON (
                Swiping.AccountholderId = Accountholder.AccountholderId 
                AND Accountholder.CardNumber = $user_card
            ) 
    WHERE Swiping.`LocationId` = $location_id 
        AND Swiping.`SwipOutTime` IS NULL limit 1) ;
        
    if ($swiped_in is null) then
        SET $result = 'Not Swiped In Location' ;
        RETURN $result ;
    end if;
        
    SET $record_id = 
    (SELECT 
        SwipeId 
    FROM
        MusterSwiping 
        inner join Accountholder 
            on (
                MusterSwiping.AccountholderId = Accountholder.AccountholderId 
                AND Accountholder.CardNumber = $user_card
            ) 
    WHERE MusterSwiping.`LocationId` = $location_id 
        AND MusterSwiping.`SwipOutTime` IS NULL) ;
    IF $record_id IS NULL 
    THEN 
        INSERT INTO MusterSwiping (
            SwipeId,
            AccountholderId,
            LocationId,
            SwipInTime,
            SwipOutTime,
            IsOperator,
            LastUpdate
        ) 
        select 
            MyUUID(),
            AccountholderId,
            $location_id,
            NOW(),
            NULL,
            0,
            NOW()
        from
            Accountholder 
        where CardNumber = $user_card ;
        
        SET $result = 'Swiped In MusterSwiping' ;
    
    ELSE 
        delete
        FROM
            MusterSwiping where SwipeId = $record_id;
        SET $result = 'Swiped Out MusterSwiping' ;
        
    END IF ;
    RETURN $result ;
END;
