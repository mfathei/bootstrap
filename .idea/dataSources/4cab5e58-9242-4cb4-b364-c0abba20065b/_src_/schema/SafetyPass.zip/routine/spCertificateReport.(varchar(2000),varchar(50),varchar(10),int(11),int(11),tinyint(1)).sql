CREATE PROCEDURE SafetyPass.spCertificateReport(IN `$Search` VARCHAR(2000), IN `$Sidx` VARCHAR(50),
                                                IN `$Sord`   VARCHAR(10), IN `$Strt` INT, IN `$Lmt` INT,
                                                IN `$export` TINYINT(1))
  BEGIN
SET @qry = 'SELECT 
	SQL_CALC_FOUND_ROWS  * from vwCertificateReport ';
SET @qryWhere = (CASE WHEN $Search IS NOT NULL AND $Search <> '' THEN CONCAT('
',$Search, '
') ELSE '
' END);
SET @qrysort = CONCAT('ORDER BY ',$Sidx,' ',$Sord);
SET @qryLimit = CONCAT(' LIMIT ', $Lmt ,' OFFSET ',  $Strt);
SET @qry = CONCAT(@qry, @qryWhere, @qrysort);
IF($export = '0') THEN
SET @qry = CONCAT(@qry,'
', @qryLimit);
END IF;
PREPARE stmt FROM @qry;
EXECUTE stmt;
IF($export = '0') THEN
SELECT FOUND_ROWS();
END IF;
DEALLOCATE PREPARE stmt;
END;
