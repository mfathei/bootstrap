CREATE FUNCTION SafetyPass.fnValidateLogin(`$CardNumber` BIGINT, `$UserPassword` VARCHAR(255))
  RETURNS INT
  BEGIN
DECLARE $Ret INT(1);
IF EXISTS (SELECT * FROM Accountholder WHERE CardNumber = $CardNumber AND `Password` = $UserPassword)
THEN
	IF EXISTS (SELECT * FROM Accountholder WHERE CardNumber = $CardNumber AND `Password` = $UserPassword AND IsActive = 1)
	THEN
		SET $Ret = 1;
	ELSE
		SET $Ret = 2;
	END IF;
ELSE
	SET $Ret = 0;
END IF;
RETURN $Ret;
END;
