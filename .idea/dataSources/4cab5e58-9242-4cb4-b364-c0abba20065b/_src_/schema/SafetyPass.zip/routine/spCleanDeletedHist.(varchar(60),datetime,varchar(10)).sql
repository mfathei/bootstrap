CREATE PROCEDURE SafetyPass.spCleanDeletedHist(IN pTableName VARCHAR(60), IN pLast_update DATETIME,
                                               IN pTimeZone  VARCHAR(10))
  BEGIN
	set @local_t = convert_tz(pLast_update, pTimeZone, getLocalTimeZone());
	DELETE from delete_hist where `table_name` = pTableName and last_update <= @local_t;
    select 'DONE' as result;
end;
