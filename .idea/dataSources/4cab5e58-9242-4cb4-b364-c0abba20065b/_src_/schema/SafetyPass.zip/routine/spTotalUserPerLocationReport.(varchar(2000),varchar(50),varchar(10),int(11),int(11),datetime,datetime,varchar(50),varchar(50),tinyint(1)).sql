CREATE PROCEDURE SafetyPass.spTotalUserPerLocationReport(IN `$search` VARCHAR(2000), IN `$sidx` VARCHAR(50),
                                                         IN `$sord`   VARCHAR(10), IN `$strt` INT, IN `$lmt` INT,
                                                         IN `$sdate`  DATETIME, IN `$edate` DATETIME,
                                                         IN `$org_id` VARCHAR(50), IN `$location_id` VARCHAR(50),
                                                         IN `$export` TINYINT(1))
  BEGIN
DECLARE $cnt INT;
SET @qry = CONCAT('SELECT 
			SQL_CALC_FOUND_ROWS
			s.SwipeId ,    
		    ac.CardNumber ,
		    s.SwipInTime ,
		    s.SwipOutTime ,
		    l.LocationId ,
			ac.AccountholderId ,
			ac.FName ,
			ac.LName,
			timecalc(sum(fnMan_Hour_Test(s.SwipInTime,s.SwipOutTime,'', $sdate,'', '',$edate,''))) AS man_hours, 
            r.RoleDescription ,
			o.PresentationName ');
SET @qryFrom = (' from Swiping s 
                      join Accountholder  ac on ac.AccountholderId=s.AccountholderId 
					  join Location l on l.LocationId=s.LocationId
					  join Organization o on o.OrgId=ac.OwnerOrgId
                      join AccountholderRole ar on ac.AccountholderId=ar.AccountholderId 
                      join Role r on r.RoleId=ar.RoleId 
');
SET @qryWhere = CONCAT(' where(o.OrgId='',$org_id,'' and  (case when '', $location_id,'' ='' or '', $location_id,''='All' or  '',$location_id,'' is null then s.LocationId in  (select LocationId  from Location where OrgId='', $org_id,'' ) else s.LocationId='', $location_id ,'' end))');
SET @qryWhere = CONCAT(@qryWhere, ' ', (CASE WHEN $search IS NOT NULL AND $search != '' THEN $search ELSE '' END),'
');
SET @qryGrpHav = (' group by ac.CardNumber HAVING man_hours > 0 
');
SET @qrySort = CONCAT('ORDER BY ',$sidx,' ',$sord);
SET @qryLimit = CONCAT(' 
LIMIT ', $lmt ,' OFFSET ',  $strt);
SET @qry = CONCAT(@qry, @qryFrom, @qryWhere, @qryGrpHav, @qrySort);
if($export = '0') then
SET @qry = CONCAT(@qry, @qryLimit);
end if;
PREPARE stmt1 FROM @qry;
EXECUTE stmt1;
if($export = '0') then
SELECT FOUND_ROWS();
end if;
DEALLOCATE PREPARE stmt1;
end;
