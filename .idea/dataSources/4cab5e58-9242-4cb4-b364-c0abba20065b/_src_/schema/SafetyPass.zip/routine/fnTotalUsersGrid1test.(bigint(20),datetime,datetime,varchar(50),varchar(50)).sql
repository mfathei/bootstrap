CREATE FUNCTION SafetyPass.fnTotalUsersGrid1test(`$userCard`         BIGINT, `$sdate` DATETIME, `$edate` DATETIME,
                                                 `$userOrganization` VARCHAR(50), `$location_id` VARCHAR(50))
  RETURNS TIME
  BEGIN
DECLARE $TMin, $TMax, $endTime DATETIME; -- times 
DECLARE $Min, $Max VARCHAR(50); -- Ids
DECLARE $total, $sdiff, $ediff, $tdiff TIME;
IF $location_id IS NULL OR $location_id = '' 
THEN  
	-- calculating start time
	SET $Min = (SELECT SwipeId FROM  Swiping s INNER JOIN Location l ON s.LocationId = l.LocationId  inner join Accountholder ac on ac.AccountholderId=s.AccountholderId  WHERE  ac.CardNumber = $userCard and  l.OrgId = $userOrganization  and ((s.SwipOutTime > $sdate AND s.SwipInTime < $edate) OR (s.SwipOutTime IS NULL AND s.SwipInTime < $edate)) ORDER BY s.SwipInTime ASC LIMIT 1);
    
	-- add calculated start time to calculated end time
	SET $TMin = (SELECT vwSwipInTime FROM vwTotalUsersGrid WHERE vwSwipeId = $Min LIMIT 1);
    
    SET $TMin = (CASE WHEN $sdate >= $TMin THEN $sdate ELSE $TMin END);
		
	-- calculating end time
/*	IF EXISTS (SELECT recordId FROM users tbl1 INNER JOIN location tbl2 ON tbl1.location_id = tbl2.location_id WHERE tbl2.organization_id = $userOrganization AND user_card = $userCard and ((end_time > $sdate AND start_time < $edate) OR (end_time IS NULL AND start_time < $edate)) AND end_time IS NULL)
    THEN*/
	
		SET $Max = (SELECT s.SwipeId FROM Swiping s INNER JOIN Location l ON s.LocationId = l.LocationId  inner join Accountholder ac on ac.AccountholderId=s.AccountholderId  WHERE l.OrgId = $userOrganization AND ac.CardNumber = $userCard and ((s.SwipOutTime > $sdate AND s.SwipInTime < $edate) OR (s.SwipOutTime IS NULL AND s.SwipInTime < $edate))/* AND end_time IS NULL*/ ORDER BY s.SwipInTime DESC LIMIT 1);
        
       -- SET $TMax = $edate;
        
		SET $TMax = (SELECT vwSwipInTime FROM vwTotalUsersGrid WHERE vwSwipeId = $Max LIMIT 1);
        
		SET $TMax = (CASE WHEN $edate >= $TMax THEN $TMax ELSE $edate END);
        
	/*ELSE 
		SET $Max = (SELECT recordId FROM users tbl1 INNER JOIN location tbl2 ON tbl1.location_id = tbl2.location_id WHERE tbl2.organization_id = $userOrganization AND user_card = $userCard and ((end_time > $sdate AND start_time < $edate) OR (end_time IS NULL AND start_time < $edate)) ORDER BY end_time DESC LIMIT 1);
        
		SET $TMax = (SELECT endTime FROM vwTotalUsersGrid WHERE recordId = $Max);
        
		SET $TMax = (CASE WHEN $edate >= $TMax THEN $TMax ELSE $edate END);
    
	END IF;*/
	
    IF $Min = $Max
    THEN 
		
        SET $tdiff = SEC_TO_TIME(TIMESTAMPDIFF(SECOND, $TMin, $TMax));
		
    ELSE
		SET $sdiff = SEC_TO_TIME(TIMESTAMPDIFF(SECOND, $TMin, (SELECT s.SwipOutTime FROM Swiping s WHERE s.SwipeId = $Min)));
		-- end of calculating start time     
		SET $ediff = SEC_TO_TIME(TIMESTAMPDIFF(SECOND, (SELECT s.SwipInTime FROM Swiping s WHERE s.SwipeId = $Max), $TMax));
		-- end of calculating end time 
		
		SET $tdiff = ADDTIME($sdiff, $ediff); -- > 1
	-- end of adding calculated start time to calculated end time
	END IF;
	-- calculate times in range excluding first record and last record which have been calculated before 
    
     
    SET $total = SEC_TO_TIME((SELECT SUM(total) FROM vwTotalUsersGrid WHERE vwOrgId = $userOrganization AND vwCardNumber = $userCard and ((vwSwipOutTime > $sdate AND vwSwipInTime < $edate) OR (vwSwipOutTime IS NULL AND vwSwipInTime < $edate)) AND vwSwipeId NOT IN ($Min, $Max) GROUP BY vwCardNumber)); -- > 2
	-- end of calculating times in range excluding first record and last record which have been calculated before 
    
	-- add 1 to 2
    SET $total = ADDTIME($tdiff, $total);
    -- end adding 1 to 2
    -- SELECT $TMin, $TMax, $sdiff, $ediff, $tdiff, $total;
ELSE 
	-- calculating start time
	SET $Min = (SELECT s.SwipeId FROM Swiping s inner join Location l on s.LocationId=l.LocationId inner join Accountholder ac on s.AccountholderId=ac.AccountholderId WHERE s.LocationId = $location_id AND ac.CardNumber = $userCard and ((s.SwipOutTime > $sdate AND s.SwipInTime < $edate) OR (s.SwipOutTime IS NULL AND s.SwipInTime < $edate)) ORDER BY s.SwipInTime ASC LIMIT 1);
    
	-- add calculated start time to calculated end time
	SET $TMin = (SELECT vwSwipInTime FROM vwTotalUsersGrid WHERE vwSwipeId = $Min LIMIT 1);
    
    SET $TMin = (CASE WHEN $sdate >= $TMin THEN $sdate ELSE $TMin END);
		
	-- calculating end time
	/*IF EXISTS (SELECT recordId FROM users WHERE location_id = $location_id AND user_card = $userCard and ((end_time > $sdate AND start_time < $edate) OR (end_time IS NULL AND start_time < $edate)) AND end_time IS NULL)
    THEN*/
	
		SET $Max = (SELECT s.SwipeId FROM Swiping s inner join Location l on s.LocationId=l.LocationId inner join Accountholder ac on s.AccountholderId=ac.AccountholderId WHERE s.LocationId = $location_id AND ac.CardNumber = $userCard and ((s.SwipOutTime > $sdate AND s.SwipInTime < $edate) OR (s.SwipOutTime IS NULL AND s.SwipInTime < $edate)) /*AND end_time IS NULL*/ ORDER BY s.SwipInTime DESC LIMIT 1);
        
       -- SET $TMax = $edate;
       
 
		SET $TMax = (SELECT vwSwipOutTime FROM vwTotalUsersGrid WHERE vwSwipeId = $Max LIMIT 1);
        
		SET $TMax = (CASE WHEN $edate >= $TMax THEN $TMax ELSE $edate END);
	/*ELSE 
		SET $Max = (SELECT recordId FROM users WHERE location_id = $location_id AND user_card = $userCard and ((end_time > $sdate AND start_time < $edate) OR (end_time IS NULL AND start_time < $edate)) ORDER BY end_time DESC LIMIT 1);
        
		SET $TMax = (SELECT endTime FROM vwTotalUsersGrid WHERE recordId = $Max);
        
		SET $TMax = (CASE WHEN $edate >= $TMax THEN $TMax ELSE $edate END);
    
	END IF;*/
	
    IF $Min = $Max
    THEN 
		
        SET $tdiff = SEC_TO_TIME(TIMESTAMPDIFF(SECOND, $TMin, $TMax));
		
    ELSE
		SET $sdiff = SEC_TO_TIME(TIMESTAMPDIFF(SECOND, $TMin, (SELECT s.SwipOutTime FROM Swiping s WHERE s.SwipeId = $Min)));
		-- end of calculating start time      
		SET $ediff = SEC_TO_TIME(TIMESTAMPDIFF(SECOND, (SELECT s.SwipInTime FROM Swiping s WHERE s.SwipeId = $Max), $TMax));
		-- end of calculating end time 
		
		SET $tdiff = ADDTIME($sdiff, $ediff); -- > 1
	-- end of adding calculated start time to calculated end time
	END IF;
	-- calculate times in range excluding first record and last record which have been calculated before 
    
    SET $total = SEC_TO_TIME((SELECT SUM(total) FROM vwTotalUsersGrid WHERE vwOrgId = $userOrganization AND vwLocationId = $location_id AND vwCardNumber = $userCard and ((vwSwipOutTime > $sdate AND vwSwipInTime < $edate) OR (vwSwipOutTime IS NULL AND vwSwipInTime < $edate)) AND vwSwipeId NOT IN ($Min, $Max) GROUP BY vwCardNumber)); -- > 2
	-- end of calculating times in range excluding first record and last record which have been calculated before 
    
	-- add 1 to 2
    SET $total = ADDTIME($tdiff, $total);
    -- end adding 1 to 2
    -- SELECT $TMin, $TMax, $sdiff, $ediff, $tdiff, $total;
END IF;
RETURN  IFNULL($total, $tdiff);
END;
