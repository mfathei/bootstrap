CREATE PROCEDURE SafetyPass.spAccountholderCertificate(IN `$Search` VARCHAR(2000), IN `$Sidx` VARCHAR(50),
                                                       IN `$Sord`   VARCHAR(10), IN `$Strt` INT, IN `$Lmt` INT,
                                                       IN `$export` INT)
  BEGIN
SET @qry = 'SELECT 
	SQL_CALC_FOUND_ROWS
		`AccountholderCertificateId`,
        `AccountholderId`,
        `CertificateId`,
		`CertificateName`, 
		`CertifyingOrgId`, 
		`CertifyingOrgName`, 
		`TrainingOrgId`, 
		`TrainingOrgName`, 
		`CertificateNumber`, 
		`IssuedDate`, 
		`ExpiryDate`, 
		`CertificateStatus`,
        `FName`,
        `LName`,
        `OrgId`,
		`ExpiryStatus`
FROM vwAccountholderCertificate';
SET @qryWhere = (CASE WHEN $Search IS NOT NULL AND $Search <> '' THEN CONCAT('
',$Search, '
') ELSE '
' END);
SET @qryLimit = CONCAT('ORDER BY ',$Sidx,' ',$Sord,' 
LIMIT ',$Strt,', ',$Lmt,' ;');
SET @qry = CONCAT(@qry, @qryWhere);
IF $export = 0 THEN
	SET @qry = CONCAT(@qry, @qryLimit);
END IF;

PREPARE stmt FROM @qry;
EXECUTE stmt;
IF $export = 0 THEN
	SELECT FOUND_ROWS();
END IF;
DEALLOCATE PREPARE stmt;
END;
