CREATE PROCEDURE SafetyPass.spExpiredCert(IN `$Search` VARCHAR(2000), IN `$Sidx` VARCHAR(50), IN `$Sord` VARCHAR(10),
                                          IN `$Strt`   INT, IN `$Lmt` INT)
  BEGIN
SET @qry = 'SELECT 
	SQL_CALC_FOUND_ROWS
		`AccountholderCertificateId`,
        `AccountholderId`,
        `CertificateId`,
		`CertificateName`, 
		`CertifyingOrgId`, 
		`CertifyingOrgName`, 
		`TrainingOrgId`, 
		`TrainingOrgName`, 
		`CertificateNumber`, 
		`IssuedDate`, 
		`ExpiryDate`, 
		`CertificateStatus`,
        `FName`,
        `LName`,
        `OrgId`,
		`ExpiryStatus`
FROM vwAccountholderCertificate t1 ';
SET @ExpStatus = CONCAT(' ExpiryStatus = 'IsExpired'', ' AND ' , 'NOT EXISTS (SELECT CertificateId, CertificateName,ExpiryStatus, AccountholderId FROM vwAccountholderCertificate t2
 WHERE t1.AccountholderId = t2.AccountholderId AND t1.CertificateId = t2.CertificateId AND t2.ExpiryStatus ='NotExpired' AND t2.ExpiryStatus ='Expiring') ');
SET @qryWhere = (CASE WHEN $Search IS NOT NULL AND $Search <> '' THEN CONCAT('
',$Search,' AND ', @ExpStatus, '
') ELSE CONCAT('
 WHERE ',@ExpStatus) END);
SET @qryLimit = CONCAT(' GROUP BY t1.CertificateId ', 'ORDER BY ',$Sidx,' ',$Sord,' 
LIMIT ',$Strt,', ',$Lmt,' ;');
SET @qry = CONCAT(@qry, @qryWhere, @qryLimit);
PREPARE stmt FROM @qry;
EXECUTE stmt;
SELECT FOUND_ROWS();
DEALLOCATE PREPARE stmt;
END;
