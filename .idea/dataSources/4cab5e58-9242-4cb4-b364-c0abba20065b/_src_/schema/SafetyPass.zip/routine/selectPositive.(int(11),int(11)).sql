CREATE FUNCTION SafetyPass.selectPositive(num1 INT, num2 INT)
  RETURNS INT(100)
  begin
   if num1 >=0
  then  return num1;
   else 
   return 0;
   end if;
end;
