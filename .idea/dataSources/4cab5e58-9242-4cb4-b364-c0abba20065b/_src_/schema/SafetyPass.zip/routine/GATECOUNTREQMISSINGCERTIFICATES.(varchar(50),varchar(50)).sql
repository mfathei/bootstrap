CREATE FUNCTION SafetyPass.GATECOUNTREQMISSINGCERTIFICATES(pLocationId VARCHAR(50), pAccountholderId VARCHAR(50))
  RETURNS INT
  BEGIN
  DECLARE $Cnt INT ;
  set @OrgId = (select OrgId from Location where LocationId = pLocationId);
  SET $Cnt = 
  (
    SELECT count(distinct(c.`CertificateId`)) FROM OrgCategoryCert occ
    INNER JOIN Location l ON(occ.OrgId = l.OrgId AND l.`LocationId` = pLocationId)
    INNER JOIN `LocationCategory` lc ON(l.LocationId = lc.LocationId AND occ.CategoryId = lc.CategoryId)
    INNER JOIN Category cg ON(occ.CategoryId = cg.CategoryId)
    INNER JOIN Certificate c ON(c.`CertificateId` = occ.`CertificateId`)
    WHERE occ.CategoryId NOT IN
    (
        SELECT CategoryId FROM OrgCategoryCert occi INNER JOIN `AccountholderCertificate` aci
        ON(occi.`CertificateId` = aci.`CertificateId` AND `AccountholderId` = pAccountholderId AND occi.`OrgId` = @OrgId) 
    ) 
  );
  
  RETURN $Cnt ;
END;
