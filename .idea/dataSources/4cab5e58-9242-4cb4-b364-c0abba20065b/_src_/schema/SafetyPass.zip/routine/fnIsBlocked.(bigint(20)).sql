CREATE FUNCTION SafetyPass.fnIsBlocked(`$CardNumber` BIGINT)
  RETURNS VARCHAR(15)
  BEGIN
DECLARE $Ret VARCHAR(15);
DECLARE $AccountholderId VARCHAR(50);
SET $AccountholderId = (SELECT AccountholderId FROM Accountholder WHERE CardNumber = $CardNumber);
IF (SELECT LoginAttemptCount FROM LoginAttempt WHERE AccountholderId = $AccountholderId) = 3
THEN 
	IF TIMESTAMPDIFF(HOUR,(SELECT LoginAttemptTime FROM LoginAttempt WHERE AccountholderId = $accountholderId), NOW()) >= 24
	THEN
		DELETE FROM LoginAttempt WHERE AccountholderId = $AccountholderId;
		SET $Ret = 'WasBlocked';
	ELSE
		SET $Ret = 'IsBlocked';
	END IF;
ELSEIF NOT EXISTS (SELECT LoginAttemptCount FROM LoginAttempt WHERE AccountholderId = $AccountholderId)
THEN
	SET $Ret = 'NotBlocked';
ELSEIF (SELECT LoginAttemptCount FROM LoginAttempt WHERE AccountholderId = $AccountholderId) < 3 
THEN
	IF TIMESTAMPDIFF(MINUTE,(SELECT LoginAttemptTime FROM LoginAttempt WHERE AccountholderId = $accountholderId), NOW()) >= 5
	THEN
		DELETE FROM LoginAttempt WHERE AccountholderId = $AccountholderId;
		SET $Ret = 'NotBlocked';	
	ELSE
		SET $Ret = 'Found';
	END IF;
END IF;
RETURN $Ret;
END;
