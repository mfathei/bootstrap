CREATE PROCEDURE SafetyPass.GateCertsStatus(IN pLocationId VARCHAR(50), IN pAccountholderId VARCHAR(50))
  begin
    SELECT occ.`CertificateId`,c.CertificateName,aci.ExpiryDate,fnIsExpired(aci.ExpiryDate) as `Status` FROM OrgCategoryCert occ
    INNER JOIN Location l ON(occ.OrgId = l.OrgId AND l.`LocationId` = pLocationId)
    INNER JOIN `LocationCategory` lc ON(l.LocationId = lc.LocationId AND occ.CategoryId = lc.CategoryId)
    INNER JOIN Category cg ON(occ.CategoryId = cg.CategoryId)
    INNER JOIN Certificate c ON(c.`CertificateId` = occ.`CertificateId`)
    inner join `AccountholderCertificate` aci on(aci.`CertificateId` = c.`CertificateId`)
    and aci.`AccountholderId` = pAccountholderId;
end;
