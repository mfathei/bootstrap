CREATE PROCEDURE SafetyPass.spBulkUploadINSRoles()
  BEGIN
DECLARE $ImportAccountholderId,$AccessRole, $RoleId VARCHAR(250);
DECLARE $Cnt, $Counter, $Position INT;
declare ending int(2) default 0 ;
declare $ai int(11);
declare acc_curs cursor for select AI,ImportAccountholderId,AccessRole from ImportAccountholder;
declare continue handler for not found set ending=1;
open acc_curs ;
theloop:loop
fetch acc_curs into $ai,$ImportAccountholderId,$AccessRole;
if ending =1 then leave theloop;end if;
set @statment=$AccessRole;
set @chesk=(select locate('*',@statment));
if @chesk > 0
 then 
 therole:loop
 SET @Position = LOCATE('*',@statment);
 set @restofstr=substring(@statment,@Position+1);
 set @accessrole=substring(@statment,1,@Position-1);
 set @Roleid=(select RoleId from Role where RoleName=@accessrole);
   if (@Roleid is not null or @Roleid !='')
   then 
   insert into`AccountholderRole`(AccountholderId,RoleId) values($ImportAccountholderId,@Roleid);
   end if;
 set @statment=@restofstr;
 SET @Position = LOCATE('*', @statment);
 if @Position=0 then leave therole ; end if; 
end loop;
end if;
set @Roleid=(select RoleId from Role where RoleName=@statment);
if (@Roleid is not null or @Roleid !='')
then 
insert into AccountholderRole(AccountholderId,RoleId) values($ImportAccountholderId,@Roleid);
end if;
end loop;
close acc_curs;
END;
