CREATE PROCEDURE SafetyPass.GateGetCurrentUsers2(IN locid VARCHAR(50), IN search VARCHAR(2000), IN sidx VARCHAR(255),
                                                 IN sord  VARCHAR(4), IN lmt INT, IN strt INT)
  BEGIN
	SET @sql = CONCAT('select SQL_CALC_FOUND_ROWS vwGetCurrentUsers_view.*,TIMESTAMPDIFF(MINUTE, vwGetCurrentUsers_view.startTime,NOW()) AS `period_in_mins`,(case when (TIMESTAMPDIFF(MINUTE, vwGetCurrentUsers_view.startTime,NOW()) > MaxStayingMinute) then 1 else 0 end) as IsExceedMaxStayMin from `vwGetCurrentUsers_view` where usertype = 0 and location_id = '',locid,'' and ',
    (SELECT CASE WHEN search = '' THEN 1=1 ELSE search END));
    
    SET @sql = CONCAT(@sql,' order by ',sidx,' ',sord,' limit ',strt,',',lmt);
    -- SELECT @sql;
    PREPARE stmt FROM @sql;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
    SELECT FOUND_ROWS();
END;
