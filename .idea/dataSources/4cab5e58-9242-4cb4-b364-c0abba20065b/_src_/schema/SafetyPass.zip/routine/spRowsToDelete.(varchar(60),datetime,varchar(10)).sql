CREATE PROCEDURE SafetyPass.spRowsToDelete(IN pTableName VARCHAR(60), IN pLast_update DATETIME,
                                           IN pTimeZone  VARCHAR(10))
  BEGIN
	SET SESSION GROUP_CONCAT_MAX_LEN = 10000;
        SET @local_t = CONVERT_TZ(pLast_update, pTimeZone, getLocalTimeZone());
	SELECT CURRENT_TIMESTAMP() AS max_row,table_column,GROUP_CONCAT(CONCAT(''' , table_value, ''') SEPARATOR ',') AS vals FROM delete_hist WHERE `table_name` = pTableName  GROUP BY max_row,table_column; -- and last_update >=  @local_t;
END;
