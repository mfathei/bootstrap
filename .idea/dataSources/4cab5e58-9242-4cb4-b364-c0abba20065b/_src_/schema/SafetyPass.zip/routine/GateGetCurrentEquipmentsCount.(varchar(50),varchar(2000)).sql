CREATE PROCEDURE SafetyPass.GateGetCurrentEquipmentsCount(IN locid VARCHAR(50), IN search VARCHAR(2000))
  BEGIN
	SET @sql = CONCAT('select count(recordId) from `vwGetCurrentUsers_view` where location_id = '',locid,'' and equipment_id is not null and ',
    (SELECT CASE WHEN search = '' THEN 1=1 ELSE search END));
    
    -- SET @sql = CONCAT(@sql,' order by ',sidx,' ',sord,' limit ',strt,',',lmt);
    -- SELECT @sql;
    PREPARE stmt FROM @sql;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;   
   -- SELECT FOUND_ROWS();
END;
