CREATE PROCEDURE SafetyPass.select_data_to_sync(IN `$TableName` VARCHAR(100), IN `$OrgId` VARCHAR(100),
                                                IN `$last_sync` DATETIME, IN `$time_zone` VARCHAR(10))
    my_proc:BEGIN
SET @vlast_sync =  CONVERT_TZ($last_sync , $time_zone, getLocalTimeZone());
SELECT @vlast_sync  AS last_sync;
IF $TableName = 'Swiping' OR $TableName = 'SafetyMeeting' THEN
	SET @qry = (SELECT CONCAT('SELECT * FROM `',`TABLE_SCHEMA`,'`.`',`TABLE_NAME`,'` WHERE `LocationId` IN (SELECT LocationId FROM Location WHERE `OrgId` = '', $OrgId,'') AND last_update >= '',@vlast_sync,'' ') FROM information_schema.`TABLES` WHERE `TABLE_SCHEMA` = DATABASE() AND `TABLE_NAME` = $TableName);
ELSEIF $TableName = 'SafetyMeetingUser' OR $TableName = 'SafetyMeetingGuest' OR $TableName = 'SafetyMeetingComment' THEN
	SET @qry = (SELECT CONCAT('SELECT * FROM `',`TABLE_SCHEMA`,'`.`',`TABLE_NAME`,'` WHERE `SafetyMeetingId` IN (SELECT `SafetyMeetingId` FROM `SafetyMeeting` WHERE `LocationId` IN (SELECT LocationId FROM Location WHERE `OrgId` = '', $OrgId,'')) AND last_update >= '',@vlast_sync,'' ') FROM information_schema.`TABLES` WHERE `TABLE_SCHEMA` = DATABASE() AND `TABLE_NAME` = $TableName);
ELSE
	SET @qry = (SELECT CONCAT('SELECT * FROM `',`TABLE_SCHEMA`,'`.`',`TABLE_NAME`,'` WHERE last_update >= '',@vlast_sync,'' ') FROM information_schema.`TABLES` WHERE `TABLE_SCHEMA` = DATABASE() AND `TABLE_NAME` = $TableName);
END IF;
/**
UPDATE last_update
SET last_sync = NOW()
WHERE `table_name` = $TableName
;
**/
PREPARE stmt FROM @qry;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END;
