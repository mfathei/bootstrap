CREATE PROCEDURE SafetyPass.spBulkUploadAccountholdertest(IN `$OrgId` VARCHAR(50), IN `$PicNames` TEXT)
  BEGIN
DECLARE $InvalidPicName, $InvalidAccessRole TEXT;
DECLARE $ImportAccountholderId,$fname,$lname,$accessrole,$city,$profilepic,$street,$postal,$email,$phone,$fax,$ownerorgid,$password,$country,$state,$slocation varchar(250);
DECLARE $opt VARCHAR(50);
DECLARE $AI int;
DECLARE $dateofpirth varchar(50);
DECLARE $medicalinformation text;
DECLARE $lastupdate timestamp;
DECLARE ending,ending2 int default 0 ;
DECLARE iahid varchar(50);
DECLARE checks varchar(50);
DECLARE $results,$light text;
-- cursor for pass importaccountholder to temp table
  declare all_curs cursor for SELECT `ImportAccountholder`.`AI`,
    `ImportAccountholder`.`ImportAccountholderId`,
    `ImportAccountholder`.`FName`,
    `ImportAccountholder`.`LName`,
    `ImportAccountholder`.`AccessRole`,
    `ImportAccountholder`.`DateOfBirth`,
    `ImportAccountholder`.`ProfilePic`,
   TRIM(REPLACE(REPLACE(REPLACE(`ImportAccountholder`.`City`, '
', ' '), '
', ' '), '	', ' ')) ,
    `ImportAccountholder`.`Street`,
    `ImportAccountholder`.`Postal`,
    `ImportAccountholder`.`Email`,
    `ImportAccountholder`.`Phone`,
    `ImportAccountholder`.`Fax`,
    `ImportAccountholder`.`OwnerOrgId`,
    `ImportAccountholder`.`MedicalInformation`,
    `ImportAccountholder`.`Password`,
    TRIM(REPLACE(REPLACE(REPLACE(`ImportAccountholder`.`Country`, '
', ' '), '
', ' '), '	', ' ')),
    TRIM(REPLACE(REPLACE(REPLACE(`ImportAccountholder`.`State`, '
', ' '), '
', ' '), '	', ' ')),
    `ImportAccountholder`.`Slocation`,
    `ImportAccountholder`.`last_update`
	
    
FROM `SafetyPass`.`ImportAccountholder`;
-- declare importid_curs cursor for select AI,ImportAccountholderId from ImportAccountholder; 

-- create temp table 
drop temporary table if exists summery;
create temporary table summery
(
 line_no int(10) not null auto_increment primary key,
 statuss varchar(50) default null,
 mandotary varchar(50) default null,
 importaccountid varchar(50),
 fname varchar(50)default null,
 lname varchar(50)default null,
 email varchar(50)default null,
 thepassword varchar(50)default null,
 accessrole varchar(250) default null,
 erroraccessrole varchar(200),
 passwords  varchar(50) default null,
 country varchar(50) default null,
 state varchar(50) default null,
 city varchar(50) default null,
 optional_fields varchar(250) default null,
 pic varchar(100)default null,
 slocation varchar(100) default null,
 dateofpirth varchar(100)default null

);
-- declare Varibles for search
set  $InvalidPicName=fnBulkUploadCheckPics($PicNames);
SET $opt = '';
set @result='';
set @counter=1;
set @man='';

  set @errorroles=fnBulkUploadCheckRoles ((select  replace( GROUP_CONCAT(AccessRole),',','*' )from ImportAccountholder   )) ;
  
    if exists(select * from ImportAccountholder where FName is null or FName='' )
    then  set @man=concat(@man,'FName',','); end if;
  
    if exists(select * from ImportAccountholder where LName is null or LName='' )
    then  set @man=concat(@man,'LName',','); end if;
  
    if exists(select * from ImportAccountholder where (`AccessRole` is null or `AccessRole`='') or(length(@errorroles) >0 ))
    then  set @man=concat(@man,'AccessRole',','); end if;
  
   
    if exists(select * from ImportAccountholder where (Email is null or $email='') or (($email is not null or $email !='') and  Email  not REGEXP  '^[a-zA-Z0-9][a-zA-Z0-9._-]*[a-zA-Z0-9._-]@[a-zA-Z0-9][a-zA-Z0-9._-]*[a-zA-Z0-9]\.[a-zA-Z]{2,4}$'))
    then  set @man=concat(@man,'Email',','); end if;

  
	if exists(select * from ImportAccountholder where ( CAST(`Password` AS BINARY) NOT RLIKE '[A-Z]' )OR (CAST(`Password` AS BINARY) NOT RLIKE '[a-z]') OR (length(`Password`) < 6) or (`Password` is null or `Password`=''))
	then  set @man=concat(@man,'Password',','); end if;

  
    if exists(select Slocation from ImportAccountholder where TRIM(REPLACE(REPLACE(REPLACE(Slocation, '
', ' '), '
', ' '), '	', ' ')) not  in(select `SubLocationName` from SubLocation))
	then  set @man=concat(@man,'Location',','); end if;

  
    if ( length(@man)>0)
    then
	select 'Issues In Mandatory Fields' As OperationStatus ,count(AI) as RecordCount,group_concat(AI) as RecordLines ,(select distinct @man )As FieldStatus  from ImportAccountholder where ( FName is null or FName='')or(LName is null or LName='')or(`AccessRole` is null or `AccessRole`='' or length(@errorroles) >0 ) or(    Email is null or $email='') or (($email is not null or $email !='') and ( Email  not REGEXP  '^[a-zA-Z0-9][a-zA-Z0-9._-]*[a-zA-Z0-9._-]@[a-zA-Z0-9][a-zA-Z0-9._-]*[a-zA-Z0-9]\.[a-zA-Z]{2,4}$'))or( CAST(`Password` AS BINARY) NOT RLIKE '[A-Z]' )OR (CAST(`Password` AS BINARY) NOT RLIKE '[a-z]') OR (length(`Password`) < 6) or (`Password` is null or `Password`='') or (TRIM(REPLACE(REPLACE(REPLACE(Slocation, '
', ' '), '
', ' '), '	', ' ')) not  in(select `SubLocationName` from SubLocation));
	truncate ImportAccountholder;
	else 
      
       BEGIN
       DECLARE continue handler for not found set ending2 =1;
       open all_curs;
       curs:loop
       fetch all_curs into $AI,$ImportAccountholderId,$fname,$lname,$accessrole,$dateofpirth,$profilepic,$city,$street,$postal,$email,$phone,$fax,$ownerorgid,$medicalinformation,$password,$country,$state,$slocation,$lastupdate;
       if ending2=1 
       then leave curs;
       end if;
       update ImportAccountholder set ImportAccountholderId=MyUUID() where AI=$AI;
       insert into summery values(@counter,null,null,null,'fname','lname','email@email.com',null,'accessrole',null,null,null,null,null,null,null,null,null);

       if ($country is  null or $country='') and  ($state is  null or $state='') and ($city is  null or $city='')
       then  
       update ImportAccountholder set `Country` =null  , `State` =null  , `City`=null   where AI=$AI; 
       else
         if ($city is not null)
          then 
           if exists(select CityName from  vwCountryStateCity  where CountryName=$country and StateName=$state and CityName=$city)
             then
             UPDATE ImportAccountholder tbl1
		     INNER JOIN common_safetypass.Country tbl2
			 ON  TRIM(REPLACE(REPLACE(REPLACE(tbl1.Country, '
', ' '), '
', ' '), '	', ' ')) = tbl2.CountryName
             SET tbl1.Country   = TRIM(REPLACE(REPLACE(REPLACE(tbl2.CountryId, '
', ' '), '
', ' '), '	', ' '))   where AI=@counter;
    
	-- Update State Id in ImportAccountholder table
	         UPDATE ImportAccountholder tbl1
             INNER JOIN common_safetypass.Country tbl2
             ON tbl1.Country = tbl2.CountryId
             INNER JOIN common_safetypass.State tbl3
             ON TRIM(REPLACE(REPLACE(REPLACE(tbl2.CountryId, '
', ' '), '
', ' '), '	', ' '))= tbl3.CountryId AND tbl1.State = tbl3.StateName
             SET tbl1.State =  TRIM(REPLACE(REPLACE(REPLACE(tbl3.StateId, '
', ' '), '
', ' '), '	', ' ')) where AI=@counter;
    
	-- Update City Id in ImportAccountholder table
	         UPDATE ImportAccountholder tbl1
             INNER JOIN common_safetypass.Country tbl2
             ON tbl1.Country = tbl2.CountryId
             INNER JOIN common_safetypass.State tbl3
             ON tbl2.CountryId = tbl3.CountryId AND tbl1.State = tbl3.StateId
		     INNER JOIN common_safetypass.City tbl4
             ON   TRIM(REPLACE(REPLACE(REPLACE(tbl3.StateId, '
', ' '), '
', ' '), '	', ' ')) = tbl4.StateId AND tbl1.City = tbl4.CityName
             SET tbl1.City =  TRIM(REPLACE(REPLACE(REPLACE(tbl4.CityId , '
', ' '), '
', ' '), '	', ' ')) where AI=@counter;
		     else
		     set @result=concat('city-Sate-Country',',');
		     update ImportAccountholder set `Country` =null  , `State` =null  , `City`=null   where AI=$AI;
             end if;
          end if;
       end if;
 

     if ($phone ='' or $phone is null ) then set @result= @result ; 
     else 
        if LENGTH($phone) != 10 or $phone not REGEXP '^[0-9]+$'  then set @result=concat(@result,'phone',',');
        end if;
    end if ;
   
  if ($fax ='' or $fax is null ) then set @result= @result ; 
    else 
        if LENGTH($fax) != 10 or $fax not REGEXP '^[0-9]+$'  then set @result=concat(@result,'Fax',',');
        end if;
  end if ;
 
  set @ownerorgid=(select OrgId from Organization where  PresentationName=$ownerorgid );

  if ( length($ownerorgid) > 0  )and( @ownerorgid is not null or @ownerorgid !='')
   then update ImportAccountholder set OwnerOrgId=@ownerorgid where AI=$AI;
  end if;
 
  if (( length($ownerorgid) > 0  )and( @ownerorgid is  null or @ownerorgid ='') or( $ownerorgid='' ))
    then update ImportAccountholder set OwnerOrgId=null where AI=$AI; 
  end if;
 
  if (( length($ownerorgid) > 0)and( @ownerorgid is  null or @ownerorgid =''))  then 
   set @result=concat(@result,'ownerorgid',','); 
  end if;
 
  set @date_format= convert_date_format( $dateofpirth);
  update ImportAccountholder set `DateOfBirth`= @date_format  where AI=$AI;
  
  set @datecheck=(select IsDate( @date_format));
  if  @datecheck =0  
  then update ImportAccountholder set `DateOfBirth`= null  where AI=$AI;
  end if ;
  
  update ImportAccountholder  set Slocation=((select `SubLocationId` from SubLocation where SubLocationName=TRIM(REPLACE(REPLACE(REPLACE($slocation, '
', ' '), '
', ' '), '	', ' '))) ) where AI=$AI;

  if ( @datecheck = 1 )  then update ImportAccountholder set `DateOfBirth`= null  where AI=$AI;
  update summery set dateofpirth = 'error' ,fname=$fname,lname=$lname,thepassword=$password,email=$email where line_no=@counter ; 
  set @result=concat(@result,'DateOfPirth',','); 
  end if ;
    
  update summery set importaccountid=(select ImportAccountholderId from ImportAccountholder where AI=@counter),pic=(select ProfilePic from ImportAccountholder where AI=@counter)  where line_no=@counter;
  IF (@result IS NOT NULL AND @result != '' ) 
  then 
  update summery set optional_fields = @result ,fname=$fname,lname=$lname,thepassword=$password,email=$email where line_no=@counter ;
  end if;
  
  set @result='';
  set @counter=@counter+1;
  end loop;
  close all_curs;
  end;
  
    SET FOREIGN_KEY_CHECKS=0;
	INSERT INTO Accountholder
	(`AccountholderId`, `FName`, `LName`, `Password`, `DateOfBirth`, `MedicalInformation`, `Street`, `CityId`, `Postal`, `Fax`, `Email`, `Phone`, `CardNumber`, `CreationDate`, `ExpiryDate`, `Status`, `IssueDate`, `OrgId`, `OwnerOrgId`, `ReceiveNotification`, `IsOrgAdmin`, `SupervisorId`, `LastUpdate`, `VerificationCode`, `Photo`, `IsActive`,`AreaId`,`LocationId`)
    SELECT
	a.ImportAccountholderId , a.`FName`, a.`LName`, sha1(a.Password), a.`DateOfBirth`, a.`MedicalInformation`, a.`Street`, a.`City`, a.`Postal`, a.`Fax`, a.`Email`, a.`Phone`, fnGenerateCardNumber(), CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP() + INTERVAL 1 YEAR, 'Valid', CURRENT_TIMESTAMP(),  $OrgId , a.`OwnerOrgId`, NULL, 0, NULL, CURRENT_TIMESTAMP(), NULL, a.`ProfilePic`, 1,a.`Slocation`,(select LocationId from SubLocation where SubLocationId=a.Slocation)
	FROM ImportAccountholder a where a.AI in (select line_no from summery where statuss is null);
    SET FOREIGN_KEY_CHECKS=1;
    if exists ( select * from summery where optional_fields is not null or pic is null )
    then 	 
	select 'Issues in Optional Fields' As OperationStatus ,count(line_no) as RecordCount,group_concat(line_no) as RecordLines,group_concat(distinct optional_fields ) as FieldStatus, $InvalidPicName as PhotoStatus from summery   where optional_fields is not null or pic is null;
	end if;
	select 'Operation Successfull!' as OperationStatus,count(line_no)as RecordCount ,group_concat(line_no) as RecordLines,group_concat(importaccountid) as AccountholderId from summery  ;
    CALL spBulkUploadINSRoles();
	TRUNCATE ImportAccountholder;
	end if;
	drop temporary table if exists summery;
   -- select * from summery;


end;
