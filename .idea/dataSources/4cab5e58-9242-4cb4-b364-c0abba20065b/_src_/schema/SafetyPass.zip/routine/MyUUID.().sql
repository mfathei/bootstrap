CREATE FUNCTION SafetyPass.MyUUID()
  RETURNS VARCHAR(50)
  if @@hostname like '%.%'
then
return SUBSTRING(concat(LEFT(@@hostname,LOCATE('.',@@hostname) - 1),'-',uuid()), 1, 50);
else
return substring(concat(@@hostname,'-',uuid()), 1, 50);
end if;
