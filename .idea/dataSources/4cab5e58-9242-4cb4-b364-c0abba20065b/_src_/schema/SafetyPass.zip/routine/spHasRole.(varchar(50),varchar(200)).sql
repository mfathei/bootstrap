CREATE PROCEDURE SafetyPass.spHasRole(IN  `$AccountholderId` VARCHAR(50), IN `$RoleArray` VARCHAR(200),
                                      OUT `$Ret`             TINYINT(1))
  BEGIN
DECLARE $Pos INT;
DECLARE $Role VARCHAR(50);
DECLARE $RoleIn VARCHAR(50);
DECLARE $GroupRoles VARCHAR(200);
SET $RoleArray = CONCAT($RoleArray, ',');
SET $GroupRoles = '';
WHILE $RoleArray <> '' DO
SET $Pos = LOCATE(',', $RoleArray);
SET $Role = LEFT($RoleArray, $Pos-1);
SET $RoleArray = TRIM(SUBSTRING($RoleArray, $Pos + 1));
SET $RoleIn = (SELECT RoleId FROM Role WHERE RoleCode = $Role);
IF $RoleIn IN (SELECT RoleId FROM AccountholderRole WHERE AccountholderId = $AccountholderId)
THEN 
SET $GroupRoles = CONCAT($GroupRoles, $Role);
ELSE
SET $GroupRoles = $GroupRoles;
END IF;
END WHILE;
IF $GroupRoles <> ''
THEN
SET $Ret = true;
ELSE
SET $Ret = false;
END IF;
select $Ret;
END;
