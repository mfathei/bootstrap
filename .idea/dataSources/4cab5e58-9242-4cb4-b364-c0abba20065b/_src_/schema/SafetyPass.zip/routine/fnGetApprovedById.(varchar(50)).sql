CREATE FUNCTION SafetyPass.fnGetApprovedById(pCardNumber VARCHAR(50))
  RETURNS VARCHAR(50)
  BEGIN
    Declare vresult VARCHAR(50) CHARSET UTF8;
    set vresult = (select ar.AccountholderId from AccountholderRole ar inner join Accountholder a
                    on(ar.AccountholderId = a.AccountholderId)
                    inner join Role r
                    On(ar.RoleId = r.RoleId)
                    where a.CardNumber = pCardNumber and r.RoleCode = 'inspector');
    RETURN vresult;
END;
