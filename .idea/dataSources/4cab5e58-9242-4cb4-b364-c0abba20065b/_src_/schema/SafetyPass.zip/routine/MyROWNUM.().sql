CREATE FUNCTION SafetyPass.MyROWNUM()
  RETURNS INT
  BEGIN
	declare x integer default 0;
    if @i is null
    then
		set @i = 1;
    end if;
    
    set x = @i;
    set @i = @i + 1;
RETURN x;
END;
