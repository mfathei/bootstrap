CREATE PROCEDURE SafetyPass.GateMissedCategories(IN pLocationId VARCHAR(50), IN pAccountholderId VARCHAR(50))
  begin
    -- set @OrgId = (select OrgId from Location where LocationId = pLocationId);
    SELECT occ.CertificateId,c.CertificateName FROM OrgCategoryCert occ
    INNER JOIN Location l ON(occ.OrgId = l.OrgId AND l.`LocationId` = pLocationId)
    INNER JOIN `LocationCategory` lc ON(l.LocationId = lc.LocationId AND occ.CategoryId = lc.CategoryId)
    INNER JOIN Certificate c ON(c.`CertificateId` = occ.`CertificateId`)
    WHERE occ.CertificateId NOT IN
    (
        SELECT CertificateId FROM `AccountholderCertificate` aci
        where `AccountholderId` = pAccountholderId 
    );
    -- GROUP BY occ.CertificateId,c.CertificateName;
end;
