CREATE FUNCTION SafetyPass.timecalc(num INT)
  RETURNS VARCHAR(50)
  begin
declare result varchar(50) default '';
set @h = floor(num/3600);
set @m = floor((num - (@h * 3600)) / 60);
set @s = num - (@h * 3600 ) - (@m * 60);
set result = concat(@h, ":", @m , ":", @s);
return result;
end;
