CREATE PROCEDURE SafetyPass.set_last_update(IN `$TableName` VARCHAR(100), IN pLast_time DATETIME)
  BEGIN
UPDATE last_update
SET last_sync = pLast_time
WHERE `table_name` = $TableName
;
END;
