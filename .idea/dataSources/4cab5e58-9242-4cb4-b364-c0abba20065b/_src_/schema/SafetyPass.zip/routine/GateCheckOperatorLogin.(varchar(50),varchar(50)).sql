CREATE FUNCTION SafetyPass.GateCheckOperatorLogin(`$user_card` VARCHAR(50), `$location_id` VARCHAR(50))
  RETURNS VARCHAR(100)
  BEGIN
    DECLARE $result VARCHAR (100) ;
    DECLARE $record_id VARCHAR (100) ;
    DECLARE vIsOperator INT DEFAULT 0 ;
    
    set $user_card = trim($user_card);
    
    IF $user_card = '' OR $user_card IS NULL THEN
		set $result = 'notAuthorized';
        return $result;
    END IF;
    
    SET @cnt = (SELECT COUNT(AccountholderId)
        FROM
            Accountholder 
        WHERE CardNumber = $user_card );
        
    IF @cnt IS NULL OR @cnt <= 0 THEN
		SET $result = 'notAuthorized';
        RETURN $result;
    END IF;    
    
    set vIsOperator = fnIsOperator($user_card);
    
    IF vIsOperator <= 0 THEN -- not operator
		set $result = 'notOperator';
        return $result;
	Else
		SET $record_id = 
		(SELECT 
			SwipeId 
		FROM
			Swiping 
			inner join Accountholder 
				on (
					Swiping.AccountholderId = Accountholder.AccountholderId 
					AND Accountholder.CardNumber = $user_card
				) 
		WHERE Swiping.`LocationId` = $location_id 
			AND Swiping.`SwipOutTime` IS NULL limit 1) ;
		IF $record_id IS NULL 
		THEN 
		INSERT INTO Swiping (
			SwipeId,
			AccountholderId,
			LocationId,
			SwipInTime,
			SwipOutTime,
			IsOperator,
			ApprovedById,
			Note
		) 
		select 
			MyUUID(),
			AccountholderId,
			$location_id,
			NOW(),
			NULL,
			1,
			NULL,
			''
		from
			Accountholder 
		where CardNumber = $user_card ;
		
		SET $result = 'Swiped In' ;
		/**
		ELSE 
		UPDATE 
			Swiping 
		SET
			SwipOutTime = NOW() 
		WHERE SwipeId = $record_id ;
		SET $result = 'Swiped Out' ;
		**/
		
		ELSE    
			SET $result = 'Previously In' ;
		END IF ;
    END IF;
    
    RETURN $result ;
END;
