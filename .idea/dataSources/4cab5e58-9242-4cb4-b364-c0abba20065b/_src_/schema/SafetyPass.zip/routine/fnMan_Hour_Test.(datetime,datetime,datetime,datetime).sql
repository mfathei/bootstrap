CREATE FUNCTION SafetyPass.fnMan_Hour_Test(swipin DATETIME, swipout DATETIME, `$sdate` DATETIME, `$edate` DATETIME)
  RETURNS INT(15)
  begin
 declare hcount int;  
 if swipout ='' or swipout=null then set swipout=NULL;  end if;
     if swipin >= $sdate and  (swipout is null or swipout = '' ) and $edate <= now() then set hcount= (selectPositive(TIMESTAMPDIFF(second,swipin,$edate),0)) ;
     elseif swipin < $sdate and (swipout is null or swipout = '') and $edate <= now() then set hcount=(selectPositive(TIMESTAMPDIFF(second, $sdate,$edate),0));
     
     elseif swipin >= $sdate and  (swipout is null or swipout = '' ) and $edate > now() then set hcount= (selectPositive(TIMESTAMPDIFF(second,swipin,now()),0)) ;
     elseif swipin < $sdate and (swipout is null or swipout = '') and $edate > now() then set hcount=(selectPositive(TIMESTAMPDIFF(second, $sdate,now()),0));
     
     elseif swipin >= $sdate and swipout <= $edate  then  set hcount=(selectPositive(TIMESTAMPDIFF(second, swipin,swipout),0));
	 elseif  swipin >= $sdate and swipout > $edate  then set hcount= (selectPositive(TIMESTAMPDIFF(second, swipin,$edate),0));
     elseif swipin < $sdate and swipout <= $edate  then  set hcount=(selectPositive(TIMESTAMPDIFF(second, $sdate,swipout),0));
     elseif swipin < $sdate and swipout > $edate  then  set hcount=(selectPositive(TIMESTAMPDIFF(second, $sdate,$edate),0));
     else  set hcount = 0;
     end if;
     return hcount;
end;
