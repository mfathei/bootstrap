CREATE FUNCTION SafetyPass.IsDate(sIn VARCHAR(1024))
  RETURNS INT
  BEGIN 
declare tp int; 
if sIn is null or sIn='' then   set tp = 0;
else
if(select length(date(sIn))) is null 
then set tp = 1; 
   else    set tp = 2; 
   end if; 
   end if;
RETURN tp; 
END;
