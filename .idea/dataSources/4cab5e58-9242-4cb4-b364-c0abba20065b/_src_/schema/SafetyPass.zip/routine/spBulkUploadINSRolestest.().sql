CREATE PROCEDURE SafetyPass.spBulkUploadINSRolestest()
  BEGIN
DECLARE $ImportAccountholderId, $RoleId VARCHAR(50);
DECLARE $AccessRole VARCHAR(255);
DECLARE $AccessRoles TEXT;
DECLARE $Cnt, $Counter, $Position INT;
SET $Cnt = (SELECT COUNT(*) FROM ImportAccountholder);
SET $Counter = 0;
AccINSLoop: WHILE $Counter <= $Cnt
DO
	SET $ImportAccountholderId = (SELECT ImportAccountholderId FROM ImportAccountholder ORDER BY ImportAccountholderId ASC LIMIT $Counter, 1);
	SET $AccessRoles = (SELECT AccessRole FROM ImportAccountholder WHERE ImportAccountholderId = $ImportAccountholderId);
    
	SET $AccessRoles = CONCAT($AccessRoles, ',');
	SET $Position = LOCATE(',',$AccessRoles);
	RoleLoop: WHILE ($Position > 0)
	
	DO
		SET $AccessRole = LEFT($AccessRoles, $Position - 1);
		SET $AccessRoles = SUBSTRING($AccessRoles, $Position + 1);
		
		SET $RoleId = (SELECT RoleId FROM Role WHERE RoleName = TRIM($AccessRole));
		UPDATE ImportAccountholder
		SET AccessRole = REPLACE(AccessRole, $AccessRole, $RoleId)
		WHERE ImportAccountholderId = $ImportAccountholderId;
		
        INSERT INTO AccountholderRole
        (`AccountholderId`, `RoleId`)
        VALUES
        ($ImportAccountholderId, $RoleId);
        
		SET $Position = LOCATE(',',$AccessRoles);
		
	END WHILE;
	SET $Counter = $Counter + 1;
	
END WHILE;
end;
