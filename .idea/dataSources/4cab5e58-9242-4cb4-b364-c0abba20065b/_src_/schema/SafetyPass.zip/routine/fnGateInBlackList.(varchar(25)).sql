CREATE FUNCTION SafetyPass.fnGateInBlackList(pCardNumber VARCHAR(25))
  RETURNS INT
  BEGIN
        declare vResult int default 0;
        SET @accid = (SELECT AccountholderId FROM Accountholder WHERE CardNumber = pCardNumber );
if @ccid is null then
SET @accid = (SELECT EquipmentId FROM Equipment WHERE CardNumber = pCardNumber );
end if;
        SET @blklist = (SELECT AccountholderId FROM Blacklist WHERE AccountholderId = @accid);
        IF @blklist IS NOT NULL THEN -- check user is found in Blacklist table
            SET vResult = 1; 
        end if; 
        
    RETURN vResult;  
    END;
