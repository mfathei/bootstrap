CREATE PROCEDURE SafetyPass.spOrgByAccount(IN `$AccountHolderId` VARCHAR(50))
  BEGIN
DECLARE $ParentOrgId VARCHAR(50);
DECLARE $spId VARCHAR(50);
DECLARE $IsSafetyPassOperator BOOL;
SET $spId = (SELECT RoleId FROM Role WHERE RoleCode LIKE 'sp_user');
SET $IsSafetyPassOperator = EXISTS(SELECT AccountholderId FROM AccountholderRole WHERE AccountholderId = $AccountHolderId AND RoleId = $spId);
SET $ParentOrgId = (SELECT OrgId FROM Accountholder WHERE AccountholderId = $AccountHolderId) ;
IF( $IsSafetyPassOperator)
THEN
(SELECT OrgId, PresentationName FROM Organization);
ELSE
(SELECT OrgId, PresentationName FROM Organization WHERE ParentOrgId = $ParentOrgId OR OrgId = $ParentOrgId );
END IF;
END;
