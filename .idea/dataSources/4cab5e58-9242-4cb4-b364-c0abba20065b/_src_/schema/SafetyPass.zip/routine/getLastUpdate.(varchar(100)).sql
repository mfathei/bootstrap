CREATE FUNCTION SafetyPass.getLastUpdate(`$TableName` VARCHAR(100))
  RETURNS DATETIME
  BEGIN
	DECLARE $last_sync DATETIME;
    SET $last_sync = (SELECT last_sync FROM last_update WHERE `table_name` = $TableName);
RETURN  $last_sync;
END;
