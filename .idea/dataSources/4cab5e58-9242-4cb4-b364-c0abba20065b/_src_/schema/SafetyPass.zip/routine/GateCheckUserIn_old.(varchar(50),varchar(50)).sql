CREATE FUNCTION SafetyPass.GateCheckUserIn_old(`$user_card` VARCHAR(50), `$location_id` VARCHAR(50))
  RETURNS VARCHAR(50)
  BEGIN
    DECLARE $result VARCHAR (50) ;
    DECLARE $stat VARCHAR (5) ;
    DECLARE $record_id VARCHAR (50) ;
    
    SET $user_card = TRIM($user_card);
    
    IF $user_card = '' OR $user_card IS NULL THEN
		SET $result = 'notAuthorized';
        RETURN $result;
    END IF;    
    
    set @cnt = (SELECT count(AccountholderId)
        FROM
            Accountholder 
        WHERE CardNumber = $user_card );
        
    IF @cnt IS NULL OR @cnt <= 0 THEN
		SET $result = 'notAuthorized';
        RETURN $result;
    END IF; 
    
    SET $record_id = 
    (SELECT 
        SwipeId 
    FROM
        Swiping 
        inner join Accountholder 
            on (
                Swiping.AccountholderId = Accountholder.AccountholderId 
                AND Accountholder.CardNumber = $user_card
            ) 
    WHERE Swiping.`LocationId` = $location_id 
        AND Swiping.`SwipOutTime` IS NULL) ;
    IF $record_id IS NULL 
    THEN 
        INSERT INTO Swiping (
            SwipeId,
            AccountholderId,
            LocationId,
            SwipInTime,
            SwipOutTime,
            IsOperator,
            ApprovedById,
            Note
        ) 
        select 
            MyUUID(),
            AccountholderId,
            $location_id,
            NOW(),
            NULL,
            0,
            NULL,
            ''
        from
            Accountholder 
        where CardNumber = $user_card ;
        
        SET $result = 'Swiped In , 0' ;
    
    ELSE 
        UPDATE 
            Swiping 
        SET
            SwipOutTime = NOW() 
        WHERE SwipeId = $record_id ;
        
        set $stat = (SELECT 
            IsOperator 
        FROM
            Swiping where SwipeId = $record_id);
        SET $result = CONCAT('Swiped Out , ',$stat) ;
        
    END IF ;
    RETURN $result ;
END;
