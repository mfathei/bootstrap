CREATE FUNCTION SafetyPass.GateEqMissedCertsCommaSeparated(pLocationId VARCHAR(50), pEquipmentId VARCHAR(50))
  RETURNS TEXT
  BEGIN
  DECLARE result TEXT character set utf8 default '';
  SET SESSION group_concat_max_len = 1000000;
  SET result = 
  (
    -- missed certs
SELECT GROUP_CONCAT(c.`CertificateName` SEPARATOR ",") AS missedCerts FROM OrgCategoryCert occ
    INNER JOIN Location l ON(occ.OrgId = l.OrgId AND l.`LocationId` = pLocationId)
    INNER JOIN `LocationCategory` lc ON(l.LocationId = lc.LocationId AND occ.CategoryId = lc.CategoryId)
    INNER JOIN CertificateForEquipment c ON(c.`CertificateId` = occ.`CertificateId`)
    WHERE occ.CertificateId NOT IN
    (
        SELECT CertificateId FROM `EquipmentCertificate` aci
        WHERE `EquipmentId` = pEquipmentId and aci.CertificateStatus = 'Approved' 
    )

  );
  
  RETURN result;
END;
