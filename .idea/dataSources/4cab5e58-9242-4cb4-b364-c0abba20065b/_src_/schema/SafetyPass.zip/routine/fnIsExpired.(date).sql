CREATE FUNCTION SafetyPass.fnIsExpired(`$ExpiryDate` DATE)
  RETURNS VARCHAR(15)
  BEGIN
DECLARE $EXP int;
DECLARE $Ret varchar(15);
SET $EXP = DATEDIFF($ExpiryDate, CURDATE());
IF $EXP >= 30 then SET $Ret = 'NotExpired';
ELSEIF $EXP BETWEEN 0 AND 30 then SET $Ret = 'Expiring';
ELSEIF $EXP < 0  then SET $Ret = 'IsExpired';
ELSEIF $EXP IS NULL or $EXP = '' then SET $Ret = 'NotExpired';
END IF;
RETURN $Ret;
END;
