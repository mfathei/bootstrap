CREATE PROCEDURE SafetyPass.spSyncDeletedRows(IN pTableName         VARCHAR(60), IN pColumnName VARCHAR(60),
                                              IN pCommaSeparatedIds TEXT)
  BEGIN
SET @qry = concat('DELETE FROM ', pTableName,' WHERE ', pColumnName,' IN (', pCommaSeparatedIds,') ; ' );
PREPARE stmt FROM @qry;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
select 'DONE' as result;
end;
