CREATE FUNCTION SafetyPass.convert_date_format(str VARCHAR(40))
  RETURNS VARCHAR(50)
  begin
set @test=( select STR_TO_DATE(  replace( str,'/','-'),'%d-%m-%Y'));
set @test1=( select STR_TO_DATE(  replace( str,'/','-'),'%m-%d-%Y'));
 /* if @test is not null or @test!=''
  then
  set @ret=( select STR_TO_DATE(  replace( str,'/','-'),'%d-%m-%Y'));
     else */
       if @test1 is not null or @test1 !=''
       then
	   set @ret=( select STR_TO_DATE(  replace( str,'/','-'),'%m-%d-%Y'));
          else  
          set @ret= replace( str,'/','-');
	end if;
    -- end if;
   return  @ret;
end;
