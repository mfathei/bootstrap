CREATE FUNCTION SafetyPass.columname_fieldstatus()
  RETURNS VARCHAR(100)
  begin
set @res='';
if exists( select fname from  summery  where fname is null or fname='' limit 1 )
then set @res=concat( @res,'Fname',','); end if;
if exists(select lname  from summery  where lname is null or lname='' limit 1 )
then set @res= concat( @res,'Lname',','); end if;
if exists(select email  from summery  where( email is null or email='')or(email is not null and email not REGEXP '^[a-zA-Z0-9][a-zA-Z0-9._-]*[a-zA-Z0-9._-]@[a-zA-Z0-9][a-zA-Z0-9._-]*[a-zA-Z0-9]\.[a-zA-Z]{2,4}$' )  limit 1 )
then set @res=concat( @res,'Email',','); end if;
if exists(select *  from summery  where accessrole is null or accessrole='' or erroraccessrole='not_role'   limit 1 )
then set @res=concat( @res,'AccessRole',','); end if;
if exists(select * from summery where passwords='error')
then set @res=concat( @res,'Password',','); end if;
if exists (select * from summery where slocation ='inloc')
then set @res=concat( @res,'location',','); end if;

return @res;
end;
