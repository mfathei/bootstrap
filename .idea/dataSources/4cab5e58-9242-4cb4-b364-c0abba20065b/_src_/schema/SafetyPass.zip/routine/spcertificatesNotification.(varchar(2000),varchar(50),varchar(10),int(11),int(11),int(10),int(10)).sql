CREATE PROCEDURE SafetyPass.spcertificatesNotification(IN `$Search` VARCHAR(2000), IN `$Sidx` VARCHAR(50),
                                                       IN `$Sord`   VARCHAR(10), IN `$Strt` INT, IN `$Lmt` INT,
                                                       IN DaysStart INT(10), IN DaysFreq INT(10))
  begin
SET @qry = concat('SELECT 
SQL_CALC_FOUND_ROWS ac.AccountholderId, ac.FName, ac.LName, ac.Email, acr.CertificateId, c.`CertificateName`, o.OrgId,fnspcertificatesNotification(',DaysStart,',',DaysFreq,',acr.ExpiryDate)as Notifying , (case when acr.ExpiryDate>=curdate() then datediff(date( acr.ExpiryDate),curdate())end) as Till_Expire
from AccountholderCertificate acr 
inner join Accountholder ac on acr.AccountholderId=ac.AccountholderId
inner join Certificate c on c.CertificateId=acr.CertificateId 
inner join Organization o on  o.OrgId=acr.CertifyingOrgId
having Notifying=1');
SET @qryWhere = (CASE WHEN $Search IS NOT NULL AND $Search <> '' THEN CONCAT('
',$Search, '
') ELSE '
' END);
SET @qryLimit = CONCAT('ORDER BY ',$Sidx,' ',$Sord,' 
LIMIT ',$Strt,', ',$Lmt,' ;');
SET @qry = CONCAT(@qry, @qryWhere, @qryLimit);
PREPARE stmt FROM @qry;
EXECUTE stmt;
SELECT FOUND_ROWS();
DEALLOCATE PREPARE stmt;
end;
