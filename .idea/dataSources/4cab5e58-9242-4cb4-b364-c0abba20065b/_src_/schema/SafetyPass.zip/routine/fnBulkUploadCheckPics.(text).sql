CREATE FUNCTION SafetyPass.fnBulkUploadCheckPics(`$PicNames` TEXT)
  RETURNS TEXT
  BEGIN
DECLARE $Ret, $PicNamesQ TEXT;
DECLARE $PicName, $ProfilePic VARCHAR(255);
DECLARE $Cnt, $Counter, $Position INT;
SET $Ret = 'In DB but Not in ZIP File: ';
SET $PicNamesQ = CONCAT($PicNames, ',');
SET $Cnt = (SELECT COUNT(*) FROM ImportAccountholder);
SET $Counter = 0;
PicCHKLoop: WHILE $Counter <= $Cnt
DO
	SET $ProfilePic = CONCAT('%',(SELECT   TRIM(REPLACE(REPLACE(REPLACE(`ProfilePic`, '
', ' '), '
', ' '), '	', ' '))  FROM ImportAccountholder WHERE AI = $Counter and ( ProfilePic is not null or ProfilePic='' )),'%');
    
    IF $PicNamesQ NOT LIKE $ProfilePic
    THEN
		SET $Ret = CONCAT($Ret, TRIM(BOTH '%' FROM $ProfilePic),', ');
        UPDATE ImportAccountholder SET ProfilePic = NULL WHERE AI = $Counter;
    END IF;
    
	SET $Counter = $Counter + 1;
END WHILE;

RETURN $Ret;
END;
