CREATE FUNCTION SafetyPass.GateCheckUserIn(puser_card        VARCHAR(50), plocation_id VARCHAR(50),
                                           pApprovedByCardId VARCHAR(50), pNote TEXT)
  RETURNS VARCHAR(50)
  BEGIN
    DECLARE vresult VARCHAR (50) ;
    DECLARE vstat VARCHAR (5) ;
    DECLARE vrecord_id VARCHAR (50) ;
    DECLARE vApprovedById VARCHAR (50);
    
    SET puser_card = TRIM(puser_card);
    
    IF puser_card = '' OR puser_card IS NULL THEN
		SET vresult = 'notAuthorized';
        RETURN vresult;
    END IF;    
    
    set @cnt = (SELECT count(AccountholderId)
        FROM
            Accountholder 
        WHERE CardNumber = puser_card );
        
    IF @cnt IS NULL OR @cnt <= 0 THEN
		SET vresult = 'notAuthorized';
        RETURN vresult;
    END IF; 
    
    SET vrecord_id = 
    (SELECT 
        SwipeId 
    FROM
        Swiping 
        inner join Accountholder 
            on (
                Swiping.AccountholderId = Accountholder.AccountholderId 
                AND Accountholder.CardNumber = puser_card
            ) 
    WHERE Swiping.`LocationId` = plocation_id 
        AND Swiping.`SwipOutTime` IS NULL limit 1) ;
    IF vrecord_id IS NULL 
        THEN 
        
        
        IF pApprovedByCardId <> '' AND pApprovedByCardId IS not NULL THEN
            set @isInspector = fnGetApprovedById(pApprovedByCardId);
            IF (@isInspector IS NULL OR @isInspector = '') then
                SET vresult = 'notVerifier';
                RETURN vresult;
            else
                set vApprovedById = @isInspector; -- AccountholderId for inspector
            end if;
        END IF; 
        
        
        
        INSERT INTO Swiping (
            SwipeId,
            AccountholderId,
            LocationId,
            SwipInTime,
            SwipOutTime,
            IsOperator,
            ApprovedById,
            Note
            
        ) 
        select 
            MyUUID(),
            AccountholderId,
            plocation_id,
            NOW(),
            NULL,
            0,
            vApprovedById,
            pNote
            
        from
            Accountholder 
        where CardNumber = puser_card ;
        
        SET vresult = 'Swiped In , 0' ;
    
    ELSE 
        UPDATE 
            Swiping 
        SET
            SwipOutTime = NOW(),SwipeType = 'System'
        WHERE SwipeId = vrecord_id ;
        
        set vstat = (SELECT 
            IsOperator 
        FROM
            Swiping where SwipeId = vrecord_id);
        SET vresult = CONCAT('Swiped Out , ',vstat) ;
        
    END IF ;
    RETURN vresult ;
END;
