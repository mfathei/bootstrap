CREATE FUNCTION SafetyPass.GATEMISSEDCERTSCOMMASEPARATED(pLocationId VARCHAR(50), pAccountholderId VARCHAR(50))
  RETURNS TEXT
  BEGIN
  DECLARE result TEXT character set utf8 default '';
  SET SESSION group_concat_max_len = 1000000;
  SET result = 
  (
    -- missed certs
    SELECT GROUP_CONCAT(c.`CertificateName` SEPARATOR ",") AS missedCerts FROM OrgCategoryCert occ
    INNER JOIN Location l ON(occ.OrgId = l.OrgId AND l.`LocationId` = pLocationId)
    INNER JOIN `LocationCategory` lc ON(l.LocationId = lc.LocationId AND occ.CategoryId = lc.CategoryId)
    INNER JOIN Certificate c ON(c.`CertificateId` = occ.`CertificateId`)
    WHERE occ.CertificateId NOT IN
    (
        SELECT CertificateId FROM `AccountholderCertificate` aci
        WHERE `AccountholderId` = pAccountholderId and aci.CertificateStatus = 'Approved' 
    )
  );
  
  RETURN result;
END;
