CREATE PROCEDURE proc.sp_getversions(IN filename VARCHAR(255), IN fileparent VARCHAR(255))
  BEGIN
select t.file_id, t.file_createdate as file_lastupdated,concat(u.first_name,' ',u.last_name) as file_uploadby 
from `file` t inner join auth.user u on t.file_uploadby = u.user_id where t.file_filename = filename and t.file_parentid = fileparent
order by t.file_createdate desc;
END;
