CREATE PROCEDURE WhoKnozMe.addDocumentProc(IN `$bo_name`            VARCHAR(100), IN `$fullname` VARCHAR(255),
                                           IN `$template_id`        VARCHAR(36), IN `$description` TEXT,
                                           IN `$mobile_sync`        INT, IN `$external_id` VARCHAR(255),
                                           IN `$external_key_id`    VARCHAR(55), IN `$external_source_id` VARCHAR(36),
                                           IN `$properties`         TEXT, IN `$updator_id` VARCHAR(36),
                                           IN `$creator_id`         VARCHAR(36), IN `$owner_id` VARCHAR(36),
                                           IN `$business_rule_id`   VARCHAR(36), IN `$part_id` VARCHAR(36),
                                           IN `$customGroupID`      VARCHAR(36), IN `$efectiveDate` DATETIME,
                                           IN `$file_id`            VARCHAR(36), IN `$image_id` VARCHAR(36),
                                           IN `$list_index`         VARCHAR(24), IN `$expiry_date` DATETIME,
                                           IN `$next_id`            VARCHAR(36), IN `$subject_id` VARCHAR(36))
  BEGIN
	set @objid = uuid();
	set @obtype = (select id from object_type_tbl where object_type_name = 'File' limit 1);
    set @rtype = (select id from rel_type_tbl where rel_type_name = 'contains' and rel_type_abbrev = 'g2f' limit 1);
    INSERT INTO business_object_tbl (id,object_type_id,bo_name,fullname,created_date,updated_date,`status`,hidden,template_id,
	description,mobile_sync,external_id,external_key_id,external_source_id,properties,updator_id,
    creator_id,owner_id,business_rule_id,participant_id,owner_group_id,effective_date,file_id,image_id,list_index,expiry_date,next_bo_id)
    VALUES (@objid,@obtype,$bo_name,$fullname, current_timestamp(), current_timestamp(),"Active",0,  $template_id,$description, $mobile_sync ,  $external_id,$external_key_id,$external_source_id,$properties,$updator_id,  $creator_id,$owner_id,$business_rule_id, $part_id,
    $customGroupID, $efectiveDate, $file_id,
    $image_id,$list_index, $expiry_date, $next_id) ;
    
 	insert into relationship_tbl(id, subject_id,object_id,start_date,rel_type_id) values (@objid,$subject_id, @objid, current_timestamp(),  @rtype);
    
    select @objid as BOID;
    
END;
