CREATE PROCEDURE WhoKnozMe.action_list_proc(IN xmlData TEXT)
  BEGIN
SET @Orgid = EXTRACTVALUE(xmlData, '/OrgId');
SET @page = EXTRACTVALUE(xmlData, '//page');
SET @LIMIT = EXTRACTVALUE(xmlData, '//limit');
SET @sortOrder =  EXTRACTVALUE(xmlData, '//sortOrder');
SET @INDEX =  EXTRACTVALUE(xmlData, '//index');
SET @Export =  EXTRACTVALUE(xmlData, '//Export');
SET @Opeartion =  EXTRACTVALUE(xmlData, '//Opeartion');
SET @project_id =   EXTRACTVALUE(xmlData, '//project_id');
SET @selectquery ="SELECT *	";
SET @queryFrom = " FROM action_list_view ";
SET @queryWhere = ' where 1 = 1  ';
SET @queryWhere = CONCAT(@queryWhere,' and hidden = 0 ');
 SET @queryWhere = CONCAT(@queryWhere,' and project_id = ',"'", @project_id,"'");
SET @myArrayOfValue = 'action_list_id,action_list_name,business_object_id,properties,id,object_type_id,list_index,bo_name,fullname,description,bo_properties,next_bo_id,value_id,template_id,business_rule_id,status,hidden,mobile_sync,last_accessed_date,update_type,updated_date,created_date,effective_date,expiry_date,participant_id,owner_id,owner_group_id,last_accessor_id,updator_id,creator_id,external_id,external_key_id,external_source_id,';
SET @Postition = LOCATE(',', @myArrayOfValue);
WHILE ( @Postition > 0 ) DO
	SET @STR = SUBSTRING(@myArrayOfValue, 1, @Postition-1);
	SET @myArrayOfValue = SUBSTRING(@myArrayOfValue, @Postition + 1);
	SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//',@STR));
	IF (@Col != '' AND @Col !='NULL') THEN
		IF (@Opeartion = 'like' OR @Opeartion = '' ) THEN	
			SET @queryWhere = CONCAT(@queryWhere,CONCAT(' AND ',@STR,' like('"'%", @Col ,"%'"') '));	
		ELSE
			IF (@Opeartion = '!=') THEN
				SET @Opeartion = '<>';
			END IF;
			SET @queryWhere = CONCAT(@queryWhere,CONCAT(' AND BINARY ',@STR, @Opeartion ,"'", @Col ,"'"' '));
		END IF;
		-- SET @queryWhere = CONCAT(@queryWhere,CONCAT(' AND ',@STR,' like('"'%", @Col ,"%'"') '));	
	END IF;
	
	SET @Postition = LOCATE(',', @myArrayOfValue);
END WHILE;
SET @query = CONCAT( @selectquery, @queryFrom,  @queryWhere );
SET @querycount = CONCAT( 'SELECT count(*) into @cnt ', @queryFrom, @queryWhere );
PREPARE stmt1 FROM @querycount;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
SET @selectquery = CONCAT (@selectquery,', ', @cnt, ' as Count ');
SET @QUERY = CONCAT( @selectquery, @queryFrom, @queryWhere );
IF( @Export ="false") THEN
SET @page = (@page - 1) * @LIMIT;
END IF;
PREPARE stmt1 FROM @QUERY;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
END;
