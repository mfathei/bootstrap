CREATE FUNCTION WhoKnozMe.check_codedlist_fun(`$person_id`  VARCHAR(36), `$cLst_lookup_id` VARCHAR(36),
                                              `$identifier` VARCHAR(255))
  RETURNS VARCHAR(36)
  BEGIN
DECLARE $bo_id VARCHAR(36);
DECLARE $cLst_id VARCHAR(36);
SET $bo_id = (select ephr_intake_fun($person_id, $identifier));
IF $cLst_lookup_id in (select codedlist_lookup_id from codedlist_tbl where id in (select object_id from relationship_tbl where subject_id = $bo_id))
then
set $clst_id = (select id from codedlist_tbl where id in (select id from bo_view where participant_id = $person_id and object_type_name = 'Coded List') and codedlist_lookup_id = $cLst_lookup_id);
RETURN  $clst_id;
else 
RETURN  0;
end if;
END;
