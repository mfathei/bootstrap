CREATE PROCEDURE WhoKnozMe.pricelist_group(IN `$province_id` VARCHAR(36))
  BEGIN
DECLARE $company_id, $pricelist VARCHAR(36);
DECLARE $province_name VARCHAR(50);
SET $province_name = (SELECT prov_name FROM province_tbl WHERE id = $province_id);
SET $company_id = (SELECT company_id FROM province_tbl WHERE id = $province_id);
SET $pricelist = (SELECT object_id FROM relationship_tbl WHERE subject_id = $company_id AND object_id IN (SELECT id FROM business_object_tbl WHERE object_type_id = (SELECT id FROM object_type_tbl WHERE abbrev = 'pl')));
SELECT CONCAT($province_name, ' ', bo_name), id FROM bo_view WHERE id IN (SELECT object_id FROM relationship_tbl WHERE subject_id = $pricelist);
END;
