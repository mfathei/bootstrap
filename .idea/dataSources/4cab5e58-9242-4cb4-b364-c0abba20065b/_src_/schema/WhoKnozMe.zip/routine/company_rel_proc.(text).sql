CREATE PROCEDURE WhoKnozMe.company_rel_proc(IN xmlData TEXT)
  BEGIN
SET @page = EXTRACTVALUE(xmlData, '//page');
SET @LIMIT = EXTRACTVALUE(xmlData, '//limit');
SET @sortOrder =  EXTRACTVALUE(xmlData, '//sortOrder');
SET @INDEX =  EXTRACTVALUE(xmlData, '//index');
SET @Export =  EXTRACTVALUE(xmlData, '//Export');
SET @company_id =   EXTRACTVALUE(xmlData, '//company_id');
SET @flag =   EXTRACTVALUE(xmlData, '//flag');
IF @flag = 1 THEN
SET @selectquery ="SELECT bo_id, bo_name as name, fullname as full_name, relation_description, rel_id, rel_type_name, subject_role, object_role";
ELSEIF @flag = 2 THEN
SET @selectquery ="SELECT bo_id, object_bo_name as name, object_full_name as full_name, description, rel_id, date(effective_date) as effective_date ";
ELSEIF @flag = 3 THEN
SET @selectquery ="SELECT bo_id, object_bo_name as name, object_full_name as full_name, description, rel_id,date(effective_date) as effective_date,object_hidden,object_status,object_mobile_sync,date(object_expiry_date) as object_expiry_date ,object_list_index";
END IF;
SET @queryFrom = " FROM relationships_bo_view ";
IF @flag = 1 THEN
SET @queryWhere = CONCAT(' where object_type_name="Company" and subject_type_name="Company" and hidden = 0 and ( subject_id = ',"'", @company_id,"'",' or object_id = ',"'", @company_id,"'",')');
ELSEIF @flag = 2 THEN
SET @queryWhere = CONCAT(' where object_type_name="Group" and subject_type_name="Price list" and hidden = 0 and subject_id = (select distinct bo_id from relationships_bo_view where subject_id= ',"'", @company_id,"'",' and object_type_name="Price list")');
 -- select @queryWhere;
ELSEIF @flag = 3 THEN
SET @queryWhere = CONCAT(' where object_type_name="Product" and subject_type_name="Group" and hidden = 0 and subject_id = ',"'", @company_id,"'");
END IF;
IF @flag = 1 THEN
SET @myArrayOfValue = ' bo_id, bo_name, fullname, relation_description, rel_id, rel_type_name, subject_role, object_role,';
ELSEIF @flag = 2 THEN
SET @myArrayOfValue = ' bo_id, bo_name, fullname, description, rel_id, rel_type_name, subject_role, object_role, effective_date,';
ELSEIF @flag = 3 THEN
SET @myArrayOfValue = ' bo_id, bo_name, fullname, description, rel_id, rel_type_name, subject_role, object_role, effective_date, object_hidden, object_status, object_mobile_sync, object_expiry_date, object_list_index,';
END IF;
SET @Postition = LOCATE(',', @myArrayOfValue);
WHILE ( @Postition > 0 ) DO
	SET  @STR = TRIM(@STR);
	SET @STR = SUBSTRING(@myArrayOfValue, 1, @Postition-1);
	SET @myArrayOfValue = SUBSTRING(@myArrayOfValue, @Postition + 1);
IF (@STR = 'bo_name') THEN  SET @STR = 'name'; 
ELSEIF (@STR = 'fullname') THEN SET @STR = 'full_name'; END IF;
	SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//',@STR));
IF (@STR = 'name') THEN  SET @STR = 'bo_name'; 
ELSEIF (@STR = 'full_name') THEN SET @STR = 'fullname'; END IF;
	IF (@Col != '' AND @Col !='NULL') THEN
		SET  @STR = TRIM(@STR);
		SET @queryWhere = CONCAT(@queryWhere,CONCAT(' AND ',@STR,' like('"'%", @Col ,"%'"') '));	
	END IF;
	
	SET @Postition = LOCATE(',', @myArrayOfValue);
END WHILE;
SET @querycount = CONCAT( 'SELECT count(*) into @cnt ', @queryFrom, @queryWhere );
PREPARE stmt1 FROM @querycount;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
SET @selectquery = CONCAT (@selectquery,', ', @cnt, ' as Count ');
SET @QUERY = CONCAT( @selectquery, @queryFrom, @queryWhere );
SET @QUERY = CONCAT(@QUERY, ' order by ', @INDEX,'  ', @sortOrder);
IF( @Export ="false") THEN
SET @page = (@page - 1) * @LIMIT;
SET @QUERY = CONCAT(@QUERY, ' LIMIT ', @LIMIT ,' OFFSET ',  @page);
 
END IF;
  
PREPARE stmt1 FROM @QUERY;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
END;
