CREATE FUNCTION WhoKnozMe.ephr_intake_all_fun(`$person_id` VARCHAR(100))
  RETURNS VARCHAR(36)
  BEGIN
DECLARE $id VARCHAR(36);
set @identfier1 = '%<Identifier>participant_identification</Identifier>%';
set @identfier2 = '%<Identifier>demographics</Identifier>%';
set @identfier3 = '%<Identifier>medical_other_insurance_accounts</Identifier>%';
set @identfier4 = '%<Identifier>quick_links_emergency_contacts</Identifier>%';
set @identfier5 = '%<Identifier>present_health_concerns</Identifier>%';
set @identfier6 = '%<Identifier>symptoms</Identifier>%';
set @identfier7 = '%<Identifier>medical_products</Identifier>%';
set @identfier8 = '%<Identifier>pain_observations</Identifier>%';
set @identfier9 = '%<Identifier>personal_medical_history</Identifier>%';
set @identfier10 = '%<Identifier>family_medical_history</Identifier>%';
set @identfier11 = '%<Identifier>medical_(diagnostic)_history</Identifier>%';
set @identfier12 = '%<Identifier>injury_&_poisoning_+_external_cuase</Identifier>%';
set @identfier13 = '%<Identifier>personal_observations</Identifier>%';
set @identfier15 = '%<Identifier>sugrical_&_other_procedure_history</Identifier>%';
set @identfier20 = '%<Identifier>medical_appointment_(encounters)</Identifier>%';
set @identfier21 = '%<Identifier>medical_other_insurance_accounts</Identifier>%';
set @identfier22 = '%<Identifier>immunization_&_travel_history</Identifier>%';
set @identfier23 = '%<Identifier>other_treatments</Identifier>%';
set @identfier24 = '%<Identifier>adverse_effects_(allergies_,_reactions_or_treatment)</Identifier>%';
set @identfier25 = '%<Identifier>lab_results</Identifier>%';
set @identfier26 = '%<Identifier>medical_imaging_files</Identifier>%';
set @identfier27 = '%<Identifier>patient_medical_summaries</Identifier>%';
set @identfier28 = '%<Identifier>health_directives</Identifier>%';
set @obtype = (select id from object_type_tbl where object_type_name = 'File' limit 1);
SET $id = (
SELECT count(bo.id) FROM business_object_tbl bo 
join relationship_tbl rl on(rl.subject_id = bo.id)
join business_object_tbl fl on(rl.object_id = fl.id and fl.object_type_id = @obtype)
 WHERE bo.participant_id = $person_id AND bo.Hidden <> 1 AND (
bo.properties LIKE @identfier1 
or bo.properties LIKE @identfier2 
or bo.properties LIKE @identfier3 
or bo.properties LIKE @identfier4
or bo.properties LIKE @identfier5
or bo.properties LIKE @identfier6
or bo.properties LIKE @identfier7
or bo.properties LIKE @identfier8
or bo.properties LIKE @identfier9
or bo.properties LIKE @identfier10
or bo.properties LIKE @identfier11
or bo.properties LIKE @identfier12
or bo.properties LIKE @identfier13
or bo.properties LIKE @identfier15
or bo.properties LIKE @identfier20
or bo.properties LIKE @identfier21
or bo.properties LIKE @identfier22
or bo.properties LIKE @identfier23
or bo.properties LIKE @identfier24
or bo.properties LIKE @identfier25
or bo.properties LIKE @identfier26
or bo.properties LIKE @identfier27
or bo.properties LIKE @identfier28
)  
 
);
RETURN  $id;
END;
