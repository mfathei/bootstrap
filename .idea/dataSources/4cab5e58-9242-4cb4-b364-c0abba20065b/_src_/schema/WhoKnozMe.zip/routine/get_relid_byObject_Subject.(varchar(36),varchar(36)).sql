CREATE FUNCTION WhoKnozMe.get_relid_byObject_Subject(`$ob_id` VARCHAR(36), `$sub_id` VARCHAR(36))
  RETURNS VARCHAR(36)
  BEGIN
	DECLARE $relid VARCHAR(36);
	SET $relid = (SELECT DISTINCT id FROM relationship_tbl 
	WHERE (subject_id = $sub_id AND object_id = $ob_id));
	RETURN $relid;
    END;
