CREATE PROCEDURE WhoKnozMe.Shareholder_proc(IN xmlData TEXT)
  BEGIN
SET @Orgid = EXTRACTVALUE(xmlData, '//OrgId');
SET @page = EXTRACTVALUE(xmlData, '//page');
SET @LIMIT = EXTRACTVALUE(xmlData, '//limit');
SET @sortOrder =  EXTRACTVALUE(xmlData, '//sortOrder');
SET @INDEX =  EXTRACTVALUE(xmlData, '//index');
SET @Export =  EXTRACTVALUE(xmlData, '//Export');
SET @selectquery ="SELECT *	";
SET @queryFrom = " FROM Shareholder_view   ";
SET @queryWhere = ' where 1 <> 0 ';
SET @myArrayOfValue = 'id,username,group_name,user_group_id,status,salt,properties,person_id,person_name,pers_participant_id,relationship_id,relationship_name,rel_participant_id,';
SET @Postition = LOCATE(',', @myArrayOfValue);
WHILE ( @Postition > 0 ) DO
	SET @STR = SUBSTRING(@myArrayOfValue, 1, @Postition-1);
	SET @myArrayOfValue = SUBSTRING(@myArrayOfValue, @Postition + 1);
	SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//',@STR));
	IF (@Col != '' AND @Col !='NULL') THEN
		SET @queryWhere = CONCAT(@queryWhere,CONCAT(' AND ',@STR,' like('"'%", @Col ,"%'"') '));	
	END IF;
	
	SET @Postition = LOCATE(',', @myArrayOfValue);
END WHILE;
SET @querycount = CONCAT( 'SELECT count(*) into @cnt ', @queryFrom, @queryWhere );
PREPARE stmt1 FROM @querycount;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
SET @selectquery = CONCAT (@selectquery,', ', @cnt, ' as Count ');
SET @QUERY = CONCAT( @selectquery, @queryFrom, @queryWhere );
SET @QUERY = CONCAT(@QUERY, ' order by ', @INDEX,'  ', @sortOrder);
IF( @Export ="false") THEN
SET @page = (@page - 1) * @LIMIT;
SET @QUERY = CONCAT(@QUERY, ' LIMIT ', @LIMIT ,' OFFSET ',  @page);
 
END IF;
PREPARE stmt1 FROM @QUERY;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
END;
