CREATE PROCEDURE WhoKnozMe.hide_group_capsule(IN `$participant_id` VARCHAR(36), IN `$group_type` VARCHAR(36))
  BEGIN
DECLARE $contact_group_id VARCHAR(36);
IF $group_type = 'emergency'  THEN
	SET $group_type= 'contacts_emergency_contacts';
    
ELSEIF $group_type = 'care'  THEN
	SET $group_type= 'care_team';
	
ELSEIF $group_type = 'fGeneric'  THEN
	SET $group_type= 'family(Genetic)';
	
ELSEIF $group_type = 'fLivingArrang' THEN
 SET $group_type= 'family(living_arrangement)';
ELSEIF $group_type = 'caregiver'  THEN
  SET $group_type= 'caregiver_clients';
  
ELSEIF $group_type = 'addressbook'  THEN
SET $group_type= 'address_book';
END IF;
 
SET $contact_group_id = ephr_intake_fun(  $participant_id ,$group_type);
    UPDATE business_object_tbl 
    SET trusted =0
    WHERE id=$contact_group_id ;
 SET @otype = (SELECT id FROM object_type_tbl WHERE object_type_name = 'Capsule');
UPDATE business_object_tbl  bo 
JOIN relationship_tbl rel ON(bo.id = rel.id AND bo.object_type_id = @otype)
SET hidden = 1
 WHERE subject_id = $contact_group_id ;-- '156046ef-b79b-11e6-8628-74e6e20204b8' or id = '22fcb4d1-b79b-11e6-8628-74e6e20204b8';
END;
