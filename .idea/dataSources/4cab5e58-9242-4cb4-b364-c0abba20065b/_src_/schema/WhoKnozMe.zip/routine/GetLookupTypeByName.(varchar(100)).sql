CREATE FUNCTION WhoKnozMe.GetLookupTypeByName(pLookupTypeName VARCHAR(100))
  RETURNS VARCHAR(36)
  BEGIN
declare vId VARCHAR(36) default null;
set vId = (select id from lookup_type_tbl where lookup_type_name = pLookupTypeName);
return vId;
    END;
