CREATE PROCEDURE WhoKnozMe.product_tbls_new_proc(IN xmlData TEXT)
  BEGIN
SET @Orgid = EXTRACTVALUE(xmlData, '//OrgId');
SET @page = EXTRACTVALUE(xmlData, '//page');
SET @LIMIT = EXTRACTVALUE(xmlData, '//limit');
SET @sortOrder =  EXTRACTVALUE(xmlData, '//sortOrder');
SET @INDEX =  EXTRACTVALUE(xmlData, '//index');
SET @Export =  EXTRACTVALUE(xmlData, '//Export');
SET @selectquery ="SELECT *	";
SET @queryFrom = " FROM product_tbls_view   ";
SET @queryWhere = " where 1 <> 0  ";
SET @myArrayOfValue = 'id,make,model,GroupID,GroupName,GroupFullName,bo2_participant_id,bo2_owner_group_id,product_code_type_id,product_code,product_code_company,internal_code,component_list_total_value,package_descrip,package_qty,package_measurement_value_id,supplier_price,suggested_retail_price,dept_id,brand_id,manufacturer,supplier_id,category_type,sub_category_id,currency_type,TableProperties,thumbnail,pricing_rule_id,software_version,product_file_id,product_image_id,CategoryName,SubCategoryName,object_type_id,list_index,bo_name,fullname,description,properties,next_bo_id,value_id,template_id,business_rule_id,status,hidden,mobile_sync,last_accessed_date,update_type,updated_date,created_date,effective_date,expiry_date,participant_id,owner_id,owner_group_id,last_accessor_id,updator_id,creator_id,external_id,external_key_id,external_source_id,file_id,image_id,FileName,';
SET @Postition = LOCATE(',', @myArrayOfValue);
WHILE ( @Postition > 0 ) DO
	SET @STR = SUBSTRING(@myArrayOfValue, 1, @Postition-1);
	SET @myArrayOfValue = SUBSTRING(@myArrayOfValue, @Postition + 1);
	SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//',@STR));
	IF (@Col != '' AND @Col !='NULL') THEN
		/*IF (@STR = 'id') THEN
			SET @queryWhere = CONCAT(@queryWhere,CONCAT(' AND ',@STR,' = '"'", @Col ,"'"' '));	
		Else
			SET @queryWhere = CONCAT(@queryWhere,CONCAT(' AND ',@STR,' like('"'%", @Col ,"%'"') '));	
		END IF;*/
		SET @queryWhere = CONCAT(@queryWhere,CONCAT(' AND ',@STR,' like('"'%", @Col ,"%'"') '));
	END IF;
	
	SET @Postition = LOCATE(',', @myArrayOfValue);
END WHILE;
SET @querycount = CONCAT( 'SELECT count(*) into @cnt ', @queryFrom, @queryWhere );
PREPARE stmt1 FROM @querycount;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
SET @selectquery = CONCAT (@selectquery,', ', @cnt, ' as Count ');
SET @QUERY = CONCAT( @selectquery, @queryFrom, @queryWhere );
SET @QUERY = CONCAT(@QUERY, ' order by ', @INDEX,'  ', @sortOrder);
IF ( @Export ="false") THEN
SET @page = (@page - 1) * @LIMIT;
SET @QUERY = CONCAT(@QUERY, ' LIMIT ', @LIMIT ,' OFFSET ',  @page);
 
END IF;
PREPARE stmt1 FROM @QUERY;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
END;
