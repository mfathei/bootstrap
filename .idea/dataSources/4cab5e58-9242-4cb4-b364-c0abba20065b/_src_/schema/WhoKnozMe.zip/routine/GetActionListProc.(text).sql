CREATE PROCEDURE WhoKnozMe.GetActionListProc(IN xmlData TEXT)
  BEGIN
SET @page = EXTRACTVALUE(xmlData, '//page');
SET @limit = EXTRACTVALUE(xmlData, '//limit');
SET @sortOrder =  EXTRACTVALUE(xmlData, '//sortOrder');
SET @index =  EXTRACTVALUE(xmlData, '//index');
SET @Export =  EXTRACTVALUE(xmlData, '//Export');
SET @PersonIDWKME =  EXTRACTVALUE(xmlData, '//PersonIDWKME');
SET @selectquery ="SELECT *";
                
SET @queryFrom = " from action_list_tbl";
SET @queryWhere = ' where 1= 1 ';
SET @queryWhere = CONCAT(@queryWhere,' and business_object_id = ',"'", @PersonIDWKME,"'");
SET @myArrayOfValue = 'id,action_list_name,business_object_id,properites,';
SET @Postition = LOCATE(',', @myArrayOfValue);
WHILE ( @Postition > 0 ) DO
 SET @STR = SUBSTRING(@myArrayOfValue, 1, @Postition-1);
 SET @myArrayOfValue = SUBSTRING(@myArrayOfValue, @Postition + 1);
 SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//',@STR));
 IF (@Col != '' AND @Col !='NULL') THEN
SET @queryWhere = CONCAT(@queryWhere,CONCAT(' AND    `',@STR,'`  like '"'%", @Col ,"%'"));
 END IF;
 
 SET @Postition = LOCATE(',', @myArrayOfValue);
END WHILE;
SET @querycount = CONCAT( 'SELECT count(*) into @cnt ', @queryFrom, @queryWhere );
PREPARE stmt1 FROM @querycount;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
	
SET @selectquery = CONCAT (@selectquery,', ', @cnt, ' as Count ');
SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );
SET @query = CONCAT(@query, ' order by ', @index,'  ', @sortOrder);
IF( @Export ="false") THEN
SET @page = (@page - 1) * @limit;
SET @query = CONCAT(@query, ' LIMIT ', @limit ,' OFFSET ',  @page);
END IF;
PREPARE stmt1 FROM @query;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
END;
