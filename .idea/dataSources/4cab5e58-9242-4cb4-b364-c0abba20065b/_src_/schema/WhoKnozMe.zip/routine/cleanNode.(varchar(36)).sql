CREATE PROCEDURE WhoKnozMe.cleanNode(IN `$id` VARCHAR(36))
  BEGIN
SET @obid = (SELECT object_id FROM relationship_tbl WHERE id = $id);
DELETE FROM relationship_tbl WHERE id = $id;
DELETE FROM business_object_tbl WHERE id = $id;
DELETE FROM business_object_tbl WHERE id = @obid;
    END;
