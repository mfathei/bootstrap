CREATE FUNCTION WhoKnozMe.company_admin_fun(`$person_id` VARCHAR(36))
  RETURNS INT
  BEGIN
DECLARE $user_id VARCHAR(36);
DECLARE $wkme_admin_id VARCHAR(36);
DECLARE $cs4_admin_id VARCHAR(36);
/*set $wkme_admin_id = '383b58d1-862c-11e4-aacb-1c6f65f2b147';
set $cs4_admin_id = '382833cf-862c-11e4-aacb-1c6f65f2b147';*/
SET $wkme_admin_id = 'aa9020e4-daa7-11e3-a4dc-1c6f65f2b147';
SET $cs4_admin_id = 'aa9020e4-daa7-11e3-a4dc-1c6f65f2b147';
SET $user_id = (SELECT id FROM user_tbl WHERE person_id = $person_id);
IF EXISTS (SELECT * FROM ugu_tbl WHERE user_group_id = $cs4_admin_id AND user_id = $user_id)
THEN
	IF (SELECT username FROM user_tbl WHERE id = $user_id) = 'admin'
		THEN 
		RETURN 1;
	ELSE
		RETURN 2;
	END IF;
ELSE 
RETURN 0;
END IF;
/*if exists (select * from ugu_tbl where user_group_id = $wkme_admin_id and  user_id = $user_id)
then
return 2;
end if;*/
END;
