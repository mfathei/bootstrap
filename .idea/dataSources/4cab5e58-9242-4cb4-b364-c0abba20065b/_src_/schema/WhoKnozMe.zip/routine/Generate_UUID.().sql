CREATE FUNCTION WhoKnozMe.Generate_UUID()
  RETURNS VARCHAR(255)
  BEGIN
declare $UUID varchar(255);
set $UUID = uuid();
RETURN $uuid;
END;
