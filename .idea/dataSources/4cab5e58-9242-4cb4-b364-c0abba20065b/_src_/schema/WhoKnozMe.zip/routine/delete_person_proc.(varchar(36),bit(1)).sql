CREATE PROCEDURE WhoKnozMe.delete_person_proc(IN `$person_id` VARCHAR(36), IN `$CompanyOwner` BIT)
  BEGIN
DECLARE $user_id, $MIN, $MAX VARCHAR(36);
SET $user_id = (SELECT id FROM user_tbl WHERE person_id = $person_id);
DELETE FROM account_tbl WHERE id IN (SELECT id FROM business_object_tbl WHERE participant_id = $person_id AND object_type_id = '3a993221-d5e1-11e3-a67e-1c6f65f2b147');
SET $MIN = (SELECT MIN(id) FROM business_object_tbl WHERE participant_id = $person_id AND object_type_id = 'e4f731de-fc6d-11e3-84c3-52540002e01a');
SET $MAX = (SELECT MAX(id) FROM business_object_tbl WHERE participant_id = $person_id AND object_type_id = 'e4f731de-fc6d-11e3-84c3-52540002e01a');
action_loop: WHILE $MIN <= $MAX
DO 
	CALL delete_action_proc($MIN);
	IF $MIN = $MAX 
	THEN
		LEAVE action_loop;
	ELSE 
		SET $MIN = (SELECT MIN(id) FROM business_object_tbl WHERE participant_id = $person_id AND object_type_id = 'e4f731de-fc6d-11e3-84c3-52540002e01a' AND id > $MIN);
	END IF;
END WHILE;
IF $CompanyOwner = 1
THEN
	DELETE FROM company_tbl WHERE id IN (SELECT id FROM business_object_tbl WHERE participant_id = $person_id AND object_type_id = '7a582bfb-bd7d-11e3-b5d8-1c6f65f2b147');
END IF;
DELETE FROM asset_tbl WHERE id IN (SELECT id FROM business_object_tbl WHERE participant_id = $person_id AND object_type_id = '3a9911e7-d5e1-11e3-a67e-1c6f65f2b147');
DELETE FROM value_triplet_tbl WHERE business_object_id IN (SELECT id FROM business_object_tbl WHERE participant_id = $person_id AND object_type_id = 'fb86b96c-68f9-11e4-913c-52540002e01a');
DELETE FROM family_medical_tbl WHERE person_id = $person_id;
DELETE FROM codedlist_tbl WHERE id IN (SELECT id FROM business_object_tbl WHERE participant_id = $person_id AND object_type_id = 'fb86b96c-68f9-11e4-913c-52540002e01a');
DELETE FROM demographics_tbl	WHERE id IN (SELECT id FROM business_object_tbl WHERE participant_id = $person_id AND object_type_id = '24e5ffa2-ebe1-11e3-a851-52540002e01a');
DELETE FROM enterprise_tbl 		WHERE id IN (SELECT id FROM business_object_tbl WHERE participant_id = $person_id AND object_type_id = '04f4e2ef-be2b-11e3-9a59-1c6f65f2b147');
DELETE FROM identity_tbl		WHERE id IN (SELECT id FROM business_object_tbl WHERE participant_id = $person_id AND object_type_id = 'b8c24d84-5e96-11e4-915e-52540002e01a');
DELETE FROM itemlist_tbl		WHERE business_object_id IN (SELECT id FROM business_object_tbl WHERE participant_id = $person_id AND object_type_id = '3f0b5f61-cea3-11e3-87e6-1c6f65f2b147');
DELETE FROM product_tbl 		WHERE id IN (SELECT id FROM business_object_tbl WHERE participant_id = $person_id AND object_type_id = '3f0b5f61-cea3-11e3-87e6-1c6f65f2b147');
DELETE FROM file_tbl	 		WHERE id IN (SELECT id FROM business_object_tbl WHERE participant_id = $person_id AND object_type_id = '3a996428-d5e1-11e3-a67e-1c6f65f2b147');
DELETE FROM project_tbl	 		WHERE id IN (SELECT id FROM business_object_tbl WHERE participant_id = $person_id AND object_type_id = '3a99abf2-d5e1-11e3-a67e-1c6f65f2b147');
DELETE FROM project_tbl	 		WHERE id IN (SELECT id FROM business_object_tbl WHERE participant_id = $person_id AND object_type_id = '3a99abf2-d5e1-11e3-a67e-1c6f65f2b147');
DELETE FROM cgu_tbl 	 		WHERE user_id = $user_id;
DELETE FROM ugu_tbl 	 		WHERE user_id = $user_id;
DELETE FROM security_qna_tbl	WHERE person_id = $person_id;
DELETE FROM user_tbl			WHERE id = $user_id;
DELETE FROM person_tbl			WHERE id = $person_id;
DELETE FROM contact_tbl			WHERE id IN (SELECT id FROM business_object_tbl WHERE participant_id = $person_id AND object_type_id = '3a7e64d3-d5e1-11e3-a67e-1c6f65f2b147');
DELETE FROM address_tbl			WHERE id IN (SELECT id FROM business_object_tbl WHERE participant_id = $person_id AND object_type_id = '3a7e848f-d5e1-11e3-a67e-1c6f65f2b147');
DELETE FROM relationship_tbl	WHERE id IN (SELECT id FROM business_object_tbl WHERE participant_id = $person_id AND object_type_id = '3a98f0dd-d5e1-11e3-a67e-1c6f65f2b147');
DELETE FROM business_object_tbl WHERE participant_id = $person_id AND id <> $person_id;
UPDATE business_object_tbl
SET participant_id = NULL
WHERE id = $person_id;
DELETE FROM business_object_tbl WHERE id = $person_id;
END;
