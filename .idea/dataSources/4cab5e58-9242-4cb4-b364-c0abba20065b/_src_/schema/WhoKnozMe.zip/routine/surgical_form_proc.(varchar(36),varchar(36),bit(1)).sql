CREATE PROCEDURE WhoKnozMe.surgical_form_proc(IN `$participant_id` VARCHAR(36), IN `$parent_id` VARCHAR(36),
                                              IN `$IsSurgical`     BIT)
  BEGIN
IF $IsSurgical = 1
	THEN
		SELECT 
			`vt`.`id` AS `id`,
			MAX(`vt`.`utc_create_time`) AS `utc_create_time`,
			`vt`.`test_type` AS `test_type`,
			`vt`.`qualifier_type_id` AS `qualifier_type_id`,
			`vt`.`approach_site_id` AS `approach_site_id`,
			`vt`.`target_site_id` AS `target_site_id`,
			`vt`.`value1_type` AS `value1_type`,
			`vt`.`notation1_type` AS `notation1_type`,
			`vt`.`notation1` AS `notation1`,
			`vt`.`value1` AS `value1`,
			`vt`.`value1_units` AS `value1_units`,
			`vt`.`value2_type` AS `value2_type`,
			`vt`.`notation2_type` AS `notation2_type`,
			`vt`.`notation2` AS `notation2`,
			`vt`.`value2` AS `value2`,
			`vt`.`value2_units` AS `value2_units`,
			`vt`.`value3_type` AS `value3_type`,
			`vt`.`notation3_type` AS `notation3_type`,
			`vt`.`notation3` AS `notation3`,
			`vt`.`value3` AS `value3`,
			`vt`.`value3_units` AS `value3_units`,
			`vt`.`device_id` AS `device_id`,
			`vt`.`next_id` AS `next_id`,
			`vt`.`comment` AS `comment`,
			`vt`.`file_id` AS `file_id`,
			`vt`.`business_object_id` AS `business_object_id`,
			`vt`.`ephr_section` AS `ephr_section`,
			`vt`.`effective_date` AS `effective_date`,
			`ct`.`codedlist_lookup_id` AS `lookup_id`,
			`cltc`.`lookup_name` AS `lookup_name`,
			`cltc`.`common_name` AS `common_name`,
			`cltc`.`parent_id` AS `parent_id`,
			`cltp`.`common_name` AS `parent_common_name`,
			`cltc`.`level` AS `level`,
			`bo`.`participant_id` AS `participant_id`
		FROM
			(((((`value_triplet_tbl` `vt`
			JOIN `codedlist_tbl` `ct` ON ((`vt`.`business_object_id` = `ct`.`id`)))
			JOIN `business_object_tbl` `bo` ON ((`bo`.`id` = `ct`.`id`)))
			JOIN `codedlist_lookup_tbl` `cltc` ON ((`cltc`.`id` = `ct`.`codedlist_lookup_id`)))
			JOIN `codedlist_lookup_tbl` `cltp` ON ((`cltp`.`id` = `cltc`.`parent_id`)))
			JOIN ((SELECT `vt1`.`business_object_id`,  max(`vt1`.`utc_create_time`) AS `utc_create_time`
			FROM `value_triplet_tbl` `vt1` GROUP BY `business_object_id`)) max_utc ON vt.business_object_id = max_utc.business_object_id AND `vt`.`utc_create_time` = max_utc.`utc_create_time`) 
		WHERE participant_id = $participant_id 
		and cltc.active  = 1 
		and cltc.parent_id = $parent_id
		and cltc.`level` = 4 
		GROUP BY `ct`.`codedlist_lookup_id`
		HAVING `utc_create_time` = MAX(`vt`.`utc_create_time`)
		
	UNION ALL 
			SELECT 
			NULL AS `id`,
			NULL AS `utc_create_time`,
			NULL AS `test_type`,
			NULL AS `qualifier_type_id`,
			NULL AS `approach_site_id`,
			NULL AS `target_site_id`,
			NULL AS `value1_type`,
			NULL AS `notation1_type`,
			NULL AS `notation1`,
			NULL AS `value1`,
			NULL AS `value1_units`,
			NULL AS `value2_type`,
			NULL AS `notation2_type`,
			NULL AS `notation2`,
			NULL AS `value2`,
			NULL AS `value2_units`,
			NULL AS `value3_type`,
			NULL AS `notation3_type`,
			NULL AS `notation3`,
			NULL AS `value3`,
			NULL AS `value3_units`,
			NULL AS `device_id`,
			NULL AS `next_id`,
			NULL AS `comment`,
			NULL AS `file_id`,
			NULL AS `business_object_id`,
			NULL AS `ephr_section`,
			NULL AS `effective_date`,
			`cltc`.`id` AS `lookup_id`,
			`cltc`.`lookup_name` AS `lookup_name`,
			`cltc`.`common_name` AS `common_name`,
			`cltc`.`parent_id` AS `parent_id`,
			`cltc`.`level` AS `level`,
			NULL AS `parent_common_name`,
			NULL AS `participant_id`
			
			FROM
			( `codedlist_lookup_tbl` `cltc` )
			WHERE cltc.active  = 1 
			and cltc.parent_id = $parent_id 
			and cltc.`level` = 4 and
			`cltc`.`id` NOT IN (SELECT codedlist_lookup_id FROM codedlist_value_triplet_view WHERE participant_id = $participant_id);
 ELSE
 -- *************************************************************************************************************
	 
		 SELECT 
			`vt`.`id` AS `id`,
			MAX(`vt`.`utc_create_time`) AS `utc_create_time`,
			`vt`.`test_type` AS `test_type`,
			`vt`.`qualifier_type_id` AS `qualifier_type_id`,
			`vt`.`approach_site_id` AS `approach_site_id`,
			`vt`.`target_site_id` AS `target_site_id`,
			`vt`.`value1_type` AS `value1_type`,
			`vt`.`notation1_type` AS `notation1_type`,
			`vt`.`notation1` AS `notation1`,
			`vt`.`value1` AS `value1`,
			`vt`.`value1_units` AS `value1_units`,
			`vt`.`value2_type` AS `value2_type`,
			`vt`.`notation2_type` AS `notation2_type`,
			`vt`.`notation2` AS `notation2`,
			`vt`.`value2` AS `value2`,
			`vt`.`value2_units` AS `value2_units`,
			`vt`.`value3_type` AS `value3_type`,
			`vt`.`notation3_type` AS `notation3_type`,
			`vt`.`notation3` AS `notation3`,
			`vt`.`value3` AS `value3`,
			`vt`.`value3_units` AS `value3_units`,
			`vt`.`device_id` AS `device_id`,
			`vt`.`next_id` AS `next_id`,
			`vt`.`comment` AS `comment`,
			`vt`.`file_id` AS `file_id`,
			`vt`.`business_object_id` AS `business_object_id`,
			`vt`.`ephr_section` AS `ephr_section`,
			`vt`.`effective_date` AS `effective_date`,
			`ct`.`codedlist_lookup_id` AS `lookup_id`,
			`cltc`.`lookup_name` AS `lookup_name`,
			`cltc`.`common_name` AS `common_name`,
			`cltc`.`parent_id` AS `parent_id`,
			`cltp`.`common_name` AS `parent_common_name`,
			`cltc`.`level` AS `level`,
			`bo`.`participant_id` AS `participant_id`
		FROM
			(((((`value_triplet_tbl` `vt`
			JOIN `codedlist_tbl` `ct` ON ((`vt`.`business_object_id` = `ct`.`id`)))
			JOIN `business_object_tbl` `bo` ON ((`bo`.`id` = `ct`.`id`)))
			JOIN `codedlist_lookup_tbl` `cltc` ON ((`cltc`.`id` = `ct`.`codedlist_lookup_id`)))
			JOIN `codedlist_lookup_tbl` `cltp` ON ((`cltp`.`id` = `cltc`.`parent_id`)))
			JOIN ((SELECT `vt1`.`business_object_id`,  max(`vt1`.`utc_create_time`) AS `utc_create_time`
			FROM `value_triplet_tbl` `vt1` GROUP BY `business_object_id`)) max_utc ON vt.business_object_id = max_utc.business_object_id AND `vt`.`utc_create_time` = max_utc.`utc_create_time`) 
		WHERE participant_id = $participant_id 
		and cltc.parent_id = $parent_id
		and cltc.`level` = 4 
		GROUP BY `ct`.`codedlist_lookup_id`
		HAVING `utc_create_time` = MAX(`vt`.`utc_create_time`)
		
	UNION ALL 
			SELECT 
			NULL AS `id`,
			NULL AS `utc_create_time`,
			NULL AS `test_type`,
			NULL AS `qualifier_type_id`,
			NULL AS `approach_site_id`,
			NULL AS `target_site_id`,
			NULL AS `value1_type`,
			NULL AS `notation1_type`,
			NULL AS `notation1`,
			NULL AS `value1`,
			NULL AS `value1_units`,
			NULL AS `value2_type`,
			NULL AS `notation2_type`,
			NULL AS `notation2`,
			NULL AS `value2`,
			NULL AS `value2_units`,
			NULL AS `value3_type`,
			NULL AS `notation3_type`,
			NULL AS `notation3`,
			NULL AS `value3`,
			NULL AS `value3_units`,
			NULL AS `device_id`,
			NULL AS `next_id`,
			NULL AS `comment`,
			NULL AS `file_id`,
			NULL AS `business_object_id`,
			NULL AS `ephr_section`,
			NULL AS `effective_date`,
			`cltc`.`id` AS `lookup_id`,
			`cltc`.`lookup_name` AS `lookup_name`,
			`cltc`.`common_name` AS `common_name`,
			`cltc`.`parent_id` AS `parent_id`,
			`cltc`.`level` AS `level`,
			NULL AS `parent_common_name`,
			NULL AS `participant_id`
			
			FROM
			( `codedlist_lookup_tbl` `cltc` )
			WHERE cltc.parent_id = $parent_id 
			and cltc.`level` = 4 and
			`cltc`.`id` NOT IN (SELECT codedlist_lookup_id FROM codedlist_value_triplet_view WHERE participant_id = $participant_id);
END IF;
END;
