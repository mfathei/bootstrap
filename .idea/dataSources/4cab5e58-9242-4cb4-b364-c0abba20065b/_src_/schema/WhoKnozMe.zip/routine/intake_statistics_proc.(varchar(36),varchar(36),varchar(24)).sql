CREATE PROCEDURE WhoKnozMe.intake_statistics_proc(IN `$person_id`        VARCHAR(36), IN `$idnetifier` VARCHAR(36),
                                                  IN `$lookup_type_name` VARCHAR(24))
  BEGIN
Parameters: BEGIN
DECLARE $business_object_id VARCHAR(36);
DECLARE $notation2_type VARCHAR(45);
DECLARE $notation2 VARCHAR(36);
DECLARE $notation3_type VARCHAR(45);
DECLARE $notation3 VARCHAR(36);
DECLARE $col_name VARCHAR(255);
DECLARE $lookup_type_id VARCHAR(36);
DECLARE $cLst_done, Fetch_Status BIT DEFAULT 0;
DECLARE $cLst_id VARCHAR(36);
SET $business_object_id = (SELECT ephr_intake_fun($person_id, $idnetifier));
SET @notation = 'select test_type,  notation1_type, count(notation1) as notation_count, business_object_id ';
SET @fromclause = ' 
					from value_triplet_tbl vtt left join codedlist_lookup_tbl clt on vtt.test_type = clt.lookup_name  
					left join codedlist_lookup_tbl clt1 on clt.id = clt1.id ';
SET @whereclause = CONCAT(' 
					where business_object_id in (select id from codedlist_tbl where id in (select object_id from relationship_tbl where subject_id = ',"'",$business_object_id,"'",'and codedlist_lookup_id in (select id from codedlist_lookup_tbl where ephr_section_orginal = ',"'",$lookup_type_name,"'",'))) and notation1 = 'P'');
SET @group_by = '  
					group by   notation1_type, test_type
';
SET @Order_by = '
					order by clt.list_index, test_type, clt1.list_index, notation1_type ';
Block1: BEGIN
 -- notation2 CURSOR --
DECLARE $notation2_cur CURSOR FOR SELECT DISTINCT notation2_type,notation2 
FROM value_triplet_tbl vtb LEFT OUTER JOIN lookup_tbl lt ON vtb.notation2 = lookup_name
WHERE business_object_id IN (SELECT id FROM codedlist_tbl WHERE id IN (SELECT object_id FROM relationship_tbl WHERE subject_id = $business_object_id) AND codedlist_lookup_id IN (SELECT id FROM codedlist_lookup_tbl WHERE ephr_section_orginal = $lookup_type_name))
AND notation2 IS NOT NULL
ORDER BY notation2_type, lt.list_index;
 -- notation3 CURSOR --
DECLARE $notation3_cur CURSOR FOR SELECT DISTINCT notation3_type, notation3 
FROM value_triplet_tbl vtb LEFT OUTER JOIN lookup_tbl lt ON vtb.notation3 = lookup_name
WHERE business_object_id IN (SELECT id FROM codedlist_tbl WHERE id IN (SELECT object_id FROM relationship_tbl WHERE subject_id = $business_object_id) AND codedlist_lookup_id IN (SELECT id FROM codedlist_lookup_tbl WHERE ephr_section_orginal = $lookup_type_name))
AND notation3 IS NOT NULL
ORDER BY notation3_type, lt.list_index;
DECLARE CONTINUE HANDLER FOR NOT FOUND SET Fetch_Status = 1;
OPEN $notation2_cur;
FETCH NEXT FROM $notation2_cur INTO $notation2_type, $notation2;
WHILE Fetch_Status = 0 
DO 
SET $notation2 = REPLACE($notation2,'-','_');
SET $notation2_type = REPLACE($notation2_type,'-','_');
SET $col_name = CONCAT($notation2_type,'_',$notation2);
SET @notation = CONCAT(@notation,
' ,
(select intake_statistics_fun(test_type,notation1_type,notation1, '',$notation2_type,'', business_object_id,  '',$notation2,'', 2))
 as ',$col_name,' ');
FETCH NEXT FROM  $notation2_cur
INTO $notation2_type, $notation2;
END WHILE;
CLOSE $notation2_cur;
SET Fetch_status = 0;
OPEN $notation3_cur;
FETCH NEXT FROM $notation3_cur INTO $notation3_type, $notation3;
WHILE Fetch_Status = 0 
DO 
SET $notation3 = REPLACE($notation3,'-','_');
SET $notation3_type = REPLACE($notation3_type,'-','_');
SET $col_name = CONCAT($notation3_type,'_',$notation3);
SET @notation = CONCAT(@notation,
' , (select intake_statistics_fun(test_type,notation1_type,notation1,'',$notation3_type,'',   business_object_id, '',$notation3,'', 3))
   as ',$col_name,' ');
FETCH NEXT FROM  $notation3_cur
INTO $notation3_type, $notation3;
END WHILE;
CLOSE $notation3_cur;
END Block1;
SET @selectstmt = CONCAT(@notation,@fromclause,@whereclause,@group_by,@Order_by);
PREPARE stmt FROM @selectstmt;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
 
END Parameters;
END;
