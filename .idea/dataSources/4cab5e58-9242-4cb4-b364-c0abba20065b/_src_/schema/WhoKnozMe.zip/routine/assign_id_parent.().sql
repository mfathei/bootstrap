CREATE PROCEDURE WhoKnozMe.assign_id_parent()
  BEGIN
DECLARE $MIN, $MAX, $Plevel, $CLevel, $POrder INT;
DECLARE $id, $Pid VARCHAR(36);
SET $MIN = (SELECT MIN(OrderAI) FROM _ICD9Temp2);
SET $MAX = (SELECT MAX(OrderAI) FROM _ICD9Temp2);
WHILE $MIN <= $MAX
DO 
SET $CLevel = (SELECT `level` FROM _ICD9Temp2 WHERE OrderAI = $MIN);
SET $id = (SELECT generate_uuid());
UPDATE _ICD9Temp2 SET id = $id WHERE OrderAI = $MIN;
IF $CLevel > 1
THEN 
SET $POrder = (SELECT MAX(OrderAI) FROM _ICD9Temp2 WHERE `level` = $CLevel - 1 AND OrderAI < $MIN);
SET $Pid = (SELECT id FROM _ICD9Temp2 WHERE OrderAI = $POrder);
UPDATE _ICD9Temp2 SET parent_id = $Pid WHERE OrderAI = $MIN;
END IF;
SET $MIN = $MIN + 1;
/*-- SET $PLevel = $CLevel;
SET $CLevel = (select levelI from _TempICD9 where OrderN = $Min);
SET $id = (select generate_uuid());
update _TempICD9 set id = $id;
if $Clevel > $PLevel
then 
 IF $CLevel = $MLevel 
	THEN 
update _TempICD9 set parent_id = $Pid;
END IF;
IF $CLevel > $MLevel
then
update _TempICD9 set parent_id = $Mid;
update 
end if;
SET $MLevel = $CLevel;
SET $Mid = $id;
end if;*/
END WHILE;
END;
