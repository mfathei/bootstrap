CREATE FUNCTION WhoKnozMe.RELATIONSHIPS_BO_FUN(`$bo_id` VARCHAR(36), `$participant_id` VARCHAR(36), `$flag` BIT)
  RETURNS TEXT
  BEGIN
DECLARE $ret TEXT;
DECLARE $contacts_group_id, $relationship VARCHAR(36);
IF $Participant_id IS NULL
THEN SET $ret = NULL;
ELSE
SET $relationship = (SELECT relationship_tbl.id FROM relationship_tbl INNER JOIN business_object_tbl ON business_object_tbl.id=relationship_tbl.id WHERE hidden = 0 AND subject_id = $participant_id AND object_id = $bo_id LIMIT 1);
SET $contacts_group_id = ephr_intake_fun($participant_id, 'contacts');
IF $flag = 0 THEN
SET $ret = (SELECT GROUP_CONCAT(bo_name SEPARATOR ', ') FROM business_object_tbl WHERE id IN (SELECT object_id FROM relationship_tbl
 WHERE subject_id = $contacts_group_id) AND id IN (SELECT subject_id FROM relationship_tbl 
WHERE object_id = $relationship) AND object_type_id = (SELECT id FROM object_type_tbl WHERE abbrev = 'g'));
 ELSE 
SET $ret = (SELECT GROUP_CONCAT(id SEPARATOR ', ') FROM business_object_tbl WHERE id IN (SELECT object_id FROM relationship_tbl
 WHERE subject_id = $contacts_group_id) AND id IN (SELECT subject_id FROM relationship_tbl 
WHERE object_id = $relationship) AND object_type_id = (SELECT id FROM object_type_tbl WHERE abbrev = 'g'));
END IF;
END IF;
RETURN $ret;
END;
