CREATE FUNCTION WhoKnozMe.getCleanQuestion(`$question` TEXT)
  RETURNS TEXT
  BEGIN
        set @start = 29; -- position("<Question>" in $question) + 10;
        set @end = POSITION("</Question>" IN $question);
        set @str = substr($question , @start);
        set @extra = substr($question , @end, length($question));
        set $question = replace(@str, @extra, '');
        
        return $question;
    END;
