CREATE PROCEDURE WhoKnozMe.GroupCursor(IN `$PriceListId` VARCHAR(36), OUT `$GroupName` VARCHAR(255))
  BEGIN
DECLARE fetch_status INT DEFAULT 0;
DECLARE $GroupId VARCHAR(36);
DECLARE $TestId VARCHAR(36);
DECLARE $GroupName VARCHAR(255);
DECLARE Group_cursor CURSOR FOR 
		SELECT  object_id FROM  relationship_tbl
		WHERE subject_id  = $PriceListId AND object_id IN  (SELECT id FROM business_object_tbl WHERE object_type_id IN (SELECT id FROM object_type_tbl WHERE object_type_name = 'group'));
DECLARE CONTINUE HANDLER FOR NOT FOUND SET fetch_status = 100;
OPEN Group_cursor;
FETCH Group_cursor INTO $GroupId;
WHILE fetch_status = 0
DO
SET $TestId = (SELECT object_id FROM relationship_tbl WHERE subject_id = $GroupId  LIMIT 1);
IF $TestId IN (SELECT id FROM business_object_tbl WHERE object_type_id = (SELECT id FROM object_type_tbl WHERE object_type_name = 'product')) THEN
					SET $GroupName = (SELECT fullname FROM business_object_tbl WHERE id = $GroupId);
ELSE
WHILE $TestId = (SELECT id FROM business_object_tbl WHERE object_type_id <> (SELECT id FROM object_type_tbl WHERE object_type_name = 'product') LIMIT 1)
	DO
	SET $GroupId = $TestId;
	SET $TestId = (SELECT object_id FROM relationship_tbl WHERE subject_id = $GroupId LIMIT 1);
	SET $GroupName = (SELECT fullname FROM business_object_tbl WHERE id = $GroupId);
	END WHILE;					
						-- select $GroupName;
	END IF;
SELECT $GroupName;
FETCH Group_cursor INTO $GroupId;
END WHILE;
CLOSE Group_cursor;
END;
