CREATE PROCEDURE WhoKnozMe.admin_company(IN `$person_id` VARCHAR(36))
  BEGIN
/*DECLARE $acct_id VARCHAR(36);
DECLARE $company_id VARCHAR(36);
DECLARE $CompanyGroupID VARCHAR(36);
SET $acct_id = (select id from account_tbl where cust_vend_id = $person_id);
SET $CompanyGroupID = (SELECT subject_id FROM relationship_tbl WHERE object_id = $acct_id);
SET $company_id = (select subject_id from relationship_tbl where object_id = $CompanyGroupID);*/
if (select company_admin_fun ($person_id)) = 1
then
select id, abbrev from company_tbl where id = 'e70a79c9-d603-11e3-a67e-1c6f65f2b147';
end if ;
if (select company_admin_fun ($person_id)) = 2
then
select id, abbrev from company_tbl where id = 'e70abcd3-d603-11e3-a67e-1c6f65f2b147';
end if;
END;
