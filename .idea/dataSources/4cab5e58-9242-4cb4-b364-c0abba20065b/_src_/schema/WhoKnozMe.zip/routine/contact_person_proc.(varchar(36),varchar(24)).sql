CREATE PROCEDURE WhoKnozMe.contact_person_proc(IN `$person_id` VARCHAR(36), IN `$group_type` VARCHAR(24))
  BEGIN
DECLARE $contact_group_id VARCHAR(36);
IF $group_type = 'emergency'
THEN
 SET $contact_group_id = ephr_intake_fun( $person_id,'contacts_emergency_contacts');
 SELECT SQL_CALC_FOUND_ROWS rel.id,relationship_id,rel.list_index, vw.end_date, bo_name,BoOfBillAddress, vw.rel_type_name, phone_number1, phone_type_name1, area_code1, phone_number2, phone_type_name2, area_code2, phone_number3, phone_type_name3,  area_code3, phone_code, sms, vw.object_role, vw.contact_id,email
 FROM person_contact_view vw JOIN relationship_tbl rel ON(rel.`object_id` = vw.`relationship_id` AND rel.`subject_id` = $contact_group_id)
 -- where person_id in (select object_id from relationship_tbl where subject_id = $person_id and id in (select object_id from relationship_tbl where subject_id = $contact_group_id ))
 AND vw.subject_id = $person_id
 AND vw.rel_type_id NOT IN  ('e9c438b2-68c2-11e4-913c-52540002e01a','5d7df21c-48a1-11e4-9cf6-52540002e01a')  ORDER BY (rel.end_date IS NULL),rel.end_date DESC, rel.list_index ASC;
ELSEIF $group_type = 'care'
THEN
 SET $contact_group_id = ephr_intake_fun( $person_id,'care_team');
 SELECT SQL_CALC_FOUND_ROWS rel.id,relationship_id,rel.list_index, vw.end_date, bo_name,BoOfBillAddress, vw.rel_type_name, phone_number1, phone_type_name1, area_code1, phone_number2, phone_type_name2, area_code2, phone_number3, phone_type_name3,  area_code3, phone_code, sms, vw.object_role, vw.contact_id,email
 FROM person_contact_view vw JOIN relationship_tbl rel ON(rel.`object_id` = vw.`relationship_id` AND rel.`subject_id` = $contact_group_id) 
 -- where person_id in (select object_id from relationship_tbl where subject_id = $person_id and id in (select object_id from relationship_tbl where subject_id = $contact_group_id ))
 AND vw.subject_id = $person_id
 AND vw.rel_type_id NOT IN ('e9c438b2-68c2-11e4-913c-52540002e01a','5d7df21c-48a1-11e4-9cf6-52540002e01a') ORDER BY (rel.end_date IS NULL),rel.end_date DESC, rel.list_index ASC;
    
 ELSEIF $group_type = 'fGeneric'
THEN
 SET $contact_group_id = ephr_intake_fun( $person_id,'family(Genetic)');
 SELECT SQL_CALC_FOUND_ROWS rel.id,relationship_id,rel.list_index, vw.end_date, bo_name,BoOfBillAddress, vw.rel_type_name, phone_number1, phone_type_name1, area_code1, phone_number2, phone_type_name2, area_code2, phone_number3, phone_type_name3,  area_code3, phone_code, sms, vw.object_role, vw.contact_id,email
 FROM person_contact_view vw JOIN relationship_tbl rel ON(rel.`object_id` = vw.`relationship_id` AND rel.`subject_id` = $contact_group_id)
 -- where person_id in (select object_id from relationship_tbl where subject_id = $person_id and id in (select object_id from relationship_tbl where subject_id = $contact_group_id ))
 AND vw.subject_id = $person_id
 AND vw.rel_type_id NOT IN ('e9c438b2-68c2-11e4-913c-52540002e01a','5d7df21c-48a1-11e4-9cf6-52540002e01a');
       
   
ELSEIF $group_type = 'fLivingArrang'
THEN
 SET $contact_group_id = ephr_intake_fun( $person_id,'family(living_arrangement)');
 SELECT SQL_CALC_FOUND_ROWS rel.id,relationship_id,rel.list_index, vw.end_date, bo_name,BoOfBillAddress, vw.rel_type_name, phone_number1, phone_type_name1, area_code1, phone_number2, phone_type_name2, area_code2, phone_number3, phone_type_name3,  area_code3, phone_code, sms, vw.object_role, vw.contact_id,email
 FROM person_contact_view vw JOIN relationship_tbl rel ON(rel.`object_id` = vw.`relationship_id` AND rel.`subject_id` = $contact_group_id)
 -- where person_id in (select object_id from relationship_tbl where subject_id = $person_id and id in (select object_id from relationship_tbl where subject_id = $contact_group_id ))
 AND vw.subject_id = $person_id
 AND vw.rel_type_id NOT IN ('e9c438b2-68c2-11e4-913c-52540002e01a','5d7df21c-48a1-11e4-9cf6-52540002e01a');
ELSEIF $group_type = 'caregiver'
THEN
  SET $contact_group_id = ephr_intake_fun( $person_id,'caregiver_clients');
 SELECT SQL_CALC_FOUND_ROWS rel.id,relationship_id,rel.list_index, vw.end_date, bo_name,BoOfBillAddress, vw.rel_type_name, phone_number1, phone_type_name1, area_code1, phone_number2, phone_type_name2, area_code2, phone_number3, phone_type_name3,  area_code3, phone_code, sms, vw.object_role, vw.contact_id,email
 FROM person_contact_view vw JOIN relationship_tbl rel ON(rel.`object_id` = vw.`relationship_id` AND rel.`subject_id` = $contact_group_id)
 -- where person_id in (select object_id from relationship_tbl where subject_id = $person_id and id in (select object_id from relationship_tbl where subject_id = $contact_group_id ))
 AND vw.subject_id = $person_id
 AND vw.rel_type_id NOT IN ('e9c438b2-68c2-11e4-913c-52540002e01a','5d7df21c-48a1-11e4-9cf6-52540002e01a');
ELSEIF $group_type = 'addressbook'
THEN
  SET $contact_group_id = ephr_intake_fun( $person_id,'address_book');
 SELECT SQL_CALC_FOUND_ROWS rel.id,relationship_id,rel.list_index, vw.end_date, bo_name,BoOfBillAddress, vw.rel_type_name, phone_number1, phone_type_name1, area_code1, phone_number2, phone_type_name2, area_code2, phone_number3, phone_type_name3,  area_code3, phone_code, sms, vw.object_role, vw.contact_id,email
 FROM person_contact_view vw JOIN relationship_tbl rel ON(rel.`object_id` = vw.`relationship_id` AND rel.`subject_id` = $contact_group_id)
 -- where person_id in (select object_id from relationship_tbl where subject_id = $person_id and id in (select object_id from relationship_tbl where subject_id = $contact_group_id ))
 AND vw.subject_id = $person_id
 AND vw.rel_type_id NOT IN ('e9c438b2-68c2-11e4-913c-52540002e01a','5d7df21c-48a1-11e4-9cf6-52540002e01a');
END IF;
SELECT FOUND_ROWS() AS `count`;
END;
