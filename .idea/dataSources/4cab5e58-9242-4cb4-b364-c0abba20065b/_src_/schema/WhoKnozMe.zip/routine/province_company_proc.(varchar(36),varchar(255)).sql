CREATE PROCEDURE WhoKnozMe.province_company_proc(IN `$province_id` VARCHAR(36), IN `$incorp_type_name` VARCHAR(255))
  BEGIN
DECLARE $incorp_type_id, $lookup_type_id VARCHAR(36);
SET $Lookup_type_id = '36dc752b-9d18-11e4-b362-5254000a52fa';
SET $incorp_type_id = (SELECT id FROM lookup_tbl WHERE lookup_type_id = $lookup_type_id AND lookup_name = $incorp_type_name);
SELECT * FROM 
company_bo_view
WHERE id IN (SELECT id FROM company_co_view WHERE incorp_type_name = $incorp_type_name AND  (SpProvID = $province_id OR BpProvID = $province_id));
/*incorp_type_id = $incorp_type_id
AND contact_id in (select contact_id from contact_tbl where billto_address_id in 
					(select tbl1.id from address_tbl tbl1 inner join city_tbl tbl2 on tbl1.city_id = tbl2.id
					 where tbl2.province_tbl_id = $province_id)
					 or shipto_address_id in 
					(select tbl1.id from address_tbl tbl1 inner join city_tbl tbl2 on tbl1.city_id = tbl2.id
					 where tbl2.province_tbl_id = $province_id));*/
END;
