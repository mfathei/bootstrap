CREATE PROCEDURE WhoKnozMe.ServiceRequests_proc(IN xmlData TEXT)
  BEGIN
SET @page = EXTRACTVALUE(xmlData, '//page');
SET @LIMIT = EXTRACTVALUE(xmlData, '//limit');
SET @sortOrder =  EXTRACTVALUE(xmlData, '//sortOrder');
SET @INDEX =  EXTRACTVALUE(xmlData, '//index');
SET @participant_id =  EXTRACTVALUE(xmlData, '//participant_id');
SET @selectquery ="SELECT *	";
SET @queryFrom = " from  project_bo_view";
SET @queryWhere = ' where bo_properties like "%service_request%" and hidden = 0 AND participant_id= ';
SET @queryWhere = CONCAT(@queryWhere,'"',@participant_id,'"'); 
SET @myArrayOfValue = ' id, task_number, fullname, bo_name, status, effective_date, expiry_date, percent_complete, priority_type_name, qualitative_type_name, task_number2, ';
SET @Postition = LOCATE(',', @myArrayOfValue);
WHILE ( @Postition > 0 ) DO
	SET @STR = SUBSTRING(@myArrayOfValue, 1, @Postition-1);
	SET @myArrayOfValue = SUBSTRING(@myArrayOfValue, @Postition + 1);
	SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//',@STR));
	IF (@Col != '' AND @Col !='NULL') THEN
		SET @queryWhere = CONCAT(@queryWhere,CONCAT(' AND ',@STR,' like('"'%", @Col ,"%'"') '));	
	END IF;
	
	SET @Postition = LOCATE(',', @myArrayOfValue);
END WHILE;
SET @querycount = CONCAT( 'SELECT count(*) into @cnt ', @queryFrom, @queryWhere );
PREPARE stmt1 FROM @querycount;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
SET @selectquery = CONCAT (@selectquery,', ', @cnt, ' as Count ');
SET @QUERY = CONCAT( @selectquery, @queryFrom, @queryWhere );
SET @QUERY = CONCAT(@QUERY, ' order by ', @INDEX,'  ', @sortOrder);
SET @page = (@page - 1) * @LIMIT;
SET @QUERY = CONCAT(@QUERY, ' LIMIT ', @LIMIT ,' OFFSET ',  @page);
 
 
PREPARE stmt1 FROM @QUERY;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
END;
