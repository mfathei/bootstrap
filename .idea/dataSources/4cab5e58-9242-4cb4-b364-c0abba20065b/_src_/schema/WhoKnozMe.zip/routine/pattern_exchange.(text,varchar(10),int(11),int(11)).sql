CREATE FUNCTION WhoKnozMe.pattern_exchange(str TEXT, delim VARCHAR(10), X INT, Y INT)
  RETURNS TEXT
  BEGIN
	SET @first_pattern = SPLIT_STRING(str, delim, X);
	SET @second_pattern = SPLIT_STRING(str, delim, Y);
	SET str = REPLACE(str, @first_pattern, 't_m_p');
    SET str = REPLACE(str, @second_pattern, @first_pattern);
    SET str = REPLACE(str, 't_m_p', @second_pattern);
	RETURN str;
END;
