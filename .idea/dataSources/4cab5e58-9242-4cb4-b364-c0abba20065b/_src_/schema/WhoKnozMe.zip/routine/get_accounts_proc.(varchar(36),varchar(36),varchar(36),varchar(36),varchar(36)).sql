CREATE PROCEDURE WhoKnozMe.get_accounts_proc(IN `$phn`   VARCHAR(36), IN `$dln` VARCHAR(36), IN `$memb_id` VARCHAR(36),
                                             IN `$lname` VARCHAR(36), IN `$fname` VARCHAR(36))
  BEGIN
DECLARE $phn1 VARCHAR(36);
DECLARE $dln1 VARCHAR(36);
DECLARE $memb_id1 VARCHAR(36);
SET $phn1 = (SELECT vend_cust_acct_num FROM account_tbl WHERE  REPLACE( vend_cust_acct_num, " ", "" )=$phn);
SET $dln1 = (SELECT vend_cust_acct_num FROM account_tbl WHERE  REPLACE( vend_cust_acct_num, " ", "" )=$dln);
SET $memb_id1 = (SELECT vend_cust_acct_num FROM account_tbl WHERE  REPLACE( vend_cust_acct_num, " ", "" )=$memb_id);
SELECT cust_vend_id FROM account_tbl INNER JOIN person_tbl ON person_tbl.id =cust_vend_id WHERE last_name = $lname AND (first_name = $fname OR goes_by_name =$fname) AND (vend_cust_acct_num=$phn1 AND cust_vend_acct_num = 'PHN') OR (vend_cust_acct_num=$dln1 AND cust_vend_acct_num = 'DLN') OR (vend_cust_acct_num = $memb_id1 AND vend_cust_id ='5711dd11-3348-11e4-8260-5254000a52fa') ;
END;
