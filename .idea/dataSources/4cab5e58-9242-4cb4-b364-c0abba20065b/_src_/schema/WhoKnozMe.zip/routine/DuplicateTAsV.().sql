CREATE PROCEDURE WhoKnozMe.DuplicateTAsV()
  BEGIN
        DECLARE p_finished INTEGER DEFAULT 0;
        DECLARE vid VARCHAR(36);
        DECLARE vlist_index VARCHAR(24);
        DECLARE vlevel VARCHAR(12);
        DECLARE vlevel_type VARCHAR(24);
        DECLARE vlookup_type_id VARCHAR(36);
        DECLARE vMedicalObservation VARCHAR(255);
        DECLARE vtaxonomy VARCHAR(255);
        DECLARE vConceptCompany_id VARCHAR(36);
        DECLARE vConceptID VARCHAR(55);
        DECLARE vMedicalAbbreviation VARCHAR(24);
        DECLARE vMedicalDescription VARCHAR(100);
        DECLARE vtranslation_id VARCHAR(36);
        DECLARE vbusiness_rule_id VARCHAR(36);
        DECLARE vfile_id VARCHAR(36);
        DECLARE vnext_id VARCHAR(36);
        DECLARE vDevice VARCHAR(45);
        DECLARE vCommonAbbrev VARCHAR(45);
        DECLARE vCommonName VARCHAR(45);
        DECLARE vCommonLanguage VARCHAR(45);
        DECLARE vDescription TEXT;
        DECLARE vSampleMaterial VARCHAR(45);
        DECLARE vappoach_site_id VARCHAR(36);
        DECLARE vtarget_site_id VARCHAR(36);
        DECLARE vmethod_id VARCHAR(36);
        DECLARE vicd_9_10_id VARCHAR(36);
        DECLARE vlabtest_value VARCHAR(45);
        DECLARE vsubject_inst_value VARCHAR(45);
        DECLARE vIncludes VARCHAR(45);
        DECLARE vinterpretation_range_desc VARCHAR(100);
        DECLARE vInterpretationDecoder VARCHAR(45);
        DECLARE vInterpretation VARCHAR(45);
        DECLARE vGender VARCHAR(45);
        DECLARE vage_range_text VARCHAR(45);
        DECLARE vage_min INT(11);
        DECLARE vage_test VARCHAR(45);
        DECLARE vage_max INT(11);
        DECLARE vref_range_text VARCHAR(45);
        DECLARE vref_range_operator VARCHAR(45);
        DECLARE vref_range_min INT(11);
        DECLARE vref_range_max INT(11);
        DECLARE vSI_Units_abbrev VARCHAR(45);
        DECLARE vComments TEXT;
        DECLARE vparent_id VARCHAR(36);
        DECLARE p_cursor CURSOR FOR
            SELECT 
            `list_index`,
            `level`,
            `lookup_type_id`,
            `MedicalObservation`,
            `taxonomy`,
            `ConceptCompany_id`,
            `ConceptID`,
            `MedicalAbbreviation`,
            `MedicalDescription`,
            `translation_id`,
            `business_rule_id`,
            `file_id`,
            `next_id`,
            `Device`,
            `CommonAbbrev`,
            `CommonName`,
            `CommonLanguage`,
            `Description`,
            `SampleMaterial`,
            `appoach_site_id`,
            `target_site_id`,
            `method_id`,
            `icd_9_10_id`,
            `labtest_value`,
            `subject_inst_value`,
            `Includes`,
            `interpretation_range_desc`,
            `InterpretationDecoder`,
            `Interpretation`,
            `Gender`,
            `age_range_text`,
            `age_min`,
            `age_test`,
            `age_max`,
            `ref_range_text`,
            `ref_range_operator`,
            `ref_range_min`,
            `ref_range_max`,
            `SI_Units_abbrev`,
            `Comments`,
            `parent_id`
            FROM observation_lookup_tbl it 
            WHERE it.level_type = 'T';
            -- and it.id='02df1eea-1aac-11e6-8267-5254000a52fa';
        -- declare NOT FOUND handler
        DECLARE CONTINUE HANDLER FOR NOT FOUND SET p_finished = 1;
        
    OPEN p_cursor;
    ex: LOOP
        
        FETCH p_cursor INTO  
            vlist_index,
            vlevel,
            vlookup_type_id,
            vMedicalObservation,
            vtaxonomy,
            vConceptCompany_id,
            vConceptID,
            vMedicalAbbreviation,
            vMedicalDescription,
            vtranslation_id,
            vbusiness_rule_id,
            vfile_id,
            vnext_id,
            vDevice,
            vCommonAbbrev,
            vCommonName,
            vCommonLanguage,
            vDescription,
            vSampleMaterial,
            vappoach_site_id,
            vtarget_site_id,
            vmethod_id,
            vicd_9_10_id,
            vlabtest_value,
            vsubject_inst_value,
            vIncludes,
            vinterpretation_range_desc,
            vInterpretationDecoder,
            vInterpretation,
            vGender,
            vage_range_text,
            vage_min,
            vage_test,
            vage_max,
            vref_range_text,
            vref_range_operator,
            vref_range_min,
            vref_range_max,
            vSI_Units_abbrev,
            vComments,
            vparent_id
        ;
	
        IF p_finished = 1 THEN 
            LEAVE ex;
        END IF;	
	/**
        select 
            vlist_index,
            vlevel,
            vlookup_type_id,
            vMedicalObservation,
            vtaxonomy,
            vConceptCompany_id,
            vConceptID,
            vMedicalAbbreviation,
            vMedicalDescription,
            vtranslation_id,
            vbusiness_rule_id,
            vfile_id,
            vnext_id,
            vDevice,
            vCommonAbbrev,
            vCommonName,
            vCommonLanguage,
            vDescription,
            vSampleMaterial,
            vappoach_site_id,
            vtarget_site_id,
            vmethod_id,
            vicd_9_10_id,
            vlabtest_value,
            vsubject_inst_value,
            vIncludes,
            vinterpretation_range_desc,
            vInterpretationDecoder,
            vInterpretation,
            vGender,
            vage_range_text,
            vage_min,
            vage_test,
            vage_max,
            vref_range_text,
            vref_range_operator,
            vref_range_min,
            vref_range_max,
            vSI_Units_abbrev,
            vComments,
            vparent_id;
            **/
SET @cnt = (	
SELECT id FROM observation_lookup_tbl WHERE
IFNULL(list_index,'')=IFNULL(vlist_index,'') AND 
IFNULL(lookup_type_id,'')=IFNULL(vlookup_type_id,'') AND 
IFNULL(MedicalObservation,'')=IFNULL(vMedicalObservation,'') AND 
IFNULL(taxonomy,'')=IFNULL(vtaxonomy,'') AND 
IFNULL(ConceptCompany_id,'')=IFNULL(vConceptCompany_id,'') AND 
IFNULL(ConceptID,'')=IFNULL(vConceptID,'') AND 
IFNULL(MedicalAbbreviation,'')=IFNULL(vMedicalAbbreviation,'') AND 
IFNULL(MedicalDescription,'')=IFNULL(vMedicalDescription,'') AND 
IFNULL(translation_id,'')=IFNULL(vtranslation_id,'') AND 
IFNULL(business_rule_id,'')=IFNULL(vbusiness_rule_id,'') AND 
IFNULL(file_id,'')=IFNULL(vfile_id,'') AND 
IFNULL(next_id,'')=IFNULL(vnext_id,'') AND 
IFNULL(Device,'')=IFNULL(vDevice,'') AND 
IFNULL(CommonAbbrev,'')=IFNULL(vCommonAbbrev,'') AND 
IFNULL(CommonName,'')=IFNULL(vCommonName,'') AND 
IFNULL(CommonLanguage,'')=IFNULL(vCommonLanguage,'') AND 
IFNULL(Description,'')=IFNULL(vDescription,'') AND 
IFNULL(SampleMaterial,'')=IFNULL(vSampleMaterial,'') AND 
IFNULL(appoach_site_id,'')=IFNULL(vappoach_site_id,'') AND 
IFNULL(target_site_id,'')=IFNULL(vtarget_site_id,'') AND 
IFNULL(method_id,'')=IFNULL(vmethod_id,'') AND 
IFNULL(icd_9_10_id,'')=IFNULL(vicd_9_10_id,'') AND 
IFNULL(labtest_value,'')=IFNULL(vlabtest_value,'') AND 
IFNULL(subject_inst_value,'')=IFNULL(vsubject_inst_value,'') AND 
IFNULL(Includes,'')=IFNULL(vIncludes,'') AND 
IFNULL(interpretation_range_desc,'')=IFNULL(vinterpretation_range_desc,'') AND 
IFNULL(InterpretationDecoder,'')=IFNULL(vInterpretationDecoder,'') AND 
IFNULL(Interpretation,'')=IFNULL(vInterpretation,'') AND 
IFNULL(Gender,'')=IFNULL(vGender,'') AND 
IFNULL(age_range_text,'')=IFNULL(vage_range_text,'') AND 
IFNULL(age_min,'')=IFNULL(vage_min,'') AND 
IFNULL(age_test,'')=IFNULL(vage_test,'') AND 
IFNULL(age_max,'')=IFNULL(vage_max,'') AND 
IFNULL(ref_range_text,'')=IFNULL(vref_range_text,'') AND 
IFNULL(ref_range_operator,'')=IFNULL(vref_range_operator,'') AND 
IFNULL(ref_range_min,'')=IFNULL(vref_range_min,'') AND 
IFNULL(ref_range_max,'')=IFNULL(vref_range_max,'') AND 
IFNULL(SI_Units_abbrev,'')=IFNULL(vSI_Units_abbrev,'') AND 
IFNULL(Comments,'')=IFNULL(vComments,'') AND 
IFNULL(parent_id,'')=IFNULL(vparent_id,'')
AND level_type = 'V'
);
    IF @cnt IS NULL THEN
        
            INSERT INTO observation_lookup_tbl VALUES(
            
                UUID(),
                vlist_index,
                '2',
                'V',
                vlookup_type_id,
                vMedicalObservation,
                vtaxonomy,
                vConceptCompany_id,
                vConceptID,
                vMedicalAbbreviation,
                vMedicalDescription,
                vtranslation_id,
                vbusiness_rule_id,
                vfile_id,
                vnext_id,
                vDevice,
                vCommonAbbrev,
                vCommonName,
                vCommonLanguage,
                vDescription,
                vSampleMaterial,
                vappoach_site_id,
                vtarget_site_id,
                vmethod_id,
                vicd_9_10_id,
                vlabtest_value,
                vsubject_inst_value,
                vIncludes,
                vinterpretation_range_desc,
                vInterpretationDecoder,
                vInterpretation,
                vGender,
                vage_range_text,
                vage_min,
                vage_test,
                vage_max,
                vref_range_text,
                vref_range_operator,
                vref_range_min,
                vref_range_max,
                vSI_Units_abbrev,
                vComments,
                vparent_id
            
            );
        
    END IF;
	
	END LOOP ex;
    CLOSE p_cursor;        
        
    END;
