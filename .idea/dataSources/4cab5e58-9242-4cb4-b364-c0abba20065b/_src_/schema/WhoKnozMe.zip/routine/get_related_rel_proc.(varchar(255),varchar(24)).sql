CREATE PROCEDURE WhoKnozMe.get_related_rel_proc(IN `$id` VARCHAR(255), IN `$object_type_name` VARCHAR(24))
  BEGIN
DECLARE $object_type_id VARCHAR(36);
SET $object_type_id = (SELECT id FROM object_type_tbl WHERE object_type_name = $object_type_name);
SELECT * FROM business_object_tbl bot 
WHERE object_type_id = $object_type_id AND
 ( bot.id IN (SELECT subject_id FROM relationship_tbl WHERE object_id = $id) OR bot.id IN (SELECT object_id FROM relationship_tbl WHERE subject_id = $id)) OR bot.id = $id;
END;
