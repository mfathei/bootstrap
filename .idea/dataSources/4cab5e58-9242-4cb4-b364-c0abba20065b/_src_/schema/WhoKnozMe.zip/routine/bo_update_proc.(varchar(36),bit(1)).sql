CREATE PROCEDURE WhoKnozMe.bo_update_proc(IN `$user_id` VARCHAR(36), IN `$IsShareholder` BIT)
  BEGIN
DECLARE $person_id VARCHAR(36);
DECLARE $contact_id VARCHAR(36);
DECLARE $SAddress_id VARCHAR(36);
DECLARE $BAddress_id VARCHAR(36);
DECLARE $demographics_id VARCHAR(36);
DECLARE $relationship_id VARCHAR(36);
DECLARE $identity_id VARCHAR(36);
DECLARE $p_relationship_id VARCHAR(36);
DECLARE $file_id VARCHAR(36);
/*DECLARE $Urelationship_id VARCHAR(36);
DECLARE $Usubject_id VARCHAR(36);
DECLARE $object_id VARCHAR(36);
DECLARE $object_type_name VARCHAR(24);
DECLARE $subject_id VARCHAR(36);*/
IF $IsShareholder IS NULL THEN
SET $IsShareholder = 0;
END IF ;
	SET $person_id 			= (SELECT person_id FROM user_tbl WHERE id = $user_id);
	SET $contact_id 		= (SELECT contact_id FROM person_tbl WHERE id = $person_id);
	SET $SAddress_id 		= (SELECT shipto_address_id FROM contact_tbl WHERE id = $contact_id);
	SET $BAddress_id 		= (SELECT billto_address_id FROM contact_tbl WHERE id = $contact_id);
	SET $demographics_id 	= (SELECT id FROM demographics_tbl WHERE person_id = $person_id);
	SET $relationship_id 	= (SELECT id FROM relationship_tbl WHERE object_id = $person_id AND subject_id IN (SELECT id FROM 		business_object_tbl WHERE object_type_id IN (SELECT id FROM object_type_tbl WHERE object_type_name LIKE 'company')) AND 		rel_type_id = 'fc95ea6a-be30-11e3-9a59-1c6f65f2b147');
	SET $identity_id 		= (SELECT id FROM identity_tbl WHERE person_id = $person_id);
	SET $p_relationship_id 	= (SELECT id FROM relationship_tbl WHERE subject_id = '5cf5b910-68c2-11e4-913c-52540002e01a' AND object_id = $person_id);
	SET $file_id 			= (SELECT id FROM business_object_tbl WHERE participant_id = $person_id AND object_type_id = '3a996428-d5e1-11e3-a67e-1c6f65f2b147');
	-- set $Urelationship_id   = (select relationship_id from user_tbl where person_id = $person_id);
	/*set $subject_id		    = (select subject_id from relationship_tbl where id = $Urelationship_id);
	set $Usubject_id 		= (select id from user_tbl where person_id = subject_id);
	set $object_id		    = (select object_id  from relationship_tbl where id = $Urelationship_id);
	set $object_type_name   = (select object_type_name from object_type_tbl where id = (select object_type_id from 					business_object_tbl where id = $subject_id));*/
IF $IsShareholder = 0 THEN
		UPDATE business_object_tbl SET 
		owner_id = $user_id,
		updator_id = $user_id,
		creator_id = $user_id
		WHERE id IN ($person_id, $contact_id, $SAddress_id, $BAddress_id, $demographics_id, $relationship_id, $identity_id, $p_relationship_id, $file_id) AND owner_id <> 		 $user_id AND updator_id <> $user_id AND creator_id <> $user_id ;
ELSE 
		 -- if $person_id = $subject_id then
			UPDATE business_object_tbl SET 
			owner_id = $user_id
			--  updator_id = $Usubject_id
			WHERE id IN ($person_id, $contact_id, $SAddress_id, $BAddress_id, $demographics_id, $relationship_id, $identity_id, $p_relationship_id, $file_id) AND owner_id <> 					   $user_id;
		/*else
			update business_object_tbl set 
			owner_id = $Usubject_id
			-- updator_id = $Usubject_id
			where id in ($person_id, $contact_id, $SAddress_id, $BAddress_id, $demographics_id, $relationship_id) and owner_id <> 					$user_id and updator_id <> $user_id and creator_id <> $user_id ;
		end if;*/
		
	/*if $object_type_name = 'Company'
		then 
		set $contact_id  	= (select contact_id from company_tbl where id = $object_id);
		set $SAddress_id 	= (select shipto_address_id from contact_tbl where id = $contact_id);
		set $BAddress_id 	= (select billto_address_id from contact_tbl where id = $contact_id);
		update business_object_tbl set 
		owner_id = $Usubject_id,
		updator_id = $Usubject_id
		where id in ($contact_id, $SAddress_id, $BAddress_id, $object_id) 
		and owner_id <> $user_id and updator_id <> $user_id and creator_id <> $user_id ;
	end if;*/
	
END IF;
SELECT $user_id;
END;
