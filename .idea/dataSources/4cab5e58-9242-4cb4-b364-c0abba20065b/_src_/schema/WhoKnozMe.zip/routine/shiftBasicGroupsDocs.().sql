CREATE PROCEDURE WhoKnozMe.shiftBasicGroupsDocs()
  BEGIN
    DECLARE finish INT DEFAULT 0;
    DECLARE rid VARCHAR(100); 
    DECLARE sid VARCHAR(100);
    DECLARE std_name_sur CURSOR FOR SELECT vo.RelationShipId,subject_id from object_info_view vo join user_basic_groups bg ON(bg.id = vo.subject_id)
where vo.object_type_name = 'File' 
and (vo.properties is null or vo.properties not in( "<bo><Identifier>mylist_group</Identifier></bo>", "<bo><Identifier>mylist_documents</Identifier></bo>"));
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET finish=1;
    
    DECLARE EXIT HANDLER FOR sqlwarning
    BEGIN
        ROLLBACK;
    END;
    
    DECLARE EXIT HANDLER FOR sqlexception
    BEGIN
        ROLLBACK;
    END;
    
    SET @c = 0;
    
    OPEN std_name_sur;
    
    START TRANSACTION;
    
    std_name_loop: LOOP
        FETCH std_name_sur INTO rid,sid;
        IF finish=1 THEN
            LEAVE std_name_loop;
        END IF;
        -- select uid,pid;
        SET @subjid = (
select b.id from relationship_tbl r join business_object_tbl b
on(r.object_id = b.id)
where r.subject_id = sid
and b.properties = "<bo><Identifier>mylist_documents</Identifier></bo>");
         
        if @subjid is not null then
            update relationship_tbl set subject_id = @subjid where id = rid;
            SET @c = @c + 1;
        end if;
    END LOOP std_name_loop;
    
    COMMIT; 
    
    CLOSE std_name_sur;
    SELECT @c AS counter;
END;
