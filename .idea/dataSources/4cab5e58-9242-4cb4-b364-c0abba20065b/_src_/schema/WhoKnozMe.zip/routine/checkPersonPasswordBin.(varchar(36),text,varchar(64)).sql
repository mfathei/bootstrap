CREATE FUNCTION WhoKnozMe.checkPersonPasswordBin(`$person_id` VARCHAR(36), `$passwrd` TEXT, `$binNumber` VARCHAR(64))
  RETURNS INT(2)
  BEGIN
    set @bin = 
    (SELECT 
        person_id 
    FROM
        user_tbl 
        JOIN account_tbl 
            ON account_tbl.cust_vend_id = user_tbl.person_id 
            where user_tbl.person_id = $person_id 
            and user_tbl.password = $passwrd
            and account_tbl.vend_access_code = $binNumber 
    limit 1) ;
    
    IF @bin IS NULL 
    THEN 
        RETURN 0 ;
    END IF ;
    
    return 1 ;
END;
