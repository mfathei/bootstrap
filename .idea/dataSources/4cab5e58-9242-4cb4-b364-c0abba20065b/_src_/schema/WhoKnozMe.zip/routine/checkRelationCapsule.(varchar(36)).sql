CREATE FUNCTION WhoKnozMe.checkRelationCapsule(`$relationship_id` VARCHAR(36))
  RETURNS INT
  BEGIN
SET @count = 0;
 SELECT COUNT(*) INTO @count FROM relationships_bo_view  bw
	JOIN business_object_tbl b ON bw.rel_id= b.id
	WHERE subject_id = $relationship_id
	AND b.object_type_id= (SELECT id FROM object_type_tbl WHERE object_type_name = 'Capsule');
   -- and b.Hidden = 0;
RETURN @count;
END;
