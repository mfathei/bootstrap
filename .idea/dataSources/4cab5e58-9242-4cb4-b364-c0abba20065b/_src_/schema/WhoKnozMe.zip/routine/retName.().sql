CREATE FUNCTION WhoKnozMe.retName()
  RETURNS VARCHAR(255)
  BEGIN
	return "test";
    END;
