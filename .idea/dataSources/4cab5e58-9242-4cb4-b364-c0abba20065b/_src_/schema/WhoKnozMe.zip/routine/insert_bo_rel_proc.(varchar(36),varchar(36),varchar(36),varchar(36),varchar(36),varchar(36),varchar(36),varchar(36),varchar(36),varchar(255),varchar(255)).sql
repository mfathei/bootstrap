CREATE PROCEDURE WhoKnozMe.insert_bo_rel_proc(IN `$s_id`           VARCHAR(36), IN `$o_id` VARCHAR(36),
                                              IN `$rel_roles_id`   VARCHAR(36), IN `$user_id` VARCHAR(36),
                                              IN `$participant_id` VARCHAR(36), IN `$customGroupID` VARCHAR(36),
                                              IN `$effective_date` VARCHAR(36), IN `$end_date` VARCHAR(36),
                                              IN `$description`    VARCHAR(36), IN `$s_identifier` VARCHAR(255),
                                              IN `$o_identifier`   VARCHAR(255))
  BEGIN
DECLARE $object_type_id, $rel_type_id, $rel_id VARCHAR(36);
DECLARE $s_bo_name, $o_bo_name, $rel_type_name, $s_role, $o_role, $type_abbrev, $bo_name VARCHAR(100);
DECLARE $full_name VARCHAR(255);
/*if $s_id or $o_id are null A.Rahman*/
IF $s_id IS NULL AND $s_identifier IS NOT NULL
THEN 
	SET $s_id = ephr_intake_fun($participant_id, $s_identifier);
END IF;
IF $o_id IS NULL AND $o_identifier IS NOT NULL
THEN 
	SET $o_id = ephr_intake_fun($participant_id, $o_identifier);
END IF;
/* end */
SET $object_type_id = (SELECT id FROM object_type_tbl WHERE abbrev = 'rel');
SET $rel_type_id = (SELECT rel_type_id FROM rel_roles_tbl WHERE id = $rel_roles_id);
	-- start construct bo_name
SET $s_bo_name = (SELECT bo_name FROM business_object_tbl WHERE id = $s_id);
SET $o_bo_name = (SELECT bo_name FROM business_object_tbl WHERE id = $o_id);
SET $s_role = (SELECT subject_role FROM rel_roles_tbl WHERE id = $rel_roles_id);
SET $o_role = (SELECT object_role FROM rel_roles_tbl WHERE id = $rel_roles_id);
SET $type_abbrev = (SELECT rel_type_abbrev FROM rel_type_tbl WHERE id = $rel_type_id);
SET $full_name = CONCAT($s_bo_name,':',$s_role,':',$type_abbrev,':',$o_role,':',$o_bo_name);
SET $bo_name = SUBSTR( $full_name, 1, 100);
SET $rel_type_name = (SELECT rel_type_name FROM rel_type_tbl WHERE id = $rel_type_id);
SET $rel_id = Generate_UUID();
/*set $start_date = ( select start_date from rel_view  where id = $rel_type_id );*/
IF ($effective_date IS NULL) THEN
	SET $effective_date = NOW();
END IF;
INSERT INTO business_object_tbl
(id, object_type_id, bo_name, fullname, `status`, hidden, updated_date, created_date, effective_date, participant_id, owner_id, updator_id, creator_id,owner_group_id,description,expiry_date) 
VALUES 
($rel_id, $object_type_id, $bo_name, $full_name, 'Active', 0, NOW(), NOW(), $effective_date, $participant_id, $user_id, $user_id, $user_id,$customGroupID,$description,$end_date) ;
/* */
INSERT INTO relationship_tbl
(id, subject_id, object_id, start_date,end_date, rel_type_id, rel_type_name, rel_roles_id, subject_role, object_role) 
VALUES 
($rel_id, $s_id, $o_id, $effective_date,$end_date, $rel_type_id, $rel_type_name, $rel_roles_id, $s_role, $o_role);
SELECT $rel_id;
/* */
END;
