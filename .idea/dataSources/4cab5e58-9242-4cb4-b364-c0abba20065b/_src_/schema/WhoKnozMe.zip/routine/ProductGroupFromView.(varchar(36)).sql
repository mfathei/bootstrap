CREATE PROCEDURE WhoKnozMe.ProductGroupFromView(IN `$CompanyId` VARCHAR(36))
  BEGIN
DECLARE $GroupId VARCHAR(36);
DECLARE $TestId VARCHAR(36);
DECLARE $LastOne VARCHAR(36);
DECLARE $ObjectId VARCHAR(36);
DECLARE $SubjectId VARCHAR(36);
DECLARE $GroupName VARCHAR(255);
SET $GroupId = (SELECT subject_id FROM product_group LIMIT 1);
SET $ObjectId = $GroupId;
SET $TestId = $GroupId;
SET $SubjectId = (SELECT subject_id FROM relationship_tbl WHERE object_id = $ObjectId);
WHILE $GroupId IS NOT NULL
DO 
IF $TestId = $LastOne THEN
SET $testid = '0';
ELSE
loop1: WHILE $SubjectId <> $CompanyId
DO
IF $SubjectId IN (SELECT id FROM business_object_tbl WHERE object_type_id = (SELECT id FROM object_type_tbl WHERE object_type_name = 'company'))
THEN
SET $TestId = '0';
LEAVE loop1;
ELSE 
SET $ObjectId = $SubjectId;
SET $SubjectId = (SELECT subject_id FROM relationship_tbl WHERE object_id = $ObjectId);
END IF;
END WHILE;
END IF;
SELECT fullname FROM business_object_tbl WHERE id = $TestId AND $TestId <> '0';
SET $LastOne = $TestId;
SET $GroupId = (SELECT subject_id FROM product_group WHERE subject_id <> $GroupId LIMIT 1 );
END WHILE;
END;
