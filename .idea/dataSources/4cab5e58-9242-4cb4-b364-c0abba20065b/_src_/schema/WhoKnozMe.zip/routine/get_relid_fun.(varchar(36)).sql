CREATE FUNCTION WhoKnozMe.get_relid_fun(`$bo_id` VARCHAR(36))
  RETURNS VARCHAR(100)
  BEGIN
DECLARE $relid VARCHAR(36);
set $relid = (SELECT DISTINCT tbl1.id FROM relationship_tbl tbl1 inner join business_object_tbl tbl2
on tbl1.id = tbl2.participant_id
WHERE (subject_id = $bo_id OR object_id = $bo_id));
RETURN $relid;
END;
