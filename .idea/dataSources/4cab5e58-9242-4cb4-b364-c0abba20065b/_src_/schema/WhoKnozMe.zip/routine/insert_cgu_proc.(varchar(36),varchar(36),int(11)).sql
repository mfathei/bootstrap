CREATE PROCEDURE WhoKnozMe.insert_cgu_proc(IN `$person_id1` VARCHAR(36), IN `$person_id2` VARCHAR(36),
                                           IN `$cg_type`    INT)
  BEGIN
DECLARE $initials1 VARCHAR(45);
DECLARE $initials2 VARCHAR(45);
DECLARE $user_id1 VARCHAR(36);
DECLARE $user_id2 VARCHAR(36);
DECLARE $inverstorsg_id VARCHAR(36);
DECLARE $custom_group_id VARCHAR(36);
SET $initials1 = (SELECT initials FROM person_tbl WHERE id = $person_id1);
SET $initials2 = (SELECT initials FROM person_tbl WHERE id = $person_id2);
SET $user_id1  = (SELECT id FROM user_tbl WHERE person_id = $person_id1);
SET $user_id2  = (SELECT id FROM user_tbl WHERE person_id = $person_id2);
SET $inverstorsg_id = (SELECT id FROM custom_group_tbl WHERE custom_group_name = 'Investors');
/*
$cg_type = 0 ---> investor account,
$cg_type = 1 ---> joint ownership registration
$cg_type = 2 ---> message receivers
$cg_type = 3 ---> add product's custom group
*/
IF $cg_type = 0 
 THEN 
  INSERT INTO cgu_tbl
  (custom_group_id, user_id )
  VALUES 
  ($inverstorsg_id, $user_id1);
        
        
 ELSEIF $cg_type = 1 THEN 
    
    
  INSERT INTO cgu_tbl
   (custom_group_id, user_id)
  VALUES 
   ($inverstorsg_id,$user_id1),($inverstorsg_id,$user_id2);
  -- Joint Ownership part -- 
   -- Create Custome Group
  SET $custom_group_id = Generate_uuid();
  INSERT INTO custom_group_tbl
   (id, custom_group_name)
  VALUES 
   ($custom_group_id, CONCAT('Joint Ownership','(',$initials1,':',$initials2,')'));
   -- Insert created Custom Group with user_id of two persons into cgu_tbl
  INSERT INTO cgu_tbl
   (custom_group_id, user_id)
  VALUES 
   ($custom_group_id,$user_id1),($custom_group_id,$user_id2);
  SELECT $custom_group_id;
        
 ELSEIF $cg_type = 2 THEN 
    
    -- Create Custom Group
  SET $custom_group_id = (SELECT Generate_uuid());
  
  INSERT INTO custom_group_tbl
   (id, custom_group_name)
  VALUES 
   ($custom_group_id,'Message Receivers');
  -- Insert created Custom Group with user_id of message receivers into cgu_tbl
  
  INSERT INTO cgu_tbl 
   (custom_group_id, user_id)
  SELECT 
   $custom_group_id,receiver_id
  FROM sender_receiver_tbl
  WHERE msg_id = $person_id1;
 
      -- update BO of messagee
  UPDATE business_object_tbl SET owner_group_id=$custom_group_id WHERE id= $person_id1;
  -- update BO of files
  UPDATE business_object_tbl SET owner_group_id=$custom_group_id
  WHERE id IN (SELECT file_tbl.id 
  FROM file_tbl
  INNER JOIN relationship_tbl ON relationship_tbl.object_id=file_tbl.id AND relationship_tbl.subject_id=$person_id1);
     
    -- SELECT $custom_group_id;
 ELSEIF $cg_type = 3 THEN 
  SET $custom_group_id = (SELECT owner_group_id FROM business_object_tbl WHERE id = $person_id1);
  IF NOT EXISTS (SELECT user_id FROM cgu_tbl WHERE custom_group_id = $custom_group_id AND user_id = $user_id2)
        THEN
   IF $custom_group_id IS NULL
   THEN
   
    SET $custom_group_id = Generate_uuid();
    SET $initials1 = (SELECT bo_name FROM business_object_tbl WHERE id = $person_id1);
    INSERT INTO custom_group_tbl
     (id, custom_group_name)
    VALUES 
     ($custom_group_id, $initials1);
     
    UPDATE business_object_tbl
    SET owner_group_id = $custom_group_id
    WHERE id = $person_id1;
    
   END IF;
   
   INSERT INTO cgu_tbl
   (custom_group_id, user_id )
   VALUES 
   ($custom_group_id, $user_id2);
            
  END IF;
END IF;
/*
ELSEIF $cg_type = 2 then 
   SET $custom_group_id = (select Generate_uuid());
    INSERT INTO custom_group_tbl
   VALUES 
    ($custom_group_id, 'Contacts Relationships', $person_id1);
   Update business_object_tbl 
   set owner_group_id = $custom_group_id
   where id = $person_id1;
ELSEIF $cg_type = 3 then 
   set $custom_group_id = (select owner_group_id from business_object_tbl where id = $person_id2);
   insert into cgu_tbl 
    (custom_group_id, user_id )
   Value 
    ($custom_group_id, $user_id1);
END IF;
*/
END;
