CREATE TRIGGER WhoKnozMe.email_log_BEFORE_INSERT
BEFORE INSERT ON WhoKnozMe.email_log
FOR EACH ROW
  SET new.email_log_id = UUID();
