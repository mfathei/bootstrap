CREATE TRIGGER WhoKnozMe.value_triplet_BINS
BEFORE INSERT ON WhoKnozMe.value_triplet_tbl
FOR EACH ROW
  BEGIN
	SET NEW.effective_date = CURRENT_TIMESTAMP();
    END;
