CREATE TRIGGER WhoKnozMe.email_template_BEFORE_INSERT
BEFORE INSERT ON WhoKnozMe.email_template
FOR EACH ROW
  BEGIN
   SET new.email_template_id = UUID();
   END;
