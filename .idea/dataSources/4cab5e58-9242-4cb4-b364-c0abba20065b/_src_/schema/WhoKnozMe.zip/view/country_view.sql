CREATE VIEW WhoKnozMe.country_view AS
  SELECT
    `whoknozme`.`country_tbl`.`id`           AS `id`,
    `whoknozme`.`country_tbl`.`country_name` AS `country_name`,
    `whoknozme`.`country_tbl`.`abbrev`       AS `abbrev`,
    `whoknozme`.`country_tbl`.`url`          AS `URL`,
    `whoknozme`.`country_tbl`.`phone_code`   AS `phone_code`,
    `whoknozme`.`country_tbl`.`properties`   AS `properties`,
    `whoknozme`.`currency_type_tbl`.`code`   AS `currency_type`,
    `whoknozme`.`company_tbl`.`abbrev`       AS `CompanyAbbrev`,
    `whoknozme`.`country_tbl`.`fed_tax_rate` AS `FedTaxRate`
  FROM ((`whoknozme`.`country_tbl`
    JOIN `whoknozme`.`currency_type_tbl`
      ON ((`whoknozme`.`country_tbl`.`currency_type_id` = `whoknozme`.`currency_type_tbl`.`id`))) LEFT JOIN
    `whoknozme`.`company_tbl` ON ((`whoknozme`.`company_tbl`.`id` = `whoknozme`.`country_tbl`.`company_id`)));
