CREATE VIEW WhoKnozMe.user_role_view AS
  SELECT
    `whoknozme`.`user_role_tbl`.`id`   AS `id`,
    `whoknozme`.`user_role_tbl`.`role` AS `role`,
    `whoknozme`.`user_tbl`.`username`  AS `username`
  FROM (`whoknozme`.`user_role_tbl`
    JOIN `whoknozme`.`user_tbl` ON ((`whoknozme`.`user_role_tbl`.`user_id` = `whoknozme`.`user_tbl`.`id`)));
