CREATE VIEW WhoKnozMe.city_view AS
  SELECT
    `whoknozme`.`city_tbl`.`id`                    AS `id`,
    `whoknozme`.`city_tbl`.`city_name`             AS `city_name`,
    `whoknozme`.`city_tbl`.`abbrev`                AS `city_abbrev`,
    `whoknozme`.`city_tbl`.`timezone_offset`       AS `timezone_offset`,
    `whoknozme`.`city_tbl`.`dayligtht_saving_time` AS `dayligtht_saving_time`,
    `whoknozme`.`country_tbl`.`country_name`       AS `country_name`,
    `whoknozme`.`country_tbl`.`id`                 AS `country_id`,
    `whoknozme`.`province_tbl`.`prov_name`         AS `prov_name`,
    `whoknozme`.`county_tbl`.`county_name`         AS `county_name`,
    `whoknozme`.`company_tbl`.`abbrev`             AS `abbrev`,
    `whoknozme`.`city_tbl`.`properties`            AS `CityProperties`,
    `whoknozme`.`city_tbl`.`city_tax_rate`         AS `CityTaxRate`
  FROM ((((`whoknozme`.`city_tbl`
    LEFT JOIN `whoknozme`.`province_tbl`
      ON ((`whoknozme`.`city_tbl`.`province_tbl_id` = `whoknozme`.`province_tbl`.`id`))) LEFT JOIN
    `whoknozme`.`country_tbl`
      ON ((`whoknozme`.`province_tbl`.`country_tbl_id` = `whoknozme`.`country_tbl`.`id`))) LEFT JOIN
    `whoknozme`.`county_tbl` ON ((`whoknozme`.`city_tbl`.`county_tbl_id` = `whoknozme`.`county_tbl`.`id`))) LEFT JOIN
    `whoknozme`.`company_tbl` ON ((`whoknozme`.`company_tbl`.`id` = `whoknozme`.`city_tbl`.`company_id`)));
