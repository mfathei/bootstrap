CREATE VIEW WhoKnozMe.actions_view AS
  SELECT
    `whoknozme`.`action_tbl`.`id`                             AS `ActionId`,
    `bo_tbl`.`bo_name`                                        AS `bo_name`,
    `bo_tbl`.`fullname`                                       AS `bo_fullname`,
    `bo_tbl`.`hidden`                                         AS `hidden`,
    `bo_tbl`.`participant_id`                                 AS `bo_participant_id`,
    `bo_tbl`.`owner_group_id`                                 AS `bo_owner_group_id`,
    `bo_tbl`.`properties`                                     AS `bo_properties`,
    `whoknozme`.`action_tbl`.`action_type`                    AS `action_type`,
    `whoknozme`.`action_type_tbl`.`action_noun_type`          AS `action_noun_type`,
    `whoknozme`.`action_tbl`.`participant_subject_id`         AS `participant_subject_id`,
    `whoknozme`.`action_tbl`.`participant_object_id`          AS `participant_object_id`,
    `whoknozme`.`action_tbl`.`participant_authority_id`       AS `participant_authority_id`,
    `whoknozme`.`action_tbl`.`participant_device_id`          AS `participant_device_id`,
    `whoknozme`.`action_tbl`.`utc_time_start`                 AS `utc_time_start`,
    `whoknozme`.`action_tbl`.`utc_time_end`                   AS `utc_time_end`,
    `whoknozme`.`action_tbl`.`utc_time_offest`                AS `utc_time_offest`,
    `whoknozme`.`action_tbl`.`local_time_start`               AS `local_time_start`,
    `whoknozme`.`action_tbl`.`local_time_end`                 AS `local_time_end`,
    `whoknozme`.`action_tbl`.`status_type_id`                 AS `action_status_type_id`,
    `whoknozme`.`action_tbl`.`recurring_frequency`            AS `recurring_frequency`,
    `whoknozme`.`action_tbl`.`recurring_units_id`             AS `recurring_units_id`,
    `whoknozme`.`action_tbl`.`recurring_term`                 AS `recurring_term`,
    `whoknozme`.`action_tbl`.`recurring_term_units_id`        AS `recurring_term_units_id`,
    `whoknozme`.`action_tbl`.`Dependancy_id`                  AS `Dependancy_id`,
    `whoknozme`.`action_tbl`.`project_id`                     AS `project_id`,
    `l_tbl`.`lookup_name`                                     AS `lookup_name`,
    `whoknozme`.`action_tbl`.`action_list_id`                 AS `action_list_id`,
    `whoknozme`.`action_tbl`.`start_time`                     AS `start_time`,
    `whoknozme`.`action_tbl`.`duration`                       AS `duration`,
    `whoknozme`.`action_type_tbl`.`id`                        AS `ActionTypeId`,
    `whoknozme`.`action_type_tbl`.`subject_name`              AS `subject_name`,
    `whoknozme`.`action_type_tbl`.`object_name`               AS `object_name`,
    `whoknozme`.`action_type_tbl`.`action_abbrev`             AS `action_abbrev`,
    `whoknozme`.`action_type_tbl`.`action_verb_type`          AS `action_verb_type`,
    `whoknozme`.`diagnosis_tbl`.`id`                          AS `DiagnosisId`,
    `whoknozme`.`diagnosis_tbl`.`loinc_id`                    AS `loinc_id`,
    `whoknozme`.`diagnosis_tbl`.`name`                        AS `name`,
    `whoknozme`.`diagnosis_tbl`.`fullname`                    AS `fullname`,
    `whoknozme`.`diagnosis_tbl`.`severity_id`                 AS `severity_id`,
    `whoknozme`.`diagnosis_tbl`.`status_id`                   AS `status_id`,
    `whoknozme`.`diagnosis_tbl`.`action_id`                   AS `DiagActionId`,
    `whoknozme`.`diagnosis_tbl`.`diagnosis_type`              AS `diagnosis_type`,
    `whoknozme`.`encounter_tbl`.`id`                          AS `EncounterId`,
    `whoknozme`.`encounter_tbl`.`service_field_type_id`       AS `service_field_type_id`,
    `whoknozme`.`encounter_tbl`.`practitioner_type_id`        AS `practitioner_type_id`,
    `whoknozme`.`encounter_tbl`.`service_type_id`             AS `service_type_id`,
    `whoknozme`.`encounter_tbl`.`project_itemlist_id`         AS `project_itemlist_id`,
    `whoknozme`.`encounter_tbl`.`resulting_action_list_id`    AS `resulting_action_list_id`,
    `whoknozme`.`encounter_tbl`.`location_address_id`         AS `location_address_id`,
    `whoknozme`.`encounter_tbl`.`participant_ugu_id`          AS `participant_ugu_id`,
    `whoknozme`.`encounter_tbl`.`location_point_lat_lon`      AS `location_point_lat_lon`,
    `whoknozme`.`encounter_tbl`.`workflow_id`                 AS `workflow_id`,
    `whoknozme`.`encounter_tbl`.`action_id`                   AS `action_id`,
    `whoknozme`.`encounter_tbl`.`comment`                     AS `comment`,
    `whoknozme`.`encounter_tbl`.`value_id`                    AS `value_id`,
    `whoknozme`.`encounter_tbl`.`encounter_start_plan`        AS `encounter_start_plan`,
    `whoknozme`.`encounter_tbl`.`encounter_start_actual`      AS `encounter_start_actual`,
    `whoknozme`.`encounter_tbl`.`encounter_end_plan`          AS `encounter_end_plan`,
    `whoknozme`.`encounter_tbl`.`encounter_end_actual`        AS `encounter_end_actual`,
    `pe1_t`.`id`                                              AS `SuPersonId`,
    `pe1_t`.`first_name`                                      AS `SuFirstName`,
    `pe1_t`.`middle_names`                                    AS `SuMiddleName`,
    `pe1_t`.`last_name`                                       AS `SuLastName`,
    `pe1_t`.`initials`                                        AS `SuInitials`,
    `pe1_t`.`goes_by_name`                                    AS `SuGoesByName`,
    `pe2_t`.`id`                                              AS `ObPersonId`,
    `pe2_t`.`first_name`                                      AS `ObFirstName`,
    `pe2_t`.`middle_names`                                    AS `ObMiddleName`,
    `pe2_t`.`last_name`                                       AS `PbLastName`,
    `pe2_t`.`initials`                                        AS `ObInitials`,
    `pe2_t`.`goes_by_name`                                    AS `ObGoesByName`,
    `whoknozme`.`procedure_tbl`.`id`                          AS `ProcedureId`,
    `whoknozme`.`procedure_tbl`.`procedure_type`              AS `procedure_type`,
    `whoknozme`.`procedure_tbl`.`action_id`                   AS `ProcActionId`,
    `whoknozme`.`procedure_tbl`.`status_type_id`              AS `procedure_status_type_id`,
    `whoknozme`.`observation_tbl`.`id`                        AS `ObservationId`,
    `whoknozme`.`observation_tbl`.`observation_properties_id` AS `observation_properties_id`,
    `whoknozme`.`observation_tbl`.`action_id`                 AS `ObsActionId`,
    `whoknozme`.`observation_tbl`.`status_type_id`            AS `obser_status_type_id`,
    `whoknozme`.`observation_tbl`.`value_id`                  AS `obser_value_id`,
    `whoknozme`.`observation_tbl`.`workflow_id`               AS `obser_workflow_id`,
    `whoknozme`.`observation_tbl`.`list_id`                   AS `list_id`,
    `whoknozme`.`observation_tbl`.`test_type_id`              AS `test_type_id`,
    `OLT`.`MedicalObservation`                                AS `test_type_name`,
    `whoknozme`.`supply_tbl`.`id`                             AS `SupplyId`,
    `whoknozme`.`supply_tbl`.`supply_type`                    AS `supply_type`,
    `whoknozme`.`supply_tbl`.`action_id`                      AS `SuppActionId`,
    `whoknozme`.`supply_tbl`.`status_type_id`                 AS `Supply_status_type_id`,
    `whoknozme`.`transaction_tbl`.`id`                        AS `TransactionId`,
    `whoknozme`.`transaction_tbl`.`transaction_type`          AS `transaction_type`,
    `whoknozme`.`transaction_tbl`.`transaction_date`          AS `transaction_date`,
    `whoknozme`.`transaction_tbl`.`transaction_authority_id`  AS `transaction_authority_id`,
    `whoknozme`.`transaction_tbl`.`comment`                   AS `trans_comment`,
    `whoknozme`.`transaction_tbl`.`properties`                AS `properties`,
    `whoknozme`.`transaction_tbl`.`action_id`                 AS `Trans_ActionId`,
    `whoknozme`.`transaction_tbl`.`status_type_id`            AS `trans_status_type_id`,
    `whoknozme`.`relationship_tbl`.`subject_id`               AS `subject_id`,
    `bo_tbl1`.`owner_group_id`                                AS `bo1_owner_group_id`,
    `bo_tbl1`.`participant_id`                                AS `bo1_participant_id`,
    `bo_tbl1`.`bo_name`                                       AS `bo_name21`
  FROM ((((((((((((((`whoknozme`.`action_tbl`
    JOIN `whoknozme`.`action_type_tbl`
      ON ((`whoknozme`.`action_tbl`.`action_type` = `whoknozme`.`action_type_tbl`.`id`))) JOIN
    `whoknozme`.`business_object_tbl` `bo_tbl` ON ((`whoknozme`.`action_tbl`.`id` = `bo_tbl`.`id`))) LEFT JOIN
    `whoknozme`.`lookup_tbl` `l_tbl` ON ((`whoknozme`.`action_tbl`.`status_type_id` = `l_tbl`.`id`))) LEFT JOIN
    `whoknozme`.`person_tbl` `pe1_t` ON ((`whoknozme`.`action_tbl`.`participant_subject_id` = `pe1_t`.`id`))) LEFT JOIN
    `whoknozme`.`person_tbl` `pe2_t` ON ((`whoknozme`.`action_tbl`.`participant_object_id` = `pe2_t`.`id`))) LEFT JOIN
    `whoknozme`.`encounter_tbl`
      ON ((`whoknozme`.`action_tbl`.`id` = `whoknozme`.`encounter_tbl`.`action_id`))) LEFT JOIN
    `whoknozme`.`procedure_tbl`
      ON ((`whoknozme`.`action_tbl`.`id` = `whoknozme`.`procedure_tbl`.`action_id`))) LEFT JOIN `whoknozme`.`supply_tbl`
      ON ((`whoknozme`.`action_tbl`.`id` = `whoknozme`.`supply_tbl`.`action_id`))) LEFT JOIN `whoknozme`.`diagnosis_tbl`
      ON ((`whoknozme`.`action_tbl`.`id` = `whoknozme`.`diagnosis_tbl`.`action_id`))) LEFT JOIN
    `whoknozme`.`observation_tbl`
      ON ((`whoknozme`.`action_tbl`.`id` = `whoknozme`.`observation_tbl`.`action_id`))) LEFT JOIN
    `whoknozme`.`transaction_tbl`
      ON ((`whoknozme`.`action_tbl`.`id` = `whoknozme`.`transaction_tbl`.`action_id`))) LEFT JOIN
    `whoknozme`.`relationship_tbl`
      ON ((`whoknozme`.`action_tbl`.`id` = `whoknozme`.`relationship_tbl`.`object_id`))) LEFT JOIN
    `whoknozme`.`business_object_tbl` `bo_tbl1`
      ON ((`whoknozme`.`relationship_tbl`.`subject_id` = `bo_tbl1`.`id`))) LEFT JOIN
    `whoknozme`.`observation_lookup_tbl` `OLT` ON ((`whoknozme`.`observation_tbl`.`test_type_id` = `OLT`.`id`)));
