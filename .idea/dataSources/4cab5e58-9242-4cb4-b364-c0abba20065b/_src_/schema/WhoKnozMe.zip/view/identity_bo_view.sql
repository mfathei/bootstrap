CREATE VIEW WhoKnozMe.identity_bo_view AS
  SELECT
    `tbl1`.`id`                AS `id`,
    `tbl1`.`identity_type_id`  AS `identity_type_id`,
    `tbl2`.`lookup_name`       AS `identity_type_name`,
    `tbl1`.`verified_date`     AS `verified_date`,
    `tbl1`.`identity_number`   AS `identity_number`,
    `tbl1`.`properties`        AS `identity_properties`,
    `tbl1`.`person_id`         AS `person_id`,
    `tbl3`.`bo_name`           AS `person_bo_name`,
    `tbl1`.`relationship_id`   AS `relationship_id`,
    `tbl4`.`bo_name`           AS `relationship_bo_name`,
    `tbl1`.`picture_id`        AS `picture_id`,
    `tbl5`.`file_path`         AS `picture_path`,
    `tbl1`.`issuer_id`         AS `issuer_id`,
    `tbl6`.`bo_name`           AS `issuer_bo_name`,
    `tbl`.`object_type_id`     AS `object_type_id`,
    `tbl`.`list_index`         AS `list_index`,
    `tbl`.`bo_name`            AS `bo_name`,
    `tbl`.`fullname`           AS `fullname`,
    `tbl`.`description`        AS `description`,
    `tbl`.`properties`         AS `properties`,
    `tbl`.`next_bo_id`         AS `next_bo_id`,
    `tbl`.`value_id`           AS `value_id`,
    `tbl`.`template_id`        AS `template_id`,
    `tbl`.`business_rule_id`   AS `business_rule_id`,
    `tbl`.`status`             AS `status`,
    `tbl`.`hidden`             AS `hidden`,
    `tbl`.`mobile_sync`        AS `mobile_sync`,
    `tbl`.`last_accessed_date` AS `last_accessed_date`,
    `tbl`.`update_type`        AS `update_type`,
    `tbl`.`updated_date`       AS `updated_date`,
    `tbl`.`created_date`       AS `created_date`,
    `tbl`.`effective_date`     AS `effective_date`,
    `tbl`.`expiry_date`        AS `expiry_date`,
    `tbl`.`participant_id`     AS `participant_id`,
    `tbl`.`owner_id`           AS `owner_id`,
    `tbl`.`owner_group_id`     AS `owner_group_id`,
    `tbl`.`last_accessor_id`   AS `last_accessor_id`,
    `tbl`.`updator_id`         AS `updator_id`,
    `tbl`.`creator_id`         AS `creator_id`,
    `tbl`.`external_id`        AS `external_id`,
    `tbl`.`external_key_id`    AS `external_key_id`,
    `tbl`.`external_source_id` AS `external_source_id`,
    `tbl`.`file_id`            AS `file_id`,
    `tbl`.`image_id`           AS `image_id`
  FROM ((((((`whoknozme`.`identity_tbl` `tbl1`
    JOIN `whoknozme`.`business_object_tbl` `tbl` ON ((`tbl1`.`id` = `tbl`.`id`))) LEFT JOIN
    `whoknozme`.`lookup_tbl` `tbl2` ON ((`tbl1`.`identity_type_id` = `tbl2`.`id`))) LEFT JOIN
    `whoknozme`.`business_object_tbl` `tbl3` ON ((`tbl1`.`person_id` = `tbl3`.`id`))) LEFT JOIN
    `whoknozme`.`business_object_tbl` `tbl4` ON ((`tbl1`.`relationship_id` = `tbl4`.`id`))) LEFT JOIN
    `whoknozme`.`file_tbl` `tbl5` ON ((`tbl1`.`picture_id` = `tbl5`.`id`))) JOIN
    `whoknozme`.`business_object_tbl` `tbl6` ON ((`tbl1`.`issuer_id` = `tbl6`.`id`)));
