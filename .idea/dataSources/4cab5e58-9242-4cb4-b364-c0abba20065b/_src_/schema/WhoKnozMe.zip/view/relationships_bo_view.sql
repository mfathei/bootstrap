CREATE VIEW WhoKnozMe.relationships_bo_view AS
  SELECT
    `bot1`.`id`                                                                         AS `bo_id`,
    `bot2`.`bo_name`                                                                    AS `bo_name`,
    `bot2`.`fullname`                                                                   AS `fullname`,
    `bot2`.`participant_id`                                                             AS `rel_participant`,
    `bot1`.`description`                                                                AS `description`,
    `bot1`.`effective_date`                                                             AS `effective_date`,
    `bot2`.`description`                                                                AS `relation_description`,
    `whoknozme`.`relationship_tbl`.`id`                                                 AS `rel_id`,
    `bot2`.`hidden`                                                                     AS `hidden`,
    `whoknozme`.`relationship_tbl`.`start_date`                                         AS `start_date`,
    `whoknozme`.`relationship_tbl`.`end_date`                                           AS `end_date`,
    `whoknozme`.`relationship_tbl`.`rel_type_id`                                        AS `rel_type_id`,
    `whoknozme`.`relationship_tbl`.`rel_roles_id`                                       AS `rel_roles_id`,
    `whoknozme`.`rel_type_tbl`.`rel_type_name`                                          AS `rel_type_name`,
    `whoknozme`.`relationship_tbl`.`subject_id`                                         AS `subject_id`,
    `whoknozme`.`relationship_tbl`.`object_id`                                          AS `object_id`,
    `ot`.`object_type_name`                                                             AS `object_type_name`,
    `ot2`.`object_type_name`                                                            AS `subject_type_name`,
    `bot1`.`bo_name`                                                                    AS `object_bo_name`,
    `bot1`.`fullname`                                                                   AS `object_full_name`,
    `bot1`.`file_id`                                                                    AS `object_file_id`,
    `bot1`.`image_id`                                                                   AS `object_image_id`,
    `bot1`.`hidden`                                                                     AS `object_hidden`,
    `bot1`.`status`                                                                     AS `object_status`,
    `bot1`.`mobile_sync`                                                                AS `object_mobile_sync`,
    `bot1`.`expiry_date`                                                                AS `object_expiry_date`,
    `bot1`.`list_index`                                                                 AS `object_list_index`,
    `sot1`.`bo_name`                                                                    AS `subject_bo_name`,
    `whoknozme`.`relationship_tbl`.`subject_role`                                       AS `subject_role`,
    `whoknozme`.`relationship_tbl`.`object_role`                                        AS `object_role`,
    `bot2`.`object_type_id`                                                             AS `object_type_id`,
    `ft`.`file_path`                                                                    AS `path`,
    `RELATIONSHIPS_BO_FUN`(`bot1`.`id`, `whoknozme`.`relationship_tbl`.`subject_id`, 0) AS `groups`
  FROM (((((((`whoknozme`.`relationship_tbl`
    JOIN `whoknozme`.`business_object_tbl` `bot1` ON ((`bot1`.`id` = `whoknozme`.`relationship_tbl`.`object_id`))) JOIN
    `whoknozme`.`business_object_tbl` `sot1` ON ((`sot1`.`id` = `whoknozme`.`relationship_tbl`.`subject_id`))) JOIN
    `whoknozme`.`rel_type_tbl`
      ON ((`whoknozme`.`relationship_tbl`.`rel_type_id` = `whoknozme`.`rel_type_tbl`.`id`))) JOIN
    `whoknozme`.`business_object_tbl` `bot2` ON ((`bot2`.`id` = `whoknozme`.`relationship_tbl`.`id`))) JOIN
    `whoknozme`.`object_type_tbl` `ot` ON ((`bot1`.`object_type_id` = `ot`.`id`))) JOIN
    `whoknozme`.`object_type_tbl` `ot2` ON ((`sot1`.`object_type_id` = `ot2`.`id`))) LEFT JOIN
    `whoknozme`.`file_tbl` `ft` ON ((`ft`.`id` = `whoknozme`.`relationship_tbl`.`object_id`)))
  WHERE (`bot1`.`hidden` = '0');
