CREATE VIEW WhoKnozMe.product_group AS
  SELECT
    `whoknozme`.`relationship_tbl`.`id`           AS `id`,
    `whoknozme`.`relationship_tbl`.`subject_id`   AS `subject_id`,
    `whoknozme`.`relationship_tbl`.`object_id`    AS `object_id`,
    `whoknozme`.`relationship_tbl`.`start_date`   AS `start_date`,
    `whoknozme`.`relationship_tbl`.`end_date`     AS `end_date`,
    `whoknozme`.`relationship_tbl`.`list_index`   AS `list_index`,
    `whoknozme`.`relationship_tbl`.`properties`   AS `properties`,
    `whoknozme`.`relationship_tbl`.`rel_type_id`  AS `rel_type_id`,
    `whoknozme`.`relationship_tbl`.`contact_id`   AS `contact_id`,
    `whoknozme`.`relationship_tbl`.`subject_role` AS `subject_role`,
    `whoknozme`.`relationship_tbl`.`object_role`  AS `object_role`,
    `whoknozme`.`relationship_tbl`.`act`          AS `act`
  FROM `whoknozme`.`relationship_tbl`
  WHERE `whoknozme`.`relationship_tbl`.`object_id` IN (SELECT `whoknozme`.`business_object_tbl`.`id`
                                                       FROM `whoknozme`.`business_object_tbl`
                                                       WHERE `whoknozme`.`business_object_tbl`.`object_type_id` IN
                                                             (SELECT `whoknozme`.`object_type_tbl`.`id`
                                                              FROM `whoknozme`.`object_type_tbl`
                                                              WHERE (`whoknozme`.`object_type_tbl`.`object_type_name` =
                                                                     'product')));
