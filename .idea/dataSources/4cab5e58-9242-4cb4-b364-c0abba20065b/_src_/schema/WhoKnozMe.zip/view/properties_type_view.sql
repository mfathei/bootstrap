CREATE VIEW WhoKnozMe.properties_type_view AS
  SELECT
    `whoknozme`.`properties_type_tbl`.`id`           AS `id`,
    `whoknozme`.`properties_type_tbl`.`name`         AS `name`,
    `whoknozme`.`properties_type_tbl`.`template`     AS `template`,
    `whoknozme`.`object_type_tbl`.`object_type_name` AS `object_type_name`
  FROM (`whoknozme`.`properties_type_tbl`
    JOIN `whoknozme`.`object_type_tbl`
      ON ((`whoknozme`.`properties_type_tbl`.`object_type_id` = `whoknozme`.`object_type_tbl`.`id`)));
