CREATE VIEW WhoKnozMe.template_view AS
  SELECT
    `whoknozme`.`template_tbl`.`id`                  AS `id`,
    `whoknozme`.`template_tbl`.`script`              AS `script`,
    `whoknozme`.`object_type_tbl`.`object_type_name` AS `object_type_name`,
    `whoknozme`.`template_tbl`.`template_name`       AS `template_name`,
    `whoknozme`.`template_tbl`.`properties`          AS `properties`
  FROM (`whoknozme`.`template_tbl`
    JOIN `whoknozme`.`object_type_tbl`
      ON ((`whoknozme`.`template_tbl`.`object_type_id` = `whoknozme`.`object_type_tbl`.`id`)));
