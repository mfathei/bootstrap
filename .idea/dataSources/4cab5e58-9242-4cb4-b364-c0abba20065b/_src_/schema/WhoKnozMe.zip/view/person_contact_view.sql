CREATE VIEW WhoKnozMe.person_contact_view AS
  SELECT
    `pt`.`id`                 AS `person_id`,
    `relt`.`rel_type_name`    AS `rel_type_name`,
    `relt`.`id`               AS `rel_type_id`,
    `bo`.`bo_name`            AS `bo_name`,
    `bo`.`object_type_id`     AS `object_type_id`,
    `boRel`.`list_index`      AS `list_index`,
    `pt`.`first_name`         AS `first_name`,
    `pt`.`middle_names`       AS `middle_names`,
    `pt`.`last_name`          AS `last_name`,
    `pt`.`initials`           AS `initials`,
    `pt`.`goes_by_name`       AS `goes_by_name`,
    `pt`.`title_id`           AS `title_id`,
    `pt`.`prof_status`        AS `prof_status`,
    `pt`.`properties`         AS `person_properties`,
    `ct`.`id`                 AS `contact_id`,
    `ct`.`country_id`         AS `country_id`,
    `ct`.`area_code1`         AS `area_code1`,
    `lookup1`.`lookup_name`   AS `phone_type_name1`,
    `ct`.`phone_number1`      AS `phone_number1`,
    `ct`.`extension1`         AS `extension1`,
    `ct`.`area_code2`         AS `area_code2`,
    `lookup2`.`lookup_name`   AS `phone_type_name2`,
    `ct`.`phone_number2`      AS `phone_number2`,
    `ct`.`extension2`         AS `extension2`,
    `ct`.`area_code3`         AS `area_code3`,
    `lookup3`.`lookup_name`   AS `phone_type_name3`,
    `ct`.`phone_number3`      AS `phone_number3`,
    `ct`.`extension3`         AS `extension3`,
    `ct`.`phone`              AS `phone`,
    `ct`.`phone_ext`          AS `phone_ext`,
    `ct`.`mobile`             AS `mobile`,
    `ct`.`fax`                AS `fax`,
    `ct`.`email`              AS `email`,
    `ct`.`verified_date`      AS `verified_date`,
    `ct`.`verified_source_id` AS `verified_source_id`,
    `ct`.`website`            AS `website`,
    `ct`.`properties`         AS `contact_properties`,
    `ct`.`shipto_address_id`  AS `shipto_address_id`,
    `ct`.`billto_address_id`  AS `billto_address_id`,
    `ct`.`billto_space_id`    AS `billto_space_id`,
    `ct`.`shipto_space_id`    AS `shipto_space_id`,
    `ct`.`sms`                AS `sms`,
    `rel`.`id`                AS `relationship_id`,
    `rel`.`object_role`       AS `object_role`,
    `rel`.`object_id`         AS `object_id`,
    `rel`.`subject_role`      AS `subject_role`,
    `rel`.`subject_id`        AS `subject_id`,
    `cntry`.`phone_code`      AS `phone_code`,
    `boAdd`.`bo_name`         AS `BoOfBillAddress`,
    `rel`.`end_date`          AS `end_date`
  FROM ((((((((((`whoknozme`.`person_tbl` `pt`
    JOIN `whoknozme`.`contact_tbl` `ct` ON ((`pt`.`contact_id` = `ct`.`id`))) JOIN
    `whoknozme`.`business_object_tbl` `bo` ON ((`pt`.`id` = `bo`.`id`))) LEFT JOIN
    `whoknozme`.`business_object_tbl` `boAdd` ON ((`ct`.`billto_address_id` = `boAdd`.`id`))) LEFT JOIN
    `whoknozme`.`country_tbl` `cntry` ON ((`cntry`.`id` = `ct`.`country_id`))) LEFT JOIN
    `whoknozme`.`relationship_tbl` `rel` ON ((`pt`.`id` = `rel`.`object_id`))) LEFT JOIN
    `whoknozme`.`business_object_tbl` `boRel` ON ((`boRel`.`id` = `rel`.`id`))) LEFT JOIN
    `whoknozme`.`rel_type_tbl` `relt` ON ((`rel`.`rel_type_id` = `relt`.`id`))) LEFT JOIN
    `whoknozme`.`lookup_tbl` `lookup1` ON ((`lookup1`.`id` = `ct`.`phone_type_id1`))) LEFT JOIN
    `whoknozme`.`lookup_tbl` `lookup2` ON ((`lookup2`.`id` = `ct`.`phone_type_id2`))) LEFT JOIN
    `whoknozme`.`lookup_tbl` `lookup3` ON ((`lookup3`.`id` = `ct`.`phone_type_id3`)));
