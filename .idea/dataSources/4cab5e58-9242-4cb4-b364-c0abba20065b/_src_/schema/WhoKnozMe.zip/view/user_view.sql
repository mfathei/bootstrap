CREATE VIEW WhoKnozMe.user_view AS
  SELECT DISTINCT
    `u_t`.`id`                                             AS `ID`,
    `u_t`.`password`                                       AS `Password`,
    `l_u`.`lookup_name`                                    AS `Title`,
    `p_t`.`id`                                             AS `PersonID`,
    `p_t`.`first_name`                                     AS `FirstName`,
    `p_t`.`middle_names`                                   AS `MiddleName`,
    `p_t`.`last_name`                                      AS `LastName`,
    `p_t`.`goes_by_name`                                   AS `GoesBy`,
    `p_t`.`initials`                                       AS `Initials`,
    `co_t`.`mobile`                                        AS `Mobile`,
    `co_t`.`phone`                                         AS `Phone`,
    `co_t`.`work_number`                                   AS `work_number`,
    `co_t`.`email`                                         AS `Email`,
    `sad_t`.`address1`                                     AS `ShipToLine1`,
    `bad_t`.`address1`                                     AS `BillToLine1`,
    `sad_t`.`address2`                                     AS `ShipToLine2`,
    `bad_t`.`address2`                                     AS `BillToLine2`,
    `u_t`.`username`                                       AS `UserName`,
    `sc_t`.`id`                                            AS `ShipToCityID`,
    `sc_t`.`city_name`                                     AS `ShipToCity`,
    `sc_t`.`abbrev`                                        AS `ShipToCityAbbrev`,
    `bc_t`.`id`                                            AS `BillToCityID`,
    `bc_t`.`city_name`                                     AS `BillToCity`,
    `bc_t`.`abbrev`                                        AS `BillToCityAbbrev`,
    `pbo`.`bo_name`                                        AS `BoName`,
    `cbo`.`bo_name`                                        AS `ContactBoName`,
    `cbo`.`fullname`                                       AS `ContactFullName`,
    `sbo`.`bo_name`                                        AS `ShipToBoName`,
    `sbo`.`fullname`                                       AS `ShipToFullName`,
    `bbo`.`bo_name`                                        AS `BillToBoName`,
    `bbo`.`fullname`                                       AS `BillToFullName`,
    `pbo`.`status`                                         AS `PboStatus`,
    `cbo`.`status`                                         AS `CboStatus`,
    `sbo`.`status`                                         AS `SboStatus`,
    `bbo`.`status`                                         AS `BboStatus`,
    `co_t`.`phone_ext`                                     AS `PhoneExt`,
    `co_t`.`fax`                                           AS `Fax`,
    `sad_t`.`postal_code`                                  AS `SadPostalCode`,
    `bad_t`.`postal_code`                                  AS `BadPostalCode`,
    `sad_t`.`lattitude`                                    AS `Sadlattitude`,
    `bad_t`.`lattitude`                                    AS `Badlattitude`,
    `sad_t`.`longitude`                                    AS `Sadlongitude`,
    `bad_t`.`longitude`                                    AS `Badlongitude`,
    `sp_t`.`id`                                            AS `SpProvID`,
    `sp_t`.`prov_name`                                     AS `SpProvName`,
    `bp_t`.`id`                                            AS `BpProvID`,
    `bp_t`.`prov_name`                                     AS `BpProvName`,
    `sp_t`.`prov_tax_rate`                                 AS `SadTaxRate`,
    `bp_t`.`prov_tax_rate`                                 AS `BadTaxRate`,
    `sp_t`.`tax_type`                                      AS `SadTaxType`,
    `bp_t`.`tax_type`                                      AS `BadTaxType`,
    `scy_t`.`id`                                           AS `ScyCountyID`,
    `scy_t`.`county_name`                                  AS `ScyCountyName`,
    `bcy_t`.`id`                                           AS `BcyCountyID`,
    `bcy_t`.`county_name`                                  AS `BcyCountyName`,
    `sco_t`.`id`                                           AS `ScoCountryID`,
    `sco_t`.`country_name`                                 AS `ScoCountryName`,
    `bco_t`.`id`                                           AS `BcoCountryID`,
    `bco_t`.`country_name`                                 AS `BcoCountryName`,
    `USER_FUNCTION`(`whoknozme`.`ugu_tbl`.`user_group_id`) AS `UserGroup`,
    `cbo`.`id`                                             AS `ContactId`,
    `sbo`.`id`                                             AS `ShipToId`,
    `bbo`.`id`                                             AS `BillToId`
  FROM ((((((((((((((((((`whoknozme`.`user_tbl` `u_t`
    JOIN `whoknozme`.`person_tbl` `p_t` ON ((`p_t`.`id` = `u_t`.`person_id`))) LEFT JOIN `whoknozme`.`lookup_tbl` `l_u`
      ON ((`p_t`.`title_id` = `l_u`.`id`))) JOIN `whoknozme`.`contact_tbl` `co_t`
      ON ((`p_t`.`contact_id` = `co_t`.`id`))) JOIN `whoknozme`.`address_tbl` `sad_t`
      ON ((`co_t`.`shipto_address_id` = `sad_t`.`id`))) JOIN `whoknozme`.`address_tbl` `bad_t`
      ON ((`co_t`.`billto_address_id` = `bad_t`.`id`))) JOIN `whoknozme`.`city_tbl` `sc_t`
      ON ((`sad_t`.`city_id` = `sc_t`.`id`))) JOIN `whoknozme`.`city_tbl` `bc_t`
      ON ((`bad_t`.`city_id` = `bc_t`.`id`))) JOIN `whoknozme`.`ugu_tbl`
      ON ((`whoknozme`.`ugu_tbl`.`user_id` = `u_t`.`id`))) LEFT JOIN `whoknozme`.`province_tbl` `sp_t`
      ON ((`sc_t`.`province_tbl_id` = `sp_t`.`id`))) LEFT JOIN `whoknozme`.`province_tbl` `bp_t`
      ON ((`bc_t`.`province_tbl_id` = `bp_t`.`id`))) JOIN `whoknozme`.`country_tbl` `sco_t`
      ON ((`sp_t`.`country_tbl_id` = `sco_t`.`id`))) JOIN `whoknozme`.`country_tbl` `bco_t`
      ON ((`bp_t`.`country_tbl_id` = `bco_t`.`id`))) LEFT JOIN `whoknozme`.`county_tbl` `scy_t`
      ON ((`sc_t`.`county_tbl_id` = `scy_t`.`id`))) LEFT JOIN `whoknozme`.`county_tbl` `bcy_t`
      ON ((`bc_t`.`county_tbl_id` = `bcy_t`.`id`))) JOIN `whoknozme`.`business_object_tbl` `pbo`
      ON ((`pbo`.`id` = `p_t`.`id`))) JOIN `whoknozme`.`business_object_tbl` `cbo` ON ((`cbo`.`id` = `co_t`.`id`))) JOIN
    `whoknozme`.`business_object_tbl` `sbo` ON ((`sbo`.`id` = `sad_t`.`id`))) JOIN
    `whoknozme`.`business_object_tbl` `bbo` ON ((`bbo`.`id` = `bad_t`.`id`)));
