CREATE VIEW WhoKnozMe.action_bo_view AS
  SELECT
    `whoknozme`.`business_object_tbl`.`id`                 AS `bo_id`,
    `whoknozme`.`business_object_tbl`.`object_type_id`     AS `object_type_id`,
    `whoknozme`.`business_object_tbl`.`list_index`         AS `list_index`,
    `whoknozme`.`business_object_tbl`.`bo_name`            AS `bo_name`,
    `whoknozme`.`business_object_tbl`.`fullname`           AS `fullname`,
    `whoknozme`.`business_object_tbl`.`description`        AS `description`,
    `whoknozme`.`business_object_tbl`.`properties`         AS `properties`,
    `whoknozme`.`business_object_tbl`.`next_bo_id`         AS `next_bo_id`,
    `whoknozme`.`business_object_tbl`.`value_id`           AS `value_id`,
    `whoknozme`.`business_object_tbl`.`template_id`        AS `template_id`,
    `whoknozme`.`business_object_tbl`.`business_rule_id`   AS `business_rule_id`,
    `whoknozme`.`business_object_tbl`.`status`             AS `status`,
    `whoknozme`.`business_object_tbl`.`hidden`             AS `hidden`,
    `whoknozme`.`business_object_tbl`.`mobile_sync`        AS `mobile_sync`,
    `whoknozme`.`business_object_tbl`.`last_accessed_date` AS `last_accessed_date`,
    `whoknozme`.`business_object_tbl`.`update_type`        AS `update_type`,
    `whoknozme`.`business_object_tbl`.`updated_date`       AS `updated_date`,
    `whoknozme`.`business_object_tbl`.`created_date`       AS `created_date`,
    `whoknozme`.`business_object_tbl`.`effective_date`     AS `effective_date`,
    `whoknozme`.`business_object_tbl`.`expiry_date`        AS `expiry_date`,
    `whoknozme`.`business_object_tbl`.`participant_id`     AS `participant_id`,
    `whoknozme`.`business_object_tbl`.`owner_id`           AS `owner_id`,
    `whoknozme`.`business_object_tbl`.`owner_group_id`     AS `owner_group_id`,
    `whoknozme`.`business_object_tbl`.`last_accessor_id`   AS `last_accessor_id`,
    `whoknozme`.`business_object_tbl`.`updator_id`         AS `updator_id`,
    `whoknozme`.`business_object_tbl`.`creator_id`         AS `creator_id`,
    `whoknozme`.`business_object_tbl`.`external_id`        AS `external_id`,
    `whoknozme`.`business_object_tbl`.`external_key_id`    AS `external_key_id`,
    `whoknozme`.`business_object_tbl`.`external_source_id` AS `external_source_id`,
    `whoknozme`.`business_object_tbl`.`file_id`            AS `file_id`,
    `whoknozme`.`business_object_tbl`.`image_id`           AS `image_id`,
    `whoknozme`.`action_tbl`.`id`                          AS `ActionId`,
    `whoknozme`.`action_tbl`.`action_type`                 AS `action_type`,
    `whoknozme`.`action_type_tbl`.`action_noun_type`       AS `action_noun_type`,
    `whoknozme`.`action_tbl`.`participant_subject_id`      AS `participant_subject_id`,
    `psbo`.`bo_name`                                       AS `participant_subject_name`,
    `whoknozme`.`action_tbl`.`participant_object_id`       AS `participant_object_id`,
    `pobo`.`bo_name`                                       AS `participant_object_name`,
    `whoknozme`.`action_tbl`.`participant_authority_id`    AS `participant_authority_id`,
    `abo`.`bo_name`                                        AS `participant_authority_name`,
    `whoknozme`.`action_tbl`.`participant_device_id`       AS `participant_device_id`,
    `whoknozme`.`action_tbl`.`utc_time_start`              AS `utc_time_start`,
    `whoknozme`.`action_tbl`.`utc_time_end`                AS `utc_time_end`,
    `whoknozme`.`action_tbl`.`utc_time_offest`             AS `utc_time_offest`,
    `whoknozme`.`action_tbl`.`local_time_start`            AS `local_time_start`,
    `whoknozme`.`action_tbl`.`local_time_end`              AS `local_time_end`,
    `whoknozme`.`action_tbl`.`status_type_id`              AS `status_type_id`,
    `slookup`.`lookup_name`                                AS `status_type_name`,
    `whoknozme`.`action_tbl`.`action_list_id`              AS `action_list_id`,
    `whoknozme`.`action_tbl`.`start_time`                  AS `start_time`,
    `whoknozme`.`action_tbl`.`duration`                    AS `duration`,
    `al`.`action_list_name`                                AS `action_list_name`,
    `whoknozme`.`action_tbl`.`Alarm`                       AS `Alarm`,
    `whoknozme`.`action_tbl`.`AlarmSign`                   AS `AlarmSign`,
    `whoknozme`.`action_tbl`.`AlarmValue`                  AS `AlarmValue`,
    `whoknozme`.`action_tbl`.`AlarmTerm`                   AS `AlarmTerm`,
    `whoknozme`.`action_tbl`.`recurring_frequency`         AS `recurring_frequency`,
    `whoknozme`.`action_tbl`.`recurring_units_id`          AS `recurring_units_id`,
    `whoknozme`.`action_tbl`.`recurring_term`              AS `recurring_term`,
    `whoknozme`.`action_tbl`.`recurring_term_units_id`     AS `recurring_term_units_id`,
    `whoknozme`.`action_tbl`.`Dependancy_id`               AS `Dependancy_id`,
    `whoknozme`.`action_tbl`.`project_id`                  AS `project_id`,
    `ob`.`test_type_id`                                    AS `test_type_id`,
    `obl`.`MedicalObservation`                             AS `test_type_name`,
    `obl`.`lookup_type_id`                                 AS `look_id`,
    `obl`.`list_index`                                     AS `test_list_index`,
    `projbo`.`bo_name`                                     AS `project_name`,
    `obl`.`parent_id`                                      AS `parent_id`,
    `obll`.`MedicalObservation`                            AS `parent_name`
  FROM ((((((((((((`whoknozme`.`action_tbl`
    JOIN `whoknozme`.`business_object_tbl`
      ON ((`whoknozme`.`action_tbl`.`id` = `whoknozme`.`business_object_tbl`.`id`))) JOIN `whoknozme`.`action_type_tbl`
      ON ((`whoknozme`.`action_tbl`.`action_type` = `whoknozme`.`action_type_tbl`.`id`))) LEFT JOIN
    `whoknozme`.`business_object_tbl` `psbo`
      ON ((`whoknozme`.`action_tbl`.`participant_subject_id` = `psbo`.`id`))) LEFT JOIN
    `whoknozme`.`business_object_tbl` `pobo`
      ON ((`whoknozme`.`action_tbl`.`participant_object_id` = `pobo`.`id`))) LEFT JOIN
    `whoknozme`.`business_object_tbl` `abo`
      ON ((`whoknozme`.`action_tbl`.`participant_authority_id` = `abo`.`id`))) LEFT JOIN
    `whoknozme`.`business_object_tbl` `projbo` ON ((`whoknozme`.`action_tbl`.`project_id` = `projbo`.`id`))) LEFT JOIN
    `whoknozme`.`lookup_tbl` `slookup` ON ((`whoknozme`.`action_tbl`.`status_type_id` = `slookup`.`id`))) LEFT JOIN
    `whoknozme`.`action_list_tbl` `al` ON ((`whoknozme`.`action_tbl`.`action_list_id` = `al`.`id`))) LEFT JOIN
    `whoknozme`.`observation_tbl` `ob` ON ((`whoknozme`.`action_tbl`.`id` = `ob`.`action_id`))) LEFT JOIN
    `whoknozme`.`observation_lookup_tbl` `obl` ON ((`ob`.`test_type_id` = `obl`.`id`))) LEFT JOIN
    `whoknozme`.`object_type_tbl` `ott`
      ON ((`ott`.`id` = `whoknozme`.`business_object_tbl`.`object_type_id`))) LEFT JOIN
    `whoknozme`.`observation_lookup_tbl` `obll` ON ((`obl`.`parent_id` = `obll`.`id`)));
