CREATE VIEW WhoKnozMe.county_view AS
  SELECT
    `whoknozme`.`county_tbl`.`id`              AS `id`,
    `whoknozme`.`county_tbl`.`county_name`     AS `county_name`,
    `whoknozme`.`province_tbl`.`prov_name`     AS `prov_name`,
    `whoknozme`.`country_tbl`.`country_name`   AS `country_name`,
    `whoknozme`.`company_tbl`.`abbrev`         AS `CompanyAbbrev`,
    `whoknozme`.`county_tbl`.`properties`      AS `Properties`,
    `whoknozme`.`county_tbl`.`county_tax_rate` AS `CountyTaxRate`
  FROM (((`whoknozme`.`county_tbl`
    JOIN `whoknozme`.`province_tbl`
      ON ((`whoknozme`.`county_tbl`.`province_tbl_id` = `whoknozme`.`province_tbl`.`id`))) LEFT JOIN
    `whoknozme`.`country_tbl`
      ON ((`whoknozme`.`province_tbl`.`country_tbl_id` = `whoknozme`.`country_tbl`.`id`))) LEFT JOIN
    `whoknozme`.`company_tbl` ON ((`whoknozme`.`county_tbl`.`company_id` = `whoknozme`.`company_tbl`.`id`)));
