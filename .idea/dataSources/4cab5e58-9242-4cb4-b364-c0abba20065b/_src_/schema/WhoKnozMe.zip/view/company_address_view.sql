CREATE VIEW WhoKnozMe.company_address_view AS
  SELECT
    `c_v`.`id`                 AS `id`,
    `c_v`.`abbrev`             AS `abbrev`,
    `c_v`.`trademark`          AS `trademark`,
    `c_v`.`incorp_date`        AS `incorp_date`,
    `c_v`.`incorp_type_id`     AS `incorp_type_id`,
    `c_v`.`incorp_number`      AS `incorp_number`,
    `c_v`.`trading_symbol`     AS `trading_symbol`,
    `c_v`.`year_end_month`     AS `year_end_month`,
    `c_v`.`tax_number`         AS `tax_number`,
    `c_v`.`company_properties` AS `company_properties`,
    `c_v`.`contact_id`         AS `contact_id`,
    `c_v`.`object_type_id`     AS `object_type_id`,
    `c_v`.`bo_name`            AS `bo_name`,
    `c_v`.`fullname`           AS `fullname`,
    `c_v`.`description`        AS `description`,
    `c_v`.`status`             AS `status`,
    `c_v`.`hidden`             AS `hidden`,
    `c_v`.`mobile_sync`        AS `mobile_sync`,
    `c_v`.`effective_date`     AS `effective_date`,
    `co_t`.`mobile`            AS `Mobile`,
    `co_t`.`phone`             AS `Phone`,
    `co_t`.`work_number`       AS `work_number`,
    `co_t`.`email`             AS `Email`,
    `sad_t`.`address1`         AS `ShipToLine1`,
    `bad_t`.`address1`         AS `BillToLine1`,
    `sad_t`.`address2`         AS `ShipToLine2`,
    `bad_t`.`address2`         AS `BillToLine2`,
    `sc_t`.`id`                AS `ShipToCityID`,
    `sc_t`.`city_name`         AS `ShipToCity`,
    `sc_t`.`abbrev`            AS `ShipToCityAbbrev`,
    `bc_t`.`id`                AS `BillToCityID`,
    `bc_t`.`city_name`         AS `BillToCity`,
    `bc_t`.`abbrev`            AS `BillToCityAbbrev`,
    `cbo`.`bo_name`            AS `ContactBoName`,
    `cbo`.`fullname`           AS `ContactFullName`,
    `sbo`.`bo_name`            AS `ShipToBoName`,
    `sbo`.`fullname`           AS `ShipToFullName`,
    `bbo`.`bo_name`            AS `BillToBoName`,
    `bbo`.`fullname`           AS `BillToFullName`,
    `cbo`.`status`             AS `CboStatus`,
    `sbo`.`status`             AS `SboStatus`,
    `bbo`.`status`             AS `BboStatus`,
    `co_t`.`phone_ext`         AS `PhoneExt`,
    `co_t`.`fax`               AS `Fax`,
    `sad_t`.`postal_code`      AS `SadPostalCode`,
    `bad_t`.`postal_code`      AS `BadPostalCode`,
    `sad_t`.`lattitude`        AS `Sadlattitude`,
    `bad_t`.`lattitude`        AS `Badlattitude`,
    `sad_t`.`longitude`        AS `Sadlongitude`,
    `bad_t`.`longitude`        AS `Badlongitude`,
    `sp_t`.`id`                AS `SpProvID`,
    `sp_t`.`prov_name`         AS `SpProvName`,
    `bp_t`.`id`                AS `BpProvID`,
    `bp_t`.`prov_name`         AS `BpProvName`,
    `scy_t`.`id`               AS `ScyCountyID`,
    `scy_t`.`county_name`      AS `ScyCountyName`,
    `bcy_t`.`id`               AS `BcyCountyID`,
    `bcy_t`.`county_name`      AS `BcyCountyName`,
    `sco_t`.`id`               AS `ScoCountryID`,
    `sco_t`.`country_name`     AS `ScoCountryName`,
    `bco_t`.`id`               AS `BcoCountryID`,
    `bco_t`.`country_name`     AS `BcoCountryName`,
    `cbo`.`id`                 AS `ContactId`,
    `sbo`.`id`                 AS `ShipToId`,
    `bbo`.`id`                 AS `BillToId`
  FROM ((((((((((((((`whoknozme`.`company_bo_view` `c_v`
    JOIN `whoknozme`.`contact_tbl` `co_t` ON ((`co_t`.`id` = `c_v`.`contact_id`))) JOIN
    `whoknozme`.`address_tbl` `sad_t` ON ((`co_t`.`shipto_address_id` = `sad_t`.`id`))) JOIN
    `whoknozme`.`address_tbl` `bad_t` ON ((`co_t`.`billto_address_id` = `bad_t`.`id`))) JOIN
    `whoknozme`.`city_tbl` `sc_t` ON ((`sad_t`.`city_id` = `sc_t`.`id`))) JOIN `whoknozme`.`city_tbl` `bc_t`
      ON ((`bad_t`.`city_id` = `bc_t`.`id`))) LEFT JOIN `whoknozme`.`province_tbl` `sp_t`
      ON ((`sc_t`.`province_tbl_id` = `sp_t`.`id`))) LEFT JOIN `whoknozme`.`province_tbl` `bp_t`
      ON ((`bc_t`.`province_tbl_id` = `bp_t`.`id`))) JOIN `whoknozme`.`country_tbl` `sco_t`
      ON ((`sp_t`.`country_tbl_id` = `sco_t`.`id`))) JOIN `whoknozme`.`country_tbl` `bco_t`
      ON ((`bp_t`.`country_tbl_id` = `bco_t`.`id`))) LEFT JOIN `whoknozme`.`county_tbl` `scy_t`
      ON ((`sc_t`.`county_tbl_id` = `scy_t`.`id`))) LEFT JOIN `whoknozme`.`county_tbl` `bcy_t`
      ON ((`bc_t`.`county_tbl_id` = `bcy_t`.`id`))) JOIN `whoknozme`.`business_object_tbl` `cbo`
      ON ((`cbo`.`id` = `co_t`.`id`))) JOIN `whoknozme`.`business_object_tbl` `sbo`
      ON ((`sbo`.`id` = `sad_t`.`id`))) JOIN `whoknozme`.`business_object_tbl` `bbo` ON ((`bbo`.`id` = `bad_t`.`id`)));
