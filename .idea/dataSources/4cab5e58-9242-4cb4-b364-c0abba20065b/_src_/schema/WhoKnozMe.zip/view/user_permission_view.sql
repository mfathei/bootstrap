CREATE VIEW WhoKnozMe.user_permission_view AS
  SELECT
    `whoknozme`.`user_permission_tbl`.`id`         AS `id`,
    `whoknozme`.`user_permission_tbl`.`permission` AS `permission`,
    `whoknozme`.`enterprise_tbl`.`enterprise_name` AS `enterprise_name`,
    `whoknozme`.`user_tbl`.`username`              AS `username`
  FROM ((`whoknozme`.`user_permission_tbl`
    JOIN `whoknozme`.`user_tbl` ON ((`whoknozme`.`user_permission_tbl`.`user_id` = `whoknozme`.`user_tbl`.`id`))) JOIN
    `whoknozme`.`enterprise_tbl`
      ON ((`whoknozme`.`user_permission_tbl`.`enterprise_id` = `whoknozme`.`enterprise_tbl`.`id`)));
