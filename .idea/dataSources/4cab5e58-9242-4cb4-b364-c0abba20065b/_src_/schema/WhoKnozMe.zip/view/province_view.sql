CREATE VIEW WhoKnozMe.province_view AS
  SELECT
    `whoknozme`.`province_tbl`.`id`            AS `id`,
    `whoknozme`.`province_tbl`.`prov_name`     AS `prov_name`,
    `whoknozme`.`province_tbl`.`abbrev`        AS `abbrev`,
    `whoknozme`.`province_tbl`.`tax_type`      AS `tax_type`,
    `whoknozme`.`province_tbl`.`prov_tax_rate` AS `prov_tax_rate`,
    `whoknozme`.`province_tbl`.`prov_tax_rate` AS `fed_tax_rate`,
    `whoknozme`.`province_tbl`.`company_id`    AS `ProvinceCompany`,
    `whoknozme`.`country_tbl`.`country_name`   AS `country_name`,
    `whoknozme`.`company_tbl`.`abbrev`         AS `CompanyAbbrev`,
    `whoknozme`.`province_tbl`.`properties`    AS `Properties`,
    `whoknozme`.`province_tbl`.`url`           AS `Url`
  FROM ((`whoknozme`.`province_tbl`
    JOIN `whoknozme`.`country_tbl`
      ON ((`whoknozme`.`province_tbl`.`country_tbl_id` = `whoknozme`.`country_tbl`.`id`))) LEFT JOIN
    `whoknozme`.`company_tbl` ON ((`whoknozme`.`province_tbl`.`company_id` = `whoknozme`.`company_tbl`.`id`)));
