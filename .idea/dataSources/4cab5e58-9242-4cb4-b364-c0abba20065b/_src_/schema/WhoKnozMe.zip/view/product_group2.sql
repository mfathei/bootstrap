CREATE VIEW WhoKnozMe.product_group2 AS
  SELECT
    `whoknozme`.`business_object_tbl`.`id`                 AS `id`,
    `whoknozme`.`business_object_tbl`.`object_type_id`     AS `object_type_id`,
    `whoknozme`.`business_object_tbl`.`list_index`         AS `list_index`,
    `whoknozme`.`business_object_tbl`.`bo_name`            AS `bo_name`,
    `whoknozme`.`business_object_tbl`.`fullname`           AS `fullname`,
    `whoknozme`.`business_object_tbl`.`description`        AS `description`,
    `whoknozme`.`business_object_tbl`.`properties`         AS `properties`,
    `whoknozme`.`business_object_tbl`.`next_bo_id`         AS `next_bo_id`,
    `whoknozme`.`business_object_tbl`.`value_id`           AS `value_id`,
    `whoknozme`.`business_object_tbl`.`template_id`        AS `template_id`,
    `whoknozme`.`business_object_tbl`.`business_rule_id`   AS `business_rule_id`,
    `whoknozme`.`business_object_tbl`.`status`             AS `status`,
    `whoknozme`.`business_object_tbl`.`hidden`             AS `hidden`,
    `whoknozme`.`business_object_tbl`.`mobile_sync`        AS `mobile_sync`,
    `whoknozme`.`business_object_tbl`.`last_accessed_date` AS `last_accessed_date`,
    `whoknozme`.`business_object_tbl`.`update_type`        AS `update_type`,
    `whoknozme`.`business_object_tbl`.`updated_date`       AS `updated_date`,
    `whoknozme`.`business_object_tbl`.`created_date`       AS `created_date`,
    `whoknozme`.`business_object_tbl`.`effective_date`     AS `effective_date`,
    `whoknozme`.`business_object_tbl`.`expiry_date`        AS `expiry_date`,
    `whoknozme`.`business_object_tbl`.`participant_id`     AS `participant_id`,
    `whoknozme`.`business_object_tbl`.`owner_id`           AS `owner_id`,
    `whoknozme`.`business_object_tbl`.`owner_group_id`     AS `owner_group_id`,
    `whoknozme`.`business_object_tbl`.`last_accessor_id`   AS `last_accessor_id`,
    `whoknozme`.`business_object_tbl`.`updator_id`         AS `updator_id`,
    `whoknozme`.`business_object_tbl`.`creator_id`         AS `creator_id`,
    `whoknozme`.`business_object_tbl`.`external_id`        AS `external_id`,
    `whoknozme`.`business_object_tbl`.`external_key_id`    AS `external_key_id`,
    `whoknozme`.`business_object_tbl`.`external_source_id` AS `external_source_id`,
    `whoknozme`.`business_object_tbl`.`file_id`            AS `file_id`,
    `whoknozme`.`business_object_tbl`.`image_id`           AS `image_id`
  FROM `whoknozme`.`business_object_tbl`
  WHERE `whoknozme`.`business_object_tbl`.`object_type_id` IN (SELECT `whoknozme`.`object_type_tbl`.`id`
                                                               FROM `whoknozme`.`object_type_tbl`
                                                               WHERE (`whoknozme`.`object_type_tbl`.`object_type_name` =
                                                                      'group'));
