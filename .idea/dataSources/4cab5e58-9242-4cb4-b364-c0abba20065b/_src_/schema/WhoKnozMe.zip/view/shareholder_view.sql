CREATE VIEW WhoKnozMe.shareholder_view AS
  SELECT
    `ut`.`id`              AS `id`,
    `ut`.`username`        AS `username`,
    `gt`.`group_name`      AS `group_name`,
    `ugu`.`user_group_id`  AS `user_group_id`,
    `ut`.`status`          AS `status`,
    `ut`.`salt`            AS `salt`,
    `ut`.`properties`      AS `properties`,
    `ut`.`person_id`       AS `person_id`,
    `pbo`.`bo_name`        AS `person_name`,
    `pbo`.`participant_id` AS `pers_participant_id`,
    `ut`.`relationship_id` AS `relationship_id`,
    `rbo`.`bo_name`        AS `relationship_name`,
    `rbo`.`participant_id` AS `rel_participant_id`
  FROM ((((`whoknozme`.`user_tbl` `ut`
    JOIN `whoknozme`.`ugu_tbl` `ugu` ON ((`ut`.`id` = `ugu`.`user_id`))) JOIN `whoknozme`.`user_group_tbl` `gt`
      ON ((`ugu`.`user_group_id` = `gt`.`id`))) LEFT JOIN `whoknozme`.`business_object_tbl` `pbo`
      ON ((`ut`.`person_id` = `pbo`.`id`))) LEFT JOIN `whoknozme`.`business_object_tbl` `rbo`
      ON ((`ut`.`relationship_id` = `rbo`.`id`)))
  WHERE (`ugu`.`user_group_id` = 'aa8fe0a4-daa7-11e3-a4dc-1c6f65f2b147');
