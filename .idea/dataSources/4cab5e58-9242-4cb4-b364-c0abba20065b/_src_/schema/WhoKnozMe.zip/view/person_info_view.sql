CREATE VIEW WhoKnozMe.person_info_view AS
  SELECT DISTINCT
    `whoknozme`.`person_tbl`.`id`           AS `ID`,
    `whoknozme`.`person_tbl`.`first_name`   AS `FirstName`,
    `whoknozme`.`person_tbl`.`middle_names` AS `MiddleName`,
    `whoknozme`.`person_tbl`.`last_name`    AS `LastName`,
    `whoknozme`.`user_tbl`.`username`       AS `UserName`,
    `whoknozme`.`user_tbl`.`id`             AS `UserID`,
    `whoknozme`.`person_tbl`.`initials`     AS `initials`,
    `whoknozme`.`person_tbl`.`goes_by_name` AS `goes_by_name`,
    `whoknozme`.`person_tbl`.`title_id`     AS `title_id`,
    `whoknozme`.`person_tbl`.`prof_status`  AS `prof_status`,
    `whoknozme`.`person_tbl`.`contact_id`   AS `contact_id`,
    `co_t`.`country_id`                     AS `country_id`,
    `co_t`.`area_code1`                     AS `area_code1`,
    `lookup1`.`lookup_name`                 AS `phone_type_name1`,
    `co_t`.`phone_number1`                  AS `phone_number1`,
    `co_t`.`extension1`                     AS `extension1`,
    `co_t`.`area_code2`                     AS `area_code2`,
    `cntry`.`phone_code`                    AS `phone_code`,
    `lookup2`.`lookup_name`                 AS `phone_type_name2`,
    `co_t`.`phone_number2`                  AS `phone_number2`,
    `co_t`.`extension2`                     AS `extension2`,
    `co_t`.`area_code3`                     AS `area_code3`,
    `lookup3`.`lookup_name`                 AS `phone_type_name3`,
    `co_t`.`phone_number3`                  AS `phone_number3`,
    `co_t`.`extension3`                     AS `extension3`,
    `co_t`.`phone`                          AS `phone`,
    `co_t`.`phone_ext`                      AS `phone_ext`,
    `co_t`.`mobile`                         AS `mobile`,
    `co_t`.`work_number`                    AS `work_number`,
    `co_t`.`email`                          AS `Email`,
    `whoknozme`.`person_tbl`.`properties`   AS `properties`,
    `bo_t`.`participant_id`                 AS `participant_id`,
    `bo_t`.`bo_name`                        AS `BoName`,
    `bo_t`.`fullname`                       AS `FullName`,
    `sad_t`.`postal_code`                   AS `SadPostalCode`,
    `bad_t`.`postal_code`                   AS `BadPostalCode`,
    `bad_t`.`address1`                      AS `BillToLine1`,
    `sad_c`.`province_tbl_id`               AS `SadProvince`,
    `bad_c`.`province_tbl_id`               AS `BadProvince`,
    `bad_c`.`city_name`                     AS `BadCityName`,
    `bad_c`.`id`                            AS `BadCity`,
    `sad_p`.`prov_tax_rate`                 AS `SadTaxRate`,
    `bad_p`.`prov_tax_rate`                 AS `BadTaxRate`,
    `sad_p`.`tax_type`                      AS `SadTaxType`,
    `bad_p`.`tax_type`                      AS `BadTaxType`,
    `sad_p`.`prov_name`                     AS `SadProvName`,
    `bad_p`.`prov_name`                     AS `BadProvName`,
    `bad_p`.`company_id`                    AS `SadProvinceCompany`,
    `bad_p`.`company_id`                    AS `BadProvinceCompany`,
    `dm_t`.`date_of_birth`                  AS `date_of_birth`,
    `lookup4`.`lookup_name`                 AS `title`,
    `cntry`.`country_name`                  AS `country_name`
  FROM (((((((((((((((`whoknozme`.`person_tbl`
    JOIN `whoknozme`.`business_object_tbl` `bo_t` ON ((`bo_t`.`id` = `whoknozme`.`person_tbl`.`id`))) LEFT JOIN
    `whoknozme`.`user_tbl` ON ((`whoknozme`.`person_tbl`.`id` = `whoknozme`.`user_tbl`.`person_id`))) JOIN
    `whoknozme`.`contact_tbl` `co_t` ON ((`whoknozme`.`person_tbl`.`contact_id` = `co_t`.`id`))) JOIN
    `whoknozme`.`demographics_tbl` `dm_t` ON ((`whoknozme`.`person_tbl`.`id` = `dm_t`.`person_id`))) JOIN
    `whoknozme`.`address_tbl` `sad_t` ON ((`co_t`.`shipto_address_id` = `sad_t`.`id`))) JOIN
    `whoknozme`.`address_tbl` `bad_t` ON ((`co_t`.`billto_address_id` = `bad_t`.`id`))) JOIN
    `whoknozme`.`city_tbl` `sad_c` ON ((`sad_t`.`city_id` = `sad_c`.`id`))) JOIN `whoknozme`.`province_tbl` `sad_p`
      ON ((`sad_p`.`id` = `sad_c`.`province_tbl_id`))) JOIN `whoknozme`.`city_tbl` `bad_c`
      ON ((`bad_t`.`city_id` = `bad_c`.`id`))) JOIN `whoknozme`.`province_tbl` `bad_p`
      ON ((`bad_p`.`id` = `bad_c`.`province_tbl_id`))) LEFT JOIN `whoknozme`.`country_tbl` `cntry`
      ON ((`co_t`.`country_id` = `cntry`.`id`))) LEFT JOIN `whoknozme`.`lookup_tbl` `lookup1`
      ON ((`lookup1`.`id` = `co_t`.`phone_type_id1`))) LEFT JOIN `whoknozme`.`lookup_tbl` `lookup2`
      ON ((`lookup2`.`id` = `co_t`.`phone_type_id2`))) LEFT JOIN `whoknozme`.`lookup_tbl` `lookup3`
      ON ((`lookup3`.`id` = `co_t`.`phone_type_id3`))) LEFT JOIN `whoknozme`.`lookup_tbl` `lookup4`
      ON ((`lookup4`.`id` = `whoknozme`.`person_tbl`.`title_id`)));
