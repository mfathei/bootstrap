CREATE VIEW WhoKnozMe.company_co_view AS
  SELECT DISTINCT
    `com_t`.`id`                                AS `id`,
    `com_t`.`abbrev`                            AS `abbrev`,
    `com_t`.`trademark`                         AS `trademark`,
    `com_t`.`incorp_date`                       AS `incorp_date`,
    `com_t`.`incorp_type_id`                    AS `incorp_type_id`,
    `inc_type`.`lookup_name`                    AS `incorp_type_name`,
    `com_t`.`incorp_number`                     AS `incorp_number`,
    `com_t`.`trading_symbol`                    AS `trading_symbol`,
    `com_t`.`year_end_month`                    AS `year_end_month`,
    `com_t`.`tax_number`                        AS `tax_number`,
    `com_t`.`properties`                        AS `properties`,
    `com_t`.`contact_id`                        AS `contact_id`,
    `com_t`.`incorp_authority_id`               AS `incorp_authority_id`,
    `com_t`.`incorp_act_id`                     AS `incorp_act_id`,
    `com_t`.`incorp_jurisdication_stateprov_id` AS `incorp_jurisdication_stateprov_id`,
    `com_t`.`incorp_jurisdication_federal_id`   AS `incorp_jurisdication_federal_id`,
    `com_t`.`extraprovincial_registration`      AS `extraprovincial_registration`,
    `co_t`.`mobile`                             AS `Mobile`,
    `co_t`.`phone`                              AS `Phone`,
    `co_t`.`email`                              AS `email`,
    `co_t`.`country_id`                         AS `country_id`,
    `co_t`.`work_number`                        AS `work_number`,
    `co_t`.`area_code1`                         AS `area_code1`,
    `co_t`.`area_code2`                         AS `area_code2`,
    `co_t`.`area_code3`                         AS `area_code3`,
    `co_t`.`phone_number1`                      AS `phone_number1`,
    `co_t`.`extension1`                         AS `extension1`,
    `co_t`.`phone_type_id1`                     AS `phone_type_id1`,
    `pht1`.`lookup_name`                        AS `phone_type_name1`,
    `co_t`.`phone_number2`                      AS `phone_number2`,
    `co_t`.`extension2`                         AS `extension2`,
    `co_t`.`phone_type_id2`                     AS `phone_type_id2`,
    `pht2`.`lookup_name`                        AS `phone_type_name2`,
    `co_t`.`phone_number3`                      AS `phone_number3`,
    `co_t`.`extension3`                         AS `extension3`,
    `co_t`.`phone_type_id3`                     AS `phone_type_id3`,
    `pht3`.`lookup_name`                        AS `phone_type_name3`,
    `sad_t`.`address1`                          AS `ShipToLine1`,
    `bad_t`.`address1`                          AS `BillToLine1`,
    `sad_t`.`address2`                          AS `ShipToLine2`,
    `bad_t`.`address2`                          AS `BillToLine2`,
    `sc_t`.`id`                                 AS `ShipToCityID`,
    `sc_t`.`city_name`                          AS `ShipToCity`,
    `sc_t`.`abbrev`                             AS `ShipToCityAbbrev`,
    `bc_t`.`id`                                 AS `BillToCityID`,
    `bc_t`.`city_name`                          AS `BillToCity`,
    `bc_t`.`abbrev`                             AS `BillToCityAbbrev`,
    `pbo`.`bo_name`                             AS `BoName`,
    `pbo`.`fullname`                            AS `FullName`,
    `pbo`.`description`                         AS `Description`,
    `cbo`.`bo_name`                             AS `ContactBoName`,
    `cbo`.`fullname`                            AS `ContactFullName`,
    `sbo`.`bo_name`                             AS `ShipToBoName`,
    `sbo`.`fullname`                            AS `ShipToFullName`,
    `bbo`.`bo_name`                             AS `BillToBoName`,
    `bbo`.`fullname`                            AS `BillToFullName`,
    `pbo`.`status`                              AS `PboStatus`,
    `cbo`.`status`                              AS `CboStatus`,
    `sbo`.`status`                              AS `SboStatus`,
    `bbo`.`status`                              AS `BboStatus`,
    `co_t`.`phone_ext`                          AS `PhoneExt`,
    `co_t`.`fax`                                AS `Fax`,
    `co_t`.`sms`                                AS `sms`,
    `co_t`.`dialing_code`                       AS `dialing_code`,
    `sad_t`.`postal_code`                       AS `SadPostalCode`,
    `bad_t`.`postal_code`                       AS `BadPostalCode`,
    `sad_t`.`lattitude`                         AS `Sadlattitude`,
    `bad_t`.`lattitude`                         AS `Badlattitude`,
    `sad_t`.`longitude`                         AS `Sadlongitude`,
    `bad_t`.`longitude`                         AS `Badlongitude`,
    `sad_t`.`street_number`                     AS `SadStreetNumber`,
    `sad_t`.`street_name`                       AS `SadStreetName`,
    `sad_t`.`street_type_id`                    AS `SadStreetType`,
    `shipst`.`lookup_name`                      AS `SadStreetTypeName`,
    `sad_t`.`street_direction_id`               AS `SadStreetDirection`,
    `shipdir`.`lookup_name`                     AS `SadStreetDirectionName`,
    `sspace`.`area_number`                      AS `ShipAreaNumber`,
    `bad_t`.`street_number`                     AS `BadStreetNumber`,
    `bad_t`.`street_name`                       AS `BadStreetName`,
    `bad_t`.`street_type_id`                    AS `BadStreetType`,
    `billst`.`lookup_name`                      AS `BadStreetTypeName`,
    `bad_t`.`street_direction_id`               AS `BadStreetDirection`,
    `billdir`.`lookup_name`                     AS `BadStreetDirectionName`,
    `bspace`.`area_number`                      AS `BillAreaNumber`,
    `sp_t`.`id`                                 AS `SpProvID`,
    `sp_t`.`prov_name`                          AS `SpProvName`,
    `bp_t`.`id`                                 AS `BpProvID`,
    `bp_t`.`prov_name`                          AS `BpProvName`,
    `sco_t`.`id`                                AS `ScoCountryID`,
    `sco_t`.`country_name`                      AS `ScoCountryName`,
    `bco_t`.`id`                                AS `BcoCountryID`,
    `bco_t`.`country_name`                      AS `BcoCountryName`,
    `cbo`.`id`                                  AS `ContactId`,
    `sbo`.`id`                                  AS `ShipToId`,
    `bbo`.`id`                                  AS `BillToId`
  FROM (((((((((((((((((((((((`whoknozme`.`company_tbl` `com_t`
    JOIN `whoknozme`.`contact_tbl` `co_t` ON ((`com_t`.`contact_id` = `co_t`.`id`))) LEFT JOIN
    `whoknozme`.`lookup_tbl` `inc_type` ON ((`inc_type`.`id` = `com_t`.`incorp_type_id`))) LEFT JOIN
    `whoknozme`.`lookup_tbl` `pht1` ON ((`co_t`.`phone_type_id1` = `pht1`.`id`))) LEFT JOIN
    `whoknozme`.`lookup_tbl` `pht2` ON ((`co_t`.`phone_type_id2` = `pht2`.`id`))) LEFT JOIN
    `whoknozme`.`lookup_tbl` `pht3` ON ((`co_t`.`phone_type_id3` = `pht3`.`id`))) JOIN `whoknozme`.`address_tbl` `sad_t`
      ON ((`co_t`.`shipto_address_id` = `sad_t`.`id`))) LEFT JOIN `whoknozme`.`lookup_tbl` `shipst`
      ON ((`sad_t`.`street_type_id` = `shipst`.`id`))) LEFT JOIN `whoknozme`.`lookup_tbl` `shipdir`
      ON ((`sad_t`.`street_direction_id` = `shipdir`.`id`))) LEFT JOIN `whoknozme`.`space_tbl` `sspace`
      ON ((`sad_t`.`id` = `sspace`.`address_id`))) JOIN `whoknozme`.`address_tbl` `bad_t`
      ON ((`co_t`.`billto_address_id` = `bad_t`.`id`))) LEFT JOIN `whoknozme`.`lookup_tbl` `billst`
      ON ((`bad_t`.`street_type_id` = `billst`.`id`))) LEFT JOIN `whoknozme`.`lookup_tbl` `billdir`
      ON ((`bad_t`.`street_direction_id` = `billdir`.`id`))) LEFT JOIN `whoknozme`.`space_tbl` `bspace`
      ON ((`bad_t`.`id` = `bspace`.`address_id`))) JOIN `whoknozme`.`city_tbl` `sc_t`
      ON ((`sad_t`.`city_id` = `sc_t`.`id`))) JOIN `whoknozme`.`city_tbl` `bc_t`
      ON ((`bad_t`.`city_id` = `bc_t`.`id`))) LEFT JOIN `whoknozme`.`province_tbl` `sp_t`
      ON ((`sc_t`.`province_tbl_id` = `sp_t`.`id`))) LEFT JOIN `whoknozme`.`province_tbl` `bp_t`
      ON ((`bc_t`.`province_tbl_id` = `bp_t`.`id`))) JOIN `whoknozme`.`country_tbl` `sco_t`
      ON ((`sp_t`.`country_tbl_id` = `sco_t`.`id`))) JOIN `whoknozme`.`country_tbl` `bco_t`
      ON ((`bp_t`.`country_tbl_id` = `bco_t`.`id`))) JOIN `whoknozme`.`business_object_tbl` `pbo`
      ON ((`pbo`.`id` = `com_t`.`id`))) JOIN `whoknozme`.`business_object_tbl` `cbo`
      ON ((`cbo`.`id` = `co_t`.`id`))) JOIN `whoknozme`.`business_object_tbl` `sbo`
      ON ((`sbo`.`id` = `sad_t`.`id`))) JOIN `whoknozme`.`business_object_tbl` `bbo` ON ((`bbo`.`id` = `bad_t`.`id`)));
