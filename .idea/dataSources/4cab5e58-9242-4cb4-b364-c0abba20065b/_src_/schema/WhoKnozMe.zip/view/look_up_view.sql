CREATE VIEW WhoKnozMe.look_up_view AS
  SELECT
    `whoknozme`.`lookup_tbl`.`id`                    AS `id`,
    `whoknozme`.`lookup_tbl`.`lookup_name`           AS `lookup_name`,
    `whoknozme`.`lookup_tbl`.`list_index`            AS `list_index`,
    `whoknozme`.`lookup_type_tbl`.`lookup_type_name` AS `lookup_type`,
    `whoknozme`.`lookup_tbl`.`translation_id`        AS `translation_id`,
    `whoknozme`.`lookup_tbl`.`level`                 AS `level`,
    `whoknozme`.`file_tbl`.`file_name`               AS `FileName`,
    `whoknozme`.`lookup_tbl`.`taxonomy`              AS `taxonomy`,
    `whoknozme`.`lookup_tbl`.`level_type`            AS `level_type`,
    `whoknozme`.`lookup_tbl`.`concept_type`          AS `concept_type`,
    `whoknozme`.`lookup_tbl`.`mnemonic`              AS `mnemonic`,
    `whoknozme`.`lookup_tbl`.`description`           AS `description`,
    `whoknozme`.`business_rule_tbl`.`script`         AS `Script`,
    `l_t`.`lookup_name`                              AS `NextLookupName`,
    `whoknozme`.`lookup_tbl`.`common_bo_name`        AS `common_bo_name`,
    `whoknozme`.`lookup_tbl`.`common_fullname`       AS `common_fullname`,
    `whoknozme`.`lookup_tbl`.`common_description`    AS `common_description`,
    `whoknozme`.`lookup_tbl`.`concept_company_id`    AS `concept_company_id`,
    `whoknozme`.`lookup_tbl`.`concept_external_id`   AS `concept_external_id`,
    `whoknozme`.`lookup_tbl`.`reference_link`        AS `reference_link`,
    `whoknozme`.`lookup_tbl`.`reference_company_id`  AS `reference_company_id`,
    `whoknozme`.`lookup_tbl`.`parent_id`             AS `parent_id`,
    `parent`.`lookup_name`                           AS `parent_name`
  FROM (((((`whoknozme`.`lookup_tbl`
    JOIN `whoknozme`.`lookup_type_tbl`
      ON ((`whoknozme`.`lookup_tbl`.`lookup_type_id` = `whoknozme`.`lookup_type_tbl`.`id`))) LEFT JOIN
    `whoknozme`.`file_tbl` ON ((`whoknozme`.`lookup_tbl`.`file_id` = `whoknozme`.`file_tbl`.`id`))) LEFT JOIN
    `whoknozme`.`business_rule_tbl`
      ON ((`whoknozme`.`lookup_tbl`.`business_rule_id` = `whoknozme`.`business_rule_tbl`.`id`))) LEFT JOIN
    `whoknozme`.`lookup_tbl` `l_t` ON ((`whoknozme`.`lookup_tbl`.`next_id` = `l_t`.`id`))) LEFT JOIN
    `whoknozme`.`lookup_tbl` `parent` ON ((`whoknozme`.`lookup_tbl`.`parent_id` = `parent`.`id`)));
