CREATE VIEW WhoKnozMe.rel_type_view AS
  SELECT
    `whoknozme`.`rel_type_tbl`.`id`              AS `id`,
    `whoknozme`.`rel_type_tbl`.`rel_type_name`   AS `rel_type_name`,
    concat(`whoknozme`.`rel_type_tbl`.`rel_type_name`, ' (', `subject_t`.`object_type_name`, ' to ',
           `object_t`.`object_type_name`, ')')   AS `rel_type_fullname`,
    `subject_t`.`object_type_name`               AS `subject_bo_type`,
    `object_t`.`object_type_name`                AS `object_bo_type`,
    `whoknozme`.`rel_type_tbl`.`rel_type_abbrev` AS `rel_type_abbrev`
  FROM ((`whoknozme`.`rel_type_tbl`
    JOIN `whoknozme`.`object_type_tbl` `subject_t`
      ON ((`whoknozme`.`rel_type_tbl`.`subject_bo_type` = `subject_t`.`id`))) JOIN
    `whoknozme`.`object_type_tbl` `object_t` ON ((`whoknozme`.`rel_type_tbl`.`object_bo_type` = `object_t`.`id`)));
