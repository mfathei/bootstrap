CREATE VIEW WhoKnozMe.business_rule_view AS
  SELECT
    `whoknozme`.`business_rule_tbl`.`id`         AS `id`,
    `whoknozme`.`business_rule_tbl`.`script`     AS `script`,
    `whoknozme`.`business_rule_tbl`.`properties` AS `properties`,
    `bpname`.`script`                            AS `partnerscript`
  FROM (`whoknozme`.`business_rule_tbl`
    JOIN `whoknozme`.`business_rule_tbl` `bpname` ON ((`whoknozme`.`business_rule_tbl`.`next_id` = `bpname`.`id`)));
