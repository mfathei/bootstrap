CREATE VIEW WhoKnozMe.person_file_view AS
  SELECT
    `p_t`.`id`        AS `id`,
    `f_t`.`file_path` AS `ProfilePicture`
  FROM ((`whoknozme`.`person_tbl` `p_t`
    JOIN `whoknozme`.`identity_tbl` `i_t` ON ((`p_t`.`id` = `i_t`.`person_id`))) JOIN `whoknozme`.`file_tbl` `f_t`
      ON ((`i_t`.`picture_id` = `f_t`.`id`)));
