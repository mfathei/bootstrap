CREATE VIEW WhoKnozMe.rel_roles_view AS
  SELECT
    `whoknozme`.`rel_roles_tbl`.`id`                  AS `id`,
    `whoknozme`.`rel_roles_tbl`.`object_role`         AS `object_role`,
    `whoknozme`.`rel_roles_tbl`.`subject_role`        AS `subject_role`,
    `whoknozme`.`rel_roles_tbl`.`object_role_abbrev`  AS `object_role_abbrev`,
    `whoknozme`.`rel_roles_tbl`.`subject_role_abbrev` AS `subject_role_abbrev`,
    `whoknozme`.`rel_type_tbl`.`rel_type_name`        AS `rel_type_name`
  FROM (`whoknozme`.`rel_roles_tbl`
    JOIN `whoknozme`.`rel_type_tbl` ON ((`whoknozme`.`rel_roles_tbl`.`rel_type_id` = `whoknozme`.`rel_type_tbl`.`id`)));
