CREATE VIEW WhoKnozMe.codedlist_family_medical_view AS
  SELECT
    `fmt`.`person_id`            AS `person_id`,
    `fmt`.`codedlist_lookup_id`  AS `codedlist_lookup_id`,
    `cltc`.`common_name`         AS `child_common_name`,
    `cltc`.`lookup_name`         AS `child_lookup_name`,
    `cltc`.`parent_id`           AS `parent_id`,
    `cltc`.`concept_external_id` AS `concept_external_id`,
    `cltp`.`common_name`         AS `parent_common_name`,
    `cltp`.`lookup_name`         AS `parent_lookup_name`,
    `fmt`.`individual`           AS `individual`,
    `fmt`.`mom`                  AS `mom`,
    `fmt`.`mom_ephr`             AS `mom_ephr`,
    `fmt`.`dad`                  AS `dad`,
    `fmt`.`dad_ephr`             AS `dad_ephr`,
    `fmt`.`sister`               AS `sister`,
    `fmt`.`sister_ephr`          AS `sister_ephr`,
    `fmt`.`brother`              AS `brother`,
    `fmt`.`brother_ephr`         AS `brother_ephr`,
    `fmt`.`daughter`             AS `daughter`,
    `fmt`.`daughter_ephr`        AS `daughter_ephr`,
    `fmt`.`son`                  AS `son`,
    `fmt`.`son_ephr`             AS `son_ephr`,
    `fmt`.`other_close_rel`      AS `other_close_rel`,
    `fmt`.`other_close_rel_ephr` AS `other_close_rel_ephr`,
    `fmt`.`acuity_id`            AS `acuity_id`,
    `lk2`.`lookup_name`          AS `acuity_name`,
    `fmt`.`severity_id`          AS `severity_id`,
    `lk1`.`lookup_name`          AS `severity_name`,
    `fmt`.`comment`              AS `family_medical_comment`,
    `fmt`.`updated_date`         AS `updated_date`
  FROM ((((`whoknozme`.`family_medical_tbl` `fmt`
    JOIN `whoknozme`.`codedlist_lookup_tbl` `cltc` ON ((`cltc`.`id` = `fmt`.`codedlist_lookup_id`))) JOIN
    `whoknozme`.`codedlist_lookup_tbl` `cltp` ON ((`cltp`.`id` = `cltc`.`parent_id`))) LEFT JOIN
    `whoknozme`.`lookup_tbl` `lk1` ON ((`lk1`.`id` = `fmt`.`severity_id`))) LEFT JOIN `whoknozme`.`lookup_tbl` `lk2`
      ON ((`lk2`.`id` = `fmt`.`acuity_id`)));
