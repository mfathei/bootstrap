CREATE VIEW WhoKnozMe.user_type_view AS
  (SELECT
     `whoknozme`.`user_tbl`.`id`                 AS `id`,
     `whoknozme`.`user_tbl`.`username`           AS `username`,
     `whoknozme`.`user_tbl`.`password`           AS `password`,
     `whoknozme`.`user_tbl`.`status`             AS `status`,
     `whoknozme`.`user_tbl`.`salt`               AS `salt`,
     `whoknozme`.`user_tbl`.`properties`         AS `properties`,
     `whoknozme`.`user_tbl`.`person_id`          AS `person_id`,
     `whoknozme`.`user_tbl`.`relationship_id`    AS `relationship_id`,
     `whoknozme`.`business_object_tbl`.`bo_name` AS `bo_name`,
     `whoknozme`.`user_group_tbl`.`group_name`   AS `group_name`
   FROM ((((`whoknozme`.`user_tbl`
     JOIN `whoknozme`.`person_tbl` ON ((`whoknozme`.`user_tbl`.`person_id` = `whoknozme`.`person_tbl`.`id`))) JOIN
     `whoknozme`.`business_object_tbl`
       ON ((`whoknozme`.`person_tbl`.`id` = `whoknozme`.`business_object_tbl`.`id`))) JOIN `whoknozme`.`ugu_tbl`
       ON ((`whoknozme`.`ugu_tbl`.`user_id` = `whoknozme`.`user_tbl`.`id`))) JOIN `whoknozme`.`user_group_tbl`
       ON ((`whoknozme`.`ugu_tbl`.`user_group_id` = `whoknozme`.`user_group_tbl`.`id`))));
