CREATE PROCEDURE common.add_city(IN cityname VARCHAR(255), IN stateid VARCHAR(50))
  BEGIN
	set @uuid = (select myuuid());
    insert into city (city_id,state_id,city_name) values (@uuid,stateid,cityname);
    select @uuid;
END;
