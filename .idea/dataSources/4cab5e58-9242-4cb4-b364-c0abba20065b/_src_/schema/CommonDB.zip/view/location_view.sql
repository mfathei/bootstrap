CREATE VIEW CommonDB.location_view AS
  SELECT
    `commondb`.`location1`.`Location1Id`   AS `Location1Id`,
    `commondb`.`location1`.`Location1Name` AS `Location1Name`,
    `commondb`.`location1`.`OrgId`         AS `OrgId`,
    `commondb`.`location1`.`Order`         AS `Location1Order`,
    `commondb`.`location2`.`Location2Id`   AS `Location2Id`,
    `commondb`.`location2`.`Location2Name` AS `Location2Name`,
    `commondb`.`location2`.`Order`         AS `Location2Order`,
    `commondb`.`location3`.`Location3Id`   AS `Location3Id`,
    `commondb`.`location3`.`Location3Name` AS `Location3Name`,
    `commondb`.`location3`.`Order`         AS `Location3Order`,
    `commondb`.`location4`.`Location4Id`   AS `Location4Id`,
    `commondb`.`location4`.`Location4Name` AS `Location4Name`,
    `commondb`.`location4`.`Order`         AS `Location4Order`
  FROM (((`commondb`.`location1`
    LEFT JOIN `commondb`.`location2`
      ON (((`commondb`.`location1`.`Location1Id` = `commondb`.`location2`.`Location1Id`) AND
           (`commondb`.`location2`.`Hide` = 0)))) LEFT JOIN `commondb`.`location3`
      ON (((`commondb`.`location2`.`Location2Id` = `commondb`.`location3`.`Location2Id`) AND
           (`commondb`.`location3`.`Hide` = 0)))) LEFT JOIN `commondb`.`location4`
      ON (((`commondb`.`location3`.`Location3Id` = `commondb`.`location4`.`Location3Id`) AND
           (`commondb`.`location4`.`Hide` = 0))))
  WHERE (`commondb`.`location1`.`Hide` = 0);
