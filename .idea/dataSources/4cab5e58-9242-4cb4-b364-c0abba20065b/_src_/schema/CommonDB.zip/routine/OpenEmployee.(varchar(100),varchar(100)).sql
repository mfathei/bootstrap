CREATE PROCEDURE CommonDB.OpenEmployee(IN `$EmployeeId` VARCHAR(100), IN `$OrgId` VARCHAR(100))
  BEGIN


select  organization.OrgId,organization.OrgName, employee.EmployeeId, employee.FirstName, employee.LastName, 
		employee.Email, employee.Address, city.CityName, 
		employee.SecurityQuestionId, employee.SecurityAnswer, security_question.Question,
		province.ProvinceName, country.CountryName,
		org_employee.Department,  org_employee.Company, emp_group.AssignToGroupDate,
		province.ProvinceId, country.CountryId, employee.PostalCode, employee.Password,employee.CityId,
		employee.Position, employee.Area, employee.Location, employee.PrimaryPhone, employee.AlternatePhone,
		org_employee.SupervisorId,`group`.Description, 
		concat(Supervisor.Firstname,' ', Supervisor.lastName) as SupervisorName, 
        CASE emp_group.IsActive WHEN '0' THEN 'Inactive' WHEN '1' THEN 'Active' END AS UserStatus,
		CASE org_employee.EmpIsActive WHEN '0' THEN 'Inactive' WHEN '1' THEN 'Active' END AS EmpStatus,

		CASE emp_group.IsActive WHEN '0' THEN '0' WHEN '1' THEN '1' END AS IsActive,
		CASE org_employee.EmpIsActive WHEN '0' THEN '0' WHEN '1' THEN '1' END AS EmpIsActive,
 
		`group`.GroupId, `group`.GroupName
		,product.ProductId, product.ProductName, ClassificationName, org_employee.ClassificationId, DirectAccessCode
			
from employee   
	inner join  org_employee on org_employee.EmployeeId = employee.EmployeeId
	inner join  organization on organization.OrgId =org_employee.OrgId
	left outer join  city on city.CityId = employee.CityId
	left outer join  province on province.provinceId = city.provinceId
	left outer join  country on country.countryId = province.CountryId
	left outer join  employee as Supervisor  on Supervisor.EmployeeId = org_employee.SupervisorId	
	left outer join  emp_group on emp_group.EmployeeId = employee.EmployeeId  and groupid in (select groupid from `group` where orgid = $OrgId)
	left outer join  `group`  on `group` .GroupId = emp_group.GroupId and organization.orgid = `group`.orgid
	 
	left outer join  product_group on product_group.GroupId = `group`.GroupId  and product_group.GroupId  =  emp_group.GroupId
	left outer join  product_version on  product_version.ProductVersionId = product_group.ProductVersionId
	left outer join  product on product.ProductId = product_version.ProductId
	left outer join  security_question on security_question.SecurityQuestionId = employee.SecurityQuestionId
	left outer join  classification on classification.ClassificationId = org_employee.ClassificationId


where employee.EmployeeId= $EmployeeId and org_employee.OrgId = $OrgId
group by ProductName;

	


END;
