CREATE PROCEDURE CommonDB.GetSupervisorId(IN `$OrgId` VARCHAR(100), IN `$SupervisorName` TEXT)
  BEGIN

set @selectquery ="select employee.EmployeeId, concat(employee.FirstName, ' ' ,employee.LastName) as SupervisorName";
set @queryFrom = " from employee
            inner join org_employee on org_employee.EmployeeId= employee.EmployeeId ";


SET @queryWhere = CONCAT('where org_employee.Orgid = "', $OrgId,'"');
 SET @queryWhere = CONCAT(@queryWhere,'  AND CONCAT (FirstName',  ' , ' ',','LastName)',' like('"'%", $SupervisorName ,"%'"')');	
SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );


-- select @query; 


PREPARE stmt1 FROM @query;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 

END;
