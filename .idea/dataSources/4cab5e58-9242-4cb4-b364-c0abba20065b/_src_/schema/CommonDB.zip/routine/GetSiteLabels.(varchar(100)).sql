CREATE PROCEDURE CommonDB.GetSiteLabels(IN `$languageCode` VARCHAR(100))
  BEGIN
SELECT 
	`field`.`FieldId`,
    `field`.`FieldName`,
    `field`.`DefaultFieldLabel`,
    `field`.`PageName`
FROM `CommonDB`.`field`
join `language` on `language`.LanguageId= field.LanguageId
WHERE languageCode =$languageCode;
END;
