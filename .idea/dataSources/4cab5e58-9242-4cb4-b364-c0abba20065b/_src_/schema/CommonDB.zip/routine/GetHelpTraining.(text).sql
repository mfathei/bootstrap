CREATE PROCEDURE CommonDB.GetHelpTraining(IN xmlData TEXT)
  BEGIN

SET @page = extractvalue(xmlData, '//page');

SET @limit = extractvalue(xmlData, '//limit');

SET @sortOrder =  extractvalue(xmlData, '//sortOrder');

SET @index =  extractvalue(xmlData, '//index');

SET @Export =  extractvalue(xmlData, '//Export'); 
SET @LanguageCode =  extractvalue(xmlData, '//LanguageCode'); 


set @selectquery ="SELECT HelpId, HelpName, HelpTypeName, MaterialType, help.`Order`, HelpDescription, concat(FirstName,' ' , LastName) as UpdatedById, UpdatedDate, help_type.HelpTypeId, HelpURL   ";
                
set @queryFrom = " from  help
 inner join help_type on help.HelpTypeId=help_type.HelpTypeId
 join `language` ln on ln.LanguageId = help_type.LanguageId
inner join employee on help.UpdatedById = employee.EmployeeId ";

SET @queryWhere = ' where 1= 1 and OrgId is null and help_type.IsActive=1';

SET @queryWhere = CONCAT(@queryWhere,' and LanguageCode = "', @LanguageCode,'"');
 
SET @myArrayOfValue = 'HelpId,HelpName,HelpTypeName,Order,HelpDescription,UpdatedById,';

SET @Postition = LOCATE(',', @myArrayOfValue);

WHILE ( @Postition > 0 ) DO

 SET @STR = SUBSTRING(@myArrayOfValue, 1, @Postition-1);
 SET @myArrayOfValue = SUBSTRING(@myArrayOfValue, @Postition + 1);

	SET @Col =  extractvalue(xmlData, CONCAT('//',@STR));

	IF (@Col != '' AND @Col !='NULL') THEN
		if( @STR = 'Order') then set  @STR = ' help.`Order`';  end if;
        if( @STR = 'UpdatedById') then set  @STR = 'concat(FirstName,' ' , LastName)';  end if;
		SET @queryWhere = CONCAT(@queryWhere,CONCAT(' AND    ',@STR,' like '"'%", @Col ,"%'")); 
	END IF;
 
 SET @Postition = LOCATE(',', @myArrayOfValue);
END WHILE;

SET @MaterialType =  extractvalue(xmlData, '//MaterialType');
IF (@MaterialType != '' AND @MaterialType !='NULL') THEN
	IF( @MaterialType  != '2' ) THEN 
		SET @queryWhere = CONCAT(@queryWhere,'  AND MaterialType like "', @MaterialType ,'"');  
	END IF;	
END IF;

SET @UpdatedDateFrom =  extractvalue(xmlData, '//UpdatedDateFrom');
SET @UpdatedDateTo =  extractvalue(xmlData, '//UpdatedDateTo');
IF(@UpdatedDateTo != '') THEN
	
	SET @UpdatedDateTo  = STR_TO_DATE(@UpdatedDateTo , '%m/%d/%Y');
	SET @UpdatedDateTo2 = DATE_ADD(@UpdatedDateTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND help.UpdatedDate >  ', "'" , @UpdatedDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND help.UpdatedDate <=  ', "'",  @UpdatedDateTo2  ,"'" );										
ELSE 
IF(@UpdatedDateTo = '' AND @UpdatedDateFrom !='' ) THEN
	SET @UpdatedDateFrom  = STR_TO_DATE(@UpdatedDateFrom , '%m/%d/%Y');
	SET @UpdatedDateFrom2 = DATE_ADD(@UpdatedDateFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND help.UpdatedDate >=  ',  "'", @UpdatedDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND help.UpdatedDate <  ', "'", @UpdatedDateFrom2  ,"'");	
END IF;
END IF;


SET @querycount = CONCAT( 'SELECT count(*) into @cnt ', @queryFrom, @queryWhere );

-- select  @querycount;

PREPARE stmt1 FROM @querycount;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
	
SET @selectquery = CONCAT (@selectquery,', ', @cnt, ' as Count ');

SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );

if( @index = 'Order') then set  @index = 'help.`Order`';  end if;

-- HelpTypeName,Order,HelpDescription,UpdatedById,UpdatedDate
if(@index ='help.`Order`' or @index ='HelpTypeName' or @index ='HelpDescription'  or @index ='UpdatedDate' or @index ='HelpName' )then
SET @query = CONCAT(@query, ' order by ', @index,'  ', @sortOrder);
end if;



if( @Export ="false") then
SET @page = (@page - 1) * @limit;
SET @query = CONCAT(@query, ' LIMIT ', @limit ,' OFFSET ',  @page);

end if;

-- select  @query;


PREPARE stmt1 FROM @query;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 


END;
