CREATE PROCEDURE CommonDB.GetCompanyHistory(IN xmlData TEXT)
  BEGIN

SET @Orgid = extractvalue(xmlData, '//HistOrgId');

SET @page = extractvalue(xmlData, '//page');

SET @limit = extractvalue(xmlData, '//limit');

SET @sortOrder =  extractvalue(xmlData, '//sortOrder');

SET @index =  extractvalue(xmlData, '//index');

SET @Export =  extractvalue(xmlData, '//Export');

set @selectquery ="SELECT HistOrgId,OrgId,OrgName,Address,CityName,BillingCityName,date_format( UpdatedDate,'%m/%d/%Y') AS  UpdatedDate,BillingCountryName,
                    PostalCode,MailingAddress,Email,Discount,BillingContact,BillingPostalCode, OrgStatus,
                    BillingCycleUnite,BillingCycle,FirstBillingDate,LastBillingDate,SystemAdminName, HistoryOperationName  ";
                    
set @queryFrom = "  FROM hist_organization 
					join history_operation on history_operation.HistoryOperationId = hist_organization.HistoryOperationId ";

SET @queryWhere = '    where 1 = 1 ';

IF (@Orgid != '' AND @Orgid !='0') THEN
 	SET @queryWhere = CONCAT(@queryWhere,' and hist_organization.OrgId =  "', @Orgid,'" ');
 END IF;	

SET @myArrayOfValue = 'HistoryOperationName,OrgStatus,OrgName,Address,CityName,BillingCityName,PostalCode,MailingAddress,Email,Discount,BillingContact,BillingPostalCode,BillingCycleUnite,BillingCycle,SystemAdminName,';
                    

SET @Postition = LOCATE(',', @myArrayOfValue);

WHILE ( @Postition > 0 ) DO

 SET @STR = SUBSTRING(@myArrayOfValue, 1, @Postition-1);
 SET @myArrayOfValue = SUBSTRING(@myArrayOfValue, @Postition + 1);

 SET @Col =  extractvalue(xmlData, CONCAT('//',@STR));
 IF (@Col != '' AND @Col !='NULL') THEN

 
  SET @queryWhere = CONCAT(@queryWhere,CONCAT(' AND    ',@STR,'  like '"'%", @Col ,"%'")); 
 END IF;
 
 SET @Postition = LOCATE(',', @myArrayOfValue);
END WHILE;


SET @UpdatedDateFrom =  extractvalue(xmlData, '//UpdatedDateFrom');
SET @UpdatedDateTo =  extractvalue(xmlData, '//UpdatedDateTo');
IF(@UpdatedDateTo != '') THEN	
	SET @UpdatedDateTo  = STR_TO_DATE(@UpdatedDateTo , '%m/%d/%Y');
    SET @UpdatedDateFrom  = STR_TO_DATE(@UpdatedDateFrom , '%m/%d/%Y');
	SET @UpdatedDateTo2 = DATE_ADD(@UpdatedDateTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_organization.UpdatedDate >  ', "'" , @UpdatedDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_organization.UpdatedDate <=  ', "'",  @UpdatedDateTo2  ,"'" );										
ELSE 
IF(@UpdatedDateTo = '' AND @UpdatedDateFrom !='' ) THEN
	SET @UpdatedDateFrom  = STR_TO_DATE(@UpdatedDateFrom , '%m/%d/%Y');
	SET @UpdatedDateFrom2 = DATE_ADD(@UpdatedDateFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_organization.UpdatedDate >=  ',  "'", @UpdatedDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_organization.UpdatedDate <  ', "'", @UpdatedDateFrom2  ,"'");	
END IF;
END IF;


SET @LastBillingDateFrom =  extractvalue(xmlData, '//LastBillingDateFrom');
SET @LastBillingDateTo =  extractvalue(xmlData, '//LastBillingDateTo');
IF(@LastBillingDateTo != '') THEN	
	SET @LastBillingDateTo  = STR_TO_DATE(@LastBillingDateTo , '%m/%d/%Y');
    SET @LastBillingDateFrom  = STR_TO_DATE(@LastBillingDateFrom , '%m/%d/%Y');
	SET @LastBillingDateTo2 = DATE_ADD(@LastBillingDateTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_organization.LastBillingDate >  ', "'" , @LastBillingDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_organization.LastBillingDate <=  ', "'",  @LastBillingDateTo2  ,"'" );										
ELSE 
IF(@LastBillingDateTo = '' AND @LastBillingDateFrom !='' ) THEN
	SET @LastBillingDateFrom  = STR_TO_DATE(@LastBillingDateFrom , '%m/%d/%Y');
	SET @LastBillingDateFrom2 = DATE_ADD(@LastBillingDateFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_organization.LastBillingDate >=  ',  "'", @LastBillingDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_organization.LastBillingDate <  ', "'", @LastBillingDateFrom2  ,"'");	
END IF;
END IF;

SET @FirstBillingDateFrom =  extractvalue(xmlData, '//FirstBillingDateFrom');
SET @FirstBillingDateTo =  extractvalue(xmlData, '//FirstBillingDateTo');
IF(@FirstBillingDateTo != '') THEN	
	SET @FirstBillingDateTo  = STR_TO_DATE(@FirstBillingDateTo , '%m/%d/%Y');
    SET @FirstBillingDateFrom  = STR_TO_DATE(@FirstBillingDateFrom , '%m/%d/%Y');
	SET @FirstBillingDateTo2 = DATE_ADD(@FirstBillingDateTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_organization.FirstBillingDate >  ', "'" , @FirstBillingDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_organization.FirstBillingDate <=  ', "'",  @FirstBillingDateTo2  ,"'" );										
ELSE 
IF(@FirstBillingDateTo = '' AND @FirstBillingDateFrom !='' ) THEN
	SET @FirstBillingDateFrom  = STR_TO_DATE(@FirstBillingDateFrom , '%m/%d/%Y');
	SET @FirstBillingDateFrom2 = DATE_ADD(@FirstBillingDateFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_organization.FirstBillingDate >=  ',  "'", @FirstBillingDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_organization.FirstBillingDate <  ', "'", @FirstBillingDateFrom2  ,"'");	
END IF;
END IF;

 -- select  @queryWhere;

SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );

SET @querycount =  CONCAT( 'SELECT count(*) into @cnt from  (', @query, ' ) t');

PREPARE stmt1 FROM @querycount;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 


 SET @selectquery = CONCAT (@selectquery,', ', @cnt, ' as Count ');

SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );

SET @query = CONCAT(@query, ' order by ', @index,'  ', @sortOrder);

if( @Export ="false") then

SET @page = (@page - 1) * @limit;
SET @query = CONCAT(@query, ' LIMIT ', @limit ,' OFFSET ',  @page);

end if;


PREPARE stmt1 FROM @query;
EXECUTE stmt1;
-- select @query; 
END;
