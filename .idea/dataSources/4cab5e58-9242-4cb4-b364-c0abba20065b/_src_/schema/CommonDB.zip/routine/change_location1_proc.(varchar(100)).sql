CREATE PROCEDURE CommonDB.change_location1_proc(IN `$OrgId` VARCHAR(100))
  BEGIN
DECLARE $MaxLoc1, $MinLoc1, $Location2Id VARCHAR(100);
  
DECLARE EXIT HANDLER FOR SQLEXCEPTION
BEGIN
	/*SET @CurrState = RETURNED_SQLSTATE;
	SET @ErrDesc = MESSAGE_TEXT;
	SET @FullError = CONCAT('ERROR ', " (", @CurrState, "): ", @ErrDesc);
	SELECT @FullError;	*/
	SHOW ERRORS;
	ROLLBACK;
END;
DECLARE EXIT HANDLER FOR SQLWARNING
BEGIN
	/*SET @CurrState = RETURNED_SQLSTATE;
	SET @ErrDesc = MESSAGE_TEXT;
	SET @FullError = CONCAT('ERROR ', " (", @CurrState, "): ", @ErrDesc);
	SELECT @FullError;	*/
	SHOW ERRORS;
	ROLLBACK;
END;
SET autocommit=0;    
START TRANSACTION;

SET $MaxLoc1 = (SELECT MAX(Location1Id) FROM location1 WHERE OrgId = $OrgId AND Hide = 0);
SET $MinLoc1 = (SELECT MIN(Location1Id) FROM location1 WHERE OrgId = $OrgId AND Hide = 0);

BEGIN
Loc1Loop: WHILE $MinLoc1 <= $MaxLoc1
DO


	
	INSERT INTO location1
	(Location1Id, Location1Name, OrgId, `Order`, LastUpdateDate, EditingBy, Hide, OldId)
    SELECT 
    Location2Id, Location2Name, $OrgId, `Order`, LastUpdateDate, EditingBy, Hide, OldId
    FROM location2 
    WHERE Location1Id = $MinLoc1;
    
    
    INSERT INTO hist_location1
	(HistLocation1Id, Location1Id, Location1Name, OrgId, HistoryOperationId, UpdatedById, UpdatedDate, OldId)
    SELECT 
    MyUUID(), Location2Id, Location2Name, OrgId, HistoryOperationId, UpdatedById, UpdatedDate, OldId
    FROM hist_location2
    WHERE Location2Id IN (SELECT Location2Id FROM location2 WHERE Location2Id = $MinLoc1);
    
    UPDATE ABCanTrackV2.incident 
    SET Location1Id = Location2Id
    WHERE Location1Id = $MinLoc1;
    
    CALL `change_location2_proc`($MinLoc1);
    
	UPDATE location2 
    SET Location1Id = Location2Id
    WHERE Location1Id = $MinLoc1;
    
    DELETE FROM location1 WHERE Location1Id = $MinLoc1;
    
    IF $MinLoc1 = $MaxLoc1
    THEN
		LEAVE Loc1Loop;
	ELSE
		SET $MinLoc1 = (SELECT MIN(Location1Id) FROM location1 WHERE OrgId = $OrgId AND Hide = 0 AND Location1Id > $MinLoc1);
	END IF;
END WHILE;
END;
COMMIT;

END;
