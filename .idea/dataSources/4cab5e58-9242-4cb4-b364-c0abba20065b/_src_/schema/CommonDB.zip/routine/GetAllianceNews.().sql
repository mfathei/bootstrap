CREATE PROCEDURE CommonDB.GetAllianceNews()
  BEGIN

set @selectquery ="select NewsId, DATE_FORMAT(NewsDate, '%m/%d/%Y') AS NewsDate, NewsDate AS Date , NewsTitle,NewsDetails, IsActive  ";
set @queryFrom = " from news";

SET @queryWhere = CONCAT(' where  OrgId is Null ');

SET @queryWhere = CONCAT(@queryWhere, ' and IsActive = 1');

SET @querycount = CONCAT( 'SELECT count(*) into @cnt ', @queryFrom, @queryWhere );
PREPARE stmt1 FROM @querycount;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 



SET @selectquery = CONCAT (@selectquery,', ', @cnt, ' as Count ');

SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );

SET @query = CONCAT (@query, ' order by Date desc  ');


PREPARE stmt1 FROM @query;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 



END;
