CREATE PROCEDURE CommonDB.GetHelpTrainingTabs(IN xmlData TEXT)
  BEGIN
SET @page = EXTRACTVALUE(xmlData, '//page');
 
SET @limit = EXTRACTVALUE(xmlData, '//limit');
SET @sortOrder =  EXTRACTVALUE(xmlData, '//sortOrder');
SET @index =  EXTRACTVALUE(xmlData, '//index');
SET @Export =  EXTRACTVALUE(xmlData, '//Export');
SET @selectquery ="SELECT HelpTypeId, HelpTypeCode ,  HelpTypeName, MaterialType, `Order`";
                
SET @queryFrom = " from  help_type";
SET @queryWhere = ' where 1= 1 and IsCustom=0 and IsActive = 1  and  LanguageId= GetLanguageId('en')  ' ;
SET @myArrayOfValue = 'HelpTypeId,HelpTypeName,Order,';
SET @Postition = LOCATE(',', @myArrayOfValue);
WHILE ( @Postition > 0 ) DO
 SET @STR = SUBSTRING(@myArrayOfValue, 1, @Postition-1);
 SET @myArrayOfValue = SUBSTRING(@myArrayOfValue, @Postition + 1);
 SET @Col =  EXTRACTVALUE(xmlData, CONCAT('//',@STR));
 IF (@STR != '' AND @Col !='NULL') THEN
 -- if( @index = 'Order') then set  @STR = '`Order`';  end if;
  SET @queryWhere = CONCAT(@queryWhere,CONCAT(' AND    `',@STR,'` like '"'%", @Col ,"%'")); 
 END IF;
 
 SET @Postition = LOCATE(',', @myArrayOfValue);
END WHILE;
SET @MaterialType =  EXTRACTVALUE(xmlData, '//MaterialType');
IF (@MaterialType != '' AND @MaterialType !='NULL') THEN
	IF( @MaterialType  != '2' ) THEN 
		SET @queryWhere = CONCAT(@queryWhere,'  AND MaterialType like "', @MaterialType ,'"');  
	END IF;	
END IF;
SET @querycount = CONCAT( 'SELECT count(*) into @cnt ', @queryFrom, @queryWhere );
PREPARE stmt1 FROM @querycount;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
	
SET @selectquery = CONCAT (@selectquery,', ', @cnt, ' as Count ');
SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );
IF( @index = 'Order') THEN SET  @index = '`Order`';  END IF;
IF(@index ='`Order`' OR @index ='HelpTypeName')THEN
SET @query = CONCAT(@query, ' order by ', @index,'  ', @sortOrder);
END IF;
IF( @Export ="false") THEN
SET @page = (@page - 1) * @limit;
SET @query = CONCAT(@query, ' LIMIT ', @limit ,' OFFSET ',  @page);
END IF;
-- select  @query;
PREPARE stmt1 FROM @query;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
END;
