CREATE FUNCTION CommonDB.GetProvinceId(`$ProvinceName` VARCHAR(255))
  RETURNS VARCHAR(100)
  BEGIN
set @prov_id = (select province.ProvinceId from CommonDB.province where ProvinceName=$ProvinceName);

RETURN @prov_id;
END;
