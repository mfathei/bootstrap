CREATE PROCEDURE CommonDB.ins_org_analysis_params(IN `$OldObserAndAnalId` VARCHAR(100),
                                                  IN `$NewObserAndAnalId` VARCHAR(100), IN `$LangId` VARCHAR(100))
  BEGIN
DECLARE p_finished INTEGER DEFAULT 0;
DECLARE $pcode, $pid ,$NewId VARCHAR(255);
 DECLARE p_cursor CURSOR FOR
 select op.ObservationAndAnalysisParamId,op.FieldCode from `ABCanTrackV2`.`observation_analysis_param` op
 WHERE op.ObservationAndAnalysisId = $OldObserAndAnalId AND ParentId IS NULL AND op.LanguageId = $LangId;

 -- declare NOT FOUND handler
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET p_finished = 1;
    
 open p_cursor;

-- FETCH g_p_cursor INTO $gid , $fcode, $pcode, $pid;

ex: LOOP
	FETCH p_cursor INTO $pid ,$pcode;

	IF p_finished = 1 THEN 
		LEAVE ex;
	END IF;

-- select $fcode,$pcode;

INSERT INTO `ABCanTrackV2`.`observation_analysis_param`
	(
		`ObservationAndAnalysisParamId`,
        `FieldCode`,
	    `LanguageId`,
		`ObservationAndAnalysisId`,
		`ObservationAndAnalysisParamName`,
		`ObservationAndAnalysisParamDetails`,
		`Order`,
		`IsMulti`,
		`ParentId`,
		`LastUpdateDate`,
		`EditingBy`,
		`Hide`
	)
	SELECT
		'',
        `FieldCode`,
	    $LangId,
		$NewObserAndAnalId,
		`ObservationAndAnalysisParamName`,
		`ObservationAndAnalysisParamDetails`,
		`Order`,
		`IsMulti`,
		`ParentId`,
		CURRENT_TIMESTAMP(),
		`EditingBy`,
		`Hide`
	FROM  `ABCanTrackV2`.`observation_analysis_param`
	WHERE ObservationAndAnalysisParamId = $pid AND `ParentId` IS NULL AND LanguageId = $LangId;

	SET $NewId = (select op.ObservationAndAnalysisParamId from `ABCanTrackV2`.`observation_analysis_param` op WHERE op.ObservationAndAnalysisId = $NewObserAndAnalId AND ParentId IS NULL AND op.FieldCode=$pcode AND op.LanguageId = $LangId);
 
	CALL ins_org_analysis_params_chld($pid,$NewId,$NewObserAndAnalId,$LangId);

END LOOP ex;

CLOSE p_cursor;

END;
