CREATE PROCEDURE CommonDB.InsertMissingCustomFieldsData(IN `$OrgId` VARCHAR(100))
  BEGIN
DECLARE $FieldId, $OptionId VARCHAR(100);
DECLARE $Label VARCHAR(255);
IF EXISTS (SELECT PersonInvolvedSafetyOrientationId  FROM ABCanTrackV1.IncidentPersonInvolved WHERE IncidentId in (SELECT IncidentId FROM ABCanTrackV1.Incident WHERE CompanyId = $OrgId))
THEN
	SET $FieldId = (SELECT FieldId FROM ABCanTrackV2.field WHERE OrgId = $OrgId AND FieldName = 'People_select_0');
	SET $Label 	 = (SELECT DefaultFieldLabel FROM ABCanTrackV2.field WHERE FieldId = $FieldId);

			INSERT INTO `MigrationDB`.`LogTable`
			(`OrgId`,
			`TableId`,
			`TableName`,
			`Comment`)
			VALUES
			($OrgId,
			$FieldId,
			$Label, 
			'Safety Orientation history');

	INSERT INTO `ABCanTrackV2`.`hist_field_value`
		(
			`HistFieldValueId`,
			`FieldValueId`,
			`IncidentId`,
			`FieldId`,
			`OptionName`,
			`HistIncidentId`,
			`FieldValue`,
			`TableKeyValue`,
			`TableKeyId`,
			`HistoryOperationId`,
			`UpdatedById`
		)
	SELECT 

			MyUUID(),
			MyUUID(),
			tbl2.IncidentId,
			$FieldId,
			PersonInvolvedSafetyOrientationId,
			tbl2.HistIncidentId,
			NULL,
			'people_involved',
			PersonInvolvedId,
			tbl2.HistoryOperationId,
			tbl2.UpdatedById
	FROM ABCanTrackV1.Incident tbl1 
	INNER JOIN ABCanTrackV2.hist_incident tbl2
	ON tbl1.IncidentId = tbl2.HistIncidentId 
	INNER JOIN ABCanTrackV1.IncidentPersonInvolved tbl3
	on tbl1.IncidentId = tbl3.IncidentId
	WHERE OrgId = $OrgId AND PersonInvolvedSafetyOrientationId IS NOT NULL 
    and tbl1.IncidentId not in (select HistIncidentId from ABCanTrackV2.hist_field_value WHERE fieldid = $FieldId);
END IF;
END;
