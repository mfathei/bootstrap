CREATE PROCEDURE CommonDB.change_location3_proc(IN `$Location2Id` VARCHAR(200))
  BEGIN
DECLARE $MaxLoc3, $MinLoc3 VARCHAR(200);
  

SET $MaxLoc3 = (SELECT MAX(Location3Id) FROM location3 WHERE Location2Id = $Location2Id AND Hide = 0);
SET $MinLoc3 = (SELECT MIN(Location3Id) FROM location3 WHERE Location2Id = $Location2Id AND Hide = 0);

BEGIN
Loc3Loop: WHILE $MinLoc3 <= $MaxLoc3
DO
	INSERT INTO location3
	(Location3Id, Location3Name, `Order`, LastUpdateDate, EditingBy, Hide, OldId)
    SELECT 
    Location4Id, Location4Name, `Order`, LastUpdateDate, EditingBy, Hide, OldId
    FROM location4
    WHERE Location3Id = $MinLoc3;
    
    INSERT INTO hist_location3
	(HistLocation3Id, Location3Id, Location3Name, Location2Name, Location1Name, OrgId, HistoryOperationId, UpdatedById, UpdatedDate, OldId)
    SELECT 
    MyUUID(), Location4Id, Location4Name, Location3Name, Location2Name, OrgId, HistoryOperationId, UpdatedById, UpdatedDate, OldId
    FROM hist_location4
    WHERE Location4Id IN (SELECT Location4Id FROM location4 WHERE Location3Id = $MinLoc3);
    
    UPDATE ABCanTrackV2.incident 
    SET Location3Id = Location4Id
    WHERE Location3Id = $MinLoc3;
    
    UPDATE ABCanTrackV2.incident 
    SET Location4Id = NULL
    WHERE Location4Id IN (SELECT Location4Id FROM location4 WHERE Location3Id = $MinLoc3);
	    
    DELETE FROM location4 WHERE Location3Id = $MinLoc3;
    
    DELETE FROM location3 WHERE Location3Id = $MinLoc3;
    DELETE FROM hist_location3 WHERE Location3Id = $MinLoc3;
    
	IF $MinLoc3 = $MaxLoc3
	THEN
		LEAVE Loc3Loop;
	ELSE
		SET $MinLoc3 = (SELECT MIN(Location3Id) FROM location3 WHERE Location2Id = $Location2Id AND Hide = 0 AND Location3Id > $MinLoc3);
    END IF;
END WHILE;

END ;

END;
