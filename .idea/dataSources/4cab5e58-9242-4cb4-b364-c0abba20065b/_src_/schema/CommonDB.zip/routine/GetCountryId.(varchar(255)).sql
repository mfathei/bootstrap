CREATE FUNCTION CommonDB.GetCountryId(`$CountryName` VARCHAR(255))
  RETURNS VARCHAR(100)
  BEGIN
set @prov_id = (select country.CountryId from CommonDB.country where CountryName=$CountryName);

RETURN @prov_id;
END;
