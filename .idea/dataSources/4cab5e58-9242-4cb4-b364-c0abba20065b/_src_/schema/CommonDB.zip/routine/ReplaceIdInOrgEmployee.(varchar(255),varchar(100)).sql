CREATE PROCEDURE CommonDB.ReplaceIdInOrgEmployee(IN `$mail` VARCHAR(255), IN `$empId` VARCHAR(100))
  BEGIN
	DECLARE vEmpId, vOrgId VARCHAR(100);
	DECLARE finished INT DEFAULT 0;
	DECLARE e_cursor CURSOR FOR
    SELECT EmployeeId,OrgId FROM org_employee
    WHERE EmployeeId IN (SELECT EmployeeId FROM CommonDB.employee WHERE Email=$mail AND EmployeeId <> $empId);
    
    DECLARE CONTINUE HANDLER FOR NOT FOUND
		SET finished = 1;
       
	SET @found = NULL;
	OPEN e_cursor;
    
    ex : LOOP 
    
		FETCH e_cursor INTO vEmpId, vOrgId;
    
		IF finished = 1 THEN
			LEAVE ex;
        END IF;
        
        SET @found = (SELECT EmployeeId FROM org_employee WHERE EmployeeId = $empId AND OrgId = vOrgId);
        
        IF @found IS NULL THEN
			UPDATE `org_employee` SET EmployeeId = $empId WHERE EmployeeId = vEmpId AND OrgId = vOrgId;
		ELSE
			DELETE FROM org_employee WHERE EmployeeId = vEmpId AND OrgId = vOrgId;
        END IF;
        
        UPDATE `CommonDB`.`org_employee` SET SupervisorId = $empId WHERE `SupervisorId` = vEmpId;
    END LOOP ex;
	CLOSE e_cursor;
	
END;
