CREATE PROCEDURE CommonDB.import_location3_proc(IN `$OrgId`              VARCHAR(100), IN `$UpdatedById` VARCHAR(100),
                                                IN `$HistoryOperationId` VARCHAR(100))
  BEGIN

UPDATE import_location tbl1
INNER JOIN location3 tbl2
ON tbl1.Location3Name = tbl2.Location3Name AND tbl1.Location2Id = tbl2.Location2Id -- AND tbl1.OrgId = $OrgId
SET tbl1.Location3Id = tbl2.Location3Id
WHERE tbl1.OrgId = $OrgId;

INSERT INTO location3
	(Location3Name, Location2Id)
SELECT DISTINCT
	 Location3Name, Location2Id
FROM import_location 
WHERE OrgId = $OrgId AND Location3Id IS NULL; 

INSERT INTO `CommonDB`.`hist_location3`
(
	`Location3Id`,
	`Location3Name`,
	`Location2Name`,
	`Location1Name`,
	`OrgId`,
	`HistoryOperationId`,
	`UpdatedById`,
	`UpdatedDate`
)
SELECT DISTINCT 
	tbl2.`Location3Id`,
	tbl2.`Location3Name`,
	tbl1.`Location2Name`,
	tbl1.`Location1Name`,
	$OrgId,
	$HistoryOperationId,
	$UpdatedById,
	CURRENT_TIMESTAMP
FROM import_location tbl1
INNER JOIN location3 tbl2
ON tbl1.Location3Name = tbl2.Location3Name AND tbl1.Location2Id = tbl2.Location2Id
WHERE tbl1.OrgId = $OrgId
AND tbl1.Location3Id IS NULL;

UPDATE import_location tbl1
INNER JOIN location3 tbl2
ON tbl1.Location3Name = tbl2.Location3Name AND tbl1.Location2Id = tbl2.Location2Id -- AND tbl1.OrgId = $OrgId
SET tbl1.Location3Id = tbl2.Location3Id
WHERE tbl1.OrgId = $OrgId;

END;
