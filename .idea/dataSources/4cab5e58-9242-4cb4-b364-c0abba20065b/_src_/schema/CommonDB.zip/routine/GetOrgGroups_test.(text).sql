CREATE PROCEDURE CommonDB.GetOrgGroups_test(IN xmlData TEXT)
  BEGIN
SET @Orgid = extractvalue(xmlData, '//OrgId');
SET @page = extractvalue(xmlData, '//page');
SET @limit = extractvalue(xmlData, '//limit');
SET @sortOrder =  extractvalue(xmlData, '//sortOrder');
SET @index =  extractvalue(xmlData, '//index');
SET @Export =  extractvalue(xmlData, '//Export');
SET @LanguageCode =  extractvalue(xmlData, '//LanguageCode');
SET @lblActive = (select GetItemLabel(@LanguageCode,'active'));
SET @lblInactive = (select GetItemLabel(@LanguageCode,'inactive'));
set @selectquery =CONCAT('  SELECT distinct `group`.GroupId, `group`.OrgId, GroupName, Description,
					CASE `group`.IsActive  WHEN '0' THEN '',@lblInactive,'' WHEN '1' THEN '', @lblActive,'' END AS IsActive, 
					CreationDate, ( SELECT GROUP_CONCAT( DISTINCT CONCAT(FirstName , ' ', LastName) SEPARATOR ', ')
								FROM employee  	
								inner join emp_group on emp_group.EmployeeId= employee.EmployeeId 	
                                inner join org_employee oe on oe.EmployeeId= employee.EmployeeId  
                                and oe.EmpIsActive =1  and `oe`.OrgId =   "', @Orgid,'"
								WHERE employee.EmployeeId = emp_group.EmployeeId and emp_group.GroupId = `group`.GroupId  
								GROUP BY `group`.GroupId  ) as GroupMember');
set @queryFrom = ' from `group` 			
		 	 left outer join emp_group on emp_group.GroupId= `group`.GroupId   
			 left outer join  employee on employee.EmployeeId= emp_group.EmployeeId 
              inner join org_employee oe on oe.EmployeeId= employee.EmployeeId
              
              ';
SET @queryWhere = ' where 1 = 1  ';
IF (@Orgid != '' AND @Orgid !='0') THEN
	SET @queryWhere = CONCAT(@queryWhere,' and `group`.OrgId =   "', @Orgid,'" ');
END IF;	
SET @GroupName =  extractvalue(xmlData, '//GroupName');
IF (@GroupName != '' AND @GroupName !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,'  AND GroupName like('"'%", @GroupName ,"%'"')');	
END IF;
SET @Description =  extractvalue(xmlData, '//Description');
IF (@Description != '' AND @Description !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,'  AND Description like('"'%", @Description ,"%'"')');	
END IF;
SET @CreationDateFrom =  extractvalue(xmlData, '//CreationDateFrom');
SET @CreationDateTo =  extractvalue(xmlData, '//CreationDateTo');
IF(@CreationDateTo != '') THEN
	SET @CreationDateTo  = STR_TO_DATE(@CreationDateTo , '%m/%d/%Y');
	SET @CreationDateTo2 = DATE_ADD(@CreationDateTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND CreationDate >  ', "'" , @CreationDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND CreationDate <=  ', "'",  @CreationDateTo2  ,"'" );										
ELSE 
IF(@CreationDateTo = '' AND @CreationDateFrom !='' ) THEN
	SET @CreationDateFrom  = STR_TO_DATE(@CreationDateFrom , '%m/%d/%Y');
-- 	SET @CreationDateFrom2 = DATE_ADD(@CreationDateFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND CreationDate >=  ',  "'", @CreationDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND CreationDate <  ', "'", @CreationDateFrom2  ,"'");	
END IF;
END IF;	
SET @IsActive =  extractvalue(xmlData, '//IsActive');
IF (@IsActive != '' AND @IsActive !='NULL') THEN
	/*IF( @IsActive  != '2' ) THEN 
		SET @queryWhere = CONCAT(@queryWhere,'  AND  `group`.IsActive = ',  @IsActive ); 
	END IF;	*/
    
    	IF( @IsActive  = '1' ) THEN 
			SET @queryWhere = CONCAT(@queryWhere,'  AND  `group`.IsActive = ',  @IsActive ); 
			SET @queryWhere = CONCAT(@queryWhere,'  AND emp_group.IsActive = ',  @IsActive ); 
            SET @queryWhere = CONCAT(@queryWhere,'  AND oe.EmpIsActive = ',  @IsActive ); 
        ELSEIF( @IsActive  = '0' ) THEN
        SET @queryWhere = CONCAT(@queryWhere,'  AND  `group`.IsActive = ',  @IsActive ); 
			-- SET @queryWhere = CONCAT(@queryWhere,'  AND ( `group`.IsActive = ',  @IsActive ); 
          --  SET @queryWhere = CONCAT(@queryWhere,'  AND oe.EmpIsActive = ',  @IsActive ); 
		--	SET @queryWhere = CONCAT(@queryWhere,'  OR emp_group.IsActive = ',  @IsActive,')  ' ); 
	END IF;
    
END IF; 
SET @GroupMember =  extractvalue(xmlData, '//GroupMember');
IF (@GroupMember != '' AND @GroupMember !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,'  AND   (CONCAT(FirstName , " ", LastName) like('"'%",@GroupMember,"%'"'))');									
END IF;	
 SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );
-- SET @querycount = CONCAT( 'SELECT count(*) into @cnt ', @queryFrom, @queryWhere );
SET @querycount =  CONCAT( 'SELECT count(*) into @cnt from  (', @query, ' ) t');
PREPARE stmt1 FROM @querycount;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
SET @selectquery = CONCAT (@selectquery,', ', @cnt, ' as Count ');
SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );
SET @query = CONCAT(@query, ' group by `group`.GroupId  order by ', @index,'  ', @sortOrder);
if( @Export ="false") then
	SET @page = (@page - 1) * @limit;
	SET @query = CONCAT(@query, ' LIMIT ', @limit ,' OFFSET ',  @page);
end if;
select @query; 
PREPARE stmt1 FROM @query;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
-- select @query; 
END;
