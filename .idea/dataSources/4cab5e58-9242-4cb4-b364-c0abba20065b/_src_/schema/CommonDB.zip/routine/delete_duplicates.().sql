CREATE PROCEDURE CommonDB.delete_duplicates()
  BEGIN
DECLARE $Min, $Max/*, $role_name*/ , $Province VARCHAR(100);
DECLARE $City VARCHAR(255);
DECLARE $limit_var INT;
SET $Min = (SELECT MIN(id) FROM _CDuplicates);
SET $Max = (SELECT MAX(id) FROM _CDuplicates);
DelLoop: WHILE $Min <= $Max
DO
	SET $Province = (SELECT Province FROM CityProvince WHERE id = $Min);
	SET $City = (SELECT City FROM CityProvince WHERE id = $Min);

	IF (SELECT COUNT(id) FROM CityProvince WHERE Province = $Province AND City = $City) > 1
	THEN
		-- SET $role_name = (SELECT role_name FROM _duplicate_accorg WHERE accountholder_id = $Min);
		SET $limit_var = (SELECT COUNT(id) FROM CityProvince WHERE Province = $Province AND City = $City /*AND role_name = $role_name*/ ) - 1;
		
		DELETE FROM CityProvince
		WHERE Province = $Province AND City = $City
		LIMIT $limit_var;
		
		/*
		UPDATE _duplicate_accorg
		SET IsDone = 1,
			limit_var = $limit_var
		WHERE accountholder_id = $Min;
		*/
		IF $Min = $Max
		THEN
			LEAVE DelLoop;
		ELSE
			SET $Min = (SELECT MIN(id) FROM _CDuplicates WHERE id > $Min);
		END IF;
	END IF;
END WHILE;
END;
