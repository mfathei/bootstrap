CREATE PROCEDURE CommonDB.GetGroupUsers(IN xmlData TEXT)
  BEGIN
SET @GroupId = extractvalue(xmlData, '//GroupId');
SET @Orgid = extractvalue(xmlData, '//OrgId');
SET @page = extractvalue(xmlData, '//page');
SET @limit = extractvalue(xmlData, '//limit');
SET @sortOrder =  extractvalue(xmlData, '//sortOrder');
SET @index =  extractvalue(xmlData, '//index');
SET @Export =  extractvalue(xmlData, '//Export');
SET @LanguageCode =  extractvalue(xmlData, '//LanguageCode');
SET @lblActive = (select GetItemLabel(@LanguageCode,'active'));
SET @lblInactive = (select GetItemLabel(@LanguageCode,'inactive'));
set @selectquery =concat(' select distinct employee.EmployeeId, concat(FirstName," " , LastName) as FullName, 
					CASE emp_group.IsActive  when '0' then '',@lblInactive,'' when '1' then '', @lblActive,'' END  AS IsActive
					, emp_group.AssignToGroupDate ');
set @queryFrom = '  from employee
					inner join emp_group on emp_group.EmployeeId = employee.EmployeeId
					inner join `group` on emp_group.GroupId = `group`.GroupId  ';
SET @queryWhere = ' where 1 = 1 ';
IF (@GroupId != '' AND @GroupId !='0') THEN
	SET @queryWhere = CONCAT(@queryWhere,' and emp_group.GroupId = "', @GroupId,'"');
END IF;	
/* search part */
SET @IsActive =  extractvalue(xmlData, '//IsActive');
IF (@IsActive != '' AND @IsActive !='NULL') THEN
	IF( @IsActive  != '2' ) THEN 
		SET @queryWhere = CONCAT(@queryWhere,'  AND emp_group.IsActive = ',  @IsActive ); 
	END IF;	
END IF;
SET @AssignToGroupDateFrom =  extractvalue(xmlData, '//AssignToGroupDateFrom');
SET @AssignToGroupDateTo =  extractvalue(xmlData, '//AssignToGroupDateTo');
IF(@AssignToGroupDateTo != '') THEN
	
	SET @AssignToGroupDateTo  = STR_TO_DATE(@AssignToGroupDateTo , '%m/%d/%Y');
	SET @AssignToGroupDateTo2 = DATE_ADD(@AssignToGroupDateTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND emp_group.AssignToGroupDate >  ', "'" , @AssignToGroupDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND emp_group.AssignToGroupDate <=  ', "'",  @AssignToGroupDateTo2  ,"'" );										
ELSE 
IF(@AssignToGroupDateTo = '' AND @AssignToGroupDateFrom !='' ) THEN
	SET @AssignToGroupDateFrom  = STR_TO_DATE(@AssignToGroupDateFrom , '%m/%d/%Y');
	SET @AssignToGroupDateFrom2 = DATE_ADD(@AssignToGroupDateFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND emp_group.AssignToGroupDate >=  ',  "'", @AssignToGroupDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND emp_group.AssignToGroupDate <  ', "'", @AssignToGroupDateFrom2  ,"'");	
END IF;
END IF;
SET @FullName =  extractvalue(xmlData, '//FullName');
IF (@FullName != '' AND @FullName !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,'  AND  CONCAT (FirstName', ' ,','LastName)',' like('"'%", @FullName ,"%'"')');	
END IF;	
SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );
SET @querycount = CONCAT( 'SELECT count(*) into @cnt ', @queryFrom, @queryWhere );
PREPARE stmt1 FROM @querycount;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
SET @selectquery = CONCAT (@selectquery,', ', @cnt, ' as Count ');
SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );
SET @query = CONCAT(@query, ' order by ', @index,'  ', @sortOrder);
if( @Export ="false") then
SET @page = (@page - 1) * @limit;
SET @query = CONCAT(@query, ' LIMIT ', @limit ,' OFFSET ',  @page);
end if;
-- select @query; 
PREPARE stmt1 FROM @query;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
END;
