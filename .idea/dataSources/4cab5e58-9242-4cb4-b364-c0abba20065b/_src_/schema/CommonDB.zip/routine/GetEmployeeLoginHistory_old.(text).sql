CREATE PROCEDURE CommonDB.GetEmployeeLoginHistory_old(IN xmlData TEXT)
  BEGIN

SET @Orgid = extractvalue(xmlData, '//OrgId');

SET @page = extractvalue(xmlData, '//page');

SET @limit = extractvalue(xmlData, '//limit');

SET @sortOrder =  extractvalue(xmlData, '//sortOrder');

SET @index =  extractvalue(xmlData, '//index');

SET @EmpLoginHistoryId =  extractvalue(xmlData, '//EmpLoginHistoryId');

SET @Export =  extractvalue(xmlData, '//Export');

set @selectquery =" select login_history.LogInHistoryId, login_history.EmployeeId, UserName, FirstName, LastName, OrgName, Login, Logout, LoginStatus, LogoutStatus";

set @queryFrom = " from login_history
					inner join employee  on login_history.EmployeeId = employee.EmployeeId
					inner join org_employee on org_employee.EmployeeId = employee.EmployeeId
					inner join organization on organization.OrgId = org_employee.OrgId ";

SET @queryWhere = ' where 1= 1 ';

IF (@Orgid != '' AND @Orgid !='0') THEN
	SET @queryWhere = CONCAT(@queryWhere,' and organization.OrgId =  "', @Orgid,'" ');
END IF;	

IF (@EmpLoginHistoryId != '' AND @EmpLoginHistoryId !='0') THEN
	SET @queryWhere = CONCAT(@queryWhere,' and login_history.EmployeeId = "', @EmpLoginHistoryId,'"');
END IF;	

/* search part */
SET @FirstName =  extractvalue(xmlData, '//FirstName');
IF (@FirstName != '' AND @FirstName !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,'  AND  FirstName like('"'%", @FirstName ,"%'"')');	
END IF;	

SET @LastName =  extractvalue(xmlData, '//LastName');
IF (@LastName != '' AND @LastName !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,'  AND  LastName like('"'%", @LastName ,"%'"')');	
END IF;	

SET @UserName =  extractvalue(xmlData, '//UserName');
IF (@UserName != '' AND @UserName !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,'  AND  UserName like('"'%", @UserName ,"%'"')');	
END IF;	

SET @OrgName =  extractvalue(xmlData, '//OrgName');
IF (@OrgName != '' AND @OrgName !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,'  AND  OrgName like('"'%", @OrgName ,"%'"')');	
END IF;	

SET @LoginStatus =  extractvalue(xmlData, '//LoginStatus');
IF (@LoginStatus != '' AND @LoginStatus !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,'  AND  LoginStatus like('"'%", @LoginStatus ,"%'"')');	
END IF;	

SET @LogoutStatus =  extractvalue(xmlData, '//LogoutStatus');
IF (@LogoutStatus != '' AND @LogoutStatus !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,'  AND  LogoutStatus like('"'%", @LogoutStatus ,"%'"')');	
END IF;	



SET @LoginFrom =  extractvalue(xmlData, '//LoginFrom');
SET @LoginTo =  extractvalue(xmlData, '//LoginTo');


IF(@LoginTo != '') THEN
	
	SET @LoginTo  = STR_TO_DATE(@LoginTo , '%m/%d/%Y');
	SET @LoginTo2 = DATE_ADD(@LoginTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND login_history.Login >  ', "'" , @LoginFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND login_history.Login <=  ', "'",  @LoginTo2  ,"'" );										
ELSE 
IF(@LoginTo = '' AND @LoginFrom !='' ) THEN

	SET @LoginFrom  = STR_TO_DATE(@LoginFrom , '%m/%d/%Y');
	SET @LoginFrom2 = DATE_ADD(@LoginFrom ,INTERVAL 1 DAY) ;

	SET @queryWhere = CONCAT(@queryWhere,'  AND login_history.Login >=  ',  "'", @LoginFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND login_history.Login <  ', "'", @LoginFrom2  ,"'");	
END IF;

END IF;


SET @LogoutFrom =  extractvalue(xmlData, '//LogoutFrom');
SET @LogoutTo =  extractvalue(xmlData, '//LogoutTo');


IF(@LogoutTo != '') THEN
	
	SET @LogoutTo  = STR_TO_DATE(@LogoutTo , '%m/%d/%Y');
	SET @LogoutTo2 = DATE_ADD(@LogoutTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND login_history.Logout >  ', "'" , @LogoutFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND login_history.Logout <=  ', "'",  @LogoutTo2  ,"'" );										
ELSE 
IF(@LogoutTo = '' AND @LogoutFrom !='' ) THEN

	SET @LogoutFrom  = STR_TO_DATE(@LogoutFrom , '%m/%d/%Y');
	SET @LogoutFrom2 = DATE_ADD(@LogoutFrom ,INTERVAL 1 DAY) ;

	SET @queryWhere = CONCAT(@queryWhere,'  AND login_history.Logout >=  ',  "'", @LogoutFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND login_history.Logout <  ', "'", @LogoutFrom2  ,"'");	
END IF;

END IF;

/* end of search */

SET @querycount = CONCAT( 'SELECT count(*) into @cnt ', @queryFrom, @queryWhere );
PREPARE stmt1 FROM @querycount;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 


SET @selectquery = CONCAT (@selectquery,', ', @cnt, ' as Count ');

SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );

SET @query = CONCAT(@query, ' order by ', @index,'  ', @sortOrder);

if( @Export ="false") then

SET @page = (@page - 1) * @limit;
SET @query = CONCAT(@query, ' LIMIT ', @limit ,' OFFSET ',  @page);

end if;

-- select @query ; 

PREPARE stmt1 FROM @query;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 

END;
