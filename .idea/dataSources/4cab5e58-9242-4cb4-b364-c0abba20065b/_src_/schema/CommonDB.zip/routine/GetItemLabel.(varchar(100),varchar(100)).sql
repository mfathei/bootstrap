CREATE FUNCTION CommonDB.GetItemLabel(`$LanguageCode` VARCHAR(100), `$AlertMessageCode` VARCHAR(100))
  RETURNS VARCHAR(100)
  BEGIN

SET @ItemLabel = (SELECT AlertMessageDescription FROM alert_message
join `language` on `language`.LanguageId = alert_message.LanguageId
where AlertMessageCode=$AlertMessageCode and LanguageCode=$LanguageCode);

RETURN @ItemLabel;
END;
