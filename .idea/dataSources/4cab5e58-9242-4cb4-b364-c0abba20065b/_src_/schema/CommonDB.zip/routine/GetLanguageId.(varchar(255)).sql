CREATE FUNCTION CommonDB.GetLanguageId(`$LanguageCode` VARCHAR(255))
  RETURNS VARCHAR(100)
  BEGIN
set @lang_id = (select language.LanguageId from CommonDB.language where LanguageCode=$LanguageCode );
RETURN @lang_id;
END;
