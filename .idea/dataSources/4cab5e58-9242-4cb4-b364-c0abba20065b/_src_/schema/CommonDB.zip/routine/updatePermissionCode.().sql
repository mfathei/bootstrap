CREATE PROCEDURE CommonDB.updatePermissionCode()
  BEGIN
  DECLARE done INT DEFAULT FALSE;
  DECLARE indx INTEGER;
  DECLARE id VARCHAR(100);
  DECLARE abcantrackid VARCHAR(100);

  DECLARE pid VARCHAR(100);
  DECLARE txt VARCHAR(255);
  DECLARE pcode VARCHAR(255);
  DECLARE ename VARCHAR(255);
  DECLARE cur1 CURSOR FOR SELECT r.PermissionId,r.ProductId,r.PermissionCode,LOWER(REPLACE(SUBSTR(IFNULL(r.PermissionName,''),1,99),' ',''))
  FROM `CommonDB`.permission r
  LEFT JOIN `CommonDB`.product d
  ON (r.productId=d.productId)
  ORDER BY r.PermissionName;-- very important
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

  OPEN cur1;

    SET indx = 1;
    SET abcantrackid = (SELECT ProductId FROM `CommonDB`.product WHERE productCode='ABCanTrack');

  READ_LOOP: LOOP
    FETCH cur1 INTO id,pid,pcode,ename;
    IF done THEN
      LEAVE READ_LOOP;
    END IF;
    
    IF (ename = txt) THEN
        SET ename = CONCAT(ename,CONVERT(indx,CHAR(50)));
        SET indx = indx + 1;
    ELSE
        SET txt = ename;
    END IF;
    
    IF (pid != abcantrackid) OR (pcode = '') THEN
        UPDATE `CommonDB`.permission SET permission.PermissionCode=ename WHERE permission.PermissionId=id;
    END IF;
    
  END LOOP;

  CLOSE cur1;
END;
