CREATE PROCEDURE CommonDB.ActiveUserCount(IN `$OrgId` VARCHAR(100))
  BEGIN


set @query = "select distinct employee.EmployeeId, concat(FirstName,' ' , LastName) as FullName, 
					employee.UserName, GroupName, 
					CASE org_employee.IsActive WHEN '0' THEN 'Inactive' WHEN '1' THEN 'Active' END AS IsActive
					, org_employee.AssignToGroupDate, 
					( SELECT MAX(Login)FROM login_history
					WHERE login_history.EmployeeId  = employee.EmployeeId) as Login 

from employee
					inner join org_employee on org_employee.EmployeeId = employee.EmployeeId
					inner join `group` on `group`.GroupId = org_employee.GroupId 					
					inner join org_prod_employee on org_prod_employee.EmployeeId = org_employee.EmployeeId and  org_employee.OrgId = org_prod_employee.OrgId
					inner join product_version on product_version.ProductVersionId = org_prod_employee.ProductVersionId									
					left outer join login_history on login_history.EmployeeId = employee.EmployeeId

";

SET @query =  CONCAT(@query, ' where org_employee.EmpIsActive = 1 AND org_employee.IsActive = 1 and org_employee.OrgId =  ',$OrgId); 

SET @querycount =  CONCAT( 'SELECT count(*) as ActiveCount from  (', @query, ' ) t');

PREPARE stmt1 FROM @querycount;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 


 -- select ActiveCount ;

END;
