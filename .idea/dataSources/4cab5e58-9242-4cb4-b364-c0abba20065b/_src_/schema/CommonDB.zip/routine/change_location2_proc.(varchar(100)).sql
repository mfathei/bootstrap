CREATE PROCEDURE CommonDB.change_location2_proc(IN `$Location1Id` VARCHAR(100))
  BEGIN
DECLARE $MaxLoc2, $MinLoc2 VARCHAR(100);
  
SET $MaxLoc2 = (SELECT MAX(Location2Id) FROM location2 WHERE Location1Id = $Location1Id AND Hide = 0);
SET $MinLoc2 = (SELECT MIN(Location2Id) FROM location2 WHERE Location1Id = $Location1Id AND Hide = 0);
Loc2Loop: WHILE $MinLoc2 <= $MaxLoc2
DO
	INSERT INTO location2
	(Location2Id, Location2Name, Location1Id, `Order`, LastUpdateDate, EditingBy, Hide, OldId)
    SELECT 
    Location3Id, Location3Name, $MinLoc2, `Order`, LastUpdateDate, EditingBy, Hide, OldId
    FROM location3 
    WHERE Location2Id = $MinLoc2;
    

    INSERT INTO hist_location2
	(HistLocation2Id, Location2Id, Location2Name, Location1Name, OrgId, HistoryOperationId, UpdatedById, UpdatedDate, OldId)
    SELECT 
    MyUUID(), Location3Id, Location3Name, Location2Name, OrgId, HistoryOperationId, UpdatedById, UpdatedDate, OldId
    FROM hist_location3
    WHERE Location3Id IN (SELECT Location3Id FROM location3 WHERE Location2Id = $MinLoc2);
select $MinLoc2;    

    UPDATE ABCanTrackV2.incident
    SET Location2Id = Location3Id 
    WHERE Location2Id = $MinLoc2;
    
    CALL `change_location3_proc`($MinLoc2);
    
	UPDATE location3
    SET Location2Id = Location3Id
    WHERE Location2Id = $MinLoc2;
    
    DELETE FROM location2 WHERE Location2Id = $MinLoc2;
    DELETE FROM hist_location2 WHERE Location2Id = $MinLoc2;
    
    IF $MinLoc2 = $MaxLoc2
    THEN
		LEAVE Loc2Loop;
	ELSE
		SET $MinLoc2 = (SELECT MIN(Location2Id) FROM location2 WHERE Location1Id = $Location1Id AND Hide = 0 AND Location2Id > $MinLoc2);
	END IF;
END WHILE;


END;
