CREATE PROCEDURE CommonDB.ins_org_analysis_params_chld(IN `$OldParentId`       VARCHAR(100),
                                                       IN `$NewParentId`       VARCHAR(100),
                                                       IN `$NewObserAndAnalId` VARCHAR(100), IN `$LangId` VARCHAR(100))
  BEGIN
DECLARE p_finished INTEGER DEFAULT 0;
DECLARE $prcode, $prid VARCHAR(255);
 DECLARE p_cursor CURSOR FOR
 select op.ObservationAndAnalysisParamId,op.FieldCode from `ABCanTrackV2`.`observation_analysis_param` op
 WHERE op.ParentId = $OldParentId AND op.LanguageId = $LangId;

 -- declare NOT FOUND handler
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET p_finished = 1;
    
    
 open p_cursor;

-- FETCH g_p_cursor INTO $gid , $fcode, $prcode, $prid;

ex: LOOP
	FETCH p_cursor INTO $prid ,$prcode;

	IF p_finished = 1 THEN 
		LEAVE ex;
	END IF;

-- select $fcode,$prcode;

INSERT INTO `ABCanTrackV2`.`observation_analysis_param`
	(
		`ObservationAndAnalysisParamId`,
        `FieldCode`,
	    `LanguageId`,
		`ObservationAndAnalysisId`,
		`ObservationAndAnalysisParamName`,
		`ObservationAndAnalysisParamDetails`,
		`Order`,
		`IsMulti`,
		`ParentId`,
		`LastUpdateDate`,
		`EditingBy`,
		`Hide`
	)
	SELECT
		'',
        `FieldCode`,
	    $LangId,
		$NewObserAndAnalId,
		`ObservationAndAnalysisParamName`,
		`ObservationAndAnalysisParamDetails`,
		`Order`,
		`IsMulti`,
		$NewParentId,
		CURRENT_TIMESTAMP(),
		`EditingBy`,
		`Hide`
	FROM  `ABCanTrackV2`.`observation_analysis_param`
	WHERE ObservationAndAnalysisParamId = $prid AND FieldCode=$prcode AND LanguageId = $LangId;

END LOOP ex;

CLOSE p_cursor;

END;
