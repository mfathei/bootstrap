CREATE PROCEDURE CommonDB.import_locations_proc(IN `$OrgId` VARCHAR(100), IN `$UpdatedById` VARCHAR(100))
  BEGIN
DECLARE $HistoryOperationId VARCHAR(100);
SET $HistoryOperationId = (SELECT HistoryOperationId FROM CommonDB.history_operation WHERE HistoryOperationName = 'Add');

CALL `CommonDB`.`import_location1_proc`($OrgId, $UpdatedById, $HistoryOperationId);
CALL `CommonDB`.`import_location2_proc`($OrgId, $UpdatedById, $HistoryOperationId);
CALL `CommonDB`.`import_location3_proc`($OrgId, $UpdatedById, $HistoryOperationId);
CALL `CommonDB`.`import_location4_proc`($OrgId, $UpdatedById, $HistoryOperationId);

END;
