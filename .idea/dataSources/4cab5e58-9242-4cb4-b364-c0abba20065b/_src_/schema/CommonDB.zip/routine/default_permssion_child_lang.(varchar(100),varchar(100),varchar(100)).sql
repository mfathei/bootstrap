CREATE PROCEDURE CommonDB.default_permssion_child_lang(IN `$OldId`  VARCHAR(100), IN `$NewId` VARCHAR(100),
                                                       IN `$LangId` VARCHAR(100))
  BEGIN
DECLARE p_finished INTEGER DEFAULT 0;
DECLARE $pcode, $pid VARCHAR(255);
 DECLARE p_cursor CURSOR FOR
 select p.PermissionId,p.PermissionCode from CommonDB.permission p
 WHERE p.PermissionParentId = $OldId AND p.LanguageId = GetLanguageId('en');

 -- declare NOT FOUND handler
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET p_finished = 1;
    
 open p_cursor;

-- FETCH g_p_cursor INTO $gid , $fcode, $pcode, $pid;

ex: LOOP
	FETCH p_cursor INTO $pid ,$pcode;

	IF p_finished = 1 THEN 
		LEAVE ex;
	END IF;

-- select $fcode,$pcode;

 -- `CommonDB`.`permission`
 INSERT INTO `CommonDB`.`permission` (
  `permission`.`PermissionId`
  ,`permission`.`ProductId`
  ,`permission`.`PermissionCode`
  ,`permission`.`LanguageId`
  ,`permission`.`PermissionName`
  ,`permission`.`Order`
  ,`permission`.`PermissionDefinition`
  ,`permission`.`PermissionType`
  ,`permission`.`PermissionParentId`
  ,`permission`.`IsUsed`
  )
 SELECT `permission`.`PermissionId`
  ,`permission`.`ProductId`
  ,`permission`.`PermissionCode`
  ,$LangId
  ,`permission`.`PermissionName`
  ,`permission`.`Order`
  ,`permission`.`PermissionDefinition`
  ,`permission`.`PermissionType`
  ,$NewId
  ,`permission`.`IsUsed`
 FROM `CommonDB`.`permission`
 WHERE `permission`.`PermissionId`=$pid AND `permission`.`LanguageId` = GetLanguageId('en');

END LOOP ex;

CLOSE p_cursor;

END;
