CREATE PROCEDURE CommonDB.import_location1_proc(IN `$OrgId`              VARCHAR(100), IN `$UpdatedById` VARCHAR(100),
                                                IN `$HistoryOperationId` VARCHAR(100))
  BEGIN

-- DECLARE $OrgId VARCHAR(100);
-- DECLARE $MaxOrder INT;

-- Check location1 records that exist in location1 table

UPDATE import_location tbl1
INNER JOIN location1 tbl2
ON tbl1.Location1Name = tbl2.Location1Name AND tbl1.OrgId = tbl2.OrgId
SET tbl1.Location1Id = tbl2.Location1Id
WHERE tbl1.OrgId = $OrgId;

INSERT INTO location1
	(Location1Name, OrgId)
SELECT DISTINCT
	Location1Name, $OrgId
FROM import_location 
WHERE OrgId = $OrgId AND Location1Id IS NULL;

INSERT INTO `CommonDB`.`hist_location1`
(
	`Location1Id`,
	`Location1Name`,
	`OrgId`,
	`HistoryOperationId`,
	`UpdatedById`,
	`UpdatedDate`
)
SELECT DISTINCT 
	tbl2.`Location1Id`,
	tbl2.`Location1Name`,
	$OrgId,
	$HistoryOperationId,
	$UpdatedById,
	CURRENT_TIMESTAMP
FROM import_location tbl1
INNER JOIN location1 tbl2
ON tbl1.Location1Name = tbl2.Location1Name AND tbl1.OrgId = tbl2.OrgId
WHERE tbl1.OrgId = $OrgId
AND tbl1.Location1Id IS NULL;


UPDATE import_location tbl1
INNER JOIN location1 tbl2
ON tbl1.Location1Name = tbl2.Location1Name AND tbl1.OrgId = tbl2.OrgId
SET tbl1.Location1Id = tbl2.Location1Id
WHERE tbl1.OrgId = $OrgId;
    
END;
