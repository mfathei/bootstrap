CREATE PROCEDURE CommonDB.GetSupervisorList(IN `$searchString` TEXT, IN `$OrgId` VARCHAR(100))
  BEGIN

set @selectquery ="select distinct org_employee.EmployeeId, FirstName, LastName , concat(FirstName, ' ', LastName) as FullName";
set @queryFrom = " from employee
            inner join org_employee on org_employee.EmployeeId= employee.EmployeeId ";


SET @queryWhere = CONCAT('where org_employee.Orgid = "', $OrgId, '" and  org_employee.EmpIsActive = 1' );


IF ($searchString !='NULL') THEN
SET @queryWhere = CONCAT(@queryWhere,'  AND CONCAT (FirstName', ' ,','LastName)',' like('"'%", $searchString ,"%'"')');	
END IF;	

SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );

SET @query = CONCAT(@query, ' order by FirstName asc');

-- select @queryWhere; 


PREPARE stmt1 FROM @query;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 

END;
