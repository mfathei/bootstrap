CREATE PROCEDURE CommonDB.GetEmployees(IN xmlData TEXT)
  BEGIN
SET @Orgid = extractvalue(xmlData, '//OrgId');

SET @page = extractvalue(xmlData, '//page');

SET @limit = extractvalue(xmlData, '//limit');

SET @sortOrder =  extractvalue(xmlData, '//sortOrder');

SET @index =  extractvalue(xmlData, '//index');

SET @Export =  extractvalue(xmlData, '//Export');


SET @LanguageCode =  extractvalue(xmlData, '//LanguageCode');


SET @lblActive = (select GetItemLabel(@LanguageCode,'active'));
SET @lblInactive = (select GetItemLabel(@LanguageCode,'inactive'));




set @selectquery =concat('select   employee.EmployeeId,  FirstName, LastName, employee.Email, Position, PrimaryPhone, AlternatePhone, 
	classification.ClassificationId, employee.Address, Area, GroupName,emp_group.GroupId ,org_employee.Company,
	CASE EmpIsActive  when '0' then '',@lblInactive,'' when '1' then '', @lblActive,'' end AS EmpIsActive, ClassificationName ');
    
set @queryFrom = ' from employee 
inner join org_employee on employee.employeeid = org_employee.employeeid  
left outer join classification on classification.ClassificationId = org_employee.ClassificationId
';

SET @queryFrom = CONCAT(@queryFrom,'  and orgid =   "', @Orgid,'"');
SET @queryFrom = CONCAT(@queryFrom,' left outer join emp_group on employee.EmployeeId = emp_group.employeeid and groupid in (select groupid from `group` where orgid =  "', @Orgid, '") ');

SET @queryFrom = CONCAT(@queryFrom,' left outer join `group` on emp_group.groupid = `group`.`groupid`  ');


SET @queryWhere = '';

IF (@Orgid != '' AND @Orgid !='0') THEN
	SET @queryWhere = CONCAT(@queryWhere,' where org_employee.OrgId =   "', @Orgid,'"');
END IF;	

/* search part */

SET @Company =  extractvalue(xmlData, '//Company');
IF (@Company != '' AND @Company !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,'  AND org_employee.Company like('"'%", @Company ,"%'"')');	
END IF;	

SET @FirstName =  extractvalue(xmlData, '//FirstName');
IF (@FirstName != '' AND @FirstName !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,'  AND FirstName like('"'%", @FirstName ,"%'"')');	
END IF;	

SET @LastName =  extractvalue(xmlData, '//LastName');
IF (@LastName != '' AND @LastName !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,'  AND LastName like('"'%", @LastName ,"%'"')');	
END IF;	

SET @Email =  extractvalue(xmlData, '//Email');
IF (@Email != '' AND @Email !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,'  AND employee.Email like('"'%", @Email ,"%'"')');	
END IF;	

SET @PrimaryPhone =  extractvalue(xmlData, '//PrimaryPhone');
IF (@PrimaryPhone != '' AND @PrimaryPhone !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,'  AND PrimaryPhone like('"'%", @PrimaryPhone ,"%'"')');	
END IF;	

SET @AlternatePhone =  extractvalue(xmlData, '//AlternatePhone');
IF (@AlternatePhone != '' AND @AlternatePhone !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,'  AND AlternatePhone like('"'%", @AlternatePhone ,"%'"')');	
END IF;	

SET @Classification =  extractvalue(xmlData, '//Classification');
IF (@Classification != '' AND @Classification !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,'  AND Classification like('"'%", @Classification ,"%'"')');	
END IF;	

SET @Address =  extractvalue(xmlData, '//Address');
IF (@Address != '' AND @Address !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,'  AND employee.Address like('"'%", @Address ,"%'"')');	
END IF;	

SET @GroupName =  extractvalue(xmlData, '//GroupName');
IF (@GroupName != '' AND @GroupName !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,'  AND GroupName like('"'%", @GroupName ,"%'"')');	
END IF;	

SET @Position =  extractvalue(xmlData, '//Position');
IF (@Position != '' AND @Position !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,'  AND Position like('"'%", @Position ,"%'"')');	
END IF;	

SET @EmpIsActive =  extractvalue(xmlData, '//EmpIsActive');
IF (@EmpIsActive != '' AND @EmpIsActive !='NULL') THEN
	IF( @EmpIsActive  != '2' ) THEN 
		SET @queryWhere = CONCAT(@queryWhere,'  AND EmpIsActive = ',  @EmpIsActive ); 
	END IF;	
END IF;

SET @Area =  extractvalue(xmlData, '//Area');
IF (@Area != '' AND @Area !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,'  AND Area like('"'%", @Area ,"%'"')');	
END IF;	

SET @ClassificationName =  extractvalue(xmlData, '//ClassificationName');
IF (@ClassificationName != '' AND @ClassificationName !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,'  AND ClassificationName like('"'%", @ClassificationName ,"%'"')');	
END IF;	

 -- select @query; 

-- SET @querycount = CONCAT( 'SELECT count(*) into @cnt ', @queryFrom, @queryWhere );
SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );
SET @querycount =  CONCAT( 'SELECT count(*) into @cnt from  (', @query, ' ) t');

PREPARE stmt1 FROM @querycount;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 


 SET @selectquery = CONCAT (@selectquery,', ', @cnt, ' as Count ');

SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );

if(@index ='FirstName' or @index ='LastName'  or @index ='Email'  or @index ='PrimaryPhone' 
		or @index ='AlternatePhone' or @index ='Company'  or @index ='ClassificationName'  or @index ='GroupName' or @index ='EmpIsActive') then

SET @query = CONCAT(@query, ' order by ', @index,'  ', @sortOrder);

end if;

if( @Export ="false") then

SET @page = (@page - 1) * @limit;
SET @query = CONCAT(@query, ' LIMIT ', @limit ,' OFFSET ',  @page);

end if;


PREPARE stmt1 FROM @query;
EXECUTE stmt1;
 -- select @query; 
END;
