CREATE PROCEDURE CommonDB.GetUsers(IN `$OrgId` VARCHAR(100), IN `$GroupId` VARCHAR(100))
  BEGIN


select emp_group.GroupId ,`group`.Orgid,  employee.EmployeeId, FirstName, LastName , concat(FirstName, ' ', LastName) as FullName
 
from employee
	 inner join org_employee on org_employee.EmployeeId= employee.EmployeeId  and org_employee.Orgid = $OrgId
     inner join emp_group on emp_group.EmployeeId= employee.EmployeeId and groupid in (select groupid from `group` where orgid = $OrgId)
	 inner join `group` on `group`.GroupId = emp_group.GroupId and `group`.OrgId = $OrgId
	
where emp_group.GroupId  <> $GroupId
	and `password` is not null
	and emp_group.IsActive = 1 and emp_group.GroupId is not null

order by FirstName asc;



END;
