CREATE PROCEDURE CommonDB.import_location2_proc(IN `$OrgId`              VARCHAR(100), IN `$UpdatedById` VARCHAR(100),
                                                IN `$HistoryOperationId` VARCHAR(100))
  BEGIN

UPDATE import_location tbl1
INNER JOIN location2 tbl2
ON tbl1.Location2Name = tbl2.Location2Name AND tbl1.Location1Id = tbl2.Location1Id -- AND tbl1.OrgId = tbl2.OrgId
SET tbl1.Location2Id = tbl2.Location2Id
WHERE tbl1.OrgId = $OrgId;

INSERT INTO location2
	(Location2Name, Location1Id)
SELECT DISTINCT
	Location2Name, Location1Id
FROM import_location 
WHERE OrgId = $OrgId AND Location2Id IS NULL; 


INSERT INTO `CommonDB`.`hist_location2`
(
	`Location2Id`,
	`Location2Name`,
	`Location1Name`,
	`OrgId`,
	`HistoryOperationId`,
	`UpdatedById`,
	`UpdatedDate`
)
SELECT DISTINCT 
	tbl2.`Location2Id`,
	tbl2.`Location2Name`,
	tbl1.`Location1Name`,
	$OrgId,
	$HistoryOperationId,
	$UpdatedById,
	CURRENT_TIMESTAMP
FROM import_location tbl1
INNER JOIN location2 tbl2
ON tbl1.Location2Name = tbl2.Location2Name AND tbl1.Location1Id = tbl2.Location1Id
WHERE tbl1.OrgId = $OrgId
AND tbl1.Location2Id IS NULL;

UPDATE import_location tbl1
INNER JOIN location2 tbl2
ON tbl1.Location2Name = tbl2.Location2Name AND tbl1.Location1Id = tbl2.Location1Id -- AND tbl1.OrgId = tbl2.OrgId
SET tbl1.Location2Id = tbl2.Location2Id
WHERE tbl1.OrgId = $OrgId;

END;
