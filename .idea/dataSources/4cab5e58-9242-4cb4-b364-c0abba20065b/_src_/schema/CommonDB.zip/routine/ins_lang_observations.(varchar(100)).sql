CREATE PROCEDURE CommonDB.ins_lang_observations(IN `$LangId` VARCHAR(100))
  BEGIN
DECLARE p_finished INTEGER DEFAULT 0;
DECLARE $ocode, $oid, $NewId VARCHAR(255);
 DECLARE p_cursor CURSOR FOR
 select o.ObservationAndAnalysisId,o.ObservationAndAnalysisCode from `ABCanTrackV2`.observation_analysis o
 WHERE o.OrgId IS NULL AND o.LanguageId = GetLanguageId('en');

 -- declare NOT FOUND handler
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET p_finished = 1;
    
 open p_cursor;

-- FETCH g_p_cursor INTO $gid , $fcode, $pcode, $pid;

ex: LOOP
	FETCH p_cursor INTO  $oid ,$ocode;

	IF p_finished = 1 THEN 
		LEAVE ex;
	END IF;

-- select $fcode,$pcode;

 INSERT INTO `ABCanTrackV2`.`observation_analysis` 
(
	`observation_analysis`.`ObservationAndAnalysisId`,
    `observation_analysis`.`FieldCode`,
    `observation_analysis`.`LanguageId`,
    `observation_analysis`.`ObservationAndAnalysisCode`,
    `observation_analysis`.`ObservationAndAnalysisName`,
    `observation_analysis`.`ObservationAndAnalysisDetails`,
    `observation_analysis`.`OrgId`,
    `observation_analysis`.`Order`,
    `observation_analysis`.`LastUpdateDate`,
    `observation_analysis`.`EditingBy`,
    `observation_analysis`.`Hide`
)
SELECT
	'',
    `observation_analysis`.`FieldCode`,
    $LangId,
    `observation_analysis`.`ObservationAndAnalysisCode`,
    `observation_analysis`.`ObservationAndAnalysisName`,
    `observation_analysis`.`ObservationAndAnalysisDetails`,
    `observation_analysis`.`OrgId`,
    `observation_analysis`.`Order`,
    Current_timestamp(),
    `observation_analysis`.`EditingBy`,
    `observation_analysis`.`Hide`
FROM `ABCanTrackV2`.`observation_analysis` Where ObservationAndAnalysisId = $oid AND LanguageId = GetLanguageId('en');

 SET $NewId = (select o.ObservationAndAnalysisId from `ABCanTrackV2`.observation_analysis o WHERE o.OrgId IS NULL AND o.ObservationAndAnalysisCode=$ocode AND o.LanguageId = $LangId);

 CALL ins_lang_analysis_params($oid,$NewId,$LangId);

END LOOP ex;

CLOSE p_cursor;

END;
