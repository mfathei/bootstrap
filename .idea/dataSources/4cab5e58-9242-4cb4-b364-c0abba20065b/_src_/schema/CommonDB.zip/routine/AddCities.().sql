CREATE PROCEDURE CommonDB.AddCities()
  BEGIN
DECLARE p_finished INTEGER DEFAULT 0;
DECLARE $pcode, $pid  VARCHAR(255);
 DECLARE p_cursor CURSOR FOR
 SELECT 
	`_city`.`ProvinceId`,
    `_city`.`CityName`
   
FROM `CommonDB`.`_city`;
 
 -- declare NOT FOUND handler
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET p_finished = 1;
    
 open p_cursor;
-- FETCH g_p_cursor INTO $gid , $fcode, $pcode, $pid;
ex: LOOP
	FETCH p_cursor INTO $pid ,$pcode;
	IF p_finished = 1 THEN 
		LEAVE ex;
	END IF;

if  (select count(*) from `CommonDB`.`city` where ProvinceId=$pid and CityName= $pcode) = 0 then 

INSERT INTO `CommonDB`.`city`  (`CityName`,`ProvinceId`,`LanguageId`)
VALUES
($pcode, $pid, GetLanguageId('en'));

-- select $pcode;

end if;	
END LOOP ex;
CLOSE p_cursor;
END;
