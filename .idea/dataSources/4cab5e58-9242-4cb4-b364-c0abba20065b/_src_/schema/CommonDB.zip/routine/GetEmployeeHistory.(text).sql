CREATE PROCEDURE CommonDB.GetEmployeeHistory(IN xmlData TEXT)
  BEGIN
SET @Orgid = extractvalue(xmlData, '//OrgId');
SET @page = extractvalue(xmlData, '//page');
SET @limit = extractvalue(xmlData, '//limit');
SET @sortOrder =  extractvalue(xmlData, '//sortOrder');
SET @index =  extractvalue(xmlData, '//index');
SET @EmpHistoryId =  extractvalue(xmlData, '//EmpHistoryId');
SET @Export =  extractvalue(xmlData, '//Export');
SET @LanguageCode =  extractvalue(xmlData, '//LanguageCode');

SET @lblActive = (select GetItemLabel(@LanguageCode,'active'));
SET @lblInactive = (select GetItemLabel(@LanguageCode,'inactive'));

set @selectquery = CONCAT(' select HistEmployeeId, hist_employee.EmployeeId, hist_employee.FirstName,hist_employee.LastName,hist_employee.Email,	
						hist_employee.Address,hist_employee.CityName,hist_employee.ProvinceName,
						hist_employee.CountryName,hist_employee.Location,
						hist_employee.Department,hist_employee.GroupName,hist_employee.OrgName,hist_employee.PostalCode,
						hist_employee.Position,hist_employee.Area,hist_employee.SupervisorName,hist_employee.PrimaryPhone,
						hist_employee.AlternatePhone,hist_employee.Classification,hist_employee.UserName,				
						CASE  EmpIsActive  WHEN '0' THEN '',@lblInactive,'' WHEN '1' THEN '', @lblActive,''END AS  EmpIsActive,
						CASE  IsActive  WHEN '0' THEN '',@lblInactive,'' WHEN '1' THEN '', @lblActive,'' END AS  IsActive

						,hist_employee.UpdatedById,history_operation.HistoryOperationName,
						date_format(hist_employee.UpdatedDate,'%m/%d/%Y %H:%i') as UpdatedDate, 
						concat(UpdatedBy.Firstname,' ', UpdatedBy.lastName) as UpdatedByName ');
                        
set @queryFrom = ' from hist_employee
					inner join employee as UpdatedBy on hist_employee.UpdatedById = UpdatedBy.EmployeeId
					left outer join history_operation on history_operation.HistoryOperationId = hist_employee.HistoryOperationId  ';
                    
SET @queryWhere = ' where 1= 1 ';
IF (@Orgid != '' AND @Orgid !='0') THEN
	SET @queryWhere = CONCAT(@queryWhere,' and hist_employee.OrgId =  "', @Orgid,'" ');
END IF;	
IF (@EmpHistoryId != '' AND @EmpHistoryId !='0') THEN
	SET @queryWhere = CONCAT(@queryWhere,' and hist_employee.EmployeeId = "', @EmpHistoryId,'"');
END IF;	
/* search part */
SET @FirstName =  extractvalue(xmlData, '//FirstName');
IF (@FirstName != '' AND @FirstName !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_employee.FirstName like('"'%", @FirstName ,"%'"')');	
END IF;	
SET @LastName =  extractvalue(xmlData, '//LastName');
IF (@LastName != '' AND @LastName !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_employee.LastName like('"'%", @LastName ,"%'"')');	
END IF;	
SET @Email =  extractvalue(xmlData, '//Email');
IF (@Email != '' AND @Email !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_employee.Email like('"'%", @Email ,"%'"')');	
END IF;	 
SET @PrimaryPhone =  extractvalue(xmlData, '//PrimaryPhone');
IF (@PrimaryPhone != '' AND @PrimaryPhone !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_employee.PrimaryPhone like('"'%", @PrimaryPhone ,"%'"')');	
END IF;	
SET @AlternatePhone =  extractvalue(xmlData, '//AlternatePhone');
IF (@AlternatePhone != '' AND @AlternatePhone !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_employee.AlternatePhone like('"'%", @AlternatePhone ,"%'"')');	
END IF;	
SET @Classification =  extractvalue(xmlData, '//Classification');
IF (@Classification != '' AND @Classification !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_employee.Classification like('"'%", @Classification ,"%'"')');	
END IF;	
SET @Address =  extractvalue(xmlData, '//Address');
IF (@Address != '' AND @Address !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_employee.Address like('"'%", @Address ,"%'"')');	
END IF;	
SET @GroupName =  extractvalue(xmlData, '//GroupName');
IF (@GroupName != '' AND @GroupName !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_employee.GroupName like('"'%", @GroupName ,"%'"')');	
END IF;	
SET @Position =  extractvalue(xmlData, '//Position');
IF (@Position != '' AND @Position !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_employee.Position like('"'%", @Position ,"%'"')');	
END IF;	
SET @EmpIsActive =  extractvalue(xmlData, '//EmpIsActive');
IF (@EmpIsActive != '' AND @EmpIsActive !='NULL') THEN
	IF( @EmpIsActive  != '2' ) THEN 
		SET @queryWhere = CONCAT(@queryWhere,'  AND hist_employee.EmpIsActive = ',  @EmpIsActive ); 
	END IF;	
END IF;

SET @IsActive =  extractvalue(xmlData, '//IsActive');
IF (@IsActive != '' AND @IsActive !='NULL') THEN
	IF( @IsActive  != '2' ) THEN 
		SET @queryWhere = CONCAT(@queryWhere,'  AND hist_employee.IsActive = ',  @IsActive ); 
	END IF;	 
END IF;

SET @Area =  extractvalue(xmlData, '//Area');
IF (@Area != '' AND @Area !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_employee.Area like('"'%", @Area ,"%'"')');	
END IF;	
SET @SupervisorName =  extractvalue(xmlData, '//SupervisorName');
IF (@SupervisorName != '' AND @SupervisorName !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_employee.SupervisorName like('"'%", @SupervisorName ,"%'"')');	
END IF;	
SET @UpdatedByName =  extractvalue(xmlData, '//UpdatedByName');
IF (@UpdatedByName != '' AND @UpdatedByName !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,' AND CONCAT (UpdatedBy.FirstName', ' ,','UpdatedBy.LastName)',' like('"'%", @UpdatedByName ,"%'"')');	
END IF;	
SET @HistoryOperationName =  extractvalue(xmlData, '//HistoryOperationName');
IF (@HistoryOperationName != '' AND @HistoryOperationName !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,'  AND history_operation.HistoryOperationName like('"'%", @HistoryOperationName ,"%'"')');	
END IF;	
SET @CityName =  extractvalue(xmlData, '//CityName');
IF (@CityName != '' AND @CityName !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_employee.CityName like('"'%", @CityName ,"%'"')');	
END IF;	
SET @ProvinceName =  extractvalue(xmlData, '//ProvinceName');
IF (@ProvinceName != '' AND @ProvinceName !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_employee.ProvinceName like('"'%", @ProvinceName ,"%'"')');	
END IF;	
SET @CountryName =  extractvalue(xmlData, '//CountryName');
IF (@CountryName != '' AND @CountryName !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_employee.CountryName like('"'%", @CountryName ,"%'"')');	
END IF;	
SET @Location =  extractvalue(xmlData, '//Location');
IF (@Location != '' AND @Location !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_employee.Location like('"'%", @Location ,"%'"')');	
END IF;	
SET @Department =  extractvalue(xmlData, '//Department');
IF (@Department != '' AND @Department !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_employee.Department like('"'%", @Department ,"%'"')');	
END IF;	
SET @PostalCode =  extractvalue(xmlData, '//PostalCode');
IF (@PostalCode != '' AND @PostalCode !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_employee.PostalCode like('"'%", @PostalCode ,"%'"')');	
END IF;	
SET @UpdatedDateFrom =  extractvalue(xmlData, '//UpdatedDateFrom');
SET @UpdatedDateTo =  extractvalue(xmlData, '//UpdatedDateTo');
IF(@UpdatedDateTo != '') THEN	
	SET @UpdatedDateTo  = STR_TO_DATE(@UpdatedDateTo , '%m/%d/%Y');
    SET @UpdatedDateFrom  = STR_TO_DATE(@UpdatedDateFrom , '%m/%d/%Y');
	SET @UpdatedDateTo2 = DATE_ADD(@UpdatedDateTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_employee.UpdatedDate >  ', "'" , @UpdatedDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_employee.UpdatedDate <=  ', "'",  @UpdatedDateTo2  ,"'" );										
ELSE 
IF(@UpdatedDateTo = '' AND @UpdatedDateFrom !='' ) THEN
	SET @UpdatedDateFrom  = STR_TO_DATE(@UpdatedDateFrom , '%m/%d/%Y');
	SET @UpdatedDateFrom2 = DATE_ADD(@UpdatedDateFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_employee.UpdatedDate >=  ',  "'", @UpdatedDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_employee.UpdatedDate <  ', "'", @UpdatedDateFrom2  ,"'");	
END IF; 
END IF;
/* end of search */
SET @querycount = CONCAT( 'SELECT count(*) into @cnt ', @queryFrom, @queryWhere );
PREPARE stmt1 FROM @querycount;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
SET @selectquery = CONCAT (@selectquery,', ', @cnt, ' as Count ');
SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );


-- select @query ;

if(  @index ='Operation') then set  @index = 'HistoryOperationName';  end if;
SET @query = CONCAT(@query, ' order by ', @index,'  ', @sortOrder);


if( @Export ="false") then
SET @page = (@page - 1) * @limit;
SET @query = CONCAT(@query, ' LIMIT ', @limit ,' OFFSET ',  @page);
end if;
-- select @query ; 
PREPARE stmt1 FROM @query;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
END;
