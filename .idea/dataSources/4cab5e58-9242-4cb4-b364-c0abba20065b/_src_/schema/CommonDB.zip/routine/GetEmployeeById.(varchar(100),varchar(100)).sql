CREATE PROCEDURE CommonDB.GetEmployeeById(IN `$EmployeeId` VARCHAR(100), IN `$OrgId` VARCHAR(100))
  BEGIN

select * 
 from employee
inner join  org_employee on org_employee.EmployeeId = employee.EmployeeId

where  employee.EmployeeId = $EmployeeId and org_employee.orgid=  $OrgId;
END;
