CREATE PROCEDURE CommonDB.GetOrgThirdPartiesHistory(IN xmlData TEXT)
  BEGIN  

SET @OrgId = extractvalue(xmlData, '//OrgId');

SET @page = extractvalue(xmlData, '//page');

SET @limit = extractvalue(xmlData, '//limit');

SET @sortOrder =  extractvalue(xmlData, '//sortOrder');

SET @index =  extractvalue(xmlData, '//index');

SET @Export =  extractvalue(xmlData, '//Export');

SET @ShowCustomer =  extractvalue(xmlData, '//ShowCustomer');
SET @LanguageCode =  extractvalue(xmlData, '//LanguageCode');

SET @lblActive = (select GetItemLabel(@LanguageCode,'active'));
SET @lblInactive = (select GetItemLabel(@LanguageCode,'inactive'));


set @selectquery = CONCAT('SELECT hist_third_party.OrgId,hist_third_party.ThirdPartyId, hist_third_party.ThirdPartyName, 
							hist_third_party.ThirdPartyTypeName as ThirdPartyTypeId,    hist_third_party.Address,    hist_third_party.CityName,    
							hist_third_party.PostalCode, 	hist_third_party.PrimaryPhone , history_operation.HistoryOperationName ,
							CASE hist_third_party.IsActive  WHEN '0' THEN '',@lblInactive,'' WHEN '1' THEN '', @lblActive,'' END AS IsActive ,
							date_format(hist_third_party.UpdatedDate,'%m/%d/%Y %H:%i') as UpdatedDate, 
							concat(UpdatedBy.Firstname,' ', UpdatedBy.lastName) as UpdatedByName  ');
                

set @queryFrom = ' from hist_third_party
				inner join history_operation on history_operation.HistoryOperationId = hist_third_party.HistoryOperationId
				inner join employee as UpdatedBy on hist_third_party.UpdatedById = UpdatedBy.EmployeeId	
                inner join third_party   on hist_third_party.ThirdPartyId = third_party.ThirdPartyId	';

SET @queryWhere = ' where 1= 1 ';

if(@ShowCustomer  = '0') then 
SET @queryWhere = CONCAT(@queryWhere,'  and ThirdPartyTypeName != "Customer" ');
end if;

SET @queryWhere = CONCAT(@queryWhere,' and hist_third_party.OrgId =   "', @Orgid,'" ');

SET @myArrayOfValue = 'ThirdPartyName,ContactName,Address,CityName,PostalCode,PrimaryPhone,HistoryOperationName,';

SET @Postition = LOCATE(',', @myArrayOfValue);

WHILE ( @Postition > 0 ) DO

 SET @STR = SUBSTRING(@myArrayOfValue, 1, @Postition-1);
 SET @myArrayOfValue = SUBSTRING(@myArrayOfValue, @Postition + 1);

 SET @Col =  extractvalue(xmlData, CONCAT('//',@STR));
 IF (@Col != '' AND @Col !='NULL') THEN
	if(@STR !='HistoryOperationName') THEN
		SET @queryWhere = CONCAT(@queryWhere,CONCAT(' AND    hist_third_party.`',@STR,'` like '"'%", @Col ,"%'")); 
	ELSE 
		SET @queryWhere = CONCAT(@queryWhere,CONCAT(' AND    `',@STR,'` like '"'%", @Col ,"%'")); 
    END IF;
 END IF;
 
 SET @Postition = LOCATE(',', @myArrayOfValue);
END WHILE;

SET @IsActive =  extractvalue(xmlData, '//IsActive');
IF (@IsActive != '' AND @IsActive !='NULL') THEN
	IF( @IsActive  != '2' ) THEN 
		SET @queryWhere = CONCAT(@queryWhere,'  AND hist_third_party.IsActive = ',  @IsActive ); 
	END IF;	
END IF; 

SET @ThirdPartyTypeId =  extractvalue(xmlData, '//ThirdPartyTypeId');
IF (@ThirdPartyTypeId != '' AND @ThirdPartyTypeId !='NULL') THEN
	IF( @ThirdPartyTypeId  != '2' ) THEN 
		SET @queryWhere = CONCAT(@queryWhere,'  AND third_party.ThirdPartyTypeId = "',  @ThirdPartyTypeId,'"' ); 
	END IF;	
END IF;

SET @UpdatedDateFrom =  extractvalue(xmlData, '//UpdatedDateFrom');
SET @UpdatedDateTo =  extractvalue(xmlData, '//UpdatedDateTo');
IF(@UpdatedDateTo != '') THEN
	
	SET @UpdatedDateTo  = STR_TO_DATE(@UpdatedDateTo , '%m/%d/%Y');
	SET @UpdatedDateTo2 = DATE_ADD(@UpdatedDateTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_third_party.UpdatedDate >  ', "'" , @UpdatedDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_third_party.UpdatedDate <=  ', "'",  @UpdatedDateTo2  ,"'" );										
ELSE 
IF(@UpdatedDateTo = '' AND @UpdatedDateFrom !='' ) THEN
	SET @UpdatedDateFrom  = STR_TO_DATE(@UpdatedDateFrom , '%m/%d/%Y');
	SET @UpdatedDateFrom2 = DATE_ADD(@UpdatedDateFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_third_party.UpdatedDate >=  ',  "'", @UpdatedDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_third_party.UpdatedDate <  ', "'", @UpdatedDateFrom2  ,"'");	
END IF;
END IF;


SET @UpdatedByName =  extractvalue(xmlData, '//UpdatedByName');
IF (@UpdatedByName != '' AND @UpdatedByName !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,' AND CONCAT (UpdatedBy.FirstName', ' ,','UpdatedBy.LastName)',' like('"'%", @UpdatedByName ,"%'"')');	
END IF;	
SET @HistoryOperationName =  extractvalue(xmlData, '//HistoryOperationName');
IF (@HistoryOperationName != '' AND @HistoryOperationName !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,'  AND history_operation.HistoryOperationName like('"'%", @HistoryOperationName ,"%'"')');	
END IF;

SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );
 -- select  @query;

SET @querycount =  CONCAT( 'SELECT count(*) into @cnt from  (', @query, ' ) t');

PREPARE stmt1 FROM @querycount;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
	
SET @selectquery = CONCAT (@selectquery,', ', @cnt, ' as Count ');

SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );

if( @index = 'Order') then set  @index = '`Order`';  end if;


if(@index ='ThirdPartyName' or @index ='ContactName'  or @index ='ThirdPartyTypeName'  or @index ='Address'  
or @index ='CityName'  or @index ='PostalCode' or @index ='PrimaryPhone'  or @index ='IsActive'
or @index =' UpdatedByName'  or @index ='HistoryOperationName'  or @index ='UpdatedDate' ) then
SET @query = CONCAT(@query, ' order by ', @index,'  ', @sortOrder);
end if;


-- SET @query = CONCAT(@query, ' order by ', @index,'  ', @sortOrder);

if( @Export ="false") then
SET @page = (@page - 1) * @limit;
SET @query = CONCAT(@query, ' LIMIT ', @limit ,' OFFSET ',  @page);

end if;

-- select  @query;

PREPARE stmt1 FROM @query;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 


END;
