CREATE PROCEDURE CommonDB.GetLocation4History(IN xmlData TEXT)
  BEGIN
SET @Orgid = extractvalue(xmlData, '//OrgId');
SET @page = extractvalue(xmlData, '//page');
SET @limit = extractvalue(xmlData, '//limit');
SET @sortOrder =  extractvalue(xmlData, '//sortOrder');
SET @index =  extractvalue(xmlData, '//index');
SET @LocationHistoryId =  extractvalue(xmlData, '//LocationHistoryId');
SET @Export =  extractvalue(xmlData, '//Export');


set @selectquery ="SELECT HistLocation4Id, Location4Id, Location4Name, Location3Name, Location2Name, Location1Name, history_operation.HistoryOperationName,
					date_format(hist_location4.UpdatedDate,'%m/%d/%Y %H:%i') as UpdatedDate, 
					concat(UpdatedBy.Firstname,' ', UpdatedBy.lastName) as UpdatedByName  ";

set @queryFrom = " from hist_location4
				inner join history_operation on history_operation.HistoryOperationId = hist_location4.HistoryOperationId
				inner join employee as UpdatedBy on hist_location4.UpdatedById = UpdatedBy.EmployeeId";


SET @queryWhere = ' where 1= 1 ';

IF (@Orgid != '' AND @Orgid !='0') THEN
	SET @queryWhere = CONCAT(@queryWhere,' and hist_location4.OrgId =  "', @Orgid,'" ');
END IF;	

IF (@LocationHistoryId != 'null' AND @LocationHistoryId !='0') THEN
	SET @queryWhere = CONCAT(@queryWhere,' and hist_location4.Location4Id = "', @LocationHistoryId,'"');
END IF;

SET @UpdatedDateFrom =  extractvalue(xmlData, '//UpdatedDateFrom');
SET @UpdatedDateTo =  extractvalue(xmlData, '//UpdatedDateTo');
IF(@UpdatedDateTo != '') THEN
	
	SET @UpdatedDateTo  = STR_TO_DATE(@UpdatedDateTo , '%m/%d/%Y');
	SET @UpdatedDateTo2 = DATE_ADD(@UpdatedDateTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_location4.UpdatedDate >  ', "'" , @UpdatedDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_location4.UpdatedDate <=  ', "'",  @UpdatedDateTo2  ,"'" );										
ELSE 
IF(@UpdatedDateTo = '' AND @UpdatedDateFrom !='' ) THEN
	SET @UpdatedDateFrom  = STR_TO_DATE(@UpdatedDateFrom , '%m/%d/%Y');
	SET @UpdatedDateFrom2 = DATE_ADD(@UpdatedDateFrom ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_location4.UpdatedDate >=  ',  "'", @UpdatedDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND hist_location4.UpdatedDate <  ', "'", @UpdatedDateFrom2  ,"'");	
END IF;
END IF;


SET @UpdatedByName =  extractvalue(xmlData, '//UpdatedByName');
IF (@UpdatedByName != '' AND @UpdatedByName !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,' AND CONCAT (UpdatedBy.FirstName', ' ,','UpdatedBy.LastName)',' like('"'%", @UpdatedByName ,"%'"')');	
END IF;	
SET @HistoryOperationName =  extractvalue(xmlData, '//HistoryOperationName');
IF (@HistoryOperationName != '' AND @HistoryOperationName !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,'  AND history_operation.HistoryOperationName like('"'%", @HistoryOperationName ,"%'"')');	
END IF;

SET @Location4Name =  extractvalue(xmlData, '//Location4Name');
IF (@Location4Name != '' AND @Location4Name !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,'  AND Location4Name like('"'%", @Location4Name ,"%'"')');	
END IF;


SET @Location3Name =  extractvalue(xmlData, '//Location3Name');
IF (@Location3Name != '' AND @Location3Name !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,'  AND Location3Name like('"'%", @Location3Name ,"%'"')');	
END IF;

SET @Location2Name =  extractvalue(xmlData, '//Location2Name');
IF (@Location2Name != '' AND @Location2Name !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,'  AND Location2Name like('"'%", @Location2Name ,"%'"')');	
END IF;


SET @Location1Name =  extractvalue(xmlData, '//Location1Name');
IF (@Location1Name != '' AND @Location1Name !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,'  AND Location1Name like('"'%", @Location1Name ,"%'"')');	
END IF;


/* end of search */
SET @querycount = CONCAT( 'SELECT count(*) into @cnt ', @queryFrom, @queryWhere );
PREPARE stmt1 FROM @querycount;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
SET @selectquery = CONCAT (@selectquery,', ', @cnt, ' as Count ');
SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );

SET @query = CONCAT(@query, ' order by ', @index,'  ', @sortOrder);


if( @Export ="false") then
SET @page = (@page - 1) * @limit;
SET @query = CONCAT(@query, ' LIMIT ', @limit ,' OFFSET ',  @page);
end if;
 -- select @query ; 
PREPARE stmt1 FROM @query;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
END;
