CREATE PROCEDURE CommonDB.DeleteUser(IN `$EmployeeId` VARCHAR(100), IN `$OrgId` VARCHAR(100))
  BEGIN

DELETE FROM org_prod_employee  WHERE  EmployeeId = $EmployeeId  and OrgId = $OrgId ;

Update org_employee 
		set IsActive			= 0 ,
			 GroupId 			= null ,
			AssignToGroupDate 	= null
 where EmployeeId = $EmployeeId and OrgId = $OrgId ;


set @count = (select count(*) from org_employee where EmployeeId = $EmployeeId and OrgId != $OrgId  );

if( @count = 0) then 
Update employee  
set  `Password` = null,
	UserName = null,
	SecurityQuestionId = null,
	SecurityAnswer = null

where EmployeeId = $EmployeeId ;
End If;


-- select @count;
END;
