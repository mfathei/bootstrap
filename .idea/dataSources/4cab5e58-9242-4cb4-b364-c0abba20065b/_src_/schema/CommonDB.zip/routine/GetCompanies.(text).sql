CREATE PROCEDURE CommonDB.GetCompanies(IN xmlData TEXT)
  BEGIN


SET @Orgid = extractvalue(xmlData, '//OrgId');

SET @page = extractvalue(xmlData, '//page');

SET @limit = extractvalue(xmlData, '//limit');

SET @sortOrder =  extractvalue(xmlData, '//sortOrder');

SET @index =  extractvalue(xmlData, '//index');

SET @Export =  extractvalue(xmlData, '//Export');
SET @LanguageCode =  extractvalue(xmlData, '//LanguageCode');

SET @lblActive = (select GetItemLabel(@LanguageCode,'active'));
SET @lblInactive = (select GetItemLabel(@LanguageCode,'inactive'));
SET @lblYes = (select GetItemLabel(@LanguageCode,'yes'));
SET @lblNo = (select GetItemLabel(@LanguageCode,'no'));

set @selectquery = CONCAT(' SELECT org.OrgId, org.OrgName, org.Address,org.CityId,c1.CityName, p1.ProvinceName, p1.ProvinceId, co1.CountryName, co1.CountryId,
                    org.BillingCityId, c2.CityName as BillingCityName, p2.ProvinceName as BillingProvinceName, p2.ProvinceId as BillingProvinceId, co2.CountryName as BillingCountryName, co2.CountryId as BillingCountryId,
                    org.PostalCode,org.LocationLevel,date_format(org.CreationDate,'%m/%d/%Y') AS  CreationDate,
                    org.MailingAddress,org.Email,org.Discount,org.CreatedBy,org.BillingContact,org.BillingPostalCode,
                    org.BillingCycleUnite,org.BillingCycle,date_format(org.FirstBillingDate,'%m/%d/%Y') AS  FirstBillingDate,date_format(org.LastBillingDate,'%m/%d/%Y') AS  LastBillingDate,
                    CASE org.IsActive WHEN '0' then '',@lblInactive,'' WHEN '1' then '', @lblActive,'' END AS IsActive,
                   CASE org.ShowCustomer   WHEN '0' then '',@lblNo,'' WHEN '1' then '', @lblYes,'' END AS ShowOrgCustomer,OrgCode,SystemAdminId,concat(FirstName,' ' , LastName) as SystemAdminName   ');
                   
set @queryFrom = '  FROM organization  org
					left outer join employee on employee.EmployeeId = org.SystemAdminId
                    left outer join city c1 on c1.CityId = org.CityId
                    left outer join province p1 on p1.ProvinceId = c1.ProvinceId
                    left outer join country co1 on co1.CountryId = p1.CountryId
                    left outer join city c2 on c2.CityId = org.BillingCityId
                    left outer join province p2 on p2.ProvinceId = c2.ProvinceId
                    left outer join country co2 on co2.CountryId = p2.CountryId  ';


SET @queryWhere = '  where org.OrgId in (select OrgId  from ABCanTrackV2.organization)   ';

SET @myArrayOfValue = 'OrgName,Address,CityName,BillingCityName,PostalCode,LocationLevel,MailingAddress,Email,Discount,CreatedBy,BillingContact,BillingPostalCode, BillingCycleUnite,BillingCycle,OrgCode,FirstName,';
                    

SET @Postition = LOCATE(',', @myArrayOfValue);

WHILE ( @Postition > 0 ) DO

 SET @STR = SUBSTRING(@myArrayOfValue, 1, @Postition-1);
 SET @myArrayOfValue = SUBSTRING(@myArrayOfValue, @Postition + 1);

 SET @Col =  extractvalue(xmlData, CONCAT('//',@STR));
 IF (@Col != '' AND @Col !='NULL') THEN
	 
	if(@STR ='BillingCityName') then  set @STR = 'c2.CityName';  	end if;
	if(@STR ='CityName') 		then  set @STR = 'c1.CityName';  	end if;
	if(@STR ='Email') 			then  set @STR = 'org.Email'; 		end if;
	if(@STR ='Address') 		then  set @STR = 'org.Address'; 	end if;
	if(@STR ='PostalCode') 		then  set @STR = 'org.PostalCode'; 	end if;
	if(@STR ='FirstName')		then  set @STR = 'FirstName'; 		end if;
 
 
  SET @queryWhere = CONCAT(@queryWhere,CONCAT(' AND    ',@STR,'  like '"'%", @Col ,"%'")); 
 END IF;
 
 SET @Postition = LOCATE(',', @myArrayOfValue);
END WHILE;


SET @IsActive =  extractvalue(xmlData, '//IsActive');
IF (@IsActive != '' AND @IsActive !='NULL') THEN
	IF( @IsActive  != '2' ) THEN 
		SET @queryWhere = CONCAT(@queryWhere,'  AND org.IsActive = ',  @IsActive ); 
	END IF;	
END IF;



SET @ShowOrgCustomer =  extractvalue(xmlData, '//ShowOrgCustomer');
IF (@ShowOrgCustomer != '' AND @ShowOrgCustomer !='NULL') THEN
	IF( @ShowOrgCustomer  != '2' ) THEN 
		SET @queryWhere = CONCAT(@queryWhere,'  AND  org.ShowCustomer = ',  @ShowOrgCustomer ); 
	END IF;	
END IF;



SET @CreationDateFrom =  extractvalue(xmlData, '//CreationDateFrom');
SET @CreationDateTo =  extractvalue(xmlData, '//CreationDateTo');


IF(@CreationDateTo ="" AND @CreationDateFrom != "" ) THEN

	SET @CreationDateFrom  = STR_TO_DATE(@CreationDateFrom , '%m/%d/%Y');
	SET @CreationDateFrom2 = DATE_ADD(@CreationDateFrom ,INTERVAL 1 DAY) ;

	SET @queryWhere = CONCAT(@queryWhere,'  AND CreationDate >=  ',  "'", @CreationDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND CreationDate <  ', "'", @CreationDateFrom2  ,"'");

ELSE IF(@CreationDateTo !="" ) then
		SET @CreationDateFrom  = STR_TO_DATE(@CreationDateFrom , '%m/%d/%Y');
		SET @CreationDateTo  = STR_TO_DATE(@CreationDateTo , '%m/%d/%Y');
		SET @CreationDateTo2 = DATE_ADD(@CreationDateTo ,INTERVAL 1 DAY) ;
		SET @queryWhere = CONCAT(@queryWhere,'  AND CreationDate >  ', "'" , @CreationDateFrom ,"'" );	
		SET @queryWhere = CONCAT(@queryWhere,'  AND CreationDate <=  ', "'",  @CreationDateTo2  ,"'" );	
	
	END IF;
END IF;

  -- select  @query;

SET @query = CONCAT( @selectquery, @queryFrom , @queryWhere);

SET @querycount =  CONCAT( 'SELECT count(*) into @cnt from  (', @query, ' ) t');

PREPARE stmt1 FROM @querycount;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 

SET @selectquery = CONCAT (@selectquery,', ', @cnt, ' as Count ');

SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );

SET @query = CONCAT(@query, ' order by ', @index,'  ', @sortOrder);

if( @Export ="false") then

SET @page = (@page - 1) * @limit;
SET @query = CONCAT(@query, ' LIMIT ', @limit ,' OFFSET ',  @page);

end if;

PREPARE stmt1 FROM @query;
EXECUTE stmt1;
-- select @query; 

END;
