CREATE PROCEDURE CommonDB.GetUserEmailLog(IN xmlData TEXT)
  BEGIN


SET @page = extractvalue(xmlData, '//page');

SET @limit = extractvalue(xmlData, '//limit');

SET @sortOrder =  extractvalue(xmlData, '//sortOrder');

SET @index =  extractvalue(xmlData, '//index');

SET @EmpLoginHistoryId =  extractvalue(xmlData, '//EmpLoginHistoryId');

SET @Export =  extractvalue(xmlData, '//Export');


set @selectquery ='SELECT SQL_CALC_FOUND_ROWS 
    EmailLogId,
    EmailTypeName,
    `Subject`,
    SentDate,
    case IsSent when '0' then 'No' when '1' then 'Yes' end as IsSent,
    concat(FirstName,' ', LastName) as SendToEmplyeeName';
                

set @queryFrom = " FROM
    email_log el
        JOIN
    email_type et ON et.EmailTypeId = el.EmailTypeId
        JOIN
    employee ON employee.EmployeeId = el.SendToEmployeeId";

SET @queryWhere = CONCAT(' WHERE 1= 1 ');



IF (@EmpLoginHistoryId != '' AND @EmpLoginHistoryId !='0') THEN
 SET @queryWhere = CONCAT(@queryWhere,' and SendToEmployeeId = "', @EmpLoginHistoryId,'"');
END IF; 

SET @SendToEmplyeeName =  extractvalue(xmlData, '//SendToEmplyeeName');
IF (@SendToEmplyeeName != '' AND @SendToEmplyeeName !='NULL') THEN
 SET @queryWhere = CONCAT(@queryWhere,'  AND  CONCAT (FirstName', ' ,','LastName)',' like('"'%", @SendToEmplyeeName ,"%'"')'); 
END IF; 
 
SET @EmailTypeName =  extractvalue(xmlData, '//EmailTypeName');
IF (@EmailTypeName != '' AND @EmailTypeName !='0') THEN
 SET @queryWhere = CONCAT(@queryWhere,' and EmailTypeName like('"'%", @EmailTypeName ,"%'"')');
END IF;

SET @Subject =  extractvalue(xmlData, '//Subject');
IF (@Subject != '' AND @Subject !='0') THEN
 SET @queryWhere = CONCAT(@queryWhere,' and `Subject` like('"'%", @Subject ,"%'"')');
END IF;

SET @IsSent =  extractvalue(xmlData, '//IsSent');
IF (@IsSent != '' AND @IsSent !='NULL') THEN
 IF( @IsSent  != '2' ) THEN 
  SET @queryWhere = CONCAT(@queryWhere,'  AND IsSent = ', @IsSent );  
 END IF; 
END IF;

SET @SentDateFrom =  extractvalue(xmlData, '//SentDateFrom');
SET @SentDateTo =  extractvalue(xmlData, '//SentDateTo');


IF(@SentDateTo ="" AND @SentDateFrom !="" ) THEN

	SET @SentDateFrom  = STR_TO_DATE(@SentDateFrom , '%m/%d/%Y');
	SET @SentDateFrom2 = DATE_ADD(@SentDateFrom ,INTERVAL 1 DAY) ;

	SET @queryWhere = CONCAT(@queryWhere,'  AND SentDate >=  ',  "'", @SentDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND SentDate <  ', "'", @SentDateFrom2  ,"'");

ELSE IF(@SentDateTo !="") then
		SET @SentDateFrom  = STR_TO_DATE(@SentDateFrom , '%m/%d/%Y');
		SET @SentDateTo  = STR_TO_DATE(@SentDateTo , '%m/%d/%Y');
		SET @SentDateTo2 = DATE_ADD(@SentDateTo ,INTERVAL 1 DAY) ;
		SET @queryWhere = CONCAT(@queryWhere,'  AND SentDate >  ', "'" , @SentDateFrom ,"'" );	
		SET @queryWhere = CONCAT(@queryWhere,'  AND SentDate <=  ', "'",  @SentDateTo2  ,"'" );	
	
	END IF;
END IF;


SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );

if(@index ='EmailTypeName' or @index ='Subject' or @index = 'SentDate' or @index = 'IsSent' or @index = 'SendToEmplyeeName')then
SET @query = CONCAT(@query, ' order by ', @index,'  ', @sortOrder);
end if;


if( @Export ="false") then
SET @page = (@page - 1) * @limit;
SET @query = CONCAT(@query, ' LIMIT ', @limit ,' OFFSET ',  @page);

end if;

-- select  @query;

PREPARE stmt1 FROM @query;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
SELECT FOUND_ROWS();
 
END;
