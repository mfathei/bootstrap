CREATE FUNCTION CommonDB.getEmailTypeIdByLang(pEmailTypeId VARCHAR(100), pLangId VARCHAR(100))
  RETURNS VARCHAR(100)
  BEGIN
        declare vEmailTypeId VARCHAR(100) CHARSET utf8 default null;
        set @emailTypeCode = (select FieldCode from CommonDB.`email_type` where EmailTypeId = pEmailTypeId and LanguageId = CommonDB.GetLanguageId('en'));
        set vEmailTypeId = (select EmailTypeId from CommonDB.`email_type` where FieldCode = @emailTypeCode and LanguageId = pLangId);
        return vEmailTypeId;
    END;
