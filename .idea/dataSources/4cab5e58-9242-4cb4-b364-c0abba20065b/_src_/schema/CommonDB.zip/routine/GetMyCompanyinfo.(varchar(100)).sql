CREATE PROCEDURE CommonDB.GetMyCompanyinfo(IN `$OrgId` VARCHAR(100))
  BEGIN

SET @LanguageCode =  (select LanguageCode from `language` l
join organization o on o.LanguageId = l.LanguageId  
where o.OrgId = $OrgId);

SET @lblActive = (select GetItemLabel(@LanguageCode,'active'));
SET @lblInactive = (select GetItemLabel(@LanguageCode,'inactive'));

SET @lblYes = (select GetItemLabel(@LanguageCode,'yes'));
SET @lblNo = (select GetItemLabel(@LanguageCode,'no'));

SET @selectquery =CONCAT(' SELECT distinct org.OrgId, OrgName, org.Address,org.CityId,c1.CityName, p1.ProvinceName, p1.ProvinceId, co1.CountryName, co1.CountryId,
org.BillingCityId, c2.CityName as BillingCityName, p2.ProvinceName as BillingProvinceName, p2.ProvinceId as BillingProvinceId, co2.CountryName as BillingCountryName, co2.CountryId as BillingCountryId,
org.PostalCode,LocationLevel,org.CreationDate,
MailingAddress,org.Email,Discount,CreatedBy,BillingContact,BillingPostalCode,
BillingCycleUnite,BillingCycle,FirstBillingDate,LastBillingDate,
CASE org.IsActive  WHEN '0' THEN '',@lblInactive,'' WHEN '1' THEN '', @lblActive,''  END AS OrgStatus,
CASE org.IsActive WHEN '0' THEN '0' WHEN '1' THEN '1' END AS IsActive,
CASE org.ShowCustomer WHEN '0' THEN '',@lblNo,'' WHEN '1' THEN '', @lblYes,''  END AS ShowCustomer,
OrgCode,SystemAdminId, FirstName, LastName, ProductId
FROM organization  org
join org_product on org_product.OrgId = org.OrgId
join product_version on product_version.ProductVersionId = org_product.ProductVersionId
left outer join employee on employee.EmployeeId = org.SystemAdminId
left outer join city c1 on c1.CityId = org.CityId
left outer join province p1 on p1.ProvinceId = c1.ProvinceId
left outer join country co1 on co1.CountryId = p1.CountryId
left outer join city c2 on c2.CityId = org.BillingCityId
left outer join province p2 on p2.ProvinceId = c2.ProvinceId
left outer join country co2 on co2.CountryId = p2.CountryId  ') ;
	
  
SET @query = CONCAT(@selectquery,'  where  org_product.IsActive = 1 and  org.OrgId =  "', $OrgId,'"  group by  org.OrgId ');

-- select @query; 

PREPARE stmt1 FROM @query;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
 
END;
