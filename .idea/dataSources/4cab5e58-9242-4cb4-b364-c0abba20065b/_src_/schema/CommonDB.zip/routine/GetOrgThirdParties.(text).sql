CREATE PROCEDURE CommonDB.GetOrgThirdParties(IN xmlData TEXT)
  BEGIN   

SET @OrgId = extractvalue(xmlData, '//OrgId');

SET @page = extractvalue(xmlData, '//page');

SET @limit = extractvalue(xmlData, '//limit');

SET @sortOrder =  extractvalue(xmlData, '//sortOrder');

SET @index =  extractvalue(xmlData, '//index');

SET @Export =  extractvalue(xmlData, '//Export');

SET @ShowCustomer =  extractvalue(xmlData, '//ShowCustomer');
SET @LanguageCode =  extractvalue(xmlData, '//LanguageCode');

SET @lblActive = (select GetItemLabel(@LanguageCode,'active'));
SET @lblInactive = (select GetItemLabel(@LanguageCode,'inactive'));


set @selectquery =CONCAT('SELECT ThirdPartyId, ThirdPartyName,    ContactName, ThirdPartyTypeName as ThirdPartyTypeId,    Address,    city.CityName, province.ProvinceName as ProvinceStateId, country.CountryName,   PostalCode,    PrimaryPhone,
						CASE IsActive  WHEN '0' THEN '',@lblInactive,'' WHEN '1' THEN '', @lblActive,''  END AS IsActive   ');
                 

set @queryFrom = ' from third_party
					inner join third_party_type on third_party_type.ThirdPartyTypeId = third_party.ThirdPartyTypeId
					left outer join city on city.CityId = third_party.CityId   
                    left outer join province on province.ProvinceId = city.ProvinceId   
                    left outer join country on country.CountryId = province.CountryId      ';

SET @queryWhere = ' where 1= 1 ';

if(@ShowCustomer  = '0') then 
SET @queryWhere = CONCAT(@queryWhere,'  and ThirdPartyTypeCode != "Customer" ');
end if;

SET @queryWhere = CONCAT(@queryWhere,' and third_party.OrgId =   "', @Orgid,'" ');

SET @queryWhere = CONCAT(@queryWhere,' and third_party.Hide = 0 ');

SET @myArrayOfValue = 'ThirdPartyName,ContactName,Address,CityName,PostalCode,PrimaryPhone,ProvinceStateId,CountryName,';

SET @Postition = LOCATE(',', @myArrayOfValue);

WHILE ( @Postition > 0 ) DO

	SET @STR = SUBSTRING(@myArrayOfValue, 1, @Postition-1);
	SET @myArrayOfValue = SUBSTRING(@myArrayOfValue, @Postition + 1);

	SET @Col =  extractvalue(xmlData, CONCAT('//',@STR));
	IF (@Col != '' AND @Col !='NULL') THEN
	 
	if( @STR = 'CityName') then set  @STR = 'city.CityName';  end if;
	if( @STR = 'ProvinceStateId') then set  @STR = 'province.ProvinceName';  end if;
	if( @STR = 'CountryName') then set  @STR = 'country.CountryName';  end if;
 
  SET @queryWhere = CONCAT(@queryWhere,CONCAT(' AND  ',@STR,' like '"'%", @Col ,"%'")); 
 END IF;
 
 SET @Postition = LOCATE(',', @myArrayOfValue);
END WHILE;

SET @IsActive =  extractvalue(xmlData, '//IsActive');
IF (@IsActive != '' AND @IsActive !='NULL') THEN
	IF( @IsActive  != '2' ) THEN 
		SET @queryWhere = CONCAT(@queryWhere,'  AND IsActive = ',  @IsActive ); 
	END IF;	
END IF;

SET @ThirdPartyTypeId =  extractvalue(xmlData, '//ThirdPartyTypeId');
IF (@ThirdPartyTypeId != '' AND @ThirdPartyTypeId !='NULL') THEN
	IF( @ThirdPartyTypeId  != '2' ) THEN 
		SET @queryWhere = CONCAT(@queryWhere,'  AND third_party.ThirdPartyTypeId = "',  @ThirdPartyTypeId,'"' ); 
	END IF;	
END IF;


SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );
 -- select  @query;

SET @querycount =  CONCAT( 'SELECT count(*) into @cnt from  (', @query, ' ) t');

PREPARE stmt1 FROM @querycount;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
	
SET @selectquery = CONCAT (@selectquery,', ', @cnt, ' as Count ');

SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );

if( @index = 'Order') then set  @index = '`Order`';  end if;

if(@index ='ThirdPartyName' or @index ='ContactName'  or @index ='ThirdPartyTypeName'  or @index ='Address'  
or @index ='CityName'  or @index ='PostalCode' or @index ='PrimaryPhone'  or @index ='IsActive') then
SET @query = CONCAT(@query, ' order by ', @index,'  ', @sortOrder);
end if;

if( @Export ="false") then
SET @page = (@page - 1) * @limit;
SET @query = CONCAT(@query, ' LIMIT ', @limit ,' OFFSET ',  @page);

end if;

-- select  @query;

PREPARE stmt1 FROM @query;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 


END;
