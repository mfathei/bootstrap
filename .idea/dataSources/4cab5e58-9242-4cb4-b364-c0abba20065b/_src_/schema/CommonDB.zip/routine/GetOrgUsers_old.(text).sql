CREATE PROCEDURE CommonDB.GetOrgUsers_old(IN xmlData TEXT)
  BEGIN

SET @Orgid = extractvalue(xmlData, '//OrgId');

SET @page = extractvalue(xmlData, '//page');

SET @limit = extractvalue(xmlData, '//limit');

SET @sortOrder =  extractvalue(xmlData, '//sortOrder');

SET @index =  extractvalue(xmlData, '//index');

SET @Export =  extractvalue(xmlData, '//Export');

set @selectquery =" select distinct employee.EmployeeId, concat(FirstName,' ' , LastName) as FullName, 
					employee.UserName, GroupName, emp_group.GroupId ,
					CASE emp_group.IsActive WHEN '0' THEN 'Inactive' WHEN '1' THEN 'Active' END AS IsActive
					, emp_group.AssignToGroupDate, 
					( SELECT MAX(Login)FROM login_history
					WHERE login_history.EmployeeId  = employee.EmployeeId) as Login ";

set @queryFrom = " from employee
					inner join emp_group on emp_group.EmployeeId = employee.EmployeeId 
					inner join `group` on `group`.GroupId = emp_group.GroupId 												
					left outer join login_history on login_history.EmployeeId = employee.EmployeeId ";


SET @queryWhere = ' where 1 = 1 ';

IF (@Orgid != '' AND @Orgid !='0') THEN
	SET @queryWhere = CONCAT(@queryWhere,' and `group`.OrgId =  "', @Orgid,'" ');
END IF;	

/* search part */

SET @GroupName =  extractvalue(xmlData, '//GroupName');
IF (@GroupName != '' AND @GroupName !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,'  AND GroupName like('"'%", @GroupName ,"%'"')');	
END IF;	

SET @UserName =  extractvalue(xmlData, '//UserName');
IF (@UserName != '' AND @UserName !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,'   AND  UserName like('"'%", @UserName ,"%'"')');	
END IF;	

SET @IsActive =  extractvalue(xmlData, '//IsActive');
IF (@IsActive != '' AND @IsActive !='NULL') THEN
	IF( @IsActive  != 'All' ) THEN 
		SET @queryWhere = CONCAT(@queryWhere,'  AND emp_group.IsActive = ',  @IsActive ); 
	END IF;	
END IF;


SET @LoginFrom =  extractvalue(xmlData, '//LoginFrom');
SET @LoginTo =  extractvalue(xmlData, '//LoginTo');


IF(@LoginTo != '') THEN
	
	SET @LoginTo  = STR_TO_DATE(@LoginTo , '%m/%d/%Y');
	SET @LoginTo2 = DATE_ADD(@LoginTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND login_history.Login >  ', "'" , @LoginFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND login_history.Login <=  ', "'",  @LoginTo2  ,"'" );										
ELSE 
IF(@LoginTo = '' AND @LoginFrom !='' ) THEN

	SET @LoginFrom  = STR_TO_DATE(@LoginFrom , '%m/%d/%Y');
	SET @LoginFrom2 = DATE_ADD(@LoginFrom ,INTERVAL 1 DAY) ;

	SET @queryWhere = CONCAT(@queryWhere,'  AND login_history.Login >=  ',  "'", @LoginFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND login_history.Login <  ', "'", @LoginFrom2  ,"'");	
END IF;

END IF;

SET @AssignToGroupDateFrom =  extractvalue(xmlData, '//AssignToGroupDateFrom');
SET @AssignToGroupDateTo =  extractvalue(xmlData, '//AssignToGroupDateTo');

IF(@AssignToGroupDateTo != '') THEN
	
	SET @AssignToGroupDateTo  = STR_TO_DATE(@AssignToGroupDateTo , '%m/%d/%Y');
	SET @AssignToGroupDateTo2 = DATE_ADD(@AssignToGroupDateTo ,INTERVAL 1 DAY) ;
	SET @queryWhere = CONCAT(@queryWhere,'  AND emp_group.AssignToGroupDate >  ', "'" , @AssignToGroupDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND emp_group.AssignToGroupDate <=  ', "'",  @AssignToGroupDateTo2  ,"'" );										
ELSE 
IF(@AssignToGroupDateTo = '' AND @AssignToGroupDateFrom !='' ) THEN

	SET @AssignToGroupDateFrom  = STR_TO_DATE(@AssignToGroupDateFrom , '%m/%d/%Y');
	SET @AssignToGroupDateFrom2 = DATE_ADD(@AssignToGroupDateFrom ,INTERVAL 1 DAY) ;

	SET @queryWhere = CONCAT(@queryWhere,'  AND emp_group.AssignToGroupDate >=  ',  "'", @AssignToGroupDateFrom ,"'" );	
	SET @queryWhere = CONCAT(@queryWhere,'  AND emp_group.AssignToGroupDate <  ', "'", @AssignToGroupDateFrom2  ,"'");	
END IF;

END IF;




SET @FullName =  extractvalue(xmlData, '//FullName');
IF (@FullName != '' AND @FullName !='NULL') THEN
	SET @queryWhere = CONCAT(@queryWhere,'   AND   CONCAT(FirstName , " ", LastName) like('"'%", @FullName ,"%'"')');	
END IF;	

SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );

SET @querycount =  CONCAT( 'SELECT count(*) into @cnt from  (', @query, ' ) t');
-- SET @querycount = CONCAT( 'SELECT count(*) into @cnt ', @queryFrom, @queryWhere );


PREPARE stmt1 FROM @querycount;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 


SET @selectquery = CONCAT (@selectquery,', ', @cnt, ' as Count ');

SET @query = CONCAT( @selectquery, @queryFrom, @queryWhere );

SET @query = CONCAT(@query, ' order by ', @index,'  ', @sortOrder);

if( @Export ="false") then

SET @page = (@page - 1) * @limit;
SET @query = CONCAT(@query, ' LIMIT ', @limit ,' OFFSET ',  @page);

end if;
-- select @query; 

PREPARE stmt1 FROM @query;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 

-- select @query; 
END;
