CREATE PROCEDURE CommonDB.default_group_perms_lang(IN `$LangId` VARCHAR(255))
  BEGIN
DECLARE finished INTEGER DEFAULT 0;
DECLARE $gid , $fcode, $pcode, $pid VARCHAR(255);
 DECLARE g_p_cursor CURSOR FOR
 select `group`.GroupId,`group`.FieldCode,permission.PermissionCode,permission.PermissionId from CommonDB.group_permission join CommonDB.`group` 
 on (`group`.GroupId = group_permission.GroupId AND `group`.OrgId IS NULL AND `group`.LanguageId = GetLanguageId('en'))
 join CommonDB.permission
 ON (group_permission.PermissionId = permission.PermissionId AND `permission`.LanguageId = GetLanguageId('en'));
  
 -- declare NOT FOUND handler
	DECLARE CONTINUE HANDLER 
	FOR NOT FOUND SET finished = 1;
    
 open g_p_cursor;

-- FETCH g_p_cursor INTO $gid , $fcode, $pcode, $pid;

ex: LOOP
	FETCH g_p_cursor INTO $gid , $fcode, $pcode, $pid;

	IF finished = 1 THEN 
		LEAVE ex;
	END IF;

-- select $fcode,$pcode;

set @new_gid = (select GroupId from CommonDB.`group` where OrgId IS NULL AND FieldCode = $fcode AND LanguageId = $LangId);
set @new_pid = (select PermissionId from CommonDB.`permission` where PermissionCode = $pcode AND LanguageId = $LangId);

insert into CommonDB.group_permission
values(@new_gid,@new_pid);



END LOOP ex;

CLOSE g_p_cursor;

END;
