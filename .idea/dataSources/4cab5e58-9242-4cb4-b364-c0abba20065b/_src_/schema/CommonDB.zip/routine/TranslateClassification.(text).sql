CREATE PROCEDURE CommonDB.TranslateClassification(IN xmlData TEXT)
  BEGIN
SET @page = extractvalue(xmlData, '//page');
SET @limit = extractvalue(xmlData, '//limit');
SET @sortOrder =  extractvalue(xmlData, '//sortOrder');
SET @index =  extractvalue(xmlData, '//index');
SET @Export =  extractvalue(xmlData, '//Export'); 
SET @languageCode = 'ru';
set @selectquery = CONCAT( 'SELECT 
    ClassificationId,
    FieldCode,
    ClassificationName,
    (SELECT 
            ClassificationName
        FROM
            classification tbl1
                JOIN
            `language` ON tbl1.`LanguageId` = `language`.`LanguageId` 
        WHERE
            languageCode ="', @languageCode,'"
                AND tbl2.FieldCode = tbl1.FieldCode) AS RussianClassificationName') ;
set @queryFrom = ' FROM   classification tbl2
					JOIN    `language` ON tbl2.`LanguageId` = `language`.`LanguageId`
					WHERE    languageCode = 'en'   '; 
SET @querycount = CONCAT( 'SELECT count(*) into @cnt ', @queryFrom);
-- select  @querycount;
PREPARE stmt1 FROM @querycount;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
SET @selectquery = CONCAT (@selectquery,', ', @cnt, ' as Count ');
SET @query = CONCAT(@selectquery , @queryFrom);
SET @query = CONCAT(@query, ' order by ', @index,'  ', @sortOrder);

if( @Export ="false") then
SET @page = (@page - 1) * @limit;
SET @query = CONCAT(@query, ' LIMIT ', @limit ,' OFFSET ',  @page);
 
end if;

PREPARE stmt1 FROM @query;
EXECUTE stmt1;
DEALLOCATE PREPARE stmt1; 
END;
