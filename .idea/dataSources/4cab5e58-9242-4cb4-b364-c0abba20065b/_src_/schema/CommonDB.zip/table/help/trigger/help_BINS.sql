CREATE TRIGGER CommonDB.help_BINS
BEFORE INSERT ON CommonDB.help
FOR EACH ROW
  BEGIN
SET NEW.HelpId = MyUUID();
Update last_uuid
SET LastId	= new.HelpId
WHERE TableName = 'help';
END;
