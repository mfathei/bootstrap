CREATE TRIGGER CommonDB.product_version_BINS
BEFORE INSERT ON CommonDB.product_version
FOR EACH ROW
  BEGIN
SET new.ProductVersionId = MyUUID();
END;
