CREATE TRIGGER CommonDB.email_template_BINS
BEFORE INSERT ON CommonDB.email_template
FOR EACH ROW
  BEGIN
SET new.TemplateId = MyUUID();
END;
