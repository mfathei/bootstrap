CREATE TRIGGER CommonDB.login_history_BINS
BEFORE INSERT ON CommonDB.login_history
FOR EACH ROW
  BEGIN
SET new.LoginHistoryId = MyUUID();
END;
