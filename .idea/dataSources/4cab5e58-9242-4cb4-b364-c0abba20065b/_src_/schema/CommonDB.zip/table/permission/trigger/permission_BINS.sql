CREATE TRIGGER CommonDB.permission_BINS
BEFORE INSERT ON CommonDB.permission
FOR EACH ROW
  BEGIN
SET new.PermissionId = MyUUID();
END;
