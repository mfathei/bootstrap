CREATE TRIGGER CommonDB.location4_BINS
BEFORE INSERT ON CommonDB.location4
FOR EACH ROW
  BEGIN
	SET new.Location4Id = MyUUID();
	Update last_uuid
	SET LastId	= new.Location4Id
	WHERE TableName = 'location4';
END;
