CREATE TRIGGER CommonDB.location4_AUPD
AFTER UPDATE ON CommonDB.location4
FOR EACH ROW
  BEGIN
 
update  ABCanTrackV2.location4
set 
	`location4`.`location4Id` = new.location4Id,
    `location4`.`location4Name` =  new.location4Name,
    `location4`.`Location3Id` = new.Location3Id,
    `location4`.`Order` = new.`Order`,
    `location4`.`LastUpdateDate` = new.LastUpdateDate,
    `location4`.`EditingBy` = new.EditingBy,
    `location4`.`Hide` = new.Hide
where `ABCanTrackV2`.`location4`.`location4Id` = OLD.location4Id;
 
 END;
