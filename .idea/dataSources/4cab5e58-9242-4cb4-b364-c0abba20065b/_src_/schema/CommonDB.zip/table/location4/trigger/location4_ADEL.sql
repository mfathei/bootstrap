CREATE TRIGGER CommonDB.location4_ADEL
AFTER DELETE ON CommonDB.location4
FOR EACH ROW
  BEGIN
Delete from ABCanTrackV2.location4 where Location4Id = OLD.Location4Id;
END;
