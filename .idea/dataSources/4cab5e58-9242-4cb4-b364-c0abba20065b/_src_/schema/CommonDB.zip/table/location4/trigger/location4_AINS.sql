CREATE TRIGGER CommonDB.location4_AINS
AFTER INSERT ON CommonDB.location4
FOR EACH ROW
  BEGIN
insert into ABCanTrackV2.location4
(
	`location4`.`location4Id`,
    `location4`.`location4Name`,
    `location4`.`Location3Id`,
    `location4`.`Order`,
    `location4`.`LastUpdateDate`,
    `location4`.`EditingBy`,
    `location4`.`Hide`
)
select
	new.`location4Id`,
    new.`location4Name`,
    new.`Location3Id`,
    new.`Order`,
    new.`LastUpdateDate`,
    new.`EditingBy`,
    new.`Hide`;
END;
