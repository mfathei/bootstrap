CREATE TRIGGER CommonDB.org_employee_AUPD
AFTER UPDATE ON CommonDB.org_employee
FOR EACH ROW
  BEGIN
 
UPDATE `ABCanTrackV2`.`org_employee`
SET
	`org_employee`.`EmployeeId` = NEW.`EmployeeId`,
    `org_employee`.`OrgId` = NEW.`OrgId`,
    `org_employee`.`Department` = NEW.`Department`,
    `org_employee`.`Company` = NEW.`Company`,
    `org_employee`.`EmpIsActive` = NEW.`EmpIsActive`
	
WHERE `ABCanTrackV2`.`org_employee`.`EmployeeId` = OLD.`EmployeeId`
		AND `ABCanTrackV2`.`org_employee`.`OrgId` = OLD.`OrgId`;
 
 END;
