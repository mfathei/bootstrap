CREATE TRIGGER CommonDB.org_employee_BDEL
BEFORE DELETE ON CommonDB.org_employee
FOR EACH ROW
  BEGIN
DELETE FROM `ABCanTrackV2`.`org_employee`
	WHERE `ABCanTrackV2`.`org_employee`.`EmployeeId` = OLD.`EmployeeId`
		AND `ABCanTrackV2`.`org_employee`.`OrgId` = OLD.`OrgId`;
END;
