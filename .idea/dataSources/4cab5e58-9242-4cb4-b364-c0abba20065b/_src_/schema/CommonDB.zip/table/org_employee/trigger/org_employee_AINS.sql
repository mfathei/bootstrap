CREATE TRIGGER CommonDB.org_employee_AINS
AFTER INSERT ON CommonDB.org_employee
FOR EACH ROW
  BEGIN
INSERT INTO `ABCanTrackV2`.`org_employee`
(
	`org_employee`.`EmployeeId`,
    `org_employee`.`OrgId`,
    `org_employee`.`Department`,
    `org_employee`.`Company`,
    `org_employee`.`EmpIsActive`
)
VALUES
(
	NEW.`EmployeeId`,
    NEW.`OrgId`,
    NEW.`Department`,
    NEW.`Company`,
    NEW.`EmpIsActive`
);
END;
