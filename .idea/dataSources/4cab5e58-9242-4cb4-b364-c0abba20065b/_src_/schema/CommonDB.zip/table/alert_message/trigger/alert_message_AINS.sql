CREATE TRIGGER CommonDB.alert_message_AINS
AFTER INSERT ON CommonDB.alert_message
FOR EACH ROW
  BEGIN
/*
DECLARE $Min, $Max varchar(100);
SET $Min = (select min(OrgId) from organization);
SET $Max = (select max(OrgId) from organization);
MsgLoop: WHILE $Min <= $Max
DO
INSERT INTO  `CommonDB`.`org_alert_message`
(
	`org_alert_message`.`OrgId`,
    `org_alert_message`.`AlertMessageId`,
    `org_alert_message`.`LanguageId`,
    `org_alert_message`.`AlertMessageDescription` 
)
Values
(
	$Min,
	NEW.`AlertMessageId`,
	1,
	NEW.`AlertMessageDescription`
);
IF $Min = $Max
then LEAVE MsgLoop;
Else
SET $Min = (select min(OrgId) from organization where OrgId > $Min);

END  IF;

END WHILE;
*/
END;
