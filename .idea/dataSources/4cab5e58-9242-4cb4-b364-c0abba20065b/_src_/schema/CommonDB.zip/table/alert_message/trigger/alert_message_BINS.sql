CREATE TRIGGER CommonDB.alert_message_BINS
BEFORE INSERT ON CommonDB.alert_message
FOR EACH ROW
  BEGIN

SET new.AlertMessageId = MyUUID();

END;
