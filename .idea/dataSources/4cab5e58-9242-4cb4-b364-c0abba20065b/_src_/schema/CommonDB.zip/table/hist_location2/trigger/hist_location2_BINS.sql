CREATE TRIGGER CommonDB.hist_location2_BINS
BEFORE INSERT ON CommonDB.hist_location2
FOR EACH ROW
  BEGIN
SET new.HistLocation2Id = MyUUID();
END;
