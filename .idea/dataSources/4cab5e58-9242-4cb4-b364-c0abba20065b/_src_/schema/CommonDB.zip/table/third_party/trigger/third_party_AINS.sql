CREATE TRIGGER CommonDB.third_party_AINS
AFTER INSERT ON CommonDB.third_party
FOR EACH ROW
  BEGIN
insert into ABCanTrackV2.third_party
(
	`third_party`.`ThirdPartyId`,
    `third_party`.`ThirdPartyName`,
    `third_party`.`ContactName`,
    `third_party`.`ThirdPartyTypeId`,
    `third_party`.`OrgId`,
    `third_party`.`Address`,
    `third_party`.`CityId`,
    `third_party`.`PostalCode`,
    `third_party`.`PrimaryPhone`,
    `third_party`.`IsActive`,
    `third_party`.`LastUpdateDate`,
    `third_party`.`EditingBy`,
    `third_party`.`Hide`
)
select 
	new.`ThirdPartyId`,
    new.`ThirdPartyName`,
    new.`ContactName`,
    new.`ThirdPartyTypeId`,
    new.`OrgId`,
    new.`Address`,
    new.`CityId`,
    new.`PostalCode`,
    new.`PrimaryPhone`,
    new.`IsActive`,
    new.`LastUpdateDate`,
    new.`EditingBy`,
    new.`Hide`
;
END;
