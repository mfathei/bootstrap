CREATE TRIGGER CommonDB.third_party_BINS
BEFORE INSERT ON CommonDB.third_party
FOR EACH ROW
  BEGIN
	SET new.ThirdPartyId = MyUUID();
	Update last_uuid
	SET LastId	= new.ThirdPartyId
	WHERE TableName = 'third_party';
END;
