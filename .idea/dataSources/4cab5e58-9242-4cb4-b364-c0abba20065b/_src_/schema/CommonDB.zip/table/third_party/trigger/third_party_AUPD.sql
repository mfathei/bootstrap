CREATE TRIGGER CommonDB.third_party_AUPD
AFTER UPDATE ON CommonDB.third_party
FOR EACH ROW
  BEGIN
 
update ABCanTrackV2.third_party
set 
	`third_party`.`ThirdPartyId` = new.ThirdPartyId,
    `third_party`.`ThirdPartyName` = new.ThirdPartyName,
    `third_party`.`ContactName` = new.ContactName,
    `third_party`.`ThirdPartyTypeId` = new.ThirdPartyTypeId,
    `third_party`.`OrgId` = new.OrgId,
    `third_party`.`Address` = new.Address,
    `third_party`.`CityId` = new.CityId,
    `third_party`.`PostalCode` = new.PostalCode,
    `third_party`.`PrimaryPhone` = new.PrimaryPhone,
    `third_party`.`IsActive` = new.IsActive,
    `third_party`.`LastUpdateDate` = new.LastUpdateDate,
    `third_party`.`EditingBy` = new.EditingBy,
    `third_party`.`Hide` = new.Hide
where `ABCanTrackV2`.`third_party`.`ThirdPartyId` = OLD.ThirdPartyId;
 
 END;
