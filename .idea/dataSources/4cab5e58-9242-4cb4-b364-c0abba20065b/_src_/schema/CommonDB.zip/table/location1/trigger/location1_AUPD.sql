CREATE TRIGGER CommonDB.location1_AUPD
AFTER UPDATE ON CommonDB.location1
FOR EACH ROW
  BEGIN
 
update  ABCanTrackV2.location1
set 
	`location1`.`location1Id` = new.location1Id,
    `location1`.`location1Name` =  new.location1Name,
    `location1`.`OrgId` = new.OrgId,
    `location1`.`Order` = new.`Order`,
    `location1`.`LastUpdateDate` = new.LastUpdateDate,
    `location1`.`EditingBy` = new.EditingBy,
    `location1`.`Hide` = new.Hide
where `ABCanTrackV2`.`location1`.`location1Id` = OLD.location1Id;
 
 END;
