CREATE TRIGGER CommonDB.location1_AINS
AFTER INSERT ON CommonDB.location1
FOR EACH ROW
  BEGIN
insert into ABCanTrackV2.location1
(
	`location1`.`Location1Id`,
    `location1`.`Location1Name`,
    `location1`.`OrgId`,
    `location1`.`Order`,
    `location1`.`LastUpdateDate`,
    `location1`.`EditingBy`,
    `location1`.`Hide`
)
select
	new.`Location1Id`,
    new.`Location1Name`,
    new.`OrgId`,
    new.`Order`,
    new.`LastUpdateDate`,
    new.`EditingBy`,
    new.`Hide`;
END;
