CREATE TRIGGER CommonDB.location1_ADEL
AFTER DELETE ON CommonDB.location1
FOR EACH ROW
  BEGIN
Delete from ABCanTrackV2.location1 where Location1Id = OLD.Location1Id;
END;
