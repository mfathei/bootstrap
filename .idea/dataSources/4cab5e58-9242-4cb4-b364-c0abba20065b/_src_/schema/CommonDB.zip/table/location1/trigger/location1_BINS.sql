CREATE TRIGGER CommonDB.location1_BINS
BEFORE INSERT ON CommonDB.location1
FOR EACH ROW
  BEGIN
	SET new.Location1Id = MyUUID();
	Update last_uuid
	SET LastId	= new.Location1Id
	WHERE TableName = 'location1';
END;
