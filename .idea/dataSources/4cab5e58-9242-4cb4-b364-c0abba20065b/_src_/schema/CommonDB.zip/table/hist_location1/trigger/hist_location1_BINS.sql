CREATE TRIGGER CommonDB.hist_location1_BINS
BEFORE INSERT ON CommonDB.hist_location1
FOR EACH ROW
  BEGIN
SET new.HistLocation1Id = MyUUID();
END;
