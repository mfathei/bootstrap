CREATE TRIGGER CommonDB.hist_third_party_BINS
BEFORE INSERT ON CommonDB.hist_third_party
FOR EACH ROW
  BEGIN
SET new.HistThirdPartyId = MyUUID();
END;
