CREATE TRIGGER CommonDB.language_BEFORE_DELETE
BEFORE DELETE ON CommonDB.language
FOR EACH ROW
  BEGIN
	IF LOWER(OLD.LanguageCode) = 'en' THEN
		SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Error: You can't delete English Language(it is the default)!';
    END IF;
    
    SET @find = (SELECT LanguageId FROM ABCanTrackV2.`language` WHERE LOWER(LanguageCode)=LOWER(OLD.LanguageCode)); 
    
    IF @find IS NOT NULL THEN
		SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Error: You must delete this Language from ABCanTrackV2 first!';
    END IF;
END
;
