CREATE TRIGGER CommonDB.language_AINS
AFTER INSERT ON CommonDB.language
FOR EACH ROW
  BEGIN
DECLARE $MIN, $MAX, $CurId VARCHAR(100);
DECLARE $Code1 VARCHAR(255);
 -- ABCanTrackV2.`language`
 INSERT INTO ABCanTrackV2.`language` (
  `language`.`LanguageId`
  ,`language`.`LanguageName`
  ,`language`.`LanguageCode`
  ,`language`.`LastUpdateDate`
  ,`language`.`EditingBy`
  ,`language`.`Hide`
  )
 VALUES (
  new.`LanguageId`
  ,new.`LanguageName`
  ,new.`LanguageCode`
  ,new.`LastUpdateDate`
  ,new.`EditingBy`
  ,new.`Hide`
  );
 -- `CommonDB`.`field`
 INSERT INTO `CommonDB`.`field`
 SELECT `field`.`FieldId`
  ,`FieldName`
  ,`DefaultFieldLabel`
  ,new.`LanguageId`
  ,`field`.`PageName`
  ,`field`.`IsTranslatable`
 FROM `CommonDB`.`field`
 WHERE `field`.`LanguageId` = GetLanguageId('en');
 -- `CommonDB`.`group`
 INSERT INTO `CommonDB`.`group` (
  `GroupId`
  ,`FieldCode`
  ,`LanguageId`
  ,`GroupName`
  ,`Description`
  ,`IsActive`
  )
 SELECT `group`.`GroupId`
  ,`group`.`FieldCode`
  ,new.`LanguageId`
  ,`GroupName`
  ,`Description`
  ,`group`.`IsActive`
 FROM `CommonDB`.`group`
 WHERE `group`.`OrgId` IS NULL
  AND `group`.`LanguageId` = GetLanguageId('en');
 --  `CommonDB`.`third_party_type`
 
 INSERT INTO CommonDB.`email_type`
(
    EmailTypeId,
    LanguageId,
    EmailTypeName,
    FieldCode
)
SELECT
    '',
    NEW.`LanguageId`,
    EmailTypeName,
    FieldCode
FROM CommonDB.`email_type` WHERE LanguageId = GetLanguageId('en');
-- CommonDB.`email_type`
INSERT INTO ABCanTrackV2.`email_type`
(
    EmailTypeId,
    EmailTypeCode,
    LanguageId,
    EmailTypeName
)
SELECT
    '',
    EmailTypeCode,
    NEW.`LanguageId`,
    EmailTypeName
FROM ABCanTrackV2.`email_type` WHERE LanguageId = GetLanguageId('en');
--  
 INSERT INTO `CommonDB`.`third_party_type` (
  `ThirdPartyTypeCode`
  ,`ThirdPartyTypeName`
  ,`LanguageId`
  ,`Hide`
  )
 SELECT `third_party_type`.`ThirdPartyTypeCode`
  ,`ThirdPartyTypeName`
  ,new.`LanguageId`
  ,`third_party_type`.`Hide`
 FROM `CommonDB`.`third_party_type`
 WHERE `third_party_type`.`OrgId` IS NULL
  AND `third_party_type`.`LanguageId` = GetLanguageId('en');
 -- `CommonDB`.`operation_type`
 INSERT INTO `CommonDB`.`operation_type` (
  `LanguageId`
  ,`OperationTypeName`
  ,`OrgId`
  ,`FieldCode`
  ,`Order`
  ,`Hide`
  )
 SELECT new.`LanguageId`
  ,`OperationTypeName`
  ,`operation_type`.`OrgId`
  ,`operation_type`.`FieldCode`
  ,`operation_type`.`Order`
  ,`operation_type`.`Hide`
 FROM `CommonDB`.`operation_type`
 WHERE `operation_type`.`LanguageId` = GetLanguageId('en')
  AND OrgId IS NULL;
 -- `CommonDB`.`org_field`
 INSERT INTO `CommonDB`.`org_field` (
  `FieldName`
  ,`LanguageId`
  ,`Label`
  )
 SELECT
  `FieldName`
  ,new.`LanguageId`
  ,`Label`
 FROM `CommonDB`.`org_field`
 WHERE `org_field`.`OrgId` IS NULL
  AND `org_field`.`LanguageId` = GetLanguageId('en');
 -- `CommonDB`.`email_template`
 INSERT INTO `CommonDB`.`email_template` (
  `OrgId`
  ,`FieldCode`
  ,`LanguageId`
  ,`EmailTypeId`
  ,`Subject`
  ,`Body`
  ,`UpdatedDate`
  ,`IsActive`
  )
 SELECT `email_template`.`OrgId`
  ,`email_template`.`FieldCode`
  ,new.`LanguageId`
  ,CommonDB.getEmailTypeIdByLang(`email_template`.`EmailTypeId`, new.`LanguageId`)
  ,`Subject`
  ,`Body`
  ,`email_template`.`UpdatedDate`
  ,`email_template`.`IsActive`
 FROM `CommonDB`.`email_template`
 WHERE `email_template`.`LanguageId` = GetLanguageId('en');
 -- `CommonDB`.`alert_message`
 INSERT INTO `CommonDB`.`alert_message` (
  `alert_message`.`AlertMessageId`
  ,`alert_message`.`AlertName`
  ,`alert_message`.`AlertDescription`
  ,`alert_message`.`AlertMessageCode`
  ,`alert_message`.`LanguageId`
  ,`alert_message`.`AlertMessageDescription`
  ,`alert_message`.`LastUpdateDate`
  ,`alert_message`.`Hide`
  ,`alert_message`.`OldId`
  )
 SELECT `alert_message`.`AlertMessageId`
  ,`alert_message`.`AlertName`
  ,`alert_message`.`AlertDescription`
  ,`alert_message`.`AlertMessageCode`
  ,new.`LanguageId`
  ,`alert_message`.`AlertMessageDescription`
  ,`alert_message`.`LastUpdateDate`
  ,`alert_message`.`Hide`
  ,`alert_message`.`OldId`
 FROM `CommonDB`.`alert_message`
 WHERE `alert_message`.`LanguageId` = GetLanguageId('en');
 --  `CommonDB`.`classification`
 INSERT INTO `CommonDB`.`classification` (
  `classification`.`ClassificationId`
  ,`classification`.`ClassificationName`
  ,`classification`.`LanguageId`
  ,`classification`.`Description`
  ,`classification`.`FieldCode`
  )
 SELECT `classification`.`ClassificationId`
  ,`classification`.`ClassificationName`
  ,new.`LanguageId`
  ,`classification`.`Description`
  ,`classification`.`FieldCode`
 FROM `CommonDB`.`classification`
 WHERE `classification`.`LanguageId` = GetLanguageId('en');
 -- `CommonDB`.`permission`
CALL `default_permssions_lang`(new.`LanguageId`);
CALL default_group_perms_lang(new.`LanguageId`);
 -- `CommonDB`.`help_type`
 INSERT INTO `CommonDB`.`help_type` (
  `help_type`.`HelpTypeId`
  ,`help_type`.`HelpTypeCode`
  ,`help_type`.`LanguageId`
  ,`help_type`.`HelpTypeName`
  ,`help_type`.`MaterialType`
  ,`help_type`.`IsCustom`
  ,`help_type`.`Order`
  ,`help_type`.`IsActive`
  )
 SELECT `help_type`.`HelpTypeId`
  ,`help_type`.`HelpTypeCode`
  ,new.`LanguageId`
  ,`help_type`.`HelpTypeName`
  ,`help_type`.`MaterialType`
  ,`help_type`.`IsCustom`
  ,`help_type`.`Order`
  ,`help_type`.`IsActive`
 FROM `CommonDB`.`help_type`
 WHERE `help_type`.`LanguageId` = GetLanguageId('en');
 -- ABCanTrackV2 Lookup Tables ----------------------------------------------------------------------------------------------
 INSERT INTO `ABCanTrackV2`.`body_area`
(
    `body_area`.`FieldCode`,
    `body_area`.`LanguageId`,
    `body_area`.`BodyAreaName`,
    `body_area`.`OrgId`,
    `body_area`.`Order`,
    `body_area`.`LastUpdateDate`,
    `body_area`.`EditingBy`,
    `body_area`.`Hide`
)
SELECT
    `body_area`.`FieldCode`,
    NEW.`LanguageId`,
    `body_area`.`BodyAreaName`,
    `body_area`.`OrgId`,
    `body_area`.`Order`,
    CURRENT_TIMESTAMP(),
    `body_area`.`EditingBy`,
    `body_area`.`Hide`
FROM `ABCanTrackV2`.`body_area` WHERE OrgId IS NULL AND LanguageId = GetLanguageId('en');
INSERT INTO `ABCanTrackV2`.`body_part`
(
    `body_part`.`FieldCode`,
    `body_part`.`LanguageId`,
    `body_part`.`BodyPartName`,
    `body_part`.`OrgId`,
    `body_part`.`Order`,
    `body_part`.`LastUpdateDate`,
    `body_part`.`EditingBy`,
    `body_part`.`Hide`
)
SELECT
    `body_part`.`FieldCode`,
    NEW.`LanguageId`,
    `body_part`.`BodyPartName`,
    `body_part`.`OrgId`,
    `body_part`.`Order`,
    CURRENT_TIMESTAMP(),
    `body_part`.`EditingBy`,
    `body_part`.`Hide`
FROM `ABCanTrackV2`.`body_part` WHERE OrgId IS NULL AND LanguageId = GetLanguageId('en');
INSERT INTO `ABCanTrackV2`.`certificate`
(
    `certificate`.`FieldCode`,
    `certificate`.`LanguageId`,
    `certificate`.`CertificateName`,
    `certificate`.`OrgId`,
    `certificate`.`Order`,
    `certificate`.`LastUpdateDate`,
    `certificate`.`EditingBy`,
    `certificate`.`Hide`
)
SELECT
    `certificate`.`FieldCode`,
    NEW.`LanguageId`,
    `certificate`.`CertificateName`,
    `certificate`.`OrgId`,
    `certificate`.`Order`,
    CURRENT_TIMESTAMP(),
    `certificate`.`EditingBy`,
    `certificate`.`Hide`
FROM `ABCanTrackV2`.`certificate` WHERE OrgId IS NULL AND LanguageId = GetLanguageId('en');
 -- *************************************************************
INSERT INTO `ABCanTrackV2`.`contact`
(
    `contact`.`FieldCode`,
    `contact`.`LanguageId`,
    `contact`.`ContactName`,
    `contact`.`OrgId`
)
SELECT
    `contact`.`FieldCode`,
    NEW.`LanguageId`,
    `contact`.`ContactName`,
    `contact`.`OrgId`
FROM `ABCanTrackV2`.`contact` WHERE OrgId IS NULL AND LanguageId = GetLanguageId('en');
INSERT INTO `ABCanTrackV2`.`contact_agency`
(
    `contact_agency`.`FieldCode`,
    `contact_agency`.`LanguageId`,
    `contact_agency`.`ContactAgencyName`,
    `contact_agency`.`Description`,
    `contact_agency`.`OrgId`,
    `contact_agency`.`Order`,
    `contact_agency`.`LastUpdateDate`,
    `contact_agency`.`EditingBy`,
    `contact_agency`.`Hide`
)
SELECT
    `contact_agency`.`FieldCode`,
    NEW.`LanguageId`,
    `contact_agency`.`ContactAgencyName`,
    `contact_agency`.`Description`,
    `contact_agency`.`OrgId`,
    `contact_agency`.`Order`,
    CURRENT_TIMESTAMP(),
    `contact_agency`.`EditingBy`,
    `contact_agency`.`Hide`
FROM `ABCanTrackV2`.`contact_agency` WHERE OrgId IS NULL AND LanguageId = GetLanguageId('en');
INSERT INTO `ABCanTrackV2`.`contact_code`
(
    `contact_code`.`FieldCode`,
    `contact_code`.`LanguageId`,
    `contact_code`.`ContactCodeName`,
    `contact_code`.`OrgId`,
    `contact_code`.`Order`,
    `contact_code`.`LastUpdateDate`,
    `contact_code`.`EditingBy`,
    `contact_code`.`Hide`
)
SELECT
    `contact_code`.`FieldCode`,
    NEW.`LanguageId`,
    `contact_code`.`ContactCodeName`,
    `contact_code`.`OrgId`,
    `contact_code`.`Order`,
    CURRENT_TIMESTAMP(),
    `contact_code`.`EditingBy`,
    `contact_code`.`Hide`
FROM `ABCanTrackV2`.`contact_code` WHERE OrgId IS NULL AND LanguageId = GetLanguageId('en');
INSERT INTO `ABCanTrackV2`.`corr_act_status`
(
    `corr_act_status`.`FieldCode`,
    `corr_act_status`.`LanguageId`,
    `corr_act_status`.`CorrActStatusName`,
    `corr_act_status`.`CorrActStatusCode`,
    `corr_act_status`.`Description`,
    `corr_act_status`.`OrgId`,
    `corr_act_status`.`Order`,
    `corr_act_status`.`LastUpdateDate`,
    `corr_act_status`.`EditingBy`,
    `corr_act_status`.`Hide`
)
SELECT
    `corr_act_status`.`FieldCode`,
    NEW.`LanguageId`,
    `corr_act_status`.`CorrActStatusName`,
    `corr_act_status`.`CorrActStatusCode`,
    `corr_act_status`.`Description`,
    `corr_act_status`.`OrgId`,
    `corr_act_status`.`Order`,
    CURRENT_TIMESTAMP(),
    `corr_act_status`.`EditingBy`,
    `corr_act_status`.`Hide`
FROM `ABCanTrackV2`.`corr_act_status` WHERE OrgId IS NULL AND LanguageId = GetLanguageId('en');
INSERT INTO `ABCanTrackV2`.`duration_unit`
(
    `duration_unit`.`FieldCode`,
    `duration_unit`.`LanguageId`,
    `duration_unit`.`DurationUnitName`,
    `duration_unit`.`Order`,
    `duration_unit`.`OrgId`,
    `duration_unit`.`LastUpdateDate`,
    `duration_unit`.`EditingBy`,
    `duration_unit`.`Hide`
)
SELECT
    `duration_unit`.`FieldCode`,
    NEW.`LanguageId`,
    `duration_unit`.`DurationUnitName`,
    `duration_unit`.`Order`,
    `duration_unit`.`OrgId`,
    CURRENT_TIMESTAMP(),
    `duration_unit`.`EditingBy`,
    `duration_unit`.`Hide`
FROM `ABCanTrackV2`.`duration_unit` WHERE OrgId IS NULL AND LanguageId = GetLanguageId('en');
INSERT INTO `ABCanTrackV2`.`email_template`
(
    `email_template`.`FieldCode`,
    `email_template`.`LanguageId`,
    `email_template`.`OrgId`,
    `email_template`.`EmailTypeId`,
    `email_template`.`Title`,
    `email_template`.`Subject`,
    `email_template`.`Body`,
    `email_template`.`UpdatedDate`,
    `email_template`.`IsActive`,
    `email_template`.`Order`
)
SELECT
    `email_template`.`FieldCode`,
    NEW.`LanguageId`,
	`email_template`.`OrgId`,
    ABCanTrackV2.getEmailTypeIdByLang(`email_template`.`EmailTypeId`,GetLanguageId('ru')),
    `email_template`.`Title`,
    `email_template`.`Subject`,
    `email_template`.`Body`,
    `email_template`.`UpdatedDate`,
    `email_template`.`IsActive`,
    `email_template`.`Order`
FROM `ABCanTrackV2`.`email_template` WHERE `OrgId` IS NULL AND LanguageId = GetLanguageId('en');
SET $MIN = (SELECT MIN(EnvConditionId) FROM `ABCanTrackV2`.env_condition WHERE OrgId IS NULL AND LanguageId = GetLanguageId('en'));
SET $MAX = (SELECT MAX(EnvConditionId) FROM `ABCanTrackV2`.env_condition WHERE OrgId IS NULL AND LanguageId = GetLanguageId('en'));
EnvLoop: WHILE $MIN <= $MAX
DO
INSERT INTO `ABCanTrackV2`.`env_condition`
(
    `env_condition`.`FieldCode`,
    `env_condition`.`LanguageId`,
    `env_condition`.`EnvConditionName`,
    `env_condition`.`OrgId`,
    `env_condition`.`IsMulti`,
    `env_condition`.`Order`,
    `env_condition`.`LastUpdateDate`,
    `env_condition`.`EditingBy`,
    `env_condition`.`Hide`
)
SELECT
    `env_condition`.`FieldCode`,
    NEW.`LanguageId`,
    `env_condition`.`EnvConditionName`,
    `env_condition`.`OrgId`,
    `env_condition`.`IsMulti`,
    `env_condition`.`Order`,
    CURRENT_TIMESTAMP(),
    `env_condition`.`EditingBy`,
    `env_condition`.`Hide`
FROM `ABCanTrackV2`.`env_condition` WHERE EnvConditionId = $MIN AND LanguageId = GetLanguageId('en');
SET $CurId = (SELECT MAX(EnvConditionId) FROM `ABCanTrackV2`.env_condition WHERE OrgId IS NULL AND LanguageId = NEW.`LanguageId`);
INSERT INTO `ABCanTrackV2`.`env_cond_parameter`
(
    `env_cond_parameter`.`FieldCode`,
    `env_cond_parameter`.`LanguageId`,
    `env_cond_parameter`.`EnvCondParameterName`,
    `env_cond_parameter`.`EnvConditionId`,
    `env_cond_parameter`.`Order`,
    `env_cond_parameter`.`LastUpdateDate`,
    `env_cond_parameter`.`EditingBy`,
    `env_cond_parameter`.`Hide`
)
SELECT
    `env_cond_parameter`.`FieldCode`,
    NEW.`LanguageId`,
    `env_cond_parameter`.`EnvCondParameterName`,
    $CurId,
    `env_cond_parameter`.`Order`,
    CURRENT_TIMESTAMP(),
    `env_cond_parameter`.`EditingBy`,
    `env_cond_parameter`.`Hide`
FROM `ABCanTrackV2`.`env_cond_parameter` WHERE EnvConditionId = $MIN AND LanguageId = GetLanguageId('en');
IF $MIN = $MAX THEN
LEAVE EnvLoop;
ELSE
SET $MIN = (SELECT MIN(EnvConditionId) FROM `ABCanTrackV2`.env_condition WHERE OrgId IS NULL AND EnvConditionId > $MIN  AND LanguageId = GetLanguageId('en'));
END IF;
END WHILE;
INSERT INTO `ABCanTrackV2`.`event_type`
(
    `event_type`.`FieldCode`,
    `event_type`.`LanguageId`,
    `event_type`.`EventTypeName`,
    `event_type`.`OrgId`,
    `event_type`.`Order`,
    `event_type`.`LastUpdateDate`,
    `event_type`.`EditingBy`,
    `event_type`.`Hide`
)
SELECT
    `event_type`.`FieldCode`,
    NEW.`LanguageId`,
    `event_type`.`EventTypeName`,
    `event_type`.`OrgId`,
    `event_type`.`Order`,
    CURRENT_TIMESTAMP(),
    `event_type`.`EditingBy`,
    `event_type`.`Hide`
FROM `ABCanTrackV2`.`event_type` WHERE OrgId IS NULL AND LanguageId = GetLanguageId('en');
INSERT INTO `ABCanTrackV2`.`external_agency`
(
    `external_agency`.`FieldCode`,
    `external_agency`.`LanguageId`,
    `external_agency`.`ExtAgencyName`,
    `external_agency`.`OrgId`,
    `external_agency`.`Description`,
    `external_agency`.`Order`,
    `external_agency`.`LastUpdateDate`,
    `external_agency`.`EditingBy`,
    `external_agency`.`Hide`
)
SELECT
    `external_agency`.`FieldCode`,
    NEW.`LanguageId`,
    `external_agency`.`ExtAgencyName`,
    `external_agency`.`OrgId`,
    `external_agency`.`Description`,
    `external_agency`.`Order`,
    CURRENT_TIMESTAMP(),
    `external_agency`.`EditingBy`,
    `external_agency`.`Hide`
FROM `ABCanTrackV2`.`external_agency` WHERE OrgId IS NULL AND LanguageId = GetLanguageId('en');
SET $MIN = (SELECT MIN(ImpactTypeId) FROM `ABCanTrackV2`.impact_type WHERE OrgId IS NULL AND LanguageId = GetLanguageId('en'));
SET $MAX = (SELECT MAX(ImpactTypeId) FROM `ABCanTrackV2`.impact_type WHERE OrgId IS NULL AND LanguageId = GetLanguageId('en'));
ImpactLoop: WHILE $MIN <= $MAX
DO
INSERT INTO `ABCanTrackV2`.`impact_type`
(
    `impact_type`.`FieldCode`,
    `impact_type`.`LanguageId`,
    `impact_type`.`ImpactTypeName`,
    `impact_type`.`ImpactTypeCode`,
    `impact_type`.`IsPotential`,
    `impact_type`.`OrgId`,
    `impact_type`.`Order`,
    `impact_type`.`LastUpdateDate`,
    `impact_type`.`EditingBy`,
    `impact_type`.`Hide`
)
SELECT
    `impact_type`.`FieldCode`,
    NEW.`LanguageId`,
    `impact_type`.`ImpactTypeName`,
    `impact_type`.`ImpactTypeCode`,
    `impact_type`.`IsPotential`,
    `impact_type`.`OrgId`,
    `impact_type`.`Order`,
    CURRENT_TIMESTAMP(),
    `impact_type`.`EditingBy`,
    `impact_type`.`Hide`
FROM `ABCanTrackV2`.`impact_type` WHERE ImpactTypeId = $MIN AND LanguageId = GetLanguageId('en');
SET $CurId = (SELECT MAX(ImpactTypeId) FROM `ABCanTrackV2`.impact_type WHERE OrgId IS NULL AND LanguageId = NEW.`LanguageId`);
INSERT INTO `ABCanTrackV2`.`impact_sub_type`
(
    `impact_sub_type`.`FieldCode`,
    `impact_sub_type`.`LanguageId`,
	`impact_sub_type`.`ImpactSubTypeName`,
    `impact_sub_type`.`ImpactTypeId`,
    `impact_sub_type`.`Order`,
    `impact_sub_type`.`LastUpdateDate`,
    `impact_sub_type`.`EditingBy`,
    `impact_sub_type`.`Hide`
)
SELECT
    `impact_sub_type`.`FieldCode`,
    NEW.`LanguageId`,
    `impact_sub_type`.`ImpactSubTypeName`,
    $CurId,
    `impact_sub_type`.`Order`,
    CURRENT_TIMESTAMP(),
    `impact_sub_type`.`EditingBy`,
    `impact_sub_type`.`Hide`
FROM `ABCanTrackV2`.`impact_sub_type` WHERE ImpactTypeId = $MIN AND LanguageId = GetLanguageId('en');
IF $MIN = $MAX THEN
LEAVE ImpactLoop;
ELSE
SET $MIN = (SELECT MIN(ImpactTypeId) FROM `ABCanTrackV2`.impact_type WHERE OrgId IS NULL AND ImpactTypeId > $MIN AND LanguageId = GetLanguageId('en'));
END IF;
END WHILE;
INSERT INTO `ABCanTrackV2`.`incident_severity`
(
    `incident_severity`.`FieldCode`,
    `incident_severity`.`LanguageId`,
    `incident_severity`.`IncidentSeverityName`,
    `incident_severity`.`OrgId`,
    `incident_severity`.`Order`,
    `incident_severity`.`LastUpdateDate`,
    `incident_severity`.`EditingBy`,
    `incident_severity`.`Hide`
)
SELECT
    `incident_severity`.`FieldCode`,
    NEW.`LanguageId`,
    `incident_severity`.`IncidentSeverityName`,
    `incident_severity`.`OrgId`,
    `incident_severity`.`Order`,
    CURRENT_TIMESTAMP(),
    `incident_severity`.`EditingBy`,
    `incident_severity`.`Hide`
FROM `ABCanTrackV2`.`incident_severity` WHERE OrgId IS NULL AND LanguageId = GetLanguageId('en');
INSERT INTO `ABCanTrackV2`.`initial_treatment`
(
    `initial_treatment`.`FieldCode`,
    `initial_treatment`.`LanguageId`,
    `initial_treatment`.`InitialTreatmentName`,
    `initial_treatment`.`OrgId`,
    `initial_treatment`.`Order`,
    `initial_treatment`.`LastUpdateDate`,
    `initial_treatment`.`EditingBy`,
    `initial_treatment`.`Hide`
)
SELECT
    `initial_treatment`.`FieldCode`,
    NEW.`LanguageId`,
    `initial_treatment`.`InitialTreatmentName`,
    `initial_treatment`.`OrgId`,
    `initial_treatment`.`Order`,
    CURRENT_TIMESTAMP(),
    `initial_treatment`.`EditingBy`,
    `initial_treatment`.`Hide`
FROM `ABCanTrackV2`.`initial_treatment` WHERE OrgId IS NULL AND LanguageId = GetLanguageId('en');
INSERT INTO `ABCanTrackV2`.`injury_recordable`
(
    `injury_recordable`.`FieldCode`,
    `injury_recordable`.`LanguageId`,
    `injury_recordable`.`RecordableName`,
    `injury_recordable`.`OrgId`,
    `injury_recordable`.`Order`,
    `injury_recordable`.`LastUpdateDate`,
    `injury_recordable`.`EditingBy`,
    `injury_recordable`.`Hide`
)
SELECT
    `injury_recordable`.`FieldCode`,
    NEW.`LanguageId`,
    `injury_recordable`.`RecordableName`,
    `injury_recordable`.`OrgId`,
    `injury_recordable`.`Order`,
    CURRENT_TIMESTAMP(),
    `injury_recordable`.`EditingBy`,
    `injury_recordable`.`Hide`
FROM `ABCanTrackV2`.`injury_recordable` WHERE OrgId IS NULL AND LanguageId = GetLanguageId('en');
INSERT INTO `ABCanTrackV2`.`injury_type`
(
    `injury_type`.`FieldCode`,
    `injury_type`.`LanguageId`,
    `injury_type`.`InjuryTypeName`,
    `injury_type`.`OrgId`,
    `injury_type`.`Order`,
    `injury_type`.`LastUpdateDate`,
    `injury_type`.`EditingBy`,
    `injury_type`.`Hide`
)
SELECT
    `injury_type`.`FieldCode`,
    NEW.`LanguageId`,
    `injury_type`.`InjuryTypeName`,
    `injury_type`.`OrgId`,
    `injury_type`.`Order`,
    CURRENT_TIMESTAMP(),
    `injury_type`.`EditingBy`,
    `injury_type`.`Hide`
FROM `ABCanTrackV2`.`injury_type` WHERE OrgId IS NULL AND LanguageId = GetLanguageId('en');
INSERT INTO `ABCanTrackV2`.`inv_source`
(
    `inv_source`.`FieldCode`,
    `inv_source`.`LanguageId`,
    `inv_source`.`InvSourceName`,
    `inv_source`.`OrgId`,
    `inv_source`.`Order`,
    `inv_source`.`LastUpdateDate`,
    `inv_source`.`EditingBy`,
    `inv_source`.`Hide`
)
SELECT
    `inv_source`.`FieldCode`,
    NEW.`LanguageId`,
    `inv_source`.`InvSourceName`,
    `inv_source`.`OrgId`,
    `inv_source`.`Order`,
    CURRENT_TIMESTAMP(),
    `inv_source`.`EditingBy`,
    `inv_source`.`Hide`
FROM `ABCanTrackV2`.`inv_source` WHERE OrgId IS NULL AND LanguageId = GetLanguageId('en');
INSERT INTO `ABCanTrackV2`.`inv_status`
(
    `inv_status`.`FieldCode`,
    `inv_status`.`LanguageId`,
    `inv_status`.`InvStatusName`,
    `inv_status`.`InvStatusCode`,
    `inv_status`.`Description`,
    `inv_status`.`OrgId`,
    `inv_status`.`Order`,
    `inv_status`.`LastUpdateDate`,
    `inv_status`.`EditingBy`,
    `inv_status`.`Hide`
)
SELECT
    `inv_status`.`FieldCode`,
    NEW.`LanguageId`,
    `inv_status`.`InvStatusName`,
    `inv_status`.`InvStatusCode`,
    `inv_status`.`Description`,
    `inv_status`.`OrgId`,
    `inv_status`.`Order`,
    CURRENT_TIMESTAMP(),
    `inv_status`.`EditingBy`,
    `inv_status`.`Hide`
FROM `ABCanTrackV2`.`inv_status` WHERE OrgId IS NULL AND LanguageId = GetLanguageId('en');
/**
SET $Min = (select min(ObservationAndAnalysisId) from `ABCanTrackV2`.observation_analysis where OrgId is null AND LanguageId = GetLanguageId('en'));
SET $Max = (select max(ObservationAndAnalysisId) from `ABCanTrackV2`.observation_analysis where OrgId is null AND LanguageId = GetLanguageId('en'));
ObserLoop: While $Min <= $Max
DO
INSERT INTO `ABCanTrackV2`.`observation_analysis`
(
    `observation_analysis`.`FieldCode`,
    `observation_analysis`.`LanguageId`,
    `observation_analysis`.`ObservationAndAnalysisCode`,
    `observation_analysis`.`ObservationAndAnalysisName`,
    `observation_analysis`.`ObservationAndAnalysisDetails`,
    `observation_analysis`.`OrgId`,
    `observation_analysis`.`Order`,
    `observation_analysis`.`LastUpdateDate`,
    `observation_analysis`.`EditingBy`,
    `observation_analysis`.`Hide`
)
SELECT
    `observation_analysis`.`FieldCode`,
    NEW.`LanguageId`,
    `observation_analysis`.`ObservationAndAnalysisCode`,
    `observation_analysis`.`ObservationAndAnalysisName`,
    `observation_analysis`.`ObservationAndAnalysisDetails`,
    `observation_analysis`.`OrgId`,
    `observation_analysis`.`Order`,
    Current_timestamp(),
    `observation_analysis`.`EditingBy`,
    `observation_analysis`.`Hide`
FROM `ABCanTrackV2`.`observation_analysis` Where ObservationAndAnalysisId = $Min AND LanguageId = GetLanguageId('en');
SET $CurId = (SELECT LastId from last_uuid where TableName = 'observation_analysis');
SET $Code1 = (select ObservationAndAnalysisCode from `ABCanTrackV2`.observation_analysis where OrgId is null AND LanguageId = GetLanguageId('en') AND ObservationAndAnalysisId = $Min );
CALL `ABCanTrackV2`.`InsertObserAnaParamTrigger2`($Code1,NEW.`LanguageId`,$Min);
IF $Min = $Max then
LEAVE ObserLoop;
Else
SET $Min = (select min(ObservationAndAnalysisId) from `ABCanTrackV2`.observation_analysis where OrgId is null AND LanguageId = GetLanguageId('en') and ObservationAndAnalysisId > $Min);
END IF;
END While;
**/
CALL `ins_lang_observations`(NEW.`LanguageId`);
INSERT INTO `ABCanTrackV2`.`oe_department`
(
    `oe_department`.`FieldCode`,
    `oe_department`.`LanguageId`,
    `oe_department`.`Province`,
    `oe_department`.`OEDepartmentName`,
    `oe_department`.`Address`,
    `oe_department`.`WebSite`,
    `oe_department`.`Phone`,
    `oe_department`.`Fax`,
    `oe_department`.`Order`,
    `oe_department`.`OrgId`,
    `oe_department`.`HelpMeName`,
    `oe_department`.`HelpMeDescription`,
    `oe_department`.`LastUpdateDate`,
    `oe_department`.`EditingBy`,
    `oe_department`.`Hide`
)
SELECT
    `oe_department`.`FieldCode`,
    NEW.`LanguageId`,
    `oe_department`.`Province`,
    `oe_department`.`OEDepartmentName`,
    `oe_department`.`Address`,
    `oe_department`.`WebSite`,
    `oe_department`.`Phone`,
    `oe_department`.`Fax`,
    `oe_department`.`Order`,
    `oe_department`.`OrgId`,
    `oe_department`.`HelpMeName`,
    `oe_department`.`HelpMeDescription`,
    CURRENT_TIMESTAMP(),
    `oe_department`.`EditingBy`,
    `oe_department`.`Hide`
FROM `ABCanTrackV2`.`oe_department` WHERE OrgId IS NULL AND LanguageId = GetLanguageId('en');
/*
INSERT INTO `ABCanTrackV2`.`org_field`
(
	`org_field`.`OrgId`,
    `org_field`.`FieldId`,
    `org_field`.`FieldLabel`,
    `org_field`.`HelpMeName`,
    `org_field`.`HelpMeDescription`,
    `org_field`.`IsMandatory`
)
SELECT
	`field`.`OrgId`,
	`field`.`FieldId`,
    `field`.`DefaultFieldLabel`,
    `field`.`DefaultHelpMeName`,
    `field`.`DefaultHelpMeDescription`,
    `field`.`IsMandatory`
FROM `ABCanTrackV2`.`field` Where OrgId is null;
*/
INSERT INTO `ABCanTrackV2`.`priority`
(
    `priority`.`FieldCode`,
    `priority`.`LanguageId`,
    `priority`.`PriorityName`,
    `priority`.`OrgId`,
    `priority`.`Order`,
    `priority`.`LastUpdateDate`,
    `priority`.`EditingBy`,
    `priority`.`Hide`
)
SELECT
    `priority`.`FieldCode`,
    NEW.`LanguageId`,
    `priority`.`PriorityName`,
    `priority`.`OrgId`,
    `priority`.`Order`,
    CURRENT_TIMESTAMP(),
    `priority`.`EditingBy`,
    `priority`.`Hide`
FROM `ABCanTrackV2`.`priority` WHERE OrgId IS NULL AND LanguageId = GetLanguageId('en');
INSERT INTO `ABCanTrackV2`.`quantity_unit`
(
    `quantity_unit`.`FieldCode`,
    `quantity_unit`.`LanguageId`,
    `quantity_unit`.`QuantityUnitName`,
    `quantity_unit`.`Order`,
    `quantity_unit`.`OrgId`,
    `quantity_unit`.`LastUpdateDate`,
    `quantity_unit`.`EditingBy`,
    `quantity_unit`.`Hide`
)
SELECT
    `quantity_unit`.`FieldCode`,
    NEW.`LanguageId`,
    `quantity_unit`.`QuantityUnitName`,
    `quantity_unit`.`Order`,
    `quantity_unit`.`OrgId`,
    CURRENT_TIMESTAMP(),
    `quantity_unit`.`EditingBy`,
    `quantity_unit`.`Hide`
FROM `ABCanTrackV2`.`quantity_unit` WHERE OrgId IS NULL AND LanguageId = GetLanguageId('en');
INSERT INTO `ABCanTrackV2`.`restricted_work`
(
    `restricted_work`.`FieldCode`,
    `restricted_work`.`LanguageId`,
    `restricted_work`.`RestrictedWorkName`,
    `restricted_work`.`OrgId`,
    `restricted_work`.`Order`,
    `restricted_work`.`LastUpdateDate`,
    `restricted_work`.`EditingBy`,
    `restricted_work`.`Hide`
)
SELECT
    `restricted_work`.`FieldCode`,
    NEW.`LanguageId`,
    `restricted_work`.`RestrictedWorkName`,
    `restricted_work`.`OrgId`,
    `restricted_work`.`Order`,
    CURRENT_TIMESTAMP(),
    `restricted_work`.`EditingBy`,
    `restricted_work`.`Hide`
FROM `ABCanTrackV2`.`restricted_work` WHERE OrgId IS NULL AND LanguageId = GetLanguageId('en');
INSERT INTO `ABCanTrackV2`.`risk_of_recurrence`
(
    `risk_of_recurrence`.`FieldCode`,
    `risk_of_recurrence`.`LanguageId`,
    `risk_of_recurrence`.`RiskOfRecurrenceName`,
    `risk_of_recurrence`.`OrgId`,
    `risk_of_recurrence`.`Order`,
    `risk_of_recurrence`.`LastUpdateDate`,
    `risk_of_recurrence`.`EditingBy`,
    `risk_of_recurrence`.`Hide`
)
SELECT
    `risk_of_recurrence`.`FieldCode`,
    NEW.`LanguageId`,
    `risk_of_recurrence`.`RiskOfRecurrenceName`,
    `risk_of_recurrence`.`OrgId`,
    `risk_of_recurrence`.`Order`,
    CURRENT_TIMESTAMP(),
    `risk_of_recurrence`.`EditingBy`,
    `risk_of_recurrence`.`Hide`
FROM `ABCanTrackV2`.`risk_of_recurrence` WHERE OrgId IS NULL AND LanguageId = GetLanguageId('en');
SET $MIN = (SELECT MIN(RootCauseId) FROM `ABCanTrackV2`.root_cause WHERE OrgId IS NULL AND LanguageId = GetLanguageId('en'));
SET $MAX = (SELECT MAX(RootCauseId) FROM `ABCanTrackV2`.root_cause WHERE OrgId IS NULL AND LanguageId = GetLanguageId('en'));
RootCauseLoop: WHILE $MIN <= $MAX
DO
INSERT INTO `ABCanTrackV2`.`root_cause`
(
    `root_cause`.`FieldCode`,
    `root_cause`.`LanguageId`,
    `root_cause`.`RootCauseName`,
    `root_cause`.`OrgId`,
    `root_cause`.`Order`,
    `root_cause`.`LastUpdateDate`,
    `root_cause`.`EditingBy`,
    `root_cause`.`Hide`
)
SELECT
    `root_cause`.`FieldCode`,
    NEW.`LanguageId`,
    `root_cause`.`RootCauseName`,
    `root_cause`.`OrgId`,
    `root_cause`.`Order`,
    CURRENT_TIMESTAMP(),
    `root_cause`.`EditingBy`,
    `root_cause`.`Hide`
FROM `ABCanTrackV2`.`root_cause` WHERE RootCauseId = $MIN AND LanguageId = GetLanguageId('en');
SET $CurId = (SELECT MAX(RootCauseId) FROM `ABCanTrackV2`.root_cause WHERE OrgId IS NULL AND LanguageId = NEW.`LanguageId`);
 INSERT INTO `ABCanTrackV2`.`root_cause_param`
 (
    `root_cause_param`.`FieldCode`,
    `root_cause_param`.`LanguageId`,
    `root_cause_param`.`RootCauseParamName`,
    `root_cause_param`.`RootCauseId`,
    `root_cause_param`.`RootCauseParamDescription`,
    `root_cause_param`.`Order`,
    `root_cause_param`.`LastUpdateDate`,
    `root_cause_param`.`EditingBy`,
    `root_cause_param`.`Hide`
)
 SELECT
    `root_cause_param`.`FieldCode`,
    NEW.`LanguageId`,
    `root_cause_param`.`RootCauseParamName`,
    $CurId,
    `root_cause_param`.`RootCauseParamDescription`,
    `root_cause_param`.`Order`,
    CURRENT_TIMESTAMP(),
    `root_cause_param`.`EditingBy`,
    `root_cause_param`.`Hide`
FROM `ABCanTrackV2`.`root_cause_param`  WHERE RootCauseId = $MIN AND LanguageId = GetLanguageId('en');
IF $MIN = $MAX THEN
LEAVE RootCauseLoop;
ELSE
SET $MIN = (SELECT MIN(RootCauseId) FROM `ABCanTrackV2`.root_cause WHERE OrgId IS NULL AND RootCauseId > $MIN AND LanguageId = GetLanguageId('en'));
END IF;
END WHILE;
INSERT INTO `ABCanTrackV2`.`spill_release_source`
(
    `spill_release_source`.`FieldCode`,
    `spill_release_source`.`LanguageId`,
    `spill_release_source`.`SourceName`,
    `spill_release_source`.`Description`,
    `spill_release_source`.`OrgId`,
    `spill_release_source`.`Order`,
    `spill_release_source`.`LastUpdateDate`,
    `spill_release_source`.`EditingBy`,
    `spill_release_source`.`Hide`
)
SELECT
    `spill_release_source`.`FieldCode`,
    NEW.`LanguageId`,
    `spill_release_source`.`SourceName`,
    `spill_release_source`.`Description`,
    `spill_release_source`.`OrgId`,
    `spill_release_source`.`Order`,
     CURRENT_TIMESTAMP(),
    `spill_release_source`.`EditingBy`,
    `spill_release_source`.`Hide`
FROM `ABCanTrackV2`.`spill_release_source` WHERE OrgId IS NULL AND LanguageId = GetLanguageId('en');
INSERT INTO `ABCanTrackV2`.`symptoms`
(
    `symptoms`.`FieldCode`,
    `symptoms`.`LanguageId`,
    `symptoms`.`Description`,
    `symptoms`.`AdditionalDetails`,
    `symptoms`.`OrgId`,
    `symptoms`.`Order`,
    `symptoms`.`LastUpdateDate`,
    `symptoms`.`EditingBy`,
    `symptoms`.`Hide`
)
SELECT
    `symptoms`.`FieldCode`,
    NEW.`LanguageId`,
    `symptoms`.`Description`,
    `symptoms`.`AdditionalDetails`,
    `symptoms`.`OrgId`,
    `symptoms`.`Order`,
    CURRENT_TIMESTAMP(),
    `symptoms`.`EditingBy`,
    `symptoms`.`Hide`
FROM `ABCanTrackV2`.`symptoms` WHERE OrgId IS NULL AND LanguageId = GetLanguageId('en');
INSERT INTO `ABCanTrackV2`.`vehicle_type`
(
    `vehicle_type`.`FieldCode`,
    `vehicle_type`.`LanguageId`,
    `vehicle_type`.`VehicleTypeName`,
    `vehicle_type`.`AdditionalDetails`,
    `vehicle_type`.`OrgId`,
    `vehicle_type`.`Order`,
    `vehicle_type`.`LastUpdateDate`,
    `vehicle_type`.`EditingBy`,
    `vehicle_type`.`Hide`
)
SELECT
    `vehicle_type`.`FieldCode`,
    NEW.`LanguageId`,
    `vehicle_type`.`VehicleTypeName`,
    `vehicle_type`.`AdditionalDetails`,
    `vehicle_type`.`OrgId`,
    `vehicle_type`.`Order`,
    CURRENT_TIMESTAMP(),
    `vehicle_type`.`EditingBy`,
    `vehicle_type`.`Hide`
FROM `ABCanTrackV2`.`vehicle_type` WHERE `OrgId` IS NULL AND LanguageId = GetLanguageId('en');
INSERT INTO `ABCanTrackV2`.`sp_rel_agency`
(
     `sp_rel_agency`.LanguageId
	,`sp_rel_agency`.FieldCode
	,`sp_rel_agency`.SpRelAgencyName
	,`sp_rel_agency`.OrgId
	,`sp_rel_agency`.`Order`
	,`sp_rel_agency`.LastUpdateDate
	,`sp_rel_agency`.EditingBy
	,`sp_rel_agency`.Hide
)
SELECT
     NEW.LanguageId
	,`sp_rel_agency`.FieldCode
	,`sp_rel_agency`.SpRelAgencyName
	,`sp_rel_agency`.OrgId
	,`sp_rel_agency`.`Order`
	,CURRENT_TIMESTAMP()
	,`sp_rel_agency`.EditingBy
	,`sp_rel_agency`.Hide
FROM `ABCanTrackV2`.`sp_rel_agency` WHERE `OrgId` IS NULL AND LanguageId = GetLanguageId('en');
INSERT INTO `ABCanTrackV2`.`operation`
(
	`operation`.`OperationCode`,
	`operation`.`OperationName`,
	`operation`.`LanguageId`,
	`operation`.`LastUpdateDate`,
	`operation`.`EditingBy`,
	`operation`.`Hide`
)
SELECT
	`operation`.`OperationCode`,
	`operation`.`OperationName`,
	NEW.`LanguageId`,
	CURRENT_TIMESTAMP(),
	`operation`.`EditingBy`,
	`operation`.`Hide`
FROM `ABCanTrackV2`.`operation` WHERE LanguageId = GetLanguageId('en');
INSERT INTO `ABCanTrackV2`.`output_type`
(
	`output_type`.`OutputTypeId`,
	`output_type`.`OutputCode`,
    `output_type`.`OutputTypeName`,
	`output_type`.`LanguageId`,
	`output_type`.`LastUpdateDate`,
	`output_type`.`EditingBy`,
	`output_type`.`Hide`
)
SELECT
	`output_type`.`OutputTypeId`,
	`output_type`.`OutputCode`,
    `output_type`.`OutputTypeName`,
	NEW.`LanguageId`,
	CURRENT_TIMESTAMP(),
	`output_type`.`EditingBy`,
	`output_type`.`Hide`
FROM `ABCanTrackV2`.`output_type` WHERE LanguageId = GetLanguageId('en');
INSERT INTO `ABCanTrackV2`.`tab`
(
	`tab`.`TabId`,
	`tab`.`TabName`,
	`tab`.`LanguageId`,
	`tab`.`FieldCode`,
	`tab`.`TableName`,
	`tab`.`LastUpdateDate`,
	`tab`.`EditingBy`,
	`tab`.`Hide`
)
SELECT
	`tab`.`TabId`,
	`tab`.`TabName`,
	NEW.`LanguageId`,
	`tab`.`FieldCode`,
	`tab`.`TableName`,
	CURRENT_TIMESTAMP(),
	`tab`.`EditingBy`,
	`tab`.`Hide`
FROM `ABCanTrackV2`.`tab` WHERE LanguageId = GetLanguageId('en');
INSERT INTO `ABCanTrackV2`.`sub_tab`
(
	`sub_tab`.`SubTabId`,
	`sub_tab`.`SubTabName`,
	`sub_tab`.`LanguageId`,
	`sub_tab`.`FieldCode`,
	`sub_tab`.`SubTabLabel`,
	`sub_tab`.`TabId`,
	`sub_tab`.`LastUpdateDate`,
	`sub_tab`.`EditingBy`,
	`sub_tab`.`Hide`,
	`sub_tab`.`Order`
)
SELECT
	`sub_tab`.`SubTabId`,
	`sub_tab`.`SubTabName`,
	NEW.`LanguageId`,
	`sub_tab`.`FieldCode`,
	`sub_tab`.`SubTabLabel`,
	`sub_tab`.`TabId`,
	CURRENT_TIMESTAMP(),
	`sub_tab`.`EditingBy`,
	`sub_tab`.`Hide`,
	`sub_tab`.`Order`
FROM `ABCanTrackV2`.`sub_tab` WHERE LanguageId = GetLanguageId('en');
INSERT INTO `ABCanTrackV2`.`template_type`
(
	`template_type`.`TemplateTypeId`,
	`template_type`.`TemplateTypeCode`,
	`template_type`.`TemplateTypeName`,
	`template_type`.`LanguageId`,
	`template_type`.`LastUpdateDate`
)
SELECT
	`template_type`.`TemplateTypeId`,
	`template_type`.`TemplateTypeCode`,
	`template_type`.`TemplateTypeName`,
	NEW.`LanguageId`,
	CURRENT_TIMESTAMP()
FROM `ABCanTrackV2`.`template_type` WHERE LanguageId = GetLanguageId('en');
/**
Trigger CommonDB.third_party_type_AINS makes this so we commented it
INSERT INTO `ABCanTrackV2`.`third_party_type`
(
	`third_party_type`.`ThirdPartyTypeId`,
	`third_party_type`.`ThirdPartyTypeCode`,
	`third_party_type`.`ThirdPartyTypeName`,
	`third_party_type`.`LanguageId`,
	`third_party_type`.`OrgId`,
	`third_party_type`.`Order`,
	`third_party_type`.`LastUpdateDate`,
	`third_party_type`.`EditingBy`,
	`third_party_type`.`Hide`
)
SELECT
	MyUUID(),
	`third_party_type`.`ThirdPartyTypeCode`,
	`third_party_type`.`ThirdPartyTypeName`,
	NEW.`LanguageId`,
	`third_party_type`.`OrgId`,
	`third_party_type`.`Order`,
	CURRENT_TIMESTAMP(),
	`third_party_type`.`EditingBy`,
	`third_party_type`.`Hide`
FROM `ABCanTrackV2`.`third_party_type` WHERE OrgId IS NULL AND LanguageId = GetLanguageId('en');
**/
INSERT INTO `ABCanTrackV2`.`time_frame`
(
	`time_frame`.`TimeFrameId`,
	`time_frame`.`TimeFrameName`,
	`time_frame`.`LanguageId`,
	`time_frame`.`FieldCode`,
	`time_frame`.`LastUpdateDate`,
	`time_frame`.`EditingBy`,
	`time_frame`.`Hide`
)
SELECT
	`time_frame`.`TimeFrameId`,
	`time_frame`.`TimeFrameName`,
	NEW.`LanguageId`,
	`time_frame`.`FieldCode`,
	CURRENT_TIMESTAMP(),
	`time_frame`.`EditingBy`,
	`time_frame`.`Hide`
FROM `ABCanTrackV2`.`time_frame` WHERE LanguageId = GetLanguageId('en');
INSERT INTO `ABCanTrackV2`.`field_type`
(
	`field_type`.`FieldTypeId`,
	`field_type`.`FieldTypeName`,
	`field_type`.`LanguageId`,
	`field_type`.`FieldTypeCode`,
	`field_type`.`LastUpdateDate`,
	`field_type`.`EditingBy`,
	`field_type`.`Hide`
)
SELECT
	`field_type`.`FieldTypeId`,
	`field_type`.`FieldTypeName`,
	NEW.`LanguageId`,
	`field_type`.`FieldTypeCode`,
	CURRENT_TIMESTAMP(),
	`field_type`.`EditingBy`,
	`field_type`.`Hide`
FROM `ABCanTrackV2`.`field_type` WHERE LanguageId = GetLanguageId('en');
INSERT INTO `ABCanTrackV2`.`alert_message`
(
	`alert_message`.`AlertMessageId`,
	`alert_message`.`AlertName`,
	`alert_message`.`LanguageId`,
	`alert_message`.`AlertDescription`,
	`alert_message`.`AlertMessageCode`,
	`alert_message`.`AlertMessageDescription`,
	`alert_message`.`LastUpdateDate`,
	`alert_message`.`EditingBy`,
	`alert_message`.`Hide`,
	`alert_message`.`OldId`
)
SELECT
	`alert_message`.`AlertMessageId`,
	`alert_message`.`AlertName`,
	NEW.`LanguageId`,
	`alert_message`.`AlertDescription`,
	`alert_message`.`AlertMessageCode`,
	`alert_message`.`AlertMessageDescription`,
	CURRENT_TIMESTAMP(),
	`alert_message`.`EditingBy`,
	`alert_message`.`Hide`,
	`alert_message`.`OldId`
FROM `ABCanTrackV2`.`alert_message` WHERE LanguageId = GetLanguageId('en');
INSERT INTO `ABCanTrackV2`.`field`
(
	`field`.`FieldId`,
	`field`.`FieldName`,
	`field`.`LanguageId`,
	`field`.`DefaultFieldLabel`,
	`field`.`DataTypeId`,
	`field`.`IsStatistical`,
	`field`.`IsEditable`,
	`field`.`FieldTypeId`,
	`field`.`SubTabId`,
	`field`.`TableName`,
	`field`.`TableFieldName`,
	`field`.`OrgId`,
	`field`.`FieldDescription`,
	`field`.`DefaultHelpMeName`,
	`field`.`DefaultHelpMeDescription`,
	`field`.`IsHidden`,
	`field`.`Order`,
	`field`.`FieldParam`,
	`field`.`LastUpdateDate`,
	`field`.`EditingBy`,
	`field`.`Hide`,
	`field`.`IsTemplate`,
	`field`.`AdminNotes`,
	`field`.`IsMandatory`,
	`field`.`IsCustom`
)
SELECT
	`field`.`FieldId`,
	`field`.`FieldName`,
	NEW.`LanguageId`,
	`field`.`DefaultFieldLabel`,
	`field`.`DataTypeId`,
	`field`.`IsStatistical`,
	`field`.`IsEditable`,
	`ABCanTrackV2`.GetFieldTypeIdByLang(`field`.`FieldTypeId`, NEW.`LanguageId`),
	`ABCanTrackV2`.GetSubTabIdByLang(`field`.`SubTabId`, NEW.`LanguageId`),
	`field`.`TableName`,
	`field`.`TableFieldName`,
	`field`.`OrgId`,
	`field`.`FieldDescription`,
	`field`.`DefaultHelpMeName`,
	`field`.`DefaultHelpMeDescription`,
	`field`.`IsHidden`,
	`field`.`Order`,
	`field`.`FieldParam`,
	CURRENT_TIMESTAMP(),
	`field`.`EditingBy`,
	`field`.`Hide`,
	`field`.`IsTemplate`,
	`field`.`AdminNotes`,
	`field`.`IsMandatory`,
	`field`.`IsCustom`
FROM `ABCanTrackV2`.`field` WHERE OrgId IS NULL AND LanguageId = GetLanguageId('en');
INSERT INTO `CommonDB`.`history_operation`
(
    HistoryOperationId,
    FieldCode,
    HistoryOperationName,
    LanguageId
)
SELECT
    '',
    FieldCode,
    HistoryOperationName,
    NEW.LanguageId
FROM `CommonDB`.`history_operation` WHERE LanguageId = GetLanguageId('en');

-- ------------------

INSERT INTO `ABCanTrackV2`.`yes_no`
(
	`Id`,
    `OrgId`,
    `LanguageId`, 
    `LabelYes`, 
    `LabelNo`
)
select MyUUID(),
    null,
    NEW.LanguageId,
    `LabelYes`, 
    `LabelNo`
from `ABCanTrackV2`.`yes_no` where OrgId is null and `LanguageId` = GetLanguageId('en');
-- ------------------

insert into  ABCanTrackV2.template(
TemplateId,
FieldCode,
TemplateName,
TemplateTypeId,
EmployeeId,
OrgId,
LanguageId,
LastUpdatedDate,
IsTranslatable
)
SELECT 
'',
FieldCode,
TemplateName,
(select TemplateTypeId from ABCanTrackV2.template_type where TemplateTypeCode='DefaultTemplate'  and LanguageId=NEW.LanguageId),
EmployeeId,
OrgId,
NEW.LanguageId,
LastUpdatedDate,
IsTranslatable
 FROM ABCanTrackV2.template t
 where IsTranslatable=1 and LanguageId=GetLanguageId('en');
 
 
call ABCanTrackV2.default_template_field_lang(NEW.LanguageId);

 END;
