CREATE TRIGGER CommonDB.language_BINS
BEFORE INSERT ON CommonDB.language
FOR EACH ROW
  BEGIN
SET new.LanguageId = MyUUID();
END;
