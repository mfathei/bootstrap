CREATE TRIGGER CommonDB.language_AUPD
AFTER UPDATE ON CommonDB.language
FOR EACH ROW
  BEGIN
 
Update ABCanTrackV2.`language`
set 
	`language`.`LanguageId` = new.LanguageId,
    `language`.`LanguageName` = new.LanguageName,
    `language`.`LanguageCode` = new.LanguageCode,
    `language`.`LastUpdateDate` = new.LastUpdateDate,
    `language`.`EditingBy` = new.EditingBy,
    `language`.`Hide` = new.Hide
where `ABCanTrackV2`.`language`.`LanguageId` = OLD.LanguageId;
 
 END;
