CREATE TRIGGER CommonDB.group_BINS
BEFORE INSERT ON CommonDB.`group`
FOR EACH ROW
  BEGIN

SET new.GroupId = MyUUID();
Update last_uuid
	SET LastId	= new.GroupId
	WHERE TableName = 'group';

END;
