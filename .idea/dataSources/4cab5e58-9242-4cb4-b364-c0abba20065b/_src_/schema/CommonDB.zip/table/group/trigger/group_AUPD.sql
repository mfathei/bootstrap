CREATE TRIGGER CommonDB.group_AUPD
AFTER UPDATE ON CommonDB.`group`
FOR EACH ROW
  BEGIN
 
UPDATE `ABCanTrackV2`.`group`
SET
	`group`.`GroupId` = NEW.GroupId,
    `group`.`OrgId` = NEW.OrgId,
    `group`.`LanguageId`= NEW.`LanguageId`,
    `group`.`FieldCode`= NEW.`FieldCode`,
    `group`.`GroupName` = NEW.GroupName,
    `group`.`Description` = NEW.Description,
    `group`.`IsActive` = NEW.IsActive,
    `group`.`CreationDate` = NEW.CreationDate
WHERE `ABCanTrackV2`.`group`.`GroupId` = Old.GroupId;
 
 END;
