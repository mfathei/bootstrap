CREATE TRIGGER CommonDB.group_AINS
AFTER INSERT ON CommonDB.`group`
FOR EACH ROW
  BEGIN
-- set @enLangId = GetLanguageId('en');
INSERT INTO `ABCanTrackV2`.`group`
(
	`group`.`GroupId`,
    `group`.`OrgId`,
    `group`.`LanguageId`,
    `group`.`FieldCode`,
    `group`.`GroupName`,
    `group`.`Description`,
    `group`.`IsActive`,
    `group`.`CreationDate`
)
VALUES
(
    NEW.`GroupId`,
    NEW.`OrgId`,
    NEW.`LanguageId`,
    NEW.`FieldCode`,
    NEW.`GroupName`,
    NEW.`Description`,
    NEW.`IsActive`,
    NEW.`CreationDate`
);
IF NEW.FieldCode = 'administrators'
THEN
	INSERT INTO group_permission
	(
		GroupId,
		PermissionId
	)
	SELECT 
		NEW.GroupId,
        PermissionId
	FROM `CommonDB`.`group_permission` WHERE `GroupId` = (SELECT `GroupId` FROM `CommonDB`.`group` WHERE `FieldCode` = 'administrators' AND OrgId IS NULL AND LanguageId=NEW.`LanguageId`);
    
ELSEIF NEW.FieldCode = 'managers'
THEN
	INSERT INTO group_permission
	(
		GroupId,
		PermissionId
	)
	SELECT 
		NEW.GroupId,
        PermissionId
	FROM `CommonDB`.`group_permission` WHERE `GroupId` = (SELECT `GroupId` FROM `CommonDB`.`group` WHERE `FieldCode` = 'managers' AND OrgId IS NULL AND LanguageId=NEW.`LanguageId`);
ELSEIF NEW.FieldCode = 'fieldstaff'
THEN
	INSERT INTO group_permission
	(
		GroupId,
		PermissionId
	)
	SELECT 
		NEW.GroupId,
        PermissionId
	FROM `CommonDB`.`group_permission` WHERE `GroupId` = (SELECT `GroupId` FROM `CommonDB`.`group` WHERE `FieldCode` = 'fieldstaff' AND OrgId IS NULL AND LanguageId=NEW.`LanguageId`);
END  IF;
/*
INSERT INTO group_permission
	(
		GroupId,
		PermissionId
	)
	SELECT 
		NEW.GroupId,
        PermissionId
	FROM CommonDB.permission WHERE PermissionType = 'Default';
*/
END;
