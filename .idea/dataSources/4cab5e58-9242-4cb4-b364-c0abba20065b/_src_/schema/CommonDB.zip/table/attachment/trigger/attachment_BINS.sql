CREATE TRIGGER CommonDB.attachment_BINS
BEFORE INSERT ON CommonDB.attachment
FOR EACH ROW
  BEGIN
SET new.AttachmentId = MyUUID();
END;
