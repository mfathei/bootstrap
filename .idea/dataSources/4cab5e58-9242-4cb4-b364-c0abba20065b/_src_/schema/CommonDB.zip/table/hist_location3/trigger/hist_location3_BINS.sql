CREATE TRIGGER CommonDB.hist_location3_BINS
BEFORE INSERT ON CommonDB.hist_location3
FOR EACH ROW
  BEGIN
SET new.HistLocation3Id = MyUUID();
END;
