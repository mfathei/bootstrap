CREATE TRIGGER CommonDB.org_field_AUPD
AFTER UPDATE ON CommonDB.org_field
FOR EACH ROW
  BEGIN
DECLARE $FieldId VARCHAR(100);
SET $FieldId = (select FieldId from ABCanTrackV2.field where FieldName = Old.FieldName  and LanguageId = OLD.LanguageId);
Update ABCanTrackV2.org_field
set FieldLabel = new.Label
where FieldId = $FieldId and OrgId = OLD.OrgId;
END;
