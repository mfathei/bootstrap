CREATE TRIGGER CommonDB.third_party_type_BINS
BEFORE INSERT ON CommonDB.third_party_type
FOR EACH ROW
  BEGIN
SET new.ThirdPartyTypeId = MyUUID();
END;
