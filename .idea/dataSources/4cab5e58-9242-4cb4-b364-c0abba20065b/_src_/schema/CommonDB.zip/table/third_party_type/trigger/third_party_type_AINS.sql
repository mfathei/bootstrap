CREATE TRIGGER CommonDB.third_party_type_AINS
AFTER INSERT ON CommonDB.third_party_type
FOR EACH ROW
  BEGIN
insert into ABCanTrackV2.third_party_type
(
	`third_party_type`.`ThirdPartyTypeId`,
    `third_party_type`.`ThirdPartyTypeCode`,
    `third_party_type`.`ThirdPartyTypeName`,
    `third_party_type`.`LanguageId`,
    `third_party_type`.`OrgId`,
    `third_party_type`.`Order`,
    `third_party_type`.`LastUpdateDate`,
    `third_party_type`.`EditingBy`,
    `third_party_type`.`Hide`
)
select 
	new.`ThirdPartyTypeId`,
	new.`ThirdPartyTypeCode`,
    new.`ThirdPartyTypeName`,
    new.`LanguageId`,
    new.`OrgId`,
    new.`Order`,
    new.`LastUpdateDate`,
    new.`EditingBy`,
    new.`Hide`
;
END;
