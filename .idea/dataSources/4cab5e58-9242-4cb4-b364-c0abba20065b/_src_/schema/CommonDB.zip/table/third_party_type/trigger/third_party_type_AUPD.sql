CREATE TRIGGER CommonDB.third_party_type_AUPD
AFTER UPDATE ON CommonDB.third_party_type
FOR EACH ROW
  BEGIN
 
update ABCanTrackV2.third_party_type
set
	`third_party_type`.`ThirdPartyTypeId` = new.ThirdPartyTypeId,
    `third_party_type`.`ThirdPartyTypeCode` = new.ThirdPartyTypeCode,
    `third_party_type`.`ThirdPartyTypeName` = new.ThirdPartyTypeName,
    `third_party_type`.`OrgId` = new.OrgId,
    `third_party_type`.`Order` = new.`Order`,
    `third_party_type`.`LastUpdateDate` = new.LastUpdateDate,
    `third_party_type`.`EditingBy` = new.EditingBy,
    `third_party_type`.`Hide` = new.Hide
where `ABCanTrackV2`.`third_party_type`.`ThirdPartyTypeId` = OLD.ThirdPartyTypeId;
 
 END;
