CREATE TRIGGER CommonDB.employee_BINS
BEFORE INSERT ON CommonDB.employee
FOR EACH ROW
  BEGIN
	
	SET NEW.EmployeeId = MyUUID();
    
	SET NEW.UserName = NEW.Email;
    
	UPDATE last_uuid
	SET LastId	= NEW.EmployeeId
	WHERE TableName = 'employee';
END;
