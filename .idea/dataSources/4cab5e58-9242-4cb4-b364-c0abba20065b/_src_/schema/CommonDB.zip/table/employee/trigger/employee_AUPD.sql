CREATE TRIGGER CommonDB.employee_AUPD
AFTER UPDATE ON CommonDB.employee
FOR EACH ROW
  BEGIN
UPDATE `ABCanTrackV2`.`employee`
SET 
	`employee`.`EmployeeId` = NEW.`EmployeeId`,
    `employee`.`FirstName` = NEW.`FirstName`,
    `employee`.`LastName` = NEW.`LastName`,
    `employee`.`Email` = NEW.`Email`,
    `employee`.`Address` = NEW.`Address`,
    `employee`.`CityId` = NEW.`CityId`,
    `employee`.`PostalCode` = NEW.`PostalCode`,
    `employee`.`Position` = NEW.`Position`,
    `employee`.`Area` = NEW.`Area`,
    `employee`.`PrimaryPhone` = NEW.`PrimaryPhone`,
    `employee`.`AlternatePhone` = NEW.`AlternatePhone`
WHERE `ABCanTrackV2`.`employee`.`EmployeeId` = OLD.`EmployeeId`;
 
 END;
