CREATE TRIGGER CommonDB.employee_AINS
AFTER INSERT ON CommonDB.employee
FOR EACH ROW
  BEGIN
INSERT INTO `ABCanTrackV2`.`employee`
(
	`employee`.`EmployeeId`,
    `employee`.`FirstName`,
    `employee`.`LastName`,
    `employee`.`Email`,
    `employee`.`Address`,
    `employee`.`CityId`,
    `employee`.`PostalCode`,
    `employee`.`Position`,
    `employee`.`Area`,
    `employee`.`PrimaryPhone`,
    `employee`.`AlternatePhone`
)
VALUES 
(
	NEW.`EmployeeId`,
    NEW.`FirstName`,
    NEW.`LastName`,
    NEW.`Email`,
    NEW.`Address`,
    NEW.`CityId`,
    NEW.`PostalCode`,
    NEW.`Position`,
    NEW.`Area`,
    NEW.`PrimaryPhone`,
    NEW.`AlternatePhone`
)
;
END;
