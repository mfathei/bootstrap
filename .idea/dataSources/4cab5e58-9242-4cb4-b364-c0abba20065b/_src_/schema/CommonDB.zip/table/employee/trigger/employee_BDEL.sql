CREATE TRIGGER CommonDB.employee_BDEL
BEFORE DELETE ON CommonDB.employee
FOR EACH ROW
  BEGIN
DELETE FROM `ABCanTrackV2`.`employee` WHERE `EmployeeId` = Old.`EmployeeId`;
END;
