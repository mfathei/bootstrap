CREATE TRIGGER CommonDB.classification_BINS
BEFORE INSERT ON CommonDB.classification
FOR EACH ROW
  BEGIN
SET new.ClassificationId = MyUUID();
END;
