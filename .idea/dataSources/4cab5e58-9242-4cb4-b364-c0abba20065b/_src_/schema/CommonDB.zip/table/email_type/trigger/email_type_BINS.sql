CREATE TRIGGER CommonDB.email_type_BINS
BEFORE INSERT ON CommonDB.email_type
FOR EACH ROW
  BEGIN
SET new.EmailTypeId = MyUUID();
END;
