CREATE TRIGGER CommonDB.hist_organization_BINS
BEFORE INSERT ON CommonDB.hist_organization
FOR EACH ROW
  BEGIN
SET new.HistOrgId = MyUUID();
END;
