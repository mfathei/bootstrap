CREATE TRIGGER CommonDB.location3_AUPD
AFTER UPDATE ON CommonDB.location3
FOR EACH ROW
  BEGIN
 
update  ABCanTrackV2.location3
set 
	`location3`.`location3Id` = new.location3Id,
    `location3`.`location3Name` =  new.location3Name,
    `location3`.`Location2Id` = new.Location2Id,
    `location3`.`Order` = new.`Order`,
    `location3`.`LastUpdateDate` = new.LastUpdateDate,
    `location3`.`EditingBy` = new.EditingBy,
    `location3`.`Hide` = new.Hide
where `ABCanTrackV2`.`location3`.`location3Id` = OLD.location3Id;
 
 END;
