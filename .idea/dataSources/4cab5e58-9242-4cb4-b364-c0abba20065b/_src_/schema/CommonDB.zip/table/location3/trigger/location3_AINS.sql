CREATE TRIGGER CommonDB.location3_AINS
AFTER INSERT ON CommonDB.location3
FOR EACH ROW
  BEGIN
insert into ABCanTrackV2.location3
(
	`location3`.`location3Id`,
    `location3`.`location3Name`,
    `location3`.`Location2Id`,
    `location3`.`Order`,
    `location3`.`LastUpdateDate`,
    `location3`.`EditingBy`,
    `location3`.`Hide`
)
select
	new.`location3Id`,
    new.`location3Name`,
    new.`Location2Id`,
    new.`Order`,
    new.`LastUpdateDate`,
    new.`EditingBy`,
    new.`Hide`;
END;
