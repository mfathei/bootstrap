CREATE TRIGGER CommonDB.location3_ADEL
AFTER DELETE ON CommonDB.location3
FOR EACH ROW
  BEGIN
Delete from ABCanTrackV2.location3 where Location3Id = OLD.Location3Id;
END;
