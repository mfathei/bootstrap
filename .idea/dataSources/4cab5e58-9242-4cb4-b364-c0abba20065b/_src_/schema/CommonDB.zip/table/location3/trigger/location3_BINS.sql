CREATE TRIGGER CommonDB.location3_BINS
BEFORE INSERT ON CommonDB.location3
FOR EACH ROW
  BEGIN
	SET new.Location3Id = MyUUID();
	Update last_uuid
	SET LastId	= new.Location3Id
	WHERE TableName = 'location3';
END;
