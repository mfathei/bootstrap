CREATE TRIGGER CommonDB.province_AUPD
AFTER UPDATE ON CommonDB.province
FOR EACH ROW
  BEGIN
 
UPDATE `ABCanTrackV2`.`province`
SET
	`province`.`ProvinceId` = NEW.`ProvinceId`,
    `province`.`ProvinceName` = NEW.`ProvinceName`,
    `province`.`LanguageId`= new.`LanguageId`,
    `province`.`CountryId` = NEW.`CountryId`
WHERE `ABCanTrackV2`.`province`.`ProvinceId` = OLD.`ProvinceId`;
 
 END;
