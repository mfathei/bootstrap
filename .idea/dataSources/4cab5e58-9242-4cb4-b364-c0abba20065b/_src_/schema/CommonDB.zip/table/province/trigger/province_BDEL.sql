CREATE TRIGGER CommonDB.province_BDEL
BEFORE DELETE ON CommonDB.province
FOR EACH ROW
  BEGIN

DELETE FROM ABCanTrackV2.province WHERE ProvinceId = OLD.ProvinceId;

END;
