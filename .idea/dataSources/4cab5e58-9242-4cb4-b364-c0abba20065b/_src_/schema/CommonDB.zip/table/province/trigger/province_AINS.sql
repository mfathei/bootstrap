CREATE TRIGGER CommonDB.province_AINS
AFTER INSERT ON CommonDB.province
FOR EACH ROW
  BEGIN
INSERT INTO `ABCanTrackV2`.`province`
(
	`province`.`ProvinceId`,
    `province`.`ProvinceName`,
    `province`.`LanguageId`,
    `province`.`CountryId`
)
VALUES
(
	NEW.`ProvinceId`,
    NEW.`ProvinceName`,
    NEW.`LanguageId`,
    NEW.`CountryId`
);
END;
