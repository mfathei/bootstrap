CREATE TRIGGER CommonDB.province_BINS
BEFORE INSERT ON CommonDB.province
FOR EACH ROW
  BEGIN
  SET new.ProvinceId = MyUUID();
END;
