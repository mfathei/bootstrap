CREATE TRIGGER CommonDB.location2_BINS
BEFORE INSERT ON CommonDB.location2
FOR EACH ROW
  BEGIN
	SET new.Location2Id = MyUUID();
	Update last_uuid
	SET LastId	= new.Location2Id
	WHERE TableName = 'location2';
END;
