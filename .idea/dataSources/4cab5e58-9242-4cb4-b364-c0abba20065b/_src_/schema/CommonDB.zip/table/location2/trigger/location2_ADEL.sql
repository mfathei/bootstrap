CREATE TRIGGER CommonDB.location2_ADEL
AFTER DELETE ON CommonDB.location2
FOR EACH ROW
  BEGIN
Delete from ABCanTrackV2.location2 where Location2Id = OLD.Location2Id;
END;
