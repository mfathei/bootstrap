CREATE TRIGGER CommonDB.location2_AINS
AFTER INSERT ON CommonDB.location2
FOR EACH ROW
  BEGIN
insert into ABCanTrackV2.location2
(
	`location2`.`location2Id`,
    `location2`.`location2Name`,
    `location2`.`Location1Id`,
    `location2`.`Order`,
    `location2`.`LastUpdateDate`,
    `location2`.`EditingBy`,
    `location2`.`Hide`
)
select
	new.`location2Id`,
    new.`location2Name`,
	new.`Location1Id`,
    new.`Order`,
    new.`LastUpdateDate`,
    new.`EditingBy`,
    new.`Hide`;
END;
