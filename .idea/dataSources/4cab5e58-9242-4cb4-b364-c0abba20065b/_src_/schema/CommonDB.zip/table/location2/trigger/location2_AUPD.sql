CREATE TRIGGER CommonDB.location2_AUPD
AFTER UPDATE ON CommonDB.location2
FOR EACH ROW
  BEGIN
 
update  ABCanTrackV2.location2
set 
	`location2`.`location2Id` = new.`location2Id`,
    `location2`.`location2Name` =  new.`location2Name`,
	`location2`.`Location1Id` = new.`Location1Id`,
    `location2`.`Order` = new.`Order`,
    `location2`.`LastUpdateDate` = new.`LastUpdateDate`,
    `location2`.`EditingBy` = new.`EditingBy`,
    `location2`.`Hide` = new.`Hide`
where `ABCanTrackV2`.`location2`.`location2Id` = OLD.location2Id;
 
 END;
