CREATE TRIGGER CommonDB.organization_AINS
AFTER INSERT ON CommonDB.organization
FOR EACH ROW
  BEGIN
/* This Trigger inserts default data into the following Tables
1. `ABCanTrackV2`.`organization`
2. `CommonDB`.`operation_type`
3. `CommonDB`.`org_alert_message`
4. `CommonDB`.`org_field`
5. `CommonDB`.`third_party_type`
6. `CommonDB`.`group`
*/
INSERT INTO	`ABCanTrackV2`.`organization`
(
	`organization`.`OrgId`,
    `organization`.`OrgName`,
    `organization`.`OrgCode`,
    `organization`.`LanguageId`,
    `organization`.`Street`,
    `organization`.`CityId`,
    `organization`.`PostalCode`
)
VALUES
( 
	NEW.`OrgId`,
    NEW.`OrgName`,
    NEW.`OrgCode`,
    NEW.`LanguageId`,
    NEW.`Address`,
    NEW.`CityId`,
    NEW.`PostalCode`
);
-- ***********************************************
INSERT INTO `CommonDB`.`operation_type`
(
    `operation_type`.`LanguageId`,
    `operation_type`.`OperationTypeName`,
    `operation_type`.`OrgId`,
    `operation_type`.`Order`,
    `operation_type`.`LastUpdateDate`,
    `operation_type`.`EditingBy`,
    `operation_type`.`Hide`
)
SELECT 
    `operation_type`.`LanguageId`,
    `operation_type`.`OperationTypeName`,
     NEW.`OrgId`,
    `operation_type`.`Order`,
    Current_timestamp(),
    `operation_type`.`EditingBy`,
    `operation_type`.`Hide`
FROM `CommonDB`.`operation_type` WHERE `OrgId` IS NULL AND `operation_type`.`LanguageId`= NEW.`LanguageId`;
-- ***********************************************
/*INSERT INTO `CommonDB`.`org_alert_message`
(
	`org_alert_message`.`OrgId`,
    `org_alert_message`.`AlertMessageId`,
    `org_alert_message`.`LanguageId`,
    `org_alert_message`.`AlertMessageDescription`
)
SELECT 
	 NEW.OrgId,
	`alert_message`.`AlertMessageId`,
	$LanguageId,
    `alert_message`.`AlertMessageDescription`
FROM `CommonDB`.`alert_message`;
*/
INSERT INTO `CommonDB`.`org_field`
(
    `org_field`.`FieldName`,
    `org_field`.`OrgId`,
    `org_field`.`LanguageId`,
    `org_field`.`Label`
)
SELECT 
    `org_field`.`FieldName`,
     NEW.`OrgId`,
    `org_field`.`LanguageId`,
    `org_field`.`Label`
FROM `CommonDB`.`org_field` WHERE `OrgId` IS NULL AND `org_field`.`LanguageId`= NEW.`LanguageId`;
INSERT INTO `CommonDB`.`third_party_type`
(
    `third_party_type`.`ThirdPartyTypeCode`,
    `third_party_type`.`ThirdPartyTypeName`,
    `third_party_type`.`OrgId`,
    `third_party_type`.`LanguageId`,
    `third_party_type`.`Order`,
    `third_party_type`.`LastUpdateDate`,
    `third_party_type`.`EditingBy`,
    `third_party_type`.`Hide`
)
SELECT 
    `third_party_type`.`ThirdPartyTypeCode`,
    `third_party_type`.`ThirdPartyTypeName`,
     NEW.`OrgId`,
     `third_party_type`.`LanguageId`,
    `third_party_type`.`Order`,
    Current_timestamp(),
    `third_party_type`.`EditingBy`,
    `third_party_type`.`Hide`
FROM `CommonDB`.`third_party_type` WHERE `OrgId` IS NULL AND `third_party_type`.`LanguageId`= NEW.`LanguageId`;
INSERT INTO `CommonDB`.`group`
(
    `group`.`OrgId`,
    `group`.`FieldCode`,
    `group`.`LanguageId`,
    `group`.`GroupName`,
    `group`.`Description`,
    `group`.`IsActive`,
    `group`.`CreationDate`
)
SELECT 
     NEW.`OrgId`,
    `group`.`FieldCode`,
    `group`.`LanguageId`,
    `group`.`GroupName`,
    `group`.`Description`,
    `group`.`IsActive`,
    Current_timestamp()
FROM `CommonDB`.`group` WHERE OrgId IS NULL AND `group`.`LanguageId`= NEW.`LanguageId`;
END;
