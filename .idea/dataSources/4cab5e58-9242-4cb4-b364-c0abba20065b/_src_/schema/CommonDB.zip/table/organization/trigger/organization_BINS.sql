CREATE TRIGGER CommonDB.organization_BINS
BEFORE INSERT ON CommonDB.organization
FOR EACH ROW
  BEGIN
	SET NEW.OrgId = MyUUID();
	SET NEW.CreationDate = CURRENT_TIMESTAMP();
	Update last_uuid
	SET LastId	= NEW.OrgId
	WHERE TableName = 'organization';
END;
