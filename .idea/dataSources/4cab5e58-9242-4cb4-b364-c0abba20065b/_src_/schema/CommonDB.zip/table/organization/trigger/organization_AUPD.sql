CREATE TRIGGER CommonDB.organization_AUPD
AFTER UPDATE ON CommonDB.organization
FOR EACH ROW
  BEGIN
 
UPDATE `ABCanTrackV2`.`organization`
SET 
	`organization`.`OrgId` = NEW.`OrgId`,
    `organization`.`OrgName` = NEW.`OrgName`,
    `organization`.`OrgCode` = NEW.`OrgCode`,
    `organization`.`Street` = NEW.`Address`,
    `organization`.`CityId` = NEW.`CityId`,
    `organization`.`PostalCode` = NEW.`PostalCode`
WHERE `ABCanTrackV2`.`organization`.`OrgId` = OLD.`OrgId`;
 
 END;
