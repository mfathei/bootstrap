CREATE TRIGGER CommonDB.dashboard_BINS
BEFORE INSERT ON CommonDB.dashboard
FOR EACH ROW
  BEGIN
SET new.DashboardId = MyUUID();
END;
