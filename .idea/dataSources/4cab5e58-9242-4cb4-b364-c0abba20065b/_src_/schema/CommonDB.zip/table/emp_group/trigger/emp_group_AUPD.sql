CREATE TRIGGER CommonDB.emp_group_AUPD
AFTER UPDATE ON CommonDB.emp_group
FOR EACH ROW
  BEGIN
 
UPDATE `ABCanTrackV2`.`emp_group`
SET
	`emp_group`.`GroupId` = NEW.GroupId,
    `emp_group`.`EmployeeId` = NEW.EmployeeId,
    `emp_group`.`AssignToGroupDate` = NEW.AssignToGroupDate,
    `emp_group`.`IsActive` = NEW.IsActive
WHERE `ABCanTrackV2`.`emp_group`.`GroupId` = Old.GroupId AND `ABCanTrackV2`.`emp_group`.`EmployeeId` = Old.EmployeeId;
 
 END;
