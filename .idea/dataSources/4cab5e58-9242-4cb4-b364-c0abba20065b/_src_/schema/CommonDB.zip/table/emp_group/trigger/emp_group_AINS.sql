CREATE TRIGGER CommonDB.emp_group_AINS
AFTER INSERT ON CommonDB.emp_group
FOR EACH ROW
  BEGIN
INSERT INTO `ABCanTrackV2`.`emp_group`
(
	`emp_group`.`GroupId`,
    `emp_group`.`EmployeeId`,
    `emp_group`.`AssignToGroupDate`,
    `emp_group`.`IsActive`
)
VALUES
(
	 NEW.`GroupId`,
     NEW.`EmployeeId`,
     NEW.`AssignToGroupDate`,
     NEW.`IsActive`
 );
END;
