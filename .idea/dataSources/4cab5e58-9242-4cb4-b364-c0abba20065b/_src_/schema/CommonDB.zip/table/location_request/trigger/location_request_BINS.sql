CREATE TRIGGER CommonDB.location_request_BINS
BEFORE INSERT ON CommonDB.location_request
FOR EACH ROW
  BEGIN
SET new.LocRequestId = MyUUID();
END;
