CREATE TRIGGER CommonDB.security_question_BINS
BEFORE INSERT ON CommonDB.security_question
FOR EACH ROW
  BEGIN
SET new.SecurityQuestionId = MyUUID();
END;
