CREATE TRIGGER CommonDB.email_parameter_log_BINS
BEFORE INSERT ON CommonDB.email_parameter
FOR EACH ROW
  BEGIN
SET new.ParameterId = MyUUID();
END;
