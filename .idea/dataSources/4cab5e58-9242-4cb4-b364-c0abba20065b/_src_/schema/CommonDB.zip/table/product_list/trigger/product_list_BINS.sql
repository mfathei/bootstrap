CREATE TRIGGER CommonDB.product_list_BINS
BEFORE INSERT ON CommonDB.product_list
FOR EACH ROW
  BEGIN
SET new.ProductListId = MyUUID();
END;
