CREATE TRIGGER CommonDB.hist_employee_BINS
BEFORE INSERT ON CommonDB.hist_employee
FOR EACH ROW
  BEGIN
SET new.HistEmployeeId = MyUUID();
END;
