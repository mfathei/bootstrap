CREATE TRIGGER CommonDB.operation_type_AINS
AFTER INSERT ON CommonDB.operation_type
FOR EACH ROW
  BEGIN
insert into ABCanTrackV2.operation_type
(
	`operation_type`.`OperationTypeId`,
    `operation_type`.`OperationTypeName`,
    `operation_type`.`OrgId`,
    `operation_type`.`LanguageId`,
    `operation_type`.`FieldCode`,
    `operation_type`.`Order`,
    `operation_type`.`LastUpdateDate`,
    `operation_type`.`EditingBy`,
    `operation_type`.`Hide`
)
select 
	new.`OperationTypeId`,
    new.`OperationTypeName`,
    new.`OrgId`,
    new.`LanguageId`,
    new.`FieldCode`,
    new.`Order`,
    new.`LastUpdateDate`,
    new.`EditingBy`,
    new.`Hide`;
    
END;
