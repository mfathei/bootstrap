CREATE TRIGGER CommonDB.operation_type_BDEL
BEFORE DELETE ON CommonDB.operation_type
FOR EACH ROW
  BEGIN
DELETE FROM `ABCanTrackV2`.`operation_type` WHERE OperationTypeId = Old.OperationTypeId;
END;
