CREATE TRIGGER CommonDB.operation_type_BINS
BEFORE INSERT ON CommonDB.operation_type
FOR EACH ROW
  BEGIN
SET new.OperationTypeId = MyUUID();
END;
