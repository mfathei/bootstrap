CREATE TRIGGER CommonDB.operation_type_AUPD
AFTER UPDATE ON CommonDB.operation_type
FOR EACH ROW
  BEGIN
update ABCanTrackV2.operation_type
set
	`operation_type`.`OperationTypeId` = new.OperationTypeId,
    `operation_type`.`OperationTypeName` = new.OperationTypeName,
    `operation_type`.`OrgId` = new.OrgId,
    `operation_type`.`LanguageId` = new.`LanguageId`,
    `operation_type`.`FieldCode`=new.`FieldCode`,
    `operation_type`.`Order` = new.`Order`,
    `operation_type`.`LastUpdateDate` = new.LastUpdateDate,
    `operation_type`.`EditingBy` = new.EditingBy,
    `operation_type`.`Hide` = new.Hide
where `ABCanTrackV2`.`operation_type`.`OperationTypeId` = OLD.OperationTypeId;
 END;
