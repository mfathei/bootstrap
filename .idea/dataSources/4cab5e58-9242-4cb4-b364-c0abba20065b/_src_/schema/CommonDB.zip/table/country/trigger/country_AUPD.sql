CREATE TRIGGER CommonDB.country_AUPD
AFTER UPDATE ON CommonDB.country
FOR EACH ROW
  BEGIN
 
UPDATE ABCanTrackV2.country
SET 	
	`country`.`CountryId` = NEW.`CountryId`,
    `country`.`CountryName` = NEW.`CountryName`,
     `country`.`LanguageId` = NEW.`LanguageId`
where `ABCanTrackV2`.`country`.`CountryId` = OLD.CountryId;
 
 END;
