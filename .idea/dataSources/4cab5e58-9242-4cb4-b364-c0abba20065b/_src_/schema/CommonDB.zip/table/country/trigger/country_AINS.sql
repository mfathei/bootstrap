CREATE TRIGGER CommonDB.country_AINS
AFTER INSERT ON CommonDB.country
FOR EACH ROW
  BEGIN
INSERT INTO ABCanTrackV2.country
(	
	`country`.`CountryId`,
    `country`.`LanguageId`,
    `country`.`CountryName`
)
VALUES 
(	
	NEW.`CountryId`,
    NEW.`LanguageId`,
    NEW.`CountryName`
)
;
END;
