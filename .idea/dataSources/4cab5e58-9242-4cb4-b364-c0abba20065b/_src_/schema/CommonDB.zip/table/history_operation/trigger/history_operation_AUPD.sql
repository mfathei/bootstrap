CREATE TRIGGER CommonDB.history_operation_AUPD
AFTER UPDATE ON CommonDB.history_operation
FOR EACH ROW
  BEGIN
 
UPDATE `ABCanTrackV2`.`history_operation`
SET 
	`history_operation`.`HistoryOperationId` = 	NEW.`HistoryOperationId`,
    `history_operation`.`HistoryOperationName` = NEW.`HistoryOperationName`
WHERE `ABCanTrackV2`.`history_operation`.`HistoryOperationId` = OLD.`HistoryOperationId`;
 
 END;
