CREATE TRIGGER CommonDB.history_operation_BINS
BEFORE INSERT ON CommonDB.history_operation
FOR EACH ROW
  BEGIN
  SET NEW.HistoryOperationId = MyUUID();
END;
