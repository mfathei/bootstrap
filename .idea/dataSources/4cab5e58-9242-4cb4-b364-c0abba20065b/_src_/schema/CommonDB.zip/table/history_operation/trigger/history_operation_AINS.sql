CREATE TRIGGER CommonDB.history_operation_AINS
AFTER INSERT ON CommonDB.history_operation
FOR EACH ROW
  BEGIN
INSERT INTO `ABCanTrackV2`.`history_operation`
(
	`history_operation`.`HistoryOperationId`,
    `history_operation`.`HistoryOperationName`,
    `history_operation`.LanguageId
)
VALUES
(
	NEW.`HistoryOperationId`,
    NEW.`HistoryOperationName`,
    NEW.LanguageId
)
;
END;
