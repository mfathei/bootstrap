CREATE TRIGGER CommonDB.city_AINS
AFTER INSERT ON CommonDB.city
FOR EACH ROW
  BEGIN
Insert into ABCanTrackV2.city
(	
	`city`.`CityId`,
    `city`.`CityName`,
    `city`.`LanguageId`,
    `city`.`ProvinceId`
)
values
(
	NEW.`CityId`,
    NEW.`CityName`,
    new.`LanguageId`,
    NEW.`ProvinceId`
)
;
END;
