CREATE TRIGGER CommonDB.city_AUPD
AFTER UPDATE ON CommonDB.city
FOR EACH ROW
  BEGIN
 
UPDATE ABCanTrackV2.city
set
	`city`.`CityId` = NEW.CityId,
    `city`.`CityName` = NEW.`CityName`,
    `city`.`LanguageId`= new.`LanguageId`,
    `city`.`ProvinceId` = NEW.`ProvinceId`
where `ABCanTrackV2`.`city`.`CityId` = OLD.CityId;
 
 END;
