CREATE TRIGGER CommonDB.hist_location4_BINS
BEFORE INSERT ON CommonDB.hist_location4
FOR EACH ROW
  BEGIN
SET new.HistLocation4Id = MyUUID();
END;
