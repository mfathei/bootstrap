CREATE TRIGGER CommonDB.email_log_BINS
BEFORE INSERT ON CommonDB.email_log
FOR EACH ROW
  BEGIN
	SET new.EmailLogId = MyUUID();  
	Update last_uuid
	SET LastId	= new.EmailLogId
	WHERE TableName = 'email_log';
END;
