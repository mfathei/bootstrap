CREATE PROCEDURE repo.sp_getroots(IN groupname VARCHAR(10))
  begin
	drop temporary table if exists `tmp_folders`;
	create temporary table `tmp_folders`(
		`id` varchar(50),
        `type` varchar(10),
        `name` varchar(255),
        `parentid` varchar(50),
        `extension` varchar(5),
        `delete` tinyint(1)
    );
    insert into `tmp_folders` select file_id,file_type,file_filename,file_parentid,file_extension,(select 0) from `file` where file_filename = 'Customers' and file_type = 'folder' and file_parentid = 'devapps-4cccd965-02d2-11e6-86ea-525400cc302d';
    insert into `tmp_folders` select file_id,file_type,file_filename,file_parentid,file_extension,(select 0) from `file` where file_filename = 'Engineering' and file_type = 'folder' and file_parentid = 'devapps-4cccd965-02d2-11e6-86ea-525400cc302d';
    insert into `tmp_folders` select file_id,file_type,file_filename,file_parentid,file_extension,(select 0) from `file` where file_filename = 'Globals' and file_type = 'folder' and file_parentid = 'devapps-4cccd965-02d2-11e6-86ea-525400cc302d';
    insert into `tmp_folders` select file_id,file_type,file_filename,file_parentid,file_extension,(select 0) from `file` where file_filename = 'Links' and file_type = 'folder' and file_parentid = 'devapps-4cccd965-02d2-11e6-86ea-525400cc302d';
    insert into `tmp_folders` select file_id,file_type,file_filename,file_parentid,file_extension,(select 0) from `file` where file_filename = groupname and file_type = 'folder' and file_parentid = 'devapps-4cccd965-02d2-11e6-86ea-525400cc302d';
    
    select * from `tmp_folders`;
    drop temporary table if exists `tmp_folders`;
end;
