CREATE PROCEDURE repo.temp_proc()
  BEGIN
declare finished integer default 0;
declare groupname varchar(10);
	
	declare group_cursor CURSOR FOR select `group_name` from `auth`.`group` where `is_primary` = 1;
    declare continue handler for not found set finished = 1;
    open group_cursor;
    
    get_group: loop
		fetch group_cursor into groupname;
        if finished = 1 then
			leave get_group;
		end if;
        set @uuid = (select myuuid());
        insert into `file` values (@uuid,'folder','devapps-4cccd965-02d2-11e6-86ea-525400cc302d',groupname,'',now(),'db1-cfb1fabe-6027-11e4-b1b7-525400b87f6d');
    end loop get_group;
    close group_cursor;
END;
