CREATE PROCEDURE repo.sp_getcustomerroot(IN folderid VARCHAR(50))
  begin
	select file_id as id,file_type as `type`,file_filename as `name`,file_parentid as parentid,file_extension as extension from `file` where file_id = folderid;
end;
